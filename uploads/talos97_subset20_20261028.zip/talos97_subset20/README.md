# TALOS97 20-design subset

20 of the original 97 designs, preserving original split membership: 12 train, 4 validation, 4 test. Selected by evenly spaced input nucleotide-count ranks within each original split, not by model performance. This is a compact transfer/sample dataset, not the complete benchmark.

Input: actual simulation initial t0. Target: replica 1 empirical mean of 1000 production frames, not final frame or exact equilibrium. NPZ positions normalized by40; multiply by34.072 for nm. Includes raw initial/topology/mean files and input/label NPZ. No trajectories, replica2/3, checkpoints or predictions.

manifest.json contains SHA256 for each original per-design file. Original absolute provenance paths are historical and not required to load this archive. split.json contains only the included designs. original_split_97.json preserves the full original partition for reference.

# TALOS97 endpoint dataset v1

97designs; input initial.dat t0 before first oxDNA minimization. Target replica1 empirical production mean (not lastframe). Source-only inputs NPZ and supervision labels NPZ are separate. 68train/14validation/15test,seed20261028,size stratified,not shape-held-out. Allrows retained,no trajectories copied. Rebuild:python experiments/talos97_endpoint_v1/scripts/build_dataset.py.

Edge20channels:type5,relative normalized vector3,distance1,componentwise a1*a1(3),a3*a3(3),a1*a3(3),same strand1,axial delta/100(1). Frame vectors are in fixed initial chart; only PaiNN vector backbone has explicitly equivariant readout.
