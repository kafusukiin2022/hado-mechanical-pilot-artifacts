"""Wait for verified caches, then run the authorized joint-training arm D."""
import argparse,json,subprocess,sys,time,traceback
from pathlib import Path
from .datasets import sha256
from .train import write


def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--epochs',type=int,default=120);a=p.parse_args();b=a.root/'outputs/dna_cgdm_20261104';status=b/'campaign_status.json';start=time.monotonic();static=b/'static';cache=b/'cache'
 while True:
  if (cache/'failure.json').exists():raise RuntimeError('cache preparation failed: '+(cache/'failure.json').read_text())
  ready=(cache/'manifest.json').exists() and len(json.loads((cache/'manifest.json').read_text()))==85
  if ready:break
  write(status,dict(stage='waiting_verified_cache',cache_status=json.loads((cache/'status.json').read_text()) if (cache/'status.json').exists() else {},seconds=time.monotonic()-start));time.sleep(20)
 gate=json.loads((b/'probe100_flat64/gate.json').read_text())
 if not gate['passed'] or gate['nodes']!=9996 or gate['window']!=256:raise RuntimeError('largest graph gate not passed')
 config=a.root/'dna_cgdm/config.json';write(status,dict(stage='training_D',epochs=a.epochs,config_sha256=sha256(config)))
 command=[sys.executable,'-m','dna_cgdm.train','--static',str(static),'--out',str(b/'joint_D_seed11'),'--config',str(config),'--epochs',str(a.epochs),'--arm','D','--samples','4']
 with (b/'training_D.log').open('w') as log:
  result=subprocess.run(command,cwd=str(a.root),stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:raise RuntimeError('training D failed, inspect training_D.log')
 write(status,dict(stage='complete',seconds=time.monotonic()-start,training=str(b/'joint_D_seed11')))
if __name__=='__main__':
 try:main()
 except Exception as exc:
  b=Path(__file__).resolve().parents[1]/'outputs/dna_cgdm_20261104';write(b/'campaign_failure.json',dict(error=repr(exc),traceback=traceback.format_exc()));raise
