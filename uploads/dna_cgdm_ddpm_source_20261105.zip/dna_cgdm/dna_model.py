"""Shared design encoder + upstream conditional U-GNN/DDPM + consistent heads."""
import torch
from torch import nn
from torch.nn import functional as F
from .source import enable_upstream

enable_upstream()
from graph_signal_diffusion.models.ugnn import UGNN, UGNNConfig, GNNConfig, PoolingConfig, EmbeddingConfig
from graph_signal_diffusion.diffusion.ddpm import DDPM
from graph_signal_diffusion.diffusion.ddim import DDIM


def aggregate(h, edge, weight):
    src, dst = edge
    weight = weight.to(h.dtype)
    degree = h.new_zeros(len(h)).index_add_(0, dst, weight)
    return h.new_zeros(h.shape).index_add_(0, dst, h[src]*weight[:, None])/degree.clamp_min(1e-8)[:, None]


class DesignEncoder(nn.Module):
    def __init__(self, features, width=128):
        super().__init__()
        self.input = nn.Sequential(nn.Linear(features, width), nn.SiLU(), nn.LayerNorm(width), nn.Linear(width, width), nn.SiLU())
        self.local = nn.ModuleList([nn.Sequential(nn.Linear(width*2, width), nn.SiLU(), nn.Linear(width, width), nn.LayerNorm(width)) for _ in range(2)])

    def forward(self, x, edge, weight):
        if x.ndim != 3 or x.shape[1] != 1:
            raise ValueError('design x must have shape (N,1,D), batch=1')
        h = self.input(x[:, 0])
        for layer in self.local:
            h = h+layer(torch.cat((h, aggregate(h, edge, weight)), dim=-1))
        return h


class SupervisedHeads(nn.Module):
    def __init__(self, width, scales):
        super().__init__()
        self.readout = nn.Sequential(nn.Linear(width, width), nn.SiLU(), nn.Linear(width, 14))
        self.register_buffer('scales', torch.as_tensor(scales, dtype=torch.float32))
        if self.scales.shape != (7,):
            raise ValueError('scales: mu, C, P1,P10,P50,P100,P200')

    def forward(self, c):
        a = self.readout(c).float()
        mu = a[:, :3]*self.scales[0]
        lower = a.new_zeros(len(a), 3, 3)
        i, j = torch.tril_indices(3, 3, device=a.device)
        lower[:, i, j] = a[:, 3:9]
        diagonal = torch.arange(3, device=a.device)
        lower[:, diagonal, diagonal] = F.softplus(lower[:, diagonal, diagonal])+1e-4
        covariance = (lower@lower.transpose(-1, -2))*self.scales[1]
        persistence = F.softplus(a[:, 9:])*self.scales[2:]
        # Exactly one P50 value reused, not a second independently trained head.
        return dict(mean=mu, covariance=covariance, persistence=persistence,
                    p50=persistence[:, 2], cholesky=lower*self.scales[1].sqrt())


def ugnn_config(config):
    return UGNNConfig(in_channels=3, out_channels=3,
        base_channels=config['channels'], channel_multipliers=config['channel_multipliers'],
        gnn_config=GNNConfig(K=config['graph_hops'], num_layers=2, normalize=True,
            use_strided_conv=True, use_temporal_mixer=True,
            temporal_mixer_schedule='per_layer', temporal_kernel_size=config['temporal_kernel_size'],
            temporal_dilations=config['temporal_dilations'], temporal_causal=False),
        pooling_config=PoolingConfig(gamma=config['pool_gamma'], selection_method=config['selection'],
            selector_skip_gamma1_levels=True, selector_collect_heavy_diagnostics=False, selector_version='v3', selector_cond_fusion_mode='film'),
        embedding_config=EmbeddingConfig(num_timesteps=config['diffusion_steps'],
            cond_channels=config['condition_width'], cond_embed_dim=64,
            cond_temporal_num_layers=1, cond_temporal_hidden_channels=[64],
            cond_temporal_kernel_size=1, cond_temporal_dilations=[1]),
        num_bottleneck_layers=2, compact_skip_cache=True)


class DNACGDM(nn.Module):
    def __init__(self, features, scales, config):
        super().__init__()
        self.config = dict(config)
        self.condition_encoder = DesignEncoder(features, config['condition_width'])
        self.heads = SupervisedHeads(config['condition_width'], scales)
        from .efficient_graph import optimize_ugnn
        self.denoiser = optimize_ugnn(UGNN(ugnn_config(config)))
        self.diffusion = DDPM(model=self.denoiser, num_timesteps=config['diffusion_steps'],
            beta_schedule=config['beta_schedule'], parameterization='eps',
            clip_denoised=config['clip_denoised'], revin=config['revin'])
        self.diffusion.set_collect_selector_heavy_diagnostics(False)
        self.supervised_ugnn_projection = nn.Linear(config['channels'], config['condition_width'])

    def encode(self, data):
        return self.condition_encoder(data.x, data.edge_index, data.edge_weight)

    def predict(self, data, use_ugnn=False):
        c = self.encode(data)
        if use_ugnn:
            zero = c.new_zeros(1, 1, len(c), 3)
            step = torch.zeros(1, dtype=torch.long, device=c.device)
            decoded = []
            hook = self.denoiser.decoder.output_proj.register_forward_pre_hook(lambda module, args: decoded.append(args[0]))
            try:
                self.denoiser(zero, step, data.edge_index, data.edge_weight, cond=c[None, None])
            finally:
                hook.remove()
            c = c+self.supervised_ugnn_projection(decoded[0][0, 0])
        return self.heads(c)

    def loss(self, data, labels, eta=None, xi=None):
        # Explicit batch=1; no use of target in the conditioning encoder.
        if getattr(data, 'num_graphs', 1) != 1:
            raise ValueError('mixed-N graph batching is not implemented')
        c = self.encode(data)
        target = data.y.permute(1, 0, 2)[None]
        step = torch.randint(self.config['diffusion_steps'], (1,), device=target.device)
        noise = torch.randn_like(target)
        noisy = self.diffusion.add_noise(target, step, noise)
        for module in self.denoiser.modules():
            reset = getattr(module, 'reset_selector_state', None)
            if callable(reset):
                reset()
        epsilon, _ = self.denoiser(noisy, step, data.edge_index, data.edge_weight, cond=c[None, None])
        diffusion = F.mse_loss(epsilon, noise)
        selector = self.diffusion._collect_selector_losses_and_diagnostics()
        if selector is None:
            selector = diffusion.new_zeros(())
        predicted = self.heads(c)
        scales = self.heads.scales
        p50 = ((predicted['p50']-labels['persistence'][:, 2]).square().mean()+1e-8).sqrt()/scales[4]
        mean = ((predicted['mean']-labels['mean'])/scales[0]).square().mean()
        cov = ((predicted['covariance']-labels['covariance'])/scales[1]).square().mean()
        p = ((predicted['persistence']-labels['persistence'])/scales[2:]).square().mean()
        supervised = p50+.3*(mean+cov+p)/3
        eta = self.config['eta_supervised'] if eta is None else eta
        xi = self.config['xi_selector'] if xi is None else xi
        return dict(total=diffusion+eta*supervised+xi*selector,
                    diffusion=diffusion, supervised=supervised, selector=selector,
                    p50=p50, mean=mean, covariance=cov, persistence=p)

    @torch.no_grad()
    def sample(self, data, normalization, samples=1, steps=None):
        """Only x/edges needed. Returns unnormalized local samples (M,W,N,3)."""
        self.eval()
        c = self.encode(data)
        from torch_geometric.data import Data
        condition = Data(x=c[:, None], edge_index=data.edge_index, edge_weight=data.edge_weight)
        sampler = DDIM(model=self.denoiser, num_timesteps=self.config['diffusion_steps'],
            beta_schedule=self.config['beta_schedule'], parameterization='eps',
            sampling_timesteps=steps or self.config['ddim_steps'],
            clip_denoised=False, revin=False).to(c.device)
        sampler.set_collect_selector_heavy_diagnostics(False)
        output = []
        for _ in range(samples):
            with torch.autocast(device_type=c.device.type, dtype=torch.bfloat16, enabled=c.device.type=='cuda'):
                q = sampler.sample((1, self.config['window'], len(c), 3), device=c.device, data=condition)
            output.append(q[0])
        q = torch.stack(output)
        mean = torch.as_tensor(normalization['q_mean'], dtype=q.dtype, device=q.device)
        std = torch.as_tensor(normalization['q_std'], dtype=q.dtype, device=q.device)
        return q*std+mean
