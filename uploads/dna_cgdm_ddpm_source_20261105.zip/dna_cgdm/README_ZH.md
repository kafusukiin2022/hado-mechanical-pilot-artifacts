# DNA-CGDM 第一版

基于用户指定的 https://github.com/yigit-uslu/graph-signal-diffusion ，固定上游提交 `018ac033e32105010fe2265e0bdef56db5fa74bb`，保留MIT许可。vendor checkout保持原样；DNA适配器在本目录。

## 当前结构与接口

`设计(S,F,G) → 128宽MLP+2层邻居消息传递 → Cφ`。

监督分支：`Cφ → heads → mean_local3, covariance=LLᵀ, P[1,10,50,100,200]`。P50直接取P矩阵第3列，没有两个独立P50。生成分支：`normalized Qk + k + Cφ → upstream UGNN → epsilon → upstream DDIM → Q0`。不存在原独立GPR模块。

Dataset接口x[N,1,D]、y[N,256,3]、edge_index[2,E]、scalar edge_weight[E]。batch=1，不能隐式batch不同N。监督标签来自完整2000帧，不与单个256帧窗口标签混同。训练每设计每epoch随机抽一个连续窗，各设计等权更新。

q=(aligned_position−original_design)/(1nm)，转到设计a1/a3正交局部框架。整体properKabsch，沿用旧参考和排除规则；这不证明平衡，也不是边局部力学坐标。归一化只用69训练结构的全2000帧均值/协方差充分统计，每设计等权；固定3分量q均值/标准差，不做每节点标准差归一化。固定帧间隔10000steps、dt.005，即50模拟单位；W=256是物理采样轴，k是500步噪声轴。

## 实际配置

config.json是运行配置：W256、DDPM500、DDIM100、cosine beta、3levels各64channels（multipliers=[1,1,1]）、TAG K2、gamma=[1,2,2]、learned selector v3/FiLM、TemporalMixer开启、kernel3、每块dilation[1,16]、2层bottleneck、BF16。7个GNN块各2个mixer的最长时间感受野为239帧（非因果、边界有padding），未使用全时间注意力。clip_denoised=false、revin=false。

原尝试multipliers=[1,2,4]即64/128/256：全精度6176节点OOM；优化+BF16在6176真实256帧完成一次更新但峰值45.73GB；9996节点仍OOM。实际64/64/64版本在9996节点合成256帧显存门通过，峰值34.45GB。所有失败/成功gate保留，不把合成显存门当训练结果。实际实现的BF16空间sparse.mm局部转FP32保证CUDA支持。

## 上游必要适配

- 默认legacy学习selector无法接收当前4D条件张量；改用上游已有v3 selector +FiLM。
- 上游normalized StridedTAGConv展开时间复制的边和E×T×F邻居张量，真实尺寸OOM。efficient_graph.py使用上游相同A^gamma构造和gcn_norm，再按单图sparse.mm作用于所有时间片，避免显式邻居展开。
- 此处还修正原4D路径`(T,2,E).reshape(2,T*E)`会混合源/目标轴的问题；以原层逐帧T=1的数学行为为参考，而非保持这个错误。gamma1/2/4前向和输入梯度均有对照。
- max-neighborhood pooling在大E×T×F张量上触发torch_scatter illegal memory access；时间分块16帧保持每帧运算，对照测试通过。
- encoder/decoder/bottleneck块启用nonreentrant activation checkpoint，避免保存全部中间激活。

## 损失

LD=mean((epsilon_hat−epsilon)^2)。LS=RMSE(P50)/s50+.3/3*(normalizedMSE(mu)+normalizedMSE(C)+normalizedMSE(P))。总损失LD+.1LS+1*selector_aux。所有尺度训练集固定、任务级；协方差单一尺度保持方向相对幅度。两项均反传共享条件encoder，测试检查非零梯度。

upstream DDPM.training_loss默认自动加selector项；本适配器显式复用DDPM.add_noise和原噪声MSE，并单独提取selector辅助量，避免重复计入正则，保留独立xi开关。DDIM直接复用原采样器。

## 使用

隔离环境`.venv-dna-cgdm`：Python3.11.12、torch2.5.1+cu124、PyG2.5.2；原ebd/SaProt环境未改。environment.lock.txt记录实际安装。

```bash
# 功能测试
PYTHONNOUSERSITE=1 .venv-dna-cgdm/bin/python -m unittest discover -s tests/dna_cgdm -v
# 读取全部真实轨迹并建立float32 mmap缓存，4CPU，校验SHA/时间/全部标签
PYTHONNOUSERSITE=1 .venv-dna-cgdm/bin/python -m dna_cgdm.prepare --cache outputs/dna_cgdm_20261104/cache --workers 4
# 静态设计、完整轨迹监督统计和训练专属归一化
PYTHONNOUSERSITE=1 .venv-dna-cgdm/bin/python -m dna_cgdm.bootstrap --output outputs/dna_cgdm_20261104/static --cache outputs/dna_cgdm_20261104/cache
# D联合训练，默认120epochs；C纯生成将eta置0；B条件UGNN+监督
PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True PYTHONNOUSERSITE=1 .venv-dna-cgdm/bin/python -m dna_cgdm.train --static outputs/dna_cgdm_20261104/static --out outputs/my_joint_run --epochs 120 --arm D
# 推理：输入NPZ只有原始设计特征x和图，不需要MD
PYTHONNOUSERSITE=1 .venv-dna-cgdm/bin/python -m dna_cgdm.sample --checkpoint outputs/my_joint_run/best.pt --design-input outputs/dna_cgdm_20261104/static/6hb_001.npz --output outputs/my_samples --samples 4
```

准备阶段重新读取原始MD约数百GB；新float32位置窗口缓存85项合计约17.6GB，并非复制全部15列MD。缓存receipt检查每设计2000帧SHA/参考SHA，和旧完整mu/C/P对照（float32容差）。每项完成后发布，partial文件不自动重用。resume对已完成cache核SHA。

## 实验边界

A是既有GPR多任务结果，不改旧产物。B为condition-only U-GNN decoder隐藏特征映射回128维，再共用监督头。C不训练监督头，必须用生成统计评估，checkpoint固定取末轮；不能把其监督头误差当C性能。D为当前联合训练主线。B/C提供执行入口，尚未跑完整对照；不承诺四臂已比较。

默认69train/16历史开发validation，test=[]；原验证已反复开发使用，没有声称独立测试。窗口不跨设计划分。尚无可靠母结构/家族组清单，用户建议的全新按设计测试需另建冻结split并重跑所有臂，当前不能作新设计泛化结论。

联合训练controller run_campaign.py等待全部85缓存校验及最大图门通过后自动启动D120epochs。状态outputs/dna_cgdm_20261104/campaign_status.json，训练日志training_D.log；各epochcheckpoint与指标保存joint_D_seed11/。使用旧开发验证P50选best；结束独立复算保存预测。每个验证设计从同一批4个生成窗计算mu/C/P，监督分支结果另报，不强制两分支数值一致。

生成评估工具evaluate_generated.py提供muMAE、CFrobenius、P各窗RMSE、ACF、固定节点对相关、CRPS、90%覆盖率。所有时间窗不跨独立生成样本边界。完整有限窗统计与原2000帧统计有估计尺度差异，必须分别报告。4个样本不足以建立可靠尾部覆盖。

输出是位移窗口，不包含a1/a3旋转轨迹；不能称完整oxDNA刚体轨迹或可直接继续MD。第一版尚未把Rij局部框架输运加入边消息，方向与跨节点相关误差需单独检查。采样仅代表条件随机运动窗口，不是连续MD动力学求解器。物理约束、家族独立测试、配对加固DeltaJ验证均未完成。
