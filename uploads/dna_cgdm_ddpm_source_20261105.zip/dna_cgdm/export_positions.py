"""Diagnostic oxDNA position export with explicitly unchanged template orientations.

This is visualizable geometry, NOT a validated MD continuation or generated
rigid-body trajectory: nucleotide rotations are not predicted by this model.
"""
import argparse,json
from pathlib import Path
import numpy as np
from .datasets import local_frames,NM


def main():
 p=argparse.ArgumentParser();p.add_argument('--samples',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--topology',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--sample',type=int,default=0);p.add_argument('--frame',type=int,default=0);a=p.parse_args()
 if a.output.exists():raise FileExistsError('output exists')
 samples=np.load(a.samples,mmap_mode='r');q=np.asarray(samples[a.sample,a.frame],dtype=float);reference=np.loadtxt(a.reference,skiprows=3);count=int(a.topology.open().readline().split()[0])
 if q.shape!=(count,3) or reference.shape!=(count,15) or not np.isfinite(q).all():raise ValueError('topology/reference/sample mismatch')
 frames=local_frames(reference);reference[:,:3]+=np.einsum('ni,nji->nj',q,frames)/NM
 # Reuse normalized original orientations, not model-predicted rotations.
 reference[:,3:6]=frames[:,:,0];reference[:,6:9]=frames[:,:,2];reference[:,9:]=0
 extent=np.ptp(reference[:,:3],axis=0);box=np.maximum(extent+20,20);reference[:,:3]-=reference[:,:3].mean(0)
 with a.output.open('w') as f:
  f.write('t = 0\nb = '+' '.join(map(str,box))+'\nE = 0 0 0\n');np.savetxt(f,reference,fmt='%.10g')
 np.testing.assert_allclose(np.linalg.norm(reference[:,3:6],axis=1),1,atol=1e-7);np.testing.assert_allclose(np.linalg.norm(reference[:,6:9],axis=1),1,atol=1e-7)
 a.output.with_suffix(a.output.suffix+'.json').write_text(json.dumps(dict(nodes=count,sample=a.sample,frame=a.frame,position_model='local displacement',orientation_model='unchanged design template',validated_for_md=False),indent=2)+'\n')
if __name__=='__main__':main()
