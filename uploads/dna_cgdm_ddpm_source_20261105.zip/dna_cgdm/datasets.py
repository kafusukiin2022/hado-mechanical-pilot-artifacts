"""Batch-one displacement windows, split-locked normalization and cache builder.

No model or training starts at import time. Only explicit cache preparation reads MD.
"""
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np

NM = .8518


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4*1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def local_frames(reference):
    a1 = np.array(reference[:, 3:6], dtype=float)
    a3 = np.array(reference[:, 6:9], dtype=float)
    norm = np.linalg.norm(a1, axis=1)
    if np.any(norm < 1e-10):
        raise ValueError('degenerate a1')
    a1 /= norm[:, None]
    a3 -= (a1*a3).sum(1)[:, None]*a1
    norm = np.linalg.norm(a3, axis=1)
    if np.any(norm < 1e-10):
        raise ValueError('degenerate a3')
    a3 /= norm[:, None]
    return np.stack((a1, np.cross(a3, a1), a3), axis=-1)


def local_displacement(positions, centered_reference_nm, frames):
    x = np.asarray(positions, dtype=float)*NM
    x -= x.mean(0)
    u, _, vt = np.linalg.svd(x.T@centered_reference_nm)
    u[:, -1] *= np.linalg.det(u@vt)
    q = x@(u@vt)-centered_reference_nm
    return np.einsum('ni,nij->nj', q, frames)


def prepare_cache(project, design, cache):
    """Stream/hash every frame; publish cache only after historical gates pass."""
    from .dna_metrics import trajectory_statistics
    project, cache = Path(project), Path(cache)
    source = project/'experiments/talos97_rmsf_scalar/continuation20m_20261102/labels'/design
    qc = json.loads((source/'qc.json').read_text())
    included = json.loads((project/'outputs/talos97_directional_persistence_20261104/protocol.json').read_text())['included']
    if design not in included:
        raise ValueError('outside strict QC cohort')
    refpath = Path(qc['reference'])
    if sha256(refpath) != qc['reference_sha256']:
        raise ValueError('reference hash changed')
    refraw = np.loadtxt(refpath, skiprows=3)
    frames = local_frames(refraw)
    reference = (refraw[:, :3]-refraw[:, :3].mean(0))*NM
    n = len(reference)
    cache.mkdir(parents=True, exist_ok=True)
    final = cache/(design+'.npy')
    receipt = cache/(design+'.json')
    if final.exists() or receipt.exists():
        raise FileExistsError('refuse to overwrite existing cache')
    temporary = cache/(design+'.partial.npy')
    if temporary.exists():
        raise FileExistsError('incomplete attempt exists; inspect before retry')
    output = np.lib.format.open_memmap(temporary, mode='w+', dtype='float32', shape=(2000, n, 3))
    digest = hashlib.sha256()
    try:
        with Path(qc['trajectory']).open('rb') as stream:
            for t in range(2000):
                header = [stream.readline() for _ in range(3)]
                if not all(h.startswith(k) for h, k in zip(header, (b't =', b'b =', b'E ='))):
                    raise ValueError('invalid frame headers')
                if int(float(header[0].split(b'=')[1])) != 5010000+t*10000:
                    raise ValueError('nonuniform or incorrect frame time')
                block = b''.join(stream.readline() for _ in range(n))
                digest.update(b''.join(header)); digest.update(block)
                raw = np.fromstring(block.decode('ascii'), sep=' ')
                if raw.size != n*15 or not np.isfinite(raw).all():
                    raise ValueError('invalid nucleotide rows')
                output[t] = local_displacement(raw.reshape(n, 15)[:, :3], reference, frames)
            if stream.read().strip():
                raise ValueError('unexpected trailing frames')
        output.flush()
        if digest.hexdigest() != qc['trajectory_sha256']:
            raise ValueError('trajectory hash changed')
        # Avoid materializing full (T,N,3) float64 trajectory for validation.
        historical = project/'outputs/talos97_directional_persistence_20261104/labels'/design/'statistics.npz'
        max_error = 0.
        with np.load(historical) as z:
            for start in range(0, n, 128):
                sl = slice(start, start+128)
                result = trajectory_statistics(output[:, sl])
                expected_mu = np.einsum('ni,nij->nj', z['mean_q'][sl], frames[sl])
                expected_cov = frames[sl].transpose(0, 2, 1)@z['covariance_q'][sl]@frames[sl]
                for actual, expected in ((result['mean'], expected_mu),
                                         (result['covariance'], expected_cov),
                                         (result['persistence'], z['persistence'][:, sl])):
                    np.testing.assert_allclose(actual, expected, rtol=2e-5, atol=2e-5)
                    max_error = max(max_error, float(abs(actual-expected).max()))
        del output
        cache_hash = sha256(temporary)
        temporary.replace(final)
        info = dict(design=design, frames=2000, nodes=n, shape=[2000, n, 3],
                    layout='W,N,3 local displacement; nm / 1nm', dtype='float32',
                    source_trajectory_sha256=digest.hexdigest(), reference_sha256=qc['reference_sha256'],
                    historical_labels_sha256=sha256(historical), cache_sha256=cache_hash,
                    historical_statistics_max_error=max_error, interval_steps=10000, dt=.005,
                    passed=True)
        receipt.write_text(json.dumps(info, indent=2)+'\n')
        return info
    except Exception:
        # Keep partial file as inspectable evidence, never silently reuse it.
        raise


def validate_split(split):
    if set(split) != {'train', 'validation', 'test'}:
        raise ValueError('explicit train/validation/test lists required; test may be empty')
    flat = sum((list(v) for v in split.values()), [])
    if len(flat) != len(set(flat)) or not split['train']:
        raise ValueError('overlapping/duplicate designs or empty training set')


def fit_normalization(records, split):
    """Equal-design moments over full trajectories, not overlapping window counts."""
    validate_split(split)
    x_means, x_seconds, q_means, q_seconds = [], [], [], []
    used = []
    for design in split['train']:
        record = records[design]
        x = np.asarray(record['x'], dtype=float)
        q = np.load(record['q_path'], mmap_mode='r')
        if not np.isfinite(x).all() or q.ndim != 3 or q.shape[1:] != (len(x), 3):
            raise ValueError('feature/trajectory mismatch')
        if not np.isfinite(q).all():
            raise ValueError('non-finite q')
        x_means.append(x.mean(0)); x_seconds.append(np.square(x).mean(0))
        mean = np.zeros(3); second = np.zeros(3); count = 0
        for start in range(0, len(q), 32):
            part = np.asarray(q[start:start+32], dtype=float)
            mean += part.sum(axis=(0, 1)); second += np.square(part).sum(axis=(0, 1))
            count += part.shape[0]*part.shape[1]
        q_means.append(mean/count); q_seconds.append(second/count)
        used.append(dict(design=design, q_sha256=sha256(record['q_path'])))
    xm = np.mean(x_means, axis=0); qm = np.mean(q_means, axis=0)
    return dict(x_mean=xm, x_std=np.maximum(np.sqrt(np.maximum(np.mean(x_seconds, axis=0)-xm*xm, 0)), .01),
                q_mean=qm, q_std=np.maximum(np.sqrt(np.maximum(np.mean(q_seconds, axis=0)-qm*qm, 0)), 1e-4),
                training_sources=used)


class DNAWindowDataset:
    """One graph per item: x[N,1,D], y[N,W,3]. No implicit mixed-N batching."""
    def __init__(self, records, split, part, normalization, window=256, stride=256):
        validate_split(split)
        if part not in split or window < 200 or stride < 1:
            raise ValueError('invalid partition/window/stride')
        self.records, self.normalization = records, normalization
        self.window = window
        self.items = []
        for design in split[part]:
            q = np.load(records[design]['q_path'], mmap_mode='r')
            if len(q) < window:
                raise ValueError('trajectory shorter than window')
            for start in range(0, len(q)-window+1, stride):
                self.items.append((design, start))

    def __len__(self):
        return len(self.items)

    def __getitem__(self, index):
        import torch
        design, start = self.items[index]
        record, norm = self.records[design], self.normalization
        q = np.array(np.load(record['q_path'], mmap_mode='r')[start:start+self.window], dtype='float32')
        q = (q-norm['q_mean'])/norm['q_std']
        x = (record['x']-norm['x_mean'])/norm['x_std']
        edge = np.asarray(record['edge_index'], dtype=np.int64)
        weight = np.asarray(record.get('edge_weight', np.ones(edge.shape[1])), dtype='float32')
        if edge.ndim != 2 or edge.shape[0] != 2 or weight.shape != (edge.shape[1],):
            raise ValueError('only scalar edge weights currently supported')
        if edge.size and (edge.min() < 0 or edge.max() >= len(x)):
            raise ValueError('invalid edge indices')
        return SimpleNamespace(x=torch.tensor(x[:, None], dtype=torch.float32),
                               y=torch.tensor(q.transpose(1, 0, 2), dtype=torch.float32),
                               edge_index=torch.tensor(edge, dtype=torch.long),
                               edge_weight=torch.tensor(weight, dtype=torch.float32),
                               design=design, start_frame=start, num_graphs=1)
