"""Evaluate generated windows against held-out real windows, without crossing samples."""
import argparse,json
from pathlib import Path
import numpy as np
from .dna_metrics import trajectory_statistics,statistical_errors,temporal_autocorrelation,pair_correlations,ensemble_crps,interval_coverage


def evaluate(samples,reference,pairs):
 samples=np.asarray(samples,dtype=float);reference=np.asarray(reference,dtype=float)
 if reference.ndim!=3 or samples.ndim!=4 or samples.shape[1:]!=reference.shape:raise ValueError('matched W,N,3 required')
 generated=trajectory_statistics(samples);target=trajectory_statistics(reference)
 metrics=statistical_errors(generated,target)
 lags=(1,10,50,100,199);ga=temporal_autocorrelation(samples,lags);ra=temporal_autocorrelation(reference,lags)
 gc=pair_correlations(samples,pairs);rc=pair_correlations(reference,pairs)
 metrics.update(acf_mae_by_lag=np.nanmean(abs(ga-ra),axis=(1,2)).tolist(),pair_correlation_mae=float(np.nanmean(abs(gc-rc))),
                coordinate_crps=float(ensemble_crps(samples,reference).mean()),marginal_90_coverage=interval_coverage(samples,reference,.9),
                caveat='Pointwise CRPS/coverage use matched window offsets; single trajectory finite-window descriptive diagnostics, not temporal dynamics validation')
 return metrics


def main():
 p=argparse.ArgumentParser();p.add_argument('--samples',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--pairs',type=Path);a=p.parse_args();s=np.load(a.samples,mmap_mode='r');r=np.load(a.reference,mmap_mode='r')
 if a.pairs:pairs=np.load(a.pairs)
 else:
  rng=np.random.default_rng(11);pairs=rng.integers(0,r.shape[1],size=(256,2));pairs=pairs[pairs[:,0]!=pairs[:,1]]
 a.output.write_text(json.dumps(evaluate(s,r,pairs),indent=2,allow_nan=False)+'\n')
if __name__=='__main__':main()
