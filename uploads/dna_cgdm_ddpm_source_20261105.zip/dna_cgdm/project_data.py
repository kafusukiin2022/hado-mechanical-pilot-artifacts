"""Adapter to immutable historical TALOS inputs; targets loaded separately."""
import importlib.util
import importlib
import sys
import json
from pathlib import Path
import numpy as np
from .datasets import local_frames, sha256

ROOT = Path(__file__).resolve().parents[1]
LEGACY = ROOT/'experiments/directional_persistence_models_20261104'


def legacy_module(name):
    namespace = '_dna_cgdm_legacy'
    if namespace not in sys.modules:
        spec = importlib.util.spec_from_file_location(namespace, LEGACY/'talos97/__init__.py',
            submodule_search_locations=[str(LEGACY/'talos97')])
        module = importlib.util.module_from_spec(spec); sys.modules[namespace] = module
        spec.loader.exec_module(module)
    return importlib.import_module(namespace+'.'+name)


def strict_split():
    meta = json.loads((LEGACY/'data/metadata.json').read_text())
    split = dict(meta['split'], test=[])
    if [len(split[k]) for k in ('train','validation','test')] != [69,16,0]:
        raise ValueError('strict split changed')
    return split


def design_record(design, cache):
    loader = legacy_module('graph_data')
    q = loader.load_graph_design(design, targets=False)
    with np.load(LEGACY/'data/inputs'/(design+'.npz')) as z:
        n = len(z['pos'])
    if n != len(q['s']): raise ValueError('input row count mismatch')
    edge = q['graph']['union'][0]
    # Binary union graph; let upstream TAGConv apply symmetric normalization.
    return dict(x=np.concatenate((q['s'],q['f']),axis=1), edge_index=edge,
                edge_weight=np.ones(edge.shape[1],dtype='float32'),
                q_path=str(Path(cache)/(design+'.npy')))


def design_labels(design):
    qc=json.loads((ROOT/'experiments/talos97_rmsf_scalar/continuation20m_20261102/labels'/design/'qc.json').read_text())
    reference=Path(qc['reference'])
    if sha256(reference)!=qc['reference_sha256']:raise ValueError('changed reference')
    frames=local_frames(np.loadtxt(reference,skiprows=3))
    with np.load(ROOT/'outputs/talos97_directional_persistence_20261104/labels'/design/'statistics.npz') as z:
        return dict(mean=np.einsum('ni,nij->nj',z['mean_q'],frames).astype('float32'),
                    covariance=(frames.transpose(0,2,1)@z['covariance_q']@frames).astype('float32'),
                    persistence=z['persistence'].T.astype('float32'))


def fit_static_and_label_scales(records, labels, split):
    """Train-only imputation and full-trajectory q moments; no cache prerequisite."""
    from .datasets import validate_split
    validate_split(split)
    median=np.nanmedian(np.concatenate([records[d]['x'] for d in split['train']]),axis=0)
    if not np.isfinite(median).all():raise ValueError('training feature median invalid')
    for q in records.values():
        q['x']=q['x'].copy();bad=~np.isfinite(q['x']);q['x'][bad]=np.broadcast_to(median,q['x'].shape)[bad]
    xs=[records[d]['x'].astype(float) for d in split['train']]
    xm=np.mean([x.mean(0) for x in xs],axis=0)
    xv=np.mean([(x*x).mean(0) for x in xs],axis=0)-xm*xm
    qm=np.mean([labels[d]['mean'].astype(float).mean(0) for d in split['train']],axis=0)
    q2=np.mean([(np.diagonal(labels[d]['covariance'].astype(float),axis1=-2,axis2=-1)+labels[d]['mean'].astype(float)**2).mean(0) for d in split['train']],axis=0)
    scales=[np.sqrt(np.mean([np.mean(labels[d]['mean'].astype(float)**2) for d in split['train']])),
            np.sqrt(np.mean([np.mean(labels[d]['covariance'].astype(float)**2) for d in split['train']]))]
    scales+=np.sqrt(np.mean([np.mean(labels[d]['persistence'].astype(float)**2,axis=0) for d in split['train']],axis=0)).tolist()
    return dict(x_mean=xm,x_std=np.maximum(np.sqrt(np.maximum(xv,0)),.01),
                q_mean=qm,q_std=np.maximum(np.sqrt(np.maximum(q2-qm*qm,0)),1e-4),
                label_scales=np.maximum(scales,1e-4),imputation_median=median,
                training_designs=split['train'])
