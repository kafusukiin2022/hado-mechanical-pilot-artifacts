"""Sparse-matrix TAG execution: preserve graph powers without T-fold edge expansion.

Uses upstream adjacency-power builder and gcn normalization on a single graph.
Temporal slices are independent in this spatial operation. This also avoids the
upstream 4-D edge replication reshape mixing source/target axes for T>1.
"""
import torch
from torch import nn
from torch.utils.checkpoint import checkpoint
from .source import enable_upstream

enable_upstream()
from graph_signal_diffusion.models.components.graph_conv import StridedTAGConv
from graph_signal_diffusion.models.components.pooling import NeighborhoodFeaturePooling


class SparseStridedTAGConv(StridedTAGConv):
    def forward(self,x,edge_index,edge_weight=None):
        if x.dim()==4:
            b,t,n,c=x.shape
            if b!=1:raise ValueError('DNA sparse adapter currently batch=1')
            state=x[0].permute(1,0,2).reshape(n,t*c)
        elif x.dim()==3:
            n,t,c=x.shape;state=x.reshape(n,t*c)
        else:raise ValueError('expected3D/4D')
        builder=self._compute_gamma_hop_adjacency_boolean if self.use_boolean_semiring else self._compute_gamma_hop_adjacency_power
        edge,weight=builder(edge_index,n,edge_weight,return_edge_weight=True)
        if self.normalize:
            from torch_geometric.nn.conv.gcn_conv import gcn_norm
            edge,weight=gcn_norm(edge,weight,num_nodes=n,add_self_loops=False)
        if weight is None:weight=state.new_ones(edge.shape[1])
        adjacency=torch.sparse_coo_tensor(edge.flip(0),weight.float(),(n,n),device=x.device).coalesce()
        out=None
        for k in range(self.K+1):
            term=self.lins[k](state.reshape(n,t,c))
            out=term if out is None else out+term
            if k<self.K:
                dtype=state.dtype
                with torch.autocast(device_type=x.device.type,enabled=False):
                    state=torch.sparse.mm(adjacency,state.float()).to(dtype)
        if self.bias is not None:out=out+self.bias
        return out.permute(1,0,2)[None] if x.dim()==4 else out


class CheckpointBlock(nn.Module):
    def __init__(self,module):super().__init__();self.module=module
    def forward(self,*args,**kwargs):
        if self.training and torch.is_grad_enabled():
            return checkpoint(self.module,*args,use_reentrant=False,**kwargs)
        return self.module(*args,**kwargs)


class ChunkedNeighborhood(nn.Module):
    def __init__(self,module,chunk=16):super().__init__();self.module=module;self.chunk=chunk
    def forward(self,x,edge_index,active_mask=None,return_adj=False):
        output=[];adj=None
        for start in range(0,x.shape[1],self.chunk):
            value,adj=self.module(x[:,start:start+self.chunk],edge_index,active_mask=active_mask,return_adj=return_adj)
            output.append(value)
        return torch.cat(output,dim=1),adj


def optimize_ugnn(model):
    def replace(parent):
        for name,child in list(parent.named_children()):
            if isinstance(child,StridedTAGConv):
                efficient=SparseStridedTAGConv(child.in_channels,child.out_channels,K=child.K,gamma=child.gamma,normalize=child.normalize,bias=child.bias is not None,use_boolean_semiring=child.use_boolean_semiring,power_mode=child.power_mode)
                efficient.load_state_dict(child.state_dict());setattr(parent,name,efficient)
            elif isinstance(child,NeighborhoodFeaturePooling):
                setattr(parent,name,ChunkedNeighborhood(child))
            else:replace(child)
    replace(model)
    for blocks in (model.encoder.encoder_blocks,model.decoder.decoder_blocks):
        for i,block in enumerate(blocks):blocks[i]=CheckpointBlock(block)
    model.bottleneck=CheckpointBlock(model.bottleneck)
    return model
