"""Use the pinned upstream checkout without changing its source files."""
import sys
import subprocess
from pathlib import Path

UPSTREAM_COMMIT = '018ac033e32105010fe2265e0bdef56db5fa74bb'
UPSTREAM = Path(__file__).resolve().parents[1]/'vendor/graph-signal-diffusion'


def enable_upstream():
    path = UPSTREAM/'src'
    if not path.is_dir():
        raise RuntimeError('clone the pinned graph-signal-diffusion repository first')
    commit = subprocess.check_output(['git', '-C', str(UPSTREAM), 'rev-parse', 'HEAD'], text=True).strip()
    if commit != UPSTREAM_COMMIT:
        raise RuntimeError('upstream commit differs from verified DNA-CGDM dependency')
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))
