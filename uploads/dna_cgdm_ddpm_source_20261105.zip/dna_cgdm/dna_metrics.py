"""Statistics of unnormalized local displacements (M,W,N,3).

Windows remain separate: no averaging window crosses independent samples.
Population covariance is taken over all M*W observations around their joint mean.
"""
import numpy as np

WINDOWS = (1, 10, 50, 100, 200)


def trajectory_statistics(q, windows=WINDOWS):
    q = np.asarray(q, dtype=np.float64)
    if q.ndim == 3:
        q = q[None]
    if q.ndim != 4 or q.shape[-1] != 3 or min(q.shape[:3]) < 1:
        raise ValueError('expected nonempty (M,W,N,3) or (W,N,3)')
    if not np.isfinite(q).all():
        raise ValueError('non-finite trajectory')
    windows = tuple(windows)
    if not windows or any(isinstance(h, bool) or not isinstance(h, (int, np.integer))
                          or h < 1 or h > q.shape[1] for h in windows):
        raise ValueError('windows must be positive integers no longer than W')
    mu = q.mean(axis=(0, 1))
    centered = q-mu
    covariance = np.einsum('mtni,mtnj->nij', centered, centered)/(q.shape[0]*q.shape[1])
    cumulative = np.concatenate((np.zeros_like(q[:, :1]), np.cumsum(q, axis=1)), axis=1)
    matrices = []
    for h in windows:
        average = (cumulative[:, h:]-cumulative[:, :-h])/h
        matrices.append(np.einsum('mtni,mtnj->nij', average, average)
                        /(average.shape[0]*average.shape[1]))
    matrices = np.stack(matrices)
    return dict(mean=mu, covariance=covariance, window_matrix=matrices,
                persistence=np.trace(matrices, axis1=-2, axis2=-1),
                windows_frames=np.asarray(windows))


def statistical_errors(predicted, target):
    if not np.array_equal(predicted['windows_frames'], target['windows_frames']):
        raise ValueError('different physical time windows')
    error = predicted['persistence']-target['persistence']
    return dict(mean_mae=float(np.abs(predicted['mean']-target['mean']).mean()),
                covariance_frobenius=float(np.linalg.norm(predicted['covariance']-
                                                         target['covariance'], axis=(-2, -1)).mean()),
                persistence_rmse=np.sqrt(np.mean(error**2, axis=1)).tolist())


def temporal_autocorrelation(q, lags=(1, 10, 50, 100, 199)):
    """Per-node/component ACF pooled within each sample, never across boundaries."""
    q = np.asarray(q, dtype=float)
    if q.ndim == 3: q = q[None]
    centered = q-q.mean(axis=(0,1))
    variance = (centered**2).mean(axis=(0,1))
    values = []
    for lag in lags:
        if lag < 1 or lag >= q.shape[1]: raise ValueError('invalid lag')
        numerator = (centered[:, :-lag]*centered[:, lag:]).mean(axis=(0,1))
        values.append(np.divide(numerator, variance, out=np.full_like(variance, np.nan), where=variance>1e-12))
    return np.stack(values)


def pair_correlations(q, pairs):
    """Trace-normalized vector correlations; pairs must be fixed before evaluation."""
    q = np.asarray(q,dtype=float)
    if q.ndim == 3: q=q[None]
    centered=q-q.mean(axis=(0,1))
    pairs=np.asarray(pairs,dtype=int)
    a,b=centered[:,:,pairs[:,0]],centered[:,:,pairs[:,1]]
    numerator=(a*b).sum(-1).mean((0,1))
    denominator=np.sqrt((a*a).sum(-1).mean((0,1))*(b*b).sum(-1).mean((0,1)))
    return np.divide(numerator,denominator,out=np.full_like(numerator,np.nan),where=denominator>1e-12)


def ensemble_crps(samples, observations):
    """Empirical scalar CRPS along leading ensemble axis, O(M log M)."""
    x=np.asarray(samples,dtype=float);y=np.asarray(observations,dtype=float)
    if x.shape[1:]!=y.shape or len(x)<2:raise ValueError('ensemble shape mismatch or M<2')
    ordered=np.sort(x,axis=0)
    coefficients=(2*np.arange(1,len(x)+1)-len(x)-1).reshape((-1,)+(1,)*y.ndim)
    return np.abs(x-y).mean(0)-(coefficients*ordered).sum(0)/(len(x)**2)


def interval_coverage(samples, observations, level=.9):
    """Pointwise marginal coverage; single finite MD trajectory is not calibration proof."""
    if not 0<level<1:raise ValueError('invalid level')
    low,high=np.quantile(samples,[(1-level)/2,(1+level)/2],axis=0)
    return float(np.mean((np.asarray(observations)>=low)&(np.asarray(observations)<=high)))
