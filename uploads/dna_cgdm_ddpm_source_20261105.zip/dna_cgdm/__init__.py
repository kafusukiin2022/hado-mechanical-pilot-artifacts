"""DNA-CGDM: design-conditioned displacement windows and their statistics."""
