"""Generate local-displacement windows for a design from checkpoint, without MD input."""
import argparse,json
from pathlib import Path
import numpy as np
import torch
from .dna_model import DNACGDM
from .dna_metrics import trajectory_statistics
from .train import tensor_design,write


def main():
 p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--design-input',type=Path,required=True,help='NPZ: x raw precomputeddesignfeatures,edge_index,edge_weight; no trajectories');p.add_argument('--output',type=Path,required=True);p.add_argument('--samples',type=int,default=4);p.add_argument('--seed',type=int,default=123);p.add_argument('--device',default='cuda:0');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);torch.manual_seed(a.seed)
 ck=torch.load(a.checkpoint,map_location=a.device,weights_only=False);norm=ck['normalization']
 with np.load(a.design_input) as z:
  x=z['x'].copy();bad=~np.isfinite(x);x[bad]=np.broadcast_to(norm['imputation_median'],x.shape)[bad]
  record=dict(x=(x-norm['x_mean'])/norm['x_std'],edge_index=z['edge_index'],edge_weight=z['edge_weight'])
 model=DNACGDM(record['x'].shape[1],norm['label_scales'],ck['config']).to(a.device);model.load_state_dict(ck['state'],strict=True);data=tensor_design(record,a.device);samples=model.sample(data,norm,samples=a.samples).cpu().numpy();np.save(a.output/'samples_local_q.npy',samples);np.savez_compressed(a.output/'generated_statistics.npz',**trajectory_statistics(samples))
 with torch.no_grad():pred=model.predict(data)
 np.savez_compressed(a.output/'supervised_statistics.npz',**{k:v.cpu().numpy() for k,v in pred.items()})
 write(a.output/'manifest.json',dict(samples=a.samples,seed=a.seed,checkpoint=str(a.checkpoint),layout='M,W,N,3 localdisplacements',limitations='Displacement windows only; no orientation dynamics or continuousMD guarantee. Supervised and generated statistics are separate estimators.'))
if __name__=='__main__':main()
