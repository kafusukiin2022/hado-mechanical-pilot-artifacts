"""Batch-one DNA-CGDM training and held-out-design evaluation.

One random contiguous physical window per train design and epoch; full-trajectory
labels guide only the static supervised branch. Generated-window statistics are
reported separately from the supervised branch.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('OMP_NUM_THREADS','2')
import argparse,json,time,traceback
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
from .dna_model import DNACGDM
from .dna_metrics import trajectory_statistics,statistical_errors
from .datasets import sha256
from .source import UPSTREAM_COMMIT


def write(path,obj):
 tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');tmp.replace(path)


def load_static(folder):
 split=json.loads((folder/'split.json').read_text())
 from .datasets import validate_split
 validate_split(split)
 with np.load(folder/'normalization.npz') as z:norm={k:z[k] for k in z.files}
 records={};labels={}
 for d in sum(split.values(),[]):
  with np.load(folder/(d+'.npz')) as z:
   records[d]=dict(x=(z['x']-norm['x_mean'])/norm['x_std'],edge_index=z['edge_index'],edge_weight=z['edge_weight'],q_path=str(z['q_path']))
   labels[d]={k:z['target_'+k] for k in ('mean','covariance','persistence')}
 return split,norm,records,labels


def tensor_design(record,device):
 return SimpleNamespace(x=torch.tensor(record['x'][:,None],dtype=torch.float32,device=device),edge_index=torch.tensor(record['edge_index'],dtype=torch.long,device=device),edge_weight=torch.tensor(record['edge_weight'],dtype=torch.float32,device=device),num_graphs=1)


def supervised_loss(pred,labels,scales):
 p50=((pred['p50']-labels['persistence'][:,2]).square().mean()+1e-8).sqrt()/scales[4]
 aux=(((pred['mean']-labels['mean'])/scales[0]).square().mean()+((pred['covariance']-labels['covariance'])/scales[1]).square().mean()+((pred['persistence']-labels['persistence'])/scales[2:]).square().mean())/3
 return p50+.3*aux


def evaluate(model,records,labels,split,device,use_ugnn=False):
 model.eval();rows=[]
 with torch.no_grad():
  for d in split['validation']:
   p=model.predict(tensor_design(records[d],device),use_ugnn=use_ugnn);p={k:v.cpu().numpy() for k,v in p.items()}
   error=p['persistence']-labels[d]['persistence']
   rows.append(dict(design=d,p50_rmse=float(np.sqrt(np.mean(error[:,2]**2))),mean_mae=float(np.abs(p['mean']-labels[d]['mean']).mean()),covariance_frobenius=float(np.linalg.norm(p['covariance']-labels[d]['covariance'],axis=(-2,-1)).mean()),persistence_rmse=np.sqrt(np.mean(error**2,axis=0)).tolist()))
 return rows


def main():
 parser=argparse.ArgumentParser();parser.add_argument('--static',type=Path,required=True);parser.add_argument('--out',type=Path,required=True);parser.add_argument('--config',type=Path,default=Path(__file__).with_name('config.json'));parser.add_argument('--epochs',type=int,default=120);parser.add_argument('--arm',choices=['B','C','D'],default='D');parser.add_argument('--device',default='cuda:0');parser.add_argument('--steps-per-epoch',type=int);parser.add_argument('--samples',type=int,default=4);a=parser.parse_args()
 if a.steps_per_epoch is not None and a.steps_per_epoch<1:raise ValueError('positive steps-per-epoch required')
 if a.epochs<1 or a.samples<2:raise ValueError('positive epochs and at least2 samples')
 a.out.mkdir(parents=True,exist_ok=False);config=json.loads(a.config.read_text());torch.set_num_threads(2);torch.manual_seed(config['seed']);rng=np.random.default_rng(config['seed'])
 split,norm,records,labels=load_static(a.static);ids=split['train'];missing=[d for d in ids if not Path(records[d]['q_path']).exists()]
 if a.arm!='B' and missing:raise RuntimeError('missing trajectory caches: '+','.join(missing))
 cache_receipts={}
 if a.arm!='B':
  for d in ids:
   path=Path(records[d]['q_path']);receipt=json.loads(path.with_suffix('.json').read_text())
   if not receipt['passed'] or sha256(path)!=receipt['cache_sha256']:raise ValueError('cache hash mismatch '+d)
   cache_receipts[d]=receipt
 model=DNACGDM(records[ids[0]]['x'].shape[1],norm['label_scales'],config).to(a.device)
 optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=0)
 source={str(p):sha256(p) for p in Path(__file__).parent.glob('*.py')}
 write(a.out/'protocol.json',dict(config=config,epochs=a.epochs,arm=a.arm,split=split,upstream_commit=UPSTREAM_COMMIT,source_hashes=source,cache_receipts=cache_receipts,normalization_sha256=sha256(a.static/'normalization.npz'),selection='fixed final epoch for pure generation C; historical validation supervised P50 RMSE for B,D; no untouched test',window_policy='one random contiguous256frame trainwindow perdesign perepoch; uniformdesign updates',eta=0 if a.arm=='C' else config['eta_supervised'],xi=config['xi_selector']))
 np.savez_compressed(a.out/'normalization.npz',**norm)
 best=float('inf');start=time.monotonic();scales=torch.tensor(norm['label_scales'],dtype=torch.float32,device=a.device)
 for epoch in range(1,a.epochs+1):
  model.train();losses=[];parts=[]
  order=rng.permutation(ids).tolist()
  if a.steps_per_epoch:order=order[:a.steps_per_epoch]
  for d in order:
   data=tensor_design(records[d],a.device);target={k:torch.tensor(v,device=a.device) for k,v in labels[d].items()};optimizer.zero_grad(set_to_none=True)
   if a.arm=='B':
    pred=model.predict(data,use_ugnn=True);loss=supervised_loss(pred,target,scales)
   else:
    q=np.load(records[d]['q_path'],mmap_mode='r');t=int(rng.integers(0,len(q)-config['window']+1));window=np.array(q[t:t+config['window']],dtype='float32');window=(window-norm['q_mean'])/norm['q_std'];data.y=torch.tensor(window.transpose(1,0,2),dtype=torch.float32,device=a.device)
    with torch.autocast(device_type='cuda',dtype=torch.bfloat16,enabled=str(a.device).startswith('cuda')):
     terms=model.loss(data,target,eta=0 if a.arm=='C' else config['eta_supervised'])
    loss=terms['total'];parts.append({k:float(v.detach()) for k,v in terms.items()})
   if not torch.isfinite(loss):raise FloatingPointError('nonfinite loss')
   loss.backward();grad=torch.nn.utils.clip_grad_norm_(model.parameters(),5.)
   if not torch.isfinite(grad):raise FloatingPointError('nonfinite gradient')
   optimizer.step();losses.append(float(loss.detach()))
   write(a.out/'status.json',dict(stage='training',epoch=epoch,completed_designs=len(losses),designs_this_epoch=len(order),last_design=d,seconds=time.monotonic()-start))
  rows=evaluate(model,records,labels,split,a.device,use_ugnn=a.arm=='B');score=float(np.mean([r['p50_rmse'] for r in rows]));row=dict(epoch=epoch,train_loss=float(np.mean(losses)),validation_p50_rmse=score,seconds=time.monotonic()-start,peak_cuda_bytes=torch.cuda.max_memory_allocated() if str(a.device).startswith('cuda') else None)
  if parts:row['loss_components']={k:float(np.mean([p[k] for p in parts])) for k in parts[0]}
  with (a.out/'history.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
  ck=dict(state=model.state_dict(),config=config,normalization=norm,epoch=epoch,score=score,optimizer=optimizer.state_dict());torch.save(ck,a.out/'last.pt')
  if score<best or a.arm=='C':best=score;torch.save(ck,a.out/'best.pt');write(a.out/'best_validation.json',rows)
  write(a.out/'status.json',dict(stage='training',best=best,**row));print(row,flush=True)
 # Pure generation arm C must be selected/evaluated by generated statistics, not its untrained head.
 model.load_state_dict(torch.load(a.out/'best.pt',map_location=a.device,weights_only=False)['state'])
 if any(sha256(Path(p))!=h for p,h in source.items()):raise RuntimeError('source changed during training')
 final_rows=evaluate(model,records,labels,split,a.device,use_ugnn=a.arm=='B')
 write(a.out/'final_validation.json',final_rows)
 predicted={}
 model.eval()
 with torch.no_grad():
  for d in sum(split.values(),[]):
   value=model.predict(tensor_design(records[d],a.device),use_ugnn=a.arm=='B')
   predicted[d]=value['p50'].cpu().numpy()
 np.savez_compressed(a.out/'supervised_p50_predictions.npz',**predicted)
 with np.load(a.out/'supervised_p50_predictions.npz') as check:
  for row in final_rows:
   actual=float(np.sqrt(np.mean((check[row['design']].astype(float)-labels[row['design']]['persistence'][:,2].astype(float))**2)))
   if abs(actual-row['p50_rmse'])>1e-5:raise ValueError('savedprediction metric mismatch')
 write(a.out/'prediction_verification.json',dict(passed=True,rows=len(final_rows),source_unchanged=True))
 write(a.out/'status.json',dict(stage='sampling',best_supervised_p50=best))
 generated=[];diagnostics=[]
 for d in ([] if a.arm=='B' else split['validation']):
  samples=model.sample(tensor_design(records[d],a.device),norm,samples=a.samples).cpu().numpy();np.save(a.out/(d+'_samples.npy'),samples)
  stats=trajectory_statistics(samples);target=dict(mean=labels[d]['mean'],covariance=labels[d]['covariance'],persistence=labels[d]['persistence'].T,windows_frames=np.array([1,10,50,100,200]));errors=statistical_errors(stats,target);generated.append(dict(design=d,**errors));np.savez_compressed(a.out/(d+'_sample_statistics.npz'),**stats)
  # Fixed spatial subsample bounds CPU memory; never join independent windows.
  from .evaluate_generated import evaluate as evaluate_windows
  nodes=np.linspace(0,samples.shape[2]-1,min(256,samples.shape[2]),dtype=int)
  real=np.load(records[d]['q_path'],mmap_mode='r')[:config['window'],nodes,:]
  pairs=np.column_stack((np.arange(len(nodes)-1),np.arange(1,len(nodes))))
  diagnostic=evaluate_windows(samples[:,:,nodes,:],real,pairs)
  diagnostics.append(dict(design=d,nodes=nodes.tolist(),reference_window_start=0,coordinate_frame='node-local; pair correlations are component correlations, not transported physical vector correlations',**diagnostic))
  write(a.out/'generated_window_diagnostics.json',diagnostics)
 write(a.out/'generated_evaluation.json',generated);write(a.out/'status.json',dict(stage='complete',best_supervised_p50=best,seconds=time.monotonic()-start))
if __name__=='__main__':
 try:main()
 except Exception as exc:
  # CLI output path may not yet exist; traceback remains in launcher log.
  traceback.print_exc();raise
