"""Build static records and train-only normalization without reading new MD."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('OMP_NUM_THREADS','2')
import argparse,json,traceback
from pathlib import Path
import numpy as np
from .project_data import strict_split,design_record,design_labels,fit_static_and_label_scales
from .datasets import sha256


def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--cache',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 split=strict_split();records={};labels={};hashes={}
 for i,d in enumerate(sum(split.values(),[])):
  records[d]=design_record(d,a.cache);labels[d]=design_labels(d)
  for kind in ('inputs','mapping','modal'):
   suffix='.json' if kind=='mapping' else '.npz'
   source=Path(__file__).resolve().parents[1]/'experiments/directional_persistence_models_20261104/data'/kind/(d+suffix);hashes[str(source)]=sha256(source)
  lp=Path(__file__).resolve().parents[1]/'outputs/talos97_directional_persistence_20261104/labels'/d/'statistics.npz';hashes[str(lp)]=sha256(lp)
  if i%10==0:print('STATIC',i+1,flush=True)
 norm=fit_static_and_label_scales(records,labels,split)
 for d in records:
  np.savez_compressed(a.output/(d+'.npz'),**records[d],**{'target_'+k:v for k,v in labels[d].items()})
 np.savez_compressed(a.output/'normalization.npz',**norm)
 (a.output/'split.json').write_text(json.dumps(split,indent=2)+'\n');(a.output/'source_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(a.output/'status.json').write_text(json.dumps(dict(stage='complete',designs=len(records),train=len(split['train']),validation=len(split['validation']),test=0),indent=2)+'\n')
 print('STATIC_COMPLETE',flush=True)
if __name__=='__main__':main()
