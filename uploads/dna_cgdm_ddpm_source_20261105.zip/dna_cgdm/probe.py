"""Bounded full-size memory/gradient gate, distinct from a training result."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('OMP_NUM_THREADS','2')
import argparse,json,time,traceback
from pathlib import Path
import numpy as np
import torch
from .dna_model import DNACGDM
from .train import load_static,tensor_design,write


def main():
 p=argparse.ArgumentParser();p.add_argument('--static',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--config',type=Path,default=Path(__file__).with_name('config.json'));p.add_argument('--design',default='6hb_001');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 torch.set_num_threads(2);torch.manual_seed(11);split,norm,records,labels=load_static(a.static);config=json.loads(a.config.read_text());d=a.design;device='cuda:0';start=time.monotonic();model=DNACGDM(records[d]['x'].shape[1],norm['label_scales'],config).to(device);data=tensor_design(records[d],device);path=Path(records[d]['q_path'])
 if path.exists():
  q=np.array(np.load(path,mmap_mode='r')[:config['window']],dtype='float32');data.y=torch.tensor(((q-norm['q_mean'])/norm['q_std']).transpose(1,0,2),device=device,dtype=torch.float32);source='real256framewindow'
 else:data.y=torch.randn(len(data.x),config['window'],3,device=device);source='synthetic_normalized_target_memory_gate_only'
 target={k:torch.tensor(v,device=device) for k,v in labels[d].items()};optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4);torch.cuda.reset_peak_memory_stats()
 try:
  with torch.autocast(device_type='cuda',dtype=torch.bfloat16):
   terms=model.loss(data,target)
  terms['total'].backward();grad=torch.nn.utils.clip_grad_norm_(model.parameters(),5.);assert torch.isfinite(grad);assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None);optimizer.step();torch.cuda.synchronize()
  write(a.out/'gate.json',dict(passed=True,design=d,nodes=len(data.x),window=config['window'],source=source,loss={k:float(v.detach()) for k,v in terms.items()},peak_allocated_bytes=torch.cuda.max_memory_allocated(),peak_reserved_bytes=torch.cuda.max_memory_reserved(),seconds=time.monotonic()-start))
  print('FULL_GATE_PASS',flush=True)
 except Exception as exc:
  write(a.out/'gate.json',dict(passed=False,design=d,nodes=len(data.x),window=config['window'],source=source,error=repr(exc),traceback=traceback.format_exc(),peak_allocated_bytes=torch.cuda.max_memory_allocated(),seconds=time.monotonic()-start));raise
if __name__=='__main__':main()
