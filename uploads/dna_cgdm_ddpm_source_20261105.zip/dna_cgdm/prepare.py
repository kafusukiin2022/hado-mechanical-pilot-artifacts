"""Prepare strict85 caches with restart-safe per-design receipts."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,json,time,traceback
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
from .datasets import prepare_cache,sha256


def main():
 p=argparse.ArgumentParser();p.add_argument('--project',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--cache',type=Path,required=True);p.add_argument('--design');p.add_argument('--workers',type=int,default=4);a=p.parse_args();a.cache.mkdir(parents=True,exist_ok=True)
 ids=json.loads((a.project/'outputs/talos97_directional_persistence_20261104/protocol.json').read_text())['included'];ids=[a.design] if a.design else ids
 rows=[];todo=[]
 for d in ids:
  receipt=a.cache/(d+'.json');cache=a.cache/(d+'.npy')
  if receipt.exists() and cache.exists():
   r=json.loads(receipt.read_text());assert r['passed'] and sha256(cache)==r['cache_sha256'];rows.append(r)
  else:todo.append(d)
 start=time.monotonic()
 with ProcessPoolExecutor(max_workers=a.workers) as pool:
  pending={pool.submit(prepare_cache,a.project,d,a.cache):d for d in todo}
  for future in as_completed(pending):
   try:rows.append(future.result())
   except Exception as exc:
    (a.cache/'failure.json').write_text(json.dumps(dict(design=pending[future],error=repr(exc),traceback=traceback.format_exc()),indent=2));raise
   (a.cache/'status.json').write_text(json.dumps(dict(stage='complete' if len(rows)==len(ids) else 'running',completed=len(rows),requested=len(ids),seconds=time.monotonic()-start),indent=2));print('DONE',pending[future],len(rows),'/',len(ids),flush=True)
 (a.cache/'manifest.json').write_text(json.dumps(sorted(rows,key=lambda r:r['design']),indent=2)+'\n')
if __name__=='__main__':main()
