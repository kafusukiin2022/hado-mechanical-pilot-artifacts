"""Real-design joint update + conditional DDIM + checkpoint replay gate."""
import argparse,json,time
from pathlib import Path
import numpy as np
import torch
from .dna_model import DNACGDM
from .train import load_static,tensor_design,write
from .dna_metrics import trajectory_statistics


def main():
 p=argparse.ArgumentParser();p.add_argument('--static',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False);torch.set_num_threads(2);torch.manual_seed(11);config=json.loads(Path(__file__).with_name('config.json').read_text());split,norm,records,labels=load_static(a.static);d='6hb_001';record=records[d];model=DNACGDM(record['x'].shape[1],norm['label_scales'],config).cuda();data=tensor_design(record,'cuda:0');q=np.array(np.load(record['q_path'],mmap_mode='r')[:256],dtype='float32');data.y=torch.tensor(((q-norm['q_mean'])/norm['q_std']).transpose(1,0,2),device='cuda:0',dtype=torch.float32);target={k:torch.tensor(v,device='cuda:0') for k,v in labels[d].items()};optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4);start=time.monotonic()
 with torch.autocast(device_type='cuda',dtype=torch.bfloat16):terms=model.loss(data,target)
 terms['total'].backward();normgrad=torch.nn.utils.clip_grad_norm_(model.parameters(),5.);assert torch.isfinite(normgrad);optimizer.step();optimizer.zero_grad(set_to_none=True);del terms
 model.eval();del data.y
 with torch.no_grad():baseline=model.predict(data)['p50'].cpu()
 ck=dict(state=model.state_dict(),config=config,normalization=norm,epoch=0,interpretation='oneupdate smoke only, not trained result');torch.save(ck,a.out/'smoke.pt');loaded=torch.load(a.out/'smoke.pt',map_location='cuda:0',weights_only=False);model.load_state_dict(loaded['state'],strict=True)
 with torch.no_grad():torch.testing.assert_close(model.predict(data)['p50'].cpu(),baseline)
 samples=model.sample(data,norm,samples=2,steps=3).cpu().numpy();assert samples.shape==(2,256,len(data.x),3) and np.isfinite(samples).all();statistics=trajectory_statistics(samples);np.save(a.out/'samples.npy',samples);np.savez_compressed(a.out/'statistics.npz',**statistics);write(a.out/'verification.json',dict(passed=True,design=d,realwindow=True,nodes=len(data.x),window=256,ddim_steps=3,samples=2,source='original upstreamUGNN DDPM DDIM with documented sparseadapter',checkpoint_replay=True,inference_no_targets=True,seconds=time.monotonic()-start,not_quality_evidence=True))
if __name__=='__main__':main()
