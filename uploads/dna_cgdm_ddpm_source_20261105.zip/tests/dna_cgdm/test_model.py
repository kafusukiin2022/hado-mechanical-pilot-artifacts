import json
from pathlib import Path
from types import SimpleNamespace
import unittest
import numpy as np
import torch
from dna_cgdm.dna_model import DNACGDM

def fixture():
 config=json.loads(Path('dna_cgdm/config.json').read_text());config.update(channels=8,condition_width=16,channel_multipliers=[1,2,4],diffusion_steps=12,ddim_steps=3)
 n=12;edge=torch.stack([torch.arange(n),torch.roll(torch.arange(n),1)]);edge=torch.cat([edge,edge.flip(0)],1)
 data=SimpleNamespace(x=torch.randn(n,1,6),y=torch.randn(n,256,3),edge_index=edge,edge_weight=torch.ones(edge.shape[1]),num_graphs=1)
 labels=dict(mean=torch.zeros(n,3),covariance=torch.eye(3).expand(n,3,3),persistence=torch.ones(n,5))
 return config,data,labels

class ModelTests(unittest.TestCase):
 def setUp(self):torch.set_num_threads(2);torch.manual_seed(4)
 def test_joint_gradients_and_consistency(self):
  config,data,labels=fixture();model=DNACGDM(6,np.ones(7),config)
  terms=model.loss(data,labels)
  for key in ('diffusion','supervised'):
   model.zero_grad();terms[key].backward(retain_graph=True)
   norm=sum(float(p.grad.square().sum()) for p in model.condition_encoder.parameters() if p.grad is not None)
   self.assertGreater(norm,0)
  model.zero_grad();terms['total'].backward()
  self.assertTrue(all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None))
  prediction=model.predict(data);self.assertTrue(torch.equal(prediction['p50'],prediction['persistence'][:,2]))
  self.assertGreaterEqual(float(torch.linalg.eigvalsh(prediction['covariance']).min()),-1e-6)
 def test_sample_without_targets(self):
  config,data,_=fixture();del data.y;model=DNACGDM(6,np.ones(7),config)
  q=model.sample(data,dict(q_mean=[0,0,0],q_std=[1,1,1]),samples=2,steps=3)
  self.assertEqual(tuple(q.shape),(2,256,12,3));self.assertTrue(torch.isfinite(q).all())
  self.assertGreater(float((q[0]-q[1]).abs().mean()),0)
 def test_supervised_ugnn_path(self):
  config,data,_=fixture();del data.y;model=DNACGDM(6,np.ones(7),config)
  prediction=model.predict(data,use_ugnn=True);prediction['p50'].sum().backward()
  self.assertTrue(any(p.grad is not None and p.grad.abs().sum()>0 for p in model.denoiser.parameters()))
 def test_forward_noise_formula(self):
  config,data,_=fixture();model=DNACGDM(6,np.ones(7),config);x=torch.randn(1,256,12,3);noise=torch.randn_like(x);k=torch.tensor([4]);a=model.diffusion.alphas_cumprod[k]
  torch.testing.assert_close(model.diffusion.add_noise(x,k,noise),a.sqrt()*x+(1-a).sqrt()*noise)
if __name__=='__main__':unittest.main()
