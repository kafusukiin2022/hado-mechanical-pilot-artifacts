import unittest
import torch
from dna_cgdm.efficient_graph import SparseStridedTAGConv,StridedTAGConv,ChunkedNeighborhood,NeighborhoodFeaturePooling

class SparseTests(unittest.TestCase):
 def test_temporal_slice_reference_and_gradient(self):
  torch.manual_seed(5);torch.set_num_threads(2)
  for gamma in (1,2,4):
   original=StridedTAGConv(3,4,gamma=gamma,K=2,normalize=True)
   adapted=SparseStridedTAGConv(3,4,gamma=gamma,K=2,normalize=True);adapted.load_state_dict(original.state_dict())
   edge=torch.tensor([[0,1,1,2,2,3,3,0],[1,0,2,1,3,2,0,3]]);weight=torch.ones(edge.shape[1]);x=torch.randn(1,5,4,3,requires_grad=True)
   expected=torch.cat([original(x[:,t:t+1],edge,weight) for t in range(5)],dim=1)
   actual=adapted(x,edge,weight);torch.testing.assert_close(actual,expected,rtol=1e-5,atol=1e-6)
   eg=torch.autograd.grad(expected.square().sum(),x,retain_graph=True)[0];ag=torch.autograd.grad(actual.square().sum(),x)[0];torch.testing.assert_close(eg,ag,rtol=1e-5,atol=1e-5)
 def test_chunked_pool_and_gradient(self):
  torch.manual_seed(9);pool=NeighborhoodFeaturePooling(K=1,stride=1,aggregation='max',include_self=True)
  edge=torch.tensor([[0,1,1,2],[1,0,2,1]]);x=torch.randn(1,35,3,2,requires_grad=True)
  a=pool(x,edge)[0];b=ChunkedNeighborhood(pool,chunk=4)(x,edge)[0]
  torch.testing.assert_close(a,b);ga=torch.autograd.grad(a.sum(),x,retain_graph=True)[0];gb=torch.autograd.grad(b.sum(),x)[0];torch.testing.assert_close(ga,gb)
if __name__=='__main__':unittest.main()
