import unittest
import numpy as np
from dna_cgdm.dna_metrics import ensemble_crps,interval_coverage,temporal_autocorrelation,pair_correlations
class CalibrationTests(unittest.TestCase):
 def test_crps(self):
  x=np.array([[0.,1],[2,3],[4,5]]);y=np.array([2.,2.])
  direct=np.abs(x-y).mean(0)-.5*np.abs(x[:,None]-x[None,:]).mean((0,1))
  np.testing.assert_allclose(ensemble_crps(x,y),direct)
  self.assertEqual(interval_coverage(x,y),1.)
 def test_correlations(self):
  rng=np.random.RandomState(5);q=rng.randn(2,256,3,3);q[:,:,1]=q[:,:,0]
  self.assertAlmostEqual(pair_correlations(q,[[0,1]])[0],1.)
  self.assertEqual(temporal_autocorrelation(q).shape,(5,3,3))
if __name__=='__main__':unittest.main()
