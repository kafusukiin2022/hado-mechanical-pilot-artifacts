import tempfile
import unittest
from pathlib import Path
import numpy as np
from dna_cgdm.datasets import local_frames, local_displacement, fit_normalization, DNAWindowDataset, NM
from dna_cgdm.dna_metrics import trajectory_statistics

class DataTests(unittest.TestCase):
 def test_direct_windows_and_separate_samples(self):
  rng=np.random.RandomState(3);q=rng.randn(2,256,5,3);q[1]+=3
  result=trajectory_statistics(q)
  for j,h in enumerate(result['windows_frames']):
   averages=np.stack([q[:,t:t+h].mean(1) for t in range(257-h)],axis=1)
   np.testing.assert_allclose(result['persistence'][j],(averages**2).sum(-1).mean((0,1)),atol=1e-12)
  np.testing.assert_allclose(result['covariance'],np.stack([np.cov(q[:,:,i].reshape(-1,3).T,bias=True) for i in range(5)]))
 def test_rigid_gauge(self):
  rng=np.random.RandomState(4);ref=rng.randn(10,15);ref[:,3:6]=[1,0,0];ref[:,6:9]=[0,0,1];frame=local_frames(ref);center=(ref[:,:3]-ref[:,:3].mean(0))*NM
  rot=np.array([[0,-1.,0],[1,0,0],[0,0,1]])
  q=local_displacement(ref[:,:3]@rot+18,center,frame)
  np.testing.assert_allclose(q,0,atol=1e-12)
 def test_train_only_normalization_and_interface(self):
  with tempfile.TemporaryDirectory() as folder:
   records={}
   for name,val in [('a',1),('b',999)]:
    p=Path(folder)/(name+'.npy');q=np.full((256,4,3),val,dtype='float32');np.save(p,q);records[name]=dict(x=np.full((4,2),val),q_path=p,edge_index=np.array([[0,1],[1,0]]))
   split=dict(train=['a'],validation=['b'],test=[]);norm=fit_normalization(records,split)
   np.testing.assert_allclose(norm['q_mean'],1);np.testing.assert_allclose(norm['x_mean'],1)
   item=DNAWindowDataset(records,split,'validation',norm)[0]
   self.assertEqual(tuple(item.x.shape),(4,1,2));self.assertEqual(tuple(item.y.shape),(4,256,3))
   with self.assertRaises(ValueError):fit_normalization(records,dict(train=['a'],validation=['a'],test=[]))
if __name__=='__main__':unittest.main()
