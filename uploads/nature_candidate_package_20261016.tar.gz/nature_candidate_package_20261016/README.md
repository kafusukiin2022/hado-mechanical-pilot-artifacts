# Nature candidate package

This archive contains the Nature-style manuscript candidate, source data, deterministic analysis code, main figure, experiment protocol, evidence catalog, reviewer audit, cover letter and evidence report.

The full trajectory viewer (`stable_10_full_trajectories.html`) is intentionally excluded because it is approximately 705 MB and exceeds GitHub's single-file limit. It remains in the project workspace and is referenced by the evidence index.
