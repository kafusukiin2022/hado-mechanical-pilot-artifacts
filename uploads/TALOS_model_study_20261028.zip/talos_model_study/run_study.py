"""Run fixed-protocol pilot. Test scores are computed only after model selection.

python run_study.py --data ../data/talos97_subset20 --epochs 60 --seeds 11 22 33
"""
import argparse, csv, hashlib, json, platform, time
from pathlib import Path
import numpy as np
import torch
from model import BasisNet, load_inputs, NM


def rms(delta, y):
    return float((delta-y).square().sum(-1).mean().sqrt())


def evaluate(model, data, ids):
    with torch.no_grad():
        return {d: rms(model(*data[d][:3]), data[d][3]) for d in ids}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', required=True)
    ap.add_argument('--epochs', type=int, default=60)
    ap.add_argument('--seeds', nargs='+', type=int, default=[11,22,33])
    ap.add_argument('--variants', nargs='+', default=['frame','vector','gate','no_multiscale','raw'])
    args = ap.parse_args()
    torch.set_num_threads(2)
    root = Path(args.data); out = Path('results'); out.mkdir(exist_ok=True)
    Path('checkpoints').mkdir(exist_ok=True)
    split = json.loads((root / 'split.json').read_text())
    assert not (set(split['train']) & (set(split['validation']) | set(split['test'])))
    assert not (set(split['validation']) & set(split['test']))
    # Cache source-only features. Labels may be loaded here but are not read by geometry().
    data = {}; local = {}
    for ids in split.values():
        for d in ids:
            s,B,R = load_inputs(root,d)
            a = np.load(root/'inputs'/f'{d}.npz')
            y = (np.load(root/'labels'/f'{d}.npz')['target_pos']-a['pos']) * NM
            data[d] = tuple(torch.tensor(z) for z in [s,B,R,y])
            sn,Bn,_ = load_inputs(root,d,False)
            local[d] = (torch.tensor(sn),torch.tensor(Bn),data[d][2],data[d][3])
    # Uniform DESIGN weighting for normalization and training objective.
    mean = torch.stack([data[d][0].mean(0) for d in split['train']]).mean(0)
    second = torch.stack([data[d][0].square().mean(0) for d in split['train']]).mean(0)
    std = (second-mean.square()).clamp_min(0).sqrt().clamp_min(.01)
    nm = torch.stack([local[d][0].mean(0) for d in split['train']]).mean(0)
    ns = (torch.stack([local[d][0].square().mean(0) for d in split['train']]).mean(0)-nm.square()).clamp_min(0).sqrt().clamp_min(.01)
    metadata = dict(protocol=vars(args), torch=torch.__version__, python=platform.python_version(),
                    cuda=torch.cuda.is_available(), threads=2, split=split,
                    code_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('.').glob('*.py')})
    (out/'protocol.json').write_text(json.dumps(metadata,indent=2))
    records=[]; histories=[]; predictions={}; runs=[]
    for variant in args.variants:
        ds = local if variant == 'no_multiscale' else data
        mu, sig = (nm,ns) if variant == 'no_multiscale' else (mean,std)
        for seed in args.seeds:
            torch.manual_seed(seed); rng=np.random.default_rng(seed)
            model=BasisNet(mu,sig,k=ds[split['train'][0]][1].shape[1],variant=variant)
            opt=torch.optim.AdamW(model.parameters(),lr=1e-3,weight_decay=1e-4)
            best=float('inf'); best_epoch=0; state=None; start=time.time()
            path=Path('checkpoints')/f'{variant}_{seed}.pt'
            for epoch in range(1,args.epochs+1):
                model.train(); losses=[]; updates=[]; grads=[]
                # Full graphs, full-node loss; one graph = one optimizer step.
                for d in rng.permutation(split['train']):
                    s,B,R,y=ds[d]
                    opt.zero_grad(set_to_none=True)
                    pred=model(s,B,R);loss=(pred-y).square().mean()
                    loss.backward()
                    gn=torch.nn.utils.clip_grad_norm_(model.parameters(),5.)
                    old=torch.cat([p.detach().flatten() for p in model.parameters()]).clone()
                    opt.step()
                    new=torch.cat([p.detach().flatten() for p in model.parameters()])
                    updates.append(float((new-old).norm()/(old.norm()+1e-12)))
                    grads.append(float(gn));losses.append(float(loss.detach()))
                model.eval(); val=evaluate(model,ds,split['validation']);score=float(np.mean(list(val.values())))
                if score<best:
                    best,best_epoch=score,epoch
                    state={k:v.detach().clone() for k,v in model.state_dict().items()}
                histories.append(dict(variant=variant,seed=seed,epoch=epoch,train_mse_nm2=np.mean(losses),
                                      val_macro_rmsd_nm=score,grad_norm=np.mean(grads),relative_adamw_update=np.mean(updates)))
                if epoch in [1,20,40,args.epochs]: print(variant,seed,epoch,'val',round(score,5),'best',round(best,5),'sec',round(time.time()-start,1),flush=True)
            torch.save(dict(state=state,variant=variant,width=64,k=model.k,seed=seed,epoch=best_epoch,val_nm=best),path)
            model.load_state_dict(state);model.eval()
            # Retain predictions for final evaluation AFTER all validation selection decisions.
            with torch.no_grad():
                predictions[(variant,seed)]={d:model(*ds[d][:3]).numpy() for d in sum(split.values(),[])}
            runs.append(dict(variant=variant,seed=seed,best_epoch=best_epoch,val_nm=best,
                             params=sum(p.numel() for p in model.parameters()),seconds=time.time()-start))
    # Freeze choice using validation averages across seeds; test is not used to choose variants.
    scores={v:float(np.mean([r['val_nm'] for r in runs if r['variant']==v])) for v in args.variants}
    selected=min(scores,key=scores.get)
    (out/'selection.json').write_text(json.dumps(dict(selected=selected,validation=scores,runs=runs),indent=2))
    pred_dir=out/'predictions';pred_dir.mkdir(exist_ok=True)
    for (v,seed), pred in predictions.items():
        np.savez_compressed(pred_dir/f'{v}_{seed}.npz',**pred)
        for part,ids in split.items():
            for d in ids:
                records.append(dict(variant=v,seed=seed,split=part,design=d,rmsd_nm=rms(torch.tensor(pred[d]),data[d][3])))
    # Baselines: identity and a global radial coefficient fit ONLY on training designs.
    num=den=0.
    for d in split['train']:
        x=np.load(root/'inputs'/f'{d}.npz')['pos']*NM;y=data[d][3].numpy()
        num+=np.mean(np.sum(x*y,axis=1));den+=np.mean(np.sum(x*x,axis=1))
    radial=float(num/den)
    for part,ids in split.items():
        for d in ids:
            x=np.load(root/'inputs'/f'{d}.npz')['pos']*NM
            for v,p in [('identity',np.zeros_like(x)),('radial',radial*x)]:
                records.append(dict(variant=v,seed=0,split=part,design=d,rmsd_nm=rms(torch.tensor(p),data[d][3])))
    # All-seed ensembles are defined for every variant, no test-informed seed selection.
    for v in args.variants:
        for part,ids in split.items():
            for d in ids:
                p=np.mean([predictions[(v,s)][d] for s in args.seeds],axis=0)
                records.append(dict(variant=v+'_ensemble',seed=0,split=part,design=d,rmsd_nm=rms(torch.tensor(p),data[d][3])))
    for name,rows in [('metrics',records),('history',histories)]:
        with (out/f'{name}.csv').open('w') as f:
            w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    (out/'baseline.json').write_text(json.dumps(dict(radial_coefficient=radial),indent=2))
    print('SELECTED_BY_VALIDATION',selected,scores,flush=True)


if __name__=='__main__': main()
