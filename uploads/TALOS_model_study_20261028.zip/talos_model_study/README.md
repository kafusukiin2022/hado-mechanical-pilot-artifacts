# TALOS geometric endpoint study

Read **REPORT_ZH.md** for the literature review, experiment results and limitations.

- Real pilot: 5 position-only prototypes × 3 seeds × 60 epochs; CPU.
- Dataset: user's 20-design subset, 12 train / 4 validation / 4 test.
- Original DGNN/OnePass source and checkpoints were not included and are not reproduced.
- Validation-selected prototype: `frame`; 3-seed ensemble test macro RMSD 2.6767 nm versus identity 2.8640 nm.
- `adaptive_se3_head.py` is a checked integration proposal, not a trained model.
- The 15 trained `.pt` files are in `checkpoints/`; exact scores and predictions are in `results/`.
- Predicted positions use the source chart, without an extra evaluation-time Kabsch fit.
- Raw dataset is not duplicated in this package; use the original attachment.

## Reproduce

```bash
python -m pip install -r requirements.txt
python audit_dataset.py --data /path/talos97_subset20
python run_study.py --data /path/talos97_subset20 --epochs 60 --seeds 11 22 33
python diagnostics.py --data /path/talos97_subset20
python make_figures.py
python export_tensorboard.py
python check_integration.py
```

Inference needs only an input NPZ, not labels:

```bash
python predict.py --input /path/design.npz \
  --checkpoints checkpoints/frame_11.pt checkpoints/frame_22.pt checkpoints/frame_33.pt \
  --output prediction.npz
```

Results are an exploratory small-data study. Four test designs cannot establish a universal architecture ranking. The original 97-design OnePass score is from a different training/test scope and must not be compared numerically to this pilot as a fair head-to-head result.
