"""Verify archive manifest and basic geometry without using Library provenance paths."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from model import NM


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',required=True);args=ap.parse_args()
    root=Path(args.data);manifest=json.loads((root/'manifest.json').read_text());split=json.loads((root/'split.json').read_text())
    checks=[];rows=[]
    for row in manifest['rows']:
        d=row['design_id']
        for f,expected in row['files'].items():checks.append(hashlib.sha256((root/'designs'/d/f).read_bytes()).hexdigest()==expected)
        for folder,key in [('inputs','input_cache_sha256'),('labels','label_cache_sha256')]:
            checks.append(hashlib.sha256((root/folder/f'{d}.npz').read_bytes()).hexdigest()==row[key])
        a=dict(np.load(root/'inputs'/f'{d}.npz'));b=dict(np.load(root/'labels'/f'{d}.npz'))
        assert all(np.isfinite(v).all() for v in [a['pos'],a['rotation'],a['node_features'],a['edge_features'],b['target_pos'],b['target_rotation']])
        delta=(b['target_pos']-a['pos'])*NM;R=a['rotation']
        rows.append(dict(design=d,split=next(k for k,v in split.items() if d in v),nodes=len(delta),
                         identity_rmsd_nm=float(np.sqrt(np.mean(np.sum(delta**2,axis=1)))),
                         small_fraction=float(np.mean(np.linalg.norm(delta,axis=1)<.5)),
                         frame_orthogonality_error=float(np.max(np.abs(R.transpose(0,2,1)@R-np.eye(3))))))
    assert all(checks),'SHA256 mismatch'
    result=dict(all_hashes_match=all(checks),hash_checks=len(checks),designs=rows)
    Path('results/dataset_audit.json').write_text(json.dumps(result,indent=2));print('Hash checks passed:',len(checks))


if __name__=='__main__':main()
