"""Small meaningful checks for the untrained integration candidate, incl. nonzero head."""
import torch
from adaptive_se3_head import AdaptiveSE3Head,invariant_edges


def main():
    torch.set_num_threads(2);torch.manual_seed(19)
    n,h,k=37,12,8
    X=torch.randn(n,3);R=torch.eye(3).expand(n,3,3).clone();s=torch.randn(n,h);V=torch.randn(n,k,3)
    batch=torch.tensor([0]*17+[1]*20)
    m=AdaptiveSE3Head(h,k)
    xp,rp,_=m(X,R,s,V,batch)
    assert torch.equal(xp,X) and torch.equal(rp,R),'Identity initialization'
    torch.nn.init.normal_(m.network[-1].weight,std=.1)
    Q,_=torch.linalg.qr(torch.randn(3,3))
    if torch.linalg.det(Q)<0:Q[:,0]*=-1
    t=torch.randn(3)
    xp,rp,d=m(X,R,s,V,batch)
    xt,rt,dt=m(X@Q.T+t,Q@R,s,V@Q.T,batch)
    pe=float((xt-(xp@Q.T+t)).abs().max().detach());re=float((rt-Q@rp).abs().max().detach())
    assert pe<1e-5 and re<1e-5
    for b in [0,1]:assert d['delta'][batch==b].sum(0).abs().max()<1e-5
    assert (rp.transpose(-1,-2)@rp-torch.eye(3)).abs().max()<1e-5
    i=torch.arange(n-1);edges=torch.stack([i,i+1]);et=i%5
    e=invariant_edges(X,R,edges,et);e2=invariant_edges(X@Q.T+t,Q@R,edges,et)
    assert (e-e2).abs().max()<1e-5
    loss=xp.square().mean()+rp.square().mean();loss.backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in m.parameters())
    with torch.no_grad():
        m.network[-1].weight[-1].zero_();m.network[-1].bias[-1]=-1000
        xzero,_,_=m(X,R,s,V,batch)
        assert torch.equal(xzero,X),'All-zero gates must produce exactly zero motion'
    print({'identity_init':'pass','nonzero_rotation_translation_error':pe,'rotation_output_error':re,
           'zero_sum_each_graph':'pass','rotation_manifold':'pass','edge_invariance':'pass','autograd':'pass',
           'status':'integration candidate only; no performance training'})


if __name__=='__main__':main()
