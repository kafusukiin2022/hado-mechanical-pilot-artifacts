"""Integration candidate for a LEARNED equivariant backbone; NOT trained here.

Scalar state s must be rotation invariant and V must rotate as 3-vectors.
This readout alone cannot repair non-invariant scalar edge features upstream.
Coordinate units are inherited from X. R uses column basis convention.
"""
import math
import torch
from torch import nn


def invariant_edges(pos, frames, edge_index, edge_types, same_strand=None):
    """Rebuild geometric scalars from input positions/frames, never old xyz scalars."""
    i,j=edge_index
    rel=pos[j]-pos[i];d=rel.norm(dim=-1,keepdim=True)
    unit=rel/d.clamp_min(1e-8)
    local_i=torch.einsum('nab,na->nb',frames[i],unit)
    local_j=torch.einsum('nab,na->nb',frames[j],unit)
    relative_frame=frames[i].transpose(-1,-2)@frames[j]
    types=torch.nn.functional.one_hot(edge_types,num_classes=5).to(pos.dtype)
    parts=[types,d,local_i,local_j,relative_frame.flatten(-2)]
    if same_strand is not None:parts.append(same_strand.reshape(-1,1).to(pos.dtype))
    return torch.cat(parts,-1)


class AdaptiveSE3Head(nn.Module):
    """Soft shrinkage with zero-sum displacement and a separate SO(3) update.

    pi_i = g_i * (u_i - sum_j(g_j*u_j)/sum_j(g_j)).
    Zero gate implies exactly zero displacement while sum_i pi_i=0.
    Gate is not a calibrated probability and does not guarantee fewer errors.
    """
    def __init__(self, scalar_dim, vector_channels, hidden=64, eps=1e-6):
        super().__init__();self.eps=eps;self.k=vector_channels
        dim=3*scalar_dim+vector_channels
        self.network=nn.Sequential(nn.Linear(dim,hidden),nn.SiLU(),nn.Linear(hidden,2*vector_channels+1))
        nn.init.zeros_(self.network[-1].weight);nn.init.zeros_(self.network[-1].bias)

    def forward(self,X,R,s,V,batch=None):
        if batch is None:batch=torch.zeros(len(X),dtype=torch.long,device=X.device)
        ng=int(batch.max())+1
        counts=torch.bincount(batch,minlength=ng).to(s.dtype).clamp_min(1)
        means=torch.zeros(ng,s.shape[-1],dtype=s.dtype,device=s.device).index_add_(0,batch,s)/counts[:,None]
        maxima=torch.full_like(means,-torch.inf).scatter_reduce_(0,batch[:,None].expand_as(s),s,reduce='amax',include_self=True)
        q=(V.square().sum(-1)/3+self.eps).sqrt()
        basis=V/q[...,None]
        h=torch.cat([s,means[batch],maxima[batch],q.log()],-1)
        raw=self.network(h);cp,cw,gate=raw.split([self.k,self.k,1],dim=-1)
        up=torch.einsum('nk,nka->na',cp.tanh()/math.sqrt(self.k),basis)
        omega=torch.einsum('nk,nka->na',cw.tanh()/math.sqrt(self.k),basis)
        gate=gate.sigmoid()
        total=torch.zeros(ng,1,dtype=s.dtype,device=s.device).index_add_(0,batch,gate)
        # Only replace an exactly empty/zero total: clamping a small positive
        # total would break the zero-sum identity when all gates are very small.
        denominator=torch.where(total>0,total,torch.ones_like(total))
        weighted=torch.zeros(ng,3,dtype=s.dtype,device=s.device).index_add_(0,batch,gate*up)/denominator
        delta=gate*(up-weighted[batch])
        # Left/world-frame tangent increment; do not subtract mean angular increment.
        wx,wy,wz=omega.unbind(-1);z=torch.zeros_like(wx)
        skew=torch.stack([z,-wz,wy,wz,z,-wx,-wy,wx,z],dim=-1).reshape(-1,3,3)
        return X+delta,torch.matrix_exp(skew)@R,{'gate':gate,'delta':delta,'omega':omega}
