from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    m=pd.read_csv('results/metrics.csv');h=pd.read_csv('results/history.csv');s=pd.read_csv('results/summary.csv').set_index('variant')
    names=['identity','radial','frame','vector','gate','no_multiscale','raw']
    labels=['Identity','Radial','Local frame','Vector basis','Vector + gate','Gate, no scales','Raw vectors']
    colors=['#8794a5','#8794a5','#5468d4','#168579','#d59125','#b57599','#a09c56']
    fig,axs=plt.subplots(2,2,figsize=(13,9),layout='constrained')
    ax=axs[0,0]
    vals=[s.loc[n,'test_macro_nm'] for n in names];err=[s.loc[n,'seed_sd_nm'] for n in names]
    ax.barh(labels,vals,color=colors,xerr=err,capsize=3);ax.invert_yaxis()
    ax.set(xlabel='Test design-macro RMSD (nm)',title='A  Matched pilot: mean over 3 seeds')
    for y,v in enumerate(vals):ax.text(v+.035,y,f'{v:.3f}',va='center',fontsize=9)
    ax.set_xlim(0,max(vals)+.4)
    ax=axs[0,1]
    for v,label,c in zip(names[2:],labels[2:],colors[2:]):
        z=h[h.variant==v].groupby('epoch').val_macro_rmsd_nm.agg(['mean','std'])
        ax.plot(z.index,z['mean'],label=label,color=c);ax.fill_between(z.index,z['mean']-z['std'],z['mean']+z['std'],alpha=.1,color=c)
    ax.set(title='B  Validation learning curves',xlabel='Epoch',ylabel='Macro RMSD (nm)');ax.legend(fontsize=8)
    ax=axs[1,0];t=m[(m.split=='test') & m.variant.isin(['identity','frame','vector','gate'])]
    piv=t.groupby(['design','variant']).rmsd_nm.mean().unstack()
    xx=np.arange(len(piv))
    for shift,(v,label,c) in enumerate(zip(names[2:5],labels[2:5],colors[2:5])):
        ax.bar(xx+(shift-1)*.22,piv.identity-piv[v],width=.21,label=label,color=c)
    ax.axhline(0,color='#555',lw=.8);ax.set(xticks=xx,xticklabels=[x.replace('6hb_','') for x in piv.index],title='C  Improvement over identity, each design',xlabel='Test design',ylabel='RMSD reduction (nm)');ax.legend(fontsize=8)
    ax=axs[1,1];b=pd.read_csv('results/node_bins.csv');bins=['0-0.5','0.5-2','2-4','4-8']
    for v,label,c in zip(names[::1],labels,colors):
        if v not in ['identity','frame','vector','gate']:continue
        q=b[b.variant==v].groupby('bin').mean_node_error_nm.mean().reindex(bins)
        ax.plot(range(4),q,marker='o',label=label,color=c)
    ax.set(xticks=range(4),xticklabels=['<0.5','0.5-2','2-4','4-8'],xlabel='True displacement bin (nm)',ylabel='Mean node error (nm)',title='D  Small-motion behavior, fixed seed 11');ax.legend(fontsize=8)
    fig.suptitle('TALOS 20-design pilot | 12 train / 4 validation / 4 test\nPosition prediction only; these are not DGNN / OnePass reproductions',fontsize=13)
    fig.savefig('results/comparison.png',dpi=180);fig.savefig('results/comparison.pdf');plt.close(fig)
    probes=pd.read_csv('results/probes.csv');p=probes[(probes.split=='test')&(~probes.representation.str.contains('shuffled'))]
    table=p.groupby(['representation','task']).mse_nm2.mean().unstack()
    table.to_csv('results/probe_summary.csv')
    fig,ax=plt.subplots(figsize=(9,5),layout='constrained')
    q=table['local_displacement'].sort_values();ax.barh(q.index,q.values,color='#168579');ax.invert_yaxis()
    ax.set(xlabel='Test local displacement probe MSE (nm² per component)',title='Geometry probing | Ridge alpha selected on validation designs')
    fig.savefig('results/probes.png',dpi=160);plt.close(fig)


if __name__=='__main__':main()
