"""Source-only ensemble inference. Does not open a labels directory.

python predict.py --input /path/design.npz --checkpoints checkpoints/vector_11.pt \
    checkpoints/vector_22.pt checkpoints/vector_33.pt --output prediction.npz
"""
import argparse,json
from pathlib import Path
import numpy as np
import torch
from model import BasisNet,geometry,NM


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',required=True)
    ap.add_argument('--checkpoints',nargs='+',required=True)
    ap.add_argument('--output',required=True)
    args=ap.parse_args();torch.set_num_threads(2)
    a=dict(np.load(args.input,allow_pickle=False));pred=[]
    with torch.no_grad():
        for path in args.checkpoints:
            ck=torch.load(path,map_location='cpu',weights_only=True)
            m=BasisNet(ck['state']['mean'],ck['state']['std'],k=ck['k'],width=ck['width'],variant=ck['variant'])
            m.load_state_dict(ck['state']);m.eval()
            s,B,R=geometry(a,multiscale=ck['variant']!='no_multiscale')
            pred.append(m(torch.tensor(s),torch.tensor(B),torch.tensor(R)).numpy())
    mean=np.mean(pred,axis=0)
    # Between-seed spread is not a calibrated physical or label-noise uncertainty.
    spread=np.std(pred,axis=0,ddof=1) if len(pred)>1 else np.zeros_like(mean)
    np.savez_compressed(args.output,predicted_pos=a['pos']+mean/NM,displacement_nm=mean,seed_spread_nm=spread,
                        metadata=json.dumps({'coordinate_units':'normalized; multiply by 34.072 for nm',
                                             'orientation_prediction':False,'ensemble_size':len(pred)}))
    print('Saved',Path(args.output).resolve())


if __name__=='__main__':main()
