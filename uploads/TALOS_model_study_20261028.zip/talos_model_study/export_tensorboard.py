"""Export actually measured epoch metrics to TensorBoard (no extra training)."""
from pathlib import Path
import pandas as pd
from torch.utils.tensorboard import SummaryWriter


def main():
    h=pd.read_csv('results/history.csv')
    for (variant,seed),d in h.groupby(['variant','seed']):
        with SummaryWriter(str(Path('results/tensorboard')/f'{variant}_{seed}')) as w:
            for row in d.itertuples():
                for field in ['train_mse_nm2','val_macro_rmsd_nm','grad_norm','relative_adamw_update']:
                    w.add_scalar(field,getattr(row,field),row.epoch)
    print('TensorBoard logs exported from recorded training metrics.')


if __name__=='__main__':main()
