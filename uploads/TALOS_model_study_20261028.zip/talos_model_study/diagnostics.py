"""Posthoc pilot diagnostics: probes, CKA/RSA, interventions, real optimizer steps.

Dependencies: numpy scipy scikit-learn matplotlib torch. No external model hooks
are required for this small model; sklearn Ridge and PyTorch Autograd are used.
Original DGNN/OnePass checkpoints are not available and are not diagnosed here.
"""
import argparse,csv,itertools,json
from pathlib import Path
import numpy as np
import torch
from scipy.spatial.distance import pdist
from scipy.stats import spearmanr
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from model import BasisNet,geometry,load_inputs,NM


def write_csv(name,rows):
    with (Path('results')/name).open('w') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)


def load(v,seed=11):
    ck=torch.load(Path('checkpoints')/f'{v}_{seed}.pt',map_location='cpu',weights_only=True)
    m=BasisNet(ck['state']['mean'],ck['state']['std'],k=ck['k'],width=ck['width'],variant=v)
    m.load_state_dict(ck['state']);m.eval();return m


def cka(A,B):
    A=A-A.mean(0);B=B-B.mean(0)
    return float(np.sum((A.T@B)**2)/(np.linalg.norm(A.T@A)*np.linalg.norm(B.T@B)+1e-20))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',required=True);args=ap.parse_args()
    torch.set_num_threads(2);root=Path(args.data)
    split=json.loads((root/'split.json').read_text());sel=json.loads(Path('results/selection.json').read_text())
    variants=list(sel['validation']);models={v:load(v) for v in variants}
    rng=np.random.default_rng(20261028);data={};reps={};targets={};indices={};interventions=[];gates=[]
    with torch.no_grad():
        for part,ids in split.items():
            for d in ids:
                a=dict(np.load(root/'inputs'/f'{d}.npz'));lab=dict(np.load(root/'labels'/f'{d}.npz'))
                s,B,R=geometry(a);y=(lab['target_pos']-a['pos'])*NM
                tensors=tuple(torch.tensor(z) for z in [s,B,R,y]);data[d]=tensors
                idx=rng.choice(len(s),1024,replace=False);indices[d]=idx
                delta_local=np.einsum('na,nab->nb',y,R)
                i,j=a['backbone_edges'];x=a['pos']*NM;yp=lab['target_pos']*NM
                change=np.linalg.norm(yp[j]-yp[i],axis=1)-np.linalg.norm(x[j]-x[i],axis=1)
                bond=np.bincount(i,weights=change,minlength=len(x))/np.maximum(np.bincount(i,minlength=len(x)),1)
                targets[d]={'amplitude':np.linalg.norm(y,axis=1)[idx,None],
                            'local_displacement':delta_local[idx], 'backbone_length_change':bond[idx,None]}
                reps[d]={'input':s[idx],'basis_local':np.einsum('nka,nab->nkb',B,R).reshape(len(s),-1)[idx]}
                for v,m in models.items():
                    ts=tensors
                    if v=='no_multiscale':
                        sn,Bn,Rn=geometry(a,False);ts=tuple(torch.tensor(z) for z in [sn,Bn,Rn,y])
                    pred,layers,h,c,b,g=m(*ts[:3],details=True)
                    for l,z in enumerate(layers[1:],1):reps[d][f'{v}_layer{l}']=z[idx].numpy()
                    if part=='validation' and v in ['vector','gate']:
                        base=float((pred-ts[3]).square().sum(-1).mean().sqrt())
                        for intervention in ['zero_context','zero_vectors','permute_vectors','common_permutation','rotate_vectors','half_norm']:
                            p=m(*ts[:3],intervene=intervention)
                            interventions.append(dict(variant=v,design=d,intervention=intervention,
                                base_rmsd_nm=base,rmsd_change_nm=float((p-ts[3]).square().sum(-1).mean().sqrt())-base,
                                max_prediction_difference_nm=float((p-pred).abs().max())))
                    if g is not None:
                        for lo,hi in [(0,.5),(.5,2),(2,4),(4,8),(8,1e6)]:
                            mask=(np.linalg.norm(y,axis=1)>=lo)&(np.linalg.norm(y,axis=1)<hi)
                            if mask.any():gates.append(dict(variant=v,design=d,split=part,bin=f'{lo}-{hi}',n=int(mask.sum()),gate_mean=float(g[mask].mean()),pred_amplitude=float(pred[mask].norm(dim=-1).mean()),error_nm=float((pred[mask]-ts[3][mask]).norm(dim=-1).mean())))
    write_csv('interventions.csv',interventions);write_csv('gate_bins.csv',gates)
    # Geometry probes: equal samples/design, same samples/features across probe targets.
    # Standardizer and Ridge fit TRAIN only; alpha chosen using per-design VALIDATION MSE.
    probes=[]
    names=['input','basis_local','frame_layer1','frame_layer2','vector_layer1','vector_layer2','gate_layer1','gate_layer2']
    for name in names:
        X=np.concatenate([reps[d][name] for d in split['train']]);ss=StandardScaler().fit(X);X=ss.transform(X)
        for task in targets[split['train'][0]]:
            Y=np.concatenate([targets[d][task] for d in split['train']])
            models_r=[]
            for alpha in [.1,1,10,100,1000]:
                r=Ridge(alpha=alpha).fit(X,Y)
                val=np.mean([np.mean((r.predict(ss.transform(reps[d][name]))-targets[d][task])**2) for d in split['validation']])
                models_r.append((val,alpha,r))
            _,alpha,r=min(models_r,key=lambda z:z[0])
            for part in ['validation','test']:
                for d in split[part]:
                    err=np.mean((r.predict(ss.transform(reps[d][name]))-targets[d][task])**2)
                    probes.append(dict(representation=name,task=task,split=part,design=d,mse_nm2=float(err),alpha=alpha))
        # Label-shuffle control for local displacement; within-design shuffling.
        task='local_displacement';Y=np.concatenate([targets[d][task][rng.permutation(1024)] for d in split['train']])
        r=Ridge(alpha=1000).fit(X,Y)
        for d in split['test']:
            probes.append(dict(representation=name+'_shuffled_control',task=task,split='test',design=d,
                mse_nm2=float(np.mean((r.predict(ss.transform(reps[d][name]))-targets[d][task])**2)),alpha=1000))
    for task in targets[split['train'][0]]:
        mu=np.concatenate([targets[d][task] for d in split['train']]).mean(0)
        for part in ['validation','test']:
            for d in split[part]:probes.append(dict(representation='train_mean',task=task,split=part,design=d,mse_nm2=float(np.mean((mu-targets[d][task])**2)),alpha=0))
    write_csv('probes.csv',probes)
    similarity=[]
    for part in ['validation','test']:
        for d in split[part]:
            for v,w in itertools.combinations(['frame','vector','gate'],2):
                for l in [1,2]:
                    A=reps[d][f'{v}_layer{l}'];B=reps[d][f'{w}_layer{l}']
                    similarity.append(dict(split=part,design=d,model_a=v,model_b=w,layer=l,cka=cka(A,B),
                        rsa_spearman=float(spearmanr(pdist(A[:256]),pdist(B[:256])).statistic)))
    write_csv('similarity.csv',similarity)
    # Whole-pipeline proper rigid motions, rebuilding features from rotated inputs.
    equiv=[]
    for d in split['validation']:
        a=dict(np.load(root/'inputs'/f'{d}.npz'))
        for rep in range(10):
            Q,_=np.linalg.qr(rng.normal(size=(3,3)))
            if np.linalg.det(Q)<0:Q[:,0]*=-1
            ar={k:v.copy() for k,v in a.items()};ar['pos']=a['pos']@Q.T+rng.normal(size=3)*2
            ar['rotation']=np.einsum('ab,nbc->nac',Q,a['rotation'])
            with torch.no_grad():
                for v in ['frame','vector','gate']:
                    st,Bt,Rt=geometry(ar)
                    pr=models[v](torch.tensor(st),torch.tensor(Bt),torch.tensor(Rt)).numpy()
                    base=models[v](*data[d][:3]).numpy()@Q.T
                    equiv.append(dict(design=d,variant=v,rotation=rep,max_abs_error_nm=float(np.abs(pr-base).max())))
    write_csv('equivariance.csv',equiv)
    # Actual AdamW updates on TRAIN data from trained and zero-initialized states.
    # Work on cloned models; do not alter saved checkpoints. Backtracking is not used.
    optim=[]
    for v in ['frame','vector','gate']:
        m=models[v]
        for init in [True,False]:
            clone=BasisNet(m.mean,m.std,k=m.k,variant=v)
            if not init:clone.load_state_dict(m.state_dict())
            opt=torch.optim.AdamW(clone.parameters(),lr=1e-3,weight_decay=1e-4)
            for step,d in enumerate(split['train'][:3],1):
                opt.zero_grad(set_to_none=True);s,B,R,y=data[d]
                loss=(clone(s,B,R)-y).square().mean();loss.backward()
                before={n:p.detach().clone() for n,p in clone.named_parameters()}
                norms={n:float(p.grad.norm()) if p.grad is not None else None for n,p in clone.named_parameters()}
                torch.nn.utils.clip_grad_norm_(clone.parameters(),5.);opt.step()
                for name,p in clone.named_parameters():optim.append(dict(variant=v,state='identity_init' if init else 'checkpoint_fresh_optimizer',step=step,design=d,parameter=name,
                    grad_norm=norms[name],actual_update_norm=float((p-before[name]).norm()),weight_norm_before=float(before[name].norm())))
    write_csv('optimizer_steps.csv',optim)
    # Per-design, per-seed + ensembles and exploratory cluster bootstrap (four test designs).
    import pandas as pd
    metrics=pd.read_csv('results/metrics.csv');test=metrics[metrics.split=='test']
    base=test[test.variant=='identity'].set_index('design').rmsd_nm
    summary=[]
    for v,sub in test.groupby('variant'):
        byseed=sub.groupby('seed').rmsd_nm.mean()
        perdesign=sub.groupby('design').rmsd_nm.mean().reindex(base.index)
        diff=base.values-perdesign.values
        boot=diff[rng.integers(0,len(diff),(20000,len(diff)))].mean(1)
        summary.append(dict(variant=v,test_macro_nm=float(byseed.mean()),seed_sd_nm=float(byseed.std(ddof=1)) if len(byseed)>1 else 0,
             wins_identity=int((diff>0).sum()),paired_gain_nm=float(diff.mean()),gain_ci_low=float(np.quantile(boot,.025)),gain_ci_high=float(np.quantile(boot,.975))))
    write_csv('summary.csv',summary)
    # Node-level stratified errors, first average within design, then macro over designs.
    errors=[]
    for v in ['identity','frame','vector','gate','no_multiscale','raw']:
        predfile=Path('results/predictions')/f'{v}_11.npz'
        pz=np.load(predfile) if predfile.exists() else None
        for d in split['test']:
            y=data[d][3].numpy();p=pz[d] if pz is not None else np.zeros_like(y)
            mag=np.linalg.norm(y,axis=1)
            for lo,hi in [(0,.5),(.5,2),(2,4),(4,8),(8,1e6)]:
                mask=(mag>=lo)&(mag<hi)
                if mask.any():errors.append(dict(variant=v,design=d,bin=f'{lo}-{hi}',n=int(mask.sum()),mean_node_error_nm=float(np.linalg.norm((p-y)[mask],axis=1).mean()),mean_pred_displacement_nm=float(np.linalg.norm(p[mask],axis=1).mean())))
    write_csv('node_bins.csv',errors)
    print(json.dumps(summary,indent=2));print('Diagnostics complete')


if __name__=='__main__':main()
