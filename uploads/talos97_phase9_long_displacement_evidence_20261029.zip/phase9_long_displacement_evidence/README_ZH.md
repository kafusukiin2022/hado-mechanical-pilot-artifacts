# 长位移节点系统性低估：证据与训练代码

## 主要观察
三种子基线在 11701 个长位移节点（真实幅度≥4 nm）上的平均预测幅度仅 1.64594 nm；软路由为1.73486 nm，硬路由为1.50454 nm。节点误差 RMS 分别为3.96751、3.93038、4.06931 nm。软路由总体宏 RMSD 2.15048 nm，对照2.15703 nm，改善0.30%，未达到0.05 nm筛选线。分类器固定阈值下长类宏平均召回3.59%。真实标签路由仅为诊断，不能部署。幅度不足与方向误差应区分，不能据此断言因果机制。

## 典型设计：6hb_009
按14个验证设计中长位移幅度比最接近中位数选择，非最大误差案例。长位移节点614个，真实平均幅度4.765269 nm，基线预测1.720688 nm，幅度比0.3611，其中99.67%节点被低估。全部设计汇总见all_validation_long_displacement.csv，典型设计逐节点幅度见typical_long_nodes.csv；向量npz中位移单位nm，初始位置为内部单位（乘34.072转换nm），节点索引从0开始。

## 权重选择与范围
按每个seed完整软路由验证宏RMSD选seed 11，其RMSD为2.171487 nm；保留其三个专家/分类器最佳checkpoint和对应基础frame权重，共4份。所有12次训练历史和指标保留，但其他权重省略。报告里的三种子集成指标不能仅凭这组单seed权重复现。

## 代码运行与限制
保留原目录结构。依赖Python、numpy、scipy、torch。训练命令：python experiments/talos97_model_improvement/phase9_displacement_moe/run_experiment.py --help（按原SPEC配置运行）；核验命令：python experiments/talos97_model_improvement/phase9_displacement_moe/verify_results.py。原始脚本要求原数据集、三个基础checkpoint和全套运行工件；本包只保留选中seed权重及一个验证设计向量，因此不是独立可重跑完整训练/三seed核验的数据包。源文件保持原样，summary保留原环境路径和哈希用于追溯。未纳入原始数据集、测试集、测试预测、缓存及无关项目。固定验证集已多次筛选，不是盲测。
