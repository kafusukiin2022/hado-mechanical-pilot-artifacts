from pathlib import Path
import numpy as np,json,csv,shutil,hashlib,zipfile
R=Path.cwd(); phase=R/'experiments/talos97_model_improvement/phase9_displacement_moe'; out=R/'outputs/phase9_github_bundle_20261029'; pack=out/'phase9_long_displacement_evidence';pack.mkdir(exist_ok=True)
v=json.loads((phase/'results/verification.json').read_text()); ids=list(v['ensemble_metrics']['control']['per_design']); targets={};initial={}
for d in ids:
 with np.load(R/f'experiments/talos97_endpoint_v1/data/inputs/{d}.npz') as a,np.load(R/f'experiments/talos97_endpoint_v1/data/labels/{d}.npz') as b:
  initial[d]=a['pos'].copy(); targets[d]=(b['target_pos'].astype(np.float32)-a['pos'])*34.072
scores={}
for s in (11,22,33):
 with np.load(phase/f'results/seed{s}_soft_validation.npz') as a:
  scores[s]=float(np.mean([np.sqrt(np.mean(np.sum((a[d]-targets[d])**2,axis=1))) for d in ids]))
seed=min(scores,key=scores.get); rows=[]; predictions={}
for mode in ('control','hard','soft','oracle'):
 archives=[np.load(phase/f'results/seed{s}_{mode}_validation.npz') for s in (11,22,33)]
 predictions[mode]={d:np.mean([a[d] for a in archives],axis=0) for d in ids}
 for a in archives:a.close()
for d in ids:
 t=np.linalg.norm(targets[d],axis=1);m=t>=4;p=np.linalg.norm(predictions['control'][d],axis=1)
 rows.append(dict(design=d,long_nodes=int(m.sum()),target_mean_nm=float(t[m].mean()),control_mean_nm=float(p[m].mean()),amplitude_ratio=float(p[m].mean()/t[m].mean()),underestimated_fraction=float((p[m]<t[m]).mean())))
median=float(np.median([x['amplitude_ratio'] for x in rows])); ex=min(rows,key=lambda x:abs(x['amplitude_ratio']-median));design=ex['design']
def table(path,rows):
 with path.open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
table(pack/'all_validation_long_displacement.csv',rows)
t=np.linalg.norm(targets[design],axis=1); nr=[]
for i in np.flatnonzero(t>=4):
 row={'node_index_zero_based':int(i),'target_magnitude_nm':float(t[i])}
 for mode in predictions:row[mode+'_magnitude_nm']=float(np.linalg.norm(predictions[mode][design][i]))
 nr.append(row)
table(pack/'typical_long_nodes.csv',nr)
np.savez_compressed(pack/'typical_design_vectors.npz',initial_pos_internal_units=initial[design],target_displacement_nm=targets[design],**{m+'_displacement_nm':p[design] for m,p in predictions.items()})
def copy(src):
 dest=pack/src.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
for name in ('SPEC.md','EXPECTED_VERIFICATION.md','run_experiment.py','verify_results.py','train.log'):copy(phase/name)
for name in ('REPORT_ZH.md','summary.json','verification.json','preflight.json'):copy(phase/'results'/name)
for folder in (phase/'runs').iterdir():
 if folder.is_dir():
  for name in ('history.jsonl','status.json','per_design_validation.csv'):copy(folder/name)
  if folder.name.startswith(f'seed{seed}_') and not folder.name.endswith('control'):copy(folder/'best.pt')
for name in ('model.py','run_full97.py'):copy(R/'experiments/talos97_localframe_2m'/name)
copy(R/f'experiments/talos97_localframe_2m/checkpoints/frame_{seed}.pt')
info={'checkpoint_selection':'minimum per-seed soft-routing validation macro RMSD; not test selection','per_seed_soft_rmsd_nm':scores,'selected_seed':seed,'typical_design_selection':'closest to median per-design control long-node mean amplitude ratio across all 14 validation designs','typical_design':ex,'ensemble_results_are_three_seed_not_reproducible_from_selected_single_seed_weights_alone':True,'dataset_not_included':True}
(pack/'PACKAGE.json').write_text(json.dumps(info,indent=2))
(pack/'README_ZH.md').write_text(f'''# 长位移节点系统性低估：证据与训练代码\n\n## 主要观察\n三种子基线在 11701 个长位移节点（真实幅度≥4 nm）上的平均预测幅度仅 1.64594 nm；软路由为1.73486 nm，硬路由为1.50454 nm。节点误差 RMS 分别为3.96751、3.93038、4.06931 nm。软路由总体宏 RMSD 2.15048 nm，对照2.15703 nm，改善0.30%，未达到0.05 nm筛选线。分类器固定阈值下长类宏平均召回3.59%。真实标签路由仅为诊断，不能部署。幅度不足与方向误差应区分，不能据此断言因果机制。\n\n## 典型设计：{design}\n按14个验证设计中长位移幅度比最接近中位数选择，非最大误差案例。长位移节点{ex['long_nodes']}个，真实平均幅度{ex['target_mean_nm']:.6f} nm，基线预测{ex['control_mean_nm']:.6f} nm，幅度比{ex['amplitude_ratio']:.4f}，其中{ex['underestimated_fraction']:.2%}节点被低估。全部设计汇总见all_validation_long_displacement.csv，典型设计逐节点幅度见typical_long_nodes.csv；向量npz中位移单位nm，初始位置为内部单位（乘34.072转换nm），节点索引从0开始。\n\n## 权重选择与范围\n按每个seed完整软路由验证宏RMSD选seed {seed}，其RMSD为{scores[seed]:.6f} nm；保留其三个专家/分类器最佳checkpoint和对应基础frame权重，共4份。所有12次训练历史和指标保留，但其他权重省略。报告里的三种子集成指标不能仅凭这组单seed权重复现。\n\n## 代码运行与限制\n保留原目录结构。依赖Python、numpy、scipy、torch。训练命令：python experiments/talos97_model_improvement/phase9_displacement_moe/run_experiment.py --help（按原SPEC配置运行）；核验命令：python experiments/talos97_model_improvement/phase9_displacement_moe/verify_results.py。原始脚本要求原数据集、三个基础checkpoint和全套运行工件；本包只保留选中seed权重及一个验证设计向量，因此不是独立可重跑完整训练/三seed核验的数据包。源文件保持原样，summary保留原环境路径和哈希用于追溯。未纳入原始数据集、测试集、测试预测、缓存及无关项目。固定验证集已多次筛选，不是盲测。\n''')
copy(out/'build_bundle.py')
manifest=[]
for f in sorted(pack.rglob('*')):
 if f.is_file():manifest.append({'path':str(f.relative_to(pack)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(pack/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
z=out/'talos97_phase9_long_displacement_evidence_20261029.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as a:
 for f in sorted(pack.rglob('*')):
  if f.is_file():a.write(f,str(f.relative_to(out)))
assert z.stat().st_size<100_000_000
with zipfile.ZipFile(z) as a:assert a.testzip() is None
print(json.dumps({'archive':str(z),'bytes':z.stat().st_size,'selected_seed':seed,'scores':scores,'example':ex,'files':len(manifest)+1},indent=2))
