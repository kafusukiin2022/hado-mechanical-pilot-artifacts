# Phase 9 expected verification

## Before training

1. `py_compile` the runner and independent verifier.
2. Run CPU structural preflight and a GPU preflight on a fresh, authorized allocation/device, using a training design only for gradient probes.
3. Verify the streaming split parser returns the fixed 68 train / 14 validation IDs and stops before reading the test array.
4. Verify train/validation mask counts: long is `norm((target_pos-input_pos)*34.072) >= 4.0`; short and long masks are disjoint and cover all nodes; each design has both classes.
5. Verify both zero-update experts exactly reproduce their base checkpoint predictions within `1e-5 nm`; the classifier emits finite per-node logits, is invariant to a random rigid rotation of input geometry, and its disposable training-only gradient probe gives finite nonzero gradients to its classifier and encoder. Verify long/short losses give finite nonzero gradients on their selected nodes. No optimizer step may update a saved base checkpoint.
6. Confirm no test data file is opened and no training starts during preflight.

## After training

1. Verify the 12 runs (3 seeds × matched continuation/long/short/gate) each contain finite epoch 0–50 histories, exactly 50 × 68 optimizer steps, matching per-seed design-order hashes, and checkpoints selected by the prescribed validation metric.
2. Independently reload train/validation-only labels, recompute the fixed class masks, recompute every selected expert and gate metric, reconstruct hard/soft/oracle routing from saved per-role predictions and logits, and recompute all per-design/macro/motion-bin/classification metrics.
3. Verify hard/soft prediction archives contain exactly the 14 validation IDs. Test IDs must not be decoded, test files must not be opened, and test prediction keys/inference must remain absent.
4. Recompute the preregistered decision rule and compare the hard-routed ensemble to matched continuation, frozen localframe ensemble, and OnePass. Check the largest per-design regression.
5. Verify base checkpoints, source files, split, manifest, and train/validation source files have unchanged hashes. Verify all outputs are inside this phase directory.
6. Write `results/REPORT_ZH.md`, `summary.json`, and `verification.json`; update `progress.md`, `feature_list.json`, and `session-handoff.md` with actual result and any limitation.

After preflight and a fresh resource audit, run the runner only on that verified device. Then invoke the independent verifier. Do not claim the experiment complete if any required check fails.
