# Phase 9: long/short displacement mixture of experts

## Question and hypothesis

Can specialized local-frame displacement experts, selected by an input-only node classifier, reduce the fixed TALOS97 validation error compared with continuing the same localframe checkpoints on all nodes?

Phase 7 found that nodes with target displacement at least 4 nm make up 9.9% of validation nodes but account for about 32% of OnePass pooled squared error. The localframe ensemble improves their direction estimate but predicts only 1.646 nm mean displacement against a 4.936 nm target mean. This phase tests whether a large-displacement expert and a short-displacement expert, combined by a learned gate, address that failure.

## Fixed split and data boundary

- Use the existing endpoint-v1 split: 68 train and 14 validation designs. Parse `split.json` only through the validation array and stop before decoding the test IDs.
- The class boundary is fixed at target displacement norm `>= 4.0 nm` (long expert) versus `< 4.0 nm` (short expert). This is the Phase 7 audit boundary, fixed before this implementation. Labels define masks only for training loss and validation diagnostics; gate inputs are source-only geometric features.
- Exploratory counts from the fixed split: 58,662 / 585,070 training nodes (10.03%) and 11,701 / 118,342 validation nodes (9.89%) are in the long class. All training and validation designs contain both classes.
- Open source inputs and target labels for train and validation designs only. Do not open test inputs/labels, decode test IDs, enumerate prediction archive keys, or run test inference.

## Models and training

For seeds 11, 22, and 33, use each seed's validation-selected `localframe_2m` checkpoint (`frame_{seed}.pt`, selected epochs 48/64/50) as the initialization for four independent arms:

1. **Matched continuation control:** the ordinary BasisNet, trained on every node.
2. **Long expert:** same BasisNet, trained only on nodes whose target displacement norm is at least 4 nm.
3. **Short expert:** same BasisNet, trained only on nodes below 4 nm.
4. **Gate classifier:** same scalar encoder initialized from that checkpoint, with a new one-logit head, trained to classify long versus short from input-only features.

All arms get 50 epochs, one complete design and one optimizer step per train design per epoch, AdamW (`lr=1e-3`, `weight_decay=1e-4`), gradient clipping at 5, and identical per-seed design order. Expert losses are mean squared 3D displacement error over the selected class within each design. The gate uses weighted binary cross-entropy with a training-only positive weight `N_short/N_long`; at inference, subtract `log(positive_weight)` from logits before sigmoid to recover a prior-corrected long probability. No validation or test statistics enter training normalization or class weights.

Select each continuation checkpoint by full validation macro RMSD; each expert checkpoint by macro RMSD over the matching true validation class; and the gate checkpoint by validation prior-corrected binary log loss. Epoch 0 is eligible for expert/control selection. The gate never uses validation class labels as model inputs.

## Evaluation

Primary candidate: hard routing at corrected long probability `>= 0.5`, selecting the long or short expert prediction per node. Also report (without validation tuning): probability-weighted soft routing, always-long, always-short, and a validation-label oracle that selects the corresponding expert from the true class. The oracle is diagnostic only and is not a deployable result.

Report per-design and macro validation RMSD, motion-bin errors, long-class precision/recall/F1/AUPRC/Brier score, expert-specific class RMSDs, pooled and per-design error, and per-seed and three-seed ensemble results. Compare against:

- the three-seed matched full-node continuation control;
- the frozen three-seed `localframe_2m` ensemble (Phase 7 validation macro RMSD 2.15703061 nm);
- frozen OnePass (2.25108691 nm).

The mixture has three models per seed, so it costs more inference and has three times the parameters of one BasisNet seed. State this capacity/compute difference explicitly; no causal claim about routing independent of added capacity is allowed.

Call the hard-routed ensemble promising only if it improves at least 0.05 nm over the matched-control ensemble, improves over the frozen localframe ensemble, and no validation design regresses by more than 0.20 nm versus the matched continuation. Report these conditions separately and do not imply that passing them reaches the approximately 1.2 nm overall target.

## Provenance and outputs

- Preserve every source model and checkpoint. Store all new code, logs, checkpoints, histories, predictions, manifests, and reports under this phase directory.
- Before and after the run, hash the runner, verifier, model source, split/manifest, train/validation input and label caches, and three frozen base checkpoints.
- Keep an explicit access manifest listing only train and validation IDs and files. Independent verification must recompute masks, selected expert/gate metrics, routed validation predictions, classification metrics, aggregates, and hashes from saved artifacts.
- Do not submit a new Slurm job. Before execution, perform a fresh resource check and run preflight on a currently authorized/available GPU. Never use `gpu29` for a high-memory run.
