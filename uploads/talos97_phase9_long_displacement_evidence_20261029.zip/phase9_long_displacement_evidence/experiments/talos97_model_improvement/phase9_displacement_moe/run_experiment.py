#!/usr/bin/env python3
"""Train and evaluate the preregistered long/short displacement mixture."""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
import platform
import random
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import scipy
import torch
from torch import nn
from torch.nn import functional as F

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE_DIR = ROOT / "experiments/talos97_localframe_2m"
DATA = ROOT / "experiments/talos97_endpoint_v1/data"
BASE_CHECKPOINTS = BASE_DIR / "checkpoints"
RUNS = HERE / "runs"
RESULTS = HERE / "results"
NM = 40.0 * 0.8518
LONG_THRESHOLD_NM = 4.0
SEEDS = (11, 22, 33)
ROLES = ("control", "long", "short", "gate")
EPOCHS = 50
WIDTH = 346

_model_spec = importlib.util.spec_from_file_location("phase9_localframe_model", BASE_DIR / "model.py")
if _model_spec is None or _model_spec.loader is None:
    raise RuntimeError("cannot import the frozen localframe model source")
_model_module = importlib.util.module_from_spec(_model_spec)
sys.modules[_model_spec.name] = _model_module
_model_spec.loader.exec_module(_model_module)
BasisNet = _model_module.BasisNet
geometry = _model_module.geometry

SOURCE_PATHS = (
    HERE / "SPEC.md",
    HERE / "EXPECTED_VERIFICATION.md",
    HERE / "run_experiment.py",
    HERE / "verify_results.py",
    BASE_DIR / "model.py",
    BASE_DIR / "run_full97.py",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def read_json_string_after_quote(stream) -> str:
    while (leading := stream.read(1)) and leading.isspace():
        pass
    if leading != '"':
        raise ValueError(f"expected quoted JSON key, got {leading!r}")
    chars = ['"']
    escaped = False
    while True:
        item = stream.read(1)
        if not item:
            raise ValueError("truncated split key")
        chars.append(item)
        if escaped:
            escaped = False
        elif item == "\\":
            escaped = True
        elif item == '"':
            return json.loads("".join(chars))


def expect_char(stream, expected: str) -> None:
    while (char := stream.read(1)) and char.isspace():
        pass
    if char != expected:
        raise ValueError(f"expected {expected!r}, got {char!r}")


def read_id_list(stream) -> list[str]:
    expect_char(stream, "[")
    values: list[str] = []
    while True:
        while (char := stream.read(1)) and char.isspace():
            pass
        if char == "]":
            return values
        if char != '"':
            raise ValueError(f"expected JSON string or array end, got {char!r}")
        chars = ['"']
        escaped = False
        while True:
            item = stream.read(1)
            if not item:
                raise ValueError("truncated split ID")
            chars.append(item)
            if escaped:
                escaped = False
            elif item == "\\":
                escaped = True
            elif item == '"':
                values.append(json.loads("".join(chars)))
                break
        while (delimiter := stream.read(1)) and delimiter.isspace():
            pass
        if delimiter == "]":
            return values
        if delimiter != ",":
            raise ValueError(f"expected comma or array end, got {delimiter!r}")


def read_train_validation_ids(path: Path) -> tuple[list[str], list[str]]:
    """Read train and validation arrays, returning before the test key/value."""
    with path.open("r", encoding="utf-8") as stream:
        expect_char(stream, "{")
        key = read_json_string_after_quote(stream)
        if key != "train":
            raise ValueError(f"expected train first in split, got {key!r}")
        expect_char(stream, ":")
        train_ids = read_id_list(stream)
        expect_char(stream, ",")
        key = read_json_string_after_quote(stream)
        if key != "validation":
            raise ValueError(f"expected validation second in split, got {key!r}")
        expect_char(stream, ":")
        validation_ids = read_id_list(stream)
        return train_ids, validation_ids


def load_design(ident: str, device: torch.device) -> dict[str, Any]:
    input_path = DATA / "inputs" / f"{ident}.npz"
    with np.load(input_path) as archive:
        raw = {key: np.asarray(archive[key]) for key in archive.files}
    s, basis, frames = geometry(raw, multiscale=True)
    with np.load(DATA / "labels" / f"{ident}.npz") as archive:
        target_pos = np.asarray(archive["target_pos"], dtype=np.float32)
    if target_pos.shape != raw["pos"].shape:
        raise ValueError(f"input/target shape mismatch for {ident}")
    target_delta = (target_pos - raw["pos"]) * NM
    magnitudes = np.linalg.norm(target_delta, axis=1)
    long_mask = magnitudes >= LONG_THRESHOLD_NM
    if not bool(long_mask.any()) or bool(long_mask.all()):
        raise ValueError(f"both displacement classes are required in {ident}")
    return {
        "raw": raw,
        "s": torch.as_tensor(s, dtype=torch.float32, device=device),
        "B": torch.as_tensor(basis, dtype=torch.float32, device=device),
        "R": torch.as_tensor(frames, dtype=torch.float32, device=device),
        "source_pos": torch.as_tensor(raw["pos"], dtype=torch.float32, device=device),
        "target_delta_nm": torch.as_tensor(target_delta, dtype=torch.float32, device=device),
        "long_mask": torch.as_tensor(long_mask, dtype=torch.bool, device=device),
    }


class GateClassifier(BasisNet):
    """Input-only scalar classifier initialized from a frame checkpoint."""

    def __init__(self, state: dict[str, torch.Tensor], k: int):
        super().__init__(state["mean"], state["std"], k=k, width=WIDTH, variant="frame")
        self.head = nn.Linear(WIDTH * 3, 1)
        nn.init.xavier_uniform_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def load_encoder_state(self, state: dict[str, torch.Tensor]) -> None:
        encoder_state = {key: value for key, value in state.items() if not key.startswith("head.")}
        missing, unexpected = self.load_state_dict(encoder_state, strict=False)
        if set(missing) != {"head.weight", "head.bias"} or unexpected:
            raise ValueError(f"gate encoder checkpoint mismatch: missing={missing}, unexpected={unexpected}")

    def forward(self, s: torch.Tensor, B: torch.Tensor | None = None, R: torch.Tensor | None = None) -> torch.Tensor:
        _, hidden = self.encode(s)
        return self.head(hidden).squeeze(-1)


def base_checkpoint(seed: int) -> dict[str, Any]:
    path = BASE_CHECKPOINTS / f"frame_{seed}.pt"
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    if checkpoint.get("variant") != "frame" or int(checkpoint.get("seed", -1)) != seed:
        raise ValueError(f"unexpected base checkpoint metadata: {path}")
    return checkpoint


def make_model(seed: int, role: str, init_seed: int | None = None) -> nn.Module:
    checkpoint = base_checkpoint(seed)
    if role == "gate":
        if init_seed is not None:
            torch.manual_seed(init_seed)
        model = GateClassifier(checkpoint["state"], int(checkpoint["k"]))
        model.load_encoder_state(checkpoint["state"])
    else:
        model = BasisNet(
            checkpoint["state"]["mean"], checkpoint["state"]["std"],
            k=int(checkpoint["k"]), width=WIDTH, variant="frame",
        )
        model.load_state_dict(checkpoint["state"], strict=True)
    return model


def rmsd(prediction: np.ndarray, target: np.ndarray, mask: np.ndarray | None = None) -> float:
    if mask is not None:
        prediction, target = prediction[mask], target[mask]
    if len(target) == 0:
        return float("nan")
    return float(np.sqrt(np.mean(np.sum((prediction.astype(np.float64) - target.astype(np.float64)) ** 2, axis=-1))))


def average_precision(labels: np.ndarray, scores: np.ndarray) -> float:
    labels = labels.astype(bool)
    positives = int(labels.sum())
    if positives == 0:
        return float("nan")
    order = np.argsort(-scores, kind="mergesort")
    sorted_labels = labels[order]
    tp = np.cumsum(sorted_labels)
    fp = np.cumsum(~sorted_labels)
    precision = tp / np.maximum(tp + fp, 1)
    recall = tp / positives
    previous = np.concatenate(([0.0], recall[:-1]))
    return float(np.sum((recall - previous) * precision))


def classifier_metrics(logits: np.ndarray, labels: np.ndarray, pos_weight: float) -> dict[str, float]:
    corrected = logits.astype(np.float64) - math.log(pos_weight)
    probability = 1.0 / (1.0 + np.exp(-np.clip(corrected, -40, 40)))
    predicted = probability >= 0.5
    labels = labels.astype(bool)
    tp = int(np.sum(predicted & labels))
    fp = int(np.sum(predicted & ~labels))
    fn = int(np.sum(~predicted & labels))
    tn = int(np.sum(~predicted & ~labels))
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    brier = float(np.mean((probability - labels.astype(np.float64)) ** 2))
    log_loss = float(np.mean(np.logaddexp(0.0, corrected) - labels * corrected))
    return {
        "accuracy": float((tp + tn) / max(tp + tn + fp + fn, 1)),
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(2 * precision * recall / max(precision + recall, 1e-15)),
        "auprc": average_precision(labels, probability),
        "brier": brier,
        "log_loss": log_loss,
        "positive_count": int(labels.sum()),
        "predicted_positive_count": int(predicted.sum()),
        "long_probability": probability.astype(np.float32),
    }


def evaluate_regressor(model: nn.Module, role: str, designs: dict[str, dict[str, Any]], ids: list[str]) -> tuple[float, dict[str, Any]]:
    model.eval()
    metrics: dict[str, Any] = {}
    with torch.no_grad():
        for ident in ids:
            design = designs[ident]
            prediction = model(design["s"], design["B"], design["R"])
            pred_np = prediction.detach().cpu().numpy().astype(np.float32)
            target = design["target_delta_nm"].detach().cpu().numpy().astype(np.float32)
            long_mask = design["long_mask"].detach().cpu().numpy()
            if role == "long":
                score = rmsd(pred_np, target, long_mask)
            elif role == "short":
                score = rmsd(pred_np, target, ~long_mask)
            else:
                score = rmsd(pred_np, target)
            metrics[ident] = {"selection_metric": score, "prediction": pred_np}
    return float(np.mean([metrics[ident]["selection_metric"] for ident in ids])), metrics


def evaluate_gate(model: GateClassifier, designs: dict[str, dict[str, Any]], ids: list[str], pos_weight: float) -> tuple[float, dict[str, Any]]:
    model.eval()
    metrics: dict[str, Any] = {}
    with torch.no_grad():
        for ident in ids:
            design = designs[ident]
            logits = model(design["s"]).detach().cpu().numpy().astype(np.float32)
            labels = design["long_mask"].detach().cpu().numpy()
            result = classifier_metrics(logits, labels, pos_weight)
            result["logits"] = logits
            metrics[ident] = result
    return float(np.mean([metrics[ident]["log_loss"] for ident in ids])), metrics


def selected_metric(role: str, model: nn.Module, designs: dict[str, dict[str, Any]], validation_ids: list[str], pos_weight: float):
    if role == "gate":
        return evaluate_gate(model, designs, validation_ids, pos_weight)
    return evaluate_regressor(model, role, designs, validation_ids)


def save_prediction_archive(path: Path, values: dict[str, np.ndarray]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **values)


def run_role(seed: int, role: str, designs: dict[str, dict[str, Any]], train_ids: list[str], validation_ids: list[str], pos_weight: float, device: torch.device) -> dict[str, Any]:
    run_dir = RUNS / f"seed{seed}_{role}"
    run_dir.mkdir(parents=True, exist_ok=True)
    history_path = run_dir / "history.jsonl"
    if history_path.exists() or (run_dir / "best.pt").exists():
        raise FileExistsError(f"refusing to overwrite existing run directory: {run_dir}")
    arm_seed = seed + {"control": 1000, "long": 2000, "short": 3000, "gate": 4000}[role]
    random.seed(arm_seed)
    np.random.seed(arm_seed)
    torch.manual_seed(arm_seed)
    torch.cuda.manual_seed_all(arm_seed)
    model = make_model(seed, role, init_seed=arm_seed).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    order_rng = np.random.default_rng(seed)
    best_metric = float("inf")
    best_epoch = -1
    best_state: dict[str, torch.Tensor] | None = None
    best_eval: dict[str, Any] = {}
    step_count = 0
    start_time = time.time()

    def evaluate_epoch(epoch: int, train_loss: float | None = None, gradient_norm: float | None = None, order_hash: str | None = None) -> None:
        nonlocal best_metric, best_epoch, best_state, best_eval
        metric, evaluated = selected_metric(role, model, designs, validation_ids, pos_weight)
        row: dict[str, Any] = {
            "seed": seed,
            "role": role,
            "epoch": epoch,
            "validation_selection_metric": metric,
            "validation_macro_rmsd_nm": metric if role != "gate" else None,
            "train_loss": train_loss,
            "mean_gradient_norm": gradient_norm,
            "train_order_sha256": order_hash,
        }
        with history_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, allow_nan=False) + "\n")
        if metric < best_metric:
            best_metric = metric
            best_epoch = epoch
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            best_eval = evaluated

    model.eval()
    evaluate_epoch(0)
    for epoch in range(1, EPOCHS + 1):
        model.train()
        epoch_ids = [str(value) for value in order_rng.permutation(train_ids)]
        order_hash = hashlib.sha256("\n".join(epoch_ids).encode()).hexdigest()
        losses: list[float] = []
        grad_norms: list[float] = []
        for ident in epoch_ids:
            design = designs[ident]
            target = design["target_delta_nm"]
            optimizer.zero_grad(set_to_none=True)
            if role == "gate":
                logits = model(design["s"])
                labels = design["long_mask"].to(dtype=torch.float32)
                loss = F.binary_cross_entropy_with_logits(
                    logits, labels, pos_weight=torch.tensor(pos_weight, dtype=logits.dtype, device=device)
                )
            else:
                prediction = model(design["s"], design["B"], design["R"])
                squared_error = (prediction - target).square()
                if role == "long":
                    mask = design["long_mask"]
                    loss = squared_error[mask].mean()
                elif role == "short":
                    mask = ~design["long_mask"]
                    loss = squared_error[mask].mean()
                else:
                    loss = squared_error.mean()
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError(f"non-finite loss for seed={seed} role={role} epoch={epoch} design={ident}")
            loss.backward()
            gradient_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            if not bool(torch.isfinite(gradient_norm)):
                raise FloatingPointError(f"non-finite gradient for seed={seed} role={role} epoch={epoch} design={ident}")
            optimizer.step()
            step_count += 1
            losses.append(float(loss.detach().item()))
            grad_norms.append(float(gradient_norm.detach().item()))
        evaluate_epoch(epoch, float(np.mean(losses)), float(np.mean(grad_norms)), order_hash)
        status = {
            "seed": seed,
            "role": role,
            "epoch": epoch,
            "epochs_total": EPOCHS,
            "optimizer_steps": step_count,
            "best_epoch": best_epoch,
            "best_validation_selection_metric": best_metric,
            "elapsed_seconds": time.time() - start_time,
            "complete": epoch == EPOCHS,
        }
        atomic_json(run_dir / "status.json", status)
        if epoch == 1 or epoch % 10 == 0 or epoch == EPOCHS:
            print(f"{role} seed={seed} epoch={epoch} best={best_metric:.6f} loss={np.mean(losses):.6f}", flush=True)

    if best_state is None or best_epoch < 0:
        raise RuntimeError(f"no selected checkpoint for seed={seed} role={role}")
    checkpoint_path = run_dir / "best.pt"
    torch.save({"state": best_state, "seed": seed, "role": role, "best_epoch": best_epoch,
                "best_validation_selection_metric": best_metric, "pos_weight": pos_weight if role == "gate" else None}, checkpoint_path)
    prediction_path = run_dir / ("validation_logits.npz" if role == "gate" else "validation_predictions.npz")
    selected_values = {
        ident: np.asarray(best_eval[ident]["logits" if role == "gate" else "prediction"], dtype=np.float32)
        for ident in validation_ids
    }
    save_prediction_archive(prediction_path, selected_values)
    per_design_path = run_dir / "per_design_validation.csv"
    with per_design_path.open("w", newline="", encoding="utf-8") as stream:
        if role == "gate":
            fields = ["design", "seed", "role", "log_loss", "accuracy", "precision", "recall", "f1", "auprc", "brier", "positive_count", "predicted_positive_count"]
        else:
            fields = ["design", "seed", "role", "selection_metric", "all_node_rmsd_nm", "long_node_rmsd_nm", "short_node_rmsd_nm"]
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for ident in validation_ids:
            if role == "gate":
                item = best_eval[ident]
                writer.writerow({"design": ident, "seed": seed, "role": role,
                                 **{key: item[key] for key in fields if key not in ("design", "seed", "role")}})
            else:
                item = best_eval[ident]
                prediction = np.asarray(item["prediction"])
                design = designs[ident]
                target = design["target_delta_nm"].detach().cpu().numpy()
                long_mask = design["long_mask"].detach().cpu().numpy()
                writer.writerow({"design": ident, "seed": seed, "role": role,
                                 "selection_metric": item["selection_metric"],
                                 "all_node_rmsd_nm": rmsd(prediction, target),
                                 "long_node_rmsd_nm": rmsd(prediction, target, long_mask),
                                 "short_node_rmsd_nm": rmsd(prediction, target, ~long_mask)})
    status.update({
        "complete": True,
        "best_epoch": best_epoch,
        "best_validation_selection_metric": best_metric,
        "best_checkpoint_sha256": sha256(checkpoint_path),
        "validation_archive_sha256": sha256(prediction_path),
        "optimizer_steps": step_count,
    })
    atomic_json(run_dir / "status.json", status)
    return {
        "seed": seed,
        "role": role,
        "best_epoch": best_epoch,
        "best_validation_selection_metric": best_metric,
        "optimizer_steps": step_count,
        "elapsed_seconds": time.time() - start_time,
        "best_checkpoint_sha256": sha256(checkpoint_path),
        "validation_archive_sha256": sha256(prediction_path),
    }


def collect_hashes(train_ids: list[str], validation_ids: list[str]) -> dict[str, Any]:
    selected_ids = train_ids + validation_ids
    return {
        "split_sha256": sha256(DATA / "split.json"),
        "dataset_manifest_sha256": sha256(DATA / "manifest.json"),
        "selected_input_label_sha256": {
            str(path.resolve()): sha256(path)
            for ident in selected_ids
            for path in (DATA / "inputs" / f"{ident}.npz", DATA / "labels" / f"{ident}.npz")
        },
        "base_checkpoint_sha256": {str(seed): sha256(BASE_CHECKPOINTS / f"frame_{seed}.pt") for seed in SEEDS},
        "source_sha256": {str(path.resolve()): sha256(path) for path in SOURCE_PATHS},
    }


def rotate_raw(raw: dict[str, np.ndarray], rotation: np.ndarray) -> dict[str, np.ndarray]:
    rotated = dict(raw)
    rotated["pos"] = raw["pos"] @ rotation.T
    rotated["rotation"] = np.einsum("ij,njk->nik", rotation, raw["rotation"])
    return rotated


def preflight(device: torch.device, train_ids: list[str], validation_ids: list[str]) -> dict[str, Any]:
    before = {str(seed): sha256(BASE_CHECKPOINTS / f"frame_{seed}.pt") for seed in SEEDS}
    ident = train_ids[0]
    design = load_design(ident, device)
    base = make_model(11, "control").to(device).eval()
    long_model = make_model(11, "long").to(device).eval()
    short_model = make_model(11, "short").to(device).eval()
    gate = make_model(11, "gate", init_seed=9911).to(device).eval()
    with torch.no_grad():
        base_prediction = base(design["s"], design["B"], design["R"])
        long_prediction = long_model(design["s"], design["B"], design["R"])
        short_prediction = short_model(design["s"], design["B"], design["R"])
        logits = gate(design["s"])
    long_init_error = float(torch.linalg.vector_norm(base_prediction - long_prediction, dim=-1).max().item())
    short_init_error = float(torch.linalg.vector_norm(base_prediction - short_prediction, dim=-1).max().item())
    if not bool(torch.isfinite(logits).all()):
        raise FloatingPointError("classifier logits are non-finite")

    # A proper global rotation must leave the invariant gate probabilities unchanged.
    q = np.asarray([[0.0, -1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]], dtype=np.float32)
    rotated_raw = rotate_raw(design["raw"], q)
    sr, _, _ = geometry(rotated_raw, multiscale=True)
    with torch.no_grad():
        rotated_logits = gate(torch.as_tensor(sr, dtype=torch.float32, device=device))
    rotation_error = float((rotated_logits - logits).abs().max().item())

    # Disposable gradient probes only; no optimizer step and no saved state is changed.
    gradient_sums: dict[str, float] = {}
    target = design["target_delta_nm"]
    long_mask = design["long_mask"]
    for role, probe in (("long", make_model(11, "long").to(device).train()),
                        ("short", make_model(11, "short").to(device).train())):
        pred = probe(design["s"], design["B"], design["R"])
        mask = long_mask if role == "long" else ~long_mask
        loss = (pred[mask] - target[mask]).square().mean()
        loss.backward()
        grads = [p.grad for p in probe.parameters() if p.grad is not None]
        gradient_sums[role] = float(sum(g.abs().sum().item() for g in grads))
        if not grads or not all(bool(torch.isfinite(g).all()) for g in grads):
            raise FloatingPointError(f"invalid {role} expert gradient probe")
    gate_probe = make_model(11, "gate", init_seed=9911).to(device).train()
    probe_logits = gate_probe(design["s"])
    gate_loss = F.binary_cross_entropy_with_logits(probe_logits, long_mask.float())
    gate_loss.backward()
    gate_grads = [p.grad for p in gate_probe.parameters() if p.grad is not None]
    gradient_sums["gate"] = float(sum(g.abs().sum().item() for g in gate_grads))
    if not gate_grads or not all(bool(torch.isfinite(g).all()) for g in gate_grads):
        raise FloatingPointError("invalid gate gradient probe")
    after = {str(seed): sha256(BASE_CHECKPOINTS / f"frame_{seed}.pt") for seed in SEEDS}
    checks = {
        "fixed_split_counts": len(train_ids) == 68 and len(validation_ids) == 14,
        "base_checkpoint_predictions_reproduced_by_both_experts": max(long_init_error, short_init_error) < 1e-5,
        "gate_logits_finite": bool(torch.isfinite(logits).all()),
        "gate_rotation_invariant": rotation_error < 2e-4,
        "expert_and_gate_gradients_finite_nonzero": all(np.isfinite(v) and v > 0 for v in gradient_sums.values()),
        "base_checkpoints_unchanged": before == after,
        "optimizer_steps": 0,
        "test_ids_decoded": False,
        "test_files_opened": False,
    }
    return {
        "passed": all(value for key, value in checks.items() if isinstance(value, bool) and key not in ("test_ids_decoded", "test_files_opened")),
        "checks": checks,
        "device": str(device),
        "probe_design": ident,
        "train_design_count": len(train_ids),
        "validation_design_count": len(validation_ids),
        "long_init_max_node_error_nm": long_init_error,
        "short_init_max_node_error_nm": short_init_error,
        "classifier_rotation_logit_max_error": rotation_error,
        "gradient_abs_sums": gradient_sums,
        "base_checkpoints_sha256_before": before,
        "base_checkpoints_sha256_after": after,
        "optimizer_steps": 0,
        "test_ids_decoded": False,
        "test_files_opened": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(2)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    if device.type == "cuda":
        torch.cuda.init()
        print("DEVICE", torch.cuda.get_device_name(device), flush=True)

    train_ids, validation_ids = read_train_validation_ids(DATA / "split.json")
    if len(train_ids) != 68 or len(validation_ids) != 14:
        raise ValueError("unexpected train/validation split")
    if len(set(train_ids + validation_ids)) != 82:
        raise ValueError("train and validation IDs overlap")
    if args.preflight_only:
        result = preflight(device, train_ids, validation_ids)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["passed"] else 1

    if (RESULTS / "summary.json").exists() or RUNS.exists() and any(RUNS.iterdir()):
        raise FileExistsError("phase outputs already exist; refusing to overwrite an experiment")
    RESULTS.mkdir(parents=True, exist_ok=True)
    RUNS.mkdir(parents=True, exist_ok=True)
    preflight_result = preflight(device, train_ids, validation_ids)
    atomic_json(RESULTS / "preflight.json", preflight_result)
    if not preflight_result["passed"]:
        raise RuntimeError("preflight failed; training was not started")

    access_ids = train_ids + validation_ids
    designs = {ident: load_design(ident, device) for ident in access_ids}
    train_long = sum(int(designs[ident]["long_mask"].sum().item()) for ident in train_ids)
    train_nodes = sum(int(len(designs[ident]["long_mask"])) for ident in train_ids)
    if train_long <= 0 or train_long >= train_nodes:
        raise ValueError("invalid training class counts")
    pos_weight = float((train_nodes - train_long) / train_long)
    hashes_before = collect_hashes(train_ids, validation_ids)

    run_summaries: list[dict[str, Any]] = []
    # Each role uses identical per-seed training design orders.
    for seed in SEEDS:
        for role in ROLES:
            run_summaries.append(run_role(seed, role, designs, train_ids, validation_ids, pos_weight, device))

    # Frozen localframe validation ensemble, reproduced without opening any test artifact.
    baseline_values: dict[str, np.ndarray] = {}
    with torch.no_grad():
        for seed in SEEDS:
            base = make_model(seed, "control").to(device).eval()
            for ident in validation_ids:
                design = designs[ident]
                baseline_values[f"seed{seed}__{ident}"] = base(design["s"], design["B"], design["R"]).cpu().numpy().astype(np.float32)
    save_prediction_archive(RESULTS / "frozen_localframe_validation_predictions.npz", baseline_values)

    hashes_after = collect_hashes(train_ids, validation_ids)
    access_manifest = {
        "split_parser_stopped_after": "validation",
        "train_design_ids": train_ids,
        "validation_design_ids": validation_ids,
        "input_design_ids_opened": access_ids,
        "label_design_ids_opened": access_ids,
        "test_ids_decoded": False,
        "test_input_files_opened": False,
        "test_label_files_opened": False,
        "test_prediction_keys_read": False,
        "test_inference": False,
    }
    summary = {
        "protocol": {"seeds": list(SEEDS), "roles_per_seed": list(ROLES), "epochs": EPOCHS,
                     "long_threshold_nm": LONG_THRESHOLD_NM, "positive_weight_train_only": pos_weight,
                     "learning_rate": 1e-3, "weight_decay": 1e-4, "gradient_clip": 5.0,
                     "optimizer_steps_per_run": EPOCHS * len(train_ids),
                     "total_optimizer_steps": len(SEEDS) * len(ROLES) * EPOCHS * len(train_ids)},
        "train_ids": train_ids,
        "validation_ids": validation_ids,
        "class_counts": {"train_nodes": train_nodes, "train_long_nodes": train_long,
                         "train_long_fraction": train_long / train_nodes,
                         "validation_nodes": sum(len(designs[ident]["long_mask"]) for ident in validation_ids),
                         "validation_long_nodes": sum(int(designs[ident]["long_mask"].sum().item()) for ident in validation_ids)},
        "runs": run_summaries,
        "data_access_manifest": access_manifest,
        "hashes_before": hashes_before,
        "hashes_after": hashes_after,
        "torch_version": torch.__version__,
        "numpy_version": np.__version__,
        "scipy_version": scipy.__version__,
        "python_version": platform.python_version(),
        "device": torch.cuda.get_device_name(device) if device.type == "cuda" else str(device),
        "test_ids_decoded": False,
        "test_input_files_opened": False,
        "test_label_files_opened": False,
        "test_prediction_keys_read": False,
        "test_inference": False,
        "original_checkpoints_modified": False,
        "output_paths": [str(path.resolve()) for path in HERE.rglob("*") if path.is_file()],
    }
    atomic_json(RESULTS / "summary.json", summary)
    print("TRAINING_COMPLETE", json.dumps({"runs": len(run_summaries), "total_optimizer_steps": summary["protocol"]["total_optimizer_steps"]}), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
