#!/usr/bin/env python3
"""Recompute held-out routing and metrics from selected artifacts."""
import csv
import json
import math
from pathlib import Path
import numpy as np
import run_experiment as r


def main():
    summary=json.loads((r.RESULTS/'summary.json').read_text())
    train, val=r.read_train_validation_ids(r.DATA/'split.json')
    weight=summary['protocol']['positive_weight_train_only']
    targets={}; masks={}
    for d in val:
        with np.load(r.DATA/'inputs'/f'{d}.npz') as a, np.load(r.DATA/'labels'/f'{d}.npz') as b:
            targets[d]=(b['target_pos'].astype(np.float32)-a['pos'])*r.NM
        masks[d]=np.linalg.norm(targets[d],axis=1)>=4
    checks={'split':len(train)==68 and len(val)==14 and summary['validation_ids']==val,
            'preflight':json.loads((r.RESULTS/'preflight.json').read_text())['passed'],
            'hashes':summary['hashes_before']==summary['hashes_after']==r.collect_hashes(train,val),
            'test_boundary':all(summary[k] is False for k in ('test_ids_decoded','test_input_files_opened','test_label_files_opened','test_prediction_keys_read','test_inference'))}
    predictions={}; gate_metrics=[]; selections=[]
    orders={}
    for seed in r.SEEDS:
        archives={}
        for role in r.ROLES:
            folder=r.RUNS/f'seed{seed}_{role}'
            status=json.loads((folder/'status.json').read_text())
            hist=[json.loads(x) for x in (folder/'history.jsonl').read_text().splitlines()]
            assert [x['epoch'] for x in hist]==list(range(51))
            assert status['complete'] and status['optimizer_steps']==3400
            assert all(np.isfinite(x['validation_selection_metric']) for x in hist)
            best=min(hist,key=lambda x:x['validation_selection_metric'])
            assert best['epoch']==status['best_epoch']
            assert r.sha256(folder/'best.pt')==status['best_checkpoint_sha256']
            path=folder/('validation_logits.npz' if role=='gate' else 'validation_predictions.npz')
            assert r.sha256(path)==status['validation_archive_sha256']
            with np.load(path) as a:
                assert set(a.files)==set(val)
                archives[role]={d:a[d].copy() for d in val}
            metrics=[]
            for d in val:
                p=archives[role][d]
                assert np.isfinite(p).all()
                if role=='gate':
                    m=r.classifier_metrics(p,masks[d],weight)
                    metrics.append(m['log_loss'])
                    gate_metrics.append({'seed':seed,'design':d,**{k:v for k,v in m.items() if k!='long_probability'}})
                else:
                    mask=masks[d] if role=='long' else ~masks[d] if role=='short' else None
                    metrics.append(r.rmsd(p,targets[d],mask))
            assert abs(np.mean(metrics)-best['validation_selection_metric'])<2e-6
            selections.append({'seed':seed,'role':role,'epoch':best['epoch'],'metric':float(np.mean(metrics))})
            orders[seed,role]=[x['train_order_sha256'] for x in hist[1:]]
        assert all(orders[seed,role]==orders[seed,'control'] for role in r.ROLES)
        for mode in ('control','long','short','hard','soft','oracle'):
            out={}
            for d in val:
                long=archives['long'][d]; short=archives['short'][d]
                prob=r.classifier_metrics(archives['gate'][d],masks[d],weight)['long_probability'][:,None]
                if mode in archives: p=archives[mode][d]
                elif mode=='hard': p=np.where(prob>=.5,long,short)
                elif mode=='soft': p=prob*long+(1-prob)*short
                else: p=np.where(masks[d][:,None],long,short)
                out[d]=p
            predictions[seed,mode]=out
            np.savez_compressed(r.RESULTS/f'seed{seed}_{mode}_validation.npz',**out)
    checks['selected_metrics_epochs_hashes_orders']=True
    with np.load(r.RESULTS/'frozen_localframe_validation_predictions.npz') as a:
        frozen={d:np.mean([a[f'seed{s}__{d}'] for s in r.SEEDS],axis=0) for d in val}
    ensembles={mode:{d:np.mean([predictions[s,mode][d] for s in r.SEEDS],axis=0) for d in val} for mode in ('control','long','short','hard','soft','oracle')}
    ensembles['frozen']=frozen
    metrics={}; bins=[]
    for mode, ps in ensembles.items():
        per={d:r.rmsd(ps[d],targets[d]) for d in val}
        metrics[mode]={'macro_rmsd_nm':float(np.mean(list(per.values()))),'per_design':per}
        for lo,hi in ((0,1),(1,2),(2,4),(4,float('inf'))):
            errors=[]; mags=[]
            for d in val:
                norm=np.linalg.norm(targets[d],axis=1); mask=(norm>=lo)&(norm<hi)
                errors.extend(np.sum((ps[d][mask]-targets[d][mask])**2,axis=1).tolist())
                mags.extend(np.linalg.norm(ps[d][mask],axis=1).tolist())
            bins.append({'mode':mode,'lower_nm':lo,'upper_nm':hi if np.isfinite(hi) else None,'nodes':len(errors),'rmsd_nm':float(np.sqrt(np.mean(errors))),'predicted_mean_displacement_nm':float(np.mean(mags))})
    improvement=metrics['control']['macro_rmsd_nm']-metrics['hard']['macro_rmsd_nm']
    maxreg=max(metrics['hard']['per_design'][d]-metrics['control']['per_design'][d] for d in val)
    promising=improvement>=.05 and metrics['hard']['macro_rmsd_nm']<metrics['frozen']['macro_rmsd_nm'] and maxreg<=.2
    result={'passed':all(checks.values()),'checks':checks,'ensemble_metrics':metrics,'motion_bins':bins,'gate_per_design_metrics':gate_metrics,'selected_checkpoints':selections,'hard_improvement_over_control_nm':improvement,'maximum_design_regression_nm':maxreg,'promising':promising,'oracle_uses_validation_labels':True}
    r.atomic_json(r.RESULTS/'verification.json',result)
    lines=['# 长短位移专家与门控集成实验','',f"独立核验：{'通过' if result['passed'] else '失败'}。3 seeds × control/long/short/gate，各 50 epochs；总计 40,800 optimizer steps。",'', '| 模型（三种子集成） | 验证宏 RMSD (nm) |','|---|---:|']
    for mode,m in metrics.items(): lines.append(f"| {mode} | {m['macro_rmsd_nm']:.6f} |")
    lines+=['',f'硬路由相对匹配 control 改善 {improvement:.6f} nm；最大逐设计回归 {maxreg:.6f} nm。预注册 promising 判断：{promising}。','', '长位移定义为目标位移 ≥4 nm，短位移为 <4 nm。两个专家只在各自类别上计算训练损失；门控只读取输入几何。门控采用训练集类别权重，并在推理前校正 logits。硬路由阈值固定 0.5，软路由未调参。oracle 直接使用验证类别，仅为诊断，不能部署。','', '相较单个模型，每个 seed 的集成使用三个独立模型，增加参数量与推理成本；普通 control 只含一个模型，因此不能把收益归因于路由本身。专家/门控以验证类别 RMSD / log loss 选 checkpoint，控制以完整验证宏 RMSD 选择。固定验证集已多次用于实验筛选，结果不是盲测。','', '原始 checkpoint、数据和训练源哈希保持一致；本实验训练/验证阶段没有读取测试输入、标签或预测。此前探索脚本曾解析 split 中的测试 ID 和已有 protocol 元数据，但未打开测试数据；因此不把整个会话表述为从未见过测试 ID。','', '## 位移分层','', '| 模型 | 位移区间下界 (nm) | 节点误差 RMS (nm) | 预测平均位移 (nm) |','|---|---:|---:|---:|']
    for x in bins:
        if x['mode'] in ('hard','control','frozen','oracle'): lines.append(f"| {x['mode']} | {x['lower_nm']} | {x['rmsd_nm']:.4f} | {x['predicted_mean_displacement_nm']:.4f} |")
    (r.RESULTS/'REPORT_ZH.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'passed':result['passed'],'metrics':{k:v['macro_rmsd_nm'] for k,v in metrics.items()},'improvement':improvement,'promising':promising},indent=2))
    assert result['passed']

if __name__=='__main__': main()
