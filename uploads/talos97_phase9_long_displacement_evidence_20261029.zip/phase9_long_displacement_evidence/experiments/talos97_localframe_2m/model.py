"""SE(3) geometric-basis endpoint regressor. Not a reproduction of PaiNN/DGNN.

All geometric preprocessing uses INPUTS ONLY. Graph filters are fixed, SIGN-like;
the learned part is a scalar MLP controlling equivariant vector bases.
Coordinates/targets passed to training are in nm. Frames are column bases.
"""
import numpy as np
import torch
from torch import nn
from scipy.sparse import coo_matrix

NM = 34.072


def geometry(a, multiscale=True):
    x = np.asarray(a['pos'], dtype=np.float64)
    x = x - x.mean(0)
    R = np.asarray(a['rotation'], dtype=np.float64)
    n = len(x)
    i, j = a['edge_index']
    et = a['edge_types']
    rel = x[j] - x[i]
    d = np.linalg.norm(rel, axis=1)
    vec = [x, R[:, :, 0], R[:, :, 1], R[:, :, 2]]
    scalars = [a['node_features'], np.linalg.norm(x, axis=1)[:, None]]
    for t in range(5):
        mask = et == t
        count = np.bincount(i[mask], minlength=n)
        denom = np.maximum(count, 1)
        mean = np.stack([np.bincount(i[mask], weights=rel[mask, k], minlength=n)
                         for k in range(3)], axis=1) / denom[:, None]
        vec.append(mean)
        avg_d = np.bincount(i[mask], weights=d[mask], minlength=n) / denom
        scalars.extend([count[:, None] / 10, avg_d[:, None]])
    # Fixed local diffusion: two hops, no labels or learned weights.
    deg = np.maximum(np.bincount(i, minlength=n), 1)
    P = coo_matrix((1. / deg[i], (i, j)), shape=(n, n)).tocsr()
    smooth = P @ x
    vec.extend([smooth - x, P @ smooth - x])
    # Domain membership is only a pooling index, not a numerical feature/embedding.
    _, dom = np.unique(a['domain_ids'], return_inverse=True)
    D = dom.max() + 1
    counts = np.bincount(dom)
    c = np.stack([np.bincount(dom, weights=x[:, k], minlength=D)
                  for k in range(3)], axis=1) / counts[:, None]
    si, sj = a['segment_edge_index']
    if max(si.max(), sj.max()) >= D:
        raise ValueError('Segment edges do not index the available domains')
    sd = np.maximum(np.bincount(si, minlength=D), 1)
    C = coo_matrix((1. / sd[si], (si, sj)), shape=(D, D)).tocsr()
    coarse = [c[dom] - x, (C @ c)[dom] - c[dom], (C @ C @ c)[dom] - c[dom]]
    cov = x.T @ x / n
    coarse += [x @ cov, x @ cov @ cov]
    vec.extend(coarse if multiscale else [np.zeros_like(x)] * len(coarse))
    B = np.stack(vec, axis=1)
    norms = np.linalg.norm(B, axis=2)
    # SO(3)-invariant local components; no raw laboratory xyz in scalar features.
    local = np.einsum('nka,nab->nkb', B, R)
    s = np.concatenate(scalars + [norms, local.reshape(n, -1)], axis=1)
    return s.astype('float32'), B.astype('float32'), R.astype('float32')


class BasisNet(nn.Module):
    def __init__(self, mean, std, k=16, width=346, variant='frame'):
        super().__init__()
        self.variant, self.k = variant, k
        self.register_buffer('mean', torch.as_tensor(mean).float())
        self.register_buffer('std', torch.as_tensor(std).float().clamp_min(.01))
        self.fc1 = nn.Linear(len(mean), width)
        self.fc2 = nn.Linear(width, width)
        self.residual_blocks = nn.ModuleList([nn.Sequential(nn.LayerNorm(width), nn.Linear(width, width), nn.SiLU(), nn.LayerNorm(width), nn.Linear(width, width)) for _ in range(8)])
        # Same scalar backbone; different readout sizes are reported, not hidden.
        out = 3 if variant == 'frame' else k
        self.head = nn.Linear(width * 3, out)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)
        self.gate = nn.Linear(width * 3, 1) if variant in ('gate', 'no_multiscale') else None
        if self.gate is not None:
            nn.init.zeros_(self.gate.weight)
            nn.init.zeros_(self.gate.bias)

    def encode(self, s):
        h0 = (s - self.mean) / self.std
        h1 = torch.nn.functional.silu(self.fc1(h0))
        h2 = torch.nn.functional.silu(self.fc2(h1))
        for block in self.residual_blocks:
            h2 = h2 + block(h2)
        g = torch.cat([h2.mean(0), h2.max(0).values])
        h = torch.cat([h2, g.expand(len(s), -1)], axis=1)
        return [h0, h1, h2], h

    def readout(self, h, B, R, intervene=None):
        if intervene == 'zero_context':
            h = h.clone(); h[:, self.fc2.out_features:] = 0
        coeff = 8 * torch.tanh(self.head(h)) / np.sqrt(self.head.out_features)
        basis = R.transpose(1, 2) if self.variant == 'frame' else B
        if self.variant != 'raw' and self.variant != 'frame':
            basis = basis / (basis.square().sum(-1, keepdim=True) / 3 + 1e-6).sqrt()
        if intervene == 'half_norm':
            b = B * .5
            basis = b / (b.square().sum(-1, keepdim=True) / 3 + 1e-6).sqrt()
        if intervene == 'zero_vectors': basis = basis * 0
        if intervene in ('permute_vectors', 'common_permutation'):
            perm = torch.arange(basis.shape[1]-1, -1, -1)
            basis = basis[:, perm]
            if intervene == 'common_permutation': coeff = coeff[:, perm]
        if intervene == 'rotate_vectors':
            # Fixed proper 90-degree rotation, internal vectors only; OOD intervention.
            Q = basis.new_tensor([[0., -1, 0], [1, 0, 0], [0, 0, 1]])
            basis = basis @ Q.T
        delta = torch.einsum('nk,nka->na', coeff, basis)
        gate = torch.sigmoid(self.gate(h)) if self.gate is not None else None
        if gate is not None: delta = delta * gate
        delta = delta - delta.mean(0)
        return delta, coeff, basis, gate

    def forward(self, s, B, R, intervene=None, details=False):
        layers, h = self.encode(s)
        delta, coeff, basis, gate = self.readout(h, B, R, intervene)
        return (delta, layers, h, coeff, basis, gate) if details else delta


def load_inputs(root, design, multiscale=True):
    from pathlib import Path
    with np.load(Path(root) / 'inputs' / (design + '.npz')) as a:
        return geometry(a, multiscale)
