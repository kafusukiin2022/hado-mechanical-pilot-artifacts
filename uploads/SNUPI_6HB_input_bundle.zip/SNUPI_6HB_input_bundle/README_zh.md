# 6HB DNA 折纸：SNUPI 输入文件

检索与检查日期：2026-11-10。

## 选择结论

首选 `designs/Ex_6HB.json`，以及同名 `Ex_6HB.csv`。这是 SNUPI 官方 v2.01 发布包提供的 6HB 示例，原始字节保持不变。它本身就是 caDNAno legacy/v2 的 `name` + `vstrands` 格式，不需要从其他格式转换。

**验收边界：本次独立预检查通过；并未在本环境内通过 SNUPI 自身的 lattice/crossover 检查。** 本机启动 SNUPI v3.10 时缺少 MATLAB Runtime 的 `libmwlaunchermain.so`，在读取设计之前退出。官方手册提供该设计的模拟示例和预测结果，是兼容性的重要依据，但不等于本次、或你所用版本的实跑日志。

## 文件与结果

| 项目 | 结果 |
| --- | --- |
| 结构 | 6-helix bundle，6 根双螺旋 |
| 晶格选择 | Honeycomb，输入标记 `H` |
| 格式 | 原生 caDNAno legacy/v2 JSON |
| 独立导入 | scadnano `Design.from_cadnano_v2` 导入成功；识别为 Honeycomb、6 helices、29 strands |
| scaffold | 1 条线性链，776 nt（包括插入/缺失后的计数） |
| staple | 28 条，总计 776 nt；CSV 全部为 A/C/G/T |
| crossover | 5 条 scaffold + 64 条 staple 跨螺旋有向连接；此处按单个跨螺旋骨架连接计数，不按完整 Holliday junction 计数 |
| 连接检查 | 指针目标、前后链接互逆、链端点和方向均通过 |
| lattice 检查 | helix 行列坐标和编号奇偶性、Honeycomb 邻接通过 |
| crossover 检查 | 邻接螺旋、相同位置索引、caDNAno Honeycomb 21 位点周期与方向通过 |
| CSV 检查 | 28 条序列的 5′/3′ 端点、序列长度及拓扑覆盖一致 |
| SNUPI 自身运行 | 未完成，运行环境缺少 MATLAB Runtime |

本预检查针对这个传统 on-lattice 6HB，使用 caDNAno 的邻接规则和 crossover 表，并不复现 SNUPI 的内部解析器。它也不检验最终平衡形状、收敛、力学参数或实验折叠产率。该示例有插入设计；不要把“6HB”理解为保证完全笔直。

## 使用方法

1. 安装/使用 SNUPI 及与版本匹配的 MATLAB Runtime：SNUPI v2 对应 R2019a / 9.6；v3 对应 R2022b / 9.13。
2. 将本包的 `designs` 文件夹复制到 **SNUPI 可执行文件所在目录**。本包不含 SNUPI 可执行文件和 MATLAB Runtime。
3. 备份你现有的 `Input.txt`，再将本包 `Input.txt` 的这一行写入 SNUPI 正在读取的 `Input.txt`：

   ```text
   H    designs/Ex_6HB
   ```

   路径不加 `.json` 或 `.csv` 后缀。JSON 和 CSV 必须同目录、同基本文件名。
4. 使用你安装版本自带的默认设置运行 SNUPI。GUI 版本则选择 `Ex_6HB.json`、Honeycomb，并按需加载 `Ex_6HB.csv`。
5. 检查该次运行的日志，确认结构读取及 lattice/crossover 处理没有报错，然后再判断是否进入有限元求解、是否收敛。只有该日志才能给出你所用 SNUPI 版本的实际通过结论。

Linux v3 官方启动方式示例（Runtime 路径需换成实际安装路径）：

```bash
./run_SNUPI.sh /usr/local/MATLAB/MATLAB_Runtime/R2022b
```

基础静态结构分析的 CSV 是可选的；涉及序列相关参数、PDB/oxDNA 导出时应保留正确的序列文件。本包已提供匹配的 CSV。为减少版本差异，首先使用所装 SNUPI 版本自身的默认选项。本包 `configs/Default_SNUPI_v2.snp` 仅为官方 v2 默认配置的留档，不要求覆盖 v3 默认配置。

## 检查记录与来源

- `validation/preflight.py`：可复现的独立检查脚本。运行 `python validation/preflight.py`；若已安装 scadnano，也会执行 caDNAno v2 导入。脚本仅检查包内 `designs`。
- `validation/preflight_report.json`：本次对首选文件的检查结果和 SHA-256。
- `validation/runtime_attempt.txt`：本环境启动失败的实际记录，不是设计检查失败日志。
- `validation/other_candidates_screening.json`：另外三个候选文件的筛选记录；这些文件未作为可用输入随包交付。
- `Protocol_SNUPI_v2.pdf`：官方原始手册。PDF 第 3–5 页展示 Ex_6HB 的选择、Honeycomb 设置及模拟结果。
- `configs/Input_original_v2.txt`：官方原始示例清单，包含 `H ../EXAMPLE/Ex_6HB`。
- `provenance.json`：下载来源、仓库快照及文件校验和。

原始来源：

1. SNUPI 官方仓库：https://github.com/SSDL-SNU/SNUPI
2. 官方 v2.01 Linux 下载：https://raw.githubusercontent.com/SSDL-SNU/SNUPI/master/SNUPI_v2_01_linux.zip
   - 压缩包内 `EXAMPLE/Ex_6HB.json` 和 `EXAMPLE/Ex_6HB.csv`。
   - 官方 `Protocol.pdf`、`FILES/Input.txt` 和 `FILES/Default.snp`。
3. caDNAno2 Honeycomb 规则：https://github.com/douglaslab/cadnano2/blob/239ecc851407b64b44a8a4bdecdd5eb4848868f5/cadnano2/model/parts/honeycombpart.py
4. scadnano 文档：https://scadnano-python-package.readthedocs.io/en/latest/

另筛选了 Douglas lab pScaf 仓库的 `6hb-1512.json`、`6hb-2268.json`、`6hb-3024.json`。它们的 caDNAno v2 导入和 Honeycomb crossover 预检查通过，但配套 CSV 含 `?` 未指定碱基；1512 版本另有两条 staple 的 CSV 端点与 JSON 不一致。因此未选为本次可直接配对使用的首选。该筛除不表示它们不能在无序列模式下进行静态分析。

该次任务允许 6HB、正二十面体或长方形，故最终选择已有官方实例且通过本次独立预检查的 6HB。正二十面体虽有 SNUPI 论文分析先例，但本次没有获得并验证对应的同一输入文件，不作“已通过”推荐。

## 引用与原文件权利

官方文件来自上述作者公开发布包，其权利归原作者；本包没有为原始材料附加新许可。

使用 SNUPI 研究结果时，请遵循官方要求引用：Lee et al., *Rapid Computational Analysis of DNA Origami Assemblies at Near-Atomic Resolution*, ACS Nano 2021, DOI: https://doi.org/10.1021/acsnano.0c07717 。其他版本功能按官方仓库列出的对应论文引用。
