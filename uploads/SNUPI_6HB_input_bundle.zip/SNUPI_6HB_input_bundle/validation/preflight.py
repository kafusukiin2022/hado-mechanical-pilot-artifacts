#!/usr/bin/env python3
"""Independent caDNAno v2/Honeycomb preflight. NOT SNUPI's own validator.

Run from package root: python validation/preflight.py
Uses Python standard library; optionally imports scadnano if installed.
Crossover/neighbor tables follow caDNAno2 commit
239ecc851407b64b44a8a4bdecdd5eb4848868f5, model/parts/honeycombpart.py.
For these conventional on-lattice bundles only; do not use to reject free-form
wireframe designs with intentional nonlocal links.
"""
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EMPTY = [-1, -1, -1, -1]
LOW = {'scaf': [[1, 11], [8, 18], [4, 15]], 'stap': [[6], [13], [20]]}
HIGH = {'scaf': [[2, 12], [9, 19], [5, 16]], 'stap': [[7], [14], [0]]}


def inspect(path):
    data = json.loads(path.read_text())
    problems = []
    stats = Counter()
    helices = data['vstrands']
    hs = {h['num']: h for h in helices}
    assert len(hs) == len(helices), 'Duplicate helix number'
    assert len({(h['row'], h['col']) for h in helices}) == len(hs), 'Duplicate coordinate'
    lengths = {len(h['scaf']) for h in helices}
    assert len(lengths) == 1, 'Inconsistent helix array lengths'
    assert next(iter(lengths)) % 21 == 0, 'Not a 21-position honeycomb array'
    active = {st: {} for st in ['scaf', 'stap']}
    for h in helices:
        n, r, c = h['num'], h['row'], h['col']
        if n % 2 != (r+c) % 2:
            problems.append(['helix_parity', n, r, c])
        for key in ['scaf', 'stap', 'loop', 'skip']:
            assert len(h[key]) == next(iter(lengths)), f'{n}: {key} length mismatch'
        for st in active:
            for i, a in enumerate(h[st]):
                assert len(a) == 4 and all(isinstance(v, int) for v in a), 'Bad pointer record'
                if a != EMPTY:
                    active[st][(n, i)] = a
                    stats[st+'_nt'] += 1 + h['loop'][i] + h['skip'][i]
                    assert h['loop'][i] >= 0 and h['skip'][i] in [-1, 0], 'Bad indel'

    for st, bases in active.items():
        for (n, i), a in bases.items():
            h = hs[n]
            even = n % 2 == 0
            r, c = h['row'], h['col']
            neighbors = [(r,c+1),(r-1,c),(r,c-1)] if even else [(r,c-1),(r+1,c),(r,c+1)]
            # Tables refer to low/high member of a crossover pair. The outgoing
            # 3' link uses Low for even scaffold / odd staple helices.
            low = even if st == 'scaf' else not even
            table = LOW[st] if low else HIGH[st]
            for side in [0, 2]:
                dest = tuple(a[side:side+2])
                if dest == (-1, -1):
                    continue
                if dest not in bases:
                    problems.append(['missing_target', st, n, i, side, dest])
                elif tuple(bases[dest][2-side:4-side]) != (n, i):
                    problems.append(['nonreciprocal_link', st, n, i, side, dest])
            j, k = a[2:]
            if j >= 0 and j != n and j in hs:
                stats[st+'_crossover_links'] += 1
                rc = (hs[j]['row'], hs[j]['col'])
                if rc not in neighbors:
                    problems.append(['nonneighbor_crossover', st, n, i, j, k])
                elif i != k:
                    problems.append(['crossover_offset', st, n, i, j, k])
                elif i % 21 not in table[neighbors.index(rc)]:
                    problems.append(['crossover_phase', st, n, i, j, k])
                if h['skip'][i] or hs[j]['skip'][k]:
                    problems.append(['deletion_at_crossover', st, n, i, j, k])
            elif j == n:
                forward = even if st == 'scaf' else not even
                if k != i + (1 if forward else -1):
                    problems.append(['nonlocal_same_helix_link', st, n, i, j, k])
            if h['skip'][i] and (-1 in a):
                problems.append(['deletion_at_nick', st, n, i])

    strand_info = {}
    for st, bases in active.items():
        starts = [node for node, a in bases.items() if a[:2] == [-1, -1]]
        unseen = set(bases)
        strands = []
        for start in starts + sorted(bases):
            if start not in unseen:
                continue
            visited = set()
            cur, end, length = start, start, 0
            while cur in bases and cur not in visited:
                visited.add(cur)
                unseen.discard(cur)
                n, i = cur
                length += 1 + hs[n]['loop'][i] + hs[n]['skip'][i]
                end = cur
                cur = tuple(bases[cur][2:])
            circular = cur == start
            if cur not in [(-1, -1), start]:
                problems.append(['bad_strand_termination', st, start, cur])
            strands.append({'start': start, 'end': end, 'nt': length, 'circular': circular})
        strand_info[st] = strands
        stats[st+'_strands'] = len(strands)
        stats[st+'_circular_strands'] = sum(s['circular'] for s in strands)

    def coord(s):
        m = re.fullmatch(r'(\d+)\[(\d+)\]', s.strip())
        assert m, f'Bad CSV coordinate: {s}'
        return tuple(map(int, m.groups()))

    rows = list(csv.DictReader(path.with_suffix('.csv').open(newline='')))
    by_start = {tuple(s['start']): s for s in strand_info['stap']}
    used = set()
    for row in rows:
        start, end = coord(row['Start']), coord(row['End'])
        if start in used:
            problems.append(['csv_duplicate_start', start])
        used.add(start)
        strand = by_start.get(start)
        if strand is None:
            problems.append(['csv_start_missing', start])
        elif tuple(strand['end']) != end or strand['nt'] != int(row['Length']):
            problems.append(['csv_topology_mismatch', start, end, row['Length'], strand])
        seq = row['Sequence'].strip().upper()
        if len(seq) != int(row['Length']) or set(seq)-set('ACGT'):
            problems.append(['csv_sequence_or_length', start])
    if used != set(by_start):
        problems.append(['csv_coverage_mismatch', len(used), len(by_start)])
    stats['csv_staple_rows'] = len(rows)
    stats['paired_nt'] = sum(1+hs[n]['loop'][i]+hs[n]['skip'][i]
                             for n,i in set(active['scaf']) & set(active['stap']))
    stats['unpaired_scaf_nt'] = stats['scaf_nt']-stats['paired_nt']
    stats['unpaired_stap_nt'] = stats['stap_nt']-stats['paired_nt']
    parser = {'status': 'NOT_RUN', 'reason': 'Optional scadnano package not installed'}
    try:
        import scadnano as sc
    except ImportError:
        pass
    else:
        try:
            design = sc.Design.from_cadnano_v2(filename=str(path))
            parser = {'status': 'PASS', 'grid': str(design.grid),
                      'helices': len(design.helices), 'strands': len(design.strands)}
        except Exception as error:
            parser = {'status': 'FAIL', 'error': str(error)}
            problems.append(['cadnano_v2_parser_failure', str(error)])
    return {'file': path.name, 'lattice': 'Honeycomb (H)', 'helices': len(hs),
            'array_length': next(iter(lengths)), 'stats': dict(stats),
            'independent_preflight': 'PASS' if not problems else 'FAIL',
            'issues': problems, 'cadnano_v2_import': parser,
            'snupi_execution': 'NOT_RUN: MATLAB Runtime unavailable in this environment',
            'json_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'csv_sha256': hashlib.sha256(path.with_suffix('.csv').read_bytes()).hexdigest()}


if __name__ == '__main__':
    results = [inspect(p) for p in sorted((ROOT/'designs').glob('*.json'))]
    out = ROOT/'validation/preflight_report.json'
    out.write_text(json.dumps(results, ensure_ascii=False, indent=2)+'\n')
    for result in results:
        print(result['file'], result['independent_preflight'], result['stats'], result['issues'])
    raise SystemExit(any(r['independent_preflight'] != 'PASS' for r in results))
