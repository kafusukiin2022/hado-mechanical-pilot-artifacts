#!/usr/bin/env python
"""Train V16-A with candidate-intrinsic physics and partial-order supervision."""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from scipy.stats import kendalltau
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scripts.prepare_ranking_dataset import official_selection
from scripts.prepare_v15_pareto_rank import pareto_depth
from scripts.train_v1 import seed_everything
from scripts.train_v15_pareto_rank import (
    QueryBatchSampler,
    front_metrics,
    selector_ranking_metrics,
)


INTRINSIC_DIM = 24 + 300 + 4


def intrinsic_features(payload):
    """Return features that cannot change when the candidate pool changes."""
    targets = payload["targets"].float()
    monomer = payload["monomer_stability"].float()
    binding = payload["binding_stability"].float()
    base_m34 = torch.stack((binding.max(1).values, monomer.max(1).values), dim=1)
    hybrid = torch.cat((targets[:, :2], base_m34), dim=1)
    features = torch.cat((torch.log1p(monomer), torch.log1p(binding),
                          torch.log1p(hybrid)), dim=1)
    if features.shape[1] != INTRINSIC_DIM:
        raise ValueError(f"expected {INTRINSIC_DIM} intrinsic features, got {features.shape[1]}")
    return features.float(), hybrid.float(), base_m34.float()


class V16Dataset(Dataset):
    def __init__(self, path, feature_mean=None, feature_std=None,
                 objective_mean=None, objective_std=None):
        self.path = Path(path)
        self.payload = torch.load(path, map_location="cpu", weights_only=False)
        self.sample_ids = self.payload["sample_ids"]
        self.sources = self.payload["sources"]
        source_map = {source: index for index, source in enumerate(sorted(set(self.sources)))}
        self.query_id = torch.tensor([source_map[source] for source in self.sources])
        self.targets = self.payload["targets"].float()
        self.rank = self.payload["source_rank"].long()
        self.front = self.rank.eq(1).float()
        raw, self.hybrid, self.base_m34 = intrinsic_features(self.payload)
        if feature_mean is None:
            feature_mean = raw.mean(0)
            feature_std = raw.std(0).clamp_min(1e-4)
        if objective_mean is None:
            objective_mean = self.targets.mean(0)
            objective_std = self.targets.std(0).clamp_min(1e-4)
        self.feature_mean = torch.as_tensor(feature_mean).float()
        self.feature_std = torch.as_tensor(feature_std).float()
        self.objective_mean = torch.as_tensor(objective_mean).float()
        self.objective_std = torch.as_tensor(objective_std).float()
        self.features = (raw - self.feature_mean) / self.feature_std

    def __len__(self):
        return len(self.features)

    def __getitem__(self, index):
        return (self.features[index], self.targets[index], self.base_m34[index],
                self.rank[index], self.front[index], self.query_id[index], index)


class V16OrderModel(nn.Module):
    def __init__(self, input_dim=INTRINSIC_DIM, dropout=0.1, residual_limit=0.5):
        super().__init__()
        self.residual_limit = residual_limit
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 512), nn.GELU(), nn.Dropout(dropout), nn.LayerNorm(512),
            nn.Linear(512, 256), nn.GELU(), nn.Dropout(dropout), nn.LayerNorm(256),
            nn.Linear(256, 128), nn.GELU(), nn.LayerNorm(128),
        )
        self.metric_residual = nn.Linear(128, 2)
        nn.init.zeros_(self.metric_residual.weight)
        nn.init.zeros_(self.metric_residual.bias)

    def forward(self, features, base_m34, exact_m12):
        hidden = self.encoder(features)
        delta = self.residual_limit * torch.tanh(self.metric_residual(hidden))
        corrected_m34 = (base_m34 + delta).clamp_min(0)
        return {
            "corrected_metrics": torch.cat((exact_m12, corrected_m34), dim=1),
            "corrected_m34": corrected_m34,
            "metric_delta": delta,
            "hidden": hidden,
        }


def dominance_relations(metrics):
    """Return pair relation matrix: 1 row dominates col, -1 reverse, 0 incomparable."""
    no_worse = (metrics[:, None, :] <= metrics[None, :, :]).all(2)
    strictly_better = (metrics[:, None, :] < metrics[None, :, :]).any(2)
    dominates = no_worse & strictly_better
    relation = dominates.to(torch.int8) - dominates.T.to(torch.int8)
    return relation


def order_violation(left, right):
    """Zero exactly when the minimized vector left weakly dominates right."""
    return F.relu(left - right).square().sum(-1)


def _sample_pair_indices(mask, hardness, maximum):
    indices = mask.nonzero(as_tuple=False)
    if len(indices) <= maximum:
        return indices
    values = hardness[indices[:, 0], indices[:, 1]]
    hard_count = maximum // 2
    hard = indices[torch.topk(values, hard_count, largest=False).indices]
    remaining = maximum - hard_count
    random = indices[torch.randperm(len(indices), device=indices.device)[:remaining]]
    return torch.cat((hard, random), dim=0)


def partial_order_loss(predicted, target, query_id, margin=0.05,
                       pairs_per_class=2048):
    """Balanced dominate/reverse/incomparable order-embedding loss."""
    relation = dominance_relations(target)
    upper = torch.triu(torch.ones_like(relation, dtype=torch.bool), diagonal=1)
    upper &= query_id[:, None].eq(query_id[None])
    unequal = (target[:, None, :] != target[None, :, :]).any(2)
    upper &= unequal
    hardness = (target[:, None, :] - target[None, :, :]).square().sum(2)
    groups = {
        "forward": _sample_pair_indices(upper & relation.eq(1), hardness, pairs_per_class),
        "reverse": _sample_pair_indices(upper & relation.eq(-1), hardness, pairs_per_class),
        "incomparable": _sample_pair_indices(upper & relation.eq(0), hardness, pairs_per_class),
    }
    losses, counts = [], {}
    for name, indices in groups.items():
        counts[name] = len(indices)
        if not len(indices):
            continue
        left, right = predicted[indices[:, 0]], predicted[indices[:, 1]]
        forward = order_violation(left, right)
        reverse = order_violation(right, left)
        if name == "forward":
            loss = forward + F.relu(margin - reverse)
        elif name == "reverse":
            loss = reverse + F.relu(margin - forward)
        else:
            loss = F.relu(margin - forward) + F.relu(margin - reverse)
        losses.append(loss.mean())
    if not losses:
        return predicted.sum() * 0.0, counts
    return torch.stack(losses).mean(), counts


def multitask_loss(output, batch, objective_mean, objective_std,
                   dominance_weight=1.0, physical_weight=0.25,
                   margin=0.05, pairs_per_class=2048):
    _, target, _, _, _, query_id, _ = batch
    predicted_scaled = (output["corrected_metrics"] - objective_mean) / objective_std
    target_scaled = (target - objective_mean) / objective_std
    dominance, counts = partial_order_loss(
        predicted_scaled, target_scaled, query_id, margin, pairs_per_class
    )
    physical = F.smooth_l1_loss(output["corrected_m34"], target[:, 2:])
    total = dominance_weight * dominance + physical_weight * physical
    return total, {"dominance": dominance, "physical": physical}, counts


def predicted_front(sample_ids, metrics):
    front, _ = official_selection(sample_ids, metrics)
    members = set(front)
    return np.asarray([sample_id in members for sample_id in sample_ids], dtype=bool)


def dominance_classification_metrics(target, predicted, seed=20260919,
                                     pairs=1_000_000):
    rng = np.random.default_rng(seed)
    left = rng.integers(0, len(target), size=pairs)
    right = rng.integers(0, len(target), size=pairs)

    def relations(values):
        left_dom = np.all(values[left] <= values[right], axis=1) & np.any(
            values[left] < values[right], axis=1)
        right_dom = np.all(values[right] <= values[left], axis=1) & np.any(
            values[right] < values[left], axis=1)
        return np.where(left_dom, 1, np.where(right_dom, -1, 0))

    truth, estimate = relations(target), relations(predicted)
    per_class = {}
    for label, name in ((1, "left_dominates"), (-1, "right_dominates"),
                        (0, "incomparable")):
        tp = np.sum((truth == label) & (estimate == label))
        fp = np.sum((truth != label) & (estimate == label))
        fn = np.sum((truth == label) & (estimate != label))
        per_class[name] = {
            "support": int(np.sum(truth == label)),
            "precision": float(tp / max(1, tp + fp)),
            "recall": float(tp / max(1, tp + fn)),
            "F1": float(2 * tp / max(1, 2 * tp + fp + fn)),
        }
    return {
        "accuracy": float(np.mean(truth == estimate)),
        "macro_F1": float(np.mean([item["F1"] for item in per_class.values()])),
        "per_class": per_class,
        "sampled_pairs": int(pairs),
    }


@torch.no_grad()
def predict(model, dataset, device, batch_size):
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, pin_memory=True)
    model.eval(); corrected, deltas = [], []
    for batch in loader:
        features, target, base_m34 = batch[0], batch[1], batch[2]
        output = model(features.to(device), base_m34.to(device), target[:, :2].to(device))
        corrected.append(output["corrected_metrics"].cpu().numpy())
        deltas.append(output["metric_delta"].cpu().numpy())
    return np.concatenate(corrected), np.concatenate(deltas)


def evaluate(model, dataset, device, batch_size, rank_device=None, per_source=True):
    predicted, deltas = predict(model, dataset, device, batch_size)
    target = dataset.targets.numpy()
    sources = np.asarray(dataset.sources)
    if per_source:
        groups = {source: np.where(sources == source)[0] for source in np.unique(sources)}
    else:
        groups = {"all": np.arange(len(dataset))}
    reports = {}
    for source, indices in groups.items():
        ids = [dataset.sample_ids[index] for index in indices]
        true_rank = dataset.rank.numpy()[indices]
        estimated_rank, layers = pareto_depth(
            predicted[indices], device=rank_device or device,
            chunk_size=min(1024, len(indices))
        )
        target_front = true_rank == 1
        estimate_front = estimated_rank == 1
        reports[source] = {
            "records": len(indices),
            "predicted_layers": layers,
            "front": front_metrics(target_front, estimate_front.astype(float), 0.5),
            "kendall_tau_b": float(kendalltau(-true_rank, -estimated_rank).statistic),
            "front_rank_MAE": float(np.mean(np.abs(true_rank - estimated_rank))),
            "dominance": dominance_classification_metrics(
                target[indices], predicted[indices],
                pairs=min(1_000_000, max(1, len(indices) ** 2)),
            ),
            "selector": selector_ranking_metrics(
                ids, target[indices], predicted[indices],
                estimate_front.astype(float), 0.5,
            ),
        }
    macro = {
        "front_F1": float(np.mean([x["front"]["F1"] for x in reports.values()])),
        "front_recall": float(np.mean([x["front"]["recall"] for x in reports.values()])),
        "dominance_macro_F1": float(np.mean([
            x["dominance"]["macro_F1"] for x in reports.values()
        ])),
        "mean_NDCG@10": float(np.mean([
            x["selector"]["mean_NDCG@10"] for x in reports.values()
        ])),
    }
    return {"macro": macro, "sources": reports,
            "max_abs_metric_delta": float(np.abs(deltas).max())}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path,
                        default=ROOT / "artifacts/v15-pareto-rank-data")
    parser.add_argument("--out", type=Path,
                        default=ROOT / "artifacts/v16-order-run")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--eval-batch-size", type=int, default=2048)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--min-lr", type=float, default=1e-5)
    parser.add_argument("--dominance-weight", type=float, default=1.0)
    parser.add_argument("--physical-weight", type=float, default=0.25)
    parser.add_argument("--margin", type=float, default=0.05)
    parser.add_argument("--pairs-per-class", type=int, default=2048)
    parser.add_argument("--seed", type=int, default=20260919)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()

    seed_everything(args.seed); torch.set_num_threads(args.threads)
    if not torch.cuda.is_available():
        raise RuntimeError("V16 training requires CUDA")
    train = V16Dataset(args.data_dir / "train.pt")
    dev = V16Dataset(
        args.data_dir / "dev.pt", train.feature_mean, train.feature_std,
        train.objective_mean, train.objective_std,
    )
    if set(train.sources) & set(dev.sources):
        raise RuntimeError("source leakage between V16 train and development")
    sampler = QueryBatchSampler(
        train, min(args.batch_size, len(train)), args.seed,
        batches=2 if args.smoke else None,
    )
    loader = DataLoader(train, batch_sampler=sampler, pin_memory=True)
    device = torch.device("cuda")
    model = V16OrderModel(train.features.shape[1]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=args.epochs, eta_min=args.min_lr
    )
    objective_mean = train.objective_mean.to(device)
    objective_std = train.objective_std.to(device)
    args.out.mkdir(parents=True, exist_ok=True)
    config = {
        "task": "v16_a_physically_anchored_partial_order",
        "train_sources": sorted(set(train.sources)),
        "dev_sources": sorted(set(dev.sources)),
        "train_records": len(train), "dev_records": len(dev),
        "input_dim": train.features.shape[1],
        "inputs": "candidate-intrinsic exact M1/M2 + frozen V8 monomer/dimer profiles",
        "pool_relative_physical_inputs": False,
        "front_inference": "non-dominated sorting of corrected M1-M4",
        "loss_weights": {"dominance": args.dominance_weight,
                         "physical": args.physical_weight},
        "margin": args.margin, "pairs_per_class": args.pairs_per_class,
        "model_parameters": sum(parameter.numel() for parameter in model.parameters()),
        "checkpoint_selection": "lexicographic pUC19 predicted-vector (front_F1, mean_NDCG@10)",
    }
    (args.out / "config.json").write_text(json.dumps(config, indent=2) + "\n")

    best, started = None, time.time()
    with (args.out / "training.jsonl").open("w") as log:
        for epoch in range(1, args.epochs + 1):
            model.train(); totals = defaultdict(list); counts = defaultdict(list)
            for raw_batch in loader:
                batch = tuple(item.to(device, non_blocking=True) for item in raw_batch)
                optimizer.zero_grad(set_to_none=True)
                output = model(batch[0], batch[2], batch[1][:, :2])
                loss, parts, pair_counts = multitask_loss(
                    output, batch, objective_mean, objective_std,
                    args.dominance_weight, args.physical_weight,
                    args.margin, args.pairs_per_class,
                )
                loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                totals["total"].append(float(loss.detach()))
                for key, value in parts.items(): totals[key].append(float(value.detach()))
                for key, value in pair_counts.items(): counts[key].append(value)
            validation = evaluate(
                model, dev, device, args.eval_batch_size, rank_device=device,
                per_source=len(set(dev.sources)) > 1,
            )
            selection = [validation["macro"]["front_F1"],
                         validation["macro"]["mean_NDCG@10"]]
            row = {
                "epoch": epoch, "learning_rate": optimizer.param_groups[0]["lr"],
                "train": {key: float(np.mean(value)) for key, value in totals.items()},
                "mean_pairs_per_batch": {
                    key: float(np.mean(value)) for key, value in counts.items()
                },
                "validation": validation, "selection_score": selection,
                "elapsed_seconds": time.time() - started,
            }
            log.write(json.dumps(row) + "\n"); log.flush(); print(json.dumps(row), flush=True)
            if best is None or tuple(selection) > tuple(best["selection_score"]):
                best = row
                torch.save({
                    "model": model.state_dict(), "config": config, "epoch": epoch,
                    "feature_mean": train.feature_mean, "feature_std": train.feature_std,
                    "objective_mean": train.objective_mean,
                    "objective_std": train.objective_std,
                }, args.out / "best.pt")
            scheduler.step()
    (args.out / "metrics.json").write_text(json.dumps({
        "best": best, "final": row, "independent_test_evaluated": False,
        "complete_pool_evaluated": False,
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
