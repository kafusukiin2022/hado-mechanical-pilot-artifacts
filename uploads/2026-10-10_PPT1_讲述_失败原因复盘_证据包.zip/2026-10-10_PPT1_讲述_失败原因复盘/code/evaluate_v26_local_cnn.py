#!/usr/bin/env python
"""Evaluate the family-trained local CNNs by raw extrema on real candidate pools."""
import argparse,gzip,json,sys,time
from pathlib import Path
import numpy as np,torch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.v26_variable import VariableSingleCNN,VariablePairCNN,tokenize,pair_index
from scripts.prepare_ranking_dataset import official_selection
from scripts.train_v15_pareto_rank import front_metrics,selector_ranking_metrics
def lines(p):
 return gzip.open(p,'rt') if str(p).endswith('.gz') else open(p)
@torch.no_grad()
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',action='append',required=True,help='name=JSONL(.gz)');p.add_argument('--single',type=Path,required=True);p.add_argument('--pair',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--chunk',type=int,default=256);a=p.parse_args();d=torch.device('cuda');sm=VariableSingleCNN().to(d).eval();pm=VariablePairCNN().to(d).eval();sm.load_state_dict(torch.load(a.single,map_location='cpu',weights_only=False)['model']);pm.load_state_dict(torch.load(a.pair,map_location='cpu',weights_only=False)['model']);out={'task':'v26_family_synthetic_local_cnn_raw_extrema','m1_m2':'candidate truth retained only for Pareto/MCDM diagnostic','candidate_corrector':False,'inputs':{}}
 for spec in a.input:
  name,path=spec.split('=',1);rows=[]
  with lines(path) as f:
   for line in f:
    if line.strip():rows.append(json.loads(line))
  ids=[];truth=[];pred34=[];ranks=[];mae3=[];mae4=[];start=time.time()
  for r in rows:
   ss=r['derived']['staple_sequences'];x=torch.stack([tokenize(s,48) for s in ss]);s,_=sm(x.to(d));ij=pair_index(len(ss));pp=[]
   for z in range(0,len(ij),a.chunk):
    q=ij[z:z+a.chunk];v,_=pm(x[q[:,0]].to(d),x[q[:,1]].to(d));pp.append(v)
   pair=torch.cat(pp); target=r['targets'];ids.append(r['sample_id']);truth.append([target['M1'],target['M2'],target['M3'],target['M4']]);pred34.append([float(pair.max()),float(s.max())]);mae3.append(abs(float(pair.max())-target['M3']));mae4.append(abs(float(s.max())-target['M4']))
   if 'v5_energy_truth' in r:
    y=torch.tensor([max(0.,-float(z['net_binding_energy'])) for z in r['v5_energy_truth']['staple_dimers']]);ranks.append(float((pair.argsort(descending=True)[:10]==y.argmax()).any()))
  truth=np.asarray(truth);pred=np.concatenate((truth[:,:2],np.asarray(pred34)),1);front,_=official_selection(ids,pred);tf,_=official_selection(ids,truth);prob=np.asarray([i in set(front) for i in ids],float);out['inputs'][name]={'records':len(rows),'seconds':time.time()-start,'M3_MAE':float(np.mean(mae3)),'M4_MAE':float(np.mean(mae4)),'M3_bias':float(np.mean(pred[:,2]-truth[:,2])),'M4_bias':float(np.mean(pred[:,3]-truth[:,3])),'winner_R@10':float(np.mean(ranks)) if ranks else None,'front':front_metrics(np.asarray([i in set(tf) for i in ids]),prob,.5),'selector':selector_ranking_metrics(ids,truth,pred,prob,.5)};print(name,json.dumps(out['inputs'][name],indent=2),flush=True)
 a.out.write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
