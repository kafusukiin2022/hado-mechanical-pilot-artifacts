#!/usr/bin/env python
"""Train V26 variable-set A/B models without topology graph features."""
from __future__ import annotations
import argparse, json, random, sys, time
from collections import defaultdict
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from scripts.train_v1 import seed_everything
from scripts.prepare_ranking_dataset import official_selection
from scripts.train_v15_pareto_rank import front_metrics, selector_ranking_metrics
from scripts.v26_variable import VariableSingleCNN,VariablePairCNN,V26SetCorrector,load_v25_cnn_weights

def forward_item(single,pair,head,item,device,chunk=64):
    tokens=item['tokens'].to(device); lengths=item['lengths'].to(device); pairs=item['pairs'].to(device)
    single_score,single_emb=single(tokens)
    ps=[]; pe=[]
    for start in range(0,len(pairs),chunk):
        ij=pairs[start:start+chunk]; score,emb=pair(tokens[ij[:,0]],tokens[ij[:,1]]); ps.append(score); pe.append(emb)
    pair_score,pair_emb=torch.cat(ps),torch.cat(pe)
    prediction,raw,delta=head(single_score,single_emb,pair_score,pair_emb,lengths,pairs)
    return prediction,raw,delta,single_score,pair_score

def local_loss(single_score,pair_score,item):
    losses=[]
    if 'monomer_target' in item: losses.append(F.smooth_l1_loss(single_score,item['monomer_target'].to(single_score.device)))
    if 'pair_target' in item: losses.append(F.smooth_l1_loss(pair_score,item['pair_target'].to(pair_score.device)))
    return torch.stack(losses).mean() if losses else single_score.sum()*0.

@torch.no_grad()
def local_mae(single,pair,items,device,chunk):
    single.eval(); pair.eval(); values=[]
    for item in items:
        tokens=item['tokens'].to(device); pairs=item['pairs'].to(device)
        ss,_=single(tokens); ps=[]
        for start in range(0,len(pairs),chunk):
            ij=pairs[start:start+chunk]; score,_=pair(tokens[ij[:,0]],tokens[ij[:,1]]); ps.append(score)
        if 'monomer_target' in item: values.append((ss-item['monomer_target'].to(device)).abs().mean())
        if 'pair_target' in item: values.append((torch.cat(ps)-item['pair_target'].to(device)).abs().mean())
    return float(torch.stack(values).mean()) if values else None

@torch.no_grad()
def evaluate(single,pair,head,items,device,chunk,group_by_source=True):
    groups=defaultdict(list); m3=[];m4=[]; local_top=[]
    single.eval(); pair.eval(); head.eval()
    for item in items:
        pred,raw,delta,ss,ps=forward_item(single,pair,head,item,device,chunk)
        group=(item['topology'],item['source']) if group_by_source else (item['topology'],'all_sources')
        groups[group].append((item,pred.cpu().numpy(),ps.cpu(),ss.cpu()))
        m3.append(abs(float(pred[0])-float(item['target'][2])));m4.append(abs(float(pred[1])-float(item['target'][3])))
        if 'pair_target' in item:
            target=item['pair_target']; rank=torch.argsort(ps,descending=True); winner=int(target.argmax()); local_top.append(float((rank[:10]==winner).any()))
    reports=[]
    for _,rows in groups.items():
        ids=[r[0]['sample_id'] for r in rows]; truth=np.stack([r[0]['target'].numpy() for r in rows]); m34=np.stack([r[1] for r in rows]); pred=np.concatenate((truth[:,:2],m34),1)
        front,_=official_selection(ids,pred); prob=np.asarray([x in set(front) for x in ids],dtype=float); actual=np.asarray([r[0]['target'][2:].numpy() for r in rows])
        true_front,_=official_selection(ids,truth); gate=front_metrics(np.asarray([x in set(true_front) for x in ids]),prob,.5)
        selector=selector_ranking_metrics(ids,truth,pred,prob,.5)
        reports.append({'topology':rows[0][0]['topology'],'source':rows[0][0]['source'],'records':len(rows),'front':gate,'selector':selector})
    return {'groups':reports,'macro':{'front_F1':float(np.mean([x['front']['F1'] for x in reports])),'front_recall':float(np.mean([x['front']['recall'] for x in reports])),'mean_NDCG@10':float(np.mean([x['selector']['mean_NDCG@10'] for x in reports])),'M3_MAE':float(np.mean(m3)),'M4_MAE':float(np.mean(m4)),'winner_R@10':float(np.mean(local_top)) if local_top else None}}

def balanced(items,rng):
    by=defaultdict(list)
    for x in items: by[x['topology']].append(x)
    width=max(len(v) for v in by.values()); out=[]
    for values in by.values(): out.extend(rng.choice(values) for _ in range(width))
    rng.shuffle(out); return out

def main():
 p=argparse.ArgumentParser(); p.add_argument('--data',type=Path,required=True); p.add_argument('--train',nargs='+',required=True); p.add_argument('--dev',nargs='+',required=True); p.add_argument('--test',nargs='*',default=[]); p.add_argument('--mode',choices=('statistics','embedding'),default='embedding'); p.add_argument('--stage',choices=('local','candidate','joint'),default='candidate'); p.add_argument('--single-init',type=Path,default=ROOT/'artifacts/cnn-single/best.pt'); p.add_argument('--pair-init',type=Path,default=ROOT/'artifacts/cnn-pair/best.pt'); p.add_argument('--init-v26',type=Path); p.add_argument('--epochs',type=int,default=10); p.add_argument('--lr',type=float,default=3e-4); p.add_argument('--cnn-lr',type=float,default=3e-5); p.add_argument('--chunk',type=int,default=64); p.add_argument('--local-weight',type=float,default=.25); p.add_argument('--seed',type=int,default=26); p.add_argument('--out',type=Path,required=True); a=p.parse_args()
 seed_everything(a.seed); rng=random.Random(a.seed)
 if not torch.cuda.is_available(): raise RuntimeError('V26 training requires CUDA')
 data=torch.load(a.data,map_location='cpu',weights_only=False)['splits']; train=[x for role in a.train for x in data[role]]; dev=[x for role in a.dev for x in data[role]]; test=[x for role in a.test for x in data[role]]
 device=torch.device('cuda'); single=VariableSingleCNN().to(device); pair=VariablePairCNN().to(device); head=V26SetCorrector(a.mode).to(device)
 load_v25_cnn_weights(single,pair,a.single_init,a.pair_init)
 if a.init_v26:
  state=torch.load(a.init_v26,map_location='cpu',weights_only=False); single.load_state_dict(state['single']); pair.load_state_dict(state['pair'])
  if state.get('config',{}).get('mode') != a.mode: raise RuntimeError('V26 init mode mismatch')
  head.load_state_dict(state['head'])
 if a.stage=='candidate':
  for model in (single,pair):
   for par in model.parameters(): par.requires_grad=False
  params=head.parameters()
 else: params=[{'params':head.parameters(),'lr':a.lr},{'params':single.parameters(),'lr':a.cnn_lr},{'params':pair.parameters(),'lr':a.cnn_lr}]
 opt=torch.optim.AdamW(params,lr=a.lr); a.out.mkdir(parents=True,exist_ok=True)
 config={'task':'v26_variable_set_corrector','mode':a.mode,'stage':a.stage,'init_v26':str(a.init_v26) if a.init_v26 else None,'train_roles':a.train,'dev_roles':a.dev,'test_roles':a.test,'train_records':len(train),'dev_records':len(dev),'test_records':len(test),'cnn_input':'variable-length staples only','graph_features':False,'m1_m2':'exact oracle for Pareto evaluation only','local_labels_available':sum('pair_target' in x for x in train)}
 (a.out/'config.json').write_text(json.dumps(config,indent=2)+'\n'); best=None; started=time.time()
 with (a.out/'training.jsonl').open('w') as log:
  for epoch in range(1,a.epochs+1):
   single.train(a.stage!='candidate');pair.train(a.stage!='candidate');head.train(); losses=[]; local=[]
   for item in balanced(train,rng):
    pred,raw,delta,ss,ps=forward_item(single,pair,head,item,device,a.chunk); target=item['target'][2:].to(device); cand=F.smooth_l1_loss(pred,target); loc=local_loss(ss,ps,item)
    loss=loc if a.stage=='local' else cand+(a.local_weight*loc if a.stage=='joint' else 0.)
    opt.zero_grad(set_to_none=True); loss.backward();torch.nn.utils.clip_grad_norm_(list(single.parameters())+list(pair.parameters())+list(head.parameters()),1.);opt.step();losses.append(float(loss.detach()));local.append(float(loc.detach()))
   val=evaluate(single,pair,head,dev,device,a.chunk); local_val=local_mae(single,pair,dev,device,a.chunk) if a.stage=='local' else None; row={'epoch':epoch,'train_loss':float(np.mean(losses)),'local_loss':float(np.mean(local)),'validation':val,'local_validation_MAE':local_val,'elapsed_seconds':time.time()-started}; log.write(json.dumps(row)+'\n');log.flush();print(json.dumps({'epoch':epoch,'validation':val['macro'],'local_validation_MAE':local_val},indent=2),flush=True)
   score=(-local_val,) if local_val is not None else (val['macro']['front_F1'],val['macro']['mean_NDCG@10'])
   if best is None or score>best['score']:
    best={'score':score,'epoch':epoch,'validation':val};torch.save({'single':single.state_dict(),'pair':pair.state_dict(),'head':head.state_dict(),'config':config,'epoch':epoch},a.out/'best.pt')
 final_test=evaluate(single,pair,head,test,device,a.chunk) if test else None
 (a.out/'metrics.json').write_text(json.dumps({'best':best,'final_test':final_test},indent=2)+'\n')
if __name__=='__main__':main()
