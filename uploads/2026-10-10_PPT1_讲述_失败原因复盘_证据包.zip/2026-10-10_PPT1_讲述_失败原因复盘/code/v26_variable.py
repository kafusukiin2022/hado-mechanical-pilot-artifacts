"""Variable-length sequence CNNs and candidate set aggregators for V26."""
from __future__ import annotations
from dataclasses import dataclass
import re
import torch
from torch import nn
from torch.nn import functional as F

PAD=4
VOCAB={'A':0,'C':1,'G':2,'T':3}

def tokenize(sequence, max_len=48):
    if len(sequence)>max_len: raise ValueError(f'staple exceeds max_len={max_len}')
    out=torch.full((max_len,),PAD,dtype=torch.long)
    out[:len(sequence)]=torch.tensor([VOCAB[x] for x in sequence],dtype=torch.long)
    return out

def pair_index(count, device=None):
    return torch.triu_indices(count,count,device=device).T

def masked_pool(values, mask, dims):
    while mask.ndim<values.ndim: mask=mask.unsqueeze(1)
    mask=mask.bool(); floor=torch.finfo(values.dtype).min
    maximum=values.masked_fill(~mask,floor).amax(dims)
    total=(values*mask).sum(dims); denom=mask.sum(dims).clamp_min(1)
    return maximum,total/denom

class VariableSingleCNN(nn.Module):
    """Original V25 convolution/head dimensions with mask-aware pooling."""
    def __init__(self):
        super().__init__()
        self.net=nn.Sequential(nn.Conv1d(4,64,9,padding=4),nn.BatchNorm1d(64),nn.GELU(),nn.Conv1d(64,128,5,padding=2),nn.BatchNorm1d(128),nn.GELU(),nn.Conv1d(128,128,3,padding=1),nn.BatchNorm1d(128),nn.GELU())
        self.pre=nn.Sequential(nn.Linear(256,128),nn.GELU(),nn.Dropout(.2),nn.Linear(128,32),nn.GELU())
        self.out=nn.Sequential(nn.Linear(32,1),nn.Softplus())
    def forward(self, tokens):
        mask=tokens.lt(PAD); x=F.one_hot(tokens.clamp_max(PAD),5)[...,:4].float().transpose(1,2)
        h=self.net(x); maximum,mean=masked_pool(h,mask,(2,)); emb=self.pre(torch.cat((maximum,mean),1)); return self.out(emb).squeeze(1),emb

class VariablePairCNN(nn.Module):
    """Original interaction-image CNN with variable lengths and pair masking."""
    def __init__(self):
        super().__init__()
        self.net=nn.Sequential(nn.Conv2d(16,64,3,padding=1),nn.BatchNorm2d(64),nn.GELU(),nn.Conv2d(64,128,3,padding=1),nn.BatchNorm2d(128),nn.GELU(),nn.Conv2d(128,128,3,padding=1),nn.BatchNorm2d(128),nn.GELU())
        self.pre=nn.Sequential(nn.Linear(256,128),nn.GELU(),nn.Dropout(.2),nn.Linear(128,32),nn.GELU())
        self.out=nn.Sequential(nn.Linear(32,1),nn.Softplus())
    def forward(self, first, second):
        valid=first.lt(PAD)[:,:,None] & second.lt(PAD)[:,None,:]
        index=(first[:,:,None]*4+second[:,None,:]).clamp_max(15)
        x=F.one_hot(index,16).permute(0,3,1,2).float()*valid[:,None]
        h=self.net(x); maximum,mean=masked_pool(h,valid,(2,3)); emb=self.pre(torch.cat((maximum,mean),1)); return self.out(emb).squeeze(1),emb

def load_v25_cnn_weights(single, pair, single_path, pair_path):
    """Load compatible convolution/head tensors from original fixed-length CNNs."""
    def compatible(module,path):
        state=torch.load(path,map_location='cpu',weights_only=False)['model']; own=module.state_dict()
        shared={k:v for k,v in state.items() if k in own and own[k].shape==v.shape}
        # Original head is one Sequential; V26 splits it into pre/out.
        remap={}
        for k,v in state.items():
            if k.startswith('head.'):
                i=k.split('.')[1]; suffix='.'.join(k.split('.')[2:])
                target={'0':'pre.0','3':'pre.3','5':'pre.5','7':'out.0'}.get(i)
                if target: remap[f'{target}.{suffix}']=v
        shared.update(remap); module.load_state_dict(shared,strict=False)
    compatible(single,single_path); compatible(pair,pair_path)

def summary(values):
    ordered=values.sort(descending=True).values; n=len(values); q=torch.quantile(values,torch.tensor([.5,.75,.9,.95,.99],device=values.device))
    def at(i): return ordered[min(i,n-1)]
    return torch.cat((q,values.mean()[None],values.std(unbiased=False)[None],at(0)[None],(at(0)-at(1))[None],ordered[:min(8,n)].mean()[None]),0)

class V26SetCorrector(nn.Module):
    """A/B V26 candidate head. No graph or topology identifier is used."""
    def __init__(self, mode='embedding', residual_limit=4.0):
        super().__init__(); self.mode=mode; self.residual_limit=residual_limit
        self.single_token=nn.Sequential(nn.Linear(34,64),nn.GELU(),nn.LayerNorm(64))
        self.pair_token=nn.Sequential(nn.Linear(36,64),nn.GELU(),nn.LayerNorm(64))
        dim=24 if mode=='statistics' else 280
        self.head=nn.Sequential(nn.Linear(dim,128),nn.GELU(),nn.LayerNorm(128),nn.Linear(128,64),nn.GELU(),nn.Linear(64,2))
        nn.init.zeros_(self.head[-1].weight); nn.init.zeros_(self.head[-1].bias)
    def forward(self, single_score, single_emb, pair_score, pair_emb, lengths, pairs):
        n=len(single_score); p=len(pair_score); l=lengths.float()/48.
        s_summary=summary(single_score); p_summary=summary(pair_score)
        scale=torch.stack((torch.log(torch.tensor(float(n),device=l.device)),torch.log(torch.tensor(float(p),device=l.device)),l.mean(),l.std(unbiased=False)))
        if self.mode=='statistics': feature=torch.cat((s_summary,p_summary,scale))
        else:
            st=self.single_token(torch.cat((single_emb,single_score[:,None],l[:,None]),1))
            left,right=pairs[:,0],pairs[:,1]
            pt=self.pair_token(torch.cat((pair_emb,pair_score[:,None],(l[left]+l[right])[:,None],(l[left]-l[right]).abs()[:,None],left.eq(right).float()[:,None]),1))
            feature=torch.cat((st.mean(0),st.max(0).values,s_summary,pt.mean(0),pt.max(0).values,p_summary,scale))
        delta=self.residual_limit*torch.tanh(self.head(feature))
        raw=torch.stack((pair_score.max(),single_score.max()))
        return (raw+delta).clamp_min(0),raw,delta

def source_from_record(record):
    text=record.get('metadata',{}).get('scaffold_description','')
    text=re.sub(r'^>scaffold\d+__','',text).replace('__5to3prime','')
    return text.rsplit('_',1)[0]

def record_to_item(record,max_len=48):
    staples=record['derived']['staple_sequences']; tokens=torch.stack([tokenize(s,max_len) for s in staples])
    item={'sample_id':record['sample_id'],'topology':record['design_id'],'source':source_from_record(record),'tokens':tokens,'lengths':tokens.lt(PAD).sum(1),'pairs':pair_index(len(staples)),'target':torch.tensor([record['targets']['M1'],record['targets']['M2'],record['targets']['M3'],record['targets']['M4']],dtype=torch.float32),'condition':record.get('v5_energy_truth',{}).get('nupack_model',{'celsius':55.,'sodium':.05,'magnesium':.0125})}
    energy=record.get('v5_energy_truth')
    if energy:
        item['monomer_target']=torch.tensor([max(0.,-float(x['energy'])) for x in energy['staple_monomers']],dtype=torch.float32)
        item['pair_target']=torch.tensor([max(0.,-float(x['net_binding_energy'])) for x in energy['staple_dimers']],dtype=torch.float32)
    return item
