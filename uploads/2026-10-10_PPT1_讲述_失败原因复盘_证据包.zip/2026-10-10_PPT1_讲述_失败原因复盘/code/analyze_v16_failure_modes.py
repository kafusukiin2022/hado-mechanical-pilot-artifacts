#!/usr/bin/env python
"""Diagnose which V16-A behaviors limit Pareto retrieval and MCDM ranking."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.stats import rankdata, spearmanr


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scaffoldselector import constants
from scripts.evaluate_v3_ranking import ndcg_at_k
from scripts.prepare_ranking_dataset import METHODS, method_relevance, selector_scores
from scripts.train_v16_order import V16Dataset, V16OrderModel, predict, predicted_front
from scripts.train_v15_pareto_rank import front_metrics, selector_ranking_metrics


def fixed_front_rankings(sample_ids, metrics, front_mask):
    """Run upstream MCDM on a supplied front without recomputing dominance."""
    scores = selector_scores(sample_ids, metrics)
    front = [sample_id for sample_id, keep in zip(sample_ids, front_mask) if keep]
    settings = {
        "use_metrics": [1, 2, 3, 4],
        "adjusted_weights": list(constants.METRIC_WEIGHTS),
    }
    result = {}
    for name, function in METHODS.items():
        ranking, values = function(sorted(front), scores, settings, metrics_type="COST")
        result[name] = {"ranking": list(ranking), "scores": list(map(float, values))}
    return result


def fixed_front_ndcg(sample_ids, truth, predicted, true_front, k=10):
    true_rankings = fixed_front_rankings(sample_ids, truth, true_front)
    predicted_rankings = fixed_front_rankings(sample_ids, predicted, true_front)
    values = {}
    for method in METHODS:
        truth_order = true_rankings[method]["ranking"]
        relevance = dict(zip(
            truth_order,
            method_relevance(method, true_rankings[method]["scores"]).tolist(),
        ))
        prediction = predicted_rankings[method]["ranking"]
        values[method] = ndcg_at_k(prediction, relevance, k)
    values["mean"] = float(np.mean(list(values.values())))
    return values


def binary_auc(target, score):
    target = np.asarray(target, dtype=bool)
    positive, negative = int(target.sum()), int((~target).sum())
    if not positive or not negative:
        return float("nan")
    ranks = rankdata(score, method="average")
    return float((ranks[target].sum() - positive * (positive + 1) / 2) /
                 (positive * negative))


def metric_error_report(target, predicted, true_front):
    result = {}
    for column, name in ((2, "M3"), (3, "M4")):
        error = predicted[:, column] - target[:, column]
        result[name] = {
            "overall_MAE": float(np.abs(error).mean()),
            "overall_bias": float(error.mean()),
            "true_front_MAE": float(np.abs(error[true_front]).mean()),
            "true_front_bias": float(error[true_front].mean()),
            "nonfront_MAE": float(np.abs(error[~true_front]).mean()),
        }
    return result


def scenario(sample_ids, truth, metrics, true_front):
    estimate_front = predicted_front(sample_ids, metrics)
    operational = selector_ranking_metrics(
        sample_ids, truth, metrics, estimate_front.astype(float), 0.5
    )
    return {
        "front": front_metrics(true_front, estimate_front.astype(float), 0.5),
        "operational_mean_NDCG10": operational["mean_NDCG@10"],
        "operational": {
            method: {
                "NDCG@10": operational[method]["NDCG@10"],
                "Recall@10": operational[method]["Recall@10"],
            } for method in METHODS
        },
        "true_front_fixed_gate_NDCG10": fixed_front_ndcg(
            sample_ids, truth, metrics, true_front, 10
        ),
        "front_mask": estimate_front,
    }


def explicit_front_pair_accuracy(truth, predicted, true_front, seed=20260919,
                                 partners=1000):
    """Measure dominance relation accuracy for pairs involving true-front items."""
    rng = np.random.default_rng(seed)
    front_indices = np.where(true_front)[0]
    left = np.repeat(front_indices, partners)
    right = rng.integers(0, len(truth), size=len(left))

    def relation(values):
        left_dom = np.all(values[left] <= values[right], axis=1) & np.any(
            values[left] < values[right], axis=1)
        right_dom = np.all(values[right] <= values[left], axis=1) & np.any(
            values[right] < values[left], axis=1)
        return np.where(left_dom, 1, np.where(right_dom, -1, 0))

    actual, estimate = relation(truth), relation(predicted)
    return {
        "pairs": len(left), "accuracy": float(np.mean(actual == estimate)),
        "spurious_dominated_rate": float(np.mean((actual == 0) & (estimate == -1))),
        "lost_true_dominance_rate": float(np.mean((actual == 1) & (estimate != 1))),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path,
                        default=ROOT / "artifacts/v15-pareto-rank-data/test-p8064.pt")
    parser.add_argument("--checkpoints", type=Path, nargs="+", default=[
        ROOT / f"artifacts/v16-order-seed-{seed}/best.pt"
        for seed in range(20260919, 20260924)
    ])
    parser.add_argument("--out", type=Path,
                        default=ROOT / "artifacts/v16-failure-mode-analysis.json")
    parser.add_argument("--batch-size", type=int, default=2048)
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("V16 failure analysis requires CUDA")
    device = torch.device("cuda")
    predictions = []
    checkpoint_rows = []
    dataset = None
    for path in args.checkpoints:
        checkpoint = torch.load(path, map_location="cpu", weights_only=False)
        current = V16Dataset(
            args.data, checkpoint["feature_mean"], checkpoint["feature_std"],
            checkpoint["objective_mean"], checkpoint["objective_std"],
        )
        model = V16OrderModel(len(checkpoint["feature_mean"])).to(device)
        model.load_state_dict(checkpoint["model"], strict=True)
        predicted, _ = predict(model, current, device, args.batch_size)
        predictions.append(predicted)
        checkpoint_rows.append({"path": str(path), "epoch": checkpoint["epoch"]})
        dataset = current
    predictions = np.stack(predictions)
    truth = dataset.targets.numpy()
    sample_ids = dataset.sample_ids
    true_front = dataset.rank.numpy() == 1
    ensemble = predictions.mean(0)
    uncertainty = predictions[:, :, 2:].std(0).mean(1)
    absolute_error = np.abs(ensemble[:, 2:] - truth[:, 2:]).mean(1)

    full = scenario(sample_ids, truth, ensemble, true_front)
    v8_raw = scenario(sample_ids, truth, dataset.hybrid.numpy(), true_front)
    exact_m3 = ensemble.copy(); exact_m3[:, 2] = truth[:, 2]
    exact_m4 = ensemble.copy(); exact_m4[:, 3] = truth[:, 3]
    exact_both = ensemble.copy(); exact_both[:, 2:] = truth[:, 2:]
    scenarios = {
        "V8_raw": v8_raw,
        "ensemble_operational": full,
        "oracle_M3_only": scenario(sample_ids, truth, exact_m3, true_front),
        "oracle_M4_only": scenario(sample_ids, truth, exact_m4, true_front),
        "oracle_M3_M4": scenario(sample_ids, truth, exact_both, true_front),
    }
    predicted_mask = full["front_mask"]
    error_mask = predicted_mask != true_front
    false_negative = true_front & ~predicted_mask
    false_positive = ~true_front & predicted_mask
    recover_m3 = scenarios["oracle_M3_only"]["front_mask"]
    recover_m4 = scenarios["oracle_M4_only"]["front_mask"]
    recover_both = scenarios["oracle_M3_M4"]["front_mask"]

    individual = []
    for row, prediction in zip(checkpoint_rows, predictions):
        item = scenario(sample_ids, truth, prediction, true_front)
        individual.append({
            **row, "front_F1": item["front"]["F1"],
            "front_precision": item["front"]["precision"],
            "front_recall": item["front"]["recall"],
            "NDCG10": item["operational_mean_NDCG10"],
        })
    compact_scenarios = {}
    for name, item in scenarios.items():
        compact_scenarios[name] = {key: value for key, value in item.items()
                                   if key != "front_mask"}
    result = {
        "task": "v16_a_failure_mode_diagnosis",
        "data": str(args.data.resolve()), "records": len(truth),
        "true_front_count": int(true_front.sum()),
        "checkpoints": individual,
        "scenarios": compact_scenarios,
        "ensemble_delta_vs_individual_mean": {
            "front_F1": float(full["front"]["F1"] - np.mean([
                item["front_F1"] for item in individual
            ])),
            "NDCG10": float(full["operational_mean_NDCG10"] - np.mean([
                item["NDCG10"] for item in individual
            ])),
        },
        "front_errors": {
            "false_negatives": int(false_negative.sum()),
            "false_positives": int(false_positive.sum()),
            "false_negative_rate": float(false_negative.sum() / true_front.sum()),
            "false_discovery_rate": float(false_positive.sum() /
                                          max(1, predicted_mask.sum())),
            "false_negatives_recovered_by_exact_M3": int(np.sum(false_negative & recover_m3)),
            "false_negatives_recovered_by_exact_M4": int(np.sum(false_negative & recover_m4)),
            "false_negatives_recovered_by_exact_M3_M4": int(np.sum(
                false_negative & recover_both
            )),
            "false_negatives_requiring_both_exact": int(np.sum(
                false_negative & recover_both & ~recover_m3 & ~recover_m4
            )),
            "errors_detectable_by_seed_uncertainty_AUC": binary_auc(error_mask, uncertainty),
        },
        "metric_errors": metric_error_report(truth, ensemble, true_front),
        "uncertainty": {
            "spearman_with_mean_absolute_M3_M4_error": float(spearmanr(
                uncertainty, absolute_error
            ).statistic),
            "mean_on_membership_errors": float(uncertainty[error_mask].mean()),
            "mean_on_correct_membership": float(uncertainty[~error_mask].mean()),
        },
        "true_front_pair_relations": explicit_front_pair_accuracy(
            truth, ensemble, true_front
        ),
        "interpretation_guard": (
            "p8064 is historically opened. This experiment diagnoses frozen models "
            "and must not be used to tune a new checkpoint."
        ),
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "ensemble": compact_scenarios["ensemble_operational"],
        "oracle_M3": compact_scenarios["oracle_M3_only"],
        "oracle_M4": compact_scenarios["oracle_M4_only"],
        "front_errors": result["front_errors"],
        "metric_errors": result["metric_errors"],
        "uncertainty": result["uncertainty"],
        "front_pairs": result["true_front_pair_relations"],
    }), flush=True)


if __name__ == "__main__":
    main()
