#!/usr/bin/env python
"""V20 corrector augmented with frozen Buterez-style CNN summaries."""
from __future__ import annotations
import argparse,json,sys,time
from collections import defaultdict
from pathlib import Path
import numpy as np,torch
from torch.utils.data import DataLoader
from torch.nn import functional as F
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.train_v1 import seed_everything
from scripts.train_v15_pareto_rank import QueryBatchSampler
from scripts.train_v16_order import evaluate,multitask_loss
from scripts.train_v20_pair_boundary import V20Dataset,boundary_loss
from scripts.train_v19_pair_corrector import V19Model

class V25Dataset(V20Dataset):
    def __init__(self,path,pair_path,cnn_path,feature_mean=None,feature_std=None,objective_mean=None,objective_std=None,cnn_ablation='full'):
        # Build the 344-dimensional V20 representation first; normalization of
        # the final 370-dimensional representation is done below.
        super().__init__(path,pair_path,None,None,objective_mean,objective_std)
        c=torch.load(cnn_path,map_location='cpu',weights_only=False)
        if c['sample_ids']!=self.sample_ids: raise RuntimeError('CNN feature alignment mismatch')
        if cnn_ablation not in {'none','single','pair','full'}:
            raise ValueError(f'unknown cnn_ablation: {cnn_ablation}')
        chunks=[]
        if cnn_ablation in {'single','full'}: chunks.append(c['single_summary'].float())
        if cnn_ablation in {'pair','full'}: chunks.append(c['pair_summary'].float())
        extra=torch.cat(chunks,1) if chunks else self.features.new_zeros((len(self.features),0))
        raw=torch.cat((self.features*self.feature_std+self.feature_mean,extra),1)
        if feature_mean is None: feature_mean=raw.mean(0);feature_std=raw.std(0).clamp_min(1e-4)
        self.feature_mean=torch.as_tensor(feature_mean).float();self.feature_std=torch.as_tensor(feature_std).float();self.features=(raw-self.feature_mean)/self.feature_std

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--epochs',type=int,default=100);p.add_argument('--batch-size',type=int,default=512);p.add_argument('--eval-batch-size',type=int,default=2048);p.add_argument('--lr',type=float,default=3e-4);p.add_argument('--min-lr',type=float,default=1e-5);p.add_argument('--boundary-weight',type=float,default=.5);p.add_argument('--threads',type=int,default=1);p.add_argument('--cnn-ablation',choices=('none','single','pair','full'),default='full');a=p.parse_args();seed_everything(a.seed);torch.set_num_threads(a.threads)
 if not torch.cuda.is_available():raise RuntimeError('V25 requires CUDA')
 dd=ROOT/'artifacts/v15-pareto-rank-data';pd=ROOT/'artifacts/v19-pair-features';cd=ROOT/'artifacts/cnn-aux-features';tr=V25Dataset(dd/'train.pt',pd/'train.pt',cd/'train.pt',cnn_ablation=a.cnn_ablation);dv=V25Dataset(dd/'dev.pt',pd/'dev.pt',cd/'dev.pt',tr.feature_mean,tr.feature_std,tr.objective_mean,tr.objective_std,cnn_ablation=a.cnn_ablation);loader=DataLoader(tr,batch_sampler=QueryBatchSampler(tr,min(a.batch_size,len(tr)),a.seed),pin_memory=True);dev=torch.device('cuda');m=V19Model(tr.features.shape[1]).to(dev);opt=torch.optim.AdamW(m.parameters(),lr=a.lr);sch=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=a.epochs,eta_min=a.min_lr);mean,std=tr.objective_mean.to(dev),tr.objective_std.to(dev);a.out.mkdir(parents=True,exist_ok=True);cfg={'task':'v25_v20_plus_frozen_buterez_cnn_summaries','cnn_ablation':a.cnn_ablation,'input_dim':tr.features.shape[1],'cnn_extra_dim':tr.features.shape[1]-344,'train_records':len(tr),'dev_records':len(dv),'p8064_used_for_selection':False};(a.out/'config.json').write_text(json.dumps(cfg,indent=2)+'\n');best=None;started=time.time()
 with (a.out/'training.jsonl').open('w') as log:
  for ep in range(1,a.epochs+1):
   m.train();tot=defaultdict(list)
   for raw in loader:
    b=tuple(x.to(dev,non_blocking=True) for x in raw);opt.zero_grad(set_to_none=True);o=m(b[0],b[2],b[1][:,:2]);base,parts,_=multitask_loss(o,b[:7],mean,std,1.,.25,.05,2048);bl,bw=boundary_loss(o['corrected_m34'][:,0],b[1][:,2],b[4],b[7]);loss=base+a.boundary_weight*bl;parts['boundary']=bl;parts['boundary_weight']=bw;loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();tot['total'].append(float(loss.detach()));[tot[k].append(float(v.detach())) for k,v in parts.items()]
   val=evaluate(m,dv,dev,a.eval_batch_size,rank_device=dev,per_source=False);sel=[val['macro']['front_F1'],val['macro']['mean_NDCG@10']];row={'epoch':ep,'train':{k:float(np.mean(v)) for k,v in tot.items()},'validation':val,'selection_score':sel,'elapsed_seconds':time.time()-started};log.write(json.dumps(row)+'\n');log.flush();print(json.dumps(row),flush=True)
   if best is None or tuple(sel)>tuple(best['selection_score']):best=row;torch.save({'model':m.state_dict(),'epoch':ep,'config':cfg,'feature_mean':tr.feature_mean,'feature_std':tr.feature_std,'objective_mean':tr.objective_mean,'objective_std':tr.objective_std},a.out/'best.pt')
   sch.step()
 (a.out/'metrics.json').write_text(json.dumps({'best':best,'final':row,'p8064_evaluated':False},indent=2)+'\n')
if __name__=='__main__':main()
