# V23--V25 Results

V23 separates front retrieval from within-front MCDM. An affine M4 calibration
fit only on training sources defines the front gate; original predicted values
remain the MCDM inputs. On p8064, Front F1 rose from V20 ensemble `0.440` to
`0.465`, while NDCG@10 stayed `0.470`.

V24 doubled the V20 encoder widths from `512/256/128` to `1024/512/256` with
the same loss and split. Five seeds gave p8064 Front F1 `0.341 +/- 0.037` and
NDCG@10 `0.408 +/- 0.080`, so simple capacity is not the main bottleneck.

V25 adds an independent Buterez-style CNN auxiliary model trained from actual
NUPACK truth. A 1-D CNN predicts single-staple M4 contributions; a 2-D
16-channel base-pair interaction CNN predicts staple-pair M3 contributions.
Quantiles, maxima, gaps, and top-k summaries (10 single + 16 pair features)
are appended to V20. Train sources are lambda/p7249/p7560, pUC19 is dev, and
p8064 is held out.

| Model | p8064 Front F1 | Recall | NDCG@10 |
|---|---:|---:|---:|
| V20 five-seed mean | 0.413 +/- 0.045 | 0.443 +/- 0.059 | 0.447 +/- 0.052 |
| V24 wide five-seed mean | 0.341 +/- 0.037 | 0.422 +/- 0.012 | 0.408 +/- 0.080 |
| V25 CNN auxiliary five-seed mean | 0.382 +/- 0.039 | 0.461 +/- 0.024 | **0.668 +/- 0.054** |
| V25 ensemble + train-only M4 gate | 0.407 | **0.478** | **0.784** |

The final row is one frozen five-model ensemble, not a five-seed mean. The
M4 affine fit uses training records only; original V25 values are retained for
MCDM after gating. This is the strongest current ranking result, but Front F1
around 0.41 is not near-perfect. Additional sealed sources are required.
