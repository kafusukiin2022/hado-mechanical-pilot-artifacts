# V16 single-topology failure-mode analysis

## Question

The experiment asks which behavior currently prevents the fixed fourfinger
model from being reliable enough to expand to multiple topologies. It diagnoses
five frozen V16-A seeds on the historically opened 7,866-candidate p8064 pool.
No checkpoint is trained or selected from this analysis.

The experiment separates:

1. M3 error from M4 error with oracle substitution;
2. Pareto retrieval from MCDM ordering by supplying the true front;
3. scalar extreme error from 24-monomer/300-dimer winner retrieval;
4. individual models from a five-seed ensemble;
5. average pair accuracy from full-pool Pareto membership.

## Main counterfactual result

| Scenario | Front precision | Front recall | Front F1 | Operational NDCG@10 | NDCG on fixed true front |
|---|---:|---:|---:|---:|---:|
| V8 raw | 0.198 | 0.435 | 0.272 | 0.270 | 0.991 |
| V16-A five-seed mean | 0.310 | 0.391 | 0.346 | 0.474 | 0.989 |
| Exact M3, predicted M4 | 0.523 | 0.739 | **0.613** | **0.743** | 0.995 |
| Predicted M3, exact M4 | 0.586 | 0.370 | 0.453 | 0.668 | 0.991 |
| Exact M3 and M4 | 1.000 | 1.000 | 1.000 | 0.996 | 1.000 |

The decisive observation is that MCDM ordering is already almost perfect when
the true front is supplied. Predicted M1-M4 reach mean NDCG@10 0.989 on that
fixed set. Operational NDCG is low because the wrong candidates enter the
MCDM stage, not because SAW/KNEE/TOPSIS ordering is intrinsically unlearned.

Exact M3 alone recovers 16 of 28 V16 ensemble false negatives. Exact M4 alone
recovers one. Eleven false negatives require both to be exact. M3 is the
dominant single bottleneck, with M4 interactions accounting for the remaining
boundary cases.

## Metric behavior at the true front

| Metric | Overall MAE | True-front MAE | True-front bias |
|---|---:|---:|---:|
| M3 | 0.848 | **1.315** | **+0.885** |
| M4 | 0.511 | 0.558 | -0.097 |

The model overestimates the M3 cost of genuinely good candidates. Among the 28
true-front candidates missed by the ensemble, raw V8 M3 bias is +1.629. These
candidates are therefore made to look worse and become falsely dominated.

V16's scalar residual improves operational front precision and NDCG relative
to V8, even though ensemble scalar MAE is slightly worse than raw V8:

| Extreme | V8 raw MAE | V16 ensemble MAE |
|---|---:|---:|
| M3 | 0.828 | 0.848 |
| M4 | 0.492 | 0.511 |

This is another demonstration that global metric MAE is not aligned with the
Pareto decision boundary.

## Winner retrieval

M3 is the maximum of 300 dimer binding scores. M4 is the maximum of 24 monomer
scores. The exact NUPACK profiles show:

| Subset | Extreme | Winner R@1 | Winner R@5 | Winner R@10 | Mean true-winner predicted rank |
|---|---|---:|---:|---:|---:|
| All 7,866 | M3 dimer | 0.362 | 0.661 | 0.795 | 8.19 |
| True front | M3 dimer | **0.174** | 0.370 | 0.500 | **24.37** |
| Front false negatives | M3 dimer | **0.107** | **0.250** | **0.393** | **27.39** |
| All 7,866 | M4 monomer | 0.504 | 0.835 | 0.934 | 3.20 |
| True front | M4 monomer | 0.370 | 0.848 | 0.935 | 3.35 |
| Front false negatives | M4 monomer | 0.429 | 0.821 | 0.964 | 3.21 |

The physical failure is therefore specific: the model often does not identify
which of the 300 dimer pairs determines M3 for the best candidates. M4's
monomer candidate retrieval is materially better and is not the primary
failure.

## Pareto amplification

For 46,000 explicitly sampled pairs involving a true-front candidate:

* relation accuracy is 0.825;
* spurious `front candidate is dominated` rate is only 0.00659;
* lost true-dominance rate is 0.0438.

A 0.66% spurious-dominance rate looks small per pair, but a candidate is removed
from Front-1 if any one of thousands of competitors falsely dominates it. This
explains why acceptable-looking pair accuracy coexists with 60.9% false-negative
rate at the complete-pool front.

Future evaluation must report full-pool Front F1 and candidate-level false
dominance, not only random pair accuracy.

## Ensemble and uncertainty

Taking the mean of five V16-A predictions changes performance relative to the
individual-seed mean by:

* Front F1: -0.021;
* NDCG@10: +0.052.

The smoother metrics help ranking but merge away some boundary diversity. Seed
standard deviation is not a useful error detector:

* uncertainty/error Spearman correlation: 0.019;
* membership-error detection AUC: 0.523;
* mean uncertainty on wrong/correct memberships: 0.151/0.146.

The current ensemble cannot safely identify candidates that should be sent to
NUPACK for active relabeling.

## Ranked diagnosis

1. **M3 dimer winner retrieval at the good tail** is the largest error.
2. **M3 positive bias on true-front candidates** turns good candidates into
   false dominated points.
3. **Pareto all-pairs amplification** converts a small relation error rate into
   severe front loss.
4. **M4 is secondary**, mainly through interactions with M3 near the boundary.
5. **Seed uncertainty is uncalibrated** and cannot triage errors.
6. **MCDM ordering is not the current bottleneck** once the correct front is
   supplied.

## Next targeted experiment

The next model should change M3 training, not add another global ranking head:

1. classify the true winner among all 300 dimer pairs;
2. add listwise Top-1/5/10 loss over pair scores;
3. overweight true-front candidates and previously observed front false
   negatives;
4. regress the true-winner amplitude and the hardest competing pairs;
5. checkpoint on source-macro full-pool Front F1, with MCDM NDCG secondary;
6. calibrate uncertainty against held-out source errors before active learning.

The go/no-go criterion for this experiment is whether exact-M3's available
headroom can be captured: p8064 Front F1 should move materially toward 0.613
without using p8064 for selection.
