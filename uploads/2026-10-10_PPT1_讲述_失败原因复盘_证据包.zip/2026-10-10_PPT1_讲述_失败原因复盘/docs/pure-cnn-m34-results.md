# Pure Sequence CNN M3/M4 Diagnostic

This experiment removes the V20/V25 topology and candidate-level features from
the M3/M4 predictor. The CNN inputs are only the 24 staple sequences: the
single CNN predicts each staple's M4 contribution and the pair CNN predicts
each of the 300 pair contributions. Candidate M3/M4 are obtained by taking the
corresponding maxima.

To construct a four-objective Pareto tuple, this diagnostic uses **exact M1/M2
as oracle values** and replaces only M3/M4 with CNN predictions. This is
strictly favorable to the pure CNN; a fully sequence-only four-output model
would need additional M1/M2 labels and was not evaluated here.

| Evaluation | Front F1 | Recall | mean NDCG@10 | M3 bias | M4 bias |
|---|---:|---:|---:|---:|---:|
| pUC19 dev | 0.348 | 0.466 | 0.540 | -1.895 | -0.596 |
| p8064 diagnostic | 0.318 | 0.609 | 0.537 | -1.293 | -0.450 |

The pure CNN does **not** improve the final ranking. It is substantially below
the frozen V25 ensemble plus M4 gate on p8064 (Front F1 `0.407`, recall
`0.478`, mean NDCG@10 `0.784`). The dominant failure is systematic
underprediction of both extrema, especially M3. The CNN can retrieve more true
front candidates at the expense of many false positives, but its Pareto/MCDM
ranking is worse.

Conclusion: staple sequence alone contains useful signal, but it is not
sufficient for the current four-objective selection task. The CNN should
remain an auxiliary pair/M3 feature provider or a pre-filter, rather than
replace the topology/physics-aware corrector. A next fairer variant would add
train-only affine calibration of CNN M3/M4, but that would be calibration on
top of the pure sequence model, not a change to this raw diagnostic.
