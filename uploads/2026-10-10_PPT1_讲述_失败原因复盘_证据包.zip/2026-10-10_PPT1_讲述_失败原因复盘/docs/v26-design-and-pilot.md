# V26 Variable-Set CNN Corrector: Design and Pilot

## Scope

V25 is tied to fourfinger's fixed profile: 24 staples, 300 unordered pairs,
and a 42 nt CNN input. V26 keeps the single-staple and pair-interaction CNN
convolutional bodies, but replaces the fixed 344-dimensional candidate feature
vector with variable-cardinality staple and pair sets. It deliberately has no
graph/topology identifier and does not predict M1 or M2.

For ranking evaluation only, exact M1/M2 are combined with V26 M3/M4. This is
an oracle diagnostic, not a deployable four-objective predictor.

## Preconditions Audited

`scripts/audit_v26_prerequisites.py` wrote
`artifacts/v26-prerequisite-audit.json`.

* The V25 M4 gate is a positive affine transform:
  \(M_4'=1.08685466M_4-0.15994240\). It preserves the raw Pareto front exactly.
  Clamping after the transform changes the front by creating ties: the audit
  found 23 raw/affine front points but 19 after affine-plus-clip.
* V20's 344 dimensions are `324 + 4 + 16`: fixed fourfinger positions for 24
  monomers and 300 pairs, four candidate metrics, and 16 frozen pair-summary
  fields. The positional block is not portable to a topology with a different
  staple count.
* Across 512 checked fourfinger records, stored targets reconstruct exactly as
  \(M_4=\max_i\max(0,-G_i)\) and
  \(M_3=\max_{i\leq j}\max(0,-\Delta G_{ij})\), with zero mismatches.
  The \(i=j\) case is a two-strand NUPACK homodimer, not monomer folding.

## Model

For each candidate, V26 stores padded staple sequences, real lengths, and
all unordered pair indices \(i\leq j\), including homodimers. Padding is
masked; 48 nt is the current supported maximum.

\[
(\hat s_i,h_i)=\operatorname{SingleCNN}(S_i),\qquad
(\hat b_{ij},z_{ij})=\operatorname{PairCNN}(S_i,S_j).
\]

The retained CNNs use respectively 1-D sequence convolutions and a 16-channel
base-pair interaction image. They now use masked max and mean pooling rather
than a fixed flatten dimension. Both emit a nonnegative score and a 32-D
pre-output embedding. Tests confirm output invariance to normal float32
precision when the same sequence is padded to different widths in evaluation
mode.

Experiment A consumes score summaries only. Experiment B also encodes local
tokens:

\[
u_i=[h_i,\hat s_i,L_i],\qquad
u_{ij}=[z_{ij},\hat b_{ij},L_i+L_j,|L_i-L_j|,\mathbb{1}(i=j)].
\]

Separate token MLPs produce 64-D representations. Their set mean and set max
are concatenated with score tail summaries (max, top gap, top-8 mean,
quantiles), \(\log n\), \(\log P\), and length statistics. A `128 -> 64 -> 2`
head yields bounded residuals:

\[
\hat M_3=\max_{i\leq j}\hat b_{ij}+\Delta_3,\qquad
\hat M_4=\max_i\hat s_i+\Delta_4,\qquad
\Delta_k=4\tanh(a_k).
\]

The final residual layer is zero-initialized, so the initial candidate result
is exactly the two local maxima. No M1/M2, topology ID, contact map, or graph
features enter the model.

## Pilot Split and Limitation

The generated pilot cache is `artifacts/v26-pilot-source-disjoint.pt`:

| Role | Records | Sources | Topology | Full local labels |
| --- | ---: | --- | --- | --- |
| train | 470 | lambda, p7249, p7560 | fourfinger + rect | fourfinger only |
| dev | 132 | pUC19 | fourfinger + rect | fourfinger only |
| diagnostic | 200 | p8064 | fourfinger + tri | fourfinger only |

`tri` is absent from training. p8064 is diagnostic only and was not used for
checkpoint selection. Rect/tri currently have candidate M1--M4 truth but not
the complete monomer/dimer oracle profile, so local CNN training is currently
fourfinger-only. This is a small, one-seed mechanism pilot, not a claim of
cross-topology generalization.

## Results

All runs used the same source-disjoint roles. `Front F1`, recall, and NDCG are
computed separately for each `(topology, source)` pool and then macro-averaged.

| Run | Training | Dev F1 | Dev NDCG@10 | Dev M3 MAE | Diagnostic F1 | Diagnostic NDCG@10 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| A: statistics | frozen transferred CNN, candidate head | 0.508 | 0.539 | 5.375 | 0.511 | 0.500 |
| B: embeddings | frozen transferred CNN, set head | 0.444 | 0.523 | 5.371 | 0.558 | 0.687 |
| B staged | local adaptation, then frozen set head | **0.593** | **0.572** | **0.966** | **0.700** | **0.785** |
| B joint | staged checkpoint plus one joint epoch | 0.494 | 0.493 | 1.748 | 0.650 | 0.745 |

The joint run's diagnostic average conceals two different pools:

| Diagnostic pool | F1 | Recall | NDCG@10 |
| --- | ---: | ---: | ---: |
| fourfinger/p8064 | 0.600 | 0.706 | 0.676 |
| tri/p8064, held-out topology | 0.700 | 0.667 | 0.815 |

The staged B checkpoint is the current candidate-training choice because it
was selected by pUC19 dev and then read once on the sealed diagnostic. Its
diagnostic macro M3/M4 MAE is `0.899/0.687` and winner Recall@10 is `0.930`.
The single joint epoch reduced its dev F1 and NDCG, so it is a negative
fine-tuning result, not evidence that joint training is beneficial. The staged
checkpoint gives fourfinger/p8064 F1/recall/NDCG@10 `0.683/0.824/0.734` and
held-out tri/p8064 `0.718/0.667/0.835`. The apparently strong tri diagnostic
is only 100 candidates from one source and must not be compared directly with
mature V25 or treated as a topology-transfer result.

## What Was and Was Not Tested

* A and B establish that fixed `24/300` tensors have been removed and that CNN
  embeddings can be aggregated over 66/70-staple candidates.
* C is intentionally deferred. The V8/V20 24/300 profile is not a legal
  topology-independent physics anchor. A reusable per-candidate M3/M4
  baseline must exist before training
  \(\hat M_k=M_k^{base}+\Delta_k\).
* D (a graph branch) is deferred until a larger split and local labels show
  that B cannot find dangerous pairs. It must include a parameter-matched
  no-graph control.

## Direct Full-Pool Rect/Tri Inference

The selected staged-B checkpoint was run once, without any update, on all
1,000 rect and all 1,000 tri candidates. Unlike the source-macro pilot
diagnostic, each topology's five biological sources were pooled before
constructing one Pareto front and one SAW/KNEE/TOPSIS ranking. Exact M1/M2
remain oracle inputs solely for this four-objective diagnostic.

| Full topology pool | M3 MAE | M4 MAE | Front precision | Front recall | Front F1 | mean NDCG@10 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rect, 1,000 candidates | 0.966 | 0.843 | 0.580 | 0.417 | 0.485 | 0.586 |
| tri, 1,000 candidates | 1.042 | 0.825 | 0.605 | 0.505 | 0.551 | 0.563 |

Rect's true/predicted front sizes were 96/69 and tri's were 97/81. Top-10
mean NDCG is not sufficient to accept the model: rect's SAW/KNEE/TOPSIS
Recall@10 were `0.10/0.00/0.00`, and tri's were `0.30/0.30/0.30`. Thus V26 has
demonstrated shape compatibility, but not reliable full-pool Pareto retrieval
or ranking on either new topology. The exact reports are
`artifacts/v26-b-staged-rect-tri-full-evaluation.json` (per-source) and
`artifacts/v26-b-staged-rect-tri-full-global-evaluation.json` (full pool).

## Next Gate

Before selecting an architecture, generate complete local monomer/pair NUPACK
profiles for rect and tri, construct source/trajectory-disjoint train/dev/test
partitions, and run A/B with at least three seeds. Report within-seen-topology
and leave-one-topology-out results separately, including local winner Recall@k,
Pareto precision/recall, M3/M4 bias, and true-score SAW/KNEE/TOPSIS results.
