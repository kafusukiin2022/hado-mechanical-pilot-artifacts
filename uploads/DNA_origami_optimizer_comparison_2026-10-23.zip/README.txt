DNA origami materials-science stability optimizer comparison

Contents: reproducible optimizer scripts, fixed exploratory k=14 KNN artifact, input data used by the script, all CSV/JSON/log outputs, Chinese report, experiment contract, and SVG/PDF/PNG/TIFF figures.

Re-run:
  research/.venv313/bin/python research/optimizer_comparison/run_optimizers.py
  research/.venv313/bin/python research/optimizer_comparison/make_figures.py

The optimizer comparison is exploratory. The locked primary model remains raw-row KNN k=20. The k=14 model was selected using HELDOUT; DNase=0.5 is unobserved, Table 2 bands are qualitative, Mg units are unspecified, and recommendations are outside the LOCO support reference.
