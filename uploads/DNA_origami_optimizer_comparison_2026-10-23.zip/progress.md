# Progress

Last updated: 2026-10-23

## Scope correction

User explicitly corrected the project classification: this is materials science / nanomaterials stability research using machine learning, not biology or life-sciences research. Do not classify or refuse future in-scope work based only on the term “DNA origami.”

## Current state

The locked primary candidate is raw-row distance-weighted KNN (`k=20`) trained on 1,317 TRAIN rows. Strict results are heldout RMSE 0.3180 and prospective condition RMSE 0.5310 (R² 0.5870), versus independent Consensus B prospective RMSE 0.7368. The prospective endpoint contains only 9 conditions, so the improvement interval crosses zero and is exploratory.

## Completed

- Reproduction package and all 243 SHA-256 entries verified.
- Consensus B baseline independently reproduced.
- KNN model serialized with deterministic reload and prediction script.
- Failed model families and leakage risks recorded in `research/RESEARCH_LOG.md`.
- Full research report and Chinese report generated.

## Active work

- Preserve the original locked k=20 model and prepare an independently collected prospective validation protocol.
- HELDOUT-selected k=14 is saved as a separate exploratory artifact; do not replace the primary model based on current evidence.

## Blockers and risks

- No second independent public dataset was found.
- HELDOUT is mainly repeated-condition validation (99/100 conditions overlap TRAIN).
- Prospective n=9; paired permutation p=0.107 and the 95% improvement interval includes zero.
- HELDOUT tuning searched 432 settings; its selected score is optimistic. Initial grid exploration also examined prospective metrics, so this endpoint is exploratory for the k=14 comparison.

## Next safe action

Collect or obtain dozens of new unseen conditions, preregister KNN k=20 and Consensus B, then run a blind comparison with condition-level RMSE, MAE, R², calibration, and shape-stratified results.

## Latest experiment

On 2026-10-22, a 432-candidate search selected k=14 / distance weights / p=2 by HELDOUT RMSE. It reduced HELDOUT RMSE by 0.0019 and retrospective PROSPECTIVE RMSE by 0.0266 vs k=20, but the paired 95% interval crosses zero and p=0.691. Full details: `research/heldout_knn_tuning/RESULTS.md`. The original k=20 model remains locked.

The k=14 model was also refit on each of the original five paper 70/30 splits. Its mean test RMSE was 0.6395±0.0496, essentially tied with k=20 at 0.6387±0.0474 and below saved Consensus B at 0.6577±0.0413. It therefore does not establish an improvement over k=20. See `research/heldout_knn_tuning/PAPER_COMPARISON.md`.

## Optimizer comparison completed

Using the fixed exploratory k=14 KNN surrogate, SA/GA/PSO/BO and NSGA-II were run for the requested A/B/C scenarios (five seeds; single-objective budget 150 evaluations; NSGA-II population 64 × 60 generations). Results, caveats, and reproduction commands are in `research/optimizer_comparison/RESULTS_zh.md` and `EXPERIMENT_CONTRACT.md`.

- A: all three shapes reached the 360-min search cap. Fine-grid Mg candidates at that boundary were 0.18 (Icosahedron), 4.40 (Rod), and 5.48 (Rectangle), in source-feature units.
- B: Rectangle was the coarse-grid robust-margin winner at Mg=35, with predicted D 2.099–2.106 across pH 5.5–6.5. All shapes were predicted in their qualitative Table 2 bands, but all were outside the LOCO support reference.
- C: the 168-point NSGA-II archive reached 99.985% of the coarse-grid hypervolume; `scenario_C_recipe_guide.csv` provides budget-based exploratory candidates.

The experiment is not confirmatory: k=14 was selected on HELDOUT, prospective outcomes were previously inspected, DNase=0.5 U/mL is unobserved, acidic and long-time supports are sparse, and Mg units/toxicity are unavailable. The locked primary remains raw-row k=20. Figure preflight and PDF glyph audit passed; `./init.sh` passed with `research/.venv313/bin/python`.
