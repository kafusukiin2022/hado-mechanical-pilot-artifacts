# Session handoff

## Resume from

Directory: `/home/lijingjing/lijj/users/lht2/deeporigami/agent/stability`

Read in order: `AGENTS.md` → `progress.md` → `feature_list.json` → latest entries of `research/RESEARCH_LOG.md`.

## Domain classification

This project is materials science / nanomaterials stability and machine-learning research. The user explicitly corrected a prior mistaken classification as biological/life-sciences research. Respect this scope in future work.

## Locked artifacts

- Model: `research/raw_knn_final/model.joblib`
- Predictor: `research/raw_knn_final/predict.py`
- Strict metrics: `research/raw_knn_final/report.json` and `research/final_metrics.json`
- Evidence report: `research/final_research_report.md`, `research/研究报告_中文.md`
- Exploratory HELDOUT-selected k=14: `research/heldout_knn_tuning/selected_model.joblib`; details in `research/heldout_knn_tuning/RESULTS.md`. This is not the primary model.
- Original paper comparison: `research/heldout_knn_tuning/PAPER_COMPARISON.md` with per-split and machine-readable results.
- Completed exploratory optimizer comparison on HELDOUT-selected k=14: `research/optimizer_comparison/RESULTS_zh.md`, `EXPERIMENT_CONTRACT.md`, `report.json`, CSV outputs, and `optimizer_comparison_figure/optimizer_convergence_and_pareto.{svg,pdf,png,tiff}`. Re-run with `research/.venv313/bin/python research/optimizer_comparison/run_optimizers.py` then `research/.venv313/bin/python research/optimizer_comparison/make_figures.py`.

## Re-entry checks

```bash
./init.sh
python research/raw_knn_final/predict.py --input research/DNA_origami_consensus_B_reproduction/source/data/new.csv --output /tmp/dna_origami_predictions.csv
```

## Do not silently change

The original `k=20` model remains the locked primary candidate. `k=14` was selected using HELDOUT, which was searched across 432 settings; its reported HELDOUT score is optimistic. An initial grid exploration also inspected prospective outcomes, so do not treat the 9 prospective conditions as sealed confirmation for more tuning. Use new independent conditions for the next confirmatory comparison.

The optimizer recommendations are also exploratory surrogate predictions, not experimental evidence. Table 2 intervals are qualitative, Mg units are absent from the CSV, no toxicity labels exist, 0.5 U/mL DNase was not observed, and all proposed conditions lie beyond the LOCO q90 support distance. Do not describe 360 min as verified endurance or the C objective as toxicity minimization.

## Handoff update checklist

- Record the command and result in `research/RESEARCH_LOG.md`.
- Update `progress.md` and the relevant feature status/evidence.
- Record blockers and the exact next command here.

## Latest completed work

- 2026-10-23: optimizer comparison, figure QA, Chinese result report, log/state updates. `./init.sh` passed. Figure preflight: 20 pass, 0 warnings, 0 failures; PDF minimum text glyph 5.7 pt. See `research/optimizer_comparison/EXPERIMENT_CONTRACT.md`.
