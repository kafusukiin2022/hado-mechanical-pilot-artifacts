# Optimization experiment contract

## Scientific question

Can the HELDOUT-selected KNN (`k=14`, distance weights, Minkowski `p=2`) identify candidate MgCl2/time/shape/pH combinations whose predicted diffusion coefficient falls inside the paper's qualitative shape-specific stable range, and do SA, GA, PSO, BO, and NSGA-II converge to similar choices?

## Data, model, and scope

- Fixed model: `research/heldout_knn_tuning/selected_model.joblib`, trained on the 1,317 TRAIN rows; do not refit during this search.
- Output: predicted diffusion coefficient `Diffusion_Coefficient` (paper units: µm²/s).
- Shape-to-threshold map from original paper Table 2: Rods [1.9, 3.3], Spheres / icosahedra [1.8, 4.0], Rectangles [1.4, 2.8]. These are qualitative, shape-specific stability bands, not biomedical safety limits.
- MgCl2 search range: 0.18–50 in the source feature's units; the paper identifies 10 mM as the standard condition, but the CSV column itself has no unit metadata. Report concentration values as source-feature units and do not convert them to an added mass or dose.
- Physical support: at 37°C, observed TRAIN incubation times span 15–360 min; only two records are at 360 min. Constrain Scenario A to 15–360 min and state that a boundary optimum is not validated endurance.
- DNase=0.5 is not an observed training level (observed levels are 0, 0.2, 1, 5); this scenario uses interpolation between levels.
- Before search, compute standardized nearest-neighbor distances to distinct TRAIN conditions; report them relative to the 90th percentile of leave-one-condition-out nearest-neighbor distances.

## Scenario definitions

### A — physiological circulation proxy

- Fixed: T=37°C, pH=7.4, DNase=0.5 U/mL.
- Decision variables: MgCl2 in [0.18, 50], incubation time in [15, 360] min; evaluate each shape separately.
- Feasible if predicted D lies within the Table 2 band for the selected shape.
- Lexicographic objective: maximize time; among equivalent maximum-time choices, minimize MgCl2. Optimization score gives feasibility absolute priority, then normalized time, then a small Mg tie-break.
- Algorithm comparison: SA, real-coded GA, PSO, Gaussian-process expected-improvement BO; 5 seeds, 150 evaluations per algorithm/shape/seed.

### B — acid-resistance proxy

- Fixed: T=37°C, incubation=60 min, DNase=0.5 U/mL (the user did not specify these; held at the circulation scenario values for comparability).
- pH grid: 5.5–6.5 inclusive at 0.1 increments.
- Decision variable: MgCl2 in [0.18, 50]; evaluate each shape separately.
- Objective: maximize the worst-case normalized margin to the Table 2 stable-band boundary across all pH values. Positive margin means the point prediction stays in-band across the tested pH grid.
- Choose the geometry by comparing the shape-wise optimized robust margins.
- Algorithm comparison: SA, GA, PSO, BO; 5 seeds, 150 evaluations per algorithm/shape/seed.

### C — NSGA-II Pareto design

- Conditions follow B: T=37°C, incubation=60 min, DNase=0.5 U/mL, pH in [5.5, 6.5].
- Decision variables: MgCl2, pH, categorical shape.
- Shape-specific target D is the midpoint of its Table 2 band: Rod=2.6, Icosahedron=2.9, Rectangle=2.1 µm²/s.
- Objectives: minimize absolute D prediction error and minimize MgCl2 concentration. MgCl2 is only an additive-burden proxy; no toxicity model exists in the dataset.
- NSGA-II: 5 seeds, population 64, 60 generations. Compare its nondominated archive with a deterministic coarse grid reference.

## Figure contract

- Core conclusion: report whether the optimizers agree on model-predicted feasible design regions, while showing where optima sit at search boundaries or outside the training-condition neighborhood.
- Archetype: quantitative multi-panel grid.
- Backend: Python (saved project preference).
- Output: single composite figure, SVG/PDF and 600-dpi PNG; editable vector text.
- Panel map: (a) A convergence by shape, showing best feasible time; (b) B convergence in robust stability margin; (c) C MgCl2-vs-target-error Pareto front; (d) NSGA-II normalized hypervolume convergence.
- Evidence hierarchy: deterministic grid reference and final optimizer recommendations are primary; seed-to-seed convergence and nearest-condition support are robustness evidence.
- Statistics: five independent random seeds, show median and interquartile range; optimizer objective-evaluation count is the x-axis. No inferential p-values for algorithm ranking.
- Source data: CSV outputs for each curve, recommendation, and nondominated point.
- Reviewer risk: KNN is a local interpolator, 0.5 U/mL is not an observed enzyme level, feature supports are sparse at long time/acidic pH/extreme Mg, Table 2 bands are qualitative, and no toxicity or in-vivo measurement is modeled.

## Execution and deliverables (2026-10-23)

- The experiment completed with five seeds per algorithm. A and B used 150 objective evaluations per algorithm/shape/seed; NSGA-II used population 64, 60 generations, and 3,904 evaluations per seed.
- Main results and machine-readable outputs are in this directory; Chinese interpretation: `RESULTS_zh.md`.
- Figure outputs: `optimizer_comparison_figure/optimizer_convergence_and_pareto.{svg,pdf,png,tiff}`. Python/matplotlib was used; vector text is editable and raster outputs are 600 dpi.
- Figure preflight: 20 pass, 0 warn, 0 fail; PDF text audit minimum glyph 5.7 pt (required >=5 pt). Visual review covered the complete composite and each panel; Pareto points and grid-reference stars remain discernible.
- The model is the exploratory HELDOUT-selected k=14, not the locked primary k=20. HELDOUT was searched across 432 candidates, and prior exploration inspected prospective outcomes; therefore all optimizer outputs are exploratory.
- No experimental outcomes are measured here. Scenario A/B stability bands are qualitative paper ranges. Source Mg units are unspecified, and the Mg objective in C is only a burden proxy, not a toxicity estimate.
- Support audit: LOCO nearest-condition distance q90=0.3046. Scenario A recommendations have nearest-condition distance about 1.28; Scenario B optima about 1.45–2.20; C recipe-guide candidates about 1.64–1.87. All exceed the q90 support reference. At 37°C and 360 min there are only two TRAIN rows (one distinct condition); acidic-pH 37°C data comprise 53 rows / 18 conditions, all DNase=0 and Mg 1–10. Treat those scenarios as extrapolative candidates requiring experiments.
- Re-run commands: `research/.venv313/bin/python research/optimizer_comparison/run_optimizers.py` (full optimizer experiment; ~2 min on the recorded run), then `research/.venv313/bin/python research/optimizer_comparison/make_figures.py`. The latter also regenerates `scenario_C_recipe_guide.csv`.
