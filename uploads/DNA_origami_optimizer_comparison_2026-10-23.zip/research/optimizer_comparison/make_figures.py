"""Make publication-style optimizer convergence and Pareto figures from CSV outputs."""
from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D


ROOT = Path(__file__).resolve().parent
FIG = ROOT / "optimizer_comparison_figure"
ALGORITHMS = ["SA", "GA", "PSO", "BO"]
ALGO_COLORS = {"SA": "#277DA1", "GA": "#F8961E", "PSO": "#8E6CBE", "BO": "#43AA8B"}
SHAPES = ["Rectangles", "Rods", "Spheres"]
SHAPE_LABELS = {"Rectangles": "Rectangle", "Rods": "Rod", "Spheres": "Icosahedron"}
SHAPE_COLORS = {"Rectangles": "#E07A5F", "Rods": "#3D6D9A", "Spheres": "#3A9D8F"}
SHAPE_MARKERS = {"Rectangles": "o", "Rods": "s", "Spheres": "^"}


def quantile_curves(frame: pd.DataFrame, metric: str) -> pd.DataFrame:
    return (
        frame.groupby(["algorithm", "eval"])[metric]
        .agg(
            median="median",
            q25=lambda values: values.quantile(0.25),
            q75=lambda values: values.quantile(0.75),
        )
        .reset_index()
    )


def convergence_panel(ax, frame: pd.DataFrame, shape: str, metric: str, ylabel: str, scenario: str):
    subset = frame[frame["shape"] == shape]
    for algorithm in ALGORITHMS:
        curve = quantile_curves(subset[subset["algorithm"] == algorithm], metric)
        x = curve["eval"].to_numpy()
        y = curve["median"].to_numpy(dtype=float)
        lo = curve["q25"].to_numpy(dtype=float)
        hi = curve["q75"].to_numpy(dtype=float)
        color = ALGO_COLORS[algorithm]
        ax.plot(x, y, color=color, lw=1.35, label=algorithm)
        if np.isfinite(lo).any() and np.isfinite(hi).any():
            ax.fill_between(x, lo, hi, color=color, alpha=0.14, linewidth=0)
    ax.set_xlim(0, 150)
    ax.set_xlabel("Objective evaluations")
    ax.set_ylabel(ylabel)
    ax.set_title(SHAPE_LABELS[shape], loc="left", fontsize=8, fontweight="bold", pad=3)
    ax.grid(axis="y", color="#DCE2E8", lw=0.55)
    ax.set_axisbelow(True)
    if scenario == "A":
        ax.axhline(6.0, color="#5A6470", lw=0.8, ls=(0, (3, 2)), alpha=0.8)
        ax.text(0.98, 0.08, "search cap: 6 h", transform=ax.transAxes, ha="right", va="bottom", fontsize=5.8, color="#59636E")


def main():
    FIG.mkdir(exist_ok=True)
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "font.size": 6.5,
            "axes.titlesize": 8,
            "axes.labelsize": 6.6,
            "xtick.labelsize": 6.1,
            "ytick.labelsize": 6.1,
            "legend.fontsize": 6.2,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.linewidth": 0.75,
            "legend.frameon": False,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
        }
    )

    a = pd.read_csv(ROOT / "scenario_A_convergence.csv")
    b = pd.read_csv(ROOT / "scenario_B_convergence.csv")
    nsga = pd.read_csv(ROOT / "scenario_C_nsga2_pareto_front.csv")
    grid = pd.read_csv(ROOT / "scenario_C_grid_reference_front.csv")
    hv = pd.read_csv(ROOT / "scenario_C_nsga2_convergence.csv")

    # A concise decision guide: for each Mg budget, show the lowest-error NSGA-II
    # candidate that stays at or below that budget.
    guide_rows = []
    pareto = nsga.sort_values("MgCl2")
    for budget in [0.2, 0.5, 1, 2, 5, 10, 20, 35, 50]:
        eligible = pareto[pareto["MgCl2"] <= budget]
        if eligible.empty:
            continue
        chosen = eligible.sort_values(["absolute_target_error", "MgCl2"]).iloc[0]
        guide_rows.append(
            {
                "Mg_budget_source_feature_units": budget,
                "chosen_shape": chosen["shape_label"],
                "MgCl2_source_feature_units": chosen["MgCl2"],
                "pH": chosen["pH"],
                "D_pred_um2_s": chosen["D_pred"],
                "D_target_um2_s": chosen["D_target"],
                "absolute_error_um2_s": chosen["absolute_target_error"],
                "nearest_train_condition_distance": chosen["nn_distance"],
                "within_train_LOCO_q90_support": chosen["within_LOCO_q90"],
            }
        )
    pd.DataFrame(guide_rows).drop_duplicates(
        ["chosen_shape", "MgCl2_source_feature_units", "pH", "absolute_error_um2_s"]
    ).to_csv(ROOT / "scenario_C_recipe_guide.csv", index=False)

    fig = plt.figure(figsize=(7.2, 8.2), constrained_layout=False)
    gs = fig.add_gridspec(3, 6, left=0.085, right=0.99, top=0.925, bottom=0.08, hspace=0.52, wspace=0.62)

    fig.text(0.085, 0.967, "Search convergence and Pareto trade-offs", fontsize=11, fontweight="bold", ha="left")
    fig.text(
        0.085,
        0.943,
        "Fixed HELDOUT-selected KNN surrogate (k = 14); lines show median across 5 seeds and ribbons show IQR",
        fontsize=6.5,
        color="#4F5964",
        ha="left",
    )

    # Algorithm legend shared by the convergence rows.
    handles = [Line2D([0], [0], color=ALGO_COLORS[a_name], lw=1.7, label=a_name) for a_name in ALGORITHMS]
    fig.legend(handles=handles, loc="upper right", bbox_to_anchor=(0.99, 0.973), ncol=4, handlelength=1.5, columnspacing=1.0)

    for i, shape in enumerate(SHAPES):
        ax = fig.add_subplot(gs[0, 2 * i : 2 * i + 2])
        convergence_panel(ax, a, shape, "best_time_hours", "Best feasible incubation (h)", "A")
        if i == 0:
            ax.set_title("A  " + SHAPE_LABELS[shape], loc="left", fontsize=8, fontweight="bold", pad=3)
        ax.set_ylim(0, 6.35)
        if i:
            ax.set_ylabel("")
        if i < 2:
            ax.set_xlabel("")

    for i, shape in enumerate(SHAPES):
        ax = fig.add_subplot(gs[1, 2 * i : 2 * i + 2])
        convergence_panel(ax, b, shape, "best_robust_margin", "Worst-case normalized margin", "B")
        if i == 0:
            ax.set_title("B  " + SHAPE_LABELS[shape], loc="left", fontsize=8, fontweight="bold", pad=3)
        if i:
            ax.set_ylabel("")
        if i < 2:
            ax.set_xlabel("")

    axc = fig.add_subplot(gs[2, 0:4])
    grid_ordered = grid.sort_values("MgCl2")
    axc.plot(
        grid_ordered["MgCl2"],
        grid_ordered["absolute_target_error"],
        color="#48535E",
        lw=0.75,
        ls=(0, (2, 2)),
        alpha=0.65,
        zorder=1,
    )
    axc.scatter(
        grid["MgCl2"],
        grid["absolute_target_error"],
        s=35,
        marker="*",
        facecolor="white",
        edgecolor="#1F2933",
        linewidth=0.7,
        zorder=2,
        label="Coarse-grid reference",
    )
    for shape in SHAPES:
        sub = nsga[nsga["shape"] == shape]
        axc.scatter(
            sub["MgCl2"],
            sub["absolute_target_error"],
            s=17,
            c=SHAPE_COLORS[shape],
            marker=SHAPE_MARKERS[shape],
            alpha=0.76,
            linewidths=0,
            label=SHAPE_LABELS[shape],
            zorder=3,
            rasterized=True,
        )
    axc.set_xlabel("MgCl₂ feature (source-data units)")
    axc.set_ylabel("|D prediction − shape target| (µm²/s)")
    axc.set_title("C  NSGA-II Pareto front", loc="left", fontsize=8, fontweight="bold", pad=4)
    axc.grid(color="#DCE2E8", lw=0.55)
    axc.set_axisbelow(True)
    axc.legend(loc="upper right", ncol=2, handletextpad=0.4, columnspacing=0.8, markerscale=0.85)
    axd = fig.add_subplot(gs[2, 4:6])
    hv_stats = (
        hv.groupby("generation")["hypervolume"]
        .agg(
            median="median",
            q25=lambda values: values.quantile(0.25),
            q75=lambda values: values.quantile(0.75),
        )
        .reset_index()
    )
    axd.plot(hv_stats["generation"], hv_stats["median"], color="#3D6D9A", lw=1.5)
    axd.fill_between(hv_stats["generation"], hv_stats["q25"], hv_stats["q75"], color="#3D6D9A", alpha=0.18, linewidth=0)
    axd.set_xlabel("NSGA-II generation")
    axd.set_ylabel("Hypervolume")
    axd.set_title("D  Multi-objective convergence", loc="left", fontsize=8, fontweight="bold", pad=4)
    axd.grid(axis="y", color="#DCE2E8", lw=0.55)
    axd.set_axisbelow(True)

    fig.text(
        0.085,
        0.025,
        "Table 2 bands are qualitative. Predictions are exploratory; MgCl₂ units are unspecified in the CSV, and acidic-pH/DNase support is sparse.",
        fontsize=5.7,
        color="#4F5964",
        ha="left",
    )

    stem = FIG / "optimizer_convergence_and_pareto"
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {stem}.svg/.pdf/.png/.tiff")
    print(f"Dimensions: 7.2 x 8.2 in; raster export 600 dpi; text remains editable in SVG/PDF")


if __name__ == "__main__":
    main()
