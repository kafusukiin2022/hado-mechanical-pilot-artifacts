"""Benchmark SA, GA, PSO, BO, and NSGA-II on the fixed k=14 KNN surrogate.

All optimizer results are surrogate-model predictions, not experimental outcomes.
The paper's Table 2 bands are qualitative shape-specific stability ranges.
"""
from __future__ import annotations

import json
import math
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from scipy.special import ndtr
from sklearn.metrics import pairwise_distances


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)
DATA = ROOT / "research/DNA_origami_consensus_B_reproduction/source/data"
MODEL_PATH = ROOT / "research/heldout_knn_tuning/selected_model.joblib"

bundle = joblib.load(MODEL_PATH)
model = bundle["model"]
scaler = bundle["scaler"]
FEATURES = bundle["features"]
CONTINUOUS = FEATURES[:5]
target_name = bundle["target"]
train = pd.read_csv(DATA / "train.csv")
train_conditions = train[FEATURES].drop_duplicates().reset_index(drop=True)
train_x = np.column_stack(
    [scaler.transform(train_conditions[CONTINUOUS]), train_conditions[FEATURES[5:]].to_numpy()]
)
condition_distances = cdist(train_x, train_x)
np.fill_diagonal(condition_distances, np.inf)
loco_nn = condition_distances.min(axis=1)
SUPPORT_Q90 = float(np.quantile(loco_nn, 0.90))

SHAPES = ["Rectangles", "Rods", "Spheres"]
SHAPE_LABELS = {"Rectangles": "Rectangle", "Rods": "Rod", "Spheres": "Icosahedron"}
THRESHOLDS = {
    "Rods": (1.9, 3.3),
    "Spheres": (1.8, 4.0),
    "Rectangles": (1.4, 2.8),
}
TARGET_D = {s: sum(THRESHOLDS[s]) / 2 for s in SHAPES}
MG_MIN, MG_MAX = float(train["MgCl2_concentration"].min()), float(train["MgCl2_concentration"].max())
TIME_MIN, TIME_MAX = 15.0, 360.0  # maximum observed at 37 C; only two TRAIN rows at 360 min
EVAL_BUDGET = 150
POP_SIZE = 15
N_SEEDS = 5
SEEDS = [20261023, 20261024, 20261025, 20261026, 20261027]
ALGORITHMS = ["SA", "GA", "PSO", "BO"]
PH_GRID_B = np.round(np.arange(5.5, 6.5001, 0.1), 2)
PH_MIN, PH_MAX = 5.5, 6.5
T_FIXED, ENZYME_FIXED, TIME_FIXED = 37.0, 0.5, 60.0


def predict_rows(rows: np.ndarray) -> np.ndarray:
    frame = pd.DataFrame(rows, columns=FEATURES)
    X = np.column_stack([scaler.transform(frame[CONTINUOUS]), frame[FEATURES[5:]].to_numpy()])
    return model.predict(X)


def nn_distance(rows: np.ndarray) -> np.ndarray:
    frame = pd.DataFrame(rows, columns=FEATURES)
    X = np.column_stack([scaler.transform(frame[CONTINUOUS]), frame[FEATURES[5:]].to_numpy()])
    return cdist(X, train_x).min(axis=1)


def base_row(shape: str, mg: float, pH: float, incubation: float, enzyme: float = ENZYME_FIXED) -> list[float]:
    return [
        T_FIXED,
        float(mg),
        float(pH),
        float(incubation),
        float(enzyme),
        *[float(shape == name) for name in FEATURES[5:]],
    ]


def normalized_margin(D: np.ndarray | float, shape: str) -> np.ndarray | float:
    lo, hi = THRESHOLDS[shape]
    width = hi - lo
    return np.minimum((np.asarray(D) - lo) / width, (hi - np.asarray(D)) / width)


def nondominated_indices(values: np.ndarray) -> np.ndarray:
    """Return Pareto-front indices for minimization objectives."""
    values = np.asarray(values, dtype=float)
    if values.ndim != 2 or values.shape[1] != 2:
        raise ValueError("Pareto values must be a 2D array")
    if not np.isfinite(values).all():
        raise ValueError("Pareto objectives must be finite")
    if len(values) == 0:
        return np.array([], dtype=int)
    # For two minimized objectives, sort by objective 1 and retain only the
    # minimum objective-2 value at each new record-low level. Exact duplicate
    # objective pairs stay together so tied categorical designs remain visible.
    order = np.lexsort((values[:, 1], values[:, 0]))
    ordered = values[order]
    keep = []
    best_y = np.inf
    start = 0
    while start < len(order):
        end = start + 1
        while end < len(order) and ordered[end, 0] == ordered[start, 0]:
            end += 1
        group = ordered[start:end]
        group_min_y = group[:, 1].min()
        if group_min_y < best_y:
            local = np.flatnonzero(group[:, 1] == group_min_y)
            keep.extend(order[start + local])
            best_y = group_min_y
        start = end
    return np.asarray(keep, dtype=int)


def hypervolume_2d(values: np.ndarray, reference: tuple[float, float] = (1.05, 1.05)) -> float:
    if len(values) == 0:
        return 0.0
    vals = values[(values[:, 0] < reference[0]) & (values[:, 1] < reference[1])]
    if len(vals) == 0:
        return 0.0
    vals = vals[nondominated_indices(vals)]
    vals = vals[np.argsort(vals[:, 0])]
    area = 0.0
    for i, point in enumerate(vals):
        x_next = vals[i + 1, 0] if i + 1 < len(vals) else reference[0]
        area += max(0.0, x_next - point[0]) * max(0.0, reference[1] - point[1])
    return float(area)


def decode_unit(x: np.ndarray, bounds: list[tuple[float, float]]) -> np.ndarray:
    return np.array([lo + np.clip(v, 0, 1) * (hi - lo) for v, (lo, hi) in zip(x, bounds)])


def run_blackbox_optimizer(name: str, dim: int, objective, rng: np.random.Generator, budget: int = EVAL_BUDGET):
    """Run one maximization task with an equal objective-evaluation budget."""
    evals: list[dict] = []
    best_score = -np.inf
    best_value = None

    def evaluate(x: np.ndarray):
        nonlocal best_score, best_value
        x = np.clip(np.asarray(x, dtype=float), 0.0, 1.0)
        result = objective(x)
        score = float(result["score"])
        if score > best_score:
            best_score, best_value = score, result
        evals.append(
            {
                "eval": len(evals) + 1,
                "x": x.copy(),
                "score": score,
                "best_score": best_score,
                "best_value": best_value,
                "current_value": result,
            }
        )
        return score

    if name == "SA":
        x = rng.random(dim)
        score = evaluate(x)
        while len(evals) < budget:
            frac = len(evals) / max(1, budget - 1)
            proposal = np.clip(x + rng.normal(0, 0.18 * (1 - frac) + 0.025, size=dim), 0, 1)
            new_score = evaluate(proposal)
            temp = 0.12 * (1 - frac) + 0.006
            if new_score >= score or rng.random() < math.exp(min(0.0, (new_score - score) / temp)):
                x, score = proposal, new_score

    elif name == "GA":
        population: list[np.ndarray] = []
        fitness: list[float] = []
        while len(evals) < min(POP_SIZE, budget):
            x = rng.random(dim)
            population.append(x)
            fitness.append(evaluate(x))
        while len(evals) < budget:
            offspring: list[np.ndarray] = []
            offspring_fit: list[float] = []
            gen_n = min(POP_SIZE, budget - len(evals))
            for _ in range(gen_n):
                def tournament() -> np.ndarray:
                    picks = rng.integers(0, len(population), size=3)
                    return population[max(picks, key=lambda i: fitness[i])]
                a, b = tournament(), tournament()
                alpha = rng.uniform(-0.25, 1.25, size=dim)
                child = alpha * a + (1 - alpha) * b
                mutate = rng.random(dim) < (1 / dim)
                child = child + mutate * rng.normal(0, 0.12, size=dim)
                child = np.clip(child, 0, 1)
                offspring.append(child)
                offspring_fit.append(evaluate(child))
            combined = population + offspring
            combined_fit = fitness + offspring_fit
            order = np.argsort(combined_fit)[::-1][:POP_SIZE]
            population = [combined[i] for i in order]
            fitness = [combined_fit[i] for i in order]

    elif name == "PSO":
        n = min(POP_SIZE, budget)
        position = rng.random((n, dim))
        velocity = rng.normal(0, 0.08, size=(n, dim))
        personal = position.copy()
        personal_fit = np.array([evaluate(position[i]) for i in range(n)])
        while len(evals) < budget:
            gbest = personal[int(np.argmax(personal_fit))].copy()
            w = 0.72
            for i in range(n):
                if len(evals) >= budget:
                    break
                velocity[i] = (
                    w * velocity[i]
                    + 1.45 * rng.random(dim) * (personal[i] - position[i])
                    + 1.45 * rng.random(dim) * (gbest - position[i])
                )
                velocity[i] = np.clip(velocity[i], -0.25, 0.25)
                position[i] = np.clip(position[i] + velocity[i], 0, 1)
                score = evaluate(position[i])
                if score > personal_fit[i]:
                    personal[i] = position[i].copy()
                    personal_fit[i] = score

    elif name == "BO":
        from sklearn.gaussian_process import GaussianProcessRegressor
        from sklearn.gaussian_process.kernels import Matern

        X = []
        y = []
        n_init = min(12, budget)
        for _ in range(n_init):
            x = rng.random(dim)
            X.append(x)
            y.append(evaluate(x))
        kernel = Matern(length_scale=np.full(dim, 0.25), length_scale_bounds="fixed", nu=2.5)
        gp = GaussianProcessRegressor(
            kernel=kernel, alpha=1e-5, normalize_y=True, optimizer=None, random_state=int(rng.integers(1, 2**31 - 1))
        )
        while len(evals) < budget:
            gp.fit(np.asarray(X), np.asarray(y))
            candidates = rng.random((1024, dim))
            mean, std = gp.predict(candidates, return_std=True)
            imp = mean - float(np.max(y)) - 0.005
            z = np.divide(imp, std, out=np.zeros_like(imp), where=std > 1e-12)
            ei = imp * ndtr(z) + std * np.exp(-0.5 * z**2) / np.sqrt(2 * np.pi)
            x = candidates[int(np.argmax(ei))]
            val = evaluate(x)
            X.append(x)
            y.append(val)
    else:
        raise ValueError(name)
    return evals, best_value


def make_A_objective(shape: str):
    lo, hi = THRESHOLDS[shape]

    def objective(x: np.ndarray) -> dict:
        mg = MG_MIN + x[0] * (MG_MAX - MG_MIN)
        minutes = float(np.clip(round(TIME_MIN + x[1] * (TIME_MAX - TIME_MIN)), TIME_MIN, TIME_MAX))
        row = np.array([base_row(shape, mg, 7.4, minutes)])
        D = float(predict_rows(row)[0])
        dist = float(nn_distance(row)[0])
        violation = max(lo - D, 0.0, D - hi) / (hi - lo)
        feasible = violation <= 1e-12
        mg_norm = (mg - MG_MIN) / (MG_MAX - MG_MIN)
        score = (2.0 + minutes / TIME_MAX + 0.001 * (1 - mg_norm)) if feasible else -violation
        return {
            "score": score,
            "feasible": bool(feasible),
            "D": D,
            "mg": mg,
            "time_min": minutes,
            "time_h": minutes / 60,
            "violation": violation,
            "margin": float(normalized_margin(D, shape)),
            "nn_distance": dist,
            "support_q90": SUPPORT_Q90,
            "support_within_q90": bool(dist <= SUPPORT_Q90),
            "shape": shape,
        }

    return objective


def make_B_objective(shape: str):
    def objective(x: np.ndarray) -> dict:
        mg = MG_MIN + x[0] * (MG_MAX - MG_MIN)
        rows = np.array([base_row(shape, mg, pH, TIME_FIXED) for pH in PH_GRID_B])
        ds = predict_rows(rows)
        margins = np.asarray(normalized_margin(ds, shape))
        robust = float(np.min(margins))
        worst_i = int(np.argmin(margins))
        dist = nn_distance(rows)
        mg_norm = (mg - MG_MIN) / (MG_MAX - MG_MIN)
        score = robust - 1e-4 * mg_norm
        return {
            "score": score,
            "robust_margin": robust,
            "mg": mg,
            "D_min": float(np.min(ds)),
            "D_max": float(np.max(ds)),
            "worst_pH": float(PH_GRID_B[worst_i]),
            "all_pH_in_band": bool(robust >= 0),
            "nn_distance_worst": float(np.max(dist)),
            "support_q90": SUPPORT_Q90,
            "support_within_q90_worst": bool(np.max(dist) <= SUPPORT_Q90),
            "shape": shape,
        }

    return objective


def a_grid_reference():
    mg_grid = np.unique(
        np.r_[np.arange(MG_MIN, 10.0001, 0.05), np.arange(10.5, MG_MAX + 1e-8, 0.5), 10.0]
    )
    time_grid = np.arange(TIME_MIN, TIME_MAX + 1, 5, dtype=float)
    result = []
    for shape in SHAPES:
        rows = np.array([base_row(shape, mg, 7.4, tm) for tm in time_grid for mg in mg_grid])
        d = predict_rows(rows).reshape(len(time_grid), len(mg_grid))
        lo, hi = THRESHOLDS[shape]
        feasible = (d >= lo) & (d <= hi)
        if feasible.any():
            last_t = int(np.where(feasible.any(axis=1))[0][-1])
            mg_idxs = np.where(feasible[last_t])[0]
            min_mg_idx = int(mg_idxs[0])
            row = rows[last_t * len(mg_grid) + min_mg_idx]
            d_val = float(d[last_t, min_mg_idx])
            dist_val = float(nn_distance(row[None, :])[0])
            result.append(
                {
                    "shape": shape,
                    "shape_label": SHAPE_LABELS[shape],
                    "max_feasible_time_grid_min": float(time_grid[last_t]),
                    "minimum_Mg_at_that_time_grid": float(mg_grid[min_mg_idx]),
                    "predicted_D": d_val,
                    "stable_low": lo,
                    "stable_high": hi,
                    "normalized_margin": float(normalized_margin(d_val, shape)),
                    "nearest_condition_distance": dist_val,
                    "within_LOCO_q90": bool(dist_val <= SUPPORT_Q90),
                    "grid_mg_step_near_solution": 0.05 if mg_grid[min_mg_idx] < 10 else 0.5,
                    "grid_time_step_min": 5,
                }
            )
        else:
            result.append(
                {
                    "shape": shape,
                    "shape_label": SHAPE_LABELS[shape],
                    "max_feasible_time_grid_min": None,
                    "minimum_Mg_at_that_time_grid": None,
                    "predicted_D": None,
                    "stable_low": lo,
                    "stable_high": hi,
                    "normalized_margin": None,
                    "nearest_condition_distance": None,
                    "within_LOCO_q90": False,
                    "grid_mg_step_near_solution": None,
                    "grid_time_step_min": 5,
                }
            )
        # Store a coarse grid for per-shape feasibility diagnostics.
        rows_out = []
        for ti, tm in enumerate(time_grid):
            for mi, mg in enumerate(mg_grid):
                if feasible[ti, mi]:
                    rows_out.append(
                        {"shape": shape, "MgCl2": float(mg), "incubation_min": float(tm), "D_pred": float(d[ti, mi]), "stable": True}
                    )
        pd.DataFrame(rows_out).to_csv(OUT / f"scenario_A_{shape.lower()}_feasible_grid.csv", index=False)
    frame = pd.DataFrame(result)
    # Refine the minimum Mg value at the maximum feasible time on a 0.005
    # source-feature-unit grid. The broader grid above establishes the time
    # boundary; this one-dimensional sweep estimates its first feasible Mg.
    refined = []
    refine_step = 0.005
    mg_refine = np.r_[np.arange(MG_MIN, MG_MAX, refine_step), MG_MAX]
    for idx, row in frame.iterrows():
        shape = row["shape"]
        if pd.isna(row["max_feasible_time_grid_min"]):
            continue
        max_time = float(row["max_feasible_time_grid_min"])
        candidates = np.array([base_row(shape, mg, 7.4, max_time) for mg in mg_refine])
        d_values = predict_rows(candidates)
        lo, hi = THRESHOLDS[shape]
        feasible_idx = np.flatnonzero((d_values >= lo) & (d_values <= hi))
        if len(feasible_idx) == 0:
            continue
        best_i = int(feasible_idx[0])
        mg_best = float(mg_refine[best_i])
        d_best = float(d_values[best_i])
        distance = float(nn_distance(candidates[best_i : best_i + 1])[0])
        frame.loc[idx, "minimum_Mg_at_that_time_grid"] = mg_best
        frame.loc[idx, "predicted_D"] = d_best
        frame.loc[idx, "normalized_margin"] = float(normalized_margin(d_best, shape))
        frame.loc[idx, "nearest_condition_distance"] = distance
        frame.loc[idx, "within_LOCO_q90"] = bool(distance <= SUPPORT_Q90)
        frame.loc[idx, "grid_mg_step_near_solution"] = refine_step
        refined.append(
            {
                "shape": shape,
                "shape_label": SHAPE_LABELS[shape],
                "max_feasible_time_grid_min": max_time,
                "minimum_Mg_at_that_time_grid": mg_best,
                "predicted_D": d_best,
                "stable_low": lo,
                "stable_high": hi,
                "normalized_margin": float(normalized_margin(d_best, shape)),
                "nearest_condition_distance": distance,
                "LOCO_q90_reference": SUPPORT_Q90,
                "within_LOCO_q90": bool(distance <= SUPPORT_Q90),
                "Mg_grid_resolution_source_feature_units": refine_step,
            }
        )
    pd.DataFrame(refined).to_csv(OUT / "scenario_A_360min_Mg_refinement.csv", index=False)
    frame.to_csv(OUT / "scenario_A_grid_reference.csv", index=False)
    return frame


def b_grid_reference():
    mg_grid = np.unique(
        np.r_[np.arange(MG_MIN, 10.0001, 0.05), np.arange(10.5, MG_MAX + 1e-8, 0.5), 10.0]
    )
    out = []
    for shape in SHAPES:
        rows = np.array([base_row(shape, mg, pH, TIME_FIXED) for mg in mg_grid for pH in PH_GRID_B])
        ds = predict_rows(rows).reshape(len(mg_grid), len(PH_GRID_B))
        margins = np.asarray(normalized_margin(ds, shape))
        robust = margins.min(axis=1)
        max_idx = int(np.argmax(robust - 1e-4 * (mg_grid - MG_MIN) / (MG_MAX - MG_MIN)))
        worst_p = int(np.argmin(margins[max_idx]))
        nnd = nn_distance(rows).reshape(len(mg_grid), len(PH_GRID_B))
        out.append(
            {
                "shape": shape,
                "shape_label": SHAPE_LABELS[shape],
                "MgCl2_grid_optimum": float(mg_grid[max_idx]),
                "worst_case_normalized_margin": float(robust[max_idx]),
                "worst_case_pH": float(PH_GRID_B[worst_p]),
                "D_min_across_pH": float(ds[max_idx].min()),
                "D_max_across_pH": float(ds[max_idx].max()),
                "all_pH_in_band": bool(robust[max_idx] >= 0),
                "maximum_nearest_condition_distance": float(nnd[max_idx].max()),
                "within_LOCO_q90_for_all_pH": bool(nnd[max_idx].max() <= SUPPORT_Q90),
                "stable_low": THRESHOLDS[shape][0],
                "stable_high": THRESHOLDS[shape][1],
                "grid_mg_step_near_solution": 0.05 if mg_grid[max_idx] < 10 else 0.5,
            }
        )
    frame = pd.DataFrame(out)
    frame.to_csv(OUT / "scenario_B_grid_reference.csv", index=False)
    return frame


def write_blackbox_experiments():
    rows_a: list[dict] = []
    rows_b: list[dict] = []
    conv_a: list[dict] = []
    conv_b: list[dict] = []
    start = time.time()
    for scenario, shapes, objective_factory, row_store, conv_store, dim in [
        ("A", SHAPES, make_A_objective, rows_a, conv_a, 2),
        ("B", SHAPES, make_B_objective, rows_b, conv_b, 1),
    ]:
        bounds = [(0.0, 1.0)] * dim
        for shape_i, shape in enumerate(shapes):
            objective = objective_factory(shape)
            for algorithm in ALGORITHMS:
                for seed_i, seed in enumerate(SEEDS):
                    rng = np.random.default_rng(seed + 1000 * shape_i + (0 if scenario == "A" else 50000))
                    evaluations, best = run_blackbox_optimizer(algorithm, dim, objective, rng)
                    best_feas_time = -np.inf
                    best_feas_record = None
                    best_margin = -np.inf
                    best_margin_record = None
                    for ev in evaluations:
                        current = ev["current_value"]
                        if scenario == "A":
                            if current["feasible"] and (
                                current["time_min"] > best_feas_time
                                or (current["time_min"] == best_feas_time and (best_feas_record is None or current["mg"] < best_feas_record["mg"]))
                            ):
                                best_feas_time = current["time_min"]
                                best_feas_record = current.copy()
                            row_store.append(
                                {
                                    "scenario": scenario,
                                    "shape": shape,
                                    "algorithm": algorithm,
                                    "seed": seed,
                                    "eval": ev["eval"],
                                    **current,
                                    "best_feasible_time_min_so_far": None if best_feas_record is None else best_feas_record["time_min"],
                                    "best_feasible_mg_at_best_time_so_far": None if best_feas_record is None else best_feas_record["mg"],
                                    "best_feasible_D_so_far": None if best_feas_record is None else best_feas_record["D"],
                                    "best_feasible_nn_distance_so_far": None if best_feas_record is None else best_feas_record["nn_distance"],
                                }
                            )
                            conv_store.append(
                                {
                                    "scenario": scenario,
                                    "shape": shape,
                                    "algorithm": algorithm,
                                    "seed": seed,
                                    "eval": ev["eval"],
                                    "best_time_hours": None if best_feas_record is None else best_feas_record["time_h"],
                                    "best_Mg": None if best_feas_record is None else best_feas_record["mg"],
                                    "best_D": None if best_feas_record is None else best_feas_record["D"],
                                }
                            )
                        else:
                            if current["robust_margin"] > best_margin or (
                                current["robust_margin"] == best_margin and (best_margin_record is None or current["mg"] < best_margin_record["mg"])
                            ):
                                best_margin = current["robust_margin"]
                                best_margin_record = current.copy()
                            row_store.append(
                                {
                                    "scenario": scenario,
                                    "shape": shape,
                                    "algorithm": algorithm,
                                    "seed": seed,
                                    "eval": ev["eval"],
                                    **current,
                                    "best_robust_margin_so_far": None if best_margin_record is None else best_margin_record["robust_margin"],
                                    "best_Mg_at_margin_so_far": None if best_margin_record is None else best_margin_record["mg"],
                                    "best_max_nn_distance_so_far": None if best_margin_record is None else best_margin_record["nn_distance_worst"],
                                }
                            )
                            conv_store.append(
                                {
                                    "scenario": scenario,
                                    "shape": shape,
                                    "algorithm": algorithm,
                                    "seed": seed,
                                    "eval": ev["eval"],
                                    "best_robust_margin": None if best_margin_record is None else best_margin_record["robust_margin"],
                                    "best_Mg": None if best_margin_record is None else best_margin_record["mg"],
                                }
                            )
                    print(f"{scenario} {shape} {algorithm} seed={seed} done; best={best}", flush=True)
    pd.DataFrame(rows_a).to_csv(OUT / "scenario_A_optimizer_evaluations.csv", index=False)
    pd.DataFrame(rows_b).to_csv(OUT / "scenario_B_optimizer_evaluations.csv", index=False)
    pd.DataFrame(conv_a).to_csv(OUT / "scenario_A_convergence.csv", index=False)
    pd.DataFrame(conv_b).to_csv(OUT / "scenario_B_convergence.csv", index=False)
    print(f"A/B algorithm runs completed in {time.time()-start:.1f}s", flush=True)
    return pd.DataFrame(rows_a), pd.DataFrame(rows_b), pd.DataFrame(conv_a), pd.DataFrame(conv_b)


def nsga_nondominated_sort(F: np.ndarray) -> list[list[int]]:
    n = len(F)
    dominates_set = [[] for _ in range(n)]
    count = np.zeros(n, dtype=int)
    fronts = [[]]
    for p in range(n):
        for q in range(n):
            if p == q:
                continue
            if np.all(F[p] <= F[q]) and np.any(F[p] < F[q]):
                dominates_set[p].append(q)
            elif np.all(F[q] <= F[p]) and np.any(F[q] < F[p]):
                count[p] += 1
        if count[p] == 0:
            fronts[0].append(p)
    i = 0
    while i < len(fronts) and fronts[i]:
        next_front = []
        for p in fronts[i]:
            for q in dominates_set[p]:
                count[q] -= 1
                if count[q] == 0:
                    next_front.append(q)
        if next_front:
            fronts.append(next_front)
        i += 1
    return fronts


def crowding_distance(F: np.ndarray, front: list[int]) -> dict[int, float]:
    distance = {i: 0.0 for i in front}
    if len(front) <= 2:
        return {i: float("inf") for i in front}
    subset = F[front]
    for j in range(F.shape[1]):
        order = np.argsort(subset[:, j])
        distance[front[int(order[0])]] = float("inf")
        distance[front[int(order[-1])]] = float("inf")
        lo, hi = subset[order[0], j], subset[order[-1], j]
        if hi - lo <= 1e-12:
            continue
        for k in range(1, len(order) - 1):
            ix = front[int(order[k])]
            if np.isfinite(distance[ix]):
                distance[ix] += (subset[order[k + 1], j] - subset[order[k - 1], j]) / (hi - lo)
    return distance


def sbx(a: np.ndarray, b: np.ndarray, rng: np.random.Generator, eta: float = 15.0) -> tuple[np.ndarray, np.ndarray]:
    c1, c2 = a.copy(), b.copy()
    for j in range(2):
        if rng.random() <= 0.5 and abs(a[j] - b[j]) > 1e-14:
            x1, x2 = sorted((a[j], b[j]))
            u = rng.random()
            beta = 1 + 2 * x1 / (x2 - x1)
            alpha = 2 - beta ** -(eta + 1)
            if u <= 1 / alpha:
                betaq = (u * alpha) ** (1 / (eta + 1))
            else:
                betaq = (1 / (2 - u * alpha)) ** (1 / (eta + 1))
            y1 = 0.5 * ((x1 + x2) - betaq * (x2 - x1))
            beta = 1 + 2 * (1 - x2) / (x2 - x1)
            alpha = 2 - beta ** -(eta + 1)
            if u <= 1 / alpha:
                betaq = (u * alpha) ** (1 / (eta + 1))
            else:
                betaq = (1 / (2 - u * alpha)) ** (1 / (eta + 1))
            y2 = 0.5 * ((x1 + x2) + betaq * (x2 - x1))
            c1[j], c2[j] = np.clip(y1, 0, 1), np.clip(y2, 0, 1)
    return c1, c2


def polynomial_mutation(x: np.ndarray, rng: np.random.Generator, eta: float = 20.0) -> np.ndarray:
    child = x.copy()
    for j in range(2):
        if rng.random() < 1 / 3:
            u = rng.random()
            delta = (2 * u) ** (1 / (eta + 1)) - 1 if u < 0.5 else 1 - (2 * (1 - u)) ** (1 / (eta + 1))
            child[j] = np.clip(child[j] + delta, 0, 1)
    return child


def decode_c(x: np.ndarray) -> tuple[str, float, float]:
    mg = MG_MIN + np.clip(x[0], 0, 1) * (MG_MAX - MG_MIN)
    pH = PH_MIN + np.clip(x[1], 0, 1) * (PH_MAX - PH_MIN)
    shape = SHAPES[int(np.clip(round(x[2]), 0, 2))]
    return shape, float(mg), float(pH)


def evaluate_c(x: np.ndarray) -> dict:
    shape, mg, pH = decode_c(x)
    row = np.array([base_row(shape, mg, pH, TIME_FIXED)])
    D = float(predict_rows(row)[0])
    err = abs(D - TARGET_D[shape])
    dist = float(nn_distance(row)[0])
    return {
        "shape": shape,
        "shape_label": SHAPE_LABELS[shape],
        "MgCl2": mg,
        "pH": pH,
        "D_pred": D,
        "D_target": TARGET_D[shape],
        "absolute_target_error": err,
        "objective_error_scaled": err / 5.0,
        "objective_Mg_scaled": (mg - MG_MIN) / (MG_MAX - MG_MIN),
        "nn_distance": dist,
        "within_LOCO_q90": dist <= SUPPORT_Q90,
        "stable_low": THRESHOLDS[shape][0],
        "stable_high": THRESHOLDS[shape][1],
        "predicted_D_in_Table2_band": THRESHOLDS[shape][0] <= D <= THRESHOLDS[shape][1],
    }


def run_nsga2(seed: int, population_size: int = 64, generations: int = 60):
    rng = np.random.default_rng(seed)
    population = np.column_stack(
        [rng.random(population_size), rng.random(population_size), np.tile(np.arange(3), math.ceil(population_size / 3))[:population_size]]
    )
    rng.shuffle(population[:, 2])
    details = [evaluate_c(x) for x in population]
    F = np.array([[d["objective_error_scaled"], d["objective_Mg_scaled"]] for d in details])
    archive_x = [x.copy() for x in population]
    archive_d = details.copy()
    conv = []

    def rank_and_crowding(values: np.ndarray):
        fronts = nsga_nondominated_sort(values)
        rank = np.zeros(len(values), dtype=int)
        crowd = np.zeros(len(values), dtype=float)
        for r, front in enumerate(fronts):
            for i in front:
                rank[i] = r
            distances = crowding_distance(values, front)
            for i, value in distances.items():
                crowd[i] = value
        return fronts, rank, crowd

    def update_archive():
        nonlocal archive_x, archive_d
        values = np.array([[d["objective_error_scaled"], d["objective_Mg_scaled"]] for d in archive_d])
        front = nondominated_indices(values)
        archive_x = [archive_x[i] for i in front]
        archive_d = [archive_d[i] for i in front]

    def log_hv(gen: int):
        update_archive()
        values = np.array([[d["objective_error_scaled"], d["objective_Mg_scaled"]] for d in archive_d])
        conv.append({"seed": seed, "generation": gen, "evaluations": population_size * (gen + 1), "hypervolume": hypervolume_2d(values)})

    log_hv(0)
    for gen in range(1, generations + 1):
        fronts, rank, crowd = rank_and_crowding(F)

        def select_parent() -> np.ndarray:
            i, j = rng.integers(0, population_size, size=2)
            if rank[i] < rank[j] or (rank[i] == rank[j] and crowd[i] > crowd[j]):
                return population[i]
            return population[j]

        offspring = []
        off_details = []
        while len(offspring) < population_size:
            p1, p2 = select_parent(), select_parent()
            c1, c2 = sbx(p1, p2, rng)
            c1, c2 = polynomial_mutation(c1, rng), polynomial_mutation(c2, rng)
            # Shape is categorical: inherit one parent's shape before optional categorical mutation.
            for child in (c1, c2):
                child[2] = float(p1[2] if rng.random() < 0.5 else p2[2])
                if rng.random() < 0.12:
                    options = [s for s in range(len(SHAPES)) if s != int(child[2])]
                    child[2] = float(rng.choice(options))
            for child in (c1, c2):
                if len(offspring) >= population_size:
                    break
                detail = evaluate_c(child)
                offspring.append(child)
                off_details.append(detail)
                archive_x.append(child.copy())
                archive_d.append(detail)
        combined = np.vstack([population, np.asarray(offspring)])
        combined_details = details + off_details
        combined_F = np.array([[d["objective_error_scaled"], d["objective_Mg_scaled"]] for d in combined_details])
        fronts, _, _ = rank_and_crowding(combined_F)
        selected = []
        for front in fronts:
            if len(selected) + len(front) <= population_size:
                selected.extend(front)
            else:
                cd = crowding_distance(combined_F, front)
                selected.extend(sorted(front, key=lambda i: cd[i], reverse=True)[: population_size - len(selected)])
                break
        population = combined[selected]
        details = [combined_details[i] for i in selected]
        F = combined_F[selected]
        log_hv(gen)
    return archive_x, archive_d, conv


def c_grid_reference():
    mg_grid = np.unique(
        np.r_[np.arange(MG_MIN, 10.0001, 0.05), np.arange(10.5, MG_MAX + 1e-8, 0.5), 10.0]
    )
    ph_grid = np.round(np.arange(PH_MIN, PH_MAX + 1e-9, 0.05), 3)
    all_rows = []
    for shape in SHAPES:
        rows = np.array([base_row(shape, mg, pH, TIME_FIXED) for mg in mg_grid for pH in ph_grid])
        ds = predict_rows(rows)
        distances = nn_distance(rows)
        for row, dval, distance in zip(rows, ds, distances):
            mg, pH = row[1], row[2]
            err = abs(float(dval) - TARGET_D[shape])
            all_rows.append(
                {
                    "shape": shape,
                    "shape_label": SHAPE_LABELS[shape],
                    "MgCl2": float(mg),
                    "pH": float(pH),
                    "D_pred": float(dval),
                    "D_target": TARGET_D[shape],
                    "absolute_target_error": err,
                    "objective_error_scaled": err / 5,
                    "objective_Mg_scaled": (float(mg) - MG_MIN) / (MG_MAX - MG_MIN),
                    "nn_distance": float(distance),
                    "within_LOCO_q90": bool(distance <= SUPPORT_Q90),
                }
            )
    grid = pd.DataFrame(all_rows)
    vals = grid[["objective_error_scaled", "objective_Mg_scaled"]].to_numpy()
    front = grid.iloc[nondominated_indices(vals)].copy()
    front.to_csv(OUT / "scenario_C_grid_reference_front.csv", index=False)
    return grid, front


def main():
    t0 = time.time()
    a_ref = a_grid_reference()
    b_ref = b_grid_reference()
    print("Scenario A grid reference:\n", a_ref.to_string(index=False), flush=True)
    print("Scenario B grid reference:\n", b_ref.to_string(index=False), flush=True)
    a_rows, b_rows, conv_a, conv_b = write_blackbox_experiments()

    nsga_details = []
    nsga_conv = []
    for seed in SEEDS:
        xs, ds, cv = run_nsga2(seed)
        for d in ds:
            nsga_details.append({"seed": seed, **d})
        nsga_conv.extend(cv)
        print(f"NSGA-II seed={seed} front={len(ds)}", flush=True)
    nsga_df = pd.DataFrame(nsga_details)
    pareto_values = nsga_df[["objective_error_scaled", "objective_Mg_scaled"]].to_numpy()
    nsga_front = nsga_df.iloc[nondominated_indices(pareto_values)].copy()
    # Deduplicate near-identical solutions for a readable decision table.
    nsga_front["Mg_round"] = nsga_front["MgCl2"].round(3)
    nsga_front["pH_round"] = nsga_front["pH"].round(3)
    nsga_front = nsga_front.drop_duplicates(["shape", "Mg_round", "pH_round"])
    nsga_front = nsga_front.drop(columns=["Mg_round", "pH_round"]).sort_values(["MgCl2", "absolute_target_error"])
    nsga_front.to_csv(OUT / "scenario_C_nsga2_pareto_front.csv", index=False)
    pd.DataFrame(nsga_conv).to_csv(OUT / "scenario_C_nsga2_convergence.csv", index=False)
    _, grid_front = c_grid_reference()
    nsga_hv_by_seed = {}
    for seed in SEEDS:
        dd = nsga_df.query("seed == @seed")
        nsga_hv_by_seed[str(seed)] = hypervolume_2d(dd[["objective_error_scaled", "objective_Mg_scaled"]].to_numpy())
    grid_hv = hypervolume_2d(grid_front[["objective_error_scaled", "objective_Mg_scaled"]].to_numpy())
    nsga_hv = hypervolume_2d(nsga_front[["objective_error_scaled", "objective_Mg_scaled"]].to_numpy())

    # Algorithm summaries and recommendations by scenario/shape.
    a_final = a_rows[a_rows["eval"] == EVAL_BUDGET]
    a_summary = a_final.groupby(["shape", "algorithm"]).agg(
        feasible_runs=("best_feasible_time_min_so_far", lambda values: int(values.notna().sum())),
        median_best_time_h=("best_feasible_time_min_so_far", "median"),
        median_best_Mg=("best_feasible_mg_at_best_time_so_far", "median"),
        q25_best_Mg=("best_feasible_mg_at_best_time_so_far", lambda values: values.quantile(0.25)),
        q75_best_Mg=("best_feasible_mg_at_best_time_so_far", lambda values: values.quantile(0.75)),
        median_best_nn_distance=("best_feasible_nn_distance_so_far", "median"),
    ).reset_index()
    a_summary.to_csv(OUT / "scenario_A_algorithm_summary.csv", index=False)
    b_final = b_rows[b_rows["eval"] == EVAL_BUDGET]
    b_summary = b_final.groupby(["shape", "algorithm"]).agg(
        median_robust_margin=("best_robust_margin_so_far", "median"),
        q25_robust_margin=("best_robust_margin_so_far", lambda values: values.quantile(0.25)),
        q75_robust_margin=("best_robust_margin_so_far", lambda values: values.quantile(0.75)),
        median_best_Mg=("best_Mg_at_margin_so_far", "median"),
        q25_best_Mg=("best_Mg_at_margin_so_far", lambda values: values.quantile(0.25)),
        q75_best_Mg=("best_Mg_at_margin_so_far", lambda values: values.quantile(0.75)),
        runs_stable_across_pH=("best_robust_margin_so_far", lambda values: int((values >= 0).sum())),
        median_max_nn_distance=("best_max_nn_distance_so_far", "median"),
    ).reset_index()
    b_summary.to_csv(OUT / "scenario_B_algorithm_summary.csv", index=False)

    # Cross-check each algorithm's best solution against deterministic grid oracle.
    recommendations = []
    for shape in SHAPES:
        row = a_ref.query("shape == @shape").iloc[0].to_dict()
        recommendations.append({"scenario": "A", **row})
    for shape in SHAPES:
        row = b_ref.query("shape == @shape").iloc[0].to_dict()
        recommendations.append({"scenario": "B", **row})
    pd.DataFrame(recommendations).to_csv(OUT / "model_recommendations.csv", index=False)

    report = {
        "experiment": "Four single-objective optimizers and NSGA-II on fixed HELDOUT-selected k=14 KNN surrogate",
        "model_artifact": "research/heldout_knn_tuning/selected_model.joblib",
        "parameters": bundle["selected_params"],
        "seeds": SEEDS,
        "single_objective_evaluations_per_run": EVAL_BUDGET,
        "single_objective_repeats": N_SEEDS,
        "nsga2": {"population": 64, "generations": 60, "objective_evaluations_per_seed": 64 * 61, "objective_evaluations_total": 64 * 61 * N_SEEDS, "repeats": N_SEEDS},
        "single_objective_total_evaluations_A": len(SHAPES) * len(ALGORITHMS) * N_SEEDS * EVAL_BUDGET,
        "single_objective_total_evaluations_B": len(SHAPES) * len(ALGORITHMS) * N_SEEDS * EVAL_BUDGET,
        "table2_qualitative_stable_bands_um2_s": THRESHOLDS,
        "shape_label_mapping": SHAPE_LABELS,
        "D_target_band_midpoints_um2_s": TARGET_D,
        "scenario_conditions": {
            "A": {"T_C": 37, "pH": 7.4, "DNase_U_mL": 0.5, "Mg_range_source_feature_units": [MG_MIN, MG_MAX], "time_min": [TIME_MIN, TIME_MAX], "shape_evaluated_separately": True},
            "B": {"T_C": T_FIXED, "time_min": TIME_FIXED, "DNase_U_mL": ENZYME_FIXED, "pH_grid": PH_GRID_B.tolist(), "Mg_range_source_feature_units": [MG_MIN, MG_MAX], "shape_evaluated_separately": True},
            "C": {"T_C": T_FIXED, "time_min": TIME_FIXED, "DNase_U_mL": ENZYME_FIXED, "pH_range": [PH_MIN, PH_MAX], "target_D": TARGET_D, "optimize_shape": True},
        },
        "training_support": {
            "distinct_conditions": int(len(train_conditions)),
            "loco_nearest_condition_distance_q90": SUPPORT_Q90,
            "37C_time_max_min": 360,
            "train_rows_at_37C_360min": int(((train.Temperature == 37) & (train.Incubation_time == 360)).sum()),
            "observed_DNase_levels": sorted(train.DNase_I_concentration.unique().tolist()),
            "0.5_U_mL_is_observed": bool(np.any(np.isclose(train.DNase_I_concentration, 0.5))),
            "source_Mg_feature_unit_explicit_in_csv": False,
            "paper_standard_Mg_condition_mM": 10,
        },
        "algorithm_summary": {
            "scenario_A": a_summary.to_dict(orient="records"),
            "scenario_B": b_summary.to_dict(orient="records"),
        },
        "scenario_C_grid_reference_front_points": int(len(grid_front)),
        "scenario_C_nsga2_front_points": int(len(nsga_front)),
        "scenario_C_grid_reference_hypervolume": grid_hv,
        "scenario_C_nsga2_hypervolume": nsga_hv,
        "scenario_C_nsga2_hypervolume_fraction_of_grid": nsga_hv / grid_hv if grid_hv else None,
        "scenario_C_nsga2_hypervolume_by_seed": nsga_hv_by_seed,
        "elapsed_seconds": time.time() - t0,
        "model_selection_caveat": "This is the exploratory HELDOUT-selected k=14 model; it does not replace the locked k=20 primary model. HELDOUT was searched across 432 settings, and the nine-condition prospective endpoint has already been inspected during earlier exploratory tuning, so these scenario optima are not confirmatory validation.",
        "interpretation": "All outputs are predictions from a fixed KNN surrogate, not experimental outcomes. Table 2 bands are qualitative shape-specific stability ranges, not safety limits. The MgCl2 feature has no explicit unit metadata in the CSV, so reported values remain in source-feature units. Acidic pH with DNase=0.5 U/mL and A's DNase=0.5 are outside the observed combination support. Boundary optima and predictions outside the typical training neighborhood require materials experiments for confirmation.",
    }
    (OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print("FINAL_REPORT", json.dumps(report, indent=2), flush=True)
    print(f"Total runtime: {time.time()-t0:.1f}s", flush=True)


if __name__ == "__main__":
    main()
