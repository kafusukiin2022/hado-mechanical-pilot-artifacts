# DNA origami stability research harness

本目录保存 DNA origami 纳米材料稳定性复现、模型实验和可复现产物。研究主题属于**材料科学/纳米材料稳定性与机器学习建模**；不要仅因材料名称含有 DNA 就误分类为生物学或生命科学研究。所有后续会话先读取本文件、`progress.md`、`feature_list.json` 和 `session-handoff.md`。

## 启动流程

1. 运行 `./init.sh`，确认环境、数据完整性和模型可加载。
2. 阅读 `progress.md`，再阅读 `research/RESEARCH_LOG.md` 的最新条目。
3. 检查 `feature_list.json`，一次只推进一个未完成事项。
4. 任何新实验都写入研究日志，并记录数据划分、是否使用外部标签和验证命令。

## 工作规则

- `research/final_metrics.json` 中的严格主结果已锁定；不得用同一 9 个 prospective 条件反复调参。
- 训练/验证按完整八维条件分组，避免重复测量泄漏。
- 未经明确说明，不把 HELDOUT（99/100 条件与 TRAIN 重叠）称为独立外部测试。
- 结论必须同时报告指标、样本量和不确定性；探索性结果不得写成已证实的普适泛化。
- 领域分类遵循用户明确纠正：这是材料科学研究，不是生物学/生命科学研究；若任务范围未变，不得因 DNA origami 术语触发领域拒绝。
- 新模型必须保留脚本、配置、预测结果和可重跑命令。
- 结束会话前更新 `progress.md`、`feature_list.json` 和 `session-handoff.md`。

## 关键验证

```bash
./init.sh
python research/raw_knn_final/predict.py \
  --input research/DNA_origami_consensus_B_reproduction/source/data/new.csv \
  --output /tmp/dna_origami_predictions.csv
```

## 完成定义

- 实验或文档产物已保存；
- 验证命令通过；
- 数据划分、标签使用和局限性已记录；
- 可由下一会话按 `session-handoff.md` 恢复。
