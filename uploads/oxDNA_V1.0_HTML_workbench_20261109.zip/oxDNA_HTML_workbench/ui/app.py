#!/usr/bin/env python3
"""Local browser UI for the fixed oxDNA copyright-demo inference package."""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path(__file__).resolve().parents[1]
UI = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
LOCK = threading.Lock()
RUN = {"state": "idle", "log": "", "error": None}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_pair(top_path, conf_path):
    top_lines = Path(top_path).read_text(errors="replace").splitlines()
    if not top_lines:
        raise ValueError("拓扑文件为空")
    header = top_lines[0].split()
    if len(header) < 2:
        raise ValueError("拓扑首行缺少核苷酸数和链数")
    count, strands = int(header[0]), int(header[1])
    if count <= 0 or strands <= 0:
        raise ValueError("核苷酸数和链数必须为正整数")
    rows = [line for line in top_lines[1:] if line.strip()]
    if len(rows) != count:
        raise ValueError("拓扑声明 {} 个核苷酸，实际 {} 行".format(count, len(rows)))
    conf_lines = Path(conf_path).read_text(errors="replace").splitlines()
    if len(conf_lines) < 3:
        raise ValueError("构型文件缺少 oxDNA 头部")
    data_rows = [line for line in conf_lines[3:] if line.strip()]
    if len(data_rows) != count:
        raise ValueError("构型有 {} 行，拓扑声明 {} 个核苷酸".format(len(data_rows), count))
    parsed = []
    for idx, line in enumerate(data_rows):
        values = [float(v) for v in line.split()]
        if len(values) < 15 or not all(map(lambda x: x == x and abs(x) != float("inf"), values[:15])):
            raise ValueError("构型第 {} 行不是有限的 15 列 oxDNA 数据".format(idx + 1))
        parsed.append(values)
    topology = []
    for row in rows:
        fields = row.split()
        if len(fields) < 4:
            raise ValueError("拓扑行字段不足")
        topology.append([int(fields[0]), fields[1], int(fields[2]), int(fields[3])])
    if len(set(row[0] for row in topology)) != strands:
        raise ValueError("拓扑声明的链数与实际链数不一致")
    for i, row in enumerate(topology):
        if row[0] <= 0 or row[1] not in ("A", "T", "C", "G", "U"):
            raise ValueError("拓扑第 {} 行链编号或碱基无效".format(i + 1))
        for col, reciprocal in ((2, 3), (3, 2)):
            j = row[col]
            if j < -1 or j >= count or j == i:
                raise ValueError("拓扑第 {} 行连接索引越界或自连接".format(i + 1))
            if j >= 0 and (topology[j][0] != row[0] or topology[j][reciprocal] != i):
                raise ValueError("拓扑第 {} 行骨架连接不互反或跨链".format(i + 1))
    return {"count": count, "strands": strands, "topology": topology, "coords": parsed}


def sample_payload():
    top, conf = ROOT / "sample/sample.top", ROOT / "sample/start.conf"
    data = parse_pair(top, conf)
    data["name"] = "软著示例输入"
    data["source"] = "package sample"
    return data


def run_inference(body):
    try:
        if body.get("top_text") is not None and body.get("start_text") is not None:
            upload = RESULTS / "ui_input"
            upload.mkdir(parents=True, exist_ok=True)
            top = upload / "input.top"
            start = upload / "start.conf"
            top.write_text(body["top_text"])
            start.write_text(body["start_text"])
        else:
            top = Path(body.get("top") or ROOT / "sample/sample.top").expanduser().resolve()
            start = Path(body.get("start") or ROOT / "sample/start.conf").expanduser().resolve()
        if not top.is_file() or not start.is_file():
            raise ValueError("请提供存在的 .top 与 .conf/.dat 文件")
        parse_pair(top, start)
        output = RESULTS / "ui_prediction.conf"
        summary = RESULTS / "ui_prediction.json"
        cmd = [sys.executable, str(ROOT / "scripts/ebd_oxdna_shared_rigid_predict.py"),
               "--checkpoint", str(ROOT / "model/model_best.pt"),
               "--bundle", str(ROOT / "model/inference_bundle.json"),
               "--top", str(top), "--start", str(start),
               "--output", str(output), "--summary-json", str(summary), "--device", "cpu"]
        proc = subprocess.Popen(cmd, cwd=str(ROOT), env=dict(os.environ, PYTHONNOUSERSITE="1"),
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        lines = []
        for line in proc.stdout:
            lines.append(line.rstrip())
            with LOCK:
                RUN["log"] = "\n".join(lines[-80:])
        code = proc.wait()
        if code:
            raise RuntimeError("推理程序退出码 {}\n{}".format(code, "\n".join(lines[-30:])))
        pred = parse_pair(top, output)
        pred.update(name="模型预测结果", source="local inference", summary=json.loads(summary.read_text()))
        inp = parse_pair(top, start)
        inp.update(name="起始构型", source="user input", sha256=sha256(start))
        pred["sha256"] = sha256(output)
        with LOCK:
            RUN.update(state="complete", log="\n".join(lines[-80:]), error=None,
                       input=inp, prediction=pred, summary=json.loads(summary.read_text()))
    except Exception as exc:
        with LOCK:
            RUN.update(state="error", error=str(exc))


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def send_json(self, obj, status=200):
        raw = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/sample":
            try:
                return self.send_json(sample_payload())
            except Exception as exc:
                return self.send_json({"error": str(exc)}, 500)
        if path == "/api/status":
            with LOCK:
                data = {k: v for k, v in RUN.items() if k in ("state", "log", "error", "input", "prediction", "summary")}
            return self.send_json(data)
        if path == "/api/file":
            query = dict(part.split("=", 1) for part in urlparse(self.path).query.split("&") if "=" in part)
            file_path = Path(unquote(query.get("path", ""))).expanduser().resolve()
            if not file_path.is_file() or file_path.suffix.lower() not in (".top", ".conf", ".dat"):
                return self.send_json({"error": "仅支持本地 .top/.conf/.dat 文件"}, 400)
            try:
                return self.send_json(parse_pair(file_path if file_path.suffix == ".top" else query.get("top", ""),
                                                  file_path if file_path.suffix != ".top" else query.get("start", "")))
            except Exception as exc:
                return self.send_json({"error": str(exc)}, 400)
        if path == "/api/output":
            with LOCK:
                if RUN["state"] != "complete":
                    return self.send_json({"error": "当前运行尚无可下载结果"}, 409)
                out = RESULTS / "ui_prediction.conf"
                if not out.exists():
                    return self.send_json({"error": "尚无预测结果"}, 404)
                raw = out.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Disposition", 'attachment; filename="prediction.conf"')
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            return self.wfile.write(raw)
        if path == "/vendor/three.js":
            three = Path(os.environ.get("THREE_JS", str(UI / "vendor/three.js")))
            if three.is_file():
                raw = three.read_bytes()
                self.send_response(200); self.send_header("Content-Type", "application/javascript")
                self.send_header("Content-Length", str(len(raw))); self.end_headers(); return self.wfile.write(raw)
            self.send_error(404); return
        target = UI / ("index.html" if path in ("/", "") else path.lstrip("/"))
        if target.is_file() and target.parent == UI:
            raw = target.read_bytes()
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw))); self.end_headers(); return self.wfile.write(raw)
        self.send_error(404)

    def do_POST(self):
        if urlparse(self.path).path != "/api/run":
            return self.send_error(404)
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size < 0 or size > 64 * 1024 * 1024:
                return self.send_json({"error": "请求超过 64 MiB 限制"}, 413)
            body = json.loads(self.rfile.read(size) or b"{}")
            if not isinstance(body, dict):
                raise ValueError("请求须为JSON对象")
            if ("top_text" in body) != ("start_text" in body):
                raise ValueError("必须同时提供拓扑和构型")
            if "top_text" in body and not all(isinstance(body[k], str) for k in ("top_text", "start_text")):
                raise ValueError("输入文件内容必须为文本")
        except Exception:
            return self.send_json({"error": "请求数据无效"}, 400)
        with LOCK:
            if RUN["state"] == "running":
                return self.send_json({"error": "已有推理运行中，请等待完成"}, 409)
            RUN.clear()
            RUN.update(state="running", log="", error=None, started=time.time())
        thread = threading.Thread(target=run_inference, args=(body,), daemon=True)
        thread.start()
        self.send_json({"state": "running"}, 202)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    RESULTS.mkdir(exist_ok=True)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print("oxDNA local UI: http://{}:{}/".format(args.host, args.port), flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
