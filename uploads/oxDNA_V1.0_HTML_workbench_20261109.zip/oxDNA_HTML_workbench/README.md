# 固定 V1.0 的独立复现包

目录中含推理与训练入口、直接导入的自有模块、推理接口测试、固定权重、输入样例。历史 EGNN 适配脚本保留原样；仅在调用其 `_load_egnn_class` 分支时才需要外部 `EBD/models/egnn.py`。固定 dgnn-lite 推理和本包内 25 项测试不加载该第三方实现。

在已配置 PyTorch 1.8.1、NumPy 1.21.6、SciPy 1.7.3 的 Python 3.7 环境中：

```bash
PYTHON_BIN=/path/to/python ./run_tests.sh
PYTHON_BIN=/path/to/python ./run_demo.sh
```

所有命令从本目录使用相对数据路径。`results/` 保存新的输出。源文件、模型和样例散列分别见上层清单和 `sample/provenance.json`。训练全量重跑需原 77 个样本及其授权数据，不由这个单样本复现包提供。

## 本地浏览器工作台（2026-11-09）

在具备本包 PyTorch/NumPy/SciPy 环境的终端运行：

```bash
PYTHONNOUSERSITE=1 PYTHON_BIN=/home/lijingjing/lijj/.conda/envs/ebd/bin/python ./run_ui.sh --port 8765
```

浏览器打开 `http://127.0.0.1:8765`。远程服务器可先建立 SSH 端口转发 `ssh -L 8765:127.0.0.1:8765 用户@服务器`，再打开本机地址。停止服务按 Ctrl+C。

载入内置示例，或同时选择 `.top` 与 `.conf/.dat`；通过计数、有限数值、链数和互反骨架索引检查后，运行固定CPU模型。上传文件只传到当前本地服务，不发送至云端。完成后可切换输入/输出预览、下载 `prediction.conf`。侧栏可定位结构检查与本页面运行记录；运行中锁定输入。重新载入输入会清空页面旧结果。运行记录仅当前页面有效，输出文件保存在 `results/ui_prediction.conf` 和 `.json`，下次运行覆盖。

三维预览使用随包 `ui/vendor/three.js`，依赖支持 WebGL 的浏览器；按链着色显示全部核苷酸与拓扑骨架。滚轮缩放、拖动旋转。预览与格式检查不代表物理有效性或预测精度认证。样例输出存在4条盒外坐标提示，界面如实展示，未自动改变预测坐标。

本次新增UI未重建旧申请文档/源代码清单/ZIP；旧包的“无自主图形界面”范围描述属于历史版本，若将UI纳入正式申请需同步更新材料。本轮收尾计划与证据位于项目 `docs/harness/copyright_html_workbench_20261109.md`、`outputs/copyright_html_workbench_20261109/`。
