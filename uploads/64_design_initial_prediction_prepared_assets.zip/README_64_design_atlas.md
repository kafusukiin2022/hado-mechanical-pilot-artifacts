# 64-design Initial / prediction / Prepared atlas

This atlas contains one page per design (H101–H164) from the 64-design training split. Each page shows all nucleotide coordinates in three panels:

1. **Initial** input coordinates (gray)
2. **Model prediction (PBD96)**: the shared corrected rigid-segment GNN prediction after Gaussian control smoothing, 24 geometric substeps, and 96 fragment-center PBD iterations per substep (blue)
3. **Prepared** aligned training target (orange)

The model is evaluated with the 64-design training checkpoint `runs/rigid_64_corrected/best.pt`; this is a training-internal overfit result with no validation/test claim. Prepared coordinates are used only for supervision and post-hoc evaluation, not as model input during prediction. Coordinates are shown in native dataset units; no Angstrom conversion is implied.

`64_design_initial_prediction_prepared.pdf` is a 64-page atlas. `pages/*.png` are 300-dpi previews and `pages/*.svg` retain editable text with rasterized point marks. `64_design_rmsd.csv` contains per-design node/fragment counts, raw endpoint RMSD, PBD96 endpoint RMSD, and Kabsch RMSD values.
