# 2026-11-01–07 工作清单与证据索引

先读 WORKLOG_AND_EVIDENCE_INDEX_ZH.md：按日期列出64条任务记录（含一对重复，63项主题），每项有结果、核对状态、限制和证据入口。筛选时打开 WORK_ITEMS.csv；完整证据在 EVIDENCE_INDEX.md/CSV/JSON。

TIMELINE_ZH.md 保留107个原日志事件；FIGURE_INDEX_ZH.md 链接12个现成图表文件。snapshots/保留整理前的任务表、进度和交接，避免更正覆盖历史。VERIFICATION.json与audit/保存本次核对、Slurm/本机进程查询以及命令起止时间、耗时和退出状态。

这是清单与索引包，不包含全部原始轨迹、权重、缓存拷贝。证据链接使用同一工作区绝对路径，CSV同时保存项目路径。大型文件只索引或引用历史manifest；856个小型证据重算SHA，112条原引用补全或识别为历史远端引用。本次未重跑MD/训练或在线核对GitHub当前状态。

SHA256SUMS.txt验证本包文件，路径相对于Geodiff_fam根目录；它不是所有实验原始数据均被重新校验的声明。
