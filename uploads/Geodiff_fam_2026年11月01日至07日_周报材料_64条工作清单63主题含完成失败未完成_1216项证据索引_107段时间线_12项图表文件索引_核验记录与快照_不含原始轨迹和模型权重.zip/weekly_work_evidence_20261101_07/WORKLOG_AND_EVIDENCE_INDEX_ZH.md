# 过去一周工作清单与证据索引

**统计范围：** 2026-11-01 至 2026-11-07（北京时间）；本次核对截至 2026-11-07 09:16（北京时间）。整理前的仓库连续记录中，本周最后一条研究工作记录日期为 11 月 6 日。  
**范围说明：** 包括本项目 `feature_list.json` 中与本周日期相关的工作，以及 `progress.md` 的周内实验记录。跨周任务只计入本周实际执行、分析、发布或状态核对的部分。  
**证据原则：** 分开记录设计/代码完成、计算完成、指标结果和物理有效性；训练跑完不等于模型效果通过。路径指向项目内原始报告、JSON、日志、CSV、图、校验文件、检查点或发布清单。本目录不复制或改写原始实验数据。

## 本周工作概览

本周主线从 TALOS97/Flat42 的 RMSF 数据与模型诊断，逐渐转向轨迹统计可靠性、构象生成以及 DNA origami 的 oxDNA 输出路径。共登记 **64 条任务记录**（含一对重复登记，折合63项主题工作），详见下方完整登记表；其中包括完成的分析/实验、失败及部分完成任务、尚未结题的训练和被取代的运行。另逐一索引连续日志中的 107 个事件标题，覆盖临时诊断、取消重排、兼容性修复及发布更正。

### 1. 轨迹与数据可信度

- 对 `6hb_048` 三条既有 100M 步轨迹做分段稳定性、逐核苷酸 RMSF 副本间复现性、5M/100M 对比和前缀长度分析。全轨迹 RMSF 排名的副本间 Spearman 为 **0.917–0.944**，但轨迹均值/结构位置仍未收敛；因此结果支持相对移动节点排名复现，不能据此宣称平衡态或绝对 RMSF 已收敛。75M 是本次测试中首次达到所有副本对 rho >0.90 的前缀，不代表普适阈值。
- TALOS97 追加 20M 的分片任务最终为 **90/97** 达到 25M；**7 个**设计出现 NaN，相关错误检查点不是可用重启点。依赖完整设计队列的总体任务因此是部分完成。
- Flat42 39 设计 25M campaign：**20/39** 完成生产并通过末态检查，**19/39** 在生产前因普通 FENE 初始化失败，之后没有自动恢复或重提。
- Mango250：核查了 250 个几何条目/270 个拓扑登记项；双路径 pilot 只在一个等边代表几何上完成 DAEDALUS2 (DX/2HB) 与 TALOS (6HB) 转换和短程 oxDNA 冒烟测试。另对随包 oxDNA v3.7 输入作批量 FENE 检查，250/250 在积分开始前失败。后续 DX/2HB A100 长跑 job 22682 也在 CUDA 初始化/预检阶段失败；键边 27–28 的骨架作用点间距为 19.602521。短程 pilot 不能解释为长时稳定或全库兼容。
- 完成 TALOS97 原始结构、拓扑、未配对坐标重建、300-family 数据集 oxDNA 准备度，以及 oxDNA 版本/历史 5M+20M 参数审计。这些为只读审计或格式/可行性检查，不等于新模拟结果。

### 2. RMSF 预测与统计建模

- 对新 20M 标签上的普通 MSE/加权损失和多种图结构、读出、表示、刚体不变性、模态顺应性、平方目标、协方差/振幅等假设做了配对训练或只读诊断。多数实验提供机制线索，没有支持稳定、普遍的模型增益；验证集复用、历史特征筛选和单种子结果均在原始报告中标注。
- 逐设计轨迹分析显示 070 的一段 315 nt 高 RMSF 区域，纯刚体重建均值 RMSF **4.394 nm**，接近轨迹值 **4.572 nm**，说明该片段的主要变动可由整体刚体运动解释；这是对单个区域/轨迹窗口的描述性分解，不是 GNN 因果证明。
- Graph Diffusion V1、论文对照训练、层级 log-normal V2、clean 3-seed Macro-RMSE、Flat42 数据增广以及方向/持久性模型均产出了可追溯的代码、指标或报告。重点结论是：若干变体与基线相近或略有改进，但不足以概括为稳定的泛化提升；Flat42 增加 20 个训练构型后的 17 个历史验证设计 Macro RMSE 变化约 **0.33093→0.32853 nm（约 0.72%）**。
- 108 个设计的节点 RMSF 分布图表与数据包完成并上传；TALOS97 源数据包、模型复现材料及 DNA-CGDM/DDPM 源代码包也完成远端发布和哈希核验。远端 commit、包清单与校验结果见证据索引。

### 3. DNA 构象生成与扩散模型

- DNA-CGDM 完成实现/缓存/测试/导出冒烟与源代码打包发布；正式 D 训练曾启动，但本次核对时本地最新训练状态为 **epoch 36/120**，状态和日志停留在 11 月 5 日，未在本次主机gpu03发现相应旧PID，故不能报告训练完成或模型效果。
- 单设计 DDPM 训练按用户指示在 step 1000 停止并保留 checkpoint；其后 M64 评估只记录到 seed 101 的 18/64 样本。已有部分指标出现 RMSF RMSE 约 **5,174–5,342 nm** 的极端发散。本次核对时状态文件已过期且未在本次主机gpu03发现相应旧PID；将其列为中断的部分评估。
- 69 设计 × 100 帧 DDPM 训练完成 **6,900/6,900** 更新，但验证生成暴露严重数值发散：两端设计 M8/DDIM100 的 RMSF RMSE 约 **2,430–2,454 nm**。只读诊断确认 cosine schedule 末端 `alpha_bar[499]=9.715e-9`，terminal epsilon RMSE 约 0.19 经 `1/sqrt(alpha_bar)` 放大，clean estimate 约 1,900 nm。该结果否定原始采样质量，不是合格生成器结果。
- 同预算三 A100 对照（epsilon、epsilon identity skip、v-prediction）已经于 11 月 6 日完成并生成比较文件。epsilon 组验证 RMSF RMSE 仍约 2,432–2,446 nm；identity-skip 与 v 两组在两个验证设计、每设计 8 个样本下约 0.46–0.93 nm。它说明末端参数化对数值稳定性影响显著，但 M8 小样本、两设计验证、均值/协方差误差仍偏大，不能据此宣称物理或分布质量已通过。
- 对 DeFlow、Flow4D、DeltaFlow 预训练 checkpoint 做了下载校验与迁移适配性审计。三者权重 SHA 与镜像 LFS oid 匹配、张量有限，但与现有 DNA diffusion 模型无同名同形权重；直接把 DNA 坐标视为场景点云还会因坐标范围截断大量点。因此没有启动迁移微调。

### 4. 本次状态核验与限制

- 本目录不是 Git worktree，无法用 Git 历史重建逐日变更；因此以 harness 任务表、连续进度记录、实验文件、日志和可核对的 Slurm 记录为主要来源。`./init.sh` 本次通过；CodeGraph 文件索引可用。
- 本次读取 Slurm 记录确认 job **23239** 已于 2026-11-06 18:22 CST `COMPLETED`，`comparison.json` 的状态为 `complete`。本报告按这份最终输出校正任务表中仍残留的 `in_progress`。
- DNA-CGDM 和单设计 DDPM 是过期状态文件：未找到本地活动 PID，最近文件修改时间分别为 11 月 5 日和 11 月 6 日。不能由此推出远端/外部环境绝对没有作业；只能说明当前项目可见进程和状态证据不足以证明它们还在运行。
- 一些老任务的状态字段与其摘要互相矛盾（例如状态仍为 `in_progress`，摘要已写全任务结束）。完整登记表保留原字段并在摘要中注明可核对的结果；本报告不把状态标签当作强于原始日志/结果文件的证据。

## 做汇报时建议采用的主结论

1. **采样长度需要和结论边界一起报告：** 6hb_048 的移动节点相对排序较可重复，但全局/分段结构均值没有达到稳定判据；TALOS97 与 Flat42 批量任务有明确失败和未完成比例。
2. **模型研究有若干有效诊断，但总体泛化提升仍有限：** 本周通过 matched ablation、冻结读出和数据增广等方式排除或削弱了多个假设，避免把偶然单次改进包装成稳定收益。
3. **原始 DDPM 训练损失不能代表结构生成质量：** 6,900 更新的模型采样严重发散；epsilon identity-skip/v 对照显著缓解数值问题，但还未通过充分采样、统计分布与 oxDNA 物理有效性验证。
4. **可复现材料已沉淀：** 报告、清单、哈希、输入/输出、指标和远端包均在对应目录；可以按下表直接定位 PPT 截图、数据图和复核文件。

## 证据阅读顺序

建议每个主题优先查看中文 `REPORT_ZH.md` / `COMPARISON_ZH.md`，然后查看同目录的 `verification.json`、`comparison.json`、`manifest.json` 或独立复算文件，最后引用日志、CSV/NPZ、图表和 checkpoint 元信息。checkpoint 本身是数值证据，不应在 PPT 中单独当成质量证据。

## 完整任务登记与证据索引

以下按任务创建/记录日期排列；日期源于原任务ID，不保证是实验实际完成日。逐日事件保留原日志标题/行号供复核。以下登记从本项目 `feature_list.json` 中筛出含 2026-11-01 至 2026-11-07 日期标记的条目，共 64 项；证据字段沿用任务记录中的路径/远端引用。状态是记录状态，若正文注明了更晚的核对结果，以核对结果为准。



### 2026-11-01

**W01 · 048 三副本 100M 轨迹分段稳定性审计** — 已完成分析

完整流式检查三条各10,000帧轨迹；相邻块均值距离0.428–1.303 nm，副本整体均值相差1.110–2.163 nm。未获得结构均值稳定证据；包装脚本FAILED来自末尾断言，MD本体返回0。

任务ID：audit-talos048-dt005-20261101；原登记状态：done。

证据入口：[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/REPORT_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/verification.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/plot_summary.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/plot_summary.py>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_segment_summary.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_segment_summary.csv>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.pdf](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.pdf>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.png](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.png>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.svg](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.svg>)。全部关联文件见证据总表的 W01。

**W02 · 048 逐核苷酸 RMSF 跨副本复现性** — 已完成分析

8,818节点全轨迹Spearman 0.917–0.944、Top10%交集70.6–80.0%；相对移动节点排序较可复现，不能替代平衡态或绝对幅值收敛证明。

任务ID：audit-talos048-rmsf-repro-20261101；原登记状态：done。

证据入口：[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/REPORT_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/CHECKPOINT_PREFIX_REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/CHECKPOINT_PREFIX_REPORT_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/SHORT_5E6_COMPARISON_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/SHORT_5E6_COMPARISON_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/verification.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/checkpoint_prefix_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/checkpoint_prefix_summary.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_comparison_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_comparison_summary.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_verification.json>)。全部关联文件见证据总表的 W02。

**W03 · 048 的 5M/100M RMSF 对比** — 已完成分析

副本间平均Spearman由5M的0.708到100M的0.927；同时存在dt=.001/.005变化，不能把差别全归于轨迹长度。

任务ID：rmsf-5m-vs-100m-20261101；原登记状态：done。

证据入口：[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/SHORT_5E6_COMPARISON_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/SHORT_5E6_COMPARISON_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/CHECKPOINT_PREFIX_REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/CHECKPOINT_PREFIX_REPORT_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/REPORT_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_verification.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/checkpoint_prefix_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/checkpoint_prefix_summary.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_comparison_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_comparison_summary.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_vs_long_profile_comparison.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_vs_long_profile_comparison.csv>)。全部关联文件见证据总表的 W03。

**W04 · 048 同 dt 的 10/20/50/75/100M 前缀扫描** — 已完成分析

平均跨副本rho分别约.815/.896/.889/.920/.927；75M首次使本次三对均>.90，存在非单调性；沿用既有轨迹，未重复提交MD。

任务ID：rmsf-prefix-length-20261101；原登记状态：done。

证据入口：[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/CHECKPOINT_PREFIX_REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/CHECKPOINT_PREFIX_REPORT_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/REPORT_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/SHORT_5E6_COMPARISON_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/SHORT_5E6_COMPARISON_ZH.md>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/checkpoint_prefix_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/checkpoint_prefix_summary.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_comparison_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_comparison_summary.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_5e6_verification.json>)；[outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_vs_long_profile_comparison.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/rmsf_reproducibility/short_vs_long_profile_comparison.csv>)。全部关联文件见证据总表的 W04。

**W05 · 97 设计追加 20M 并改为八 GPU 分片** — 部分完成

原逐设计array/feeder撤销，修复shard映射后八个串行worker运行；90/97达到25M，034/046/050/052/054/066/087 NaN失败。Slurm六个FAILED不等于六个设计失败；每设计账本为准。

任务ID：talos97-dt005-20m-all-20261101；原登记状态：in_progress。

证据入口：[outputs/talos97_dt005_continue_20m_20261101_8shards/README.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/README.md>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/task_table.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/task_table.csv>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/campaign.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/campaign.json>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/submission.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/submission.json>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/preflight.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/preflight.json>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/refresh_task_table.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/refresh_task_table.py>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/run_one_sample.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/run_one_sample.py>)。全部关联文件见证据总表的 W05。


### 2026-11-02

**W06 · 20M 标签重算与继承式三种子训练** — 已完成实验

90设计2000帧标签QC、72/18新划分和97设计预测完成；使用历史预训练/36项筛选特征，旧训练与新验证交叉，不能报告为严格独立泛化。

任务ID：talos97-20m-rmsf-prediction-20261102；原登记状态：done。

证据入口：[docs/harness/rmsf_20m_weighted_ablation_2026-11-02.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/docs/harness/rmsf_20m_weighted_ablation_2026-11-02.md>)；[experiments/talos97_rmsf_scalar/continuation20m_20261102/REPORT.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/continuation20m_20261102/REPORT.md>)；[experiments/talos97_rmsf_scalar/continuation20m_20261102/label_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/continuation20m_20261102/label_verification.json>)；[experiments/talos97_rmsf_scalar/continuation20m_20261102/pipeline_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/continuation20m_20261102/pipeline_status.json>)；[experiments/talos97_rmsf_scalar/continuation20m_20261102/ranking_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/continuation20m_20261102/ranking_summary.json>)；[experiments/talos97_rmsf_scalar/continuation20m_20261102/summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/continuation20m_20261102/summary.json>)；[experiments/talos97_rmsf_scalar/continuation20m_20261102/per_design_metrics.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/continuation20m_20261102/per_design_metrics.csv>)。全部关联文件见证据总表的 W06。

**W07 · 随机初始化普通/高 RMSF 加权 MSE 三种子对照** — 已完成实验

3种子各200轮，训练归一化仅用72设计；普通/加权集成验证RMSE1.714939/1.717325 nm，未见稳定加权收益。普通相对训练均值基线MAE降低29.79%。009极值仍纳入18设计主指标。

任务ID：strict-weighted-rmsf-20261102；原登记状态：done。

证据入口：[docs/harness/rmsf_20m_weighted_ablation_2026-11-02.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/docs/harness/rmsf_20m_weighted_ablation_2026-11-02.md>)。全部关联文件见证据总表的 W07。

**W08 · 螺旋 ID 重编号不变性验证** — 已完成验证

3设计×3随机一致双射，重建全部特征和rod图，9/9通过；最大预测变化4.768e-7 nm。验证的是分组ID重命名，不是任意拓扑变化。

任务ID：helix-relabel-invariance-20261102；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/helix_relabel_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/helix_relabel_verification.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/constant_baseline_comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/constant_baseline_comparison.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/pipeline_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/pipeline_status.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/rigid_transform_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/rigid_transform_verification.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/compare_constant.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/compare_constant.py>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/exclude_009_sensitivity.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/exclude_009_sensitivity.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/launch.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/launch.py>)。全部关联文件见证据总表的 W08。

**W09 · 空间边、helix 消息、配对边八组消融** — 已完成实验

用户将旧方案改为seed11/max120/patience25；3消融×2损失加2完整对照均完成。普通MSE移除空间边rho降.0336；消融仍保留坐标/两跳等信息，只能解释显式边的增量贡献。

任务ID：edge-ablation20m-20261102；原登记状态：done。

证据入口：[docs/harness/rmsf_20m_weighted_ablation_2026-11-02.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/docs/harness/rmsf_20m_weighted_ablation_2026-11-02.md>)；[experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/comparison.json>)；[experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/full.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/full.log>)；[experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/no_basepair.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/no_basepair.log>)；[experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/no_helix_messages.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/no_helix_messages.log>)；[experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/no_spatial.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120/no_spatial.log>)；[experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120>)。全部关联文件见证据总表的 W09。

**W10 · RMSF 标量刚体旋转/平移不变性** — 已完成验证

3设计×3种子×3变换共27/27通过，最大变化7.153e-7 nm；位置与局部取向一致变换并重算特征。不等于向量输出等变或镜像不变认证。

任务ID：rigid-invariance-20261102；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/rigid_transform_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/rigid_transform_verification.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/constant_baseline_comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/constant_baseline_comparison.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/helix_relabel_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/helix_relabel_verification.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/pipeline_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/pipeline_status.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/compare_constant.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/compare_constant.py>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/exclude_009_sensitivity.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/exclude_009_sensitivity.json>)；[experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/launch.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/strict_weighted20m_20261102/launch.py>)。全部关联文件见证据总表的 W10。

**W11 · 输入几何模态顺应性特征配对实验** — 已完成实验

固定16bp刚体块，等容量zero-modal对照；18验证RMSE1.723746→1.713473 nm，17ex009为.344487→.333340。单种子配对bootstrap跨零；特征是启发式机械描述，非校准oxDNA Hessian。

任务ID：modal-compliance-rmsf-20261102；原登记状态：done。

证据入口：[docs/harness/rmsf_modal_compliance_2026-11-02.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/docs/harness/rmsf_modal_compliance_2026-11-02.md>)；[experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/README.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/README.md>)；[experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/comparison.json>)；[experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/cache_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/cache_manifest.json>)；[experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/modal_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/modal_verification.json>)；[experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/pairing_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/modal_compliance20m_20261102/pairing_verification.json>)。全部关联文件见证据总表的 W11。

**W12 · 016/070 高 RMSF 连续区的 28 层表示诊断** — 已完成分析

冻结modal/control，按完整helix分组交叉验证；高低值可分但幅值仍低估，无普遍层后表示塌缩证据。两设计均为训练成员；修正读出索引后的results.json为最终版本。

任务ID：rmsf-region-representation-016070-20261102；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/region_representation_016070_20261102/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/region_representation_016070_20261102/FIGURE_QA.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/FIGURE_QA.md>)；[experiments/talos97_rmsf_scalar/region_representation_016070_20261102/REPORT.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/REPORT.md>)；[experiments/talos97_rmsf_scalar/region_representation_016070_20261102/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/verification.json>)；[experiments/talos97_rmsf_scalar/region_representation_016070_20261102/region_summary.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/region_summary.csv>)；[experiments/talos97_rmsf_scalar/region_representation_016070_20261102/results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/results.json>)；[experiments/talos97_rmsf_scalar/region_representation_016070_20261102/layer_diagnosis.pdf](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/layer_diagnosis.pdf>)。全部关联文件见证据总表的 W12。

**W13 · 冻结末层表示的 Ridge/MLP 读出** — 已完成实验

排除016/070，70设计拟合，56/14内层选择；Ridge和三种子MLP没有稳定恢复高值幅度。单个MLP seed对070改善未复现；不是不存在数值信息的证明。

任务ID：rmsf-frozen-readout-20261102；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/frozen_readout_20261102/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/frozen_readout_20261102/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/frozen_readout_20261102/results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/frozen_readout_20261102/results.json>)；[experiments/talos97_rmsf_scalar/frozen_readout_20261102/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/frozen_readout_20261102/verification.json>)；[experiments/talos97_rmsf_scalar/frozen_readout_20261102/metrics.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/frozen_readout_20261102/metrics.csv>)；[experiments/talos97_rmsf_scalar/frozen_readout_20261102/region_metrics.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/frozen_readout_20261102/region_metrics.csv>)；[experiments/talos97_rmsf_scalar/frozen_readout_20261102/codegraph_sync.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/frozen_readout_20261102/codegraph_sync.log>)；[experiments/talos97_rmsf_scalar/frozen_readout_20261102/init.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/frozen_readout_20261102/init.log>)。全部关联文件见证据总表的 W13。

**W14 · 层间幅值探针与 LayerNorm 统计旁路** — 已完成实验

6冻结阶段、Ridge/三MLP、20评估设计；真实mean/logstd旁路不稳定优于等维打乱对照，未支持LN为幅值丢失主因。已做权重/指标/分位数独立重建。

任务ID：rmsf-layer-amplitude-20261102；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/layer_amplitude_20261102/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/layer_amplitude_20261102/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/layer_amplitude_20261102/paired_comparisons.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/layer_amplitude_20261102/paired_comparisons.json>)；[experiments/talos97_rmsf_scalar/layer_amplitude_20261102/quantile_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/layer_amplitude_20261102/quantile_verification.json>)；[experiments/talos97_rmsf_scalar/layer_amplitude_20261102/results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/layer_amplitude_20261102/results.json>)；[experiments/talos97_rmsf_scalar/layer_amplitude_20261102/summary.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/layer_amplitude_20261102/summary.csv>)；[experiments/talos97_rmsf_scalar/layer_amplitude_20261102/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/layer_amplitude_20261102/verification.json>)；[experiments/talos97_rmsf_scalar/layer_amplitude_20261102/metrics.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/layer_amplitude_20261102/metrics.csv>)。全部关联文件见证据总表的 W14。

**W15 · 普通 RMSF、平方损失和直接 nm² 目标三臂** — 已完成计算/本次补核

pipeline于11/2 21:19完成，三臂exit0。18验证RMSE1.708989/1.703220/1.711077 nm；17ex009为.328581/.323569/.331486。单seed不同损失单位，不能仅凭小差异宣称稳定增益；本次复算设计级宏平均。

任务ID：rmsf-square-target-20261102；原登记状态：in_progress。

证据入口：[experiments/talos97_rmsf_scalar/squared_target20m_20261102/comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/squared_target20m_20261102/comparison.json>)；[experiments/talos97_rmsf_scalar/squared_target20m_20261102/pipeline_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/squared_target20m_20261102/pipeline_status.json>)；[experiments/talos97_rmsf_scalar/squared_target20m_20261102/rmsf_mse/evaluation.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/squared_target20m_20261102/rmsf_mse/evaluation.json>)；[experiments/talos97_rmsf_scalar/squared_target20m_20261102/rmsf_mse/manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/squared_target20m_20261102/rmsf_mse/manifest.json>)；[experiments/talos97_rmsf_scalar/squared_target20m_20261102/rmsf_mse/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/squared_target20m_20261102/rmsf_mse/status.json>)；[experiments/talos97_rmsf_scalar/squared_target20m_20261102/squared_loss/evaluation.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/squared_target20m_20261102/squared_loss/evaluation.json>)；[experiments/talos97_rmsf_scalar/squared_target20m_20261102/squared_loss/manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/squared_target20m_20261102/squared_loss/manifest.json>)。全部关联文件见证据总表的 W15。

**W16 · 070 的 315nt 高波动片段刚体/内部运动分解** — 已完成分析

对2000帧分析，整体315nt刚体拟合Q=.94958、七helix分域Q=.98887；主要为连贯运动，非各helix独立摆动占主导。Q为描述性MSD分解，不是能量占比。

任务ID：rmsf-motion070-20261102；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/motion070_20261102/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/motion070_20261102/RIGID_RECONSTRUCTION_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/RIGID_RECONSTRUCTION_ZH.md>)；[experiments/talos97_rmsf_scalar/motion070_20261102/results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/results.json>)；[experiments/talos97_rmsf_scalar/motion070_20261102/rigid_reconstruction_results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/rigid_reconstruction_results.json>)；[experiments/talos97_rmsf_scalar/motion070_20261102/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/verification.json>)；[experiments/talos97_rmsf_scalar/motion070_20261102/rigid_reconstruction_nodes.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/rigid_reconstruction_nodes.csv>)；[experiments/talos97_rmsf_scalar/motion070_20261102/analyze.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/analyze.py>)。全部关联文件见证据总表的 W16。

**W17 · 070 的固定几何纯刚体轨迹重建** — 已完成分析

固定参考经R/T重建2000帧；均值RMSF4.394282对真实4.572458 nm（96.10%），节点Pearson.94261。保留交叉项，不能当作独立能量分解或跨设计因果结论。

任务ID：rmsf-rigid-reconstruction070-20261102；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/motion070_20261102/RIGID_RECONSTRUCTION_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/RIGID_RECONSTRUCTION_ZH.md>)；[experiments/talos97_rmsf_scalar/motion070_20261102/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/motion070_20261102/results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/results.json>)；[experiments/talos97_rmsf_scalar/motion070_20261102/rigid_reconstruction_results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/rigid_reconstruction_results.json>)；[experiments/talos97_rmsf_scalar/motion070_20261102/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/verification.json>)；[experiments/talos97_rmsf_scalar/motion070_20261102/rigid_reconstruction_nodes.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/rigid_reconstruction_nodes.csv>)；[experiments/talos97_rmsf_scalar/motion070_20261102/analyze.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/motion070_20261102/analyze.py>)。全部关联文件见证据总表的 W17。

**W18 · 稀疏全局弹性模型阶段1与零模修复** — 暂停/阶段1未完成

90输入审计与016/070原型；中心力额外零模168/176，经有限平移转动连接后均仅6刚体零模。nick网格、物理参数与参考应变未通过；用户改走轨迹监督后暂停，未做阶段2/3。

任务ID：global-mechanics-stage123-20261102；原登记状态：paused。

证据入口：[experiments/talos97_rmsf_scalar/global_mechanics_20261102/PLAN_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/global_mechanics_20261102/PLAN_ZH.md>)；[experiments/talos97_rmsf_scalar/global_mechanics_20261102/STAGE1_P0_REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/global_mechanics_20261102/STAGE1_P0_REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/global_mechanics_20261102/UNITS_AND_PRIORS_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/global_mechanics_20261102/UNITS_AND_PRIORS_ZH.md>)；[experiments/talos97_rmsf_scalar/global_mechanics_20261102/connector_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/global_mechanics_20261102/connector_verification.json>)；[experiments/talos97_rmsf_scalar/global_mechanics_20261102/elastic_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/global_mechanics_20261102/elastic_verification.json>)；[experiments/talos97_rmsf_scalar/global_mechanics_20261102/6hb_016_K_prototype.npz](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/global_mechanics_20261102/6hb_016_K_prototype.npz>)；[experiments/talos97_rmsf_scalar/global_mechanics_20261102/6hb_016_finite_null_modes.npz](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/global_mechanics_20261102/6hb_016_finite_null_modes.npz>)。全部关联文件见证据总表的 W18。

**W19 · 轨迹标量相关辅助监督三臂** — 已完成计算/本次补核

015全轨迹骨架异常使准备门槛失败，记录原因后按用户指示排除015；71train/18val三臂11/3 00:19完成。no/true/shuffle的17ex009 RMSE .317519/.320506/.318744 nm；真辅助未改善。输出是标量相关，非完整3×3张量。

任务ID：rmsf-covariance-aux-20261102；原登记状态：in_progress。

证据入口：[experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/README_ZH.md>)；[experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/diagnostics/015_REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/diagnostics/015_REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/comparison.json>)；[experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/label_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/label_verification.json>)；[experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/pipeline_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/pipeline_status.json>)；[experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/diagnostics/check015_results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/diagnostics/check015_results.json>)；[experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/no_aux/evaluation.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/no_aux/evaluation.json>)。全部关联文件见证据总表的 W19。


### 2026-11-03

**W20 · 绝对协方差幅值辅助监督三臂** — 已完成计算

三臂exit0；no/true/shuffle的18验证RMSE1.707646/1.702540/1.703846 nm；真监督略降总体RMSE却增Top20 MAE，未优于shuffle。原报告未做完整保存forward独立重放，本次只核文件与宏平均。

任务ID：rmsf-covariance-amplitude-20261103；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/comparison.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/pipeline_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/pipeline_status.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/no_aux/evaluation.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/no_aux/evaluation.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/no_aux/manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/no_aux/manifest.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/no_aux/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/no_aux/status.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/true_cov/evaluation.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/true_cov/evaluation.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/true_cov/manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/true_cov/manifest.json>)。全部关联文件见证据总表的 W20。

**W21 · 协方差单臂 10,000 轮 A100 长跑** — 已完成计算/本次补核

Slurm21255于11/3 20:21 COMPLETED；status=complete/stopped10000，best epoch121。最佳验证18 RMSE1.703230 nm、17ex009 .323307。无相同长预算noaux/shuffle对照；不能归因为协方差本身收益。

任务ID：rmsf-covariance-10k-20261103；原登记状态：in_progress。

证据入口：[experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/true_cov/evaluation.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/true_cov/evaluation.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/true_cov/manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/true_cov/manifest.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/true_cov/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/true_cov/status.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/codegraph_sync.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/codegraph_sync.log>)；[experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/protocol.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/protocol.json>)；[experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/run.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/run.py>)；[experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/slurm-21255.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/slurm-21255.log>)。全部关联文件见证据总表的 W21。

**W22 · 高值区分能力与幅值校准证据汇总** — 已完成文档

聚合层AUROC、Top20召回、冻结读出、070运动、协方差及015污染，给出gate×delta与配对对照假设；gate新实验尚未运行。

任务ID：rmsf-amplitude-calibration-synthesis-20261103；原登记状态：done。

证据入口：[docs/harness/rmsf_discrimination_vs_amplitude_calibration_20261103.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/docs/harness/rmsf_discrimination_vs_amplitude_calibration_20261103.md>)。全部关联文件见证据总表的 W22。

**W23 · RMSF 正残差形状的只读 oracle 拟合** — 已完成分析

标签选中心，拓扑/空间Gaussian验证内拟合R²约.387/.403；残差backbone相关.935。使用真实残差选中心，属于样本内描述，不能作为可部署预测提升；排除twohop后的results为最终版。

任务ID：rmsf-residual-shape-20261103；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/residual_shape_20261103/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/residual_shape_20261103/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/residual_shape_20261103/results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/residual_shape_20261103/results.json>)；[experiments/talos97_rmsf_scalar/residual_shape_20261103/analyze.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/residual_shape_20261103/analyze.py>)；[experiments/talos97_rmsf_scalar/residual_shape_20261103/run.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/residual_shape_20261103/run.log>)；[experiments/talos97_rmsf_scalar/residual_shape_20261103/run_verified.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/residual_shape_20261103/run_verified.log>)；[experiments/talos97_rmsf_scalar/residual_shape_20261103](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/residual_shape_20261103>)。全部关联文件见证据总表的 W23。

**W24 · 有符号源场扩散五臂配对消融** — 已完成实验

初次启动接口失败后保留日志重试；local/backbone/topology/spatial及随机中心五臂完成。Backbone的18验证Top20 MAE由local .6345降至.5710 nm，配对bootstrap区间不跨零；总体RMSE差区间跨零。单种子历史开发验证，不证明稳定整体泛化提升。与fungus-diffusion条目是同一实验的双重登记。

任务ID：rmsf-fungus-diffusion-20261103；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/README_ZH.md>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/mean_baseline_comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/mean_baseline_comparison.json>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/github_upload_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/github_upload_manifest.json>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/summary.json>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/retry_1/local/evaluation.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/retry_1/local/evaluation.json>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/retry_1/local/manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/retry_1/local/manifest.json>)。全部关联文件见证据总表的 W24。

**W25 · 有符号源场扩散与均值基线复核（重复登记）** — 重复登记/已完成

与rmsf-fungus-diffusion指向同一目录，不计作两套独立实验。保留任务ID以完整覆盖原表；summary、mean_baseline_comparison和retry_1为证据。

任务ID：fungus-diffusion-20261103；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/README_ZH.md>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/summary.json>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/mean_baseline_comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/mean_baseline_comparison.json>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/github_upload_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/github_upload_manifest.json>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/compare_mean_baseline.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/compare_mean_baseline.py>)；[experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/protocol.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/protocol.json>)。全部关联文件见证据总表的 W25。

**W26 · 非零 RMSE、009 污染和五条异常轨迹诊断** — 已完成诊断/问题未闭环

009四点贡献设计SSE99.9709%，RMSF约799–1256 nm；009/015/024/047/051续跑均有巨大能量异常。正常设计约.32 nm误差的采样噪声/建模成分未分解，未确定不可约误差下限。

任务ID：rmsf-rmse-floor-diagnosis-20261103；原登记状态：in_progress。

证据入口：[experiments/talos97_rmsf_scalar/rmse_floor_diagnosis_20261103/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/rmse_floor_diagnosis_20261103/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/rmse_floor_diagnosis_20261103](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/rmse_floor_diagnosis_20261103>)。全部关联文件见证据总表的 W26。

**W27 · TALOS97 原始输入结构质量审计** — 已完成审计

97设计共2964长backbone边，009/015不构成独特几何离群；缓存坐标/边与源一致。后续拓扑独立核验更正了可能错接推断，长几何边不应直接等同连接错误。

任务ID：talos97-source-structure-audit-20261103；原登记状态：done。

证据入口：[docs/harness/talos97_source_structure_audit_2026-11-03.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/docs/harness/talos97_source_structure_audit_2026-11-03.md>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/RECONSTRUCTION_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/RECONSTRUCTION_ZH.md>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstructed_bridge_coordinates.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstructed_bridge_coordinates.csv>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/audit.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/audit.py>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/input_source_audit.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/input_source_audit.json>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstruct_unpaired_bridges.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstruct_unpaired_bridges.py>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstruction_feasibility.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstruction_feasibility.json>)。全部关联文件见证据总表的 W27。

**W28 · 未配对核苷酸坐标重建可行性** — 已完成审计/结论有更正

产出重建可行性和桥接坐标CSV；早期报告基于训练子目录说原始文件缺失，后续源ZIP查证已更正。重建候选不等于恢复原转换状态或物理有效坐标。

任务ID：talos97-unpaired-coordinate-reconstruction-20261103；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/input_source_audit_20261103/RECONSTRUCTION_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/RECONSTRUCTION_ZH.md>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstructed_bridge_coordinates.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstructed_bridge_coordinates.csv>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstruct_unpaired_bridges.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstruct_unpaired_bridges.py>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstruction_feasibility.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/reconstruction_feasibility.json>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/audit.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/audit.py>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103/input_source_audit.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103/input_source_audit.json>)；[experiments/talos97_rmsf_scalar/input_source_audit_20261103](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/input_source_audit_20261103>)。全部关联文件见证据总表的 W28。

**W29 · 300 设计家族格式/来源与 oxDNA 准备度** — 已完成审计

300家族=162公开+138算法生成；146CNDO/125caDNAno/15dna/10top/3oxview/1ens。只做格式检查，均不能直接视为有RMSF标签的300训练样本；10top缺配置，转换后还需物理QC。

任务ID：dnaorigami-dataset300-oxdna-readiness-20261103；原登记状态：done。

证据入口：[docs/harness/dnaorigami_dataset300_oxdna_audit_2026-11-03.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/docs/harness/dnaorigami_dataset300_oxdna_audit_2026-11-03.md>)。全部关联文件见证据总表的 W29。

**W30 · TALOS97 源 CNDO/caDNAno/oxDNA 拓扑独立核验** — 已完成审计

97/97源链边、配对、碱基与缓存映射一致；总834348节点/824300骨架边/406800配对。澄清源设计存在及长边不等于错接；拓扑一致不认证坐标/取向/MD有效性。

任务ID：talos97-topology-verification-20261103；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/topology_verification_20261103/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/topology_verification_20261103/REPORT_ZH.md>)；[experiments/talos97_rmsf_scalar/topology_verification_20261103/results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/topology_verification_20261103/results.json>)；[experiments/talos97_rmsf_scalar/topology_verification_20261103/uniqueness.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/topology_verification_20261103/uniqueness.py>)；[experiments/talos97_rmsf_scalar/topology_verification_20261103/verify.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/topology_verification_20261103/verify.py>)；[experiments/talos97_rmsf_scalar/topology_verification_20261103](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/topology_verification_20261103>)。全部关联文件见证据总表的 W30。

**W31 · TALOS97 原始设计与问题审计单包发布** — 已完成发布

按用户更正移除先前四个单独远端文件，合成一个源ZIP+中文问题报告+逐设计hash包。历史commit64156199…；本次保留发布回执，未再次推送或联网重检远端。

任务ID：talos97-source-upload-20261103；原登记状态：done。

证据入口：[../fmdata/dataset_300/._README.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/../fmdata/dataset_300/._README.md>)；[../fmdata/dataset_300/._dna_origami_300_families_basis.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/../fmdata/dataset_300/._dna_origami_300_families_basis.md>)；[../fmdata/dataset_300/._dna_origami_300_family_split_basis.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/../fmdata/dataset_300/._dna_origami_300_family_split_basis.md>)；[../fmdata/dataset_300/README.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/../fmdata/dataset_300/README.md>)；[../fmdata/dataset_300/dna_origami_300_families_basis.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/../fmdata/dataset_300/dna_origami_300_families_basis.md>)；[../fmdata/dataset_300/dna_origami_300_family_split_basis.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/../fmdata/dataset_300/dna_origami_300_family_split_basis.md>)；[TALOS97_SOURCE_AUDIT_20261103.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/TALOS97_SOURCE_AUDIT_20261103.md>)。全部关联文件见证据总表的 W31。

**W32 · fungus 可复现训练闭环包 GitHub 发布** — 已完成发布

408文件发布到私有talos97；89设计/445指标/5checkpoint/最大反传闭环，远端407项SHA核验记录通过，commit25a82a7…。本次核对回执，不重训或推送。

任务ID：fungus-github-upload-20261103；原登记状态：done。

证据入口：[outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_DOWNLOAD.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_DOWNLOAD.md>)；[outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_README.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_README.md>)；[outputs/talos97_github_staging/remote_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/remote_verification.json>)；[outputs/talos97_github_staging/paper_remote_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/paper_remote_verification.json>)；[outputs/talos97_github_staging/build_bundle.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/build_bundle.py>)；[outputs/talos97_github_staging/talos97_labels_and_inputs_20261105.zip](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/talos97_labels_and_inputs_20261105.zip>)；[outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_PACKAGE.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_PACKAGE.json>)。全部关联文件见证据总表的 W32。

**W33 · 层级 log-normal RMSF V2A/V2B** — 已完成实验及发布

六方案训练内三折CV+refit，L4被训练CV选中；历史验证RMSE.358450 nm，没有超越历史最佳证据。保存预测/分布重建与刚体不变性通过，commit687bf81…；单seed历史开发集。

任务ID：talos97-v2-20261103；原登记状态：done。

证据入口：[outputs/talos97_github_staging/repository/results/v2/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/v2/REPORT_ZH.md>)；[outputs/talos97_github_staging/repository/results/v2/pipeline_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/v2/pipeline_status.json>)；[outputs/talos97_github_staging/repository/results/v2/summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/v2/summary.json>)；[outputs/talos97_github_staging/repository/results/v2/trained_rigid_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/v2/trained_rigid_verification.json>)；[outputs/talos97_github_staging/repository/results/v2/L0.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/v2/L0.log>)；[outputs/talos97_github_staging/repository/results/v2/L1.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/v2/L1.log>)；[outputs/talos97_github_staging/repository/results/v2/L2.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/v2/L2.log>)。全部关联文件见证据总表的 W33。

**W34 · 原始纯 Macro RMSE 120 轮 Slurm 运行** — 被后续方案取代

Slurm21589约epoch50按用户要求取消，旧产物保留；包含009的旧验证协议被clean三种子新目录替代，不能将中止结果混入最终比较。

任务ID：direct-macro-rmse-120-20261103；原登记状态：superseded。

证据入口：[experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103/protocol.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103/protocol.json>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103/run.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103/run.py>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103/slurm-21589.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103/slurm-21589.log>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103/train.sbatch](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103/train.sbatch>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_20261103>)。全部关联文件见证据总表的 W34。

**W35 · 排除009/015的纯 Macro RMSE 三种子训练** — 已完成实验

三seed固定120轮exit0，17验证最佳RMSE.318542/.317465/.329969 nm。无相同三seed普通MSE对照，不能归因为只改目标的收益；旧键validation18实际17项。

任务ID：direct-macro-rmse-clean3seed-20261103；原登记状态：done。

证据入口：[experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/controller.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/controller.log>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/exit_codes.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/exit_codes.json>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/launch.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/launch.json>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/launch.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/launch.py>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/seed11/protocol.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/seed11/protocol.json>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/seed11/run.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/seed11/run.log>)；[experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/seed11/run.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/seed11/run.py>)。全部关联文件见证据总表的 W35。

**W36 · Flat42 39 构型、12 GPU 分片 25M 模拟** — 部分完成

多次按用户指令取消/重排后最终21816–21827，9组3项+3组4项；20完成25M、19普通FENE准备失败。全12worker FAILED为聚合失败，不能说全39模拟失败。SIGILL探针/旧尝试均保留。

任务ID：talos40-flat42-25m-20261103；原登记状态：in_progress。

证据入口：[outputs/talos40_flat42_25m_20261103/COMPLETION_STATUS_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/COMPLETION_STATUS_ZH.md>)；[outputs/talos40_flat42_25m_20261103/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/README_ZH.md>)；[outputs/talos40_flat42_25m_20261103/shard_0.status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/shard_0.status.json>)；[outputs/talos40_flat42_25m_20261103/shard_1.status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/shard_1.status.json>)；[outputs/talos40_flat42_25m_20261103/shard_10.status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/shard_10.status.json>)；[outputs/talos40_flat42_25m_20261103/shard_11.status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/shard_11.status.json>)；[outputs/talos40_flat42_25m_20261103/shard_2.status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/shard_2.status.json>)。全部关联文件见证据总表的 W36。

**W37 · 图自相关及独立嵌入多尺度扩散 V1** — 已完成实现及发布

实现D1/D2/D3/D5、原97/续跑89自相关；四方案最大9942节点梯度门槛、D3一轮CPU闭环与88指标复算通过。该阶段仅smoke不证明120轮收益；旧fungus/V2保留，commit4ae7103…。

任务ID：talos97-graph-diffusion-v1-20261103；原登记状态：done。

证据入口：[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/LITERATURE_AND_TRAINING.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/LITERATURE_AND_TRAINING.md>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/REPORT_ZH.md>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_verification.json>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_verification_cpu.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_verification_cpu.json>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/verification.json>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/verification_final.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/verification_final.log>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/autocorrelation_continuation89.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/autocorrelation_continuation89.json>)。全部关联文件见证据总表的 W37。

**W38 · APPNP/GDC/MixHop/GPR 文献核对与 18 组训练** — 已完成实验及发布

6方案×3seed×120轮完成，71/17协议；GPR验证.330928±.000103，D0 .331873，历史fungus .321992±.006929 nm。新模型无优越证据；18×88指标与远端1423清单核验，commite92e90c…。

任务ID：talos97-literature-graph-training-20261103；原登记状态：done。

证据入口：[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/COMPARISON_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/COMPARISON_ZH.md>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/SUMMARY.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/SUMMARY.md>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/fungus_comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/fungus_comparison.json>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/status.json>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/summary.json>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/audit_stdout.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/audit_stdout.json>)；[outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/campaign.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/repository/results/graph_diffusion_v1/paper_matched_3seed_120ep/campaign.json>)。全部关联文件见证据总表的 W38。

**W39 · 新图扩散与旧 fungus 近似性能的机制诊断** — 已完成分析

旧fungus也传播源场；21checkpoint/1848指标复算、逐设计配对和冻结P→I干预。新GPR与D0预测相关.995；新旧并非同一预测，难例误差高度相关。无重训，CPU旧模型复现误差限制保留。

任务ID：talos97-diffusion-fungus-diagnosis-20261103；原登记状态：done。

证据入口：[outputs/talos97_diffusion_diagnosis/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_diffusion_diagnosis/REPORT_ZH.md>)；[outputs/talos97_diffusion_diagnosis/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_diffusion_diagnosis/verification.json>)；[outputs/talos97_diffusion_diagnosis/ablate_new.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_diffusion_diagnosis/ablate_new.py>)；[outputs/talos97_diffusion_diagnosis/analyze.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_diffusion_diagnosis/analyze.py>)；[outputs/talos97_diffusion_diagnosis/decompose_old.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_diffusion_diagnosis/decompose_old.py>)；[outputs/talos97_diffusion_diagnosis/diagnosis.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_diffusion_diagnosis/diagnosis.json>)；[outputs/talos97_diffusion_diagnosis/new_interventions.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_diffusion_diagnosis/new_interventions.json>)。全部关联文件见证据总表的 W39。


### 2026-11-04

**W40 · 20 个 Flat42 新标签与旧 6HB 分布比较** — 已完成分析

全20完成设计取最后20M/2000帧，旧001重算误差2.22e-15 nm；设计等权均值新1.473/旧88为1.751 nm，中位数归一CDF KS .083。仅成功子集、单副本，15_truncated_tetrahedron窗口排序不稳。

任务ID：flat42-rmsf-distribution-comparison-20261104；原登记状态：done。

证据入口：[outputs/talos40_flat42_25m_20261103/rmsf_analysis/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/REPORT_ZH.md>)；[outputs/talos40_flat42_25m_20261103/rmsf_analysis/FIGURE_QA.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/FIGURE_QA.md>)；[outputs/talos40_flat42_25m_20261103/rmsf_analysis/comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/comparison.json>)；[outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.png](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.png>)；[outputs/talos40_flat42_25m_20261103/rmsf_analysis/analysis_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/analysis_manifest.json>)；[outputs/talos40_flat42_25m_20261103/rmsf_analysis/design_summary.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/design_summary.csv>)；[outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.pdf](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.pdf>)。全部关联文件见证据总表的 W40。

**W41 · 增加20新构型的 GPR 三种子训练** — 已完成实验

71→91训练，原17验证不变；三seed均值.330928→.328532 nm（约.72%），收益很小，仍差于历史fungus。全部新家族进入训练、更新数增多，modal阈值调整已披露，不是新家族留出测试。

任务ID：flat42-graph-augmentation-20261104；原登记状态：done。

证据入口：[experiments/flat42_graph_augmented_20261104/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/flat42_graph_augmented_20261104/REPORT_ZH.md>)；[experiments/flat42_graph_augmented_20261104/MEAN_BASELINES_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/flat42_graph_augmented_20261104/MEAN_BASELINES_ZH.md>)；[experiments/flat42_graph_augmented_20261104/comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/flat42_graph_augmented_20261104/comparison.json>)；[experiments/flat42_graph_augmented_20261104/pipeline_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/flat42_graph_augmented_20261104/pipeline_status.json>)；[experiments/flat42_graph_augmented_20261104/preparation_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/flat42_graph_augmented_20261104/preparation_status.json>)；[experiments/flat42_graph_augmented_20261104/results/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/flat42_graph_augmented_20261104/results/status.json>)；[experiments/flat42_graph_augmented_20261104/artifact_hashes.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/flat42_graph_augmented_20261104/artifact_hashes.json>)。全部关联文件见证据总表的 W41。

**W42 · 108 构型全节点 RMSF 图表与发布** — 已完成分析及发布

108设计/1058876节点全纳入，均值1.679503、中位1.605110 nm；PNG/PDF/SVG、全节点NPZ、源脚本与11文件清单发布commit8ec94e2…。节点等权，不能当成百万独立重复。

任务ID：rmsf-all108-node-distribution-20261104；原登记状态：done。

证据入口：[outputs/rmsf_all108_distribution_20261104/README.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/README.md>)；[outputs/rmsf_all108_distribution_20261104/remote_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/remote_verification.json>)；[outputs/rmsf_all108_distribution_20261104/design_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/design_manifest.json>)；[outputs/rmsf_all108_distribution_20261104/summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/summary.json>)；[outputs/rmsf_all108_distribution_20261104/histogram_source.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/histogram_source.csv>)；[outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.pdf](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.pdf>)；[outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.png](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.png>)。全部关联文件见证据总表的 W42。

**W43 · 95 目标中的参考结构位移 D 标签** — 88/95已完成

仅88有完整续跑；利用均值/方差恒等式计算D，001全2000帧直接核验误差5.507e-14 nm。7失败轨迹缺失，不能称95完成；旧GPU SVD错误/CPU修复记录保留。

任务ID：talos95-reference-displacement-20261104；原登记状态：in_progress。

证据入口：[outputs/talos95_reference_displacement_20261104/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos95_reference_displacement_20261104/README_ZH.md>)；[outputs/talos95_reference_displacement_20261104/design_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos95_reference_displacement_20261104/design_summary.json>)；[outputs/talos95_reference_displacement_20261104/direct_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos95_reference_displacement_20261104/direct_verification.json>)；[outputs/talos95_reference_displacement_20261104/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos95_reference_displacement_20261104/status.json>)；[outputs/talos95_reference_displacement_20261104/calculate.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos95_reference_displacement_20261104/calculate.py>)；[outputs/talos95_reference_displacement_20261104/codegraph_sync.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos95_reference_displacement_20261104/codegraph_sync.log>)；[outputs/talos95_reference_displacement_20261104/initial_gpu_svd_failure.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos95_reference_displacement_20261104/initial_gpu_svd_failure.json>)。全部关联文件见证据总表的 W43。

**W44 · 参考位移 D 的 GPR/fungus 单种子训练** — 已完成实验/本次补核

results/status=complete，两模型120轮结束，17验证D RMSE1.169702/1.146669 nm，176预测指标历史复算通过。D与RMSF为不同任务，绝对指标不能跨任务解释成提升。

任务ID：reference-displacement-models-20261104；原登记状态：in_progress。

证据入口：[experiments/reference_displacement_models_20261104/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/reference_displacement_models_20261104/REPORT_ZH.md>)；[experiments/reference_displacement_models_20261104/results/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/reference_displacement_models_20261104/results/status.json>)；[experiments/reference_displacement_models_20261104/results/summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/reference_displacement_models_20261104/results/summary.json>)；[experiments/reference_displacement_models_20261104/GPR_mean_baselines.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/reference_displacement_models_20261104/GPR_mean_baselines.json>)；[experiments/reference_displacement_models_20261104/codegraph_sync.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/reference_displacement_models_20261104/codegraph_sync.log>)；[experiments/reference_displacement_models_20261104/launch.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/reference_displacement_models_20261104/launch.json>)；[experiments/reference_displacement_models_20261104/run.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/reference_displacement_models_20261104/run.log>)。全部关联文件见证据总表的 W44。

**W45 · 严格85设计局部参考几何持久性 S 标签** — 已完成分析

85设计/731578节点；29CPU+56GPU float64完成，2000帧/哈希/公式检查通过；节点均值.876905、中位.923143。阈值delta=.2 nm为暂定，12排除项有账本。

任务ID：talos97-local-persistence-20261104；原登记状态：done。

证据入口：[outputs/talos97_local_persistence_20261104/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_local_persistence_20261104/README_ZH.md>)；[outputs/talos97_local_persistence_20261104/design_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_local_persistence_20261104/design_summary.json>)；[outputs/talos97_local_persistence_20261104/final_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_local_persistence_20261104/final_verification.json>)；[outputs/talos97_local_persistence_20261104/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_local_persistence_20261104/status.json>)；[outputs/talos97_local_persistence_20261104/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_local_persistence_20261104/verification.json>)；[outputs/talos97_local_persistence_20261104/calculate.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_local_persistence_20261104/calculate.py>)；[outputs/talos97_local_persistence_20261104/calculate_cpu_snapshot.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_local_persistence_20261104/calculate_cpu_snapshot.py>)。全部关联文件见证据总表的 W45。

**W46 · 方向位移均值/协方差与时间窗持久性标签** — 已完成分析

85设计/731578节点，时间窗1/10/50/100/200、全2000帧；均值/方差重放最大误差约1.2e-13/9.7e-13，PSD/有限性通过。间隔是模拟单位，不等同物理秒；时序置信与干预评估未做。

任务ID：directional-persistence-20261104；原登记状态：done。

证据入口：[outputs/talos97_directional_persistence_20261104/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_directional_persistence_20261104/README_ZH.md>)；[outputs/talos97_directional_persistence_20261104/design_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_directional_persistence_20261104/design_summary.json>)；[outputs/talos97_directional_persistence_20261104/final_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_directional_persistence_20261104/final_verification.json>)；[outputs/talos97_directional_persistence_20261104/pilot_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_directional_persistence_20261104/pilot_summary.json>)；[outputs/talos97_directional_persistence_20261104/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_directional_persistence_20261104/status.json>)；[outputs/talos97_directional_persistence_20261104/calculate.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_directional_persistence_20261104/calculate.py>)；[outputs/talos97_directional_persistence_20261104/launch.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_directional_persistence_20261104/launch.json>)。全部关联文件见证据总表的 W46。

**W47 · P50 标量目标 GPR/fungus 对照** — 已完成实验

两模型120轮，历史170预测指标复算；验证RMSE9.737324/9.706941，真实设计均值oracle9.731331。P50无量纲，兼容字段_nm是旧命名，不能写nm；设计内额外收益弱。

任务ID：directional-persistence-models-20261104；原登记状态：done。

证据入口：[experiments/directional_persistence_models_20261104/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_persistence_models_20261104/README_ZH.md>)；[experiments/directional_persistence_models_20261104/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_persistence_models_20261104/REPORT_ZH.md>)；[experiments/directional_persistence_models_20261104/label_provenance.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_persistence_models_20261104/label_provenance.json>)；[experiments/directional_persistence_models_20261104/launch.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_persistence_models_20261104/launch.json>)；[experiments/directional_persistence_models_20261104/run.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_persistence_models_20261104/run.log>)；[experiments/directional_persistence_models_20261104/run.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_persistence_models_20261104/run.py>)；[experiments/directional_persistence_models_20261104](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_persistence_models_20261104>)。全部关联文件见证据总表的 W47。

**W48 · 共享编码器方向/时序辅助多任务** — 已完成实验

匹配control/multitask120轮，验证P50 RMSE9.722436/9.735879（无改善），170保存指标复算通过。单seed历史开发验证，未评估真实加固收益。

任务ID：directional-multitask-20261104；原登记状态：done。

证据入口：[experiments/directional_multitask_20261104/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_multitask_20261104/README_ZH.md>)；[experiments/directional_multitask_20261104/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_multitask_20261104/REPORT_ZH.md>)；[experiments/directional_multitask_20261104/launch.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_multitask_20261104/launch.json>)；[experiments/directional_multitask_20261104/run.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_multitask_20261104/run.log>)；[experiments/directional_multitask_20261104/run.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_multitask_20261104/run.py>)；[experiments/directional_multitask_20261104](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/directional_multitask_20261104>)。全部关联文件见证据总表的 W48。

**W49 · W256 DNA-CGDM 实现、工程门槛与 D 训练** — 实现完成/训练未完成

固定upstream018ac033、64/64/64层级、BF16；85缓存、11测试、最大9996节点反传及诊断导出通过。可见记录停在epoch36/120、11/5，当前gpu03未见旧PID；不据此断言其他节点无作业，不报告生成质量达标。

任务ID：dna-cgdm-20261104；原登记状态：in_progress。

证据入口：[dna_cgdm/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/dna_cgdm/README_ZH.md>)；[outputs/dna_cgdm_20261104/training_start_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/training_start_verification.json>)；[outputs/dna_cgdm_20261104/campaign_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/campaign_status.json>)；[outputs/dna_cgdm_20261104/pretraining_resume_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/pretraining_resume_verification.json>)；[outputs/dna_cgdm_20261104/real_smoke/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/real_smoke/verification.json>)；[outputs/dna_cgdm_20261104/joint_D_seed11/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/joint_D_seed11/status.json>)；[outputs/dna_cgdm_20261104/B_cli_smoke.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/B_cli_smoke.log>)。全部关联文件见证据总表的 W49。


### 2026-11-05

**W50 · Mango250 随包 oxDNA 的初始化/FENE 审计** — 已完成审计/250初始化失败

临时拷贝修正1-based拓扑/box头后，v3.7 DNA2的250输入均在积分前失败；1227308骨架作用点距离.401529–.420449，低于允许[.5064,1.0064] oxDNA长度单位。源文件保留，无MD积分。

任务ID：mango250-oxdna-init-fene-20261105；原登记状态：done。

证据入口：[outputs/oxdna_mango250_init_fene_20261105/initialization_summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/oxdna_mango250_init_fene_20261105/initialization_summary.json>)；[outputs/oxdna_mango250_init_fene_20261105/batch_results.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/oxdna_mango250_init_fene_20261105/batch_results.json>)；[outputs/oxdna_mango250_init_fene_20261105/fene_audit.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/oxdna_mango250_init_fene_20261105/fene_audit.json>)；[outputs/oxdna_mango250_init_fene_20261105/run_all.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/oxdna_mango250_init_fene_20261105/run_all.py>)；[outputs/oxdna_mango250_init_fene_20261105](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/oxdna_mango250_init_fene_20261105>)。全部关联文件见证据总表的 W50。

**W51 · Mango250 几何库与 DX/2HB、6HB 双路 pilot** — 已完成短程pilot

250选中几何/270拓扑登记；TOP8/GEO11为6顶点8三角面12等边的正八面体（历史日志误称四面体）。无损binary→ASCII PLY后94bp两路成功，4632/15226nt，CPU min200/equil500/MD1000均exit0；使用力帽，非无帽长稳证据。

任务ID：mango250-geometry-library-dual-route-pilot-20261105；原登记状态：done。

证据入口：[outputs/mango250_geometry_library_20261105/MANGO250_DX2HB_6HB_PILOT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/MANGO250_DX2HB_6HB_PILOT_ZH.md>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/conversion_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/conversion_manifest.json>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/oxdna_short_simulation_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/oxdna_short_simulation_manifest.json>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/oxdna_smoke_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/oxdna_smoke_manifest.json>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/6HB/conversion_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/6HB/conversion_manifest.json>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/6HB/oxdna_short_simulation_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/6HB/oxdna_short_simulation_manifest.json>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/6HB/oxdna_smoke_manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/6HB/oxdna_smoke_manifest.json>)。全部关联文件见证据总表的 W51。

**W52 · Mango DX/2HB 的 A100 5M+20M 尝试** — 失败/0生产步

Slurm22682在8秒内FAILED，CUDA初始化骨架边27–28作用点距离19.602521；没有5M检查点或20M续跑。无帽协议不同于有帽CPU短试跑，未自动修结构或重跑。

任务ID：mango250-dx2hb-tal97-25m-20261105；原登记状态：in_progress。

证据入口：[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/manifest.json>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/status.txt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/status.txt>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/allocation.txt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/allocation.txt>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/nvidia-smi.txt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/nvidia-smi.txt>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/observed_sha256.txt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/observed_sha256.txt>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/run.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/run.log>)；[outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/run.sbatch](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/DX2HB/talos97_5m_plus_20m_20261105/run.sbatch>)。全部关联文件见证据总表的 W52。

**W53 · oxDNA v3.7 及 TALOS97 5M+20M 协议审计** — 已完成审计

核实程序/库hash：原97平衡/5M dt=.001，20M continuation dt=.005、diff_coeff2.5、300K/.5M盐、每1万步输出。Mango尝试两段均.005但未积分；不同阶段不能混称同一协议。

任务ID：oxdna-protocol-audit-20261105；原登记状态：done。

证据入口：[progress.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/progress.md>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/README.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/README.md>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/task_table.csv](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/task_table.csv>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/campaign.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/campaign.json>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/preflight.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/preflight.json>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/refresh_task_table.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/refresh_task_table.py>)；[outputs/talos97_dt005_continue_20m_20261101_8shards/run_one_sample.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_dt005_continue_20m_20261101_8shards/run_one_sample.py>)。全部关联文件见证据总表的 W53。

**W54 · TALOS97 代码/环境、最终标签与原始输入发布** — 已完成发布

当前代码树去模型权重commitf5dc7b4；681055762字节ZIP拆7段，加下载/包清单9blob发布commit13e2db2，原回执核验SHA。历史commit仍可能含权重，不能声称Git历史删除。

任务ID：github-publish-tal97-labels-inputs-20261105；原登记状态：done。

证据入口：[outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_DOWNLOAD.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_DOWNLOAD.md>)；[outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_README.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_README.md>)；[outputs/talos97_github_staging/paper_remote_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/paper_remote_verification.json>)；[outputs/talos97_github_staging/remote_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/remote_verification.json>)；[outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_PACKAGE.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/talos97_labels_and_inputs_20261105_PACKAGE.json>)；[outputs/talos97_github_staging/build_bundle.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/build_bundle.py>)；[outputs/talos97_github_staging/talos97_labels_and_inputs_20261105.zip](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos97_github_staging/talos97_labels_and_inputs_20261105.zip>)。全部关联文件见证据总表的 W54。

**W55 · DNA-CGDM/DDPM 固定依赖源代码包发布** — 已完成发布

364 manifest源文件及清单，ZIP1058798字节，sha ea4e5259…，固定上游018ac033…；排除检查点/轨迹/缓存，四远端blob原核验通过，commitfdf3160…。本次未新推送。

任务ID：dna-cgdm-ddpm-source-github-20261105；原登记状态：done。

证据入口：[outputs/dna_cgdm_source_20261105/DOWNLOAD.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_source_20261105/DOWNLOAD.md>)；[outputs/dna_cgdm_source_20261105/README_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_source_20261105/README_ZH.md>)；[outputs/dna_cgdm_source_20261105/PACKAGE.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_source_20261105/PACKAGE.json>)；[outputs/dna_cgdm_source_20261105/dna_cgdm_ddpm_source_20261105.zip](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_source_20261105/dna_cgdm_ddpm_source_20261105.zip>)；[outputs/dna_cgdm_source_20261105/tests_recheck.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_source_20261105/tests_recheck.log>)；[outputs/dna_cgdm_source_20261105](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_source_20261105>)。全部关联文件见证据总表的 W55。

**W56 · DDPM 构象集合到 RMSF 的目标澄清** — 已完成分析

核对窗口生成与统计源码，RMSF=sqrt(trace population covariance)，一致对齐与自身集合均值；validation_p50_rmse不是生成RMSF误差。更多生成样本只降MC噪声，不能消除模型偏差。

任务ID：ddpm-ensemble-rmsf-clarification-20261105；原登记状态：done。

证据入口：[outputs/dna_cgdm_20261104/joint_D_seed11/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/joint_D_seed11/status.json>)；[dna_cgdm/dna_model.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/dna_cgdm/dna_model.py>)；[dna_cgdm/dna_metrics.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/dna_cgdm/dna_metrics.py>)；[outputs/dna_cgdm_20261104/joint_D_seed11/history.jsonl](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/joint_D_seed11/history.jsonl>)；[outputs/dna_cgdm_20261104/joint_D_seed11/best.pt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/joint_D_seed11/best.pt>)；[outputs/dna_cgdm_20261104/joint_D_seed11/best_validation.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/joint_D_seed11/best_validation.json>)；[outputs/dna_cgdm_20261104/joint_D_seed11/last.pt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_cgdm_20261104/joint_D_seed11/last.pt>)。全部关联文件见证据总表的 W56。

**W57 · DDPM/RMSF 跨会话研究交接文档** — 已完成文档

形成自足项目背景、文献核验要求、CPU反例与分阶段验证问题；是研究材料交接，没有新训练或MD，建议仍待验证。

任务ID：ddpm-rmsf-claude-research-brief-20261105；原登记状态：done。

证据入口：[docs/DDPM_ENSEMBLE_RMSF_CLAUDE_BRIEF_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/docs/DDPM_ENSEMBLE_RMSF_CLAUDE_BRIEF_ZH.md>)；[dna_cgdm/train.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/dna_cgdm/train.py>)；[dna_cgdm/dna_model.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/dna_cgdm/dna_model.py>)；[dna_cgdm/dna_metrics.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/dna_cgdm/dna_metrics.py>)。全部关联文件见证据总表的 W57。

**W58 · 单帧模型、参考审计与026训练/评估** — 实现完成/训练按指令停止/评估中断

85参考缓存核验但0/85通过预设四项筛查；CPU模型/高斯基线成功，后按用户授权经验拟合026。训练停step1000，评估只见seed101 M18/64，M8/16 RMSF RMSE约5173/5342 nm；64×2未完成。

任务ID：singleframe-conditional-generation-20261105；原登记状态：in_progress。

证据入口：[outputs/dna_singleframe_20261105/REPORT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261105/REPORT_ZH.md>)；[outputs/dna_singleframe_20261105/single_design_026_seed11/fit/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261105/single_design_026_seed11/fit/status.json>)；[outputs/dna_singleframe_20261105/single_design_026_seed11/training_start_verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261105/single_design_026_seed11/training_start_verification.json>)；[outputs/dna_singleframe_20261105/verification.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261105/verification.json>)；[outputs/dna_singleframe_20261105/reference/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261105/reference/status.json>)；[outputs/dna_singleframe_20261105/reference/summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261105/reference/summary.json>)；[outputs/dna_singleframe_20261105/gaussian_001/summary.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261105/gaussian_001/summary.json>)。全部关联文件见证据总表的 W58。


### 2026-11-06

**W59 · 69×100帧 DDPM 跨设计训练及恢复** — 训练完成/生成失败

原A30任务超时后在实际RTX6000Ada重启；交互步取消后从step6800原子checkpoint恢复到6900，最终211张量有限、SHA bbf9299c…。训练成功不表示采样质量；原失败尝试保留。

任务ID：singleframe-crossdesign-fixed100-retry-a6000-20261106；原登记状态：done。

证据入口：[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/fit_fresh/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/fit_fresh/status.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/fit_fresh/final.pt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/fit_fresh/final.pt>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/resume_now.log](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/resume_now.log>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb001_train.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb001_train.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_start400.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_start400.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher400.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher400.json>)。全部关联文件见证据总表的 W59。

**W60 · 验证两端设计 M8 采样耗时与质量探针** — 已完成探针/质量失败

004/100的DDIM100 M8分别103.74/338.21秒，RMSF RMSE2453.52/2429.98 nm。16验证全扫估算M128约8–24h，仅端点线性估计；因发散未执行全扫。

任务ID：singleframe-generated-quality-timing-probe-20261106；原登记状态：done。

证据入口：[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/fit_fresh/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/fit_fresh/status.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/probe_timing.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/probe_timing.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/fit_fresh/final.pt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/fit_fresh/final.pt>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb001_train.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb001_train.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_start400.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_start400.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher400.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher400.json>)。全部关联文件见证据总表的 W60。

**W61 · 单帧 DDPM 灾难发散的根因追踪** — 已完成诊断

alpha_bar499=9.715e-9，epsilon残差约.19乘逆根号增益10144，首端x0误差约1900nm，训练/验证皆重现。低t起步避免爆炸不等于正确先验或合格采样；6900更新也明显有限。

任务ID：singleframe-ddpm-divergence-root-cause-20261106；原登记状态：done。

证据入口：[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb001_train.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb001_train.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher400.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher400.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher450.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher450.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher490.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher490.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher499.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_teacher499.json>)；[dna_singleframe/diagnose_divergence.py](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/dna_singleframe/diagnose_divergence.py>)。全部关联文件见证据总表的 W61。

**W62 · 恒等噪声基线、条件均值与先验融合探针** — 已完成诊断

t499模型epsilon约.186对解析identity .00019，打乱条件变.235；train-only ridge验证均值RMSE1.732→1.637nm，14/16改善。冻结权重M8先验融合RMSF误差.700nm但均值2.293/协方差1.244，非正式修复。

任务ID：singleframe-terminal-prior-mechanism-probe-20261106；原登记状态：done。

证据入口：[progress.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/progress.md>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/prior_sampler_6hb004_m8/result.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/prior_sampler_6hb004_m8/result.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/terminal_prior_probe_condition.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/terminal_prior_probe_condition.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/mean_condition_probe.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/mean_condition_probe.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb001_train.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb001_train.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004.json>)；[outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_start400.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/divergence_6hb004_start400.json>)。全部关联文件见证据总表的 W62。

**W63 · 三 A100 同预算 epsilon/skip/v 参数化消融及批处理迁移** — 已完成训练和小样本评估

Slurm23239在11/6 18:22完成，三臂同初始化/顺序/帧/6900更新。004/100 RMSF RMSE：epsilon2445.74/2431.78，skip .927/.530，v .699/.462 nm。仅两验证设计M8，均值/协方差误差仍大；未通过完整分布或oxDNA物理验证。

任务ID：singleframe-three-a100-parameterization-ablation-20261106；原登记状态：in_progress。

证据入口：[outputs/dna_singleframe_20261106/ablation_3a100_20261106/COMPARISON_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/ablation_3a100_20261106/COMPARISON_ZH.md>)；[outputs/dna_singleframe_20261106/ablation_3a100_20261106/comparison.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/ablation_3a100_20261106/comparison.json>)；[outputs/dna_singleframe_20261106/ablation_3a100_20261106/monitor_status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/ablation_3a100_20261106/monitor_status.json>)；[outputs/dna_singleframe_20261106/ablation_3a100_20261106/full/eps/train/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/ablation_3a100_20261106/full/eps/train/status.json>)；[outputs/dna_singleframe_20261106/ablation_3a100_20261106/full/eps_skip/train/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/ablation_3a100_20261106/full/eps_skip/train/status.json>)；[outputs/dna_singleframe_20261106/ablation_3a100_20261106/full/v/train/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/ablation_3a100_20261106/full/v/train/status.json>)；[outputs/dna_singleframe_20261106/ablation_3a100_20261106/full/eps/evaluation/status.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/dna_singleframe_20261106/ablation_3a100_20261106/full/eps/evaluation/status.json>)。全部关联文件见证据总表的 W63。

**W64 · DeFlow、Flow4D、DeltaFlow 权重与 DNA 迁移适配审计** — 已完成审计

下载三checkpoint并核SHA/LFS、有限张量和配置；与当前DNA模型同名同形权重0，原nm点云保留范围仅约11–28%。环境/spconv与目标不匹配；未启动微调，尚无DNA迁移精度证据。

任务ID：scene-flow-pretrained-transfer-audit-20261106；原登记状态：done。

证据入口：[outputs/pretrained_scene_flow_20261106/ASSESSMENT_ZH.md](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/pretrained_scene_flow_20261106/ASSESSMENT_ZH.md>)；[outputs/pretrained_scene_flow_20261106/manifest.json](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/pretrained_scene_flow_20261106/manifest.json>)；[outputs/pretrained_scene_flow_20261106/deflow_best.ckpt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/pretrained_scene_flow_20261106/deflow_best.ckpt>)；[outputs/pretrained_scene_flow_20261106/deltaflow-av2.ckpt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/pretrained_scene_flow_20261106/deltaflow-av2.ckpt>)；[outputs/pretrained_scene_flow_20261106/flow4d_best.ckpt](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/pretrained_scene_flow_20261106/flow4d_best.ckpt>)；[outputs/pretrained_scene_flow_20261106](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/pretrained_scene_flow_20261106>)。全部关联文件见证据总表的 W64。


## 任务表以外的细分操作与更正

以下是原进度日志明确记录、没有单独 feature ID 的操作；已关联到相应主题，避免漏记或重复计算实验套数。

| 细分操作 | 可复核依据 | 归属与边界 |
|---|---|---|
| TALOS97 array/feeder取消、八分片KeyError修复及GPU放置调整 | snapshots/weekly_progress_excerpt.md；campaign/submission/task_table | W05，初次失败未产轨迹；最终八分片替代原方案 |
| 旧torch的stable argsort、SciPy/张量接口、float64 Ridge等兼容性修复 | 对应run/retry日志与周内事件索引 | 已保留失败尝试，不把失败稿混作最终结果 |
| 015的2000帧PBC/骨架异常定位与按指令排除 | covariance_aux20m_20261102/diagnostics/015_REPORT_ZH.md及check015_results.json | W19，异常不是简单缓存错位；之后三个对照均相同71训练设计 |
| 009异常四节点及其余四可疑轨迹逐帧追查 | rmse_floor_diagnosis_20261103/REPORT_ZH.md | W26，正常设计误差下限未定量，后续未按预测误差偷偷删点 |
| 单GPU多样本分片提交偏好固化为skill | progress.md“Corrected scheduling”“GPU批量提交约定”；本机slurm-gpu-sharded-submit/SKILL.md | W36，12个worker替代39单样本作业；仅记录历史skill创建，不在本次修改skill |
| GPR的统一均值、每设计真实均值oracle和训练均值对照 | flat42_graph_augmented_20261104/MEAN_BASELINES_ZH.md和mean_baselines.json | W41，真实设计均值oracle读标签，不是可部署基线 |
| 参考位移D的GPU SVD失败及CPU 3×3分解回退 | initial_gpu_svd_failure.json与direct_verification.json | W43/44，保留首错，88可用结果通过001直接2000帧核验 |
| DNA-CGDM稀疏TAGConv、chunked pooling、checkpoint/BF16内存适配 | dna_cgdm/efficient_graph.py；probe/test日志 | W49，最大设计工程门槛通过，未由此得到最终生成质量 |
| 85参考门槛、低秩高斯同设计诊断与单帧工程测试 | dna_singleframe_20261105/REPORT_ZH.md、reference/summary.json、gaussian_001/summary.json | W58，0/85通过预设四筛查；高斯时间留出NRMSE .125254，非跨设计生成证明 |
| 交互任务断开风险、checkpoint恢复与真实sbatch迁移 | batch_resume_and_summarize.sbatch、batch_23239.log、Slurm审计回执 | W63，setsid不改变Slurm allocation生命周期；真实batch完成，不需用户再授权重跑 |
| 单设计训练按指令停止、旧候选/重复作业取消与输出保留 | stopped_by_user/status、各submission/取消回执、周内日志 | 未自动重启；本次只核查、整理和校正harness |

## 本次更正与结果使用边界

- 64条原任务记录中，两个fungus-diffusion ID指向同一实验；按63项主题计，不称64套独立实验。
- 原任务表仍为进行中的平方目标三臂、相关辅助三臂、10,000轮实验和D模型已有最终输出；以最终status/evaluation为计算完成证据。报告中的宏平均做了本次复算，但不代表重新跑了全部模型forward或MD。
- 三A100的3个train/status均6,900/6,900，3个evaluation/summary均完成；初始化、帧、顺序、归一化等七个公平比较字段逐项一致。Slurm23239 COMPLETED；旧monitor_status.json属于交互期残留，不能用它否定最终batch结果。
- 97/39/95分别是请求目标；90/20/88是相应实际可用完成数。有限值、正常退出和文件存在都不能单独证明物理有效。
- DNA-CGDM/026部分评估的旧PID只在本次主机gpu03核查；没有联查所有其他节点，因此不声称全系统无活动进程。没有最终产物的任务仍列未完成。
- Mango pilot源报告把6顶点/12边/8三角面的代表写为四面体，名称与计数矛盾。本材料采用计数描述，不沿用错误形状名；不更改原始报告。两路带force-cap的短跑与后续无帽长跑要分开解释。
- 源设计缺失的旧重建判断已被后续源ZIP拓扑核验更正；2964条几何长边不能直接称为错接。拓扑通过与坐标/取向/轨迹有效性是不同证据。
- P50是无量纲量，旧兼容键名中的_nm不构成nm单位证据。RMSF、参考位移D、P50及生成集合RMSF不能直接交叉比较数值来宣称提升。
- GitHub发布使用历史回执/commit，本次没有重新拉取当前远端；报告涵盖此项目可访问的记录，不能替代其他目录或无法访问的旧会话。根目录没有Git历史可用。

## 证据核对等级与完整性

证据总表每行列出关联工作编号、绝对/项目路径、类型、大小、最后修改时间、是否重算SHA-256。小型报告、表格、日志优先哈希；大型checkpoint/NPZ/轨迹仅索引或引用历史manifest，不在本次重新流式扫描。目录按明确路径读取一层，不做共享存储全树遍历。文件哈希固定本次内容，不能证明科学结论；已有verification.json是历史验证回执，除非本次审计记录明确说重新复算，否则不声称复跑。

- 任务清单：WORK_ITEMS.csv / WORK_ITEMS.json。
- 完整证据：EVIDENCE_INDEX.md / EVIDENCE_INDEX.csv / EVIDENCE_INDEX.json。
- 原始引用补全：REFERENCE_RESOLUTION.json（commit/URL与本地路径分开）。
- 逐日事件：TIMELINE_ZH.md / TIMELINE.json；原日志快照带行号保留。
- 现成图表：FIGURE_INDEX_ZH.md，直接链接已有PNG/PDF/SVG，不改数据重绘。
- 本次Slurm/进程/指标互核：audit/目录及VERIFICATION.json。
- 快照：snapshots/，保留整理前的任务表/进度/交接，不覆盖原实验产物。
