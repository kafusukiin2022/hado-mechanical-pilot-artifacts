"""Build this week's bounded, local work/evidence catalog from frozen trackers.
This is a documentation-only utility. It does not run experiments or traverse
project trees recursively. Evidence directories are explicit and read one level.
"""
import csv
import hashlib
import json
import re
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
TZ=ZoneInfo('Asia/Shanghai')
START=time.time()
features=json.loads((OUT/'snapshots/weekly_features.json').read_text())
annotations=[]
for line in (OUT/'task_annotations.tsv').read_text().splitlines():
    if line.strip():
        prefix,title,status,result=line.split('|',3)
        annotations.append(dict(prefix=prefix,title=title,status=status,result=result))
assert len(features)==len(annotations)==64
TASKS=[]
for a in annotations:
    matches=[f for f in features if f['id'].startswith(a['prefix']+'-2026')]
    assert len(matches)==1,(a['prefix'],len(matches))
    f=matches[0]
    TASKS.append(dict(task_id='W%02d'%(len(TASKS)+1),feature_id=f['id'],date='2026-'+f['id'][-4:-2]+'-'+f['id'][-2:],title=a['title'],recorded_status=f.get('status'),audited_status=a['status'],result=a['result'],original_summary=f.get('summary',''),original_evidence=f.get('evidence_ref',''),evidence=[]))
BY={t['feature_id']:t for t in TASKS}

# Explicit supporting evidence directories; only direct children are indexed.
SUPPORT={
'singleframe-conditional-generation':['outputs/dna_singleframe_20261105','outputs/dna_singleframe_20261105/reference','outputs/dna_singleframe_20261105/gaussian_001','outputs/dna_singleframe_20261105/single_design_026_seed11/fit','outputs/dna_singleframe_20261105/single_design_026_seed11/evaluation_last'],
'dna-cgdm':['outputs/dna_cgdm_20261104','outputs/dna_cgdm_20261104/real_smoke','outputs/dna_cgdm_20261104/probe100_flat64','outputs/dna_cgdm_20261104/joint_D_seed11','dna_cgdm'],
'rmsf-square-target':['experiments/talos97_rmsf_scalar/squared_target20m_20261102/'+a for a in ['rmsf_mse','squared_loss','direct_square']],
'rmsf-covariance-aux':['experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/'+a for a in ['diagnostics','no_aux','true_aux','shuffled_aux']],
'rmsf-covariance-amplitude':['experiments/talos97_rmsf_scalar/covariance_amplitude20m_20261103/'+a for a in ['no_aux','true_cov','shuffled_cov']],
'rmsf-covariance-10k':['experiments/talos97_rmsf_scalar/covariance_amplitude_10k_20261103/true_cov'],
'reference-displacement-models':['experiments/reference_displacement_models_20261104/results'],
'flat42-graph-augmentation':['experiments/flat42_graph_augmented_20261104/results'],
'singleframe-three-a100-parameterization-ablation':['outputs/dna_singleframe_20261106/ablation_3a100_20261106/full/'+a+'/'+b for a in ['eps','eps_skip','v'] for b in ['train','evaluation']],
'singleframe-terminal-prior-mechanism-probe':['outputs/dna_singleframe_20261106/all69_fixed100_seed11_retry_a6000/prior_sampler_6hb004_m8'],
'edge-ablation20m':['experiments/talos97_rmsf_scalar/edge_ablation20m_20261102/single_seed120'],
'modal-compliance-rmsf':['experiments/talos97_rmsf_scalar/modal_compliance20m_20261102'],
'rmsf-region-representation-016070':['experiments/talos97_rmsf_scalar/region_representation_016070_20261102'],
'rmsf-fungus-diffusion':['experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/retry_1/'+a for a in ['local','backbone','topology','spatial','shuffled']],
'fungus-diffusion':['experiments/talos97_rmsf_scalar/fungus_diffusion_20261103/retry_1'],
'direct-macro-rmse-clean3seed':['experiments/talos97_rmsf_scalar/direct_macro_rmse_clean_3seed_20261103/seed'+s for s in ['11','22','33']],
'talos97-20m-rmsf-prediction':['experiments/talos97_rmsf_scalar/continuation20m_20261102'],
'mango250-geometry-library-dual-route-pilot':['outputs/mango250_geometry_library_20261105/route_pilot_TOP000008_GEO000011/conversion/'+a for a in ['DX2HB','6HB']],
}
ALLOWED={'.md','.json','.csv','.tsv','.txt','.log','.png','.pdf','.svg','.html','.py','.sh','.sbatch','.slurm','.pt','.npz','.npy','.ckpt','.jsonl','.zip','.gz','.conf','.top','.in','.ply'}
EVIDENCE={}
REFERENCES=[]
DIRECTORIES=set()


def register(path,task,role='support'):
    path=Path(path)
    if not path.is_absolute(): path=ROOT/path
    if not path.exists(): return None
    key=str(path)
    if key not in EVIDENCE:
        st=path.stat()
        EVIDENCE[key]=dict(path=key,project_path=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else key,kind='directory' if path.is_dir() else 'file',bytes=None if path.is_dir() else st.st_size,mtime_cst=datetime.fromtimestamp(st.st_mtime,TZ).isoformat(),sha256=None,hash_status='not_yet_checked',task_ids=[],roles=[])
    e=EVIDENCE[key]
    if task['task_id'] not in e['task_ids']:e['task_ids'].append(task['task_id'])
    if role not in e['roles']:e['roles'].append(role)
    if key not in task['evidence']:task['evidence'].append(key)
    return path


def add_directory(path,task):
    p=register(path,task,'directory')
    if p is None or not p.is_dir(): return
    DIRECTORIES.add(str(p))
    for q in sorted(p.iterdir()):
        if q.is_file() and q.suffix.lower() in ALLOWED:
            if not any(w in q.name.lower() for w in ['before_readout_index_fix','before_twohop_exclusion']):register(q,task)


for t in TASKS:
    base=ROOT
    for raw in t['original_evidence'].split(';'):
        raw=raw.strip()
        if not raw:continue
        ref=dict(task_id=t['task_id'],original_reference=raw,resolution=None,resolved_paths=[])
        if raw.startswith('http'):
            ref.update(resolution='remote_reference_not_refetched',url=raw)
        elif re.match(r'^commit\s+[0-9a-f]{7,40}$',raw):
            # The source-audit bundle was published to the private HADO artifacts repository.
            sha=raw.split()[1]
            ref.update(resolution='historical_commit_reference',commit=sha,url='https://github.com/kafusukiin2022/hado-mechanical-pilot-artifacts/commit/'+sha)
        else:
            candidates=[]
            for anchor in [ROOT,base]:
                p=Path(raw) if Path(raw).is_absolute() else anchor/raw
                if any(c in p.name for c in '*?['):
                    if p.parent.is_dir():candidates.extend(sorted(p.parent.glob(p.name)))
                elif p.exists():candidates.append(p)
                if candidates:break
            if candidates:
                for p in dict.fromkeys(candidates):
                    q=register(p,t,'primary')
                    ref['resolved_paths'].append(str(q))
                first=candidates[0]
                if base==ROOT:base=first if first.is_dir() else first.parent
                ref['resolution']='exists'
            else:ref['resolution']='unresolved_reference'
        REFERENCES.append(ref)
    # Expand only named output/experiment source directories, one level, avoiding root/docs scans.
    parents=set()
    for key in list(t['evidence']):
        p=Path(key)
        d=p if p.is_dir() else p.parent
        if d!=ROOT and d not in [ROOT/'docs',ROOT/'docs/harness'] and len(d.relative_to(ROOT).parts)>=2:parents.add(d)
    for d in sorted(parents):add_directory(d,t)
    a=next(a for a in annotations if t['feature_id'].startswith(a['prefix']+'-2026'))
    for d in SUPPORT.get(a['prefix'],[]):
        if (ROOT/d).is_dir():add_directory(d,t)
    if t['feature_id'].startswith('talos97-source-structure-audit'):
        add_directory('experiments/talos97_rmsf_scalar/input_source_audit_20261103',t)

# Exact known source paths rather than a general recursive repository scan.
for prefix,files in {
'singleframe-conditional-generation':['dna_singleframe/data.py','dna_singleframe/model.py','dna_singleframe/train.py','dna_singleframe/reference_audit.py','dna_singleframe/gaussian.py'],
'singleframe-ddpm-divergence-root-cause':['dna_singleframe/model.py','dna_singleframe/diagnose_divergence.py'],
'singleframe-three-a100-parameterization-ablation':['dna_singleframe/ablation_model.py','dna_singleframe/train_ablation.py','dna_singleframe/evaluate_ablation.py'],
'oxdna-protocol-audit':['outputs/talos97_dt005_continue_20m_20261101_8shards/campaign.json'],
'talos97-source-upload':['TALOS97_SOURCE_AUDIT_20261103.md','TALOS97_SOURCE_MATCH_MANIFEST.json'],
}.items():
    task=next(t for t in TASKS if t['feature_id'].startswith(prefix+'-2026'))
    for f in files:register(f,task)

# Hash small, reviewable artifacts with a bounded aggregate read budget; raw binaries stay indexed.
read_bytes=0
for e in EVIDENCE.values():
    if e['kind']=='directory':e['hash_status']='directory_not_hashed';continue
    if e['bytes']>4_000_000 or read_bytes+e['bytes']>80_000_000:
        e['hash_status']='metadata_only_large_or_read_budget';continue
    p=Path(e['path'])
    e['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    e['hash_status']='sha256_recomputed_now'
    read_bytes+=e['bytes']

# Original logs are retained verbatim in a frozen excerpt; preserve heading-level audit trail.
lines=(OUT/'snapshots/progress.md').read_text().splitlines()
start=next(i for i,l in enumerate(lines) if l.startswith('## 2026-11-01'))
TIMELINE=[]
for i,line in enumerate(lines):
    if (i>=start or (i<10 and '2026-11-03' in line)) and line.startswith('## '):
        TIMELINE.append(dict(sequence=len(TIMELINE)+1,original_line=i+1,title=line[3:],source='snapshots/progress.md',date_from_heading=(re.search(r'2026-\d{2}-\d{2}',line).group(0) if re.search(r'2026-\d{2}-\d{2}',line) else None)))


def dump(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def write_csv(name,rows,fields):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
        for row in rows:
            w.writerow({k:'; '.join(row[k]) if isinstance(row.get(k),list) else row.get(k) for k in fields})


def link(p,label=None):
    p=Path(p)
    label=label or (str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p))
    return '['+label+'](<'+str(p)+'>)'


# Replace the draft's English/truncated table with all Chinese results in chronological order.
doc=OUT/'WORKLOG_AND_EVIDENCE_INDEX_ZH.md'
s=doc.read_text().split('<!-- AUTO_INDEX_START -->')[0]
s=s.replace('共登记 **64 项**与本周日期相关的工作条目','共登记 **64 条任务记录**（含一对重复登记，折合63项主题工作）')
s=s.replace('其中包括完成的分析/实验、未通过或只部分完成的任务、仍未结题的训练，以及被后续方案取代的运行。','其中包括完成的分析/实验、失败及部分完成任务、尚未结题的训练和被取代的运行。另逐一索引连续日志中的 '+str(len(TIMELINE))+' 个事件标题，覆盖临时诊断、取消重排、兼容性修复及发布更正。')
s=s.replace('无活动进程','未在本次主机gpu03发现相应旧PID')
s=s.replace('未发现仍运行的 PID','未在本次主机gpu03发现相应旧PID')
s=s.replace('没有活动进程','未在本次主机gpu03发现相应旧PID')
s=s.replace('以下登记从本项目','以下按任务创建/记录日期排列；日期源于原任务ID，不保证是实验实际完成日。逐日事件保留原日志标题/行号供复核。以下登记从本项目')
s+='\n'
for day in sorted({t['date'] for t in TASKS}):
    s+='\n### '+day+'\n\n'
    for t in TASKS:
        if t['date']!=day:continue
        s+='**'+t['task_id']+' · '+t['title']+'** — '+t['audited_status']+'\n\n'+t['result']+'\n\n'
        s+='任务ID：'+t['feature_id']+'；原登记状态：'+str(t['recorded_status'])+'。\n\n'
        # Prioritize actual reports, final metrics and verification receipts in visible entry points.
        keys=list(t['evidence'])
        def rank(k):
            p=Path(k);n=p.name.lower()
            if p.is_dir():return 7
            if n.endswith('.md'):return 0
            if any(x in n for x in ['comparison','verification','evaluation','summary','result','manifest','pipeline_status','status']):return 1
            if p.suffix.lower() in ['.csv','.png','.svg','.pdf']:return 2
            return 5
        selected=sorted(keys,key=rank)[:7]
        s+='证据入口：'+'；'.join(link(k) for k in selected)+'。全部关联文件见证据总表的 '+t['task_id']+'。\n\n'

s+='''
## 任务表以外的细分操作与更正

以下是原进度日志明确记录、没有单独 feature ID 的操作；已关联到相应主题，避免漏记或重复计算实验套数。

| 细分操作 | 可复核依据 | 归属与边界 |
|---|---|---|
| TALOS97 array/feeder取消、八分片KeyError修复及GPU放置调整 | snapshots/weekly_progress_excerpt.md；campaign/submission/task_table | W05，初次失败未产轨迹；最终八分片替代原方案 |
| 旧torch的stable argsort、SciPy/张量接口、float64 Ridge等兼容性修复 | 对应run/retry日志与周内事件索引 | 已保留失败尝试，不把失败稿混作最终结果 |
| 015的2000帧PBC/骨架异常定位与按指令排除 | covariance_aux20m_20261102/diagnostics/015_REPORT_ZH.md及check015_results.json | W19，异常不是简单缓存错位；之后三个对照均相同71训练设计 |
| 009异常四节点及其余四可疑轨迹逐帧追查 | rmse_floor_diagnosis_20261103/REPORT_ZH.md | W26，正常设计误差下限未定量，后续未按预测误差偷偷删点 |
| 单GPU多样本分片提交偏好固化为skill | progress.md“Corrected scheduling”“GPU批量提交约定”；本机slurm-gpu-sharded-submit/SKILL.md | W36，12个worker替代39单样本作业；仅记录历史skill创建，不在本次修改skill |
| GPR的统一均值、每设计真实均值oracle和训练均值对照 | flat42_graph_augmented_20261104/MEAN_BASELINES_ZH.md和mean_baselines.json | W41，真实设计均值oracle读标签，不是可部署基线 |
| 参考位移D的GPU SVD失败及CPU 3×3分解回退 | initial_gpu_svd_failure.json与direct_verification.json | W43/44，保留首错，88可用结果通过001直接2000帧核验 |
| DNA-CGDM稀疏TAGConv、chunked pooling、checkpoint/BF16内存适配 | dna_cgdm/efficient_graph.py；probe/test日志 | W49，最大设计工程门槛通过，未由此得到最终生成质量 |
| 85参考门槛、低秩高斯同设计诊断与单帧工程测试 | dna_singleframe_20261105/REPORT_ZH.md、reference/summary.json、gaussian_001/summary.json | W58，0/85通过预设四筛查；高斯时间留出NRMSE .125254，非跨设计生成证明 |
| 交互任务断开风险、checkpoint恢复与真实sbatch迁移 | batch_resume_and_summarize.sbatch、batch_23239.log、Slurm审计回执 | W63，setsid不改变Slurm allocation生命周期；真实batch完成，不需用户再授权重跑 |
| 单设计训练按指令停止、旧候选/重复作业取消与输出保留 | stopped_by_user/status、各submission/取消回执、周内日志 | 未自动重启；本次只核查、整理和校正harness |

## 本次更正与结果使用边界

- 64条原任务记录中，两个fungus-diffusion ID指向同一实验；按63项主题计，不称64套独立实验。
- 原任务表仍为进行中的平方目标三臂、相关辅助三臂、10,000轮实验和D模型已有最终输出；以最终status/evaluation为计算完成证据。报告中的宏平均做了本次复算，但不代表重新跑了全部模型forward或MD。
- 三A100的3个train/status均6,900/6,900，3个evaluation/summary均完成；初始化、帧、顺序、归一化等七个公平比较字段逐项一致。Slurm23239 COMPLETED；旧monitor_status.json属于交互期残留，不能用它否定最终batch结果。
- 97/39/95分别是请求目标；90/20/88是相应实际可用完成数。有限值、正常退出和文件存在都不能单独证明物理有效。
- DNA-CGDM/026部分评估的旧PID只在本次主机gpu03核查；没有联查所有其他节点，因此不声称全系统无活动进程。没有最终产物的任务仍列未完成。
- Mango pilot源报告把6顶点/12边/8三角面的代表写为四面体，名称与计数矛盾。本材料采用计数描述，不沿用错误形状名；不更改原始报告。两路带force-cap的短跑与后续无帽长跑要分开解释。
- 源设计缺失的旧重建判断已被后续源ZIP拓扑核验更正；2964条几何长边不能直接称为错接。拓扑通过与坐标/取向/轨迹有效性是不同证据。
- P50是无量纲量，旧兼容键名中的_nm不构成nm单位证据。RMSF、参考位移D、P50及生成集合RMSF不能直接交叉比较数值来宣称提升。
- GitHub发布使用历史回执/commit，本次没有重新拉取当前远端；报告涵盖此项目可访问的记录，不能替代其他目录或无法访问的旧会话。根目录没有Git历史可用。

## 证据核对等级与完整性

证据总表每行列出关联工作编号、绝对/项目路径、类型、大小、最后修改时间、是否重算SHA-256。小型报告、表格、日志优先哈希；大型checkpoint/NPZ/轨迹仅索引或引用历史manifest，不在本次重新流式扫描。目录按明确路径读取一层，不做共享存储全树遍历。文件哈希固定本次内容，不能证明科学结论；已有verification.json是历史验证回执，除非本次审计记录明确说重新复算，否则不声称复跑。

- 任务清单：WORK_ITEMS.csv / WORK_ITEMS.json。
- 完整证据：EVIDENCE_INDEX.md / EVIDENCE_INDEX.csv / EVIDENCE_INDEX.json。
- 原始引用补全：REFERENCE_RESOLUTION.json（commit/URL与本地路径分开）。
- 逐日事件：TIMELINE_ZH.md / TIMELINE.json；原日志快照带行号保留。
- 现成图表：FIGURE_INDEX_ZH.md，直接链接已有PNG/PDF/SVG，不改数据重绘。
- 本次Slurm/进程/指标互核：audit/目录及VERIFICATION.json。
- 快照：snapshots/，保留整理前的任务表/进度/交接，不覆盖原实验产物。
'''
doc.write_text(s)

# Machine-readable output and complete clickable evidence register.
dump('WORK_ITEMS.json',TASKS)
dump('EVIDENCE_INDEX.json',list(EVIDENCE.values()))
dump('REFERENCE_RESOLUTION.json',REFERENCES)
dump('TIMELINE.json',TIMELINE)
write_csv('WORK_ITEMS.csv',TASKS,['task_id','date','title','audited_status','recorded_status','result','feature_id','evidence'])
write_csv('EVIDENCE_INDEX.csv',list(EVIDENCE.values()),['task_ids','project_path','path','kind','bytes','mtime_cst','hash_status','sha256','roles'])
# Keep the earlier filename as a compatibility alias, now fully resolved.
write_csv('EVIDENCE_INVENTORY.csv',list(EVIDENCE.values()),['task_ids','project_path','path','kind','bytes','mtime_cst','hash_status','sha256','roles'])
es=['# 证据总索引','', '每条任务在WORK_ITEMS中有中文结果及限制；这里列出本次实际找到的全部选定证据。SHA字段与JSON/CSV对应。大文件未读或历史回执不等于本次复跑。','']
for t in TASKS:
    es+=['## '+t['task_id']+' '+t['title'],'']
    for k in t['evidence']:
        e=EVIDENCE[k]
        es.append('- '+link(k)+' · '+e['kind']+' · '+str(e['bytes'])+' bytes · '+e['hash_status']+((' · SHA '+e['sha256']) if e['sha256'] else ''))
    es+=['']
(OUT/'EVIDENCE_INDEX.md').write_text('\n'.join(es)+'\n')
figs=[e for e in EVIDENCE.values() if Path(e['path']).suffix.lower() in ['.png','.pdf','.svg']]
fs=['# 可直接用于汇报的现有图表','', '图表来自已记录的实验目录，本次没有改绘。使用前同时读相应报告的计量单位、样本数、分割和限制；图内label/QA以原文件为准。','', '| 工作 | 图表文件 | 大小（bytes） |','|---|---|---:|']
for e in figs:fs.append('| '+', '.join(e['task_ids'])+' | '+link(e['path'])+' | '+str(e['bytes'])+' |')
(OUT/'FIGURE_INDEX_ZH.md').write_text('\n'.join(fs)+'\n')
(OUT/'TIMELINE_ZH.md').write_text('# 周内事件时间线\n\n按原进度日志书写顺序保留，包含开始、失败、兼容性修复、取消重排、重试、最终验证和发布更正。标题日期是记录日期，不是所有任务真实执行时刻；无日期标题沿用相邻上下文，不擅自补日期。\n\n'+ '\n'.join(str(e['sequence'])+'. '+e['title']+' — '+link(OUT/'snapshots/progress.md', '冻结progress.md:'+str(e['original_line']))+'（原第'+str(e['original_line'])+'行）' for e in TIMELINE)+'\n')
stats=dict(as_of_cst=datetime.now(TZ).isoformat(),feature_records=64,distinct_theme_count=63,timeline_headings=len(TIMELINE),evidence_entries=len(EVIDENCE),file_entries=sum(e['kind']=='file' for e in EVIDENCE.values()),recomputed_hashes=sum(e['sha256'] is not None for e in EVIDENCE.values()),bytes_read_for_hash=read_bytes,resolution_counts=dict(Counter(r['resolution'] for r in REFERENCES)),figure_files=len(figs),bounded_directories=len(DIRECTORIES),elapsed_seconds=time.time()-START)
dump('INDEX_STATS.json',stats)
print(json.dumps(stats,ensure_ascii=False))

