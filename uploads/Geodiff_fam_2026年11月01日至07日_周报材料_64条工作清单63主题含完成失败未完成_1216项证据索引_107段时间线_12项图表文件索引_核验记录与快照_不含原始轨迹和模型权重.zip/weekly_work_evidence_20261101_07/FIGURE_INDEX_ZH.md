# 可直接用于汇报的现有图表

图表来自已记录的实验目录，本次没有改绘。使用前同时读相应报告的计量单位、样本数、分割和限制；图内label/QA以原文件为准。

| 工作 | 图表文件 | 大小（bytes） |
|---|---|---:|
| W01 | [outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.pdf](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.pdf>) | 27804 |
| W01 | [outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.png](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.png>) | 483331 |
| W01 | [outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.svg](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos048_dt005_continue_1e8_20261031/trajectory_analysis/replica_stability_summary.svg>) | 41327 |
| W12 | [experiments/talos97_rmsf_scalar/region_representation_016070_20261102/layer_diagnosis.pdf](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/layer_diagnosis.pdf>) | 41106 |
| W12 | [experiments/talos97_rmsf_scalar/region_representation_016070_20261102/layer_diagnosis.png](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/layer_diagnosis.png>) | 1123224 |
| W12 | [experiments/talos97_rmsf_scalar/region_representation_016070_20261102/layer_diagnosis.svg](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/experiments/talos97_rmsf_scalar/region_representation_016070_20261102/layer_diagnosis.svg>) | 105936 |
| W40 | [outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.png](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.png>) | 883821 |
| W40 | [outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.pdf](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.pdf>) | 27038 |
| W40 | [outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.svg](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/talos40_flat42_25m_20261103/rmsf_analysis/distribution_comparison.svg>) | 63736 |
| W42 | [outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.pdf](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.pdf>) | 42731 |
| W42 | [outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.png](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.png>) | 359470 |
| W42 | [outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.svg](</home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/rmsf_all108_distribution_20261104/rmsf_all108_distribution.svg>) | 55794 |
