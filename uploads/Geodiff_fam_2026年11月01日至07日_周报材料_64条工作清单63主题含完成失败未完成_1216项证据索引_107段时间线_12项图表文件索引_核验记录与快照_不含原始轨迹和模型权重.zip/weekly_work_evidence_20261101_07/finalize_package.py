import csv,hashlib,json,re,zipfile
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
NL=chr(10)
verification=json.loads((OUT/'VERIFICATION.json').read_text())
assert verification['passed']
items=json.loads((OUT/'WORK_ITEMS.json').read_text())
for item in items:
 if item['feature_id']=='rmsf-fungus-diffusion-20261103':
  old_title=item['title'];old_result=item['result']
  item['title']='有符号源场扩散五臂配对消融'
  item['result']='初次启动接口失败后保留日志重试；local/backbone/topology/spatial及随机中心五臂完成。Backbone的18验证Top20 MAE由local .6345降至.5710 nm，配对bootstrap区间不跨零；总体RMSE差区间跨零。单种子历史开发验证，不证明稳定整体泛化提升。与fungus-diffusion条目是同一实验的双重登记。'
  report=OUT/'WORKLOG_AND_EVIDENCE_INDEX_ZH.md';s=report.read_text();s=s.replace(old_title,item['title']).replace(old_result,item['result']);report.write_text(s)
(OUT/'WORK_ITEMS.json').write_text(json.dumps(items,ensure_ascii=False,indent=2)+NL)
fields=['task_id','date','title','audited_status','recorded_status','result','feature_id','evidence']
with (OUT/'WORK_ITEMS.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
 for row in items:w.writerow({k:'; '.join(row[k]) if isinstance(row.get(k),list) else row.get(k) for k in fields})
# Synchronize stale task states only where final status and result artifacts were checked.
p=ROOT/'feature_list.json';data=json.loads(p.read_text())
updates={
'rmsf-square-target-20261102':'Audit 2026-11-07: all three arms completed 2026-11-02 21:19, exit0. Validation18 RMSE ordinary/squared-loss/direct-square=1.708989/1.703220/1.711077 nm. Saved per-design macro metrics recomputed; single seed, no stable gain claim.',
'rmsf-covariance-aux-20261102':'Audit 2026-11-07: final three-arm pipeline completed 2026-11-03 00:19, all exit0. Effective71train excluding015,18validation. Validation17ex009 RMSE no/true/shuffled=.317519/.320506/.318744 nm; true correlation auxiliary did not improve. Saved metric aggregation verified.',
'rmsf-covariance-10k-20261103':'Audit 2026-11-07: Slurm21255 COMPLETED 0:0 at2026-11-03 20:21; stopped_epoch10000,best_epoch121. Best validation18 RMSE1.703230 nm,17ex009 .323307. One true_cov arm only, no matched long noaux/shuffle controls. Saved metrics recomputed.',
'reference-displacement-models-20261104':'Audit 2026-11-07: results/status complete; GPR/fungus seed11x120epochs completed. Validation17 reference-displacement D RMSE1.169702/1.146669 nm,best epochs36/32. Different target from RMSF. Single seed, historical validation;7 target trajectories missing.',
'weekly-work-evidence-index-20261107':'Compiled64 original task records (63 themes),107 progress headings,1216 selected evidence entries (1128files/88dirs). All112 references resolved/classified;856 small evidence SHA256 values recomputed;1986 Markdown links checked;258 saved macro fields and9 ablation rows/fairness keys cross-checked. Documentation only;no model or simulation rerun.'
}
for x in data['features']:
 if x.get('id') in updates:x['status']='done';x['summary']=updates[x['id']];x['updated_at']='2026-11-07'
 if x.get('id')=='talos95-reference-displacement-20261104':x['summary']='Audit2026-11-07:88/95 available labels complete;7 missing full2000frame trajectories. 6hb_001 direct2000frame check passed max_error5.5067e-14nm after3x3SVD CPU fallback. Overall95-target remains incomplete.';x['updated_at']='2026-11-07'
 if x.get('id')=='dna-cgdm-20261104':x['summary']='Implementation/cache/engineering gates passed; full D120epoch training not verified complete. Last visible status epoch36 with35/69 designs at2026-11-05; recordedPID1278978 absent on audit hostgpu03 Nov7. Other-node liveness not checked. No completed generated-quality result.';x['updated_at']='2026-11-07'
 if x.get('id')=='singleframe-conditional-generation-20261105':x['summary']='Single-frame/reference audit and Gaussian baseline implemented;026 training stopped by user atstep1000. Evaluation last seed101 M18/64 Nov6; M8/16 generated RMSF RMSE5173.48/5341.87nm. RecordedPID2596460 absent on audit hostgpu03 Nov7;other-node liveness not checked. M64x2 incomplete.';x['updated_at']='2026-11-07'
p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+NL)
# Preserve a concise current handoff above the older active-task descriptions.
p=ROOT/'session-handoff.md';old=p.read_text();marker='## 2026-11-07 Weekly work/evidence audit complete'
if marker not in old:
 text=marker+NL+NL+'User requested a complete Nov1–7 work list and evidence index only (no PPTX). Deliverables are under outputs/weekly_work_evidence_20261101_07/: WORKLOG_AND_EVIDENCE_INDEX_ZH.md, WORK_ITEMS.csv/json, EVIDENCE_INDEX.md/csv/json, TIMELINE_ZH.md, FIGURE_INDEX_ZH.md, VERIFICATION.json, audit/, snapshots/ and SHA256SUMS.txt.64 original records include one duplicate pair (63 themes);107 log headings;1216 evidence entries;856 bounded SHA recomputations. Verification passed:1986 links,112 original references resolved/classified,258 macro fields and9 ablation rows checked. Large trajectories not reread; models not re-forwarded; GitHub not refetched. Root has no Git history.'+NL+NL+'Status corrections:23239 batch/three6900-step eps/skip/v arms complete (two validation designs M8 only). Squared/correlation/10k and D-model tasks had stale in_progress tags; final outputs audited and feature statuses updated. TALOS97/Flat42/D-label targets remain90/97,20/39,88/95. DNA-CGDM epoch36 and026 eval M18/64 are stale; recordedPIDs absent on audit hostgpu03 only, not an all-node liveness claim. No new training or MD authorized by this audit. Experimental outputs unchanged.'+NL+NL
 p.write_text(text+old)
p=ROOT/'progress.md';s=p.read_text();s=s.replace('All 412 local Markdown links resolve.','All 1,986 local Markdown links across the four index documents resolve; 258 saved macro fields and nine final ablation rows were independently checked.')
if 'Final verification receipt:' not in s:s+=NL+'Final verification receipt: outputs/weekly_work_evidence_20261101_07/VERIFICATION.json; exact timed Slurm/host/process/init commands in audit/. No experiments rerun.'+NL
p.write_text(s)
# Update saved index metadata for these live mutable files.
evidence=json.loads((OUT/'EVIDENCE_INDEX.json').read_text())
emd=(OUT/'EVIDENCE_INDEX.md').read_text()
for e in evidence:
 if e['path'] in [str(ROOT/n) for n in ['progress.md','feature_list.json','session-handoff.md']]:
  q=Path(e['path']);oldsha=e['sha256'];e['sha256']=hashlib.sha256(q.read_bytes()).hexdigest();e['bytes']=q.stat().st_size;e['hash_status']='sha256_recomputed_now';e['mtime_cst']=datetime.fromtimestamp(q.stat().st_mtime,ZoneInfo('Asia/Shanghai')).isoformat()
  if oldsha:emd=emd.replace(oldsha,e['sha256'])
(OUT/'EVIDENCE_INDEX.md').write_text(emd)
(OUT/'EVIDENCE_INDEX.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+NL)
fields=['task_ids','project_path','path','kind','bytes','mtime_cst','hash_status','sha256','roles']
for name in ['EVIDENCE_INDEX.csv','EVIDENCE_INVENTORY.csv']:
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
  for e in evidence:w.writerow({k:'; '.join(e[k]) if isinstance(e.get(k),list) else e.get(k) for k in fields})
readme='''# 2026-11-01–07 工作清单与证据索引

先读 WORKLOG_AND_EVIDENCE_INDEX_ZH.md：按日期列出64条任务记录（含一对重复，63项主题），每项有结果、核对状态、限制和证据入口。筛选时打开 WORK_ITEMS.csv；完整证据在 EVIDENCE_INDEX.md/CSV/JSON。

TIMELINE_ZH.md 保留107个原日志事件；FIGURE_INDEX_ZH.md 链接12个现成图表文件。snapshots/保留整理前的任务表、进度和交接，避免更正覆盖历史。VERIFICATION.json与audit/保存本次核对、Slurm/本机进程查询以及命令起止时间、耗时和退出状态。

这是清单与索引包，不包含全部原始轨迹、权重、缓存拷贝。证据链接使用同一工作区绝对路径，CSV同时保存项目路径。大型文件只索引或引用历史manifest；856个小型证据重算SHA，112条原引用补全或识别为历史远端引用。本次未重跑MD/训练或在线核对GitHub当前状态。

SHA256SUMS.txt验证本包文件，路径相对于Geodiff_fam根目录；它不是所有实验原始数据均被重新校验的声明。
'''
(OUT/'README_ZH.md').write_text(readme)
p=OUT/'WORKLOG_AND_EVIDENCE_INDEX_ZH.md';s=p.read_text();s=s.replace('仓库连续记录中本周最后一条工作记录日期为 11 月 6 日。','整理前的仓库连续记录中，本周最后一条研究工作记录日期为 11 月 6 日。').replace('本次核对时间为 2026-11-07 上午。','本次核对截至 2026-11-07 09:16（北京时间）。');p.write_text(s)
# Final links and package hashes.
link_count=0
for name in ['WORKLOG_AND_EVIDENCE_INDEX_ZH.md','EVIDENCE_INDEX.md','TIMELINE_ZH.md','FIGURE_INDEX_ZH.md']:
 for target in re.findall(r'\]\(<([^>]+)>\)',(OUT/name).read_text()):
  if not target.startswith(('http://','https://')):assert Path(target).exists(),target;link_count+=1
files=[p for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt']
for d in ['snapshots','audit']:
 files += [p for p in sorted((OUT/d).iterdir()) if p.is_file()]
lines=[hashlib.sha256(q.read_bytes()).hexdigest()+'  '+str(q.relative_to(ROOT)) for q in files]
(OUT/'SHA256SUMS.txt').write_text(NL.join(lines)+NL)
for line in lines:
 sha,path=line.split('  ',1);assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==sha,path
archive=OUT.parent/'weekly_work_evidence_20261101_07.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for q in files+[OUT/'SHA256SUMS.txt']:z.write(q,str(q.relative_to(OUT.parent)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),manifest_files=len(lines),zip_entries=len(files)+1,links_checked=link_count,verification_passed=True),ensure_ascii=False))

