import hashlib,json,math,re,subprocess,time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
AUDIT=OUT/'audit';AUDIT.mkdir(exist_ok=True)
TZ=ZoneInfo('Asia/Shanghai')
checks=[]
def load(p):return json.loads(Path(p).read_text())
def record(name,**kw):checks.append(dict(name=name,passed=True,**kw))
# Reconstruct scalar macro metrics independently from saved per-design rows.
metric_count=0
for rel in ['squared_target20m_20261102/comparison.json','covariance_aux20m_20261102/comparison.json','covariance_amplitude20m_20261103/comparison.json','covariance_amplitude_10k_20261103/true_cov/evaluation.json']:
 p=ROOT/'experiments/talos97_rmsf_scalar'/rel;z=load(p)
 arms={z['arm']:z} if 'arm' in z else z
 for name,a in arms.items():
  for group,metrics in a['macro'].items():
   rows=[r for r in a['per_design'] if r['split']==('validation' if group.startswith('validation') else 'train')]
   if 'exclude009' in group:rows=[r for r in rows if r['design']!='6hb_009']
   assert rows,(rel,name,group)
   for k,v in metrics.items():
    if isinstance(v,(int,float)) and all(isinstance(r.get(k),(int,float)) for r in rows):
     actual=sum(r[k] for r in rows)/len(rows)
     assert math.isclose(actual,v,abs_tol=1e-10,rel_tol=1e-10),(rel,name,group,k,actual,v)
     metric_count+=1
  record('macro_reconstruction',source=str(p),arm=name,per_design_rows=len(a['per_design']))
# Check terminal three-A100 summaries against their individual primary outputs.
b=ROOT/'outputs/dna_singleframe_20261106/ablation_3a100_20261106'
c=load(b/'comparison.json');assert c['status']=='complete' and len(c['rows'])==9
protocols={a:load(b/'full'/a/'train/protocol.json') for a in ['eps','eps_skip','v']}
for k in c['matching_keys']:assert len({json.dumps(v[k],sort_keys=True) for v in protocols.values()})==1,k
for a in protocols:
 st=load(b/'full'/a/'train/status.json');su=load(b/'full'/a/'evaluation/summary.json')
 assert st['stage']=='trained' and st['step']==6900 and su['stage']=='complete' and su['checkpoint_step']==6900
 assert (b/'full'/a/'train/final.pt').is_file()
for r in c['rows']:
 su=load(b/'full'/r['variant']/'evaluation/summary.json')['results'][r['design']]
 m=su['generation_metrics'];teacher=next(x for x in su['teacher'] if x['step']==499)
 expected={'terminal_clean_rmse_nm':teacher['clean_rmse_nm_mean'],'terminal_epsilon_rmse':teacher['epsilon_rmse_mean'],'rmsf_rmse_nm':m['rmsf_rmse_nm'],'mean_rms_error_nm':m['mean_rms_error_nm'],'covariance_relative_frobenius':m['local_component_covariance_relative_frobenius'],'spearman':m['spearman']}
 for k,v in expected.items():assert math.isclose(r[k],v,rel_tol=1e-12,abs_tol=1e-12),(r['variant'],r['design'],k)
record('ablation_final_comparison',rows=9,matching_protocol_keys=c['matching_keys'],validation_designs=c['validation_designs'],samples_per_design=8)
# Traceable command receipts: exact command, target, times, elapsed, exit and raw output.
commands=[]
def run(argv,tag,allowed=(0,)):
 begin=datetime.now(TZ).isoformat();clock=time.monotonic()
 p=subprocess.run(argv,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=55)
 result=dict(argv=argv,cwd=str(ROOT),start_cst=begin,end_cst=datetime.now(TZ).isoformat(),elapsed_seconds=time.monotonic()-clock,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,allowed_exit_codes=list(allowed))
 (AUDIT/(tag+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');commands.append(result)
 assert p.returncode in allowed,(tag,p.returncode,p.stderr)
 return p.stdout
host=run(['hostname'],'hostname').strip()
run(['./init.sh'],'harness_init')
run(['sacct','-j','23239,22934,23234,22682,21255,21589,22762,22772,20720,20721,20722,20723,20724,20725,20729,20730,21816,21817,21818,21819,21820,21821,21822,21823,21824,21825,21826,21827','-X','-P','-o','JobID,JobName%30,State,ExitCode,Start,End,Elapsed'],'slurm_terminal_records')
run(['ps','-p','1278978,2596460,2595058,394046','-o','pid,etime,stat,args'],'local_recorded_pids',allowed=(0,1))
# Checkpoint of stale status evidence; no inference about processes on other nodes.
stale=[]
for rel in ['outputs/dna_cgdm_20261104/joint_D_seed11/status.json','outputs/dna_singleframe_20261105/single_design_026_seed11/evaluation_last/status.json']:
 p=ROOT/rel;stale.append(dict(path=str(p),mtime_cst=datetime.fromtimestamp(p.stat().st_mtime,TZ).isoformat(),status=load(p),local_process_host=host))
(AUDIT/'status_snapshots.json').write_text(json.dumps(stale,ensure_ascii=False,indent=2)+'\n')
# Verify all generated work/evidence references and Markdown links.
items=load(OUT/'WORK_ITEMS.json');evidence=load(OUT/'EVIDENCE_INDEX.json');refs=load(OUT/'REFERENCE_RESOLUTION.json')
assert len(items)==64 and len({t['feature_id'] for t in items})==64
assert len(evidence)==1216 and all(Path(e['path']).exists() for e in evidence)
assert not any(r['resolution']=='unresolved_reference' for r in refs)
link_count=0
for name in ['WORKLOG_AND_EVIDENCE_INDEX_ZH.md','EVIDENCE_INDEX.md','TIMELINE_ZH.md','FIGURE_INDEX_ZH.md']:
 text=(OUT/name).read_text()
 for target in re.findall(r'\]\(<([^>]+)>\)',text):
  if target.startswith(('http://','https://')):continue
  assert Path(target).exists(),(name,target)
  link_count+=1
record('catalog_and_links',tasks=64,evidence_entries=len(evidence),resolved_original_references=len(refs),checked_local_markdown_links=link_count)
record('saved_metric_aggregation',numeric_macro_fields_recomputed=metric_count,limitation='Recomputes scalar metrics from saved per-design rows; does not rerun model forward, regenerate labels, validate trajectories, or establish physical validity.')
result=dict(passed=True,as_of_cst=datetime.now(TZ).isoformat(),host=host,checks=checks,command_receipts=len(commands),remote_github_rechecked=False,experiments_rerun=False)
(OUT/'VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))

