# DNA origami sequence Pareto package

Contains the complete per-pool Pareto fronts for 6HB and rectangle origami, short and nick-joined staple topologies, with TOPSIS ranks, scores, four metrics, and the 5′→3′ scaffold sequence in one CSV. It also contains eight TOPSIS-rank-1 SNUPI caDNAno design inputs: each of four structure/topology combinations for VEC and DBS.

Pareto fronts were calculated separately within each 5,000-sequence pool. TOPSIS ranks are within the corresponding front and pool; all four metrics were minimized with equal 0.25 weights after min-max normalization against that topology's 5,000 candidates. The rank-1 choice is one compromise candidate, not a sequence that dominates the rest.

Each design directory includes design.json, sequence-specific design.csv, Input.txt, Default.snp, and sequences.fasta. The JSON holds topology; CSV carries the selected sequence assignment. The CSV scaffold and all staple sequences cover the complete scaffold. Nick-joined means adjacent staples were joined at nicks according to the prepared topology. Candidate calculations do not establish experimental folding yield.

Full front table: `pareto_front_sequences_and_TOPSIS.csv` (1126 rows, eight groupings). Columns include structure, pool, topology, IDs, source, TOPSIS/SAW/KNEE ranks, TOPSIS score, M1-M4, TOPSIS-rank-1 flag, and scaffold sequence.
