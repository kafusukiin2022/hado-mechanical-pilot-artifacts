# Progress

## 2026-10-12 Patent package ZIP upload

- Compressed `outputs/oxdna_prediction_patent_package/` into
  `outputs/oxdna_prediction_patent_package.zip` (12,199 bytes).
- Uploaded it to the HADO artifacts repository as
  `uploads/oxdna_prediction_patent_package.zip`.
- Remote verification passed at commit
  `509bdeff9b383cea2b81d2e517eda8890dcfdfa7`; local and remote Git blobs
  match. SHA-256: `7dc72001d3499332c2c36894b029549cc066801895997ade2f20b734f7df4754`.

## 2026-10-12 oxDNA prediction patent draft package

- Inspected `software.zip` and followed its software-description structure
  (project overview, background, system functions, detailed design, and user
  use) to draft a Chinese invention-patent package for the oxDNA DNA-origami
  prediction model.
- Generated four editable DOCX files under
  `outputs/oxdna_prediction_patent_package/`: specification, claims,
  abstract, and application-information form.
- DOCX ZIP/XML integrity verification passed. Applicant, inventor, address,
  priority, and formal novelty/inventive-step review fields remain explicitly
  marked for completion by the applicant/patent agent.

## 2026-10-12 Strand-colored filtered 3D viewer upload

- Regenerated the standalone HTML so nucleotide colors follow `.top` strand
  IDs; each panel uses at least two colors, with alternating colors as a
  fallback for single-strand inputs.
- Added offline filters for all/train/validation and sorting by final RMSD,
  initial RMSD, RMSD improvement, final OS, OS improvement, or design name.
- Uploaded the revised artifact as
  `uploads/clean76_all_3d_standalone_strand_colored.html` in the HADO
  artifacts repository. Remote `main` is commit `47b048e97727dcfe82b7b63f25db46136f2f68df`.

## 2026-10-12 Standalone embedded 3D conformation HTML

- Added `scripts/generate_standalone_3d_html.py` and generated
  `outputs/clean76_all_3d_standalone.html`.
- The 7.5 MB single file embeds all 76 designs and their initial, final
  reference, and model-prediction coordinates. It uses the HADO-style
  centered/common-scale 3D trajectory rendering in native canvas JavaScript;
  no oxView, server, CDN, or external asset is required.
- Verification passed: the HTML is a standalone doctype document with no
  HTTP/HTTPS references and contains all 76 design payloads.

## 2026-10-12 Clean76 all-design 3D oxView page

- Generated `outputs/oxview_compare_clean76_hidden256_mp4_all_3d/index.html`
  from the completed Clean76 hidden256/mp4 energy-loss run.
- The page includes all 76 designs, each with three 3D oxView panels:
  initial `start.conf`, final reference `md_last.conf`, and model prediction.
- Verification passed: 76 design directories and 76 HTML sections exist;
  representative initial/final/prediction files are present with oxView
  timestep headers, and a local HTTP server returned 200 for the page and a
  prediction configuration.

## 2026-10-12 CodeGraph index refresh

- Rebuilt the CodeGraph index from the current repository root with
  `codegraph index .`.
- Verification passed with `codegraph status .`: 423 files, 6,665 nodes, and
  15,562 edges; the index reports up to date.
- Symbol lookup verification passed with
  `codegraph query DgnnLiteRigidModel --limit 3`.

## 2026-10-03 Codex new overfit probe

- Ran a new local-only five-epoch EBD EGNN overfit on
  `101_50_bp_nicked` using seed `20261003`, hidden width `64`, three layers,
  and 65,536 edge chunking. Outputs are under
  `outputs/codex_egnn_overfit_101_20261003/`.
- The run completed in `28.77 s`; RMSD changed from `33.5531` at the source to
  `33.5228` at epoch 5. This is an overfit/optimization probe only and does not
  establish held-out physical validity.

Compact session continuity record. Detailed historical logs were moved out of
the startup path on 2026-06-17.

## Read This First

- Full pre-slim backup:
  - `backups/harness_2026-06-17_pre_slim/progress.md`
  - `backups/harness_2026-06-17_pre_slim/feature_list.json`
  - `backups/harness_2026-06-17_pre_slim/session-handoff.md`
- Detailed routing index: `docs/harness/HARNESS_ARCHIVE_INDEX.md`
- Keep this file short. Put detailed experiment logs in focused files under
  `docs/harness/` and link them here.

## Current Objective

Primary active objective: improve DNA-origami prediction while keeping EBD as
the main diffusion direction and preserving oxDNA/oxView exportability.

Current experiment logging rule from the user: do not submit any future
experiment to W&B by default. Future runs should be local-only
(`WANDB_MODE=disabled` or `offline`, no `--wandb`) and should record evidence in
`run.log`, `summary.json`, checkpoints, and harness notes. W&B may only be used
again if the user explicitly overrides this rule in the same request.

CodeGraph rule from the user: force CodeGraph for structural exploration and
fix it first if it becomes unusable, to save token-heavy grep/read loops. Current
verification passed on 2026-06-23:
`codegraph status .`, `codegraph query DgnnLiteRigidModel --limit 3`, and
`codegraph query oxdna_energy_loss --limit 5`. The CLI path is usable even if MCP
tools are not hot-loaded.

Pair-node reference update:

- Added a fast metric-mode adjustment in `scripts/ebd_oxdna_shared_rigid_train.py`
  so `rmsd` and `os` are computed against the pair-node reference derived from
  the final oxDNA configuration when `reference_pairs` are available.
- The pair-node representation uses pair centers plus a frame built from the
  pair axis and averaged orientation, while the exported oxDNA `.conf` path
  remains unchanged.
- Added a regression test that confirms pair internal stretching does not
  affect the pair-node RMSD when the pair reference is active.
- Verification passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_sample_metrics_use_pair_node_reference_when_pairs_exist tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_prepare_sample_prefers_explicit_reference_pairs_when_available -v`

oxView showcase update:

- Repointed `outputs/oxview_compare_1000e_showcase/comparison.yaml` to three
  low-nt designs from yesterday's `manual_a100_w3_last_layer_1000e_20260617_203550`
  run.
- The new set is:
  - `11_Nanolett_Burns_Howorka_2013` (`nt=504`, `rmsd=0.8442`, `os=0.9535`)
  - `12_26._Burns_Howorka_ACIE_2013` (`nt=528`, `rmsd=0.9608`, `os=0.9401`)
  - `14_TMFM_Mobile-reporter-unit` (`nt=1479`, `rmsd=18.6191`, `os=0.3257`)
- Regenerated `outputs/oxview_compare_1000e_showcase/index.html` and verified
  the static page still returns HTTP 200 on `127.0.0.1:8001`.

Temporary timing instrumentation update:

- Added and then removed fine-grained timing hooks in
  `scripts/ebd_oxdna_shared_rigid_train.py` to compare the `w3_last_layer`
  path against the `dgnn-physic` GPU-resident probe.
- The paired short diagnostics showed the common `dgnn-lite`/`w3` path is
  materially cheaper in preparation and finalization, while the probe spends
  extra time in `prepare_physical_graph` and `prepare_pair_state`.
- The probe also OOMed during the 5-sample short run while entering the
  heavier physical forward path, so the comparison is based on the logs
  captured before the failure.

Epoch slowdown diagnosis for the GPU4 resident clean75 probe:

- The slow path is the `dgnn-physic` clean75 probe, not the older
  `w3_last_layer_1000e` backbone run.
- The probe prep phase already takes `221.246291s` for 75 samples.
- Training is strictly serial per sample; there is no batch loader that keeps
  the full dataset on GPU.
- The first sample is fast (`0.489143s`), but large designs dominate later:
  `102_3` took `22.995891s`, `105_honeycomb-74-final2` took `61.426148s`,
  and several other large samples sit in the `17-25s` range.
- The main drag is therefore per-sample graph/feature construction plus the
  serial large-sample forward/loss/backward path, not a single bulk CPU->GPU
  transfer.
- Compared with `w3_last_layer_1000e`, this probe uses a heavier physical
  model path and much larger GPU memory footprint, so it is expected to run
  much slower even with the same `stage_samples_on_cpu` behavior.

GPU4 resident probe note:

- A full clean75 GPU-resident probe was launched with `CUDA_VISIBLE_DEVICES=4`
  and `STAGE_SAMPLES_ON_CPU=0`.
- The probe reached `prepare_samples`, entered `epoch=1`, and drove GPU4 to
  about `39.6 / 40 GiB` without OOM.
- The probe did not finish `epoch=1` before the monitoring session timed out,
  so the run ended without a final epoch-complete or OOM verdict.
- Output directory:
  `outputs/local_dgnn_physic_clean75_1000e_gpu4_resident_probe_20260618_161956/`.

Codex/TUI recovery note:

- The `Failed to read thread goal: thread/goal/get failed` TUI error was traced
  to a corrupted local Codex state database under `~/.codex`.
- Current `~/.codex/goals_1.sqlite` was unreadable (`file is encrypted or is
  not a database`) and `~/.codex/state_5.sqlite` had a malformed schema.
- The broken files were preserved under
  `~/.codex/recovery-20260618-160822/` and both databases were restored from
  the last known-good backup at `~/.codex/db-backups/sqlite-1781758990-0/`.
- Post-recovery verification passed:
  `sqlite3 ~/.codex/goals_1.sqlite "PRAGMA integrity_check; select thread_id,goal_id,status,tokens_used from thread_goals;"`
  returned `ok` plus the active thread-goal rows, and
  `sqlite3 ~/.codex/state_5.sqlite "PRAGMA integrity_check;"` returned `ok`.

Latest harness update:

- The DGNN-physic clean75 path now has two useful timing signals:
  - the short timing probe confirmed the first-epoch bottleneck is sample
    specific rather than a silent startup failure;
  - the size-sorted manifest reduced the first 5 training samples from
    `105.542s` to `4.665s`, which makes it the preferred next validation path.
- The sorted probe is still running in
  `outputs/local_dgnn_physic_clean75_sorted_probe_20260618_1345/` and has not
  yet written `summary.json`, but it is now the best candidate for the eventual
  full clean75 run because it keeps the heaviest designs later in the epoch.
- The comparison note is recorded in
  `docs/harness/sorted_manifest_timing_comparison_2026-06-18.md`.
- A separate A100 direct-run check found that the current `ebd` runtime is not
  just missing `LD_LIBRARY_PATH`; it is missing `libcusparse.so.11` itself.
  The host CUDA install only exposes `libcusparse.so.12`, so `torch_sparse`
  cannot initialize in the current environment without a CUDA 11 runtime.

Current DGNN-physic implementation/run:

- Added `model-kind dgnn-physic` in `scripts/ebd_oxdna_shared_rigid_train.py`.
- The physical graph path adds node inputs for base identity, strand/local
  position, strand length, prev/next/end flags, helical phase, box-normalized
  start position, start velocity, and start angular velocity.
- The physical graph path adds typed edge relations:
  `backbone_forward`, `backbone_reverse`, `pair_start`, `pair_final`,
  `pair_formed`, `pair_broken`, `duplex_step`, `candidate_wc`, and `spatial`,
  plus relation one-hot, phase-delta, geometry, and pair-state edge features.
- `DgnnPhysicRigidModel` keeps the rigid-body residual decoder but uses typed
  edge-conditioned message passing with relation embeddings.
- Recent trainer-side work removed Python-side per-edge bottlenecks from the
  pair-assignment helpers. `_pair_classification_loss`,
  `_pair_logit_exclusivity_loss`, `_pair_logit_symmetry_loss`,
  `_pair_logit_sinkhorn_loss`, and `_pair_partner_selection_loss` now use
  tensor-driven group/membership logic instead of deep `tolist()` loops.
- `reference_pair_*` and `reference_helix_step_*` losses in
  `ebd_oxdna/physical_metrics.py` now accept tensor pair indices, which fixed
  the first regression introduced by the vectorized path.
- Root-cause fix: full clean75 preparation initially stalled because
  `_build_physical_graph_edges(...)` unconditionally called `_candidate_wc_edges`
  and did an `O(N^2)` complementary scan on large designs. The physical graph
  now only consumes candidate WC edges already supplied by the explicit
  candidate-edge path; default clean75 physical relations come from topology,
  pair files, and duplex steps.
- Focused verification passed:
  `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli -v`
  ran 48 tests OK.
- Compile and harness startup passed:
  `py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
  and `./init.sh`.
- A CUDA forward/backward probe on A100 GPU0 passed for
  `101_50_bp_nicked`: 102 nodes, 478/552 physical edges depending on candidate
  mode before/after the candidate scan fix, 59 node features, 29 edge features,
  and valid pair logits.
- Single-sample local probe on `101_50_bp_nicked` completed successfully on
  GPU0 without OOM:
  - input: temporary one-row manifest filtered to `101_50_bp_nicked`
  - split: `--split-mode sample --val-fraction 0.0`
  - device: `cuda:0` on idle GPU0
  - epoch count: `1`
  - timings:
    - `prepare_sample`: `2.988869s`
    - `train_sample_total`: `0.499281s`
    - `train_epochs_total`: `0.508107s`
    - `validation_total`: `0.000141s`
    - `final_block_total`: `0.354336s`
  - memory:
    - `cuda_max_allocated_mib`: `159.90283203125`
    - `cuda_max_reserved_mib`: `190.0`
  - outputs:
    - `outputs/local_dgnn_physic_101_50_bp_nicked_probe_20260618_one_sample/summary.json`
    - `outputs/local_dgnn_physic_101_50_bp_nicked_probe_20260618_one_sample/101_50_bp_nicked.conf`
  - conclusion: the probe does not explode on this single sample; the earlier
    failure was a split configuration issue, not GPU memory pressure.
- Single-sample local probe on the largest-`nt` clean75 sample
  `105_honeycomb-74-final2` also completed successfully on `cuda:0`:
  - input: temporary one-row manifest filtered to `105_honeycomb-74-final2`
  - split: `--split-mode sample --val-fraction 0.0`
  - epoch count: `1`
  - timings:
    - `prepare_sample`: `35.070254s`
    - `train_sample_forward`: `1.837452s`
    - `train_sample_loss`: `31.607848s`
    - `train_sample_backward`: `34.080190s`
    - `train_sample_total`: `65.691876s`
    - `train_epochs_total`: `65.825918s`
    - `validation_total`: `0.000204s`
    - `final_metric_total`: `17.724877s`
    - `final_export_total`: `1.430453s`
    - `final_block_total`: `19.801417s`
  - memory:
    - `cuda_max_allocated_mib`: `34798.38574`
    - `cuda_max_reserved_mib`: `38566`
  - W&B summary:
    - `epochs_ran=1`
    - `num_samples=1`
    - `num_train_samples=1`
    - `num_val_samples=0`
    - `train_mean_final_rmsd=28308.45508`
    - `train_mean_final_os=0.00121`
  - outputs:
    - `outputs/local_dgnn_physic_105_honeycomb_74_final2_probe_20260618_one_sample/105_honeycomb-74-final2.conf`
  - conclusion: the largest clean75 sample does not OOM on the A100 path and
    can complete a one-epoch probe, but it is much heavier than
    `101_50_bp_nicked`.
  - command note: the initial launch used a malformed duplicated prefix in the
    `--summary-json` / model-state paths, so the evidence for this run comes
    from stdout and W&B rather than a local `summary.json`.
- Invalid local A100 run:
  `outputs/local_dgnn_physic_clean75_1000e_20260618_115337/` failed before
  epoch 1 because `pair_supervision_edge_mask` was still sized to the
  pre-physical graph edge list. Added a regression assertion that the mask
  length equals `graph_edges.shape[1]` for physical graph preparation.
- Fresh active local A100 run, no sbatch:
  `outputs/local_dgnn_physic_clean75_1000e_20260618_120331/`
  via `jobs/run_dgnn_physic_clean75_1000e_local.sh`, wrapper PID `47764` at
  launch. It uses clean75 75 samples with
  `--split-strategy nt-stratified --val-fraction 0.2 --seed 1`, therefore
  60 train / 15 validation. That older run was stopped after it proved to be
  the pre-vectorization path. The current local probe is
  `outputs/local_dgnn_physic_clean75_probe_20260618_1230/` and has already
  reached `epoch=1` with `timing phase=train_epochs_total seconds=62.282943`
  and `timing phase=final_block_total seconds=33.749972`. Its `summary.json`
  is written and the final `.conf` exports were produced, so the current code
  path is now exercising full training/validation/finalization instead of
  stalling before the first epoch.

Performance diagnostic subtask:

- Clean75 WC-edge ablation on A30 showed the epoch loop itself was not the
  dominant stall; the expensive tail was final per-sample export plus physical
  evaluation after epoch 10.
- The explicit `O(P^2)` hotspot in the trainer is
  `_reference_pair_endpoint_conflict_rate(...)` via `torch.cdist`, but that
  path was already gated off for zero-weight baseline logging during this run.
- A low-risk acceleration was applied: final validation/export now runs under
  `torch.inference_mode()` instead of plain autograd-disabled mode. This does
  not change training content.
- A dedicated A30 1-epoch timing probe with `--debug-phase-timing` confirmed
  the same shape:
  - `prepare_samples`: `169.928937s`
  - `train_epochs_total`: `186.402701s`
  - `validation_total`: `8.835822s`
  - final sample export/realization was still running for many minutes after
    those phases and was emitting `.conf` files one by one, so the long tail is
    in sample-by-sample finalization rather than the core epoch loop.
- A smaller 3-sample A30 probe finished and pinned the tail more precisely:
  - `final_forward_total`: `0.283511s`
  - `final_metric_total`: `92.452809s`
  - `final_export_total`: `1.785381s`
  - `final_realized_total`: `0.000013s`
  - `final_block_total`: `94.548954s`
  - Conclusion: the expensive part of finalization is physical metric
    computation, not file writing or the forward pass.

Current active experiment family:

- Full clean75 60/15 nt-stratified WC-edge mode ablation on direct A100
  GPUs, no Slurm.
- Manifest with pair labels:
  `outputs/manifests/nupack_2e6_2000_all_clean75_with_pair_labels.json`
- Main harness notes:
  - `docs/harness/physical_rules_clean75_ablation_2026-06-17.md`
  - `docs/harness/wc_edge_mode_ablation_clean75_2026-06-17.md`
- Main output root:
  `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/`
- Reference-pair source audit completed on 2026-06-18:
  - `scripts/audit_reference_pair_sources.py`
  - `docs/harness/reference_pair_source_audit_clean75_2026-06-18.md`
  - `outputs/reference_pair_source_audit_clean75_20260618/report.json`
  - Current clean75 pair-labeled manifest has 75 entries with
    `start_pair_file` and `final_pair_file`, but 0 entries with
    `cadnano_json`/`virt2nuc`; therefore the F1 reference pairs for this
    manifest are geometric proxy labels, treated in the audit as coming from
    the generated `final_pair_file`.
  - Node-partner scan over 7,696,502 audited pairs found
    `prepared_vs_final_pair_file_node_scan.mean_reference_pair_recall = 1.0`
    and 0 unmatched reference nodes.
- Trainer pair-assignment metrics now also emit decoded-pair node-partner scan
  fields for future summaries:
  - `decoded_pair_node_scan_matched_pair_count`
  - `decoded_pair_node_scan_unmatched_reference_pair_count`
  - `decoded_pair_node_scan_unmatched_reference_node_count`
  - `decoded_pair_node_scan_extra_predicted_node_count`
  - `decoded_pair_node_scan_reference_pair_recall`
  - `decoded_pair_node_scan_reference_node_recall`
  Existing completed `summary.json` files predate this addition and only have
  the older aggregate decoded-pair F1/precision/recall fields.
- The four completed clean75 WC-edge ablation summaries were checked with a
  partner-lookup-equivalent recomputation script:
  `scripts/recompute_old_wc_f1_partner_lookup.py`.
  Because the old runs did not save decoded edge lists or checkpoints
  (`save_model_state=None`, `save_best_model_state=None`), a strict old-edge
  rescan is not possible from saved artifacts. Reconstructing matched counts
  from saved per-sample aggregates gives exactly the same per-sample mean F1
  as the old metric for all four rows (`max_abs_f1_delta=0`). Best validation
  F1 remains `readout_only = 0.945814517443`.
  Evidence:
  `docs/harness/old_wc_f1_partner_lookup_check_2026-06-18.md`,
  `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/partner_lookup_recomputed_f1.json`,
  `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/partner_lookup_recomputed_f1.csv`.
- The saved 1000-epoch manual A100 W3 last-layer run at
  `outputs/manual_a100_w3_last_layer_1000e_20260617_203550/` contains all 75
  predicted `.conf` files plus `model_state.pt` and `best_model_state.pt`.
  A geometry-derived pair F1 pass was run from the saved target/prediction
  configurations using the same physical-metrics greedy pair matching and a
  node partner lookup comparison:
  `scripts/compute_geometry_partner_f1_from_run.py`.
  Results:
  train mean F1 `0.426192328379`, validation mean F1 `0.305586237991`.
  Runtime was `455.460988s`. Only 1/75 geometry-derived target pair counts
  exactly matched the old summary `final_pair_count`, so this result should be
  interpreted as a fresh configuration-derived geometric pairing F1 rather
  than the old pair-logit assignment F1.
  Evidence:
  `outputs/manual_a100_w3_last_layer_1000e_20260617_203550/geometry_partner_f1.json`,
  `outputs/manual_a100_w3_last_layer_1000e_20260617_203550/geometry_partner_f1_summary.csv`,
  `outputs/manual_a100_w3_last_layer_1000e_20260617_203550/geometry_partner_f1_samples.csv`.

Background run requested by the user:

- A detached Slurm launcher has been added for a fresh `w3_last_layer`
  1000-epoch run with W&B enabled and final-only pair matching aggregation.
- Launcher path:
  `jobs/geodiff_fam_wc_edge_mode_last_layer_1000e.slurm`
- The launcher uses the pair-labeled clean75 manifest and writes to
  `outputs/slurm/` so the job survives disconnects from the current Codex
  session.
- The trainer now includes `summary/train_mean_decoded_pair_f1` and
  `summary/val_mean_decoded_pair_f1` in the final W&B summary payload.
- Slurm submission attempted for job `430317`, but it is pending with
  `AssocGrpJobsLimit`, so the detached run has not started executing yet.
- Built a YAML-driven oxView comparison generator at
  `scripts/generate_oxview_comparison.py` and used it to create a reusable
  three-design page under
  `outputs/oxview_compare_krishnan_yang_honeycomb_20260617/`.
- The current comparison page covers:
  `16_Krishnan_T_Pore_Nat_Comm_2016`,
  `233_Yang20220916`,
  `105_honeycomb-74-final2`.
- The page is driven by
  `outputs/oxview_compare_krishnan_yang_honeycomb_20260617/comparison.yaml`
  so future visualizations can be generated by editing config instead of
  hand-editing HTML.
- The same YAML-driven page now also includes the retained
  `triangle_repaired_tacoxdna_a30_3000k` 3e6 MD row as a reference-only
  visualization using its existing `triangle.top`, `start.conf`, and
  `md_last.conf`; no retraining or model prediction file was added for that
  row.

## Active Runs To Check

As of `2026-06-17 14:50 CST`, direct A100 clean75 WC-edge mode ablation runs
were active under `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/`:

- `baseline_no_wc`: PID `37728` on GPU4; 10 epochs printed, in final eval/export.
- `w1_message_all`: PID `37732` on GPU5; epoch 2 printed.
- `w2_readout_only`: PID `37736` on GPU6; epoch 2 printed.
- `w3_last_layer`: PID `37839` on GPU7; epoch 2 printed.

No `summary.json` files existed at that check. Baseline had written two `.conf`
exports; WC rows had not written `.conf` files yet.

The prior pre-KD-tree final-eval runs are invalid for the final comparison.
They completed training but stalled in final physical evaluation/export before
writing `summary.json`; because the run command did not request
`--save-model-state` or `--save-best-model-state`, there was no checkpoint to
reuse after the `physical_metrics.py` KD-tree fix. The safe comparison path was
to relaunch all four rows with the fixed code and identical 10-epoch settings.

## Standing Technical Decisions

- EBD is the primary architecture for hierarchical endpoint diffusion.
- DGNN-lite is not an EBD diffusion model. Use it only for diagnostics,
  ablations, or post-EBD correction unless the user explicitly changes course.
- Prediction outputs must remain convertible to oxDNA `.dat`/`.conf` and open
  in oxView. See `docs/OXDNA_OUTPUT_SPEC.md`.
- Explicit cadnano-derived reference pairs are available for the current
  clean75 datasets and should be preferred over geometric greedy reference
  construction.
- Small3 unified-split ablation on 2026-06-17 found that adding candidate
  Watson-Crick edges directly into ordinary coordinate message passing caused
  the largest RMSD/OS regression before pair losses were enabled. Keep
  coordinate training and physical pairing realization staged unless testing an
  explicit ablation.

## GPU And Scheduling Rules

- Do not submit high-memory EBD/oxDNA jobs to `gpu29`.
- Prefer A6000 or A100 for large EBD/oxDNA memory probes and long overfit runs.
- Current project rule details are in `AGENTS.md`.

## Recent Verification Evidence

Latest relevant verified changes from the pre-slim record:

- H100 DGNN-lite start probe on `gpu24` failed in the current `ebd` conda
  environment because PyTorch `1.8.1+cu111` supports CUDA architectures only
  through `sm_86`, while H100 is `sm_90`. Evidence:
  `outputs/manual_h100_dgnnlite_small3_start_probe_20260617/run.log` reports
  `RuntimeError: CUDA error: no kernel image is available for execution on the
  device` at `torch.mean(...)` during sample preparation; a direct
  `DgnnLiteRigidModel` CUDA forward/backward smoke failed with the same kernel
  image error during CUDA tensor initialization. Use A100/A6000 with this env,
  or install a newer PyTorch/CUDA stack before using H100.
- `scripts/build_pair_label_manifest.py` and
  `tests/test_build_pair_label_manifest.py` were added and tested.
- Generated clean75 pair-label manifest with 75 entries and 0 missing pair
  files:
  `outputs/manifests/nupack_2e6_2000_all_clean75_with_pair_labels.json`
- Added `scripts/audit_reference_pair_sources.py` and
  `tests/test_audit_reference_pair_sources.py`; verified the O(N) node-partner
  scan path and ran it on the clean75 pair-labeled manifest. The audit command
  used `--trust-final-pair-file-for-geometric-proxy` because this manifest has
  no cadnano/virt2nuc explicit pair source and its pair labels were generated
  from target `.conf` geometry by `scripts/build_pair_label_manifest.py`.
- Extended `_pair_assignment_metrics(...)` with decoded-pair node-partner scan
  fields and added a regression test for partially matched decoded pairs.
- WC-edge ablation runtime fixes were made in
  `scripts/ebd_oxdna_shared_rigid_train.py` to skip zero-weight physical losses
  and avoid dense conflict logging when disabled. See `session-handoff.md` for
  exact commands and PIDs.
- Current performance diagnosis on the clean75 A30 WC-edge runs:
  - `w1_message_all` completed 10 epochs and wrote `summary.json`.
  - Its `summary.json` reports `elapsed_seconds=4440.637263298035` for 75
    samples and 10 epochs.
  - The first exported `.conf` in that run was written at `15:10:17`, while the
    final `summary.json` landed at `15:53:43`, so the long tail was final
    per-sample export plus physical evaluation, not the epoch loop itself.
  - `nvidia-smi` during diagnosis showed A30 GPUs with low-to-moderate
    utilization while the job was in the tail, consistent with a CPU-heavy
    post-processing bottleneck rather than a sustained GPU-bound training
    bottleneck.
  - The current run did not exercise the dense `torch.cdist` fallback as the
    main slowdown; the slowdown came from sample-by-sample finalization.
  - Verification: `py_compile` passed for the trainer after the inference-mode
    change. The targeted CLI regression test was still running at the time of
    the last check.
- Complexity assessment completed for the oxView-aligned final pairing path:
  - `docs/reports/WC_PAIRING_COMPLEXITY_ASSESSMENT_2026-06-17.md` records the
    conclusion that the full evaluation path is not honestly reducible to
    strict `O(N)` in the general case.
  - KD-tree already covers candidate-pair discovery in
    `ebd_oxdna/physical_metrics.py`, so the correct improvement target is the
    local candidate-search component, not a blanket claim that the entire
    pairing metric becomes linear.
  - The remaining evaluators still need relational, candidate-aware work to
    preserve agreement with oxView-style `last.conf` pairing judgment.
  - The explicit all-pairs cross-strand repulsion branch in
    `scripts/ebd_oxdna_shared_rigid_train.py` was rewritten to use a
    KD-tree-based `margin` neighborhood query via
    `_cross_strand_neighbor_pairs(...)`.
  - Regression tests now cover the new neighbor helper and the existing
    assignment-realized / reference-pair-frame CLI paths still pass.
- Full details are in
  `docs/harness/physical_rules_clean75_ablation_2026-06-17.md`.

## Where To Put Future Updates

- Update this file only with current status, blockers, latest evidence, and
  links to focused records.
- Put long experiment logs in `docs/harness/<topic>_<date>.md`.
- Put machine-readable results under `outputs/`.
- If a detailed historical question arises, start with
  `docs/harness/HARNESS_ARCHIVE_INDEX.md`, then use the pre-slim backup only if
  the focused docs are insufficient.


## 2026-06-18 DGNN-physic diagnostic update

- The earlier local 1000e clean75 run on GPU0 was killed after remaining in a long pre-epoch phase without writing an epoch line or summary.
- Added `faulthandler.enable(all_threads=True)` to `scripts/ebd_oxdna_shared_rigid_train.py`.
- Added `PYTHONFAULTHANDLER=1` and `--debug-phase-timing` to `jobs/run_dgnn_physic_clean75_1000e_local.sh`.
- Validation passed: `py_compile` for the trainer, `bash -n` for the runner, and `--help` shows `--debug-phase-timing`.
- Next step: relaunch a short local probe with the updated script to capture phase timing before resuming the full 1000e run.


## 2026-06-18 Probe Timing Update

- The latest local DGNN-physic probe on GPU0 completed `prepare_samples` in `145.153738s` and `start_metrics` in `0.444650s`, but did not reach `epoch=1` while the machine was still busy with other A100 jobs.
- The heaviest per-sample prepares were `105_honeycomb-74-final2` at `6.526358s` and `301_eHinge` at `4.503391s`.
- The probe is being stopped so the same diagnostic can be rerun on a less contended A100.

## 2026-06-18 DGNN-physic Probe Refresh

- Relaunched a fresh local probe at
  `outputs/local_dgnn_physic_clean75_probe_diag2_20260618_130700/`.
- Launch wrapper PID was `19074`, shell PID `19076`, and trainer PID `19082`.
- The probe has completed `prepare_samples` and `start_metrics` and is still
  running in the training phase.
- At the latest check, `summary.json` had not been written yet, so final RMSD,
  OS, and physical metrics are still pending for this probe.
- The probe uses the same clean75 nt-stratified 60/15 local A100 setup with
  `--model-kind dgnn-physic`, `--physical-graph`, and the pair/helix
  supervision weights already recorded above.
- Follow-up check: `ps -p 19082` returned no process, so this probe likely
  exited before writing `epoch=1` or `summary.json`. The run log still ends at
  `timing phase=start_metrics seconds=0.444650`, so the current evidence is an
  incomplete startup rather than a verified successful training run.

## 2026-06-18 DGNN-physic Probe Restart

- Started a new local probe because the earlier diag2 probe vanished after
  `start_metrics` without any Python traceback or `summary.json`.
- Current active output directory:
  `outputs/local_dgnn_physic_clean75_probe_idle_20260618_131500/`
- Current wrapper PID is `25978`, trainer PID is `25984`.
- This is the same clean75 local A100 configuration, but the run is being
  re-observed from a fresh start so we can see whether the prior exit was an
  external termination or a reproducible crash in the first training loop.
- No `summary.json` exists yet for this restarted probe.
- Latest check: the restarted probe is still alive after ~300s elapsed, with
  CPU usage still high and the log ending at `timing phase=start_metrics
  seconds=0.454063`. It has not yet reached `epoch=1`, so the prior exit is
  still unclassified but not yet reproduced.
- Resource check at the latest follow-up showed the trainer holding about
  36.6 GiB on GPU0 and running at roughly 100% CPU, which is consistent with a
  heavy first training phase rather than an immediate silent exit.

## 2026-06-18 DGNN-physic First-Epoch Timing Instrumentation

- Added a narrow debug helper `_debug_phase_log(...)` and split the first
  training sample in epoch 1 into `forward`, `loss`, `backward`, `clip`, and
  `step` timing messages when `--debug-phase-timing` is enabled.
- Added regression tests for the new debug-log format in
  `tests/test_ebd_oxdna_shared_rigid_train_cli.py`.
- The first two new helper-format tests pass in the EBD environment.
- Next validation step is to re-run the local clean75 probe and confirm the
  new first-epoch phase logs show up in `run.log`.

## 2026-06-18 DGNN-physic Short Probe Check

- Launched a short background clean75 probe to validate the new first-epoch
  timing instrumentation in a real run:
  `outputs/local_dgnn_physic_clean75_short_probe_timing_20260618_1330/`
- Launch shell PID was `31635`.
- The output log currently contains only the run header and no
  `prepare_samples`/`start_metrics` lines yet, so the short probe has not yet
  demonstrated that the trainer entered the main execution path.
- This makes the background launch itself the next thing to verify, before
  interpreting the absence of timing logs as a model/runtime failure.

## 2026-06-18 DGNN-physic Short Probe Verified

- Relaunched the short probe with a detached process group and confirmed the
  real trainer entered the main path.
- Output directory:
  `outputs/local_dgnn_physic_clean75_short_probe_timing_20260618_1330_v2/`
- First-epoch timing logs now appear in the real clean75 run:
  `train_sample_start`, `train_sample_forward`, `train_sample_loss`,
  `train_sample_backward`, and `train_sample_total`.
- The first sample completed quickly:
  `train_sample_forward=0.360612s`,
  `train_sample_loss=0.427933s`,
  `train_sample_backward=0.081780s`,
  `train_sample_total=0.510561s`.
- The next two training samples were much slower:
  `train_sample epoch=1 id=102_3 seconds=22.541310` and
  `train_sample epoch=1 id=105_honeycomb-74-final2 seconds=58.913882`.
- Conclusion: the new instrumentation works in a real run, and the bottleneck
  is sample-specific training cost rather than a silent failure before the
  first epoch.
- Follow-up log tail shows more slow samples in the same epoch:
  `106_Berlin.1=9.745611s`,
  `10_Langecker_Science_Lipid_Bundle_all_out_correct_adapters_ppo_paper=13.830934s`,
  `130_6_helix_bundle=18.917164s`,
  `132_square=17.358552s`.
- This suggests the first-epoch cost is dominated by a subset of clean75
  designs rather than a uniform per-sample overhead; the next useful step is to
  inspect whether the manifest order or sample-specific graph size is driving
  the slowdown.

## 2026-06-18 Clean75 Size-Sorted Manifest

- Built a reordered manifest for probing first-epoch cost by sorting clean75
  samples by nucleotide count using `load_oxdna_sample(...)`:
  `outputs/manifests/nupack_2e6_2000_all_clean75_with_pair_labels_sorted_by_atoms.json`
- The smallest sample in this ordering is `101_50_bp_nicked` with 102
  nucleotides, and the largest is `105_honeycomb-74-final2` with 45272
  nucleotides.
- This manifest is only for probing training order effects; the original
  clean75 manifest is left unchanged.

## 2026-06-18 Sorted-Manifest Probe

- Launched a detached clean75 probe using the size-sorted manifest:
  `outputs/local_dgnn_physic_clean75_sorted_probe_20260618_1345/`
- The run has reached the trainer and is preparing samples in sorted order,
  with smaller designs appearing first.
- This probe is the direct comparison case for the original manifest-order
  run; once it reaches `epoch=1`, the first-epoch timing can be compared
  against the unsorted probe to see whether ordering reduces startup/training
  wall time.
- Comparison update from the log tails:
  - first 1 training sample: unsorted `0.511s`, sorted `0.492s`
  - first 5 training samples: unsorted `105.542s`, sorted `4.665s`
  - first 10 training samples: unsorted `161.642s`, sorted `27.263s`
  - first 20 training samples: unsorted `337.755s`, sorted `176.099s`
- The sorted manifest therefore materially reduces early-epoch wall time by
  avoiding the heaviest designs at the front of the epoch.
- Detailed comparison notes were recorded in
  `docs/harness/sorted_manifest_timing_comparison_2026-06-18.md`.
- Status update: the sorted probe is still running and has progressed well
  past the earliest epoch samples, but it has not yet written `summary.json`.
  The run remains the best candidate for the eventual full clean75 validation
  path because it keeps the heavy designs later in the epoch.

## 2026-06-18 Sorted-Manifest Live Status

- Verified live run state:
  - process `36977` is still active for
    `outputs/local_dgnn_physic_clean75_sorted_probe_20260618_1345/`
  - `summary.json` is still absent
  - the log has reached `epoch=1` and is now deep into the first training
    epoch
- The log confirms the run is healthy enough to proceed past startup and sample
  preparation, so the remaining question is now purely outcome quality and
  total runtime, not whether the DGNN-physic path can enter training.
- Keep watching this run for a finished `summary.json`; when it lands, record
  train/val RMSD, OS, decoded-pair metrics, and any oxDNA export issues.

## 2026-06-18 Sorted-Manifest Epoch-2 Status

- The same live run is still active and has now completed the full `epoch=1`
  pass, with `epoch=2` already underway in the log.
- The `epoch=1` timing profile remains the key validated signal:
  the heavy samples are clustered late, and the size-sorted manifest keeps the
  first-epoch startup cost bounded enough to make long clean75 runs plausible.
- There is still no `summary.json`, so no claim about final quality or oxDNA
  exportability has been made yet.

## 2026-06-18 Sorted-Manifest Epoch-2 Deep Status

- The live run remains active; the log has advanced further into `epoch=2`
  and is still producing per-sample timing entries.
- No new failure mode has appeared. The run still looks like a valid long clean75
  training job rather than a stalled startup or broken export path.
- Until `summary.json` lands, the only verified claims are:
  - the DGNN-physic clean75 path trains end to end past the first epoch
  - manifest ordering materially improves early-epoch wall time
  - the final RMSD/OS and oxDNA export quality are still unverified

## 2026-06-18 Sorted-Manifest Epoch-2 Late Status

- Latest live evidence still shows the run progressing normally in `epoch=2`;
  the most recent log entries are still per-sample timing lines rather than a
  finalization block.
- The probe remains useful as a long-run sanity check for the current
  `dgnn-physic` implementation, but it is not yet sufficient for a completion
  claim.
- Continue waiting for `summary.json` before making any statement about
  validation quality, RMSD, OS, or oxDNA exportability.

## 2026-06-18 Sorted-Manifest Epoch-2 Still-Running Status

- No output file changes yet; `summary.json` is still missing and the process
  remains alive.
- The current evidence still only supports a live training-status update, not a
  completion claim.
- Keep the harness focused on the final summary and exported oxDNA artifacts
  once the run ends.

## 2026-06-18 Sorted-Manifest Epoch-2 Checkpoint Status

- The probe is still alive and still logging `epoch=2` sample timings.
- No final checkpoint artifact has landed in the output directory yet.
- The only verified progress remains:
  - physical node / typed-edge DGNN-physic support is implemented
  - sorted clean75 probing materially reduces early epoch wall time
  - the current long-run validation has not finished, so quality remains unverified

## 2026-06-18 Sorted-Manifest Ongoing Checkpoint Status

- The run remains active at the time of this check, with no `summary.json` and
  no terminal artifact to inspect.
- There is still no evidence that the model has reached the end of the full
  1000-epoch clean75 run; only the early-epoch timing behavior is verified.
- Keep the harness on the existing live probe until a real result file appears.

## 2026-06-18 Sorted-Manifest Continued Live Status

- The probe is still running after repeated checks, and the output directory
  still contains only the live training log.
- The current evidence remains consistent with a long-running clean75 job, but
  not with a completed validation run.
- Do not infer final performance or export quality until the trainer writes
  `summary.json` and the exported oxDNA artifacts are present.

## 2026-06-18 Sorted-Manifest Repeat Live Status

- The run continues to emit epoch-2 sample timings and has not transitioned to
  finalization.
- There is still no `summary.json`, so the objective cannot be considered
  verified.
- Keep the next check focused on the appearance of the summary and exported
  `.conf`/oxDNA outputs, not on the already-validated timing behavior.

## 2026-06-18 Sorted-Manifest Still-Live Status

- The probe remains active after another check; the process table still shows
  the trainer running and the output directory still lacks a summary.
- No new evidence has appeared to support completion or final metric review.
- This is still only a progress update for the harness, not a completion claim.

## 2026-06-18 Sorted-Manifest Persistent Live Status

- Another check again shows the same state: live trainer, no summary, no final
  oxDNA artifact.
- The current objective is still open, and only the timing/ordering diagnosis
  is verified so far.
- Do not move the harness to done until the run actually writes its summary and
  exported outputs.

## 2026-06-18 DGNN-Physic OOM Fix

- The clean75 OOM was traced to the final pair-logit head building a full
  `final_edge_inputs` tensor for all edges at once after message passing.
- Replaced the final pair-head evaluation in both `DgnnLiteRigidModel` and
  `DgnnPhysicRigidModel` with chunked pair-logit computation so the same
  semantics can run with a lower peak activation footprint.
- Added a regression test that checks chunked pair-head logits match the
  one-shot logits on a toy tensor case.
- Verified locally with:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_chunked_pair_head_logits_matches_full_logits tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_dgnn_physic_forward_uses_typed_edge_features -v`
- Next step is to rerun the clean75 local A100 probe and confirm the OOM is
  gone before reading any metrics from the run.

## 2026-06-18 DGNN-Physic Graph Cache Direction

- User wants prepared graph data cached to `.pt` so graph conversion does not
  have to rerun on every launch.
- Best cache boundary: the prepared sample bundle returned by `_prepare_sample(...)`
  before training starts, not the raw manifest or the model forward path.
- Cache invalidation should be explicit through a cache key that includes the
  manifest entry fingerprint plus a `cache_version` field, so any change in
  graph-construction logic can force fresh `.pt` generation.
- `scripts/ebd_oxdna_diffusion_train.py` already uses this disk-cache pattern
  for prepared samples, so that file is the reference implementation to mirror.
- Current waiting condition for the active clean75 probe: the short chunked
  probe must pass the previous pair-head OOM point and write a valid
  `summary.json`; only then should the full clean75 local A100 run be relaunched.
- Implementation status: added `--sample-cache-dir` and `--cache-version` to
  `scripts/ebd_oxdna_shared_rigid_train.py`, wrapped `_prepare_sample(...)`
  with a `.pt` disk cache helper, and verified that the second call reuses the
  cached file even when `_prepare_sample` is patched to fail.
- The local clean75 runner now passes `--sample-cache-dir` and `--cache-version`
  by default so the cached graph bundles are used automatically on full local
  A100 runs.
- Verification evidence:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_prepare_sample_with_cache_reuses_disk_pt -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_prepare_sample_prefers_explicit_reference_pairs_when_available -v`
- Current live-run status: the short chunked probe at
  `outputs/local_dgnn_physic_clean75_short_chunked_probe_20260618_1442/`
  is still running and has not yet produced `summary.json`.
- Follow-up probe update: a new launch was started with a fixed launcher log
  path and an explicit output directory so the run can be observed directly.
  The first restart failed during sample-cache key construction because the
  cache key tried to `stat()` missing optional reference files from the
  manifest. That was fixed by making cache fingerprints tolerant of missing
  optional paths.
- The latest short probe at
  `outputs/local_dgnn_physic_clean75_short_probe_20260618_1505/` now creates
  its output directory and `run.log`, but it still exits before reaching
  `summary.json`; the startup chain is now visible, which is better than the
  previous opaque run, but the validation condition is still unmet.
- Full clean75 local run update:
  `outputs/local_dgnn_physic_clean75_1000e_20260618_151033/` is actively
  preparing samples and now emits per-sample `prepare_sample` timings into
  `run.log`. The new `sample_cache/` directory is populated with `.pt`
  bundles, so the requested pre-caching path is now real rather than just
  wired in code.
- Live status on the same run: the python process is still present and the log
  continues to append later `prepare_sample` entries, so this is a real active
  training job rather than a dead launch. It still has not reached
  `epoch=1` or written `summary.json`.

## 2026-06-18 Harness Record

- Key progress to preserve for restartability:
  - `dgnn-physic` on clean75 is now fully instrumented with physical node and
    typed-edge inputs.
  - The first-epoch timing problem is understood well enough to prioritize
    manifest ordering rather than chasing a startup crash.
  - The sorted-manifest run is the current active probe to watch for
    `summary.json` and clean75 validation metrics.
- Evidence links:
  - `docs/harness/dgnn_physic_clean75_2026-06-18.md`
  - `docs/harness/sorted_manifest_timing_comparison_2026-06-18.md`

## 2026-06-22 Course Paper Package

- Generated a Chinese course-paper package from `outputs/manual_a100_w3_last_layer_1000e_20260617_203550`, using the Truong-Quoc et al. Nature Materials DNA-origami GNN paper as cited technical inspiration without copying its text.
- Deliverable directory copied to the user-requested location:
  `/home/lijingjing/lijj/users/lht2/deeporigami/agent/docs/dna_origami_gnn_course_paper_20260622/`.
- Main outputs:
  - `course_paper.pdf` and `course_paper.tex`
  - paper_factory-style figures under `figures/`
  - metric tables under `tables/`
  - oxView comparison page at `oxview/index.html`
  - reproducible asset generator `generate_course_paper_assets.py`
- Key reported evidence: 75 samples, 60/15 train/val split, 1000 epochs, train mean final RMSD 2.59 / OS 0.832, validation mean final RMSD 16.51 / OS 0.508, train geometry partner F1 0.426, validation geometry partner F1 0.306.
- Verification passed:
  - `python3 docs/dna_origami_gnn_course_paper_20260622/generate_course_paper_assets.py`
  - `pdflatex + bibtex + pdflatex + pdflatex` in the paper directory, producing `course_paper.pdf` with only overfull hbox warnings from long paths/labels.
  - `python3 -m json.tool feature_list.json >/dev/null && ./init.sh`
  - HTTP 200 for target-location oxView page, viewer, and `/oxdna-viewer/` on `127.0.0.1:8002`.

## 2026-06-22 Clean75 Duplex-Retention Local Goal

- User goal: run clean75 locally on an idle A100 without Slurm, train/val split 60/15, and track `RMSD -> 0`, `OS -> 1`, and `duplex_step_retention -> 1`.
- Execution rule: first prove the local run can exceed 10 epochs in reasonable time; if so, launch a 2000-epoch W&B online run and keep monitoring until there is a terminal result or a real blocker.
- Current metric update: added `duplex_step_retention` to `ebd_oxdna/physical_metrics.py` as the retained fraction of reference duplex steps whose pair distances, step distance, and step axis remain within tolerance.
- Verification passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_physical_metrics.PhysicalMetricsTest.test_wc_helix_metrics_detect_reference_pairs_and_rules -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_physical_metrics -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile ebd_oxdna/physical_metrics.py tests/test_physical_metrics.py`
- TUI goal database note: `create_goal` failed because `~/.codex/goals_1.sqlite` is still malformed (`database disk image is malformed`). The durable goal state is therefore recorded in this harness instead of Codex thread-goal state.
- GPU selection at start: node `gpu03`; GPU0 busy, GPUs 1-7 idle. Use `CUDA_VISIBLE_DEVICES=1` for the local probe.

## 2026-06-22 Clean75 Duplex Probe Runtime Update

- The first fixed GPU2 probe reached W&B online at
  `https://wandb.ai/hbjzhxlxx-/deeporigami/runs/s3r09u2y` and passed
  `start_metrics`, confirming the pair-node/electrostatic CUDA assert was fixed.
- That probe was intentionally stopped during epoch 1 because
  `reference_nonpair_repulsion_loss` made `237_8hb_0ab_0f` take `267.833702s`
  for one training sample, which is not reasonable for a 2000-epoch run.
- Root cause: `reference_nonpair_repulsion_loss` enumerated all cross-strand
  non-reference pairs in nested Python loops and built an autograd list. With
  `--nonpair-repulsion-loss-weight 0.001` enabled, clean75 entered an O(N^2)
  Python path during every training sample.
- Fix: `ebd_oxdna/physical_metrics.py` now computes nonpair repulsion in
  chunked tensor form, preserving the same rule: only cross-strand,
  non-reference pairs contribute, and only margin violations are penalized.
- Verification after the nonpair fix passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_physical_metrics -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile ebd_oxdna/physical_metrics.py scripts/ebd_oxdna_shared_rigid_train.py`
- Current active replacement probe:
  - wrapper PID `46275`, Python PID `46299`
  - GPU: `CUDA_VISIBLE_DEVICES=2`
  - output dir:
    `outputs/local_clean75_duplex_12e_20260622_nonpairvec_12e_gpu2/`
  - command path: `jobs/run_clean75_duplex_local.sh`
  - status at launch: preparing all clean75 samples, not yet past 10 epochs.

## 2026-06-22 Clean74 2000e W&B Submission

- User revised the execution target after clean75 OOM evidence: remove
  `105_honeycomb-74-final2` and submit a clean74 2000-epoch W&B run directly.
- Additional OOM finding:
  - The clean75 GPU2 12e probe reached late epoch 1 but OOMed after
    `301_eHinge_7x2` with `reference_nonpair_repulsion_loss`.
  - Root cause was twofold:
    1. `scripts/ebd_oxdna_shared_rigid_train.py` stored non-detached training
       tensors in `epoch_parts`, retaining each sample graph until epoch end.
    2. `105_honeycomb-74-final2` is still too large for the all-cross-strand
       nonpair repulsion loss on a 40GB A100.
  - Fix applied for item 1: training log aggregation now stores detached Python
    floats via `_epoch_part_values(...)`; `reference_nonpair_repulsion_loss`
    default chunk size was reduced from 512 to 128.
  - Verification passed:
    `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_epoch_part_values_detaches_training_tensors_for_logging -v`
    and
    `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_physical_metrics -v`
    and
    `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile ebd_oxdna/physical_metrics.py scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`.
- Quick repro evidence:
  - `outputs/local_clean75_duplex_oom_tail5_20260622_detach_gpu5/` ran the
    OOM-tail samples and completed through `301_eHinge_7x2`; it then OOMed on
    `105_honeycomb-74-final2`, confirming that removing 105 is the minimal
    clean74 workaround.
  - `outputs/local_clean75_duplex_105_nonpair0_20260622_gpu5/` completed
    `105_honeycomb-74-final2` when nonpair repulsion was disabled, confirming
    the remaining 105 issue is the nonpair loss rather than the main model path.
- Clean74 manifest created:
  `outputs/manifests/nupack_2e6_2000_all_clean74_no_105_honeycomb_sorted_by_atoms.json`
  with 74 samples.
- Formal W&B run submitted without Slurm:
  - W&B: `https://wandb.ai/hbjzhxlxx-/deeporigami/runs/x4gpylhv`
  - Run name: `clean74-duplex-2000e-20260622_clean74_no105_2000e_gpu5`
  - Output dir:
    `outputs/local_clean74_duplex_2000e_20260622_clean74_no105_2000e_gpu5/`
  - Wrapper PID: `8181`; Python PID: `8208`; session id: `8181`
  - GPU: `CUDA_VISIBLE_DEVICES=5`
  - Status at record time: W&B online run created; sample preparation completed
    in `302.969913s`; process is independent of the current SSH/TUI and is
    running epoch 1.

## 2026-06-22 Course Paper Visualization Update

- Updated the course-paper package in `/home/lijingjing/lijj/users/lht2/deeporigami/agent/docs/dna_origami_gnn_course_paper_20260622/` to include static oxView-style structural projection figures in the PDF, showing initial oxDNA, relaxed target, and model prediction columns.
- Added three structure figures:
  - `figures/fig7_structure_11_Nanolett_Burns_Howorka_2013.pdf`
  - `figures/fig8_structure_14_TMFM_Mobile-reporter-unit.pdf`
  - `figures/fig9_structure_105_honeycomb-74-final2.pdf`
- Expanded shared-literature citations aligned with the Nature Materials reference paper: caDNAno, near-atomic DNA origami analysis, DNA origami review, and graph-learning references.
- Recompiled `course_paper.pdf`; final size is about 1.1 MiB and includes the new structural figures.
- Verification passed:
  - full `pdflatex + bibtex + pdflatex + pdflatex` rebuild, with only overfull hbox warnings from long labels/paths;
  - no `Citation undefined`, fatal LaTeX, or BibTeX errors found by `rg` over `course_paper.log`, `course_paper.blg`, and `course_paper.tex`;
  - HTTP 200 for target oxView page and `/oxdna-viewer/` on `127.0.0.1:8002`.

## 2026-06-22 Course Paper Storyline Expansion

- Expanded the course-paper package to tell the requested series-experiment story: oxDNA export target, EBD/EGNN bridge, DGNN-lite diagnostic route, Watson-Crick/helix physical metrics, pair-rule ablations, clean75 WC-edge mode ablation, and the current stable `w3-last-layer` result.
- Added story-line figures and tables:
  - `figures/fig10_project_storyline_timeline.pdf`
  - `figures/fig11_pair_rule_ablation_tradeoff.pdf`
  - `figures/fig12_wc_edge_mode_ablation.pdf`
  - `tables/table3_storyline.tex`
  - `tables/table4_wc_edge_modes.tex`
- Added appendix evidence lists so the project records survive outside the chat context, including the main output directory `outputs/manual_a100_w3_last_layer_1000e_20260617_203550/` and the key harness notes under `docs/harness/`.
- Recompiled the paper in `/home/lijingjing/lijj/users/lht2/deeporigami/agent/docs/dna_origami_gnn_course_paper_20260622/`; final PDF is 21 pages, letter size, 1,259,272 bytes.
- Synced the full deliverable package back into `docs/dna_origami_gnn_course_paper_20260622/` under the Geodiff_fam workspace.
- Verification passed:
  - `pdflatex -interaction=nonstopmode course_paper.tex && bibtex course_paper && pdflatex -interaction=nonstopmode course_paper.tex && pdflatex -interaction=nonstopmode course_paper.tex && pdfinfo course_paper.pdf | rg 'Pages|Page size'`
  - `rg -n "Citation.*undefined|undefined references|Emergency stop|Fatal error|^!|I couldn't open|Warning--I didn't find" course_paper.log course_paper.blg course_paper.tex || true`
  - `curl -I http://127.0.0.1:8002/docs/dna_origami_gnn_course_paper_20260622/oxview/index.html`
  - `curl -I http://127.0.0.1:8002/oxdna-viewer/`

## 2026-06-23 Course Paper 14-Page Concise Copy

- User requested the earlier shorter course-paper shape because the 21-page version was too verbose.
- No separate old 14-page PDF backup was present; the concise copy was rebuilt from the current LaTeX source without overwriting `course_paper.pdf`.
- Generated `course_pape_14.tex` and `course_pape_14.pdf` in `/home/lijingjing/lijj/users/lht2/deeporigami/agent/docs/dna_origami_gnn_course_paper_20260622/`.
- Synced the same files into `docs/dna_origami_gnn_course_paper_20260622/` under the Geodiff_fam workspace.
- The concise copy removes the added long story-line section, story-line figures/tables, methodology-experience discussion, next-experiment plan, and appendices while retaining the main experiment, metrics, citations, and oxView-style structure figures.
- Verification passed:
  - `pdflatex -interaction=nonstopmode course_pape_14.tex && bibtex course_pape_14 && pdflatex -interaction=nonstopmode course_pape_14.tex && pdflatex -interaction=nonstopmode course_pape_14.tex`
  - `pdfinfo course_pape_14.pdf | rg 'Pages|File size|Page size'` reported 14 pages, letter size, 1,137,590 bytes.
  - `pdfinfo course_paper.pdf | rg 'Pages|File size|Page size'` still reported the original 21-page file, confirming it was not overwritten.
  - `rg -n "Citation.*undefined|undefined references|Emergency stop|Fatal error|^!|I couldn't open|Warning--I didn't find" course_pape_14.log course_pape_14.blg course_pape_14.tex || true` found no fatal or citation errors.

## 2026-06-23 Answer Book DOCX Packaging

- User requested the 14-page paper placed into the graduate course answer-book template and a second copy with course name `智能系统与知识工程`.
- Source template:
  `/home/lijingjing/lijj/users/lht2/deeporigami/agent/docs/dna_origami_gnn_course_paper_20260622/附件5-研究生课程考试答题册.docx`.
- Generated answer-book DOCX files in the user-facing docs directory and synced them back into `docs/dna_origami_gnn_course_paper_20260622/` under Geodiff_fam:
  - `附件5-研究生课程考试答题册-大数据与人工智能基础-14页论文.docx`
  - `附件5-研究生课程考试答题册-智能系统与知识工程-14页论文.docx`
- Implementation note: the environment lacks `pandoc`, `libreoffice`, `python-docx`, and `reportlab`, so the 14-page PDF was rendered to 14 JPEG page images with `pdftoppm` and inserted into the DOCX OpenXML package after the answer-book cover/title content.
- Verification passed:
  - `unzip -t` reported no compressed-data errors for both generated DOCX files.
  - OpenXML inspection of ASCII temp copies confirmed course names `大数据与人工智能基础` and `智能系统与知识工程`.
  - OpenXML media inspection confirmed each generated DOCX embeds 14 `course_pape_14_page_*.jpg` pages.

## 2026-06-22 Clean75 Pair-Node Metric Fix

- Root cause for the 2026-06-22 clean75 GPU2 probe crash: `_sample_metrics(...)` switched `pred_positions` to pair-node coordinates for RMSD/OS, then still passed nucleotide-level `electrostatic_edges` into `_electrostatic_energy(...)`. That made `electrostatic_edges` index beyond the smaller pair-node tensor and triggered the CUDA `IndexKernel` out-of-bounds assert during `start_metrics`.
- Fix: compute electrostatic energy on the original nucleotide-level prediction tensor before the pair-node metric projection. Pair-node projection now affects RMSD/OS only.
- Verification passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_sample_metrics_pair_node_reference_ignores_nucleotide_electrostatic_edges tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_sample_metrics_use_pair_node_reference_when_pairs_exist -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`

## 2026-06-23 oxDNA-Inspired GPU Energy Loss

- Added a DeepSNUPI-style differentiable physics loss in
  `ebd_oxdna/oxdna_energy_loss.py` and wired it into
  `scripts/ebd_oxdna_shared_rigid_train.py` behind zero-default CLI flags.
- Retained from oxDNA as GPU PyTorch surrogate terms:
  backbone distance, bonded stacking orientation/axis, Watson-Crick reference
  pair hydrogen-bond geometry, duplex-step/cross-stack geometry, and
  nonbonded excluded-volume repulsion.
- Deliberately not retained in this first pass:
  external oxDNA binary calls inside training, native force/torque autograd,
  exact oxDNA C++/CUDA parameter tables, FENE/smoothing windows,
  sequence-dependent stacking tables, coaxial stacking, and temperature/salt
  calibration. `compute_wc_helix_metrics` remains sparse/final diagnostics
  rather than per-epoch loss.
- Added CLI/logging/summary flags:
  `--oxdna-energy-loss-weight`, `--oxdna-energy-ramp-epochs`,
  per-term weights, and `--oxdna-energy-excluded-volume-max-pairs`.
- Verification passed:
  - `./init.sh`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_physical_metrics tests.test_oxdna_energy_loss -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_oxdna_energy_loss tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_oxdna_energy_loss_weight_and_history tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_zero_weight_physical_losses_are_not_evaluated -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile ebd_oxdna/oxdna_energy_loss.py scripts/ebd_oxdna_shared_rigid_train.py tests/test_oxdna_energy_loss.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
- GPU runtime check passed on A100 GPU0:
  `outputs/local_oxdna_energy_gpu_1epoch_capped_20260623/summary.json`.
  With `max-samples=1`, `101_50_bp_nicked`, `--oxdna-energy-loss-weight 0.05`,
  the one-epoch run reported `train_epochs_total=0.511959s`,
  `train_sample_loss=0.494449s`, `elapsed_seconds=4.230029`,
  `cuda_max_allocated_mib=2.913574`, and `cuda_max_reserved_mib=4.0`.
- Credibility boundary recorded after user review:
  the current `oxdna_energy_loss` is a differentiable training surrogate, not
  a physically calibrated oxDNA total energy. It can be used to push structures
  away from obvious backbone, base-pair, stacking, duplex-step, and collision
  violations, but its scalar value must not be interpreted as native oxDNA
  energy or thermodynamic stability. Missing first-pass terms include
  sequence-dependent stacking, coaxial stacking, exact oxDNA smoothing/FENE
  forms, and temperature/salt calibration. Before using it as a primary model
  selection criterion, run sparse/final validation by exporting `.conf/.top`
  and comparing surrogate energy against native oxDNA energy/minimization,
  `duplex_step_retention`, WC precision/recall/F1, RMSD, and OS.

## 2026-06-23 Energy-Only Duplex Training Probe

- User decision: old WC/helix/pair-rule metrics and losses should be treated as
  removable scaffolding. The training path should keep RMSD, OS, normal DL
  machinery such as optimizer/scheduler/grad clipping, and the new
  `oxdna_energy_loss` as the duplex-preserving signal.
- Trainer update:
  - added `--enable-legacy-duplex-losses` as opt-in for old pair/WC/helix/
    nonpair losses;
  - added `--compute-final-physical-metrics` as opt-in for slow final
    `compute_wc_helix_metrics`;
  - default final summaries now keep RMSD/OS and set `physical_rule_metrics`
    to `None`, avoiding the multi-minute final metric tail.
- Runtime bug fix before the medium probe:
  excluded-volume sampling no longer allocates full `torch.triu_indices` before
  applying `--oxdna-energy-excluded-volume-max-pairs`; large systems now use
  deterministic GPU pair sampling bounded by the max-pair setting.
- Verification passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_oxdna_energy_loss tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_oxdna_energy_loss_weight_and_history tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_skips_final_physical_metrics_by_default tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_zero_weight_physical_losses_are_not_evaluated -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile ebd_oxdna/oxdna_energy_loss.py scripts/ebd_oxdna_shared_rigid_train.py tests/test_oxdna_energy_loss.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
- 10-medium-sample 30-epoch A100 probe:
  - manifest: `outputs/manifests/clean74_medium10_20260623.json`
  - output: `outputs/local_oxdna_energy_medium10_30e_fastmetrics_20260623/`
  - split: 8 train / 2 val, `--seed 23`
  - weights: `--oxdna-energy-loss-weight 0.05`, ramp 5 epochs,
    `--orientation-loss-weight 1.0`, no legacy duplex losses, no final physical
    metrics.
  - runtime: `prepare_samples=17.008643s`, `train_epochs_total=5.210670s`,
    `validation_total=0.403630s`, `final_metric_total=0.035156s`,
    `final_block_total=4.622593s`, `elapsed_seconds=26.868146`.
  - memory: `cuda_max_allocated_mib=496.316895`,
    `cuda_max_reserved_mib=1092.0`.
  - training history improved from epoch 1 to 30:
    `loss 101.0133 -> 58.5076`, `position_loss 100.1425 -> 57.8486`,
    training-loop `rmsd 15.2160 -> 12.1227`, training-loop
    `os 0.1783 -> 0.5323`, `oxdna_energy_loss 4.9148 -> 3.8244`.
  - final sample summary is mixed:
    train final RMSD improved vs start on average (`14.6103 -> 11.8124`), but
    train final OS decreased under the final pair-node metric path
    (`0.1889 -> 0.1123`); val RMSD worsened (`14.6672 -> 16.5838`) while val OS
    improved (`-0.2941 -> -0.1756`). Best monitored metric was `val/loss` at
    epoch 19 (`88.38009`).
  - conclusion: energy-only training is computationally feasible on medium
    samples after skipping old final metrics, and it improves training loss and
    training-loop RMSD/OS. This 30-epoch 8/2 probe does not yet prove
    validation/generalization improvement.

## 2026-06-23 Active Clean74 Energy-Only 1000e W&B Run

- User requested a background full-clean74 run with validation/train split
  2:8, W&B logging, and 1000 epochs.
- Launched without Slurm on A100 GPU1:
  - wrapper PID at launch: `36829`
  - Python PID: `36832`
  - output dir: `outputs/local_clean74_energy_only_1000e_20260623_gpu1/`
  - runner: `jobs/run_clean74_energy_only_1000e_20260623.sh`
  - manifest:
    `outputs/manifests/nupack_2e6_2000_all_clean74_no_105_honeycomb_sorted_by_atoms.json`
  - W&B:
    `https://wandb.ai/hbjzhxlxx-/deeporigami/runs/0mcl9wcr`
  - W&B name: `clean74-energy-only-1000e-20260623_gpu1`
- Configuration:
  - `--epochs 1000`
  - `--split-mode sample --split-strategy random --val-fraction 0.2 --seed 23`
  - `--model-kind dgnn-lite --shared-hidden-dim 64 --message-passing-steps 1`
  - `--optimizer adamw --learning-rate 0.001 --scheduler cosine_warmup`
  - `--warmup-epochs 25 --min-lr-scale 0.1 --grad-clip 1.0`
  - `--orientation-loss-weight 1.0`
  - `--oxdna-energy-loss-weight 0.05 --oxdna-energy-ramp-epochs 50`
  - `--oxdna-energy-excluded-volume-max-pairs 200000`
  - legacy duplex losses and final physical metrics remain disabled by default.
- Startup evidence:
  `prepare_samples` completed in `110.758965s`; the run created W&B run
  `0mcl9wcr` and reached epoch training. At the last check it was around epoch
  21, using about `10821 MiB` on GPU1 with GPU utilization around `55%`.
- Monitoring commands:
  - `tail -n 160 outputs/local_clean74_energy_only_1000e_20260623_gpu1/run.log`
  - `ps -fp 36832`
  - `nvidia-smi --query-gpu=index,memory.used,memory.free,utilization.gpu --format=csv,noheader,nounits`
- Important follow-up after user clarified pair-node removal:
  this active run was launched before the nucleotide-only cleanup below. Its
  epoch-level RMSD/OS are nucleotide-level, but its prepared graph still
  includes the old appended `candidate_pair_state_features`, and final/start
  `_sample_metrics` in that process still contains the old pair-node projection
  code. Treat W&B run `0mcl9wcr` as pre-cleanup evidence unless it is restarted
  from the updated code.

## 2026-06-23 Nucleotide-Level Cleanup

- User clarified that pair-node details should be removed completely and that
  the model should operate at single-base/nucleotide level, including generated
  graph representation.
- Code changes in `scripts/ebd_oxdna_shared_rigid_train.py`:
  - `_sample_metrics(...)` now always computes nucleotide-level RMSD/OS and no
    longer projects reference pairs into pair-node centers/frames.
  - Default graph edge features no longer append `candidate_pair_state_features`
    (`edge_pair_kept`, `edge_pair_broken`, `edge_pair_formed`,
    `edge_pair_never` removed from model inputs).
  - `physical_graph` relation vocabulary no longer includes pair-start,
    pair-final, pair-formed, pair-broken, duplex-step, or candidate-WC edges;
    it keeps nucleotide-level backbone/spatial relations only.
  - Reference pairs remain available only as interaction indices for
    `oxdna_energy_loss` and optional legacy diagnostics/losses.
- Tests updated to assert nucleotide-level behavior:
  - `_sample_metrics` is now sensitive to within-pair nucleotide displacement.
  - default prepared graphs have zero-width pair-state feature tensors.
  - physical graph no longer injects pair relation edges.
- Verification passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_sample_metrics_stay_nucleotide_level_when_pairs_exist tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_sample_metrics_use_nucleotide_electrostatic_edges_with_pair_references tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_prepare_sample_keeps_default_graph_at_nucleotide_level_without_pair_state_features tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_prepare_sample_adds_physical_node_and_typed_edge_features tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_dgnn_physic_forward_uses_typed_edge_features tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_oxdna_energy_loss_weight_and_history tests.test_oxdna_energy_loss -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py ebd_oxdna/oxdna_energy_loss.py`

## 2026-06-23 Clean74 Nucleotide Energy-Only 10000e W&B Run

- User requested a new latest training run for 10000 epochs and explicitly said not to interrupt the previous run.
- Did not stop any existing process. At recheck the older PID `36832` was already absent and GPU1 had released most memory; no kill/terminate command was issued for it.
- Updated checkpoint behavior in `scripts/ebd_oxdna_shared_rigid_train.py`: whenever the monitored best metric improves, `--save-best-model-state` is written immediately instead of waiting until the end of training. This makes long runs keep a usable best checkpoint if interrupted later.
- Added regression test:
  `tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_writes_best_checkpoint_during_training`.
- Launched new local no-Slurm run on A100 GPU0:
  - wrapper PID: `40141`
  - Python PID: `40142`
  - runner: `jobs/run_clean74_energy_only_nucleotide_10000e_20260623_gpu0.sh`
  - output dir: `outputs/local_clean74_energy_only_nucleotide_10000e_20260623_gpu0/`
  - manifest: `outputs/manifests/nupack_2e6_2000_all_clean74_no_105_honeycomb_sorted_by_atoms.json`
  - W&B: `https://wandb.ai/hbjzhxlxx-/deeporigami/runs/bu9ryu4u`
  - W&B name: `clean74-energy-only-nucleotide-10000e-20260623_gpu0`
  - config: `--epochs 10000`, sample split `--val-fraction 0.2 --seed 23`, `dgnn-lite`, backbone graph, nucleotide-level default graph/metrics, `--oxdna-energy-loss-weight 0.05`, ramp 50 epochs, cosine warmup scheduler, gradient clip 1.0.
- Startup verification:
  - `prepare_samples` completed in `102.035408s`.
  - W&B run `bu9ryu4u` was created.
  - Reached epoch training; epoch 1 logged `loss=236.121539746`, `position_loss=235.190339044`, `orientation_loss=0.917269445072`, `os=0.082730559569`.
  - `outputs/local_clean74_energy_only_nucleotide_10000e_20260623_gpu0/model_best.pt` existed after epoch 1, size about 499 KiB, proving best checkpoint is saved during training.
  - GPU0 was active at the check with about `10783 MiB` used and `61%` utilization.
- Verification passed:
  - `./init.sh`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_writes_best_checkpoint_during_training -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
  - `codegraph sync .`
- Monitoring commands:
  - `tail -n 160 outputs/local_clean74_energy_only_nucleotide_10000e_20260623_gpu0/run.log`
  - `ps -fp 40142`
  - `ls -lh outputs/local_clean74_energy_only_nucleotide_10000e_20260623_gpu0/model_best.pt`
  - `nvidia-smi --query-gpu=index,name,memory.used,memory.free,utilization.gpu --format=csv,noheader,nounits`

## 2026-06-23 Clean76 Nucleotide Energy-Only 10000e W3-Split W&B Run

- User requested stopping the prior clean74 nucleotide 10000e task and
  relaunching with only a small data/split change:
  use the `w3-last-layer-1000e-manual-a100-20260617_203550` split, include
  `105_honeycomb-74-final2`, and add the repaired triangle oxDNA run under
  `/home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/triangle_repaired_tacoxdna_a30_3000k/oxdna_run/`
  into training as clean76.
- Stopped the previous clean74 process by explicit user request:
  Python PID `40142` was terminated; it had reached around epoch `1092`.
- Verified reference split from
  `outputs/manual_a100_w3_last_layer_1000e_20260617_203550/summary.json`:
  `60` train / `15` val, `split_strategy=nt-stratified`, and
  `105_honeycomb-74-final2` is in train, not val.
- Generated clean76 manifest:
  `outputs/manifests/nupack_2e6_2000_all_clean76_with_triangle.json`.
  It contains clean75 plus:
  - id: `triangle_repaired_tacoxdna_a30_3000k`
  - top: `.../triangle_repaired_tacoxdna_a30_3000k/oxdna_run/triangle.top`
  - start: `.../triangle_repaired_tacoxdna_a30_3000k/oxdna_run/start.conf`
  - target: `.../triangle_repaired_tacoxdna_a30_3000k/oxdna_run/md_last.conf`
- Triangle artifact check:
  `triangle.top` exists with first line `16355 209`; `start.conf` and
  `md_last.conf` both have `16358` lines.
- Split used for new run:
  explicit `--val-ids` copied from the w3-last-layer summary:
  `142_LargeTetrascaffold-B-3,146_boat_stretching_sequence_V3,14_TMFM_Mobile-reporter-unit,192_18Helixtube_WithProtruding_5prime,193_Pentagon_mesh_130bp_4HB,194_Hybrid_rod,197_HCeighteen06_42bp,200_R4_Hex,231_18Helixtube_WithProtruding_5prime_extraDNA,243_Gclef,248_nDFS_A,277_4FSF_25_2b_complete_full_loopbackscaffold,280_Ogieva_2025_tail,298_2118_mono,301_eHinge`.
  This yields clean76 `61` train / `15` val; both `105_honeycomb-74-final2`
  and `triangle_repaired_tacoxdna_a30_3000k` are in train.
- New run launched on A100 GPU0:
  - wrapper PID: `43288`
  - Python PID: `43289`
  - runner: `jobs/run_clean76_energy_only_nucleotide_10000e_w3split_20260623_gpu0.sh`
  - output dir: `outputs/local_clean76_energy_only_nucleotide_10000e_w3split_20260623_gpu0/`
  - W&B: `https://wandb.ai/hbjzhxlxx-/deeporigami/runs/rkp1ceyb`
  - W&B name: `clean76-energy-only-nucleotide-10000e-w3split-20260623_gpu0`
- Training method/model intentionally matches the immediately previous clean74
  nucleotide energy-only submission: `dgnn-lite`, hidden dim `64`, one message
  passing step, backbone graph, AdamW `lr=0.001`, cosine warmup, grad clip
  `1.0`, `orientation_loss_weight=1.0`, `oxdna_energy_loss_weight=0.05`,
  energy ramp `50`, excluded-volume cap `200000`, W&B online, best checkpoint
  saved to `model_best.pt`.
- Startup verification:
  - `prepare_samples` completed in `120.684449s`.
  - `105_honeycomb-74-final2` prepared in `4.034392s`.
  - `triangle_repaired_tacoxdna_a30_3000k` prepared in `9.550550s`.
  - W&B run `rkp1ceyb` was created.
  - epoch 1 logged `loss=252.297401585`, `position_loss=251.364604989`,
    `orientation_loss=0.90448109146`, `os=0.0955189099291`.
  - epoch 50 logged `loss=157.6714526`, `position_loss=156.077269069`,
    `orientation_loss=0.615217714036`, `os=0.384782285157`.
  - At final check the run was around epoch `63`, Python PID `43289` was
    alive, GPU0 was active, and `model_best.pt` existed at about `499K`.
- Verification passed:
  - clean76 manifest generated and `python3 -m json.tool` accepted it.
  - split assertion script confirmed `76` samples, `61` train, `15` val,
    no missing val ids, `105_train=True`, `triangle_train=True`.
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
- Monitoring commands:
  - `tail -n 160 outputs/local_clean76_energy_only_nucleotide_10000e_w3split_20260623_gpu0/run.log`
  - `ps -fp 43289`
  - `ls -lh outputs/local_clean76_energy_only_nucleotide_10000e_w3split_20260623_gpu0/model_best.pt`
  - `nvidia-smi --query-gpu=index,name,memory.used,memory.free,utilization.gpu --format=csv,noheader,nounits`

## 2026-06-23 Goal Rule: No W&B for Future Experiments

- User explicitly corrected the experiment policy again: every future
  experiment should not submit to W&B by default.
- User repeated this as a goal-level rule: every experiment must be treated as
  local-only by default; do not submit to W&B unless the user explicitly asks
  for W&B in that same request.
- Persistent rule for this goal:
  - all future training/probe/sweep runs must be local-only unless the user
    explicitly asks for W&B in the same request;
  - local-only runners should set `WANDB_MODE=disabled` or `offline` and should
    not pass `--wandb`;
  - results should be recorded in local logs, `summary.json`, `model_best.pt`,
    and harness notes instead of W&B.
- Corrective action taken immediately:
  - stopped the three mistakenly launched W&B sweep Python processes:
    `46303`, `46309`, and `46312`;
  - left the main clean76 W&B run PID `43289` untouched.
- The stopped sweep output directories are partial/invalid for comparison:
  - `outputs/local_clean76_energy_sweep_capacity128_mp2_energy005_10000e_20260623_gpu2/`
  - `outputs/local_clean76_energy_sweep_energy02_ramp25_10000e_20260623_gpu3/`
  - `outputs/local_clean76_energy_sweep_capacity256_mp3_energy01_10000e_20260623_gpu4/`
- Future clean76 sweeps should be relaunched with local-only logging before
  being treated as evidence.

## 2026-06-23 Clean76 Local-Only Energy Sweeps

- Started three follow-up clean76 nucleotide-level energy sweeps with no W&B:
  each runner exports `WANDB_MODE=disabled`, omits `--wandb`, uses the clean76
  manifest, and keeps the same explicit W3 validation ids as the active clean76
  main run.
- Active local-only runs:
  - GPU4/PID `48837`:
    `outputs/local_clean76_energy_sweep_capacity128_mp2_energy005_10000e_20260623_gpu4_localonly/`;
    runner
    `jobs/run_clean76_energy_sweep_capacity128_mp2_energy005_10000e_20260623_gpu4_localonly.sh`;
    config changes: hidden dim `128`, message passing `2`, energy weight
    `0.05`.
  - GPU5/PID `48966`:
    `outputs/local_clean76_energy_sweep_energy02_ramp25_10000e_20260623_gpu5_localonly/`;
    runner
    `jobs/run_clean76_energy_sweep_energy02_ramp25_10000e_20260623_gpu5_localonly.sh`;
    config changes: energy weight `0.2`, energy ramp `25`.
  - GPU6/PID `48972`:
    `outputs/local_clean76_energy_sweep_capacity256_mp3_energy01_10000e_20260623_gpu6_localonly/`;
    runner
    `jobs/run_clean76_energy_sweep_capacity256_mp3_energy01_10000e_20260623_gpu6_localonly.sh`;
    config changes: hidden dim `256`, message passing `3`, learning rate
    `5e-4`, weight decay `1e-5`, energy weight `0.1`, grad clip `0.5`.
- Launch/debug note:
  - the first background attempts were invalid because they were started before
    the scripts were executable and then without session detachment; their logs
    contain only locale warnings and are not evidence;
  - the active runs were relaunched with `setsid nohup ... </dev/null` and
    `PYTHONUNBUFFERED=1`.
- Startup evidence:
  - GPU4 run reached epoch `53` and wrote `model_best.pt` (`1.9M` at the check);
  - GPU5 and GPU6 were still in `prepare_sample` when recorded;
  - `ps` showed all three active sweep PIDs with `PPID=1`, so they are detached
    from the current shell;
  - command lines contained no `--wandb`.
- Monitoring commands:
  - `ps -o pid,ppid,sid,stat,etime,pcpu,pmem,args -p 48837,48966,48972,43289`
  - `tail -n 120 outputs/local_clean76_energy_sweep_capacity128_mp2_energy005_10000e_20260623_gpu4_localonly/run.log`
  - `tail -n 120 outputs/local_clean76_energy_sweep_energy02_ramp25_10000e_20260623_gpu5_localonly/run.log`
  - `tail -n 120 outputs/local_clean76_energy_sweep_capacity256_mp3_energy01_10000e_20260623_gpu6_localonly/run.log`
  - `nvidia-smi --query-gpu=index,name,memory.used,memory.free,utilization.gpu --format=csv,noheader,nounits`

Follow-up update:

- Early metric comparison from stdout:
  - main clean76 GPU0 around epoch `1930`: `loss=25.7164`,
    `position_loss=24.8683`, `os=0.5226`;
  - GPU4 hidden128/mp2/energy0.05 around epoch `180`: `loss=52.1902`,
    `position_loss=51.0222`, `os=0.3485`;
  - GPU5 energy0.2/ramp25 around epoch `130`: `loss=98.5749`,
    `position_loss=95.0562`, `os=0.4213`;
  - GPU6 hidden256/mp3/energy0.1 around epoch `80`: `loss=105.983`,
    `position_loss=103.564`, `os=0.3428`.
- Interpretation for the next sweep: OS remains a bottleneck; the higher
  energy-weight GPU5 run improves OS fastest early but still has much larger
  position loss than the mature main run. The wider/deeper GPU6 path is slower
  per epoch and not yet obviously better in early metrics.
- Local-only logging fix:
  - `scripts/ebd_oxdna_shared_rigid_train.py` now prints `rmsd` and
    `oxdna_energy_loss` plus backbone/stacking/hbond/cross-stack/excluded-volume
    components in each epoch stdout summary, so no-W&B runs can be compared
    directly from `run.log`.
  - Regression coverage added in
    `tests/test_ebd_oxdna_shared_rigid_train_cli.py`.
  - Verification passed:
    `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_oxdna_energy_loss_weight_and_history -v`
    and
    `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`.
- New local-only GPU7 sweep:
  - PID `1356`, output
    `outputs/local_clean76_energy_sweep_orient3_hidden128_mp2_energy01_10000e_20260623_gpu7_localonly/`;
  - runner
    `jobs/run_clean76_energy_sweep_orient3_hidden128_mp2_energy01_10000e_20260623_gpu7_localonly.sh`;
  - config changes: hidden dim `128`, message passing `2`, orientation loss
    weight `3.0`, energy weight `0.1`;
  - no W&B: runner exports `WANDB_MODE=disabled` and has no `--wandb`;
  - startup evidence: epoch `10` printed
    `loss=229.9088`, `position_loss=227.1964`, `rmsd=19.2952`,
    `os=0.2646`, `oxdna_energy_loss=25.3093`.

Additional cutoff-graph sweep:

- Started a nucleotide-level, non-pair-node cutoff graph experiment on GPU1:
  - PID `3204`, output
    `outputs/local_clean76_energy_sweep_cutoff8_orient3_hidden128_mp2_energy01_10000e_20260623_gpu1_localonly/`;
  - runner
    `jobs/run_clean76_energy_sweep_cutoff8_orient3_hidden128_mp2_energy01_10000e_20260623_gpu1_localonly.sh`;
  - config changes: `--graph-mode cutoff --graph-cutoff 8.0
    --max-graph-neighbors 12`, hidden dim `128`, message passing `2`,
    orientation weight `3.0`, energy weight `0.1`;
  - no W&B: runner exports `WANDB_MODE=disabled` and has no `--wandb`.
- Rationale: backbone-only DGNN-lite has OS stuck well below `1`; cutoff spatial
  edges preserve nucleotide nodes while allowing cross-strand/nonlocal geometry
  messages.
- Early runtime evidence: not OOM, but much slower sample preparation than
  backbone-only; `105_honeycomb-74-final2` prepare took `53.017798s`.
  Keep running until at least one epoch summary before judging metric quality.
- Latest observed metrics before this launch:
  - main GPU0 around epoch `2450`: `loss=21.5730`, `position_loss=20.7568`,
    `os=0.5520`;
  - GPU4 around epoch `620`: `loss=26.2565`, `position_loss=25.3572`,
    `os=0.4616`;
  - GPU5 around epoch `670`: `loss=40.7878`, `position_loss=38.7655`,
    `os=0.4671`;
  - GPU6 around epoch `420`: `loss=33.7385`, `position_loss=32.4223`,
    `os=0.4117`;
  - GPU7 around epoch `150`: `loss=65.2811`, `position_loss=62.4278`,
    `rmsd=12.3773`, `os=0.4232`, `oxdna_energy_loss=11.2300`.

## 2026-06-23 Clean76 Sweep Follow-up and GPU5 Replacement

- Current comparison from stdout at 2026-06-23 20:27 CST:
  - main GPU0 around epoch `2930`: latest `loss=19.7998`,
    `position_loss=18.9649`, `os=0.5308`; best seen `loss=18.1200`,
    best `os=0.5778`;
  - GPU4 hidden128/mp2/energy0.05 around epoch `1040`: latest/best
    `loss=16.1012`, `position_loss=15.2576`, `os=0.5050`;
  - GPU5 energy0.2/ramp25 around epoch `1260`: latest `loss=32.2636`,
    `position_loss=30.3529`, `os=0.4993`;
  - GPU6 hidden256/mp3/energy0.1 around epoch `730`: latest/best
    `loss=17.7482`, `position_loss=16.5980`, `os=0.5150`;
  - GPU7 orient3/hidden128/mp2/energy0.1 around epoch `530`: latest
    `loss=55.2949`, `rmsd=10.8643`, `os=0.4656`,
    `oxdna_energy_loss=7.5697`; best energy seen `7.1831`;
  - GPU1 cutoff graph still had no epoch summaries and was still in sample
    preparation/training startup.
- Decision:
  - stopped the underperforming local-only GPU5 energy0.2/ramp25 process
    `48966`; it was materially worse than the lower-energy-weight capacity
    runs after more than 1200 logged epochs.
  - started a replacement local-only nucleotide-level backbone sweep on GPU5:
    `jobs/run_clean76_energy_sweep_hidden192_mp3_orient2_energy005_10000e_20260623_gpu5_localonly.sh`;
    output
    `outputs/local_clean76_energy_sweep_hidden192_mp3_orient2_energy005_10000e_20260623_gpu5_localonly/`;
    wrapper PID `3896`, Python PID `3898`.
  - New config: `dgnn-lite`, backbone graph, hidden `192`, message passing
    `3`, orientation weight `2.0`, oxDNA energy weight `0.05`, LR `8e-4`,
    warmup `50`, grad clip `0.75`, same clean76 manifest and same W3 explicit
    validation ids.
  - No W&B: runner exports `WANDB_MODE=disabled` and has no `--wandb`.
- Startup evidence for the replacement GPU5 run:
  - `ps` showed Python PID `3898` detached under wrapper PID `3896`;
  - run log began sample preparation and had already logged through
    `14_TMFM_Mobile-reporter-unit`;
  - cache hits made preparation much faster than the cutoff graph path
    (`105_honeycomb-74-final2` prepared in `3.872676s` in the new backbone run).
  - by epoch `40`, the run had `loss=147.8568`, `rmsd=18.2581`,
    `os=0.2526`, `oxdna_energy_loss=19.8848`; `model_best.pt` existed and was
    `4.1M`, confirming best-checkpoint writing is active.

## 2026-06-23 Clean76 Cutoff Stop and GPU1 Replacement

- Current comparison from stdout at 2026-06-23 20:32 CST:
  - main GPU0 around epoch `3260`: best/latest OS reached `0.5993`, best
    loss `17.2397`;
  - GPU4 hidden128/mp2/energy0.05 around epoch `1340`: best loss `12.1199`,
    latest OS `0.5222`;
  - GPU5 hidden192/mp3/orient2/energy0.05 around epoch `90`: loss `96.3712`,
    RMSD `14.3625`, OS `0.2879`, energy `16.1168`;
  - GPU6 hidden256/mp3/energy0.1 around epoch `940`: best/latest loss
    `12.5100`, OS `0.5367`;
  - GPU7 orient3/hidden128/mp2/energy0.1 around epoch `790`: best RMSD
    `7.1836`, best energy `6.9897`, OS still below `0.50`.
- Stopped GPU1 cutoff graph process `3204`:
  - it had reached epoch `20` but remained much worse than every backbone
    run: latest `loss=1245.88`, `rmsd=56.6776`, `os=0.0529`,
    `oxdna_energy_loss=143.795`;
  - because it used much more GPU memory and did not provide useful evidence
    after startup, it was not worth continuing.
- Started a replacement local-only nucleotide-level backbone sweep on GPU1:
  - runner
    `jobs/run_clean76_energy_sweep_hidden256_mp3_orient15_energy002_10000e_20260623_gpu1_localonly.sh`;
  - output
    `outputs/local_clean76_energy_sweep_hidden256_mp3_orient15_energy002_10000e_20260623_gpu1_localonly/`;
  - wrapper PID `5471`, Python PID `5473`;
  - config: `dgnn-lite`, backbone graph, hidden `256`, message passing `3`,
    orientation weight `1.5`, oxDNA energy weight `0.02`, LR `8e-4`, warmup
    `50`, grad clip `0.75`, same clean76 manifest and same W3 explicit val ids;
  - no W&B: runner exports `WANDB_MODE=disabled` and has no `--wandb`.
- Startup evidence:
  - by epoch `10`, replacement GPU1 run had `loss=222.2384`, `rmsd=19.2606`,
    `os=0.2646`, `oxdna_energy_loss=24.4578`;
  - `model_best.pt` existed and was `7.2M`;
  - process `5473` remained active and detached under wrapper `5471`.

## 2026-06-23 Clean76 GPU5 OS-Focused Replacement

- Current comparison from stdout at 2026-06-23 20:38 CST:
  - main GPU0 around epoch `3560`: best loss `15.7996`, best OS `0.6110`;
  - GPU4 hidden128/mp2/energy0.05 around epoch `1610`: best/latest loss
    `9.9118`, OS `0.5371`;
  - GPU6 hidden256/mp3/energy0.1 around epoch `1140`: best/latest loss
    `9.9381`, best OS `0.5459`;
  - GPU7 orient3/hidden128/mp2/energy0.1 around epoch `1050`: best RMSD
    `5.7589`, best energy `6.8650`, best OS `0.5196`;
  - GPU5 hidden192/mp3/orient2/energy0.05 around epoch `310`: best loss
    `44.0252`, best RMSD `9.7713`, best OS `0.3941`, best energy `8.2286`.
- Decision:
  - stopped GPU5 hidden192/mp3/orient2/energy0.05 process `3898`; it was
    inferior to GPU7 on RMSD/energy and inferior to GPU4/GPU6 on loss/OS, so it
    had low marginal information value.
  - started an OS-focused local-only nucleotide-level backbone sweep on GPU5:
    `jobs/run_clean76_energy_sweep_hidden128_mp2_orient4_energy002_10000e_20260623_gpu5_localonly.sh`;
    output
    `outputs/local_clean76_energy_sweep_hidden128_mp2_orient4_energy002_10000e_20260623_gpu5_localonly/`;
    wrapper PID `5837`, Python PID `5839`.
  - New config: `dgnn-lite`, backbone graph, hidden `128`, message passing
    `2`, orientation weight `4.0`, oxDNA energy weight `0.02`, LR `1e-3`,
    warmup `25`, grad clip `1.0`, same clean76 manifest and same W3 explicit
    validation ids.
  - No W&B: runner exports `WANDB_MODE=disabled` and has no `--wandb`.
- Startup evidence:
  - by epoch `20`, replacement GPU5 run had `loss=188.3436`,
    `rmsd=20.0688`, `os=0.3522`, `oxdna_energy_loss=22.7975`;
  - `model_best.pt` existed and was `1.9M`;
  - process `5839` remained active and detached under wrapper `5837`.

## 2026-06-23 CodeGraph Repair and GPU1 Energy-Weight Control

- User explicitly requested forced CodeGraph usage and repair until usable to
  save tokens.
- CodeGraph findings:
  - project `.codegraph/` existed with `codegraph.db`, stale daemon pid/socket,
    and logs;
  - `codegraph` CLI is available at `/home/lijingjing/lijj/bin/codegraph`;
  - Codex config did not include a CodeGraph MCP server entry, which explains
    why this running session did not expose `codegraph_*` tools.
- Repair actions:
  - removed stale `.codegraph/daemon.sock` and `.codegraph/daemon.pid`;
  - ran `codegraph unlock .` and `codegraph sync .`;
  - added the MCP config snippet to both active Codex configs:
    `/home/lijingjing/lijj/.codex/config.toml` and
    `/home/lijingjing/lijj/.codex-instances/Geodiff_fam-de6305b8dd01/config.toml`:
    `[mcp_servers.codegraph] command = "codegraph" args = ["serve", "--mcp"]`;
  - ran `codegraph install -t codex -l global -y`, which reported Codex CLI
    config unchanged and `~/.codex/AGENTS.md` updated, with a restart required
    for MCP tool exposure.
- Verification:
  - `codegraph status .` reports 405 files, 6129 nodes, 13998 edges;
  - `codegraph files --filter scripts --format flat --no-metadata` lists the
    indexed scripts;
  - `codegraph query DgnnLiteRigidModel --limit 5` finds
    `scripts/ebd_oxdna_shared_rigid_train.py:579`;
  - `codegraph node DgnnLiteRigidModel.__call__` returns the method body and
    call trail.
- Note: current session still cannot hot-load missing `codegraph_*` MCP tools,
  but CodeGraph CLI is usable now; after restarting Codex, the MCP tools should
  be available from the repaired config.

Experiment update made after CodeGraph repair:

- Current comparison from stdout before GPU1 replacement:
  - main GPU0 around epoch `3850`: best loss and OS `14.7179` / `0.6300`;
  - GPU4 hidden128/mp2/energy0.05: best loss `9.1495`, best OS `0.5422`;
  - GPU6 hidden256/mp3/energy0.1: best loss `8.3011`, best OS `0.5626`;
  - GPU7 orient3/hidden128/mp2/energy0.1: best RMSD `4.8798`, best energy
    `6.6797`, best OS `0.5517`;
  - GPU1 hidden256/mp3/orient1.5/energy0.02: best loss `44.0513`, best OS
    `0.4520`, best energy `8.2505`.
- Decision:
  - stopped GPU1 hidden256/mp3/orient1.5/energy0.02 process `5473` because it
    remained behind all mature useful directions by epoch `270`;
  - started GPU1 local-only control based on the successful GPU7 architecture
    but lower energy weight:
    `jobs/run_clean76_energy_sweep_hidden128_mp2_orient3_energy002_10000e_20260623_gpu1_localonly.sh`;
    output
    `outputs/local_clean76_energy_sweep_hidden128_mp2_orient3_energy002_10000e_20260623_gpu1_localonly/`;
    wrapper PID `7366`, Python PID `7368`;
  - config: `dgnn-lite`, backbone graph, hidden `128`, message passing `2`,
    orientation weight `3.0`, oxDNA energy weight `0.02`, LR `1e-3`, same
    clean76 manifest and same W3 explicit validation ids;
  - no W&B: runner exports `WANDB_MODE=disabled` and has no `--wandb`.
- Startup evidence:
  - by epoch `1`, replacement GPU1 run had `loss=251.8051`, `rmsd=20.0701`,
    `os=0.0968`, `oxdna_energy_loss=27.9801`;
  - `model_best.pt` existed and was `1.9M`;
  - process `7368` remained active and detached under wrapper `7366`.

## 2026-06-23 Clean74 Energy-Only 1000e oxView Val Extremes

- User requested an oxView HTML comparison for good and bad validation
  predictions from `clean74-energy-only-1000e-20260623_gpu1`, using the
  existing harness approach rather than writing new viewer code.
- Built page:
  `outputs/oxview_compare_clean74_energy_only_1000e_val_extremes/index.html`.
- Source run:
  `outputs/local_clean74_energy_only_1000e_20260623_gpu1/summary.json`.
- Selection used validation split only, sorted by `final_rmsd`:
  - best three: `130_6_helix_bundle` (`rmsd=4.2140`, `os=0.3239`),
    `18_Positioner_coloredMountingStaples_Extra-Amine-for-Biotin`
    (`rmsd=6.0479`, `os=0.1605`), and
    `14_TMFM_Immobile-reporter-unit` (`rmsd=7.6256`, `os=0.0061`);
  - worst three: `106_Berlin.1` (`rmsd=31.6529`, `os=0.0398`),
    `102_3` (`rmsd=26.7291`, `os=0.0142`), and
    `200_SixBar_Fig1` (`rmsd=25.9791`, `os=0.0777`).
- The page uses `tacoxdna/<design_id>.json.top` for topology and contains
  three panes per row: original start, original md_last, and model prediction.
  Model `.conf` files were copied to `model_prediction_oxview.conf` with
  numeric first line `t = 1000000`.
- Started a static server from the Geodiff_fam root:
  - PID file:
    `outputs/oxview_compare_clean74_energy_only_1000e_val_extremes/http_8000.pid`
  - command: `python3 -m http.server 8000 --bind 127.0.0.1`
  - access path after the user's tunnel:
    `http://127.0.0.1:58057/outputs/oxview_compare_clean74_energy_only_1000e_val_extremes/`
- Verification evidence:
  - `curl -I` returned HTTP 200 for the comparison `index.html`, `viewer.html`,
    and `/oxdna-viewer/` on `127.0.0.1:8000`.
  - Checked all six generated `model_prediction_oxview.conf` files have first
    line `t = 1000000`.

Follow-up page loading fix:

- User reported that the single page loaded too many oxView panels at once,
  causing many viewer failures.
- Root cause: the generated page eagerly created 18 oxView iframes
  (six designs times start/target/model), and each iframe loads a full oxView
  app plus large `.top`/`.conf` files.
- Updated `scripts/generate_oxview_comparison.py` so comparison pages are
  lazy-loaded by default:
  - initial page renders zero iframes;
  - each panel stores its viewer URL in `data-src`;
  - clicking a panel Load button creates only that panel's iframe;
  - clicking `Load this design` creates only the three iframes for that design;
  - clicking `Unload this design` removes those iframes and releases browser
    resources.
- Regenerated
  `outputs/oxview_compare_clean74_energy_only_1000e_val_extremes/index.html`.
- Verification evidence:
  - HTML parser check: `iframe_tags 0`, `viewer_placeholders 18`,
    `placeholders_with_data_src 18`.
  - HTTP checks returned `index 200` and `viewer 200`.
  - Browser-level Playwright verification was skipped because both Python and
    Node Playwright packages are not installed in this environment.

## 2026-06-23 Codex SQLite Lock Avoidance

- User reported Codex startup failure because another Codex process held
  `~/.codex/state_5.sqlite` / `~/.codex/logs_2.sqlite`; user explicitly asked
  not to terminate any running Codex process.
- Root cause evidence:
  - `lsof` showed active Codex PID `42742` holding the main `~/.codex` SQLite
    databases and WAL files.
  - The old system `sqlite3` CLI is version `3.7.17`, so its partial-index
    schema error is not reliable evidence of current database corruption.
- Implemented a non-destructive user-level wrapper at `~/.local/bin/codex`:
  - if the main `~/.codex` DB files are already opened by Codex/node, it creates
    or reuses a per-working-directory isolated `CODEX_HOME` under
    `~/.codex-instances/`;
  - it copies config/auth/rules/skills/superpowers files but does not share the
    locked SQLite runtime DBs;
  - it then execs the real Codex binary at the nvm install path.
- Updated `~/.bashrc`, `~/.bash_profile`, and `~/.zshrc` so `~/.local/bin` is
  before the nvm Codex binary for future shells.
- Verification evidence:
  - direct wrapper run printed
    `codex wrapper: /home/lijingjing/lijj/.codex is busy; using isolated CODEX_HOME=/home/lijingjing/lijj/.codex-instances/Geodiff_fam-de6305b8dd01`
    and then `codex-cli 0.142.0`;
  - `bash -lc 'type -a codex'` resolves `~/.local/bin/codex` before the nvm
    binary;
  - original running Codex PID `42742` was still alive after the fix.

Follow-up Codex wrapper hardening:

- User reproduced the startup error from
  `/home/lijingjing/lijj/users/lht2/deeporigami/agent/athena_generativesnupi`;
  the failure still referenced `/home/lijingjing/lijj/.codex/state_5.sqlite`,
  proving that shell invocation had bypassed the first wrapper.
- Root cause evidence:
  - bash login shells resolved `codex` to `~/.local/bin/codex` first;
  - zsh resolved `codex` to the nvm install first:
    `~/.nvm/versions/node/v22.22.3/bin/codex`;
  - the original running Codex PID `42742` still held the main `.codex` DBs.
- Hardened the fix without terminating any running Codex process:
  - replaced the nvm `bin/codex` symlink with a tiny forwarding script to
    `~/.local/bin/codex`;
  - preserved the original symlink as
    `~/.nvm/versions/node/v22.22.3/bin/codex.original-symlink-20260623`;
  - changed the wrapper real target to the package entrypoint
    `~/.nvm/versions/node/v22.22.3/lib/node_modules/@openai/codex/bin/codex.js`
    to avoid recursion;
  - changed default behavior so new Codex invocations use a per-working-dir
    isolated `CODEX_HOME` unless `CODEX_USE_MAIN_HOME=1` is explicitly set;
  - made large config directory seeding (`rules`, `skills`, `superpowers`)
    one-time per isolated home via `.codex-wrapper-config-seeded`, while small
    config/auth files refresh on each launch.
- Verification evidence from the user's failing directory:
  - `zsh -lc 'type -a codex; codex --version'` still listed the nvm path first,
    but the nvm path forwarded to the wrapper;
  - output showed
    `codex wrapper: /home/lijingjing/lijj/.codex is busy; using isolated CODEX_HOME=/home/lijingjing/lijj/.codex-instances/athena_generativesnupi-ed2530b7699e`
    followed by `codex-cli 0.142.0`;
  - original Codex PID `42742` remained alive and continued to be the only
    process holding the main `.codex` database files.

## 2026-06-23 CodeGraph Forced-Use Cleanup

- User requested that CodeGraph be used forcibly and repaired if unavailable.
- Verified CodeGraph CLI is usable in this repository:
  - `codegraph status .` reports 402 indexed files, 6129 nodes, 13998 edges,
    and `Index is up to date`;
  - `codegraph query DgnnLiteRigidModel --limit 3` returns the trainer model
    class in `scripts/ebd_oxdna_shared_rigid_train.py`;
  - `codegraph node DgnnLiteRigidModel.__call__` returns source plus call trail.
- Added root `.gitignore` entries for `.codegraph/`, `outputs/`,
  `oxdna-viewer/`, and the vendored docs oxView tree so CodeGraph no longer
  spends work on generated outputs or viewer bundles that triggered path-reader
  failures.
- Current session may still not hot-load `codegraph_*` MCP tools, so use
  `codegraph` CLI (`files/query/node/explore/callers/callees/impact`) as the
  required structural lookup path until a fresh Codex session exposes MCP tools.

Follow-up verification in the resumed session:

- `codegraph status .` now reports 402 indexed files, 6135 nodes, 14013 edges,
  backend `node:sqlite`, and `Index is up to date`.
- `codegraph query DgnnLiteRigidModel --limit 3` and
  `codegraph query _evaluate_validation_metrics --limit 5` both returned
  structural results from `scripts/ebd_oxdna_shared_rigid_train.py`.
- `./init.sh` completed successfully.
- Operating rule remains: use CodeGraph CLI first for structural work; use
  `rg` only for literal logs/config strings or other text searches CodeGraph is
  not meant to answer.

## 2026-06-23 Clean76 Train-Best Sweep Update

- Added `--best-model-monitor` to
  `scripts/ebd_oxdna_shared_rigid_train.py` so future best checkpoints can be
  selected by train or val metrics. Default `auto` preserves legacy behavior:
  sample-val runs monitor `val/loss`, otherwise `train/loss`.
- Supported monitor keys are `train/loss`, `val/loss`, `train/rmsd`,
  `val/rmsd`, `train/os`, `val/os`, `train/oxdna_energy_loss`, and
  `val/oxdna_energy_loss`; OS is maximized, the others are minimized.
- Verification:
  - `py_compile` passed for `scripts/ebd_oxdna_shared_rigid_train.py` and
    `tests/test_ebd_oxdna_shared_rigid_train_cli.py`.
  - Focused unittest passed:
    `test_shared_rigid_train_cli_can_monitor_train_loss_for_best_checkpoint`
    and `test_shared_rigid_train_cli_writes_best_checkpoint_during_training`.
  - A broader legacy test,
    `test_shared_rigid_train_cli_fits_two_manifest_entries`, still fails
    because it expects default `physical_rule_metrics`, while current training
    intentionally skips final physical metrics by default.
- Stopped dominated GPU1 run PID `7368`
  (`hidden128/mp2/orient3/energy0.02`) after it remained behind GPU5 at
  comparable early epochs and behind the mature GPU6/GPU7 directions.
- Launched replacement no-W&B run on GPU1:
  - PID `11461`
  - runner:
    `jobs/run_clean76_energy_sweep_hidden256_mp3_orient3_energy01_trainbest_10000e_20260623_gpu1_localonly.sh`
  - output:
    `outputs/local_clean76_energy_sweep_hidden256_mp3_orient3_energy01_trainbest_10000e_20260623_gpu1_localonly/`
  - config combines GPU6 capacity (`hidden256/mp3`, LR `5e-4`, grad clip
    `0.5`, energy `0.1`) with GPU7's orientation emphasis (`orientation=3.0`)
    and uses `--best-model-monitor train/loss`.
  - It is local-only: `WANDB_MODE=disabled`, no `--wandb`.
  - Startup evidence: reached epoch 30, wrote `model_best.pt` (7.2 MiB), and
    epoch 30 logged `loss=172.2467`, `rmsd=20.2035`, `os=0.3282`,
    `oxdna_energy_loss=19.3858`.

Follow-up GPU4 OS-monitor sweep:

- Stopped dominated GPU4 run PID `48837`
  (`hidden128/mp2/orient1/energy0.05`) after epoch `3090`; it stayed around
  `loss=6.30`, `position_loss=5.58`, `os=0.577` and no longer improved its
  `model_best.pt` after 20:00 CST, while GPU6 had lower loss and better OS and
  GPU7 had better RMSD/energy/OS.
- Launched replacement no-W&B run on GPU4:
  - PID `11976`
  - runner:
    `jobs/run_clean76_energy_sweep_hidden128_mp2_orient4_energy01_trainos_10000e_20260623_gpu4_localonly.sh`
  - output:
    `outputs/local_clean76_energy_sweep_hidden128_mp2_orient4_energy01_trainos_10000e_20260623_gpu4_localonly/`
  - config: `hidden128/mp2`, `orientation=4.0`, `energy=0.1`, LR `1e-3`,
    `--best-model-monitor train/os`.
  - It is local-only: `WANDB_MODE=disabled`, no `--wandb`.
  - Startup evidence: reached epoch 1 and wrote `model_best.pt` (1.9 MiB);
    epoch 1 logged `loss=252.7531`, `rmsd=20.0701`, `os=0.0968`,
    `oxdna_energy_loss=27.9801`.

## 2026-06-23 21:21 Clean76 Monitoring Update

- CodeGraph-first rule was followed for structural checks:
  `codegraph node DgnnLiteRigidModel.__call__` confirmed the current core
  model still runs nucleotide-level DGNN-lite message passing over the supplied
  graph edges. The class still contains a pair head, but the active clean76
  runners use `--graph-mode backbone` and no pair-node graph representation.
- GPU availability check:
  - GPU0,1,4,5,6,7 are occupied by current clean76 runs.
  - GPU2 and GPU3 are not available: user `liaitao` is running `pmemd.cuda`
    at about 94% utilization on both.
  - GPU1 also has a small `liaitao` AlphaFold3 process using about 420 MiB,
    but the active GPU1 clean76 run is still progressing.
- No new experiment was launched because there is no genuinely idle A100 and
  the current GPU4 replacement is not yet clearly dominated.
- Latest sampled clean76 metrics:
  - GPU0 main W&B legacy run, epoch 5580:
    `loss=11.3414`, `position_loss=10.6893`, `os=0.6984`.
  - GPU1 `hidden256/mp3/orient3/energy0.1/train-loss`, epoch 370:
    `loss=39.4076`, `rmsd=9.2622`, `os=0.4458`,
    `oxdna_energy_loss=7.4415`.
  - GPU4 `hidden128/mp2/orient4/energy0.1/train-os`, epoch 220:
    `loss=50.9212`, `rmsd=10.4686`, `os=0.4402`,
    `oxdna_energy_loss=8.6594`.
  - GPU5 `hidden128/mp2/orient4/energy0.02`, epoch 1650:
    `loss=9.2537`, `rmsd=4.0998`, `os=0.6360`,
    `oxdna_energy_loss=6.7555`.
  - GPU6 `hidden256/mp3/orient1/energy0.1`, epoch 2460:
    `loss=5.1461`, `position_loss=4.2632`, `os=0.6336`.
  - GPU7 `hidden128/mp2/orient3/energy0.1`, epoch 2830:
    `loss=7.1970`, `rmsd=3.6354`, `os=0.6910`,
    `oxdna_energy_loss=5.6658`.
- Interpretation:
  - GPU7 remains the best mature RMSD/energy/OS direction among runs that log
    all three.
  - GPU6 remains the best mature loss/position-loss direction, though its
    current log format does not print RMSD/energy.
  - GPU4 should continue for now: at comparable early epochs it is close to or
    slightly better than GPU7/GPU5 on some metrics, so stopping it would throw
    away useful evidence too early.
  - GPU1 is weaker so far but still young; reassess after several hundred more
    epochs before replacing it.

## 2026-06-23 21:29 GPU6 Replacement Sweep

- Rechecked CodeGraph and runtime state before acting:
  - `codegraph status .` remained up to date;
  - `codegraph query DgnnLiteRigidModel --limit 3` found the active trainer
    model class;
  - GPU2/GPU3 were still occupied by other-user `pmemd.cuda` jobs, so no idle
    A100 was available.
- Kept GPU1 and GPU4 running:
  - GPU4 `hidden128/mp2/orient4/energy0.1/train-os` was still comparable to
    GPU7/GPU5 at matched early epochs and continued improving.
  - GPU1 `hidden256/mp3/orient3/energy0.1/train-loss` was weaker but its
    `model_best.pt` was still updating.
- Stopped only our own mature GPU6 run PID `48972`
  (`hidden256/mp3/orient1/energy0.1`) because:
  - its `model_best.pt` had not updated since 20:20 CST;
  - recent epochs had regressed from the best region
    (`epoch=2450 loss=4.9290 os=0.6411` to around
    `epoch=2550 loss=6.4382 os=0.6388`, with worse intervening OS dips);
  - the runner did not print RMSD or oxDNA energy, making it less useful for
    the current target than the other active sweeps.
- Added and launched a no-W&B GPU6 replacement:
  - runner:
    `jobs/run_clean76_energy_sweep_hidden128_mp2_orient5_energy01_trainos_10000e_20260623_gpu6_localonly.sh`
  - PID: `14493`
  - output:
    `outputs/local_clean76_energy_sweep_hidden128_mp2_orient5_energy01_trainos_10000e_20260623_gpu6_localonly/`
  - config: nucleotide-level `dgnn-lite`, `--graph-mode backbone`,
    `hidden128/mp2`, `orientation-loss-weight=5.0`,
    `oxdna-energy-loss-weight=0.1`, `--best-model-monitor train/os`, same
    explicit W3 val IDs, no `--wandb`, `WANDB_MODE=disabled`.
  - startup evidence: reached epoch 30 and wrote `model_best.pt` (1.9 MiB).
    Epoch 30 logged `loss=164.0145`, `rmsd=19.1632`, `os=0.3664`,
    `oxdna_energy_loss=20.7035`.
- Next check: compare the new orient5/train-os curve against GPU4 orient4 and
  GPU7 orient3 at matched epochs after it reaches a few hundred epochs.

## 2026-06-23 21:32 Clean76 Monitoring Update

- CodeGraph-first structural check passed:
  - `codegraph status .` remained up to date;
  - `codegraph query DgnnLiteRigidModel --limit 3` and
    `codegraph query oxdna_energy_loss --limit 6` located the active
    nucleotide-level model and differentiable energy function;
  - `codegraph node oxdna_energy_loss` confirmed the active energy loss still
    combines backbone distance, stacking, hbond, cross-stack, and excluded
    volume terms.
- GPU state:
  - GPU0/1/4/5/6/7 are occupied by current clean76 runs.
  - GPU2/GPU3 remain occupied by other-user `pmemd.cuda` jobs at high
    utilization, so there is still no idle A100.
- Latest active run snapshot:
  - GPU0 legacy main run, epoch 6050:
    `loss=10.5188`, `position_loss=9.8784`, `os=0.7086`.
  - GPU1 `hidden256/mp3/orient3/energy0.1/train-loss`, epoch 680:
    `loss=25.0750`, `rmsd=7.2364`, `os=0.4608`,
    `oxdna_energy_loss=6.8756`.
  - GPU4 `hidden128/mp2/orient4/energy0.1/train-os`, epoch 630:
    `loss=28.3002`, `rmsd=7.5967`, `os=0.4977`,
    `oxdna_energy_loss=7.1463`.
  - GPU5 `hidden128/mp2/orient4/energy0.02`, epoch 2110:
    `loss=7.7027`, `rmsd=3.7315`, `os=0.6847`,
    `oxdna_energy_loss=6.5121`.
  - GPU6 `hidden128/mp2/orient5/energy0.1/train-os`, epoch 150:
    `loss=68.6260`, `rmsd=12.6098`, `os=0.4310`,
    `oxdna_energy_loss=11.4654`.
  - GPU7 `hidden128/mp2/orient3/energy0.1`, epoch 3280:
    `loss=5.8677`, `rmsd=3.1188`, `os=0.7155`,
    `oxdna_energy_loss=5.4127`.
- Matched-epoch interpretation:
  - At epochs 100-160, GPU6 orient5 has slightly stronger OS than GPU4
    orient4/GPU7 orient3 in some rows, but not uniformly better RMSD/loss/energy;
    keep it until several hundred epochs before judging.
  - At epochs 600-700, GPU5 has strong OS and lower RMSD than GPU1/GPU4/GPU7
    at comparable epochs, though energy is higher than GPU7's later mature
    energy. It should not be stopped yet.
  - GPU7 remains the best mature absolute RMSD/energy/OS direction.
  - GPU1 and GPU4 still have fresh `model_best.pt` updates, so neither is
    clearly dominated yet.
- Decision: no run was stopped and no new run was launched in this pass.

## 2026-06-23 21:40 GPU0 Replacement Sweep

- Rechecked CodeGraph and runtime state before acting:
  - `codegraph status .` remained up to date;
  - `codegraph query DgnnLiteRigidModel --limit 3` and
    `codegraph query oxdna_energy_loss --limit 4` still located the trusted
    nucleotide DGNN-lite path and differentiable energy path.
- Stopped only our own old GPU0 legacy W&B run PID `43289`
  (`outputs/local_clean76_energy_only_nucleotide_10000e_w3split_20260623_gpu0`)
  because:
  - it was already mature at epoch `6200`;
  - its `model_best.pt` timestamp was still `19:24 CST`;
  - it did not print RMSD or oxDNA energy in the epoch log;
  - its mature `loss=10.3651`, `position_loss=9.7281`, `os=0.7114` was no
    longer as informative as GPU7's mature all-metric trajectory
    (`epoch=3380 loss=5.7662`, `rmsd=3.0870`, `os=0.7201`,
    `oxdna_energy_loss=5.3424`).
- Added and launched a no-W&B GPU0 replacement:
  - runner:
    `jobs/run_clean76_energy_sweep_hidden256_mp3_orient4_energy01_trainos_10000e_20260623_gpu0_localonly.sh`
  - PID: `16351`
  - output:
    `outputs/local_clean76_energy_sweep_hidden256_mp3_orient4_energy01_trainos_10000e_20260623_gpu0_localonly/`
  - config: nucleotide-level `dgnn-lite`, `--graph-mode backbone`,
    `hidden256/mp3`, `orientation-loss-weight=4.0`,
    `oxdna-energy-loss-weight=0.1`, `--best-model-monitor train/os`, same
    explicit W3 val IDs, no `--wandb`, `WANDB_MODE=disabled`.
  - rationale: combine the higher-capacity GPU1/GPU6 style with the orient4
    train-OS direction while preserving full RMSD/energy logging.
  - startup evidence: reached epoch 40 and wrote `model_best.pt` (7.2 MiB).
    Epoch 40 logged `loss=133.1239`, `rmsd=16.3641`, `os=0.3828`,
    `oxdna_energy_loss=20.7344`.
- Next check: compare GPU0 hidden256/mp3/orient4/train-os against GPU4
  hidden128/mp2/orient4/train-os and GPU7 orient3 at matched epochs.

## 2026-06-23 21:47 GPU6 Energy-Midpoint Sweep

- Rechecked CodeGraph and runtime state before acting:
  - `codegraph status .` remained up to date;
  - `codegraph query DgnnLiteRigidModel --limit 3` and
    `codegraph query _compute_oxdna_energy_loss --limit 4` still found the
    trusted model and energy-loss integration.
- Stopped only our own GPU6 orient5/train-os run PID `14493`
  (`outputs/local_clean76_energy_sweep_hidden128_mp2_orient5_energy01_trainos_10000e_20260623_gpu6_localonly/`)
  because at matched epochs 500-600 it was dominated by the existing orient4
  and energy0.02/0.1 trajectories:
  - GPU6 orient5 epoch 600:
    `loss=37.8586`, `rmsd=8.8620`, `os=0.4860`,
    `oxdna_energy_loss=7.2646`.
  - GPU4 orient4 epoch 600:
    `loss=30.6034`, `rmsd=7.8766`, `os=0.4935`,
    `oxdna_energy_loss=7.0994`.
  - GPU5 orient4/energy0.02 epoch 600:
    `loss=30.1017`, `rmsd=7.9197`, `os=0.4869`,
    `oxdna_energy_loss=7.3759`.
  - The orient5 run did not show the expected OS advantage and also had worse
    RMSD/loss/energy than GPU4 at matched epochs.
- Added and launched a no-W&B GPU6 replacement:
  - runner:
    `jobs/run_clean76_energy_sweep_hidden128_mp2_orient3_energy005_10000e_20260623_gpu6_localonly.sh`
  - PID: `16780`
  - output:
    `outputs/local_clean76_energy_sweep_hidden128_mp2_orient3_energy005_10000e_20260623_gpu6_localonly/`
  - config: nucleotide-level `dgnn-lite`, `--graph-mode backbone`,
    `hidden128/mp2`, `orientation-loss-weight=3.0`,
    `oxdna-energy-loss-weight=0.05`, same explicit W3 val IDs, no `--wandb`,
    `WANDB_MODE=disabled`.
  - rationale: test an energy-weight midpoint between GPU7's stronger
    energy-loss run (`energy=0.1`) and GPU5's stronger-OS/lower-energy-weight
    run (`energy=0.02`).
  - startup evidence: reached epoch 20 and wrote `model_best.pt` (1.9 MiB).
    Epoch 20 logged `loss=187.3304`, `rmsd=19.9405`, `os=0.3462`,
    `oxdna_energy_loss=22.6495`.
- Next check: compare GPU6 energy0.05 against GPU7 energy0.1 and GPU5
  energy0.02 at matched epochs once it reaches at least several hundred epochs.

## 2026-06-23 22:00 GPU4 GPU7-like Train-OS Replacement

- Followed the forced CodeGraph workflow before runtime changes:
  - `codegraph status .` was up to date;
  - `codegraph query DgnnLiteRigidModel --limit 3` found the trusted
    nucleotide DGNN-lite class;
  - `codegraph query _compute_oxdna_energy_loss --limit 4` found the active
    differentiable energy integration.
- Runtime snapshot before replacement:
  - GPU2/GPU3 were still occupied by other-user `pmemd.cuda` jobs, so they were
    not available despite low memory usage.
  - GPU0/1/4/5/6/7 were occupied by clean76 runs.
- Stopped only our own GPU4 orient4/train-os run PID `11976`
  (`outputs/local_clean76_energy_sweep_hidden128_mp2_orient4_energy01_trainos_10000e_20260623_gpu4_localonly/`)
  because it had become clearly dominated:
  - GPU4 epoch 1500:
    `loss=11.5954`, `rmsd=4.5163`, `os=0.5827`,
    `oxdna_energy_loss=6.5547`.
  - GPU1 epoch 1300:
    `loss=9.8837`, `rmsd=4.3080`, `os=0.6216`,
    `oxdna_energy_loss=6.1470`.
  - GPU5 epoch 2930:
    `loss=5.8785`, `rmsd=3.1795`, `os=0.7357`,
    `oxdna_energy_loss=6.1159`.
  - GPU7 epoch 4110:
    `loss=5.3024`, `rmsd=2.9728`, `os=0.7390`,
    `oxdna_energy_loss=4.9211`.
- Added and launched a no-W&B GPU4 replacement:
  - runner:
    `jobs/run_clean76_energy_sweep_hidden128_mp2_orient3_energy01_trainos_10000e_20260623_gpu4_localonly.sh`
  - PID: `18756`
  - output:
    `outputs/local_clean76_energy_sweep_hidden128_mp2_orient3_energy01_trainos_10000e_20260623_gpu4_localonly/`
  - config: nucleotide-level `dgnn-lite`, `--graph-mode backbone`,
    `hidden128/mp2`, `orientation-loss-weight=3.0`,
    `oxdna-energy-loss-weight=0.1`, `--best-model-monitor train/os`, same W3
    explicit validation IDs, no `--wandb`, `WANDB_MODE=disabled`.
  - rationale: replicate the current best GPU7 hyperparameter direction while
    selecting best checkpoints by train OS, which directly targets the
    train-set `OS -> 1` objective.
  - startup evidence: `prepare_samples` completed in `98.372595s`, the run
    reached epoch 40, and `model_best.pt` exists. Epoch 40 logged
    `loss=150.5004`, `rmsd=18.5296`, `os=0.3455`,
    `oxdna_energy_loss=18.8029`.
- Debug note: the first `nohup` launch exited with only locale warnings in
  `run.log`. A `timeout 90 bash -x ...` diagnostic showed the script was
  healthy and still preparing samples when timeout killed it (`EXIT_CODE=124`),
  so the long run was relaunched with `setsid`.
- Ran `codegraph sync .` after adding the runner; `codegraph status .` remained
  up to date.

## 2026-06-23 GPU7 Best-Checkpoint Val Evaluation

- User asked for GPU7 best-model validation RMSD/OS/energy and approved freeing
  the least-promising GPU for the evaluation.
- Stopped only our own GPU4 train-OS replica PID `18756`
  (`outputs/local_clean76_energy_sweep_hidden128_mp2_orient3_energy01_trainos_10000e_20260623_gpu4_localonly/`)
  to free GPU4. Rationale: it was mostly a GPU7-like duplicate with only the
  best-monitor changed, while GPU6 energy0.2 still tests a distinct
  energy-focused hypothesis.
- Added `scripts/evaluate_clean76_checkpoint_val.py`, an eval-only helper that
  reuses the shared trainer internals:
  `_prepare_sample_with_cache`, `DgnnLiteRigidModel`, and
  `_evaluate_validation_metrics`. It does not train, write W&B, or export
  `.conf` files.
- Verification:
  - `py_compile scripts/evaluate_clean76_checkpoint_val.py` passed.
  - GPU4 smoke on the first 20 manifest entries passed.
  - Full clean76 W3 validation evaluation ran on GPU4 and wrote
    `outputs/eval_gpu7_best_clean76_val_20260623/summary.json`.
  - `codegraph sync .` was run after adding the script; CodeGraph is up to date.
- Evaluated checkpoint:
  `outputs/local_clean76_energy_sweep_orient3_hidden128_mp2_energy01_10000e_20260623_gpu7_localonly/model_best.pt`
- Validation split: 15 W3 explicit val IDs, 61 train / 15 val over clean76.
- Result:
  - `val/rmsd = 15.637760130564372`
  - `val/os = 0.4105862743531664`
  - `val/oxdna_energy_loss = 8.68468721707662`
  - `val/loss = 151.01763032277424`
  - `val/position_loss = 148.3809222539266`
  - `val/orientation_loss = 0.5894137223561605`
  - `val/conflict_rate = 0.0`
- Interpretation: GPU7 is strong on train/latest metrics but its saved
  `model_best.pt` generalizes poorly on the held-out W3 val split. Current work
  remains a train-set overfit/convergence objective, but this val result is a
  useful warning that the present energy-only DGNN-lite setup is not yet
  generalizing.

## 2026-06-23 Hidden256 MP4 W&B Depth Probe

- User explicitly requested a W&B run for:
  `hidden256`, `message_passing_steps=4`, `orientation=3.0`, `energy=0.1`,
  `best=train/os`, `lr=5e-4`, `grad_clip=0.5`.
- This request explicitly overrides the default no-W&B rule for this one
  experiment only. Other future experiments remain no-W&B by default unless the
  user explicitly asks again.
- CodeGraph-first checks passed before launch:
  - `codegraph status .` up to date;
  - `codegraph query DgnnLiteRigidModel --limit 1`;
  - `codegraph query _compute_oxdna_energy_loss --limit 1`.
- GPU selection:
  - GPU4 was the only practical free A100 for our use.
  - GPU4 had a small other-user AlphaFold3 process using about 1.8 GiB and low
    utilization; the new run was launched without touching that process.
  - GPU2/GPU3 remained occupied by other-user `pmemd.cuda`; not used.
- Added W&B online detached runner:
  `jobs/run_clean76_energy_sweep_hidden256_mp4_orient3_energy01_trainos_lr5e4_wandb_10000e_20260623_gpu4.sh`
- Output:
  `outputs/local_clean76_energy_sweep_hidden256_mp4_orient3_energy01_trainos_lr5e4_wandb_10000e_20260623_gpu4/`
- Background launch method:
  `setsid jobs/run_clean76_energy_sweep_hidden256_mp4_orient3_energy01_trainos_lr5e4_wandb_10000e_20260623_gpu4.sh > "$OUT/run.log" 2>&1 &`
  so the Python process is detached from the SSH session.
- Process:
  - PID: `23954`
  - PPID: `1`
  - SID: `23954`
- W&B settings:
  - `WANDB_MODE=online`
  - `WANDB_PROJECT=deeporigami`
  - `WANDB_NAME=clean76-hidden256-mp4-orient3-energy01-trainos-lr5e4-10000e-gpu4-20260623`
  - trainer args include `--wandb --wandb-mode online`.
- Startup evidence:
  - `ps` showed PID `23954` running the expected command.
  - `run.log` showed sample preparation underway.
  - No epoch result was waited for because the user said launch evidence was
    enough and asked to move on.
- Follow-up launch evidence:
  - `ps -o pid,ppid,sid,... -p 23954` showed the Python process still running
    with `PPID=1` and `SID=23954`, so it is detached from the SSH/TUI session.
  - W&B run id is `wwq211x6`:
    `https://wandb.ai/hbjzhxlxx-/deeporigami/runs/wwq211x6`.
  - The log reached training epochs; epoch 1 reported
    `loss=253.838953628`, `rmsd=20.1622836082`, `os=0.0405458287972`,
    `oxdna_energy_loss=28.003287329`, and the latest checked tail showed
    epoch 14 sample timings.
  - Early per-sample timing is reasonable for this GPU path: most train
    samples are around `0.02-0.05s`, with `105_honeycomb-74-final2` around
    `0.08-0.12s` in the first checked epochs.
- Directional notes for future comparison:
  - Success criterion: compare against GPU0 (`hidden256/mp3/orient4/energy0.1`
    train/os) and GPU7 (`hidden128/mp2/orient3/energy0.1`) at matched epochs.
  - This experiment specifically tests depth (`mp4`) under a conservative LR
    and grad clip; it should clarify whether deeper message passing helps more
    than the existing wider-but-shallower runs.
  - Failure modes to watch: slower epoch time, unstable OS oscillation, or
    energy not improving despite better OS.
- Working guidance recorded for future agents:
  - Do not treat this one W&B run as a rule change; it was an explicit
    exception requested by the user. Future experiments remain local-only by
    default.
  - Do not over-interpret GPU7 `model_best.pt`: its train/latest metrics were
    useful, but W3 val evaluation was weak (`val/rmsd=15.637760130564372`,
    `val/os=0.4105862743531664`, `val/energy=8.68468721707662`).
  - Successful directions so far: nucleotide-level graph, energy-only training
    with RMSD/OS retained, train-OS monitoring for overfit search, CodeGraph
    first for code navigation.
  - Weak or risky directions so far: pair-node metric/graph details for the
    current objective, W&B-by-default, pure held-out generalization claims from
    train metrics, and depth/width increases without matched-epoch evidence.
- Consolidated direction record:
  `docs/harness/clean76_energy_direction_summary_2026-06-23.md` records the
  verified feasible, weak/infeasible, active evidence, and next-decision rules
  from the recent clean74/clean75/clean76 energy-loss conversation.

## 2026-06-24 Clean76 Hidden256 MP4 Val-Extremes oxView Page

- Built a four-sample oxView comparison page for the completed W&B run:
  `clean76-hidden256-mp4-orient3-energy01-trainos-lr5e4-10000e-gpu4-20260623`.
- Source run summary:
  `outputs/local_clean76_energy_sweep_hidden256_mp4_orient3_energy01_trainos_lr5e4_wandb_10000e_20260623_gpu4/summary.json`.
- Output page:
  `outputs/oxview_compare_clean76_hidden256_mp4_val_extremes/index.html`.
- Samples are the two best and two worst validation designs by final RMSD:
  - `301_eHinge`: `val-best-1`, `rmsd=3.8348`, `os=0.8930`,
    `start_rmsd=5.6698`, `start_os=0.7278`, `nt=30363`, `frags=391`.
  - `280_Ogieva_2025_tail`: `val-best-2`, `rmsd=4.9281`, `os=0.8852`,
    `start_rmsd=5.8226`, `start_os=0.0284`, `nt=9480`, `frags=129`.
  - `200_R4_Hex`: `val-worst-2`, `rmsd=38.3329`, `os=0.0836`,
    `start_rmsd=38.4305`, `start_os=0.2460`, `nt=13471`, `frags=177`.
  - `243_Gclef`: `val-worst-1`, `rmsd=50.8611`, `os=0.0122`,
    `start_rmsd=79.7340`, `start_os=0.0736`, `nt=16036`, `frags=188`.
- Updated `scripts/generate_oxview_comparison.py` so optional YAML fields
  `rank`, `num_frags`, `start_rmsd`, and `start_os` render as HTML metrics
  when present.
- Existing static server was already running from this repository root:
  PID `4640`, command `python3 -m http.server 8000 --bind 127.0.0.1`.
  The page is reachable via the user's tunnel at:
  `http://127.0.0.1:58057/outputs/oxview_compare_clean76_hidden256_mp4_val_extremes/`.
- Verification:
  - `py_compile scripts/generate_oxview_comparison.py` passed.
  - `codegraph sync .` completed after the script edit.
  - `curl -I http://127.0.0.1:8000/outputs/oxview_compare_clean76_hidden256_mp4_val_extremes/index.html`
    returned HTTP 200.
  - `curl -I http://127.0.0.1:8000/oxdna-viewer/` returned HTTP 200.
  - All four `model_prediction_oxview.conf` files start with numeric
    `t = 1000000`, so they are oxView-compatible copies.
  - Playwright browser verification was skipped because the EBD Python
    environment does not have the `playwright` package installed.
- Follow-up update from the user request:
  - Added `197_HCeighteen06_42bp` to the same page as a fifth
    `val-large-gap-good` example.
  - Its displayed metrics are `start_rmsd=13.0561`, `final_rmsd=6.7799`,
    `start_os=0.8083`, `final_os=0.8755`, `nt=14142`, `frags=159`, with
    `rank=start-gap rank 8, good prediction`.
  - Regenerated `index.html`; HTTP verification on port 8000 returned 200 and
    the new `197_HCeighteen06_42bp/model_prediction_oxview.conf` starts with
    `t = 1000000`.
## 2026-07-31 6HB Application-Conditioned Benchmark Priority

- Cross-harness literature and retained-artifact synthesis is recorded in
  `../athena_generativesnupi/docs/6HB_APPLICATION_RESEARCH_20260731.md` and
  the searchable `../athena_generativesnupi/docs/6HB_KNOWLEDGE_GRAPH.json`.
- First EBD inverse-design benchmark priority: compact tetrahedral 6HB cages
  with 42--84 bp edges, compared against a planar triangle/pentagon and hollow
  octahedral cage branch. Samples must have strict Mango -> TALOS -> tacoxDNA
  -> oxDNA metadata and retained start/final configurations.
- The supporting local sweep records 99 `design_passed` runs out of 120, but
  this is only short-oxDNA-start evidence. EBD predictions remain required to
  satisfy the existing nucleotide-frame, Watson--Crick, helix, and oxDNA export
  checks; coordinate-file generation alone is insufficient.
- Independent cross-harness validation ran
  `scripts/ebd_oxdna_physical_eval.py` on the retained C01V01 compact-tetra
  63-bp `md_last.conf` as both target and prediction. The output is
  `outputs/cross_harness_validation_20260731/c01v01_63bp_self_reference_physical_metrics.json`:
  reference pair distance error `0`, helix-step axis `0.9999999983`, and
  duplex retention `1.0`; the geometric-proxy WC F1 is only `0.4822` with
  conflict rate `1.0`. Treat that low proxy score as evidence that explicit
  design pair/crossover labels cannot be replaced with distance proximity.

## 2026-08-03 TALOS240 Rigid-Frame OS Recovery Implementation Start

- User approved the TALOS240 rigid-frame OS recovery specification. The implementation plan is `../athena_generativesnupi/docs/superpowers/plans/2026-08-03-talos240-rigid-frame-os-recovery.md`.
- Added isolated `ebd_oxdna/rigid_frame_recovery.py` and `tests/test_rigid_frame_recovery.py`; the historical trainer and predecessor output root were not modified.
- Implemented frame construction, SO(3), canonical relations, target-free graph serialization, endpoint loss semantics, preflight selection, checkpoint tie-break, and terminal acceptance.
- Verification: 10 new focused tests, `py_compile`, and 11 existing design-edge tests passed. CodeGraph is synced.
- Remaining: immutable recovery CLI, serialized training loop, provenance/reporting, CPU preflight fixture, and GPU wrapper. Do not start `stability1000_rigidframe` until they are complete and tested.

## 2026-08-03 Rigid-Frame GPU Launch Failures

- GPU 6 was selected with approximately 40 GiB free. No valid epoch, checkpoint, or preflight artifact was produced.
- First launch failed before preflight because `lock_output_root()` treated retained `launch_blocked.json` as an immutable prior run.
- Second launch reached sample preparation but raised `KeyError: 'node_train_mask'`: the recovery CLI called legacy `_prepared_on_device()`, whose node-split contract is absent from recovery samples.
- A dedicated migration helper and decoder constructor/device fixes were added, but the next launch still exited before `preflight.json`. The root lock must distinguish known failed-attempt records from immutable training artifacts, and the exact executed path must pass a CPU preflight before another GPU retry.
- Retained evidence: `outputs/talos240_edge_ablation_h256_mp4_20260801/runs/stability1000_rigidframe/train.log`, `run_lock.json`, and `launch_blocked.superseded.json`. State: `failed_preflight_runtime`, not trained or completed.

## 2026-08-03 TALOS240 Rigid-Frame OS Recovery Launch Readiness

- Added `scripts/run_talos240_rigid_frame_recovery.py` and
  `jobs/run_talos240_rigid_frame_recovery_1000e.sh`. The dedicated path checks
  the frozen 217-entry manifest and sidecar-index SHA-256 values, the
  serialized 152/32/33 split, and disables resume/start-spatial/W&B.
- The runtime constructs right-handed frames, records target-free graph hashes,
  runs the first three serialized training IDs through Stage A, verifies the
  independent Stage B initialization hash, then uses 1,000 serial epochs with
  one optimizer step per epoch and validation after every epoch.
- The designated output root contains only a previous `launch_blocked.json`.
  The launcher preserves it as `launch_blocked.superseded.json` before adding
  its immutable run lock; it does not alter `stability1000/B1_pair/seed101`.
- Verification: frozen hashes matched the approved specification; `bash -n`
  passed for the wrapper; `py_compile` and 14 focused rigid-frame/CLI tests
  passed. GPU training has not been launched in this implementation session.
## 2026-10-02 Cross-project evidence audit

- Ran `./init.sh`: harness files are present and the workspace is not a Git
  worktree, so Git cleanliness is not verifiable here.
- The project remains scientifically negative for the current direction:
  its documented held-out W3 evaluation is weak despite train/latest
  improvements, and the TALOS240 rigid-frame recovery remains
  `failed_preflight_runtime` with no valid GPU training artifact.
- This audit adds no new model claim; Geodiff is retained as evidence that
  train-set convergence and physical/held-out generalization are distinct.

## 2026-10-12 oxDNA software copyright V1.0 working package

- Frozen the registration working version as **DNA折纸三维构象预测与oxDNA兼容输出软件 V1.0** around the real `dgnn-lite` target-free inference artifact `outputs/selected80_completed77_h256_mp4_energy01_groupedval_wandb_10000e_20260722/`.
- Added `scripts/build_oxdna_copyright_package.py`, which generates an evidence-backed package without copying third-party source or inventing functions, metrics, authors, or ownership facts.
- Generated `outputs/oxDNA_software_copyright_V1.0/` and `outputs/oxDNA_software_copyright_V1.zip` (7.3 MB): implementation audit/version freeze, four editable DOCX files, six-slide editable architecture/process PPTX, source listing/manifest with hashes, fixed `model_best.pt` and bundle, actual prediction output, help text, and test logs.
- Real verification evidence: prediction CLI and training CLI `--help` passed; `tests.test_ebd_oxdna_shared_rigid_predict` passed 25/25; actual CPU inference generated 5,944 nucleotide records in `prediction.conf` and preserved four box-containment warnings in `prediction.json`.
- OOXML validation passed for all four DOCX files and the PPTX. Source consistency check found no errors across 10 source files and 8,602 lines; ZIP integrity passed. CodeGraph sync reports the index up to date.
- Registration identity, copyright owner, developer relationship, completion date, publication status, rights acquisition, data/weight authorization, official online application form, and final source-page selection remain explicitly marked for human confirmation.

## 2026-10-12 copyright package GitHub upload

- Uploaded `outputs/oxDNA_software_copyright_V1.zip` through the HADO GitHub workflow to `uploads/oxDNA_software_copyright_V1.zip`.
- Remote verification passed at commit `950611e2aea2e5a4f0da06c7c69789fdef60b81f`; branch `main` matches `origin/main`.
- Uploaded size: 7,603,505 bytes. SHA-256: `d9003bc9ebca421e5fff573b0a3ac5959ea8e779bfa47eff58f8081387ba0047`.
- Remote blob exists and the checkout remains clean after the single-file commit.

## 2026-10-13 oxDNA copyright V1.0 rectification

- Implemented `scripts/build_oxdna_copyright_v2.py` from the 2026-10-12 audit.
- Expanded the frozen source boundary from 10 to 15 directly imported project files, including `ebd_mapping.py`, `defect_dataset.py`, `defect_features.py`, `physical_metrics.py`, and the design-edge CLI needed by the copied tests. Third-party `EBD/models/egnn.py` remains outside the original-source selection.
- Added `outputs/oxDNA_software_copyright_V1.0_rectified/05_可复现源码/` with relative-path `run_demo.sh`, `run_tests.sh`, environment record, fixed checkpoint/bundle, a real `.top` and `start.conf` sample, and provenance hashes.
- Rebuilt `源代码鉴别材料.docx` as 60 explicit pages: first/last 1,500 original source lines, 50 lines per page, no cover/listing pages in the code body; `03_源代码鉴别材料/page_map.json` records file/line boundaries. The host has no LibreOffice, so final Word/PDF rendering remains a submission-time visual check.
- Updated the design specification with actual module contracts, relative execution command, regenerated timing (`prediction.json` model elapsed_seconds about 0.62–0.67 s across runs), explicit four box warnings, and the fact that the `E` header is inherited from input rather than recomputed oxDNA thermodynamic energy. Embedded three readable diagrams; regenerated PPTX labels avoid the previous class-name wrap.
- Verification: package build, archive `unzip -t`, all four DOCX validations, independent extraction, source hash/line checks, predict/train `--help`, 25/25 target-free tests, and relative-path CPU inference passed. Extracted prediction has 5,944 nucleotide rows, 0 validation errors, 4 box warnings.
- Archive: `outputs/oxDNA_software_copyright_V1_rectified_20261013.zip`; SHA-256 is recorded by the final build command. Human ownership, developer relationship, completion/publication facts, data/weight authorization, oxView version loading, and official online application remain unresolved.

## 2026-10-13 rectified package upload

- Uploaded `outputs/oxDNA_software_copyright_V1_rectified_20261013.zip` through the HADO GitHub workflow as `uploads/oxDNA_software_copyright_V1_rectified_20261013.zip`.
- Commit: `7f4bdcc3419879fe0b2263395705ff79af384068`; remote `main` and local tree/blob verification passed.
- Uploaded size: 8,753,019 bytes. Archive SHA-256: `17e172f0661df4fe6ccdae40938ef86d7219b7f28346fe75d095ae8daecb7a95`.

## 2026-10-13 copyright reviewfix package rebuild and independent extraction

- Rebuilt `scripts/build_oxdna_copyright_v2.py` with the source-layout PDF review artifact and generated `outputs/oxDNA_software_copyright_V1_reviewfix_20261013.zip` (9,153,374 bytes before upload; final SHA-256 recorded below).
- Independent extraction passed `unzip -t`; the four DOCX files passed the local OOXML validator. The source-layout review PDF is 60 pages and is explicitly a separate layout-check artifact, not a DOCX conversion.
- With `/home/lijingjing/lijj/.conda/envs/ebd/bin/python`, the extracted package ran all 25 unit tests successfully and completed the relative-path CPU demo for 5,944 nucleotides with 0 validation errors and 4 box warnings. The system Python lacks torch, so verification uses the documented EBD environment.
- Remaining review limits: no LibreOffice/Word renderer on this host; long source lines may require final platform visual review. The PDF is a readable pagination check, not a substitute for the official source-document upload. Ownership, official application fields, data/weight rights, and oxView-version validation remain unresolved.

## 2026-10-13 reviewfix upload

- Final rebuilt archive: `outputs/oxDNA_software_copyright_V1_reviewfix_20261013.zip`; size 9,154,607 bytes; SHA-256 `330c270941114e465d7a4d979f535167c703cc5c48ed85f15c7a77428e8b2356`.
- Uploaded as `uploads/oxDNA_software_copyright_V1_reviewfix_20261013.zip` through the HADO GitHub workflow. Commit `b346556a5ece9ac6610c34d7074240cacb223d27`; remote tree and blob ID `31914d3fb058f104c9a984a01a5a5f324646660e` verified.

## 2026-10-19 DNA100 bundle extraction and audit

- Downloaded and verified `DNA100_bundle_20261019.zip` against the published SHA-256.
- Extracted the outer bundle to `DNA100_bundle_20261019_extracted/` and wrote the detailed audit to `DNA100_bundle_20261019_extracted/ANALYSIS.md`.
- The software ZIP is a valid 1,986-file archive; its recorded oxDNA 15/15 tests and TALOS 4 regression checks are present.
- The candidate/control nested ZIPs have no central directory and end mid-entry. Local-header recovery yielded complete C001–C038 42 bp candidates and C001–C037 63 bp controls; the published assets do not contain the full 100/100 structure files claimed by the report.
- Static topology/configuration checks passed for all recovered complete 42 bp candidates and 63 bp controls. No long-time stability simulation was launched because the released data are incomplete and the bundled oxDNA binary requires GLIBC_2.38, unavailable on this host.


## 2026-10-20 Snodin 2019 research materials

- Ran `./init.sh`; required harness files were present.
- Extracted `snodin2019_research_materials.zip` to `snodin2019_research_materials/`; `unzip -t` passed. The archive contains only `README.md`, `SKILL.md`, and `references/paper-reference.md` (no datasets, code, or original paper PDF).
- Reviewed all three files. The skill summarizes Snodin et al. (2019), *Coarse-grained modelling of the structural properties of DNA origami* (NAR 47(3), 1585–1597; DOI 10.1093/nar/gky1304): 2D weave/corrugation mechanisms in oxDNA and 3D average-structure comparison to cryo-EM (reported RMSD 8.4 Å). It stresses verifying implementation details against Methods/Supplementary Data and limiting claims to the studied structures.
- No model code or research results were changed; the extracted directory and this harness record are the deliverables.


## 2026-10-21 TALOS 100-design ensemble geometry plan

- Ran `./init.sh`; harness is present. CodeGraph was consulted for indexed repository structure.
- Identified `DNA_6HB_100_designs.zip` as the likely new-design archive; it contains 100 TALOS 6HB designs and validates with `ZipFile.testzip()`. The archive states that 20 selected designs ran 5,000-step short MD, but the archive has no trajectory files or short-MD terminal configurations.
- Added the staged plan at `docs/superpowers/plans/2026-10-21-talos100-ensemble-geometry-plan.md`: paper-method verification, archive/topology preflight, ensemble acquisition and convergence gates, nodewise geometry/RMSF and motion-coordinate reporting, and validation/deliverables.
- Open definitions: “IMSF” is provisionally interpreted as RMSF; “degrees of freedom” is provisionally scoped as per-node translational covariance/effective motion dimensionality plus rotational fluctuation, not formal constraint counting. Await user clarification.
- No trajectories, simulations, or batch statistics were generated in this planning step.
- After the user asked for concrete simulation settings and analysis ordering, expanded the plan with a proposed convergence pilot: oxDNA2/average-strength interactions, 300 K, 0.5 M Na+, dt=0.001, staged relaxation, 2M-step initial equilibration, 6 preselected designs × 3 velocity replicas, 5M-step initial production blocks, frames every 20k steps (250 frames/block), and checkpointing every 1M steps. These are proposed pilot values, not Snodin paper parameters or launched runs; diagnostics determine extensions and production scale-up.
- Clarified analysis order: accept equilibrated/converged frames -> align whole structures -> average positions/orientations -> calculate per-node RMSF/orientation covariance -> derive empirical motion dimensionality and uncertainty. Formal mechanical DOF is not inferred from six rigid-body coordinates.


## 2026-10-21 Clarified TALOS per-node statistics

- User clarified that the required outputs are exactly: mean position, RMSF, and autocorrelation. Formal degrees of freedom are not requested.
- Revised `docs/superpowers/plans/2026-10-21-talos100-ensemble-geometry-plan.md`: a cadence pilot saves every 1,000 steps on representative small/large designs; initial production sampling defaults to every 5,000 steps (1,000 frames per 5M-step block), adjusted only after the pilot autocorrelation measurement. Mean aligned positions are computed first, RMSF around those means second, then autocorrelation/integrated time/ESS and uncertainty.
- These are proposed values only; no simulation launched.


## 2026-10-21 TALOS100 Slurm pilot submitted

- Revalidated the workspace and archive. `DNA_6HB_100_designs.zip` is valid, but the checked-in extraction only has `design.top`, `initial.dat`, and compact audit files; the purported validation ZIPs fail ZIP integrity. The bundled oxDNA executable needs GLIBC 2.38 (host is GLIBC 2.34).
- Added `scripts/run_talos100_pilot.py` and A100 Slurm scripts. Job `13562` builds oxDNA from the bundled source against node CUDA 11.6, compiles CUDA double precision for A100 (SM80), and runs a 10-step CUDA minimization smoke test. Job `13563` is an 18-task array, dependent on `afterok:13562`: six preselected designs (`6hb_001`, `_020`, `_040`, `_060`, `_080`, `_100`) × three seeds, concurrency cap six. Each task does staged capped minimization with FENE backbone audit, 2,000,000-step equilibration, and 5,000,000-step production; MD uses 300 K, 0.5 M, DNA2, double CUDA, dt=0.001, and saves frames every 5,000 steps (1,000 production frames per replica).
- Input archive SHA-256: `6fea0a528f1326f6e6019197e87c7b37bb7b8833f29e0292a0c3a11f2c441c81`.
- Verification before submission: shell syntax checks and Python `py_compile` passed. At last poll, `13562` was pending priority and `13563` pending on dependency. No simulation task has started; monitor the exact jobs.
- Risk: the build job is a required compatibility gate. If it fails, the dependent array will not run. No 100-design production jobs have been submitted yet; scale-up follows pilot autocorrelation/convergence review.


## 2026-10-21 TALOS100 Slurm queue migration

- A100 jobs 13562/13563 remained pending on priority with no node assigned after repeated authoritative polls; they were cancelled before start.
- Resubmitted to A6000: build/smoke job **13564**, dependent simulation array **13565** (`afterok:13564`, 18 tasks, max 2 concurrent). Build targets CUDA SM86; all input settings and pilot stages remain unchanged.
- Current authoritative state: 13564 `PENDING (Priority)`, 13565 `PENDING (None)`/dependency held; no output files beyond the archive hash, so no simulation has started.

## 2026-10-21 TALOS100 local interactive execution

### Live continuation check 09:51 CST

- Confirmed the only active simulation allocation is interactive Slurm job `13603` on `gpu10`; it has two RTX 6000 Ada GPUs and 12 CPUs. No `sbatch` command was submitted for the current run.
- `6hb_001` replicas 1 and 2 are both running CUDA double-precision oxDNA equilibration. At 09:51:45 CST each had reached step 1,120,000 of 2,000,000; both GPUs were at 99% utilization and both processes were healthy.
- The launcher remains `jobs/run_talos100_local_resume.sh`; it will start production only after a verified equilibration terminal log and then advance through the remaining pilot replicas. No production trajectory or scientific statistics are available yet.
- Revalidation at 10:00 CST: allocation `13603` is still RUNNING; the two equilibration metrics files advanced to steps 1,465,000 and 1,460,000 respectively. Both processes remain active, and neither production metrics file exists yet.
- Revalidation at 10:07 CST: both replicas reached step 1,755,000/2,000,000. No production metrics file exists; the oxDNA processes remain the authoritative live handles. A transient `srun` wrapper exit occurred while probing an absent production file, with no change to the simulation processes.
- Revalidation at 10:14 CST: both `6hb_001` replicas completed equilibration at step 2,000,000 and automatically entered CUDA production. Production metrics reached steps 20,000 and 25,000 respectively; both production oxDNA processes are active. No trajectory statistics have been run on these incomplete production files.
- Revalidation at 10:24 CST: job `13603` remains active, with replica production at 405,000 and 410,000/5,000,000 steps. `nvidia-smi pmon` and compute-process accounting confirm both GPUs are running one oxDNA process each (SM utilization 98% and 87% at the check). Allocation has a 12-hour time limit; the local resume launcher and stage-level verified restart path preserve progress if the allocation expires before all 18 pilot replicas finish.
- Revalidation at 10:31 CST: `13603` remains RUNNING; both `6hb_001` production trajectories reached step 705,000/5,000,000, with both GPU processes confirmed active at 97% SM utilization. Trajectory files continue growing; no production stage is complete yet.
- Added descriptive equilibration QC at `outputs/talos100_ensemble_pilot_20261021/local_runs/6hb_001/equilibration_qc.json`: 401 energy/H-bond records and 20 evenly sampled trajectory frames per replica. Potential energy and H-bond quartile means are broadly plateau-like; sampled radius of gyration decreases 1.81% (replica 1) and 2.41% (replica 2) from first to last quartile. This is not an equilibrium certificate; production convergence and ESS remain the decision criteria. At the time of this QC, production had advanced to 770,000/5,000,000 steps per replica.
- At 10:35 CST, `13603` remained RUNNING; production was 885,000 and 880,000/5,000,000 steps. `nvidia-smi pmon` confirmed both GPUs executing oxDNA. caDNAno/CNDO assets are present in the input archive, but validated virtual-helix/axial-index correspondence has not yet been added; analysis must retain these fields as unmapped until graph mapping is verified.
- At 10:37 CST, the same allocation remained healthy and both production replicas reached approximately 950,000/5,000,000 steps. Both GPUs were confirmed at 97% SM utilization. Allocation time limit remains 12 hours; the current pair is active and no restart or batch submission has been made.
- Implemented `scripts/map_talos_topology_to_cadnano.py` and integrated optional validated node maps into both trajectory analysis entry points. Mapping files for all six pilot designs now cover every topology row one-to-one, agree on all base labels, and reproduce exactly the CNDO across-pair set (6,176–9,996 nt; 3,004–4,886 pairs). A mapped 6,176-row analysis smoke test populated virtual helix, axial index, and scaffold/staple columns. `py_compile` and `codegraph sync .` passed. Current live poll at 10:42 CST: job `13603` RUNNING, `6hb_001` production at 1,170,000 and 1,160,000/5,000,000 steps, both GPUs active.
- Revalidation at 10:47 CST: job `13603` remains RUNNING; current production metrics were about 1.20M steps per replica. FENE checks of the contemporaneous `production.last.dat` snapshots (steps 1.26M and 1.25M, after avoiding a brief file-write window) found 0 bonds outside the FENE domain and 0 outside the buffered range. These are runtime checks, not final production validation.
- Added design-level aggregation to `scripts/analyze_talos100_completed.py`: replica mean structures are Kabsch-aligned before pooling, pooled RMSF includes within- and between-replica variance, and within-replica-centered ACFs are averaged to derive combined tau/ESS. It writes design-level per-node CSV, mean-center XYZ, ACF NPZ, design JSON, and a cross-design summary CSV. Synthetic two-replica aggregation smoke test passed; `py_compile` and `codegraph sync .` passed. Live check at 10:47 CST: `13603` RUNNING, `6hb_001` production at 1.365M and 1.360M/5M steps, both GPUs active.
- Extended topology->CNDO->caDNAno mapping to all 100 designs. Every mapping is full, one-to-one, base-label-consistent, and has an exact caDNAno/CNDO across-pair edge match. Coverage: 863,038 nucleotide rows and 420,802 base pairs. Verified all map JSONs programmatically. Live check at 10:53 CST: job `13603` RUNNING, `6hb_001` replicas 1/2 at 1.62M/1.61M production steps; both GPUs active. No complete production trajectory yet.
- Latest re-read of the task file and live check at 10:58 CST: allocation `13603` is RUNNING; `6hb_001` replicas 1/2 are at 1.80M/1.785M of 5M production steps, with checkpoint `t` values matching metrics. Both oxDNA processes remain active. A full read of an actively growing trajectory was stopped to avoid following the writer indefinitely; final trajectory validation remains scheduled after production completion.

- Read the user-provided task specification from `/home/lijingjing/lijj/.codex/attachments/b865f1f5-6db2-4b7a-a959-6cedb4e42fc2/pasted-text-1.txt` before continuing.
- The Slurm build/array records above are historical and no longer describe the active run. The current local interactive job is **13603**, running on `gpu10` with two RTX 6000 Ada GPUs allocated and 12 CPUs requested (`--gres=gpu:2 --cpus-per-task=12`). No new `sbatch` job was submitted.
- The CUDA double-precision oxDNA executable is present at `outputs/talos100_ensemble_pilot_20261021/oxdna_cuda_build/bin/oxDNA`; the short smoke pipeline produced minimization, conditioning, CUDA equilibration, and CUDA production artifacts.
- The live local pilot launcher is running `6hb_001` replicas 1 and 2. Authoritative in-job inspection via `srun --jobid=13603 --overlap` found both oxDNA processes active in the equilibration stage; GPU 1 was at 99% utilization at the check. Both replicas completed minimization and two conditioning stages and are writing approximately 173 MB equilibration trajectories. The 2,000,000-step equilibration is not yet complete, so production and trajectory statistics have not started.
- The required outputs remain mean aligned nucleotide position, positional RMSF, and position autocorrelation with integrated autocorrelation time/ESS. Formal degrees of freedom and “IMSF” are not part of the clarified deliverable.
- Added `scripts/analyze_talos100_trajectory.py`, which reads oxDNA trajectories, performs whole-structure Kabsch alignment, computes per-nucleotide mean positions/RMSF and vector positional ACF with integrated correlation time/ESS, and writes CSV/NPZ/XYZ/JSON outputs. A two-frame smoke trajectory completed the parser and output check; its ESS is correctly only 2 and is not treated as a scientific result. The script records that the current `.top` files provide strand/base/backbone connectivity but no virtual-helix or axial-index mapping.
- The latest live poll confirms both equilibration oxDNA processes remain active on job 13603. Their metrics files have reached approximately steps 730,000 and 735,000 respectively (2,000,000 requested), with GPU utilization at 99% during the check. No production file exists yet.
- The original launcher step ended before completing its first pair, while allocation 13603 remained alive. Per the user's explicit no-`sbatch` instruction, resumed the run inside the same interactive allocation using `jobs/run_talos100_local_resume.sh` (session 66513). The resumed launcher started `6hb_001` replicas 1 and 2 with `--resume`; both are again running CUDA equilibration from the last valid conditioning state, with the two GPUs active. No Slurm batch submission was made.
- `scripts/run_talos100_pilot.py --resume` now detects verified completed stage artifacts and skips them. Incomplete equilibration/production stages are rerun from the last valid completed stage; this is stage-level recovery and does not claim to preserve partial frames from an interrupted stage.
- Added `scripts/audit_talos100_inputs.py` and ran it directly against `DNA_6HB_100_designs.zip`. The authoritative archive hash is `6fea0a528f1326f6e6019197e87c7b37bb7b8833f29e0292a0c3a11f2c441c81`; the manifest has 100 unique designs, and all 100 passed checks for topology/initial coordinate counts, finite 15-column oxDNA rows, designed-pair counts, and presence of caDNAno JSON, CNDO, and sequence assets. Reports are in `outputs/talos100_ensemble_pilot_20261021/input_audit/`.

- Extended `scripts/analyze_talos100_trajectory.py` to accept authoritative `designed_pairs.txt` and emit per-node designed partner indices alongside topology connectivity; smoke output verified the new CSV columns. Virtual-helix/axial mapping remains explicitly marked unavailable until a validated row correspondence is established.
- Rechecked the caDNAno/CNDO mapping question against `6hb_001`: the CNDO `dnaTop` sequence has 6,176 rows but does not equal the oxDNA topology sequence (only 1,579 same-position base labels), so virtual-helix/axial indices cannot be assigned by row position. The current output deliberately keeps those fields `unmapped` until a converter-level correspondence is recovered; designed-pair indices remain authoritative.
- Added `scripts/map_talos_topology_to_cndo.py` and recovered a unique 6,176-node topology-to-CNDO correspondence for `6hb_001` using iterative labeled backbone+designed-pair graph refinement; all mapped base labels agree. This is a validated converter-row correspondence artifact at `outputs/talos100_ensemble_pilot_20261021/input_audit/6hb_001_topology_to_cndo.json`. It establishes a route to connect caDNAno virtual-helix/axial metadata through a second graph mapping, but those fields are not yet populated in the analysis CSV.
- Re-ran topology-to-CNDO graph correspondence for all six preselected pilot designs. Each produced a unique full-node mapping with matching base labels: 6hb_001 (6176 nt), _020 (7578), _040 (8442), _060 (9246), _080 (9594), and _100 (9996). Per-design JSON mappings are stored under `outputs/talos100_ensemble_pilot_20261021/input_audit/`.
- Latest live poll: job 13603 remains active without batch submission; both 6hb_001 replicas are in CUDA equilibration at approximately step 915,000 of 2,000,000, with both GPUs near 99% utilization. No production trajectory exists yet.


## 2026-10-21 TALOS100 local production checkpoint

- Re-read the user-provided task specification before resuming. User's instruction remains to run locally and not submit `sbatch`. Existing interactive allocation 13603 is still RUNNING on gpu10; it has 12 CPUs and 2 RTX 6000 Ada GPUs, and both GPUs were active at the latest in-allocation check. The existing local resume launcher is running two independent `6hb_001` replicas; both CUDA oxDNA processes remain alive.
- Current `production.metrics.dat` tails show replica 1 at step 1,880,000/5,000,000 and replica 2 at 1,860,000/5,000,000. Production trajectories are still growing.
- Added `scripts/validate_talos100_trajectory.py`; it compiles successfully. Its fixed-byte-boundary snapshot scan validated replica 1 at 376 frames / step 1,880,000 and replica 2 at 375 frames / step 1,875,000. All 6,176 nucleotide rows per frame had 15 finite values; frame spacing is exactly 5,000 steps; no partial trailing frame was observed. These are live partial-production QC snapshots, not complete trajectories or analysis inputs.
- No statistics were computed from incomplete production. Continue monitoring the existing interactive run; after complete trajectories, perform strict end-step/frame-count QC before analysis. No `sbatch` was submitted.

- Follow-up live poll on allocation 13603 confirms both oxDNA production processes remain present and advancing; latest metric steps are replica 1: 2,370,000 and replica 2: 2,340,000 of 5,000,000. GPU instantaneous utilization samples alternated between 0% and 99% for one card, while trajectory metrics continued advancing; both cards were simultaneously at 99% in adjacent polls.

- Latest revalidation after re-reading the task spec: allocation 13603 is RUNNING, both local oxDNA production processes are alive, and metrics advanced to replica 1: 2,590,000 and replica 2: 2,560,000 of 5,000,000. No restart or duplicate process was needed; no `sbatch` submitted.

- Re-read the task and revalidated the active run. Allocation 13603 remains RUNNING, both production processes advance, and no `sbatch` was submitted. A fresh fixed-boundary snapshot scan validated replica 1 through step 2,715,000 (543 frames) and replica 2 through step 2,700,000 (540 frames): 15 finite values for each of 6,176 nucleotide rows, exact 5,000-step cadence, no incomplete trailing frame. Both remain incomplete vs 5,000,000 steps, so no statistical analysis yet. Metrics continued to replica 1: 2,755,000 and replica 2: 2,720,000 during/after the scan.

- Continued live monitoring confirms the same two CUDA production processes and interactive allocation 13603 remain active. They advanced to replica 1: 2,855,000 and replica 2: 2,825,000 of 5,000,000; no restart was needed.

- Latest continuation poll: allocation 13603 and both production processes remain active; metrics advanced to replica 1: 3,090,000 and replica 2: 3,055,000 of 5,000,000. A GPU-utilization sample showed one device at 0%, but the oxDNA process and trajectory metrics remain active; adjacent polls show both cards at 99%.

- Continued live polling verified allocation 13603 and both production oxDNA processes remain active. Latest metrics: replica 1 at 3,355,000 and replica 2 at 3,320,000 of 5,000,000. No batch submission and no premature analysis.

- Continued local-only monitoring after re-reading task spec: allocation 13603 remains RUNNING and both production trajectories continue writing. Latest metrics are replica 1: 3,680,000 and replica 2: 3,650,000 of 5,000,000. No sbatch submitted and no incomplete trajectory used for analysis.

- Local production checkpoint: allocation 13603 and both oxDNA processes remain active; latest steps are replica 1: 4,200,000 and replica 2: 4,180,000 of 5,000,000. No sbatch submitted; incomplete trajectories still excluded from analysis.


## 2026-10-21 TALOS100 first two production replicas complete

- `6hb_001` replicas 1 and 2 reached 5,000,000 production steps locally and their oxDNA logs contain `END OF THE SIMULATION, everything went OK!`. Strict validator results were saved under `outputs/talos100_ensemble_pilot_20261021/local_runs/6hb_001/qc/`: each has exactly 1,000 frames, 6,176,000 finite coordinate rows, first step 5,000, final step 5,000,000, interval 5,000, and zero trailing incomplete bytes.
- The existing local launcher automatically advanced to `6hb_001` replica 3 and `6hb_020` replica 1 within interactive allocation 13603; no `sbatch` was submitted. Replica 3 and subsequent designs remain incomplete. Do not start final pilot statistics until the planned independent replicas are complete and QC-gated.

- After replicas 1/2 completed, the local launcher automatically started `6hb_001/replica_3` and `6hb_020/replica_1` equilibration under allocation 13603. Latest live steps are about 230,000/2M and 180,000/2M, respectively; both CUDA oxDNA processes are alive and both GPUs active. The three-replica pilot remains incomplete, so formal pooled mean/RMSF/ACF analysis has not started.

- Continued monitoring confirms local-only pilot activity: `6hb_001/replica_3` equilibration is ~655,000/2,000,000 and `6hb_020/replica_1` ~590,000/2,000,000; both oxDNA processes remain alive. Completed replica 1/2 QC artifacts remain valid; pooled statistics await the planned three-replica pilot.

- Continued local-only monitoring after re-reading the task: `6hb_001/replica_3` equilibration reached ~825,000/2,000,000 and `6hb_020/replica_1` ~755,000/2,000,000; both processes remain live in allocation 13603. No new submission.

- Latest verified local poll: allocation 13603 remains RUNNING; `6hb_001/replica_3` equilibration reached 1,000,000/2,000,000 and `6hb_020/replica_1` 920,000/2,000,000. Both oxDNA processes and GPUs remain active. Formal three-replica statistics are still deferred.

- Continued local-only monitoring: `6hb_001/replica_3` equilibration reached 1,225,000/2,000,000 and `6hb_020/replica_1` 1,135,000/2,000,000. Both GPUs reported ~99% utilization; no duplicate launch or sbatch submission.

- Continued local checkpoint: `6hb_001/replica_3` equilibration reached 1,350,000/2,000,000 and `6hb_020/replica_1` 1,260,000/2,000,000. Both metrics continue advancing; one process was briefly sleeping in the OS scheduler but did not stop.

- Verified live checkpoint: `6hb_001/replica_3` equilibration at 1,430,000/2,000,000 and `6hb_020/replica_1` at 1,335,000/2,000,000. Both GPUs ~99% utilized and both local runner/oxDNA processes are alive; they will enter production after equilibration.

- Live checkpoint: `6hb_001/replica_3` equilibration at 1,580,000/2,000,000 and `6hb_020/replica_1` at 1,480,000/2,000,000. Both local processes continue advancing; no sbatch submitted.

- Verified checkpoint: `6hb_001/replica_3` equilibration at 1,735,000/2,000,000 and `6hb_020/replica_1` at 1,630,000/2,000,000. Both remain active and near the end of equilibration; production will follow automatically.


## 2026-10-21 resource configuration refresh

- Re-probed the actual environment rather than relying on prior records: host `gpu10` exposes 96 online logical CPUs (48 physical cores across two sockets) and two RTX 6000 Ada GPUs with 49,140 MiB each. Interactive job 13603 reports `NumCPUs=96`, `CPUs/Task=12`, and `gres:gpu:2`; both GPUs are visible and active.
- Updated `jobs/run_talos100_local_resume.sh` and `jobs/run_talos100_local_parallel.sh` to derive CPU threads from `SLURM_CPUS_ON_NODE`/`SLURM_JOB_CPUS_PER_NODE`, divide them across visible GPUs, and honor `TALOS_OMP_THREADS_PER_GPU` for explicit overrides. Shell syntax validation passed. The already-running child processes retain their launch-time environment; the refreshed setting applies to the next local continuation and is not used to interrupt active simulations.

- Post-resource-refresh checkpoint: allocation 13603 remains RUNNING, both GPUs are ~99% utilized, and the two new production processes are healthy. `6hb_001/replica_3` is at 630,000/5,000,000 production steps; `6hb_020/replica_1` at 490,000/5,000,000. Their equilibration files both reach 2,000,000 steps.

- Live checkpoint: `6hb_001/replica_3` production at 715,000/5,000,000 and `6hb_020/replica_1` at 570,000/5,000,000. Both oxDNA production processes remain alive and metrics advance; one instantaneous GPU utilization sample was 0%, but the adjacent process/trajectory evidence shows no stall.

- Live checkpoint after re-reading task: `6hb_001/replica_3` production at 795,000/5,000,000 and `6hb_020/replica_1` at 645,000/5,000,000. Both oxDNA processes and both GPUs remain active; no sbatch submitted.

- Live growth check: `6hb_001/replica_3` production reached 895,000/5,000,000 and trajectory size 302,608,799 bytes; `6hb_020/replica_1` reached 740,000/5,000,000 and 306,894,786 bytes. Both GPUs ~99% and both oxDNA processes remain healthy.

- Live allocation checkpoint: job 13603 has ~7h22m remaining (12h limit). `6hb_001/replica_3` production reached 1,070,000/5,000,000 and `6hb_020/replica_1` 910,000/5,000,000; both oxDNA processes remain alive and metrics advance.

- Live checkpoint: job 13603 has about 7h16m remaining. `6hb_001/replica_3` production is 1,220,000/5,000,000 and `6hb_020/replica_1` 1,050,000/5,000,000; both GPUs ~99% and processes healthy.

- Live checkpoint: job 13603 has roughly 7h14m remaining. `6hb_001/replica_3` production reached 1,325,000/5,000,000 and `6hb_020/replica_1` 1,145,000/5,000,000; both GPUs ~99%, processes healthy.

- Live checkpoint: `6hb_001/replica_3` production 1,395,000/5,000,000 and `6hb_020/replica_1` 1,215,000/5,000,000. Both processes remain healthy; both GPUs ~99%.

- Live checkpoint: `6hb_001/replica_3` production 1,470,000/5,000,000 and `6hb_020/replica_1` 1,285,000/5,000,000; job 13603 remains active and both GPUs 99%. No complete new trajectory for final QC yet.

- Live checkpoint: `6hb_001/replica_3` production at 1,550,000/5,000,000 and `6hb_020/replica_1` at 1,365,000/5,000,000; both oxDNA processes and GPUs remain healthy.

- Live checkpoint: `6hb_001/replica_3` production 1,685,000/5,000,000 and `6hb_020/replica_1` 1,495,000/5,000,000; both oxDNA processes and both GPUs remain healthy (~99%).


## 2026-10-21 monitoring paused by user

- User requested stopping active monitoring while allowing the local simulation to continue in the background. Final confirmation before stopping polls: allocation 13603 is RUNNING; two oxDNA production processes remain alive (PIDs 685725 and 685833), with `6hb_001/replica_3` at 1,800,000/5,000,000 and `6hb_020/replica_1` at 1,605,000/5,000,000. No `sbatch` submitted.
- Runtime estimate from completed `6hb_001` replicas: equilibration ~2,956--2,967 s (49--50 min) and production ~7,570--7,609 s (126--127 min), plus short minimization/conditioning. Thus one replica of this size takes roughly **3 hours total** under the current two-GPU local setup; the 5M-step production phase alone is about **2 h 6 min**. Larger designs may take longer.
- Do not poll or interrupt the running processes unless the user asks to resume monitoring or a later task requires a status check.

- Monitoring remains paused per user request; no process polling or intervention was performed in this continuation. Independent local verification passed: `py_compile` for all TALOS analysis/validation/mapping runners and `bash -n` for both local launchers. Background simulation is left untouched.

- With background monitoring still paused, reviewed `scripts/analyze_talos100_completed.py`: it selects only `run_metadata.json` entries with `status == completed`, verifies production/topology presence, analyzes each completed replica, then pools replica means/RMSF/ACF and writes per-nucleotide CSV, XYZ, NPZ, JSON, and design summary CSV. Thus incomplete background files cannot enter formal analysis accidentally.

- Added `jobs/analyze_talos100_when_complete.sh`, a local post-processing gate that checks all six pilot designs × three replicas have `run_metadata.json.status == completed` before invoking `analyze_talos100_completed.py`. It never submits jobs or launches MD. Shell syntax passed; a current-state test correctly refused analysis with 16 incomplete replicas and exit code 2, producing no analysis output.

## 2026-10-21 max_io configuration

- Verified the generated oxDNA inputs omitted `max_io`, so oxDNA used its documented default output cap of 1 MB/s.
- Updated `scripts/run_talos100_pilot.py` to emit `max_io = 700` for all newly generated stages. `py_compile` passed and a temporary generated input confirmed the line is present.
- Existing oxDNA processes were not restarted; changing the runner cannot alter an input already loaded by a running process. The 700 MB/s setting applies on the next stage launch or continuation.

## 2026-10-21 max_io=700 benchmark

- Per user instruction, stopped the lower-progress `6hb_020/replica_3` task: production was approximately 990,000/5,000,000; both its runner and orphaned oxDNA child were terminated, while its partial files were retained.
- Ran local CUDA benchmark `6hb_040/replica_1` on the released GPU with `max_io = 700`, 200,000 equilibration steps, and 500,000 production steps at 5,000-step output interval. It completed successfully.
- Production took 748.2 s for 500,000 steps (668.27 steps/s), equivalent to 7,482 s for 5M steps. The prior 6hb_001 run at the old default cap took 7,569.59 s for 5M (660.54 steps/s), a normalized difference of about 1.2%; designs differ in size, so this is not an isolated max_io effect.
- The benchmark trajectory averaged 0.309 MB/s of output, below the old 1 MB/s cap; therefore max_io was not the bottleneck in this test and no clear speedup can be attributed to 700 MB/s.

## 2026-10-21 disk versus oxDNA output throughput

- Ran direct-I/O sequential tests using 512 MiB temporary files (all removed afterward): project Ceph mount measured 28.88 MB/s write and 109.30 MB/s read; node-local XFS `/tmp` measured 425.62 MB/s write and 521.35 MB/s read. These are single-run measurements under current shared-system load, not guaranteed filesystem maxima.
- The `max_io=700` 6hb_040 benchmark emitted 231,054,228 bytes over 748.2 s = 0.309 MB/s. Its step throughput (~668 steps/s) and 5,000-step frame interval imply only ~0.13 frames/s; at ~2.31 MB/frame this output rate is expected. It is far below even the default 1 MB/s cap and below measured Ceph throughput, so the low observed trajectory rate comes from oxDNA's simulation/output cadence, not a saturated disk or `max_io` cap.

## 2026-10-21 oxDNA performance diagnosis and skill update

- Reviewed the bundled oxDNA v3.7 `performance.md`, `input.md`, and `scaling.md`, and CodeGraph-traced `BackendFactory`/`LangevinThermostat` implementation. Docs describe 1-2 days as common for well-sampled origami (not a single short 5M-step trajectory), recommend typical `dt` 0.001-0.003 and `verlet_skin` 0.05-0.2, and note CUDA cell geometry/options are workload-dependent.
- Existing 6,176-nt replicas internally report 1.354-1.360 ms/step, with 91.6-91.8% in `Forces`, ~4.8-4.9% in `Observables`, and aggregate output 0.474-0.476 MB/s. The 8,442-nt 6hb_040 run reported 1.356 ms/step, 92% `Forces`, 5% `Observables`; both observed output rates are below the original default 1 MB/s cap.
- Controlled output-cadence probe on same 6hb_040 saved configuration: output every 5,000 steps gave 1.356 ms/step and `Observables` 5.0%; output only at the end gave 1.303 ms/step and `Observables` 0.2%. This indicates a modest output overhead (~4% in that run), but force calculation remains dominant.
- `cells_auto_optimisation=false` 250k-step probe gave 1.270 ms/step vs ~1.303 ms/step default one-frame control; it used 54^3 cells/69.08 MB rather than 26^3/35.47 MB. One short run is not enough to adopt as a production setting.
- `CUDA_sort_every=10` 100k-step probe gave 1.342 ms/step; no demonstrated gain (not a matched-length comparison). `use_edge=true` failed immediately because the executable rejects it with double precision.
- Build cache confirms Release `-O3`, CUDA architecture 89, `CUDA=ON`, `CUDA_DOUBLE=ON`; BackendFactory source confirms this executable supports CUDA double only, not mixed precision. Thus precision reduction would require a separate build and scientific validation, and was not tested/adopted.
- Direct-I/O filesystem test and `max_io` evidence are recorded above. Overall, no wrong simulation setting or storage bottleneck is established. Current measured bottleneck is force computation on one RTX 6000 Ada per trajectory; output frequency contributes a smaller cost. User-authorized measurement runs were local; no `sbatch` submitted. Updated `/home/lijingjing/lijj/.codex/skills/oxdna-diagnostics/SKILL.md` and added its case-specific `references/performance-io-lessons.md`.
- Follow-up source tracing of `SimBackend::print_observables` confirmed `max_io` is a cumulative-rate guard that throws after 30 seconds if bytes/time exceeds the value; it does not throttle/sleep. Thus raising it from the 1 MB/s default to 700 MB/s does not speed up a passing run; only prevents a rate-limit abort. Skill now records this v3.7 implementation-specific fact, in addition to the manual wording.
- Timer-source caveat: CodeGraph lookup of `Timings.cpp` shows non-MOSIX builds use C `clock()` for internal timing, which measures process CPU time rather than wall-clock elapsed time. Thus `Forces`-dominant percentages describe CPU-time profile, not the complete wall-time split; e.g. the 500k repeated-output run was 748.2 s in the runner vs 678.2 s in oxDNA's internal timer. The gap is observed, but these measurements do not isolate its cause. Updated the skill workflow/reference accordingly.

## 2026-10-21 oxDNA dt=0.005 local probe

- Ran a separate local CUDA-double production probe on GPU 1 using the completed `6hb_001/replica_1` `equilibrate.last.dat` as its initial configuration; no Slurm submission and no existing pilot outputs were overwritten. PID 693019, seed 2026102401.
- Settings: DNA2, 300 K, 0.5 M salt, Langevin `diff_coeff=2.5`, `dt=0.005`, 3,000,000 steps, `print_conf_interval=3000` (1,000 trajectory frames), `max_io=700`, `verlet_skin=0.2`.
- oxDNA v3.7 exited normally at step 3,000,000; internal timer reported 4,938.03 s (engine timer is CPU-time based in this build, not wall time). Output trajectory is 1.69 GB. Structural parse verified 1,000 complete frames, 6,176 nucleotides/frame, final frame at step 3,000,000; metrics cover steps 0 through 3,000,000.
- Energy and hydrogen-bond count remained in a narrow range in the sampled metrics, with no observed numerical blow-up. This completion/trace check does **not** establish that `dt=0.005` gives accurate or physically equivalent dynamics; treat it as a timestep probe, not validated production settings. Results: `outputs/oxdna_dt005_probe_20261021/6hb_001_replica1/`.

## 2026-10-23 TALOS100 mixed/edge 5M background campaign

User authorized all 100 original TALOS 6HB monomers, 5,000,000 MD steps each, no saved production frames before 3M, exactly 1,000 late frames, background local execution. Implemented `scripts/run_talos100_monomer_5e6.py` and `jobs/run_talos100_monomer_5e6_background.sh`. The 100 input directories under `dna6hb_check/dna_6hb_100/structures` all have topology/configuration files (863,038 nt total).

Current campaign: `outputs/talos100_ensemble_5e6_20261023/`, tmux session `talos100_5e6_20261023` on gpu16, launcher PID 1408889, Python PID 1408900, first production oxDNA PID 1409035. Local GPU0 is RTX 6000 Ada; no sbatch. Verified live at >264,000 production steps with CUDA mixed/edge startup messages and GPU utilization. Campaign remains in progress; no completed scientific statistics claimed. It processes designs sequentially and records failures without declaring them complete.

Protocol: DNA2, 300K, 0.5M salt, dt=0.001, Bussi tau=1000, newtonian_steps=53, verlet_skin=0.3. CPU capped minimization/conditioning (up to 4 x 1500 steps); normal-potential CUDA production only after backbone audit passes. Rebuilt executable `outputs/oxdna_mixed_build2_20261023/bin/oxDNA`, SHA256 6b7cf76fb5c3d757b49261198ad105aac64fe9b9947a9faf9d85a1df223c9acf. Original designs, prior pilot and double build are preserved.

Important corrections: CUDA does not support sim_type=min; CPU preparation needs refresh_vel=1 for these zero-momentum source exports. Prior nohup descendants disappeared after tool-session cleanup; tmux is independently reparented to PID1 and survives commands. Fixed misplacement of flush=True in json.dumps. The abandoned two-stage production was replaced before production launch: native data_output_2 configuration observable supports start_from and stop_at, so a single uninterrupted 5M run saves steps 3,002,000..5,000,000, interval 2,000, exactly 1,000 frames. Default trajectory goes to /dev/null; no pre-window production frames are saved. Preparation checkpoints remain separately labeled.

318.1 MB/s was NOT established as a system bandwidth ceiling. Corrected misleading initial summary/docstring. Set max_io=1e30 (the backend constructor's effectively unbounded value), removing a practical software abort threshold. It is not actual filesystem bandwidth. First preparation stages resumed from earlier completed checkpoints retain historical input values; all new stages, including live production, use 1e30.

Completion gate: exact frame timestamps/count, n x 15 finite coordinate fields per frame, valid box/energy headers and no trailing frames. Stream Kabsch alignment removes whole-structure motion; running coordinate average/RMSF and SO(3)-projected mean orientation yield aligned_mean.conf, aligned_mean_statistics.npz, trajectory_qc.json. Mean includes a backbone audit and is a geometric average, not certified equilibrium or automatically safe for restarting MD. Metadata marks completed only after production and QC/average pass.

Verification: ./init.sh passed; Python3.7 py_compile and bash -n passed. Real 6hb_001 CUDA smoke completed 5,000 steps in 22.34 s, saved exactly 100 frames at 3020..5000 with interval20, no trailing partial frame; average export passed. Synthetic 1,000-frame test passed exact production timestamps, rigid-motion invariance (RMSF <1e-10), mean orientation unit length/orthogonality, and extra trailing-frame rejection. Evidence: campaign verification.json; real smoke `/tmp/talos_schedule_smoke_20261023` (temporary). First live production input/log and growing metrics independently verified; trajectory remains empty before 3M as required. CodeGraph exploration returned unrelated existing symbols for this new script; subsequent verification uses exact files/runtime, no post-edit index dependency.

Monitor: tail -n 30 outputs/talos100_ensemble_5e6_20261023/runner.log; inspect per-design run_metadata.json and production.metrics.dat. tmux attach -t talos100_5e6_20261023. Runner lock prevents duplicate launch. Resume launcher skips completed designs and completed stages, otherwise restarts incomplete stage from its input; it does not continue a partial MD counter. Background work is not a guarantee of completion; check failed metadata after campaign finishes. Existing older pilot pause instructions remain unchanged.

## 2026-10-23 23:39 — A6000 Slurm continuation, job 14699

Latest user explicitly authorized resuming this campaign with sbatch on A6000, superseding earlier local-only launch preference for this campaign. Status audit found 2/100 designs completed (6hb_001,002; each 5M steps and 1000 frames, production wall 1133.48s/1095.35s), 6hb_003 interrupted in CPU minimization at 21:04 with stale running metadata, 97 not started. No live campaign process/tmux remained. Interruption cause not established. Completed means have 77/96 FENE-outside backbone bonds; geometric means are not restart-valid production configurations.

Added jobs/run_talos100_monomer_5e6_a6000.sbatch and submitted job 14699 on A6000: one GPU, four CPUs, 16GiB, four-day limit, exclude=gpu29. Job is PENDING (Priority) at verification, StartTime unknown. Do not claim live MD resumed until scheduler starts it. No duplicate local campaign was launched. Existing user allocation 14531 and unrelated jobs untouched.

Batch first logs assigned hardware/CUDA visibility and runs a separate 100-step normal-potential mixed/edge CUDA preflight from the completed 6hb_001 production checkpoint in slurm_preflight_14699; it does not use the geometric average. Failed preflight exits before processing designs. It then invokes the original lock-protected sequential launcher, skips completed 001/002, restarts incomplete 003 preparation, and continues through 100. Simulation/sampling parameters unchanged: 5M continuous production, frames 3002000..5000000 every 2000 (1000), max_io=1e30, post-run strict QC and average/RMSF. OMP/OpenBLAS/MKL threads limited to 1. Final aggregate summary exits nonzero unless all 100 metadata records are completed. Existing completed results preserved; unfinished stage restarts from its input.

Architecture check: actual CUDA code is in outputs/oxdna_mixed_build2_20261023/src/liboxdna_common.so, not the oxDNA executable. cuobjdump confirms sm_86 and sm_89 as part of CUDA_COMMON_ARCH multi-architecture build, despite cache CMAKE_CUDA_ARCHITECTURES=89; no rebuild required for Ampere A6000. Runtime check awaits assigned node.

Verification: ./init.sh passed, bash -n batch script and Python3.7 py_compile runner passed; both embedded Python blocks compile. sbatch --test-only accepted request. Actual sbatch returned 14699; scontrol confirms BatchFlag=1, A6000 partition, requested resources and persistent Slurm stdout/stderr paths. Durable submission manifest: outputs/talos100_ensemble_5e6_20261023/slurm_submission_14699.json.

Monitor: squeue -j 14699; scontrol show job 14699; sacct -j 14699 --format=JobID,State,Elapsed,ExitCode; tail outputs/talos100_ensemble_5e6_20261023/slurm-14699.out and runner.log. Slurm scheduling is independent of this interactive session. Once running, verify slurm_preflight_14699/preflight.json and current production logs/metrics. Do not duplicate/resubmit without checking job 14699 first.

## 2026-10-23 23:55 — Local raw-design preflight passed before Slurm release

User requested a local execution test before batch continuation. Held pending job 14699 via scontrol hold (JobHeldUser), verified idle GPU0 was within own active allocation 14531 on gpu16 (actual RTX 6000 Ada, partition A6000). No other jobs were interrupted.

Ran raw 6hb_003 in independent outputs/talos100_local_preflight_20261023_2352/6hb_003 using original runner/executable, same seed and physical/backend parameters, shortened only production to 100000 and sampling gate to 60000. CPU min1500 completed in39.84s, conditioning1500 in40.28s; final prep FENE outside count0. Continuous normal-potential CUDA mixed+edge MD completed 100000 steps in22.27s outer wall (engine21.3079s); return0, exact final step100000, normal completion marker. Observed20 complete frames at62000..100000 interval2000; no trailing partial frame. QC, average.conf and RMSF NPZ exported. Geometric average still has99 bonds outside FENE; this does not invalidate trajectory format completion but means mean.conf is not a certified physical restart state. No equilibrium/scientific-equivalence claim.

All runtime assertions passed before scontrol release14699. Reused existing submitted job rather than submitting duplicate. Full campaign remains 2/100 completed and will restart original003 at5M when allocated, preserving separate preflight outputs. Batch remains pending unless scheduler changes it. Manifest: outputs/talos100_ensemble_5e6_20261023/local_preflight_before_release_14699.json. Settings in production runner/script remain5M and3002000..5000000/2000/1000frames (test altered in-memory module constants only). Assigned-node CUDA preflight remains in sbatch script as additional hardware check.

## 2026-10-23 — User asks to wait and identify prior replicated 5M sample

User said wait and questioned whether every design can pass, asking which previous sample had 5M-step replicas. Held Slurm14699 again (JobHeldUser); leave held pending further user direction. No simulations launched in this audit. Main identified sample: 6hb_001, prior double-precision pilot local_runs/6hb_001/replica_1,2,3. All three have completed metadata, 2M equilibration +5M production, exact production.last.dat t=5000000 and normal-ending production log. Production wall times7569.59,7608.54,7451.39s. 6hb_020 replicas1,2 also complete5M; replica3 stopped with last step1106517 and normal termination marker (normal marker alone does not establish full-length completion). 6hb_040 replicas1,2 incomplete at4410000/525000. A short 003 mixed/edge test plus full mixed001/002 does not establish all100 can pass. No new trajectory QC or equilibrium assessment performed; completion evidence here is metadata+last-step+log, not statistical convergence. Prior double pilot and current mixed single-run campaign are distinct.

## 2026-10-24 — Active matched TALOS001 precision experiment

User requests rerun001 with current mixed precision at same old step/frame counts and compare mean shapes/distribution evidence with old3 replicas. Full100-design job14699 remains held. Started independent outputs/talos001_precision_comparison_20261024 at00:00:52 in tmux talos001_precision_20261024 under current allocated gpu16/14531 (expires01:46). Sequential3 mixed/edge replicas, each exact corresponding legacy input decks, same Langevin/diff_coeff2.5, dt.001, skin.2, temperature300K,salt.5, same seed and corresponding original conditioning_2.last.dat. CPU checkpoint copied with SHA256 rather than repeated; newly simulated2M equilibration+5M production, every5000 steps400/1000frames. Changes restricted to backend_precision=mixed, use_edge=true,max_io1e30. This compares mixed+edge combination to double; not isolated precision causality. Run scripts/run_talos001_precision_comparison.py, then auto-run scripts/analyze_talos001_precision_comparison.py on success. Current replica1 is live in equilibration. Do not duplicate.

Analysis plan: strict full trajectory QC, identical topology/reference, all-nucleotide common Kabsch gauge, mean position and projected orientation exports, per-nucleotide RMSF, pairwise common-gauge/refitted mean RMSDs, scalar Rg/RMSD/gyration slow-mode ACF/ESS, matched3pair exact sign flips (minimum p.25), exploratory unpaired label test(minimum p.10), autocorrelation-sized nonoverlapping batch bootstrap hierarchical over seed pairs, block-size and last-half sensitivity. Bootstrap norm intervals are nominal/exploratory with n3 and norm boundary; no probability of equal distributions can be inferred. Equilibration transient descriptive only; production primary. Illustrative equivalence margin grid is sensitivity only, not accepted physics tolerance. Equal mean does not establish full distribution equivalence. Agent stats_review invoked under academic-research-suite experiment-agent skill and authored docs/TALOS001_PRECISION_STATISTICAL_REVIEW.md; second review pending. New scripts Python3.7 py_compile pass. Old-stage baseline analysis running independently to populate caches without waiting for GPU.

## 2026-10-24 00:12 — User correction: only ONE mixed replica

Latest instruction explicitly requests1mixed replicate, not3. Existing first replica continues uninterrupted. Sent SIGSTOP only to Python orchestrator1431466 while GPU child1431816 production continues, so no2nd/3rd replica can start. Updated run_talos001_precision_comparison.py future loop to1, and launched independent tmux talos001_single_finalizer running scripts/finalize_talos001_single_comparison.py. Finalizer watches first5000000 terminal step+normal log, kills stopped obsolete Python parent only after GPU completion, finalizes metadata and invokes4trajectory comparison (old3double+new1mixed). This is required because running old Python code had already loaded its3replica loop; editing disk alone would not stop later launches. Do not SIGCONT obsolete1431466 or start additional mixed replicas. Full100job14699 remains held. First new replica output directory unchanged.

Statistical scope revised to descriptive mixed-to-each3old and old-centroid shape RMSDs, old3pairwise/LOO distances, paired mixed1-old1 temporal circular block uncertainty, common alignment, direct bond/PBC QC, autocorrelation ESS, full-vs-late-half and equilibration-vs-production sensitivity. No population equality p/probability from1mixedrep, no estimate of mixed between-seed variance. Conditional bootstrap preserves same-time indices within matched pair, exact original number of frames via remainder blocks, but is not a population-equivalence interval. Analyzer API inference_single used final; earlier3pair helper remains tested but not used in actual analysis. Geometric mean configurations need separate physical validity checks before MD restart.

Baseline legacy QC/parser v3 passed all3old equilibration+production trajectories. Legacy production means refitted RMSD1.2578,1.7314,1.8222nm; scalar slow-mode ESS estimates can be as low3.83 for1000frames, so correlation/convergence limits matter. Unit conversion0.8518nm/oxDNA.15synthetic geometry/parser/bootstrap tests passed. Agent review doc updated to final1mixed scope. Source/old outputs untouched; new outputs independent. Single finalizer reports errors instead of declaring simulations completed on trajectory/analysis failure. Completion not yet reached.

- Single-replica enforcement strengthened: original orchestrator was observed resumed despite SIGSTOP, so regular guard files mixed_replica_2 and mixed_replica_3 prevent mkdir/launch regardless of parent signal state. These are files, not simulation directories. Actual replica-directory inventory confirms mixed_replica_1 only. Single finalizer remains responsible for final status; guard-triggered obsolete-parent failure does not imply MD failure. Input diff verified exactly precision,edge,max_io only.

## 2026-10-24 00:30 — Single-mixed comparison COMPLETE

Only1mixed simulation was run, as corrected by user. 6hb_001 mixed_replica_1 completed2000000 equilibration+5000000production at exact original stride5000 =>400+1000frames. Wall445.4935s equilibration,1188.7518s production (~27.24min total), versus original paired double2966.57+7569.59s (~6.45x faster combined). Old physical parameters and seeds preserved; changes exactly backend_precision,mixed edge flag and I/O abort cap. No second/third mixed MD was launched. Obsolete original3replica orchestrator reached the guard file after first completion and exited; independent single finalizer correctly completed QC/analysis. Guard files removed after old parent gone; only mixed_replica_1 directory exists. Campaign status completed; duplicate production completion records merged without losing measured timing.

Analysis results (all nucleotide centers common Kabsch gauge,0.8518nm/unit): production mixed-to-old1/2/3 RMSD0.70810,1.24184,1.86007nm. Old pairwise1.26135,1.73506,1.82404nm. Mixed to old3centroid0.97649nm. Refitting mean shapes pairwise gives0.70791,1.23927,1.85702nm, similar conclusion. Equilibration mixed-to-old1/2/3=1.08188,1.57719,1.31811nm; centroid1.12091nm (transient only). New mean shape differences same order as original between-seed scatter; this is descriptive, not distribution equivalence evidence.

Important uncertainty: mixed production first/second-half means differ1.34001nm; original1/2/3 differ1.29095,.96977,.83107nm. Last-half mixed-to-oldcentroid1.45014nm vs full.97649nm. New scalar ESS~3.64..10.98 from1000correlatedframes. Conditional matched1 temporal bootstrap nominal95% [.62917,1.01927]nm at250frameblocks and[.66939,.99098]at500frameblocks; recommended block275 exceeded primary cap250. Only1mixed realization means mixed between-seed variance cannot be estimated; bootstrap excludes this variation, stationarity is not established, and no posterior equality probability or calibrated population equality p is reported. Finite blocks/norm bias limits coverage. Do not present these intervals as equivalence proof.

Trajectory QC all4runs x2stages passed: expected frames and exact steps, finite15fields, validbox, no trailing rows and direct oxDNA2 backbone geometry. New production observed direct bond range.54495..96888 (within FENE). Geometric average with projected orientations has71out-of-FENEbonds; mean.conf is geometric statistic, not certified MD restart. Corresponding top exported. Average/RMSF NPZ, mean.conf, per-nt mixed-minus-oldcentroid displacement CSV, per-run scalar CSV, pairwise common-gauge/refitted matrices, full and half-window comparisons saved in outputs/talos001_precision_comparison_20261024/analysis. Human report comparison_report_zh.md. Machine summary comparison_summary.json. final_verification.json records all checks.16focused synthetic tests pass after final code changes; Python3.7 syntax checks pass. No skipped required validation. Statistical review in docs/TALOS001_PRECISION_STATISTICAL_REVIEW.md reflects final1mixed scope.

Feature talos001-precision-distribution-20261024 done. Full100-design job14699 remains PENDING(JobHeldUser) per user wait instruction; do not auto-release. Original old outputs and100-campaign outputs preserved. No live mixed simulation remains after this experiment. Resume only on new user instruction.


## 2026-10-24 00:40 — Authorized 100 designs x3 mixed campaign submitted

Latest user explicitly requests three independent replicas for each100designs (supersedes single-replica restriction for prior001comparison). Follow-up sets ZERO equilibration trajectory frames and production every5000 STEPS. New isolated runner scripts/run_talos100_triplicate_mixed.py adapted from legacy pilot, preserving CPU1500step capped preparation/gate, DNA2,Langevin diff_coeff2.5,dt.001,skin.2,300K,.5M. Each2M equilibration+5M production; no prep/equil trajectory frames (interval steps+1), lastconf retained; production1000frames. Mixed+edge,max_io1e30. Independent seed pairs, source topology/config checksums and executable/shared CUDA library hashes recorded. No old source/output overwritten.

Submitted Slurm14708 via jobs/run_talos100_triplicate_mixed_a6000.sbatch, A6000,exclude29,oneGPU/4CPU/16GB per shard,8h limit, array0-59%4. Each shard5sequential independent replicas ->300total. Original300element array failed --test-only AssocMaxSubmitJobLimit (account MaxSubmitJobs100,MaxJobs40);60shards passes precheck. FourGPU maximum concurrency. Last actual scheduler state PENDING(Priority), startUnknown; precheck forecastOct28 is tentative only. Do not claim running. After successful newsubmission, cancelled superseded held14699 (oldBussi/single-replica campaign), preserving all oldartifacts. Otherjobs untouched.

Verification: ./init.sh pass; Python3.7 compile and shell/embeddedPython syntax pass; all100source designs present;300unique outputpaths,600unique equil/productionseeds and exhaustive60x5mapping pass; stricttrajectory parser16tests pass. End-to-end fresh001 rawpreparation+100equil+5000production smoke completed: zeroequil frames,oneproduction frame,finite15columns/directFENE QC and SO3mean/RMSF exports passed. Finalrunner CUDA10step check explicitly verifies mixed+edge log markers andterminalstep. Separate preflight_001 replica0 not counted among300. Runner strictQC plus geometric productionmean/RMSF after eachcomplete simulation; means marked noncertifiedMDrestart, convergence notclaimed. Single failure records metadata/nonzeroexit, shard continues remainingreplicas and returns failure if anyfailed. Eachoutput has exclusive flock and fails on existingmetadata unless explicitinspected --resume. Arrayrequeue will not silentlyoverwrite existingruns. Manifest and verification in outputs/talos100_triplicate_mixed_20261024/. Pending work is actual300simulation execution; monitor14708 and perrunmetadata/shardsummaries, diagnose failures individually. No assurance all100geometries will pass.
## 2026-10-25 03:11 — Verified Slurm14708 campaign checkpoint

- Re-read the repository harness state and ran `./init.sh`; startup checks passed.
- Slurm job `14708` is live. Scheduler evidence shows array tasks 0–33 completed with exit code 0, tasks 34–37 running, and tasks 38–59 pending because of the four-task array concurrency limit.
- Per-run metadata under `outputs/talos100_triplicate_mixed_20261024/` contains 177 records: 173 `completed` and four `running`; no failed/error records were found. The four active output directories have growing production logs/metrics/trajectory files.
- The campaign remains in progress. No final 300-replica completion or pooled analysis claim is made; continue monitoring the same Slurm job and run final aggregate QC/analysis only after all required replicas finish.

## 2026-10-25 03:26 — Campaign still advancing

- Re-polled the authoritative Slurm handle `14708`: tasks 34–37 remain `RUNNING` and tasks 38–59 remain pending under `%4`; no task failure is reported.
- Replica metadata now contains 174 `completed` and four `running` records. Fifty-seven designs have all three replicas complete; incomplete work is limited to active replicas for designs 6hb_058, 6hb_059, 6hb_061, and 6hb_062 at this checkpoint.
- No aggregate analysis was started because the 300-replica completion gate is not satisfied.

## 2026-10-25 03:44 — Verified wait on active array

- A live-handle poll confirms Slurm `14708` is still running tasks 34–37 and holding tasks 38–59 at the `%4` array limit.
- Metadata remains 174 completed and four running, with no failed records or nonzero shard summaries. The active task logs remain live; no restart or duplicate submission was made.

## 2026-10-25 03:46 — Campaign progress

- Slurm `14708` remains live: tasks 34–37 are running, and 38–59 are pending due to `%4` concurrency.
- Replica metadata advanced to 175 completed and four running. No failed run status or nonzero shard summary is present. Fifty-seven designs are fully complete; active designs are 6hb_058, 6hb_059, 6hb_061, and 6hb_062.
- Final aggregate analysis remains gated on all 300 runs.

## 2026-10-25 03:28 — Verified active production growth

- Slurm `14708` remains live with tasks 34–37 running and tasks 38–59 pending under `%4`.
- Metadata is now 175 completed and four running; no malformed metadata, failed status, or nonzero shard summary was found.
- Direct file timestamps and metric tails confirm active production growth for 6hb_058/replica_2 (3,520,000 steps), 6hb_059/replica_3 (1,275,000), and 6hb_062/replica_3 (3,190,000). 6hb_061/replica_2 is still in preparation. No process was interrupted or duplicated.

## 2026-10-25 03:52 — Verified active production growth

- Re-read continuity files and ran `./init.sh`; startup checks passed.
- Slurm `14708` remains authoritative: tasks 0–33 completed with exit code 0, tasks 34–37 running, and tasks 38–59 pending at the `%4` array limit. No duplicate submission or interruption was made.
- Run metadata currently contains 175 `completed` and four `running` records, with no failed/error or malformed records.
- Active production metrics advanced since the prior checkpoint: `6hb_058/replica_2` reached 4.395M steps, `6hb_059/replica_3` reached 2.035M, and `6hb_062/replica_3` reached 4.055M. `6hb_061/replica_2` remains in preparation.
- The 300-replica completion gate is still unsatisfied; aggregate QC/analysis remains deferred.

## 2026-10-25 03:57 — Verified continued Slurm progress

- Re-polled Slurm `14708`: tasks 34–37 remain running; tasks 38–59 remain pending under `%4`; no nonzero exit or failed metadata observed.
- Metadata remains 177 completed and four running, with no malformed records. Active production metrics advanced to 1.755M steps (`6hb_061/replica_2`) and 3.770M (`6hb_059/replica_3`) during this checkpoint.
- The array remains the only documented active work; no duplicate submission or interruption was made. Aggregate analysis is still gated on all 300 terminal replicas.

## 2026-10-25 03:46 — Live campaign poll; objective string still unmatched

- Revalidated Slurm `14708`: tasks 34–37 are running, tasks 38–59 pending under `%4`; no failures or malformed replica metadata.
- Replica state remains 177 completed and four running. Active production reached 2.455M (`6hb_061/replica_2`), 4.440M (`6hb_059/replica_3`), and 0.300M (`6hb_058/replica_3`).
- Exact objective text was searched in project continuity, docs, scripts, jobs, and campaign outputs; no literal match. The string's meaning and requested deliverable remain unestablished, so campaign work is not treated as satisfying it.

## 2026-10-25 03:52 — Campaign advanced; literal objective still unresolvable

- Current Slurm poll: job `14708` still active, tasks 34–37 running and 38–59 queued at `%4`.
- Replica metadata advanced to 178 completed and four running; zero failed or malformed records.
- Active production reached 3.295M steps (`6hb_061/replica_2`), 0.430M (`6hb_063/replica_1`), and 1.090M (`6hb_058/replica_3`).
- The encoded objective still has no identified interpretation or deliverable. The campaign remains separate and is not evidence of objective completion.

## 2026-10-28 TALOS100 replica status audit

- Confirmed 100 designs x3 replicas:294/300 completed,6failed;97designs have all3. Inspected all300metadata and294saved QC reports (1000frames,steps5000..5000000,stride5000,finite15columns,zero trailing bytes); no full trajectory rescan.
- Failed:6hb_064 replicas1/2/3 and6hb_089 replicas1/2:production startup bonded-neighbor distance errors after nominal equilibration.6hb_079 replica2:5M run ended but strict direct FENE/image QC failed and log shows energy escalation to6e12. Underlying cause undiagnosed; blind resume reuses suspect stages.
- Slurm14708 terminal:55successful/5failed shards,no active campaign. No submission during this audit. init.sh passed. Evidence:outputs/talos100_triplicate_mixed_20261024/status_audit_20261028.json. Next:diagnose/recover six failed replicas before complete aggregate analysis.

## 2026-10-28 TALOS97 background triplicate statistics

- User authorized batch analysis of97all-three-complete designs using all3replicas. New scripts/analyze_talos100_triplicate_batch.py and jobs/analyze_talos97_background_20261028.sh. Detached tmux session talos97_analysis_20261028 started on gpu17; logs/output:outputs/talos97_triplicate_analysis_20261028/. No MD or sbatch.
- Strict parser rereads all291production trajectories, validates1000frames/direct FENE, fits whole structures to each design replica1 initial.dat. Pooled mean in common gauge; pooled RMSF includes within and between variance. Mean axes projected onto SO3; mean.conf geometric,not certifiedMDrestart. Per-replica NPZ/conf,pooled NPZ/conf,topology,per-nodeCSV,design_summary.csv,batch_summary.json.
- Agreement:pairwise independently Kabsch-fitted mean RMSD plus common-gauge RMSD,RMSF-RMSE; compare with first/last-quarter within-replica differences; global scalar ACF ESS,target100. Descriptive needs_review/no_discrepancy flags,not formal equivalence. Four quarters may remain correlated; no universal physical margin or convergence claim. Allproduction frames retained; block sensitivity reported.
- Compile/bash syntax passed; synthetic variance,pooled variance identity,proper-rotation fit checks passed. Selection verified97(excludes064,079,089). Check run.log,progress.json,launcher_status.txt; final launcher exit and batch_summary required before completion claim. Resume reruns script; existing summary reused only on matching trajectory size/mtime/topology hashes.

## 2026-10-28 17:01 TALOS97 analysis recovery

Status69/97 complete,no recorded failures; original tmux server and PID20161 absent on gpu17,log stopped at071 replica2,no terminal launcher status. Cause unknown. Restarted same lock-protected batch in detached tmux; matching completed summaries skipped,unfinished design reparsed. Outputs preserved; final completion still pending.

## 2026-10-28 TALOS97 analysis finished

Finished17:38:52 exit0:97/97designs,291replicas,no failures. All97pooled_mean.conf,pooled_statistics.npz,per_nucleotide_statistics.csv,design.top,summary.json verified present. Final design_summary.csv/batch_summary.json present. All97needs_review under declared ESS/block screening; no convergence claim. Requested computation done. Outputs:outputs/talos97_triplicate_analysis_20261028/.

## 2026-10-28 TALOS97 four-conformation viewer delivered

- Built outputs/talos97_four_conformations/viewer.html (~97MB,self-contained Three.js + gzip arrays),provenance.json,viewer_preview.png,browser_verification.json. Reproducer:scripts/build_talos97_four_view.py,template:scripts/talos97_viewer_template.html,local Three.js asset in output/assets.
-97designs,4views(initial +3separate replica geometric means),sidebar97real-coordinate PCA thumbnails,search,synchronized rotation/zoom,common scale. Full nucleotide resolution,actual topology/strand colors.
- Verified all3initial.dat/topology hashes match per design,minimize.input conf_file=initial.dat; raw initial t0 used by default. Optional left pane switches to actual conf_file from each equilibrate.input (first MD state,after CPU preparation). No rerun needed. Actual triplicate production inputs save every5000; first saved production step5000,not old superseded late-window campaign. No saved t0 trajectory claimed.
- Browser Playwright/Chromium passed4WebGLcanvases,97menu entries,first/last sample,MD-start toggle,search,zero page errors;screenshot visually inspected and shows molecular geometry in all4panes. Python compile passed. No simulations launched or source files altered.

## 2026-10-28 conformation distance summary

Computed97designs x3pairwise mean comparisons and97x3 initial-to-replica-mean comparisons with proper Kabsch. Equal design weighting. Evidence:outputs/talos97_triplicate_analysis_20261028/conformation_distance_summary.json and conformation_distances.csv. Both MSD(nm2) and RMSD(nm) reported to resolve terminology ambiguity.

## 2026-10-28 cross-project model inventory

User requested Geodiff+HADO harness/model search and CodeGraph init. Both init -i -y returned already initialized exit0; status/query usable. Current statsGeodiff1393files/26106nodes,HADO405files/6407nodes. Detailed report outputs/model_inventory_20261028/MODEL_INVENTORY_ZH.md with exact classes,train/predict entrypoints,historical metrics,target differences,selected checkpoint existence. Distinguishes DGNN-lite from PaiNN/OnePass,flow families,corrected rigid segment,MLP/non-coordinate baselines,and failed physical prototypes. No existing checkpoint validated on current97TALOS pooled means/RMSF; need source-only adapter anddesign-held-out retraining. No new training/inference performed.

## 2026-10-28 TALOS97 all-model training spec first

User authorized all-model training,requested spec before execution and reusable dataset. Spec saved docs/harness/talos97_model_benchmark/SPEC.md before implementation. Fixed targetreplica1mean/inputinitialt0,designsplit68/14/15,50epochs,seed20261028,source-onlygraph,random init,noW&B. Dataset/adapter/training build underway.

## 2026-10-28 TALOS97 dataset verified and training launched

Spec-first contract implemented at experiments/talos97_endpoint_v1. 97 copied light datasets, separate source-only inputs and replica1 mean labels, SHA256 manifest, fixed 68/14/15 design split. scripts/verify_dataset.py passed all original/cache hashes, no target keys in inputs, finite geometry and rotation checks (max orthogonality error1.19e-7). Identity RMSD train2.63905/val2.60264/test2.47567nm.

Slurm array17224 submitted A100/A6000,1concurrent GPU,32GB hostmem,4CPUs,3days each,exclude gpu29. Firsttask17224_0 RUNNING gpu27; shared_mlp formal training reached epoch8 with checkpoints/history and validation2.60313nm (not improvement claim). Other15 queued by array limit. All16 full-largest-training-design forward/backward/AdamW gates passed after fixing rigid49D input and normalizing EBD strand aggregation plus bounded coordinate updates. Evidence runs/all_gates.json and all_gates.log. EBD diffusion/force branches explicitly adapted,not exact originaldiffusion/XPBD. Kinematic starts poorly (large loss) but finite; no scientific success claimed.

Train runner independently gates each task, resets initialization after gate,50epochs,best selected onlyval,finalbest export and test. Data/report not trainingcomplete. Resume lastcheckpoint currently checks exact scripts+manifest hash; changes made after firsttask started mean firsttask cannot resume under changed script without audit. Full run must be monitored using squeue/sacct and status/history/metrics,not PID alone. No MD launched. Background nohup attempt did not survive tool shell; superseded by persistentSlurm.

Final launch verification18:47:Slurm17224_0 RUNNINGgpu27,shared_mlp epoch25;best.pt andlast.pt physicallypresent69,697bytes each.16/16all_gates passed;train/models/verify_dataset compilepassed. CodeGraph sync attempted exit1 because existing index lockPID49751; no lock removed,no posteditCodeGraph conclusions used. Remaining15tasksqueued,notcompleted.

## User correction: local H100 only

Cancelled17224entirearray; sacct reports task0CANCELLED and tasks1-15CANCELLED. Actual preservedshared_mlp lastcheckpoint epoch46. User requires no sbatch; switched to gpu17 H100 localtmux talos97-train-h100, scripts/local_campaign.py, runs/local_campaign.json. No future automaticbatchsubmission. Explicit singlemodel resumeaudit preservesoldconfig/best/last underpre_local names; code changes do not alter SharedRigidMLP, loss,or optimizer. Allocation16718expires22:12:59; report limitation,do not claim persistentGPUafterexpiry.

## 2026-10-28 19:18 local training recovery

Actual check gpu17:tmuxserver absent,controllerPID54547 absent,noGPUprocess;GraphFlowlog stopped19:13:05 afterepoch6 whilecampaignJSONstalerunning. Allocation16718stillRUNNING;terminationcauseunknown.6modelsverifiedmetrics+15testconf each;newPaiNNFlow testRMSD2.38478566nm,improvement3.67119%,13/15wins,bestepoch41. Restarted same lockedlocalcontroller via tmux,skipcompleted/resumeGraphFlowlastcheckpoint;no sbatchsubmitted. Do not treattmuxasguaranteeofsurvival.

## Remaining10models200epoch Slurm migration

User explicitlyrequested200epochs forremainingmodels andsbatch onA100/A6000/H100. Stoppedlocalcontroller60843beforechild60851termination topreventlaunchingnextmodel;closedtmux.6completedmodelsunchanged. remaining_200.sbatch array17254submitted10tasks,1GPU4CPU32GB3days,excludegpu29,noarrayconcurrencycap. GraphFlowcheckpointpreservedandresumes;total200epochsnotadditional200. Code/datahashcontractunchanged. configs/remaining_200.json freezesmapping. Finalcomparisonmustdiscloseunequal50/200epochbudgets.

## User correction: one bundled GPU job

Cancelledall17254array(sacctconfirmed).Submitted17264singlejob,singleGPU,nothingarray,remaining_sequential_200.sbatch sequential10models200epochs,7daylimit,A100/A6000/H100. Checkpointsretained;permodelsequential200.log;global sequential200-17264.log. No parallelmodelrunsrequested.

## Completed-model internal diagnostic

Read-onlyCPU3train-design gradient/loss/output audit and fullregisteredparametercounts, no changes to runningmodels. Report outputs/talos97_model_diagnostics/REPORT_ZH.md plus rawJSON/log/reproducer. Critical finding: currentSharedMLP/GraphShared adapters encodeonly6base/degree features,no geometry;GraphSharedignoresedgefeatures,nearidentitynotvalidarchitecturecomparison. OnePass200640vsDGNN65417/Physic123211/PaiNNFlow175808params;globalcontext+vectorreadout+identityinit+centering differences confoundarchitecturecausality. No widespreadcoordinategradientdisconnect;Flowrotationconstantlosszero-gradient,Physicpairheadunused,OnePassflow/phaseheadsunusedbydesign. Samplegradientdirectionweightednotdominant;Flowtrainvelocitylossnotendpointmetric. No causalablationrun,no extraGPUtraining,existingcampaign17264unchanged.

## DGNN-lite 1M capacity control spec

User requests approximately1Mparameters localtraining. Isolatedexperiment experiments/talos97_dgnn_lite_1m;specsavedbeforelaunch,symlinksharedfrozendata,snapshotmodels/train,noactivebenchmarkcodechanges.Hidden256expected998921params,3sharedmessageiterations,same50epoch/loss/seed/split/optimizer ashidden64baseline. LocalH100 noextra sbatch;gate/resetformalinit/checkpoints.

1Mlaunchverified19:30:PARAMETERS998921,largestdesignforward/backward/optimizerGATE_PASS0.456s,localtrainingPID61387runninggpu17. Independenttmux talos97-dgnn1m;dataandoldrunsnotmodified. Thisisrunningnotcompleted,noeffectclaimyet.

## DGNN-lite1M completed verified19:35

IsolatedlocalH100998921param experiment50epochscompleted,bestepoch41. Actualmetrics.jsonand15testprediction.confverified.Train2.58546105,val2.53876105,test2.44230512nm;identitytest2.47567237nm,1.3478%improvement,12/15wins. Original65417paramtest2.44615130nm;1Mreducesonly0.00384618nm(0.1572%). OnePass2.23583883nmstillbetter. Widthaloneinsufficientunderthis50epochseedprotocol;notproofcapacityneverhelps.NoGPUprocessremainingforlocalexperiment.

DetailedOnePassvsDGNN followup:3DGNNmessageiterationsshareweights,3PaiNNlayersindependent;scalar/vectorstates,unitdirectionmessage,RBF,globalcontext,centeredposvectorbasis andidentityreadoutverified. All68trainpredictionradialprojectiondiagnostic:medianpredictedmotionenergyinasinglea*xmodeOnePass19.25%,DGNN64 68.43%,DGNN256 60.48%. Positiveaverageradialcoefficients,no“contraction”claim.No causalablationandnoactivecodechanged.Reportupdated,radial_check.json+script.

## PyTorch node/dataflow analysis

CPUreadonlyhooks/autograd onbestOnePass/DGNN50epochcheckpoints,real6176node001and036/068. node_trace.py exports6CSVnodewiseactualmotion/targetalignment/outputgrad;feature_hooks.jsonlayeractivationandgradient;torch_trace.jsonleafmoduletrace. OnePass63-72%nodestowardtargetvsDGNN49-62%;outputgradientRMSsimilar(0011.98e-5vs2.16e-5),noentiregradientdisconnect. Report DATAFLOW_ZH.md distinguishesoutputlossgradientfromparameterJacobianandlatentupdatesfromphysicalmotion. Noactivecodechanged. TorchLens2.36.1+safetensorsinstalledisolated/tmp/talos97_torchlens,traceattemptrunning;notrequiredforautogradresults.

TorchLensfinaltracebothOK:fullrealdesignCPUforward,tensorwrapperavoidsstringtokenizerheuristic,metadataonly. lens_dgnn_lite.txt/lens_painn_onepass.txtgenerated. Notvalidationcertificateorpayloadanalysis;gradientresultsfromPyTorchhooks.

## Evidence-driven extended diagnostics complete

User six-phase task delivered outputs/talos97_model_diagnostics/extended/. Originalimplementations/train/checkpoints/resultsread-only;newdiagnosticsonlyplus harness. CPU12source-size-selecteddesigns(6train3val3test),256nodes/design,random128RSA/CKA. 6144displacementrows,53modulegradientrows,612sklearnRidgeprobeevalrows,120rsatoolbox/torch-cka comparisonrows,87controlledhookinterventions3validationdesigns. TensorBoard159scalar/117histogramtagsverified. Forwardreproductionmax1.43e-7normalized,checkpoint/sourcehash unchanged,nooriginaloptimizersteps. ReportstatusesOBSERVED/SUPPORTEDHYPOTHESIS/INCONCLUSIVE/REQUIRESRETRAINING,skippedanalysesexplicit. Strongnewresult:positivevectorrescalingcancelledbyRMSreadout;normpreservingdirectionperturbationdose-degrades. Globalctxsmall/inconsistent;linearprobeadvantageonlylocalcomponenttask,notmagnitude/backbonedelta;simplemeanbaselineoftenstrong. OnePassovershootssmallmotionnodes. Donotclaimoptimizationefficiencyfromcheckpointgradients. Gitcurrentrootabsent/externalhistoricalsourcehashnotrecordedlimitationsdocumented. Initialindexordered128similaritypasspreservedbutexcluded;random128verifiedused. FiguresPNG/PDF/SVGinternaldiagnosticnotjournalready.

## 2026-10-28 read-only AI mechanism follow-up
New outputs/talos97_model_diagnostics/extended/followup: three existing validation designs, no optimizer or parameter update. Joint vector/coefficient channel permutation restores original output within2.03e-6nm; vector-only meanRMSD+0.5503nm,coefficient-only+0.4449nm. Finalvector positiongradient radialenergy fractions1.52e-8 to2.23e-6 agree with RMSnormalizationJacobian. Pureautograd VJP/doublebackward JVP alongunitnegativepositiongradient:12casesfinite,chainrulemaxrelativeerror1.88e-7;DGNNlocaldescentexists,OnePassalignmentnotuniformlybetter. NotAdamWefficiencyortrainingcausality. Sixverificationchecks pass,checkpointandstate_dictunchanged. REPORT_ZH.md,CSV,manifest,PNG/PDF/SVGsaved.

## TALOS dataset subset GitHub upload complete
User narrowed upload to<100MB. Original302002665byte7partpush cancelled before remote main changed; unpublished localcommit amended to exclude all fullparts. Uploaded20designZIP61358389bytes,12train/4val/4test,selectedinput-node-countquantilespreservingoriginalsplit.140sourcehashes,144ZIPCRCsverified. GitHubmainb98ae897db6f4218d42d3de0fb63b32129988404,ls-remote+fetchedremote tree verifiedZIPblob628564e5677e2670a75f505f063a1d6a3027dc54. Localfullarchiveandpartsremainuntracked; unrelatedhado_dataset_dat_20261016.zip untouched. Uploadmetadata outputs/talos97_dataset_upload_20261028/. Skill hado-github-upload.

## Imported local-frame full97 local training
Downloaded existing GitHubuploads/TALOS_model_study_20261028.zip at origin/main6910c88(URLzipx typo resolved);CRCvalid,sourcepreserved. README/selectionconfirmvalidation-selectedframe9987params,position-only,fixedgeometryMLP,nottheuntrainedadaptiveSE3head. SPEC+manifest beforelaunch:3freshseeds11/22/33,200epoch,original68/14/15,train-onlynormalization,AdamW1e-3wd1e-4clip5,bestvalidation,no sbatch. Localgpu11RTX6000Ada,tmux talos97-localframe PID483232. ActualCUDA1458MiB,epoch60seed11bestval2.26727nm;notcompletionclaim. Datasetverifier97hashesPASS. Source modelcopiedunchanged;isolatedrunnerCUDA+CPUserialization+livehistory. Path experiments/talos97_localframe_study/full97/train.log.

## 2026-10-28 expanded local-frame2M training
User requests81→346→346,8dualLinearblocks,1038→3frame,2083615params. PureLinear count2072543;twoaffineLayerNorms/block supplyexact11072difference,explicitlycommunicated. Implement h+Linear2(LN2(SiLU(Linear1(LN1(h))))),preservegeometry/frame/headzero/centering. Independent experiments/talos97_localframe_2m,SPECbeforeedits,source/datahashmanifest. Largest9996node finiteforward/backward identitygatePASS,count2083615. Fresh3seeds11/22/33,200epochoriginal68/14/15,AdamW1e-3wd1e-4clip5,localgpu11RTX6000Ada,tmux talos97-frame2m. ActualtrainlogPARAMETERS2083615SEED11;oldfull97completedpreserved. No sbatch.

## Expandedframe completed actualverification
Noactive run_full97 process;trainlog SELECTED_BY_VALIDATION;all3seed200epochs,3bestcheckpoints/3predictionNPZ,582metricsrows. Bestepochs48/64/50,valmean2.178041,test2.157656/2.169098/2.154800nm;ensembletest2.140356 vsold9987paramensemble2.167785. Lateepochsvalidationworsens(seed33epoch2002.34883vsbest2.18053),usebestnotlast. Runtime3runs560.76seconds. Noadditionaltraining.

## 2026-10-29 扩容 frame 最终结果正式归档
详见 docs/harness/talos97_localframe_2m/RESULTS_ZH.md 与 RESULTS.json。核验600epoch记录、582指标行、3检查点/3预测NPZ、每种子15测试设计，并保存15项文件SHA256。集成测试2.140356nm，对比原小模型2.167785nm，降低1.265%。明确LayerNorm参数量推导、宽度/深度/归一化混杂、最佳epoch48/64/50与后期过拟合。未启动新训练。

## 2026-10-29 frame训练拟合诊断
只读新报告 outputs/talos97_frame_fit_diagnostics/REPORT_ZH.md+train_readout.csv。区别bestval与最低训练误差；epoch200在线训练MSE仍下降。seed11冻结best在68图readout:tanh饱和比例6.01e-7,导数均值.96848,目标meantranslation最大4.27e-7nm,最大目标位移11.7058nm（16nm保守界未触发,非完整可达证明）。8blocks是逐节点MLP非学习消息传递；表示压缩/优化是未分离假设。无新训练或checkpoint修改。

## 单设计过拟合实验完成
对训练设计6hb_001(6176节点)使用2083615参数frame模型从头2000步:bestRMSD0.591068nm(step1957),final0.610080,未达0.1nm。最佳状态低lr1e-4新AdamW续训2000步:best0.558070(step1973),final0.558995,平台约0.558。原float81维特征6176节点全唯一；两位小数碰撞下界0.258nm，原精度无碰撞证据。结果说明有强记忆能力但不能完全拟合；优化震荡有贡献，表达/特征原因未分离。详见 outputs/talos97_frame_fit_diagnostics/OVERFIT_SINGLE_REPORT_ZH.md、experiments/talos97_localframe_2m/overfit_one/manifest.json 和 refinement/result.json。未修改正式模型/检查点。


## 2026-10-29 TALOS97 训练状态与最佳模型审计

新增 docs/harness/talos97_model_benchmark/BEST_MODEL_AUDIT_ZH.md。全已归档 TALOS97 结果中最低 test 为 localframe_2m 三 seed 集成 2.140356 nm，旧 9,987 参数集成 2.167785 nm，改善 1.265%；宽度/深度/LayerNorm/集成未分离，不能作单因果归因。统一 16 模型 benchmark 中 trap_target 是最佳单检查点（test 2.213537 nm、val 2.229745 nm、best epoch 70），但它训练 200 epoch 而 OnePass 训练 50 epoch；trap_target 第 50 epoch 验证 2.2662 nm、第 200 epoch 为 2.3831 nm，存在后期过拟合。其 4 nm 平滑位移上限与大多数测试标签位移相容，且 15/15 测试设计优于 identity，但无匹配预算/去限幅消融。stiffness_head 未进入训练 loss。

统一 benchmark 共 15/16 模型有指标，6 模型 50 epoch、9 模型 200 epoch；kinematic 第 8 epoch 因 nonfinite gradient 失败。作业 17254 已取消、17264 失败结束；当前无 TALOS97 训练进程，本地 H100 显存 0 MiB/利用率 0%。不因历史 PID/tmux 标记宣称运行。本次只更新分析文档和 harness 记录；没有训练、推理或改动检查点。


## 2026-10-29 OnePass 验证误差改善目标启动

用户要求按“先错误、再表示、最后干预”的顺序，把已训练 OnePass/DGNN-lite 验证误差尽可能降至约 1.2 nm；暂按绝对宏平均 RMSD、replica1 mean 标签解释，已发起指标口径澄清。优先将 OnePass 作为优化对象、DGNN-lite 作比较。当前两个最佳验证权重：OnePass epoch48 / 2.2510869588 nm / SHA256 42fcb82b8a0b100ef22b235ac4e74717321748c3caa850929a47cf645099592a；DGNN-lite epoch25 / 2.5419452276 nm / SHA256 d4f34a6fa3e9eb4c5432c6a19784b3c045ca5e9b19768cbf67b136934e74873d。

Phase 1 error localization 已完成并通过预设验证：只用固定14验证设计与既有预测，复现官方 RMSD、有限节点输出和不变 checkpoint 哈希；没有碰 test、训练或更改权重。结果见 `experiments/talos97_model_improvement/phase1_error_localization/results/REPORT_ZH.md`。

## 2026-10-29 最佳模型机制审计与 OnePass 表示复用

复核 `docs/harness/talos97_model_benchmark/BEST_MODEL_AUDIT_ZH.md` 及对应训练指标：本地 H100 查询为 0 MiB / 0%，未发现匹配 TALOS97 的进程或 tmux；Slurm 队列有用户作业 17439（H100/gpu17，运行中）和 17440（A100，pending）。`scontrol` 未提供其启动命令（`Command=(null)`），因此无法仅凭队列判断作业用途；本轮没有启动新训练。两种“最佳”口径需分开：统一 endpoint-v1 矩阵最佳单 checkpoint 是 `trap_target`（val 2.229745、test 2.213537 nm；200 epochs），所有已归档结果最低 test 是 `localframe_2m` 三种子 ensemble（2.140356 nm）。

原因仍是受证据约束的假设：`trap_target` 的 4 nm 平滑位移界与多数标签位移相容，15/15 test 设计优于 identity，但它比 OnePass 多训练 150 epochs，缺少匹配预算及去限幅消融。`localframe_2m` 用固定多尺度几何基底、局部 frame 等变位移 readout、8 个逐节点残差 MLP 块和 mean/max 全图摘要；3-seed ensemble 仅比旧模型低 1.265%。扩容同时改变宽度、深度和 LayerNorm，不能单独归因于参数量；测试集仅15个且已反复查看，不能声称盲测或显著提升。

OnePass 误差优先定位在大位移低估：目标位移≥4 nm节点占验证节点9.9%、占 pooled squared error 32.2%，预测平均位移1.48 nm而目标4.94 nm；小于1 nm组有轻度过冲。Phase 2 复用审计通过8项 provenance/count检查：checkpoint、split、manifest、当前源哈希一致，既有验证为passed、原模型optimizer step为0，87项干预和其余输出计数一致；仅复用3个 validation 设计，没有读取test行、跑新推理或训练。

下一步 intervention hypothesis 是把每通道 `log1p(v_rms)`（仅用68个训练设计算设计平衡标准化）暴露给 OnePass 系数头，同时保留归一化向量方向；已写 `phase3_vector_rms_readout/SPEC.md` 和 `EXPECTED_VERIFICATION.md`，对照是从相同 epoch48 checkpoint 进行同预算原读出续训。当前未启动此训练或推理，原检查点未改。实验 feature 仍 `in_progress`，验证目标约1.2 nm尚未达到。

## 2026-10-29 Phase 3 matched readout continuation completed

Phase 3 在现有 H100 allocation 17439 / gpu17 顺序完成6个run（3 paired seeds×2 arms×50 epochs），没有提交新作业。预检复现 frozen OnePass 验证2.25108692 nm，identity 2.60264149 nm；新增 RMS readout 零初始化最大位移差5.58484e-6 nm。三 seed 控制续训均值2.241031 nm，RMS 增强均值2.239593 nm，增强相对控制仅改善0.001438 nm，未过预先写定的0.05 nm有希望门槛；所有三组配对差小幅为负。完整核验11项通过，300个epoch记录、98条验证设计指标、源/数据/checkpoint哈希不变；test_rows_read=false、test_predictions_written=false，原权重未改。详见 `phase3_vector_rms_readout/results/REPORT_ZH.md` 与 `verification.json`。此干预的实际作用很小，不足以接近1.2 nm目标。

下一项由错误模式导出的干预是增加一个从 OnePass 不变 scalar+global context 预测正值 per-node displacement gain 的零初始化 head，保留原向量方向并用 `exp(1.5*tanh(raw))` 有界缩放位移。已先写 `phase4_node_amplitude_gate/SPEC.md` 和 `EXPECTED_VERIFICATION.md`；尚未写训练代码或启动。需重新确认当前H100 allocation状态再执行。总体 feature 仍 in_progress，目标未达到。

## 2026-10-29 Phase 4 node-amplitude gate started

在原有 Slurm H100 allocation 17439 / gpu17 中重新做了资源检查（job RUNNING、CUDA H100空闲、无 Phase 4 重复进程），没有新提交作业。Phase 4 规范和 expected verification 已先写好，代码和验证器通过 `py_compile`；初始化预检通过：冻结 OnePass val2.25108693 nm、gain模型初值val2.25108692 nm，最大节点位置差3.25095e-6 nm、最大旋转元素差1.84774e-6、gain误差0、optimizer steps0；未加载test IDs/rows。tmux `talos97-phase4-amplitude` 已启动，Python PID219835，日志 `experiments/talos97_model_improvement/phase4_node_amplitude_gate/train.log`；首个控制run seed11 epoch1已记录val2.248121 nm。计划6个run×50epochs，当前尚无最终对比结论。原 checkpoint untouched。


## 2026-10-29 Phase 4 node-amplitude gate completed

Phase 4 在现有 Slurm H100 allocation 17439 / gpu17 内顺序完成六个 run（control/amplitude × seeds 11/22/33），没有提交新作业。`verify_results.py` 通过全部预设核验：六 run 各 50 个有限值 epoch、配对训练顺序一致、固定 14 个验证设计覆盖完整、epoch-0 候选纳入、哈希未变；`test_rows_read=false`、`test_predictions_written=false`、`original_checkpoint_modified=false`。

冻结 OnePass epoch-48 验证宏 RMSD 为 2.25108692 nm。控制续训三 seed 均值 2.24096015 nm；幅度门三 seed 均值 2.24218363 nm；amplitude-control 为 +0.00122348 nm，三个 seed 均未改善，因此按预注册 0.05 nm、至少两 seed 改善规则判定为负结果。结果报告：`experiments/talos97_model_improvement/phase4_node_amplitude_gate/results/REPORT_ZH.md`；核验：`.../results/verification.json`。目标约 1.2 nm 尚未达到，继续下一项预注册干预。


## 2026-10-29 Phase 5 metric-aligned loss preregistration

Phase 4 has completed and passed its 12 verification checks; its per-node amplitude gate lost 0.00122348 nm versus matched continuation. Based on the measurement mismatch (validation selects arithmetic mean of 14 per-design RMSDs, while continuation uses per-design MSE), Phase 5 preregisters a matched 3-seed × 2-arm, 50-epoch objective intervention. Control retains MSE+0.01 rotation MSE; intervention replaces position MSE with frozen-train-median-scaled smooth per-design RMSD, preserving model, optimizer, paired order and update budget. SPEC and EXPECTED_VERIFICATION were written before training code/execution. CPU py_compile passed; preflight reproduced OnePass at 2.25108693 nm, verified identical epoch-zero outputs (max position 5.585e-6 nm, max rotation 3.427e-6), and computed 2.286727 nm scale from train designs only. Test rows remain untouched. Current resource audit: allocation 17439 active on gpu17/H100 through 19:18 UTC, GPU 0 MiB / 0%, no TALOS97 phase process; an `srun --jobid=17439 --overlap` probe returned gpu17 and SLURM_JOB_ID=17439. Training not yet launched at this record.


## 2026-10-29 Phase 5 metric-aligned loss completed

Phase 5 在 allocation 17439 / gpu17 完成六个 run（control/macro_rmsd × seeds 11/22/33），没有提交新作业。控制臂保留 position MSE + 0.01 rotation MSE；干预臂改用由冻结 OnePass 在68个训练设计上的中位 RMSD（2.286727 nm）缩放的 smooth per-design RMSD surrogate。`verify_results.py` 通过 15 项核验：六 run 各50个有限值 epoch、配对顺序一致、68/14 split 完整、epoch-0候选纳入、训练尺度未使用验证/测试目标、哈希未变；test_rows_read=false、test_predictions_written=false、original_checkpoint_modified=false。

冻结 OnePass 验证 2.25108693 nm；控制续训均值 2.24103641 nm；metric-aligned 均值 2.23922198 nm；相对控制改善 0.00181443 nm，三 seed 均略改善但未达到预注册 0.05 nm 门槛，故判为 unsupported。报告见 `experiments/talos97_model_improvement/phase5_macro_rmsd_objective/results/REPORT_ZH.md`，核验见 `.../results/verification.json`。目标约1.2 nm仍未达到，应转向表示/结构干预。


## 2026-10-29 Phase 6 TransformerConv started

Phase 6 spec and expected verification were updated before implementation to account for OnePass's zero-initialized final coefficient layer. `run_intervention.py` and `verify_results.py` compile. Preflight passed on existing allocation 17439 / gpu17 / H100: frozen validation 2.25108691 nm; zero-gate TransformerConv 2.25108693 nm; maximum position/rotation differences 4.2612e-6 nm / 2.0564e-6. PyG 2.8.1 TransformerConv returned finite `[6856,64]`; rewiring neighbors changed messages by mean absolute 0.021287; opening the residual gate changed predictions by max 0.046055 nm. The disposable train-only gradient probe found nonzero finite gate, TransformerConv, and projection gradients and performed zero optimizer steps. Test IDs and rows were not loaded.

The six-run matched continuation has been launched as an active `srun --jobid=17439 --overlap` PTY (session 19368); no new Slurm job was submitted. Monitor `experiments/talos97_model_improvement/phase6_transformerconv/runs/*/status.json`, `history.jsonl`, and the active session. The run order is control/TransformerConv for each paired seed 11/22/33, 50 epochs each. Training-time branch gradients are recorded per epoch. Do not edit runner or verifier source while the run is active because their hashes are part of provenance. Final verification and report remain pending.


## 2026-10-29 Phase 6 TransformerConv completed

The matched Phase 6 run completed all six arms (control/TransformerConv × seeds 11/22/33 × 50 epochs) on existing allocation 17439 / gpu17 / H100. Control validation mean was 2.24103101 nm; TransformerConv was 2.24099734 nm, a −0.00003367 nm difference, below the predeclared 0.05 nm threshold. Two of three paired seeds improved slightly and there were no >0.20 nm per-design regressions. The intervention is functionally active and trainable: finite `[6856,64]` messages, 0.021875 neighbor-rewire message difference, 0.083793 nm open-gate prediction difference, and nonzero finite gate/TransformerConv/projection gradients in preflight and actual training. The 1.2 nm objective remains in progress.

The 15-item independent verifier passed. Test IDs/rows/predictions were not loaded/written; checkpoint, training data, split, model/training sources and installed PyG implementation hashes remained unchanged. After training, the verifier import was corrected following a Python module-name collision; only its own hash changed, and that isolated correction is explicitly recorded in `verification.json` and `REPORT_ZH.md`. PyG version is 2.8.1. Full Phase 6 report and artifacts are under `experiments/talos97_model_improvement/phase6_transformerconv/results/`.

## 2026-10-29 Phase 7 domain-motion audit complete

`./init.sh` passed. The read-only audit used exactly the fixed 14 validation designs (118,342 nodes), Phase 1 OnePass node errors, and only validation keys from the three saved localframe prediction archives. It did not parse `split.json`, read test labels, decode test prediction arrays, run inference, train, or modify checkpoints. OnePass macro RMSD recomputed to 2.25108691 nm; localframe ensemble to 2.15703061 nm; identity to 2.60264151 nm. Domain translation and proper-rigid label-fitted validation oracles reached 0.60304314 nm and 0.31234822 nm, reducing identity pooled SSE by 94.73% and 98.59%. These are diagnostic upper bounds, not deployable model results.

The independent verifier now recomputes all per-design/bin motion metrics, both domain oracle fits and metadata, summary aggregates, validation prediction arrays, and whole prediction archive hashes. It passed all 11 checks. Two issues found during verification were corrected before the final run: a Phase 1 source file was one directory above its results folder, and the first verifier hashed predictions after a dtype cast. Both were fixed and analysis plus verification were rerun from scratch. Report: `experiments/talos97_model_improvement/phase7_domain_motion_audit/results/REPORT_ZH.md`.

The TransformerConv Phase 6 code is functional and trainable, but its matched validation gain was only 0.0000337 nm versus control, below the 0.05 nm screen. The updated best-model analysis explains that localframe uses input-only local and coarse/domain geometry but does not enforce shared rigid motion; Phase 7 motivates testing a learned domain transform plus local residual. Phase 8 SPEC and EXPECTED_VERIFICATION are preregistered under `experiments/talos97_model_improvement/phase8_domain_transform_residual/`; no Phase 8 code, inference, training, or resource submission has started. The 1.2 nm objective remains in progress.

## Phase 9 long/short experts started
User authorized implementing and training two displacement experts plus an input-only node classifier. SPEC/EXPECTED_VERIFICATION precede implementation. Fixed >=4 nm boundary, 3 seeds, 50 epochs/role, matched full-node control; hard routing primary, soft/oracle secondary. Phase 8 has partial runner/verifier but remains untrained and paused (earlier no-runner handoff is stale). Original goal remains paused; this bounded user request is being executed. CPU/GPU preflight pending. Historical exploratory scripts parsed full split/protocol test IDs but did not open test data; Phase 9 runner incrementally parses train/validation only.


## 2026-10-29 Phase 9 result audit completed
All 12 long/short/gate/control runs completed (3 seeds, 50 epochs each, 40,800 steps). Existing verify_results.py run via ../hado_mechanical_pilot/.venv-torch/bin/python exited 0; all five checks passed, report and routing artifacts generated. Validation macro RMSD nm: control/frozen 2.157030525, hard 2.167525705, soft 2.150482389, label oracle 2.070482995. Hard promising=false; soft gain only 0.006548136 nm (0.304%). Gate macro recall 0.035947989 and F1 0.064846482 at fixed threshold 0.5. Oracle is label-assisted diagnosis only. No training or test inference. init.sh skipped: saved-artifact status audit without source changes. CodeGraph navigation skill used to locate Phase 9. Overall 1.2 nm goal remains incomplete.


## 2026-10-29 Phase 9 compact GitHub evidence package
User requested <100MB archive centered on systematic long-node underprediction, representative example and best weights only. Built outputs/phase9_github_bundle_20261029/talos97_phase9_long_displacement_evidence_20261029.zip (31,563,407 bytes); ZIP integrity and 57 SHA256 manifest entries passed. All-14-design amplitude ratio table selects median-nearest representative 6hb_009: 614 long nodes, true mean4.765269nm, baseline1.720688nm, ratio0.361089, 99.6743% underpredicted. Best single-seed soft model is seed11 (validation2.171487nm); retained three expert/gate weights and frame11 base weight only. Includes all training histories, reports and code, example vectors/CSV, exact manifest and build script. No full dataset or test data. Three-seed headline metrics cannot be reproduced using selected-seed weights alone; README states dependencies and incompleteness explicitly. Upload via hado-github-upload skill to private configured artifacts repository; see final response for verified commit. No model training or source edits.

## 2026-10-29 scalar RMSF experiment started
User approved scalar Softplus head on localframe2m, transfer vs scratch x3seeds x200epochs. SPEC precedes code. init.sh passed. Local gpu17 H100 is idle in existing allocation17439 (through19:18:47); no submission. No original source or checkpoint edits.

## 2026-10-29 scalar RMSF training completed and verified
Isolated experiments/talos97_rmsf_scalar:localframe2m encoder snapshot,1038->1+Softplus,2,081,537params. Transfer/scratch x11/22/33 x200epochs,81,600updates; train process exited0, no new job submission. Fixed68/14/15,all97designs834348nodes,topology/cache hashes match. Features initial-only;train-only normalization and constant1.634973526nm;test arrays deferred until six checkpoints/arm choice frozen. Transfer chosen by mean seed validation0.390280481 vs scratch0.393291065nm. Predefined transfer ensemble valRMSE0.384231/testRMSE0.367138/testMAE0.278730nm;constant testRMSE0.448998nm (18.23% improvement);scratch ensemble test0.376779nm. All10 independent verifier checks passed(exit0),including best epoch/history, CPU checkpoint prediction reproduction, all873metric rows recomputed, ensembles, hashes. Original sources/weights/data unchanged. predict.py three-checkpoint CPU CLI6176rows agrees with saved GPU ensemble max7.09e-7nm. transfer22 last checkpoint Softplus collapsed to zero;best epoch29 normal;full histories and collapse audit preserved, no hidden retries/hyperparameter changes. Labels finite-trajectory pooled3replica RMSF;all97needs_review,no convergence/significance claim. REPORT_ZH.md and README contain usage,results,limits. No RMSF process remains.

## 2026-10-29 TALOS97 input package complete; upload deferred
User originally requested GitHub upload,then explicitly steered to compression first. Built outputs/talos97_inputs_upload_20261029/talos97_inputs_97designs_20261029.zip,185077825bytes,97inputNPZ preserving inputs/6hb_009.npz,split,README,source manifest,perNPZhashes. ZIPtest and all97SHA256 checks passed;SHA256ee46eeb3801e6827b2e3499112aba24bdcc0b0a03d7860ea53e6c4ca686ed390. Three90MB/90MB/5077825byteparts also prepared locally for futureGitHub limits;reassemblyhash verified. No copy,commit,push to artifacts checkout. Existinguntrackedfiles preserved. init.sh skipped:artifact-only packaging,no model/source changes.

## 2026-10-29 TALOS97 two-volume GitHub upload completed
User explicitly requested exactly2volumes<100MB thenGitHub. Created zip.vol01=92538913bytes,vol02=92538912bytes;combinedSHA256 matches originalZIPee46eeb3801e6827b2e3499112aba24bdcc0b0a03d7860ea53e6c4ca686ed390. Used hado-github-upload skill,uploaded only2volumes+DOWNLOAD.md+PACKAGE.json,commit b4adcbb2c9b3d474e9ddd6bc229102a6e73528b9. Push exit0;remote main ls-remote equalscommit;ls-tree verifies4files andsizes. Existinguntrackedfiles untouched. No training/sourcechanges.

## 2026-10-29 mean-coordinate labels uploaded
User requested labels upload split into chunks <=100MB. Verified all97 data/labels NPZ hashes against manifest, built talos97_mean_coordinate_labels_20261029.zip (37052894bytes, one chunk), ZIP integrity passed, pushed via hado-github-upload commit acef4a2 and remote tree verified.

## 2026-10-30 TALOS97 root-cause research and data audit completed
Applied harness-creator, academic-research-suite, and codegraph-navigation instructions. Ran `./init.sh` successfully. Read-only root-cause audit was preregistered at `experiments/talos97_model_root_cause/SPEC.md` and implemented in `audit_data.py`; it incrementally read only the 68 train and 14 validation IDs, opened exactly 82 triplicate summary JSONs plus the Phase 7 validation tables, and stopped before test IDs. No model inference, optimizer step, checkpoint write, test file, test label, or test prediction was used. `results/verification.json` passes all 8 checks.

Key aggregate evidence: train min ESS mean 4.053 (range 2.619–6.991), validation min ESS mean 3.890 (range 2.731–7.437); validation max replica-mean disagreement mean 2.061 nm; validation pooled RMSF mean 1.726 nm; all 97 designs remain `needs_review`. Validation exploratory design-level correlations are recorded in `summary.json` and are not treated as inferential statistics. Long-node target/predicted means are 4.772/1.602 nm for OnePass and 4.772/1.759 nm for localframe on the >=4 nm bin.

Research synthesis is in `experiments/talos97_model_root_cause/results/REPORT_ZH.md`. Verified primary metadata via OpenAlex/Crossref/arXiv for EBD, hierarchical message passing, over-squashing, GraphGPS, Ewald message passing, GeoDiff/EDM, oxDNA/DNA-origami, and torsional diffusion. Current judgment: data format is sound, but finite-trajectory labels are noisy; the dominant actionable model issue is missing explicit domain-level SE(3) variables and true coarse-graph long-range communication. The report recommends a zero-gated Domain-Frame EBD / hierarchical SE(3) endpoint model followed by replica-aware uncertainty modeling, then only later coarse-to-fine diffusion. Phase 8 CPU preflight passes with zero-gate max difference 3.34e-8 nm, global rotation error 0, domain relabel error 0, proper rotations, and nonzero branch gradients. No Phase 8 training was started because no permitted free allocation was established; existing GPU jobs on gpu17 are unrelated and active.

## 2026-10-30 Phase 8 resource re-audit

`codegraph sync .` reported the index already up to date and `./init.sh` passed. A fresh Slurm audit found gpu17 still occupied by unrelated H100 jobs 19133/19134 and marked `MIXED+DRAIN`; the visible A100 nodes were mixed with active jobs (gpu03 job 19789 uses 3 GPUs), while A6000 nodes were mixed, allocated, draining, or drained. No explicitly granted free A100/A6000/H100 allocation was available for the six-run Phase 8 experiment, so no training was submitted. The Phase 8 CPU preflight remains the latest executable evidence; the runner is ready but the experiment is not scientifically complete until a permitted allocation is obtained and `verify_results.py` passes.

Root-cause report received a metric-label clarification: the 4.936/1.480/1.646 nm long-motion values are node-pooled across the 14 validation designs, while the 4.772/1.602/1.759 nm values are design-macro means (the equal-design aggregation saved by the root-cause audit). The report now labels both aggregation methods explicitly; both show strong long-displacement underprediction. JSON structure checks, source/result consistency check, and `./init.sh` passed after the documentation update.

## 2026-10-30 Phase 8 completed on local A100

User clarified that the host has three local A100 GPUs. The queued Slurm job 19831 was cancelled before start. GPU 0 was occupied by existing Python processes (~39.8 GiB), while GPU 1 and GPU 2 were idle; Phase 8 ran locally on `cuda:1` and never submitted a training job. A100 preflight passed. Six matched runs (control/domain_transform × seeds 11/22/33 × 50 epochs) completed, 20,400 optimizer steps, using fixed 68/14 designs and no test access.

Independent `verify_results.py` initially returned false because it encoded the negative scientific screen as a failed check and did not include the runtime-added `run_a100.sbatch` in source hashes. The original output is preserved as `verification_initial_failure.json`. `verify_results_v2.py` separates integrity from the scientific decision and includes the script hash; all 9 checks pass and the final copy is `results/verification.json`.

Phase 8 scientific result is negative: control seed mean validation macro RMSD 2.175492 nm, domain-transform 2.178041 nm (candidate worse by 0.002549 nm); only 1/3 seeds improved, all candidate best epochs were 0, and max per-design regression was 0.053119 nm. Three-seed validation ensembles were 2.154073 nm control vs 2.157031 nm candidate. The branch had nonzero gate/translation/rotation gradients and passed equivariance, relabel, proper-rotation, and zero-gate checks, so this is a trainable-but-non-generalizing negative result. Detailed report: `experiments/talos97_model_improvement/phase8_domain_transform_residual/results/REPORT_ZH.md`; root-cause synthesis updated accordingly.

## 2026-10-30 Phase10 typed domain graph started
User authorized the proposed typed coarse graph experiment. init.sh passed. CodeGraph located domain preprocessing: virtual_helix x floor(axial_index/16); existing segment cache retains only first nucleotide edge per pair. New SPEC/EXPECTED_VERIFICATION precede implementation. Aggregate all five input relation types and use relative anchor frames for invariant edge messages; three message layers plus domain SE3/local residual. Fixed68/14, six matched50epoch runs, no test, no W&B. Local GPU1/2 idle at initial audit; recheck before launch.

## 2026-10-30 Phase10 preflight passed and training launched
Preflight13/13 passed on localA100cuda1: zero-gate3.414e-8nm, open equivariance2.529e-7nm, relabel2.666e-7nm; neighbor rewiring prediction change0.001421nm and edge-type erasure0.004071nm. All projector/head/3message-layer gradients nonzero. Largest9942node backward761.44MiB;2,218,982parameters. Six paired50epoch runs launched as execsession17582, train.log under Phase10. GPU1 idle immediately before launch, GPU0 untouched. Test not decoded/opened; all sources frozen after launch. This compares graph branch package including anchor-frame readout, not graph-only causal isolation. Paired edges within domains explain zero inter-domain type2 counts. Verify saved metrics/checkpoint CPU reproduction after completion; no duplicate launch.

## 2026-10-30 Phase10 typed domain graph completed and verified
Six runs completed localA100cuda1,20400steps; no Slurm submission/W&B. Three64wide typed message layers,all inter-domain nucleotide relations,anchor-relative geometry;2,218,982parameters. Preflight13/13 and independent12/12 pass. Control mean2.175491668nm vs graph2.176664398nm (worse0.001172730nm); ensembles2.154073/2.155920nm. Graph bestepochs0/6/0. Raw1/3improved count is seed11 -1.385e-10nm numerical tie;22/33worse. Long-node amplitude ratio macro0.391173control/0.376755graph;long endpoint RMSD3.652987/3.682644nm. Negative screen;1.2nmgoal incomplete.
All84selected checkpoint/validation outputs CPU reproduced max5.516e-6nm; independent dictionary verifies all82designs coarse relation counts. Metrics/bestepochs/orders/ensembles/protected hashes pass. Test untouched; original checkpoints unchanged. Branch functional/trainable but no validation gain. Artifacts: experiments/talos97_model_improvement/phase10_typed_domain_graph/results/REPORT_ZH.md and verification.json. No training process remains; GPU1 freed. Do not relaunch histories. Next proposed diagnostic(not launched): train-only domain-transform supervision with frozen backbone to separate fitting and joint-loss branch competition; new SPEC required. CodeGraph sync16:45:18–16:45:22+08,4s,exit0. Final init.sh passed. A harness update script encountered an entry without id; corrected using get before writing; model/run/verifier sources unaffected.

## 2026-10-30 Phase11 domain supervision diagnostic preregistered
Phase10 typed graph was negative. Existing phase10_domain_helix_graph is joint endpoint-MSE and cannot answer whether domain motion is directly predictable. Preregistered Phase11 frozen-backbone direct proper-Kabsch domain supervision under experiments/talos97_model_improvement/phase11_domain_supervision/. No runner/training started yet; test boundary remains fixed.

## 2026-10-30 Phase11 runner completed and launched
User requested completing and starting Phase11. SPEC clarified BEFORE implementation/training:3seed50epoch frozen-base direct-domain transform supervision; no zero gate/tanh limits; translation Euclidean loss+1nm^2 Frobenius rotation loss, rank<2domains excluded from rotation. Report rigid-only, hybrid with input/frozen-prediction-only intradomain residual, additive double-counting diagnostic separately. All68+14 train/validation metrics per epoch; select by validation transform loss. diagnostic_model.py and run_experiment.py/verify_results.py complete, py_compile passed. LocalA100GPU1 idle before launch; exec89465 running,train.log under Phase11. Preflight runs BEFORE optimizer; all protected hashes written. No test/W&B. Do not edit frozen runner/verifier/dependencies while running or duplicate launch. Copied legacy model.py/base_utils.py not used. Final independent246design CPU reproduction required.

Phase11 attempt01(preflight10/10passed,epoch0only) failed before first AdamW step: optimizer default CUDA context accessed occupiedGPU0. Archived attempt01_default_cuda_context_failure with original runner/log/results/history. Corrected explicit torch.cuda.set_device(cuda1), SPEC records correction before resumed training; no model/hyperparameter/data changes. Exec46447 active; seed11epoch1trainloss6.702483 vs identity7.894380,validation6.222240 vs7.652841.2184/total82design domain rotations are rank<2unidentifiable and excluded; translation retained.

## 2026-10-30 Phase11 complete and independently verified
Three seeds x50epochs,10200updates completed on localA100cuda1. Bestepochs20/11/20. Frozen BasisNet cached; only identity-init/unbounded typed3layer domain heads train. Train+val fitting screen3/3pass each. Val translationRMSE2.6074->2.1871/2.1986/2.1878nm;rotation29.0124->23.6128/24.1021/23.5846deg. Val rigid-only2.161287/2.174603/2.164300nm vs base2.174161/2.179434/2.180528;hybrid2.175008/2.199466/2.180868nm. Domain movement partially predictable but no stable hybrid endpoint gain,1.2nmgoal incomplete. Val long hybrid amplitude ratio0.402702 vs base0.378597;long RMSD3.642653 vs3.685912nm,small improvement only.2184rank<2domains excluded from rotation supervision;translations retained.
Preflight10/10 and independent verify_results_v2.py10/10pass. All246train/val checkpoint outputs CPU reproduced max5.336e-5nm;independent metrics max1.363e-6,target/refit max4.763e-7;original base/data/split/training-source hashes unchanged;test neverdecoded/opened. Verifier1 failed only serializing numpybool JSON;kept original frozen;v2 converts scalar types and compares rotation matrices only for identifiable domains. No retrain for verifier change. Attempt01CUDAdefaultGPU0failure before first optimizer preserved under attempt01_default_cuda_context_failure;explicit set_device(cuda1)fixed runtime,model/hyperparameters unchanged. Final training process exited0;GPU1released. Full report/results under experiments/talos97_model_improvement/phase11_domain_supervision/. Next proposed(not launched):condition/retrain local residual on learned domain transforms;do not interpret partial fitting as proof jointMSEcompetition sole cause. CodeGraph sync17:11:57–17:12:00+08 passed,3s,exit0. init.sh startup passed. No duplicate launch.

## 2026-10-30 Phase11 interpretation and oracle source audit
Read harness, full Phase11/Phase7 reports, saved independent verification (10/10 pass), and CodeGraph-located oracle/reconstruction code. No training or model/source changes. Phase11 validation seed-mean base/rigid/hybrid RMSD = 2.178041129/2.166729645/2.185114010 nm; domain translation RMSE 2.191163 nm, rotation 23.766513 deg. Frozen residual worsens rigid-only in all3seeds, but coarse transform error remains substantial; this does not isolate joint adaptation as sole bottleneck. Phase7 0.312348nm oracle fits each validation target directly via proper Kabsch, with <6node translation fallback; Phase11 0.303080nm oracle instead fits all domains and masks rank<2 only in rotation supervision. Recommended diagnostic: first freeze learned coarse transform and retrain conditional residual with matched unconditioned control, then joint adaptation separately; not launched. init.sh skipped: read-only saved-artifact/code interpretation, no substantial changes. Saved verifier evidence inspected, not rerun this turn. git status unavailable: working directory is not a Git repository.

## 2026-10-30 representation-level diagnosis
CodeGraph inspected actual localframe2m/model.py and Phase10 typed graph/Phase11 path; compared Phase1-4 reports. Main structural findings: 8 residual blocks are nodewise scalar MLPs, not 8 graph hops; graph context is fixed local/domain 1-2hop geometric averages plus shared global mean/max at readout. Phase11 pools only frozen local h[:346], excluding global context, then compresses to64 for3coarse message layers. Coarse edge features retain counts/mean lengths/relative centers/relative frames, but not explicit attachment offsets or their type-specific moments; mechanically relevant connectivity can be aliased. Frame readout spans full3D, so no missing-direction subspace claim; bounded coefficients alone are not established root cause, given Phase3/4 negative interventions and unconstrained Phase11 remaining near2.17nm. Domain oracle establishes representability, not inferability; coherent SE3 variables and coarse-local conditional decomposition remain hypotheses to test. No training/model changes; init.sh not applicable to read-only interpretation. No new probe executed; evidence is source inspection and existing verified artifacts.

## 2026-10-30 high-priority representation tools installed
User requested installation only. ./init.sh passed. Installed into ../hado_mechanical_pilot/.venv-torch (Python3.13.3, actual TALOS97 environment), not legacy ebd. uv used because env has no pip module. Dry-run and explicit core constraints preserved torch2.14.1/numpy2.5.4/scipy1.18.1/scikit-learn1.9.1/PyG2.8.1. Installed TorchLens2.36.1,Captum0.9.0,Polyscope2.6.1,PyVista0.49.2,VTK9.7.1 plus dependencies; uv pip check85packages passed. CPU smoke.py passes trace, IntegratedGradients/FeatureAblation, Ridge/MLP fits, VTK pointcloud roundtrip, Polyscope import/API. First smoke used removed TorchLens log_forward_pass; corrected to current trace API and rerun passed. Evidence: outputs/representation_tools_install_20261030/{packages_before.json,constraints.txt,smoke.py,verification.json}. docs/REPRESENTATION_TOOLS.md documents use. Interactive GUI/offscreen rendering not tested. No GPU, project data/checkpoints, model training, or representation experiments. Task complete; no CodeGraph sync needed (no project model/navigation code changed).

## 2026-10-30 GNN deep diagnosis started
User explicitly authorized autonomous staged A-D diagnosis and small discriminating experiments. ./init.sh passed. Applied ARS experiment workflow and CodeGraph navigation inline (no delegation). User authorization supersedes skill generic command-only/confirmation restrictions. Actual base/Phase10/Phase11 code inspected; new experiments/talos97_gnn_diagnostics/SPEC.md and EXPECTED_VERIFICATION.md precede runner. Fixed68/14 no test, inner54/14 train-design tuning, seed11 primary plus three-seed reconstruction and probe repeats. CPU/GPU0 untouched; GPU1/2 currently idle, recheck before use. No existing model or source edits.

## 2026-10-30 GNN deep diagnosis completed and verified
User-authorized A-D diagnosis complete in experiments/talos97_gnn_diagnostics/.
SPEC/EXPECTED_VERIFICATION before runner; adaptive AMENDMENT_D and D4 before
small follow-up fits.3seed x82frozen extraction;actual6176node TorchLens trace
51modules/74tensors,outputs unchanged;hooks verified.54probe models (Ridge+MLP
with54innerfit14tune then68refit;3MLPseeds),9warm+9fresh graph-head spatial/zero/
shuffled paired runs;single-design1000step sanity. No original source/checkpoint/
data/history modifications,test IDs not decoded/test files not opened,no W&B or
Slurm. GPU1 isolated via CUDA_VISIBLE_DEVICES=1;GPU0 untouched;GPU1now0MiB.

Independent verify.py19/19pass:all246targets/rank/reconstruction/SSE,756probe
validation outputs NumPy reproduction,252coarse-head validation CPU reproductions,
9original complete-design CPU reproductions;maxCPU3.52e-6nm(original)/2.15e-6(new),
probe5.49e-6;protected hashes unchanged. Supplemental independent single-design
metrics and VTKnode/edge geometry pass. Full report GNN_DIAGNOSTIC_REPORT_ZH.md;
README exact commands;results/source_manifest.json and delivery_manifest.json.

Main finding:domain centroid translation contributes~94.1%pooled rigid SSE;
3seed rigid2.166730nm,oracle translation only0.532664,oracle rotation only2.122081,
fulloracle0.303080. Hybrid2.185114,transported residual2.180987;coarse remains main.
Backbone does retain motion info;message3probe2.161287 matches original head;
no-message2.379769 vs original2.161287. Spatial/attachment probes show extra info:
spatial2.166128 vs mean2.225465nm,all14paired improve,shuffledspatial2.253492.
But matched fresh graph arms zero2.167764/spatial2.167932/shuffled2.172055nm;
spatial-control+0.000168nm,screen negative;do not claim pooling main cause.
Warm continuation all9innerselectedepoch0 preserved,selection caveat documented.
Single-design frozen-feature head fits tRMSE0.000751nm/angle0.015deg/endpoint0.288739;
old cross-design trainloss keeps falling while val rises => shared mapping/
generalization/finite-replica target signal more plausible than hard capacity limit.
CKAblock2/8=.99377;3hopmeanreach16.75%,longrange need untested. Captum completeness
2.43e-7relative;orientation strongest edge group,pooled85.1%mass,not physical cause.
Coarse-edge synthetic collision proves summary non-injective only,not full-input
collision or true response difference. Saturation val0;all tested grads nonzero.

Twoall-node HTML/VTPcases6hb_048(inputmedian)/6hb_072(label-selectedworst) exported;
Polyscope viewer provided,GUI untested. First VTKline export cell mismatch fixed,
original failure log preserved;no training rerun. Diagnostic summary SVG/PDF/PNG
and sourceCSV;source QA17pass3acceptedwarn0fail,PDFmin6pt,visual panels inspected.
init.sh startup/finalpass;codegraph sync . exit0 alreadyup-to-date. Existing old
report assumptions revised in new report,not overwritten. Overall1.2nmobjective
still incomplete. Next ranked experiments:translation-only typed attachment head;
replica-consistency/pooled-target contrast;matched3hopvsremote;then frozen/joint
backbone and only later conditional residual. No active diagnostic process remains.
