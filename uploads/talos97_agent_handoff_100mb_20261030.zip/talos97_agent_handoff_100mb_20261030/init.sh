#!/usr/bin/env bash
set -euo pipefail

echo "== Harness startup =="
echo "Directory: $(pwd)"

if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo
  echo "== Git status =="
  git status --short
else
  echo
  echo "== Git status =="
  echo "Not inside a git worktree."
fi

echo
echo "== Project detection =="

ran_any=false

if [ -f package.json ]; then
  ran_any=true
  echo "Detected Node.js project."
  if command -v npm >/dev/null 2>&1; then
    if npm run | grep -qE '(^| )test($| )'; then
      echo "Run tests with: npm test"
    fi
    if npm run | grep -qE '(^| )build($| )'; then
      echo "Run build with: npm run build"
    fi
    if npm run | grep -qE '(^| )check($| )'; then
      echo "Run check with: npm run check"
    fi
  else
    echo "npm is not available."
  fi
fi

if [ -f pyproject.toml ] || [ -f requirements.txt ] || [ -f setup.py ]; then
  ran_any=true
  echo "Detected Python project."
  if command -v pytest >/dev/null 2>&1; then
    echo "Run tests with: pytest"
  else
    echo "pytest is not available."
  fi
fi

if [ -f Cargo.toml ]; then
  ran_any=true
  echo "Detected Rust project."
  if command -v cargo >/dev/null 2>&1; then
    echo "Run checks with: cargo test"
  else
    echo "cargo is not available."
  fi
fi

if [ "$ran_any" = false ]; then
  echo "No known project manifest found. Harness files are ready; add stack-specific verification later."
fi

echo
echo "== Harness files =="
for file in AGENTS.md feature_list.json progress.md session-handoff.md docs/ARCHITECTURE.md docs/VERIFICATION.md; do
  if [ -f "$file" ]; then
    echo "ok  $file"
  else
    echo "missing  $file"
    exit 1
  fi
done

echo
echo "== Complete =="

