## Latest single-design overfit complete
6hb_001 overfit using2083615param frame model:2000steps lr1e-3 best0.591068nm; low-lr1e-4 fresh AdamW refinement2000 steps best0.558070nm. Did not reach0.1nm. No exact input collisions at float features. Reports outputs/talos97_frame_fit_diagnostics/OVERFIT_SINGLE_REPORT_ZH.md and overfit_one manifest/result. No pending process.

## Current authoritative status — 2026-10-29
小模型与扩容frame的3种子×200epochs均已完成，无待续训练。正式记录 docs/harness/talos97_localframe_2m/RESULTS_ZH.md、RESULTS.json（文件hash与核验证据）。扩容2083615参数，2LayerNorm/block已说明；ensemble测试2.140356nm vs小模型2.167785nm。使用最佳验证epoch48/64/50，后期过拟合；不得将下面历史PID/tmux启动记录当作当前运行状态。

## Historical expanded frame launch (completed; superseded)
experiments/talos97_localframe_2m/train.log,tmux talos97-frame2m,localRTX6000Ada.2083615params,width346,8blockswith2LayerNormeach(inferredexactcount;communicated),3seeds200epochs,original68/14/15. Gatepassedlargest9996node. Checkactualhistory/metricsbeforecompletionclaim. Old9987param full97completedpreserved.

## Historical small frame launch (completed; superseded)
Completed historical run experiments/talos97_localframe_study/full97/run_full97.py; former PID483232,tmux talos97-localframe,gpu11RTX6000Ada.3seeds11/22/33,total200epochs each. Importedvalidation-selectedframe,9987params,positiononly,original68/14/15. Checktrain.log,results/history_live.json,checkpoints/frame_*.pt,results/metrics.csv beforeclaimcomplete. Sourcearchive/modelpreserved,SPEC+manifest. DatasetverificationPASS. No sbatch.

## Latest AI diagnostics follow-up complete
Read-only outputs/talos97_model_diagnostics/extended/followup/REPORT_ZH.md and verification.json. Joint channel permutation control passed; finalvector radialgradient strongly suppressed by RMSreadout. DGNNlocaldescentexists; no claimofoptimizationfailure. No originalmodeltraining/updates. Parent sixphase artifacts preserved.

## Latest completed diagnostic deliverable
Sixphase readonlyanalysis complete:outputs/talos97_model_diagnostics/extended/DIAGNOSTIC_REPORT_ZH.md,manifest,5requiredCSV,figures,tensorboard,verification. Nooriginalmodelsmodified/trained. Checkpointsourcehashverified.12designsubsetnotfull97. Keyinference:vectorDIRECTIONfunctional,positiveuniformSCALEcancelled;globalctxsmallinconsistent;probeweakpartial;gradientfinite,noclaimoptimizationefficiency. OriginalsingleGPUbatch17264continuesunmodified.

## Additional local1Mcapacityexperiment
UserrequestsDGNN-lite~1Mlocaltraining.Isolated experiments/talos97_dgnn_lite_1m,hidden256expected998921params,50epochs,samefrozendata/loss/seed;tmux talos97-dgnn1m,logruns/train.log.Check gate/status/history/metrics beforeclaim. OriginalsingleGPUbatch17264unchanged.

## Latest: SINGLE GPU bundled job17264
User forbidsmultiplearraytasks.Cancelled17254allconfirmed.New17264singleGPU,singlejob remaining_sequential_200.sbatch sequentialremaining10models,total200epochs,7days,A100/A6000/H100.Noarray.No localtmuxtraining. Monitor sequential200-17264.log and permodelsequential200.log;checkpointresumeautomatic,skiponlycompleted200epoch.

## Latest override: remaining200epoch sbatch
User explicitly requests sbatch again on any availableA100/A6000/H100.6completedmodelskeep50epochresults;remaining10total200epochs.Array17254(tasks0-9 no concurrencycap)submitted; mapping configs/remaining_200.json and scripts/remaining_200.sbatch.Localcontroller60843andchild60851stopped,tmuxclosed.GraphFlowresumeslastcheckpoint;noadapter/train.py changesneeded.No duplicate localrun. Monitor squeue/sacct17254,slurm200logs,permodelstatus/metrics.

## Latest resource override
User forbids sbatch.17224cancelled(alltasks sacctverified).Use ONLY local H100 gpu17; tmux talos97-train-h100,local_campaign.py and runs/local_campaign.json,permodel local.log. SharedMLPresumeepoch46audited with preservedoriginals. Allocation16718expires22:12:59; no autoSlurm submission. Earlier17224runningnotes below superseded.

# TALOS97 model benchmark active

User requested all inventoried applicable models trained on reusable97design dataset, spec beforecode. Contract docs/harness/talos97_model_benchmark/SPEC.md; data experiments/talos97_endpoint_v1/data. Input actual initial.dat t0, targetreplica1 1000frame mean,notlastframe. Fixed68/14/15. Data verificationpassed;16largestdesign gatespassed.

Slurmarray17224,16tasks concurrency1,A100/A6000,excludegpu29. Task0shared_mlp RUNNING gpu27 atlastcheck epoch8. Check squeue -j17224 and runs/slurm-17224_*.log, permodelstatus/history/best,last,metrics. Never claimcomplete without metrics and Slurmexit. Remainingtasksqueued. Eachtaskown gate before50epochs. Code scripts/train.py,models.py,verify_dataset.py,build_dataset.py,train.sbatch. Python HADO .venv-torch/bin/python.

Adapters are original classes;ebd_diffusion simplified16stepblur adaptation,forceEuler notXPBD,rigid2layers49D,Fourier sparsemix. These caveats inSPEC. EBD unnormalizedstrand aggregation numericalexplosion corrected inadapter;allgates rerunpassed. Kinematic finitebutverylargeinitialloss,needmonitor. Some runner improvements occurred whiletask0running; checkpoint sourcehash intentionallypreventsunauditedresume underchangedscripts. Do not blindlyrequeue completedruns or duplicatetraining. Needmonitorall16,repairrealruntimefailures,finalizecomparativeRMSDreportafterjobsfinish. Current firsttasknotyetscientificimprovementoveridentity.


## 2026-10-29 TALOS97 status handoff

No TALOS97 training is active. Local H100 was idle at audit time; Slurm 17254 is CANCELLED and 17264 is FAILED. The unified endpoint-v1 matrix has final metrics for 15/16 models: six 50-epoch and nine 200-epoch runs; kinematic failed at epoch 8 with non-finite gradients and has no metrics. Do not claim the matrix fully complete or compare architectures without disclosing the epoch mismatch.

Current best verified test result across the audited TALOS97 experiments is the three-seed localframe_2m ensemble, 2.140356 nm (1.265% below the 9,987-parameter ensemble). The best single checkpoint in the common endpoint-v1 matrix is trap_target, 2.213537 nm test / 2.229745 nm validation, best epoch 70. Its 200 epochs versus OnePass's 50 epochs and later overfit mean the small lead is not a controlled architecture win. Full analysis: docs/harness/talos97_model_benchmark/BEST_MODEL_AUDIT_ZH.md.

No training, model inference, or checkpoint edits were made during this audit. If resuming work, first decide whether to diagnose/retry kinematic and run matched-budget trap_target/OnePass controls; do not auto-submit or start a local run based only on historical harness launch notes.

## 2026-10-29 OnePass improvement continuation

`./init.sh` passed. Current live check: no TALOS97-matching process or tmux session; local H100 query is 0 MiB / 0%. Slurm has user job 17439 RUNNING on H100/gpu17 and job 17440 PENDING on A100; `scontrol` reports `Command=(null)`, so their workload cannot be classified from this audit. No new training was started. Overall archived test best is the three-seed `localframe_2m` ensemble at 2.140356 nm; best single checkpoint in endpoint-v1 is `trap_target` at 2.213537 nm test / 2.229745 nm validation. Read `docs/harness/talos97_model_benchmark/BEST_MODEL_AUDIT_ZH.md` for mechanism limits: the local-frame parameter increase is confounded with width/depth/LayerNorm, while trap_target's 4 nm bound is plausible but unablated and its budget was 200 versus OnePass's 50 epochs.

Phase 1 OnePass error localization is complete. Phase 2 reuse audit is verified at `experiments/talos97_model_improvement/phase2_representation_audit/results/REPORT_ZH.md` and `summary.json`; all checkpoint/data/source hashes and output counts match, and the reused representation subset is exactly three of the current 14 validation designs. No test rows were read by the audit; no inference/training/checkpoint edits occurred.

Phase 3 completed in H100 allocation 17439 on gpu17. All six runs (3 paired data-order seeds × 2 arms × 50 epochs) passed verification. Frozen OnePass validation was 2.25108692 nm; control continuation mean 2.24103099 nm; RMS-augmented mean 2.23959296 nm, only 0.00143803 nm better than control and below the predeclared 0.05 nm screening threshold. `results/verification.json` passes 11 checks, with unchanged checkpoint/data/source hashes and no test rows or predictions. Read `phase3_vector_rms_readout/results/REPORT_ZH.md`.

Phase 4 per-node amplitude gate is running in the existing Slurm allocation 17439 on gpu17; no new job submitted. Spec and expected verification were written first. Preflight passed: zero-init output matches frozen OnePass within 3.251e-6 nm max position difference and 1.848e-6 max rotation-element difference; gain=1 and optimizer steps=0. tmux `talos97-phase4-amplitude`, Python PID 219835; log `experiments/talos97_model_improvement/phase4_node_amplitude_gate/train.log`. First control seed11 epoch1 validation is 2.248121 nm. Six runs × 50 epochs are planned; final outcome is pending. Test data remains untouched and the Phase 1 checkpoint is protected. Continue toward the 1.2 nm goal.


## 2026-10-29 Phase 4 完成后的当前状态

Phase 4 节点幅度门已在 allocation 17439 / gpu17 完成。实时核查确认训练进程结束并生成六套 checkpoint/history；`verify_results.py` 全部通过。冻结 OnePass 为 2.25108692 nm，控制续训均值 2.24096015 nm，幅度门均值 2.24218363 nm，幅度门相对控制退化 0.00122348 nm；三个 seed 均未胜出，按 SPEC 判为负结果。原 checkpoint、数据和源哈希不变，未读取或写出 test 行。下一步应先设计并写 SPEC/EXPECTED_VERIFICATION，再执行新的、能直接检验训练目标与大位移节点误差关系的干预；不能把 2.24 nm 或历史最佳模型审计结果当作约 1.2 nm 目标已完成。


## 2026-10-29 Phase 5 ready to launch

Current active objective remains to bring fixed-14 validation macro RMSD near 1.2 nm. Phase 4 is completed and verified negative. Phase 5 has SPEC and EXPECTED_VERIFICATION written before code; py_compile and CPU/preflight run passed. Frozen OnePass reproduced at 2.25108693 nm, exact epoch-zero equivalence is within 5.585e-6 nm position and 3.427e-6 rotation element; scale 2.286727 nm is computed from 68 train designs only. Last actual resource audit: Slurm allocation 17439 RUNNING on gpu17/H100 (12h limit, through 19:18 UTC), no competing TALOS97 process, GPU 0 MiB/0%, and overlapping srun probe confirmed the node/job context. Recheck allocation/process/GPU and run preflight from within allocation before starting the six paired runs. Test data must remain unloaded.


## 2026-10-29 Phase 5 完成后的当前状态

Phase 5 metric-aligned loss 已完成并通过核验。冻结 OnePass 2.25108693 nm；控制续训 2.24103641 nm；scaled smooth per-design RMSD 目标 2.23922198 nm；干预相对控制仅改善 0.00181443 nm，未过 0.05 nm 筛选线。三 seed 均改善且最大设计级回归未超过0.20 nm，但这仍是负结果。训练尺度 2.286727 nm 由68个训练设计计算；test未加载；checkpoint、数据、split、源哈希不变。17439 仍为 RUNNING/H100 gpu17，但 Phase 5 进程已结束；下一步需重新写结构/表示干预的 SPEC 与 EXPECTED_VERIFICATION，不能将目前2.239 nm当作1.2 nm目标完成。


## 2026-10-29 Phase 6 active handoff

TransformerConv Phase 6 preflight passed; exact values and PyG provenance are in `experiments/talos97_model_improvement/phase6_transformerconv/results/preflight.json`. A matched 3-seed × 2-arm, 50-epoch training run is active as `srun` session 19368 under existing Slurm allocation 17439 on gpu17/H100. There is no new job submission. Check `runs/*/status.json` and `history.jsonl`; stdout is attached to session 19368. Source hashes include `run_intervention.py`, `verify_results.py`, Phase 3/OnePass sources and installed TransformerConv source, so do not modify these during training. After all six runs complete, run the verifier, produce `results/REPORT_ZH.md`, verify test isolation and checkpoint hash, then update this handoff and `progress.md`. Overall 1.2 nm objective remains in progress.


## 2026-10-29 Phase 6 completed — latest TALOS97 improvement status

TransformerConv matched continuation is complete and independently verified. Functionality passed: neighbor rewiring changes messages, opening the scalar residual gate changes predictions, the disposable train-only gradient probe reaches gate/TransformerConv/projection, and all real TransformerConv runs also recorded nonzero branch gradients. PyG 2.8.1, four 16-wide heads, edge_dim 20. Validation means: control 2.24103101 nm, TransformerConv 2.24099734 nm (−0.00003367 nm); below the predeclared 0.05 nm improvement threshold, so negative scientific result. No test IDs/rows/predictions; original checkpoint unchanged. Report: `experiments/talos97_model_improvement/phase6_transformerconv/results/REPORT_ZH.md`; verification: `.../results/verification.json`.

Training used existing allocation 17439 / gpu17 / H100; it is complete and no Phase 6 process remains. A post-training verifier import fix changed only the verifier file hash; this is recorded explicitly. All training/model/data/split/checkpoint/PyG implementation hashes match the run provenance. Overall objective is still 14-design validation macro RMSD about 1.2 nm; next work should preregister a new hypothesis before implementation and preserve the test split boundary.


## 2026-10-29 Phase 7 complete; Phase 8 preregistered

Phase 7 read-only audit and independent verification are complete. `experiments/talos97_model_improvement/phase7_domain_motion_audit/results/verification.json` passes 11 checks. Fixed-14 validation macro RMSD: OnePass 2.25108691 nm, saved localframe ensemble 2.15703061 nm, identity 2.60264151 nm. Validation-label-fitted domain translation/rigid oracle: 0.60304314 / 0.31234822 nm and 94.73% / 98.59% pooled identity SSE reduction. Treat these as optimistic diagnostics only; no model can use these label-fitted transforms at inference.

The Phase 7 analyzer/verifier index only the frozen 14 validation prediction keys; complete prediction archive bytes are hashed without key enumeration. `split.json` is hash-only in this audit. No training, inference, optimizer step, or checkpoint modification occurred. Read `phase7_domain_motion_audit/results/REPORT_ZH.md` for the motion-bin table and caveats.

Phase 8 is preregistered as a matched 3-seed × 2-arm, 50-epoch continuation from the three validation-selected `localframe_2m` checkpoints, adding a zero-gated domain SE(3) transform plus the existing local residual. SPEC and EXPECTED_VERIFICATION are in `experiments/talos97_model_improvement/phase8_domain_transform_residual/`. No runner exists and no training or job has been started. Before execution, perform a fresh resource audit and preserve the test boundary. The fixed-14 validation target near 1.2 nm remains incomplete.


## 2026-10-29 Phase 9 result audit completed
All 12 long/short/gate/control runs completed (3 seeds, 50 epochs each, 40,800 steps). Existing verify_results.py run via ../hado_mechanical_pilot/.venv-torch/bin/python exited 0; all five checks passed, report and routing artifacts generated. Validation macro RMSD nm: control/frozen 2.157030525, hard 2.167525705, soft 2.150482389, label oracle 2.070482995. Hard promising=false; soft gain only 0.006548136 nm (0.304%). Gate macro recall 0.035947989 and F1 0.064846482 at fixed threshold 0.5. Oracle is label-assisted diagnosis only. No training or test inference. init.sh skipped: saved-artifact status audit without source changes. CodeGraph navigation skill used to locate Phase 9. Overall 1.2 nm goal remains incomplete.


## 2026-10-29 Phase 9 compact GitHub evidence package
User requested <100MB archive centered on systematic long-node underprediction, representative example and best weights only. Built outputs/phase9_github_bundle_20261029/talos97_phase9_long_displacement_evidence_20261029.zip (31,563,407 bytes); ZIP integrity and 57 SHA256 manifest entries passed. All-14-design amplitude ratio table selects median-nearest representative 6hb_009: 614 long nodes, true mean4.765269nm, baseline1.720688nm, ratio0.361089, 99.6743% underpredicted. Best single-seed soft model is seed11 (validation2.171487nm); retained three expert/gate weights and frame11 base weight only. Includes all training histories, reports and code, example vectors/CSV, exact manifest and build script. No full dataset or test data. Three-seed headline metrics cannot be reproduced using selected-seed weights alone; README states dependencies and incompleteness explicitly. Upload via hado-github-upload skill to private configured artifacts repository; see final response for verified commit. No model training or source edits.

## 2026-10-29 scalar RMSF training active
User approved transfer vs scratch x seeds11/22/33 x200epochs on localframe2m scalar Softplus head. Isolated experiments/talos97_rmsf_scalar; SPEC before code. Existing allocation17439/gpu17/H100 used, no submission. Python PID316359, exec session73312; log train.log; results/status.json and history.jsonl authoritative. 82train/validation loaded;15test features/labels deferred until frozen selection.97input/topology hashes checked; train-only constant1.634973526nm. Gate passed both arms largest train9942nodes,2,081,537params, nonzero backbone/head grads. After completion run ../hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_rmsf_scalar/verify.py; inspect independent_verification, REPORT, selection. Do not edit train.py/backbone.py/SPEC while active. Local checkpoint originals protected via provenance hashes. codegraph sync passed(18:54:06–18:54:08,+08,2s,exit0). No duplicate launch.

## 2026-10-29 scalar RMSF training completed and verified
Isolated experiments/talos97_rmsf_scalar:localframe2m encoder snapshot,1038->1+Softplus,2,081,537params. Transfer/scratch x11/22/33 x200epochs,81,600updates; train process exited0, no new job submission. Fixed68/14/15,all97designs834348nodes,topology/cache hashes match. Features initial-only;train-only normalization and constant1.634973526nm;test arrays deferred until six checkpoints/arm choice frozen. Transfer chosen by mean seed validation0.390280481 vs scratch0.393291065nm. Predefined transfer ensemble valRMSE0.384231/testRMSE0.367138/testMAE0.278730nm;constant testRMSE0.448998nm (18.23% improvement);scratch ensemble test0.376779nm. All10 independent verifier checks passed(exit0),including best epoch/history, CPU checkpoint prediction reproduction, all873metric rows recomputed, ensembles, hashes. Original sources/weights/data unchanged. predict.py three-checkpoint CPU CLI6176rows agrees with saved GPU ensemble max7.09e-7nm. transfer22 last checkpoint Softplus collapsed to zero;best epoch29 normal;full histories and collapse audit preserved, no hidden retries/hyperparameter changes. Labels finite-trajectory pooled3replica RMSF;all97needs_review,no convergence/significance claim. REPORT_ZH.md and README contain usage,results,limits. No RMSF process remains.

## 2026-10-29 TALOS97 input package complete; upload deferred
User originally requested GitHub upload,then explicitly steered to compression first. Built outputs/talos97_inputs_upload_20261029/talos97_inputs_97designs_20261029.zip,185077825bytes,97inputNPZ preserving inputs/6hb_009.npz,split,README,source manifest,perNPZhashes. ZIPtest and all97SHA256 checks passed;SHA256ee46eeb3801e6827b2e3499112aba24bdcc0b0a03d7860ea53e6c4ca686ed390. Three90MB/90MB/5077825byteparts also prepared locally for futureGitHub limits;reassemblyhash verified. No copy,commit,push to artifacts checkout. Existinguntrackedfiles preserved. init.sh skipped:artifact-only packaging,no model/source changes.

## 2026-10-29 TALOS97 two-volume GitHub upload completed
User explicitly requested exactly2volumes<100MB thenGitHub. Created zip.vol01=92538913bytes,vol02=92538912bytes;combinedSHA256 matches originalZIPee46eeb3801e6827b2e3499112aba24bdcc0b0a03d7860ea53e6c4ca686ed390. Used hado-github-upload skill,uploaded only2volumes+DOWNLOAD.md+PACKAGE.json,commit b4adcbb2c9b3d474e9ddd6bc229102a6e73528b9. Push exit0;remote main ls-remote equalscommit;ls-tree verifies4files andsizes. Existinguntrackedfiles untouched. No training/sourcechanges.

## 2026-10-30 Root-cause audit and literature synthesis completed
New bounded artifact: `experiments/talos97_model_root_cause/`. `SPEC.md` and `EXPECTED_VERIFICATION.md` were written before `audit_data.py`; `./init.sh` passed at startup. The audit opens exactly the 68 train and 14 validation triplicate summary JSONs and Phase 7 validation tables, stops before test IDs, and performs no inference/training/checkpoint write. Run with the HADO torch Python; `results/verification.json` passes 8/8 checks. `results/summary.json` records train/validation ESS, replica disagreement, RMSF, drift, exploratory n=14 correlations, and hashes. `results/REPORT_ZH.md` is the Chinese evidence synthesis with verified OpenAlex/Crossref/arXiv citations.

Evidence: every train/validation design has min ESS <10 and `needs_review`; validation mean min ESS 3.890, max replica-mean disagreement 2.061 nm, pooled RMSF 1.726 nm. Long-bin target mean is 4.772 nm while OnePass/localframe means are 1.602/1.759 nm. Validation-label domain rigid oracle remains 0.312 nm, so label uncertainty is material but cannot explain the entire model gap. The report recommends explicit domain-level SE(3) variables on a coarse domain/helix graph, local nucleotide residual decoding, and uncertainty-aware replica targets before EBD-style diffusion.

Phase 8 domain-transform runner already exists on disk (earlier handoff wording saying no runner is stale). CPU preflight was executed with `--device cpu --preflight-only` and passed: zero-gate max difference 3.337e-8 nm, global rotation equivariance error 0, domain relabel error 0, determinant range 0.9999998–1.0000002, sampled rigid-distance error 9.54e-7 nm, open-gate prediction change 0.05997 nm, and nonzero gate/translation/rotation gradients. Do not start Phase 8 training automatically: current local H100/gpu17 is occupied by unrelated Slurm jobs 19133/19134, and no permitted free allocation was established. If training is explicitly resumed, rerun a resource audit, keep `gpu29` excluded, use matched 3-seed control/domain arms, and run `verify_results.py` before making any claim.

## 2026-10-30 resource re-audit

`codegraph sync .` and `./init.sh` both pass. Current Slurm state still has gpu17 `MIXED+DRAIN` with unrelated jobs 19133/19134. A100 nodes are mixed with active allocations (including job 19789 on gpu03), and A6000 nodes are mixed/allocated/draining/drained. No explicitly granted free A100/A6000/H100 allocation was found, so Phase 8 remains preflight-only. The next agent may submit only a normal A100/A6000 job with `--exclude=gpu29` if the user wants training resumed; do not run on a shared visible GPU or claim a result before the independent verifier passes.

The root-cause report now distinguishes node-pooled long-motion values (4.936/1.480/1.646 nm for target/OnePass/localframe) from the equal-design macro values stored in `summary.json` (4.772/1.602/1.759 nm). Both aggregations support the same underprediction conclusion; the root-cause verification remains passing.

## 2026-10-30 Phase 8 completed locally

User clarified the host has three local A100 GPUs. Slurm job 19831 was cancelled while pending. GPU 0 had active Python allocations (~39.8 GiB); GPU 1 and 2 were idle. Phase 8 ran on local `cuda:1`, no training job was submitted. A100 preflight passed and six matched arms (3 seeds × control/domain-transform × 50 epochs) completed, 20,400 optimizer steps.

Final integrity verifier: `experiments/talos97_model_improvement/phase8_domain_transform_residual/verify_results_v2.py`; all 9 checks pass in `results/verification.json`. Original verifier output is preserved as `verification_initial_failure.json`; its two flags were verifier semantics/source-manifest issues, not run failures. Scientific result: control mean validation 2.175492 nm; domain-transform 2.178041 nm, candidate +0.002549 nm worse; 1/3 seeds improved; all candidate best epochs 0; max per-design regression 0.053119 nm. Ensemble control/candidate 2.154073/2.157031 nm. Test untouched and frozen base checkpoints unchanged. Read `results/REPORT_ZH.md` and root-cause `experiments/talos97_model_root_cause/results/REPORT_ZH.md`. Do not repeat the same simple pooled-domain head; next useful branch is typed domain/helix coarse graph with explicit inter-domain communication and replica-aware targets.

## 2026-10-30 Phase10 preflight passed and training launched
Preflight13/13 passed on localA100cuda1: zero-gate3.414e-8nm, open equivariance2.529e-7nm, relabel2.666e-7nm; neighbor rewiring prediction change0.001421nm and edge-type erasure0.004071nm. All projector/head/3message-layer gradients nonzero. Largest9942node backward761.44MiB;2,218,982parameters. Six paired50epoch runs launched as execsession17582, train.log under Phase10. GPU1 idle immediately before launch, GPU0 untouched. Test not decoded/opened; all sources frozen after launch. This compares graph branch package including anchor-frame readout, not graph-only causal isolation. Paired edges within domains explain zero inter-domain type2 counts. Verify saved metrics/checkpoint CPU reproduction after completion; no duplicate launch.

## 2026-10-30 Phase10 typed domain graph completed and verified
Six runs completed localA100cuda1,20400steps; no Slurm submission/W&B. Three64wide typed message layers,all inter-domain nucleotide relations,anchor-relative geometry;2,218,982parameters. Preflight13/13 and independent12/12 pass. Control mean2.175491668nm vs graph2.176664398nm (worse0.001172730nm); ensembles2.154073/2.155920nm. Graph bestepochs0/6/0. Raw1/3improved count is seed11 -1.385e-10nm numerical tie;22/33worse. Long-node amplitude ratio macro0.391173control/0.376755graph;long endpoint RMSD3.652987/3.682644nm. Negative screen;1.2nmgoal incomplete.
All84selected checkpoint/validation outputs CPU reproduced max5.516e-6nm; independent dictionary verifies all82designs coarse relation counts. Metrics/bestepochs/orders/ensembles/protected hashes pass. Test untouched; original checkpoints unchanged. Branch functional/trainable but no validation gain. Artifacts: experiments/talos97_model_improvement/phase10_typed_domain_graph/results/REPORT_ZH.md and verification.json. No training process remains; GPU1 freed. Do not relaunch histories. Next proposed diagnostic(not launched): train-only domain-transform supervision with frozen backbone to separate fitting and joint-loss branch competition; new SPEC required. CodeGraph sync16:45:18–16:45:22+08,4s,exit0. Final init.sh passed. A harness update script encountered an entry without id; corrected using get before writing; model/run/verifier sources unaffected.

## 2026-10-30 Phase11 runner completed and launched
User requested completing and starting Phase11. SPEC clarified BEFORE implementation/training:3seed50epoch frozen-base direct-domain transform supervision; no zero gate/tanh limits; translation Euclidean loss+1nm^2 Frobenius rotation loss, rank<2domains excluded from rotation. Report rigid-only, hybrid with input/frozen-prediction-only intradomain residual, additive double-counting diagnostic separately. All68+14 train/validation metrics per epoch; select by validation transform loss. diagnostic_model.py and run_experiment.py/verify_results.py complete, py_compile passed. LocalA100GPU1 idle before launch; exec89465 running,train.log under Phase11. Preflight runs BEFORE optimizer; all protected hashes written. No test/W&B. Do not edit frozen runner/verifier/dependencies while running or duplicate launch. Copied legacy model.py/base_utils.py not used. Final independent246design CPU reproduction required.

## 2026-10-30 Phase11 complete and independently verified
Three seeds x50epochs,10200updates completed on localA100cuda1. Bestepochs20/11/20. Frozen BasisNet cached; only identity-init/unbounded typed3layer domain heads train. Train+val fitting screen3/3pass each. Val translationRMSE2.6074->2.1871/2.1986/2.1878nm;rotation29.0124->23.6128/24.1021/23.5846deg. Val rigid-only2.161287/2.174603/2.164300nm vs base2.174161/2.179434/2.180528;hybrid2.175008/2.199466/2.180868nm. Domain movement partially predictable but no stable hybrid endpoint gain,1.2nmgoal incomplete. Val long hybrid amplitude ratio0.402702 vs base0.378597;long RMSD3.642653 vs3.685912nm,small improvement only.2184rank<2domains excluded from rotation supervision;translations retained.
Preflight10/10 and independent verify_results_v2.py10/10pass. All246train/val checkpoint outputs CPU reproduced max5.336e-5nm;independent metrics max1.363e-6,target/refit max4.763e-7;original base/data/split/training-source hashes unchanged;test neverdecoded/opened. Verifier1 failed only serializing numpybool JSON;kept original frozen;v2 converts scalar types and compares rotation matrices only for identifiable domains. No retrain for verifier change. Attempt01CUDAdefaultGPU0failure before first optimizer preserved under attempt01_default_cuda_context_failure;explicit set_device(cuda1)fixed runtime,model/hyperparameters unchanged. Final training process exited0;GPU1released. Full report/results under experiments/talos97_model_improvement/phase11_domain_supervision/. Next proposed(not launched):condition/retrain local residual on learned domain transforms;do not interpret partial fitting as proof jointMSEcompetition sole cause. CodeGraph sync17:11:57–17:12:00+08 passed,3s,exit0. init.sh startup passed. No duplicate launch.

## 2026-10-30 GNN deep diagnosis completed and verified
User-authorized A-D diagnosis complete in experiments/talos97_gnn_diagnostics/.
SPEC/EXPECTED_VERIFICATION before runner; adaptive AMENDMENT_D and D4 before
small follow-up fits.3seed x82frozen extraction;actual6176node TorchLens trace
51modules/74tensors,outputs unchanged;hooks verified.54probe models (Ridge+MLP
with54innerfit14tune then68refit;3MLPseeds),9warm+9fresh graph-head spatial/zero/
shuffled paired runs;single-design1000step sanity. No original source/checkpoint/
data/history modifications,test IDs not decoded/test files not opened,no W&B or
Slurm. GPU1 isolated via CUDA_VISIBLE_DEVICES=1;GPU0 untouched;GPU1now0MiB.

Independent verify.py19/19pass:all246targets/rank/reconstruction/SSE,756probe
validation outputs NumPy reproduction,252coarse-head validation CPU reproductions,
9original complete-design CPU reproductions;maxCPU3.52e-6nm(original)/2.15e-6(new),
probe5.49e-6;protected hashes unchanged. Supplemental independent single-design
metrics and VTKnode/edge geometry pass. Full report GNN_DIAGNOSTIC_REPORT_ZH.md;
README exact commands;results/source_manifest.json and delivery_manifest.json.

Main finding:domain centroid translation contributes~94.1%pooled rigid SSE;
3seed rigid2.166730nm,oracle translation only0.532664,oracle rotation only2.122081,
fulloracle0.303080. Hybrid2.185114,transported residual2.180987;coarse remains main.
Backbone does retain motion info;message3probe2.161287 matches original head;
no-message2.379769 vs original2.161287. Spatial/attachment probes show extra info:
spatial2.166128 vs mean2.225465nm,all14paired improve,shuffledspatial2.253492.
But matched fresh graph arms zero2.167764/spatial2.167932/shuffled2.172055nm;
spatial-control+0.000168nm,screen negative;do not claim pooling main cause.
Warm continuation all9innerselectedepoch0 preserved,selection caveat documented.
Single-design frozen-feature head fits tRMSE0.000751nm/angle0.015deg/endpoint0.288739;
old cross-design trainloss keeps falling while val rises => shared mapping/
generalization/finite-replica target signal more plausible than hard capacity limit.
CKAblock2/8=.99377;3hopmeanreach16.75%,longrange need untested. Captum completeness
2.43e-7relative;orientation strongest edge group,pooled85.1%mass,not physical cause.
Coarse-edge synthetic collision proves summary non-injective only,not full-input
collision or true response difference. Saturation val0;all tested grads nonzero.

Twoall-node HTML/VTPcases6hb_048(inputmedian)/6hb_072(label-selectedworst) exported;
Polyscope viewer provided,GUI untested. First VTKline export cell mismatch fixed,
original failure log preserved;no training rerun. Diagnostic summary SVG/PDF/PNG
and sourceCSV;source QA17pass3acceptedwarn0fail,PDFmin6pt,visual panels inspected.
init.sh startup/finalpass;codegraph sync . exit0 alreadyup-to-date. Existing old
report assumptions revised in new report,not overwritten. Overall1.2nmobjective
still incomplete. Next ranked experiments:translation-only typed attachment head;
replica-consistency/pooled-target contrast;matched3hopvsremote;then frozen/joint
backbone and only later conditional residual. No active diagnostic process remains.
