# 给另一台电脑 Agent 的 TALOS97 模型诊断交接包

本包包含部分真实NPZ输入和标签、实际模型/训练代码、原三seed权重、
当前诊断的代码与结果摘要，以及可在CPU独立运行的子集核验程序。
请先阅读本说明和NEXT_AGENT_PROMPT_ZH.md，再阅读诊断报告。

## 最快开始

建议Python3.11–3.13，新建环境。在解压后的根目录运行：

```bash
python -m venv .venv
# Linux/macOS；Windows可直接使用 .venv\Scripts\python.exe
source .venv/bin/activate
python -m pip install -r requirements-minimal.txt
python portable_verify.py --output portable_verification.json
```

无需GPU、PyG或原服务器路径。CPU验证会核对包内文件SHA256，从原checkpoint
重新计算全部子集设计的三个seed的base/rigid/hybrid，并与原保存坐标和指标比较。
本包权重使用torch.load(...,weights_only=False)，仅加载随包附带且已核对哈希的文件。
首次验证可能耗时数分钟，依机器而定。

需要TorchLens/Captum/probe/3D分析时再安装requirements-analysis.txt。
原运行环境的精确版本记录在ENVIRONMENT_ORIGINAL.json，其中torch是特殊CUDA13构建；
不要求另一台电脑强行安装相同CUDA构建。minimal环境主要用于CPU数值重现，
analysis依赖的跨版本支持需在新机检查。PyVista/Polyscope GUI需要显示/OpenGL。

## 数据与单位

- SUBSET.json列出8train+6validation设计和选择规则；不含test数据/ID。
- inputs/<ID>.npz为source-only初始结构，labels/<ID>.npz为监督，原始目录在
  experiments/talos97_endpoint_v1/data/。
- pos是原oxDNA坐标除以40并居中；物理nm=pos×34.072（40×0.8518）。
- rotation为列向量框架；domain_ids=virtual_helix×floor(axial_index/16)的离散分组。
- 标签是replica1的有限轨迹1000帧均值，经全局对齐初始结构；不是3replica均值。
- 域平移是目标质心减输入质心，域旋转由proper Kabsch拟合。rank<2域的旋转不可辨识。
- 数据split保留原68/14训练/验证ID以便代码定位，只有SUBSET.json中的14份数据实际存在。
  split的test为空；manifest是带源文件hash的子集描述，二者都不是原文件的字节拷贝。
- 选取是为覆盖输入尺寸和已有诊断案例，不是新随机评估集。不能用14设计子集重算
  原68/14总体指标，也不能宣称子集重新训练等价于原实验。

## 当前结论：已验证与未解决

原3seed验证rigid2.166730nm；只替换真实平移0.532664nm，只替换真实旋转
2.122081nm；约94%pooled SSE来自域质心偏差。Oracle读取标签，只用于定位误差。
粗图消息有效，backbone保留一定运动信号；单设计能近精确拟合域平移。
空间/连接特征让probe改善，但真实粗头空间矩对照平均无实际收益。
所以不能把“连接摘要压缩”或“mean pooling”当作已证实的唯一/主要原因。

特别说明：平移是已定位的主要故障，连接点编码只是待测原因之一。
下一轮应围绕“如何准确预测跨设计域平移”，区分输入、远程传播、共享映射学习
和目标重复性；不要把再做连接点编码预设为必然正确的方向。

## 主要路径

- experiments/talos97_gnn_diagnostics/GNN_DIAGNOSTIC_REPORT_ZH.md：完整报告。
- 同目录SPEC、AMENDMENT：先验和追加决策；results/verification.json为原19/19核验。
- 同目录results、figures：指标、源数据和静态图。三维可视化脚本保留，HTML/VTP已删以控制大小。
- 同目录probes/followup/fresh：保留JSON/CSV结果，删除小实验权重和NPZ输出。
- 诊断cache全部省略，可用原模型和本包NPZ重新提取；portable_verify不需要cache。
- experiments/talos97_localframe_2m/model.py、run_full97.py：实际base架构/原训练入口；
  checkpoints/frame_{11,22,33}.pt为原3seed验证选点权重。
- experiments/talos97_model_improvement/phase10_typed_domain_graph/：Phase11依赖的
  实际粗图构造、message层、原联合训练代码。
- experiments/talos97_model_improvement/phase11_domain_supervision/diagnostic_model.py、
  run_experiment.py：实际执行的模型与训练；runs/seed*/best.pt和history.jsonl为原记录。
- Phase11同目录model.py/base_utils.py是早期未使用的复制文件，不能误认成实际模型。
- 旧Phase1–9与root-cause报告保留科学背景，不代表当前未验证假设已成为结论。
- AGENTS/progress/handoff为原服务器上下文；其中旧环境路径/GPU/作业状态不适用于新机。

## 完整性与可复现范围

MANIFEST_SHA256.json覆盖全部交付文件；压缩包SHA256在GitHub外层PACKAGE.json。
源代码、原3seed模型权重、数据NPZ按字节保留；路径根通过__file__解析，CPU子集
核验无需修改原代码。原始结果中的绝对路径/hash是历史证据，不应视为新机文件位置。

本包没有原MD轨迹、oxDNA执行程序、完整97/82设计数据、全量诊断缓存、其他旧模型
checkpoint或测试预测。原全量verify.py和训练入口会因缺少数据而不能直接完整运行；
请用portable_verify.py作本包可复现入口。原代码保留用于阅读、修改和设计后续实验，
不要直接重跑并覆盖原results/history。若要完整重训，需要补齐数据并另开输出目录。

原始诊断的19/19完整性通过不等于新模型性能改善，也不等于本子集独立复现了全部实验。

## 100 MB 精简版

本版压缩包及外层说明合计低于100,000,000 bytes。保留14设计NPZ、三个seed原模型与Phase11权重、训练代码和诊断报告；删除全部诊断激活缓存、probe/对照小实验权重与NPZ、Phase1大型中间NPZ、生成的3D HTML/VTP。原诊断结果作为历史证据保留；若要重做全部诊断，需重新提取缓存并补齐数据。REMOVED_FILES.json记录省略项。
