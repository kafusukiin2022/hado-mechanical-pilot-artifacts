# TALOS97 GNN deep diagnostics

Start with [GNN_DIAGNOSTIC_REPORT_ZH.md](GNN_DIAGNOSTIC_REPORT_ZH.md).
Plan: `SPEC.md`, `EXPECTED_VERIFICATION.md`; adaptive decisions were recorded
before additional training in `AMENDMENT_D.md` and `AMENDMENT_D4.md`.

Active runtime from repository root:

```bash
../hado_mechanical_pilot/.venv-torch/bin/python \
  experiments/talos97_gnn_diagnostics/verify.py
```

Verification reads exactly68train/14validation; never decodes test IDs. It
recomputes target/metrics, probe weights and selected coarse checkpoints on CPU.
Completed outputs must not be overwritten or training silently restarted.

The original execution sequence was (each script refuses completed result sets):

```bash
CUDA_VISIBLE_DEVICES=1 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
  ../hado_mechanical_pilot/.venv-torch/bin/python -u \
  experiments/talos97_gnn_diagnostics/extract.py --device cuda:0
# After extraction completes:
CUDA_VISIBLE_DEVICES=1 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
  ../hado_mechanical_pilot/.venv-torch/bin/python -u \
  experiments/talos97_gnn_diagnostics/probes.py --device cuda:0
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
  ../hado_mechanical_pilot/.venv-torch/bin/python -u \
  experiments/talos97_gnn_diagnostics/analyze.py --device cpu
# After inspecting B/C results and writing amendment D:
CUDA_VISIBLE_DEVICES=1 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
  ../hado_mechanical_pilot/.venv-torch/bin/python -u \
  experiments/talos97_gnn_diagnostics/followup.py --device cuda:0
# After warm-start outcome, amendment D4:
CUDA_VISIBLE_DEVICES=1 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
  ../hado_mechanical_pilot/.venv-torch/bin/python -u \
  experiments/talos97_gnn_diagnostics/fresh_head.py --device cuda:0
```

`common.py` defines source-only features and explicit label-only targets;
`extract.py` records hooks and actual TorchLens trace, all3seed reconstructions;
`probes.py` performs inner-design-selected Ridge/MLP fitting;
`analyze.py` runs CKA, rank/nearest-neighbor descriptors, Captum, computational
ablations, gradient and graph support checks;
`followup.py`/`fresh_head.py` contain bounded matched spatial-head experiments.
`summarize.py` produces paired whole-design intervals; `plot_summary.py` creates
the summary figure; `visualize.py` exports all-node HTML and PyVista/VTK assets.

No new dependencies were installed for this task. GPU0 was occupied and not used;
GPU1 was isolated as CUDA device0. No Slurm submission, W&B or external upload.
Existing raw data, sources and checkpoints were never modified.

Open `visualizations/6hb_048.html` and `visualizations/6hb_072.html` in a browser.
For Polyscope, use a machine/display with OpenGL:

```bash
../hado_mechanical_pilot/.venv-torch/bin/python \
  experiments/talos97_gnn_diagnostics/view_polyscope.py 6hb_048
```

Interactive GUI rendering has not been verified on this headless server.
Use `results/verification.json` for integrity checks and the report for scientific
interpretation; a verifier pass is not evidence of positive performance gains.
