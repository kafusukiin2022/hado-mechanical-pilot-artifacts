#!/usr/bin/env python3
"""D4 fresh-branch spatial experiment; preserves all warm-start results."""
import argparse
import time
from common import *
from followup import tensor_data,spatial_shuffle,loss_head,eval_head


def fresh(seed,device):
    torch.manual_seed(seed);head=DiagnosticHead().to(device)
    original=head.projector[0];expanded=torch.nn.Linear(442,64).to(device)
    with torch.no_grad():
        expanded.weight[:,:346].copy_(original.weight);expanded.weight[:,346:].zero_();expanded.bias.copy_(original.bias)
    head.projector[0]=expanded
    return head


def fit(cache,train,tune,seed,device,epochs,select):
    head=fresh(seed,device);initial_hash=old.state_hash(head.state_dict())
    opt=torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=.0001)
    rng=np.random.default_rng(seed);history=[];best=float('inf');n=0;extra=None
    for ep in range(epochs+1):
        digest=None
        if ep:
            head.train();order=[str(i) for i in rng.permutation(train)]
            digest=hashlib.sha256('\n'.join(order).encode()).hexdigest()
            for ident in order:
                opt.zero_grad(set_to_none=True);loss=loss_head(head,cache[ident]);loss.backward()
                if ep==2 and extra is None:extra=float(head.projector[0].weight.grad[:,346:].abs().sum())
                torch.nn.utils.clip_grad_norm_(head.parameters(),5);opt.step()
        tr,_=eval_head(head,cache,train)
        held,_=eval_head(head,cache,tune) if select else (tr,{})
        value=held['macro']['loss']
        history.append(dict(epoch=ep,train_loss=tr['macro']['loss'],tune_loss=value if select else None,train_order_sha256=digest))
        if value<best:best=value;n=ep
    return head,n,history,initial_hash,extra


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--device',default='cuda:0');args=ap.parse_args()
    torch.set_num_threads(2);device=torch.device(args.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    if (RESULTS/'fresh_complete.json').exists():raise FileExistsError('Fresh results exist')
    tr,va,inner,tune=ids();data={i:read_cache(i) for i in tr+va};spatial_shuffle(data,tr+va)
    folder=HERE/'fresh';folder.mkdir(exist_ok=True);results=[];start=time.time()
    for arm in ['zero','spatial','shuffled']:
        cache=tensor_data(data,tr+va,device,arm)
        for seed in [11,22,33]:
            model,n,history,initial_hash,extra=fit(cache,inner,tune,seed,device,30,True)
            del model
            model,_,refit,initial2,extra2=fit(cache,tr,[],seed,device,n,False)
            assert initial_hash==initial2
            trainmetrics,_=eval_head(model,cache,tr,data);valmetrics,arrays=eval_head(model,cache,va,data)
            save_npz(folder/f'graph_{arm}_{seed}_predictions.npz',**arrays)
            torch.save(dict(state={k:v.cpu() for k,v in model.state_dict().items()},arm=arm,seed=seed,
                       selected_epoch=n),folder/f'graph_{arm}_{seed}.pt')
            row=dict(arm=arm,seed=seed,selected_epoch=n,history=history,refit_history=refit,
                     initial_state_sha256=initial_hash,extra_epoch2_grad=extra,refit_extra_epoch2_grad=extra2,
                     parameters=sum(p.numel() for p in model.parameters()),train=trainmetrics,validation=valmetrics)
            results.append(row);dump(RESULTS/'fresh_graph.json',dict(runs=results))
            dump(RESULTS/'status.json',dict(stage='fresh_head',arm=arm,seed=seed,elapsed=time.time()-start))
            print('FRESH',arm,seed,'epochs',n,'train',round(trainmetrics['macro']['loss'],5),'val',round(valmetrics['macro']['loss'],5),
                  'endpoint',round(valmetrics['macro']['rigid_rmsd_nm'],5),'seconds',round(time.time()-start,1),flush=True)
            del model
    dump(RESULTS/'fresh_complete.json',dict(passed=True,runs=9,elapsed=time.time()-start))
    print('FRESH COMPLETE',flush=True)


if __name__=='__main__':main()
