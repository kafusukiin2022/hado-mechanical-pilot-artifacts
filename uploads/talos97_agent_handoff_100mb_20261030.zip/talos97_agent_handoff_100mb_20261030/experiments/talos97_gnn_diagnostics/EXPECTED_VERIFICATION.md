# Expected verification

1. Parsed68/14 match frozen IDs, train/inner/validation disjoint, no test access.
2. Every input/label/base/Phase11 checkpoint and dependency source hash unchanged.
3. Frozen original endpoint and Phase11 outputs reproduce saved per-design scores
   within1e-4nm; use all3seeds for reconstruction and seed11 for layer extraction.
4. Kabsch determinant+1, orthogonality and synthetic conventions pass; rank masks
   preserved. Oracle t/R reconstruction agrees with independent SVD.
5. Manual layer capture reproduces actual network outputs; TorchLens trace agrees
   or documented compatibility exception; no checkpoint modifications by tracing.
6. Saved probe scaler/weights yield independently recomputable validation outputs,
   equal-design metrics, finite rotations. Probe selection inner-only and logs match.
7. CKA symmetric with unit diagonal on nonconstant layers; rank finite and bounded.
8. Ablation score recomputation, IG finite/completeness,3hop perturbation support,
   and synthetic old-summary collision/new-feature separation checked.
9. Reconstruction SSE = rigid SSE + residual SSE + cross term, within tolerance;
   oracle swaps and rotation-transported residual independently recomputed.
10. Figure/VTK output finite and geometrically consistent, all14validation metrics
    present; logs record seeds, device, versions, exact commands and any failures.
11. Scientific conclusions distinguish observation, predictive association,
    intervention on model computation, and untested physical explanation.
12. Final report includes limitations and next falsifying experiments; harness
    progress/feature/handoff updated. No 1.2nm completion claim absent evidence.
