#!/usr/bin/env python3
"""Frozen model interventions, attribution, graph reach, representation similarity."""
import argparse
import copy
import time
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import shortest_path
from sklearn.neighbors import NearestNeighbors
from common import *


def representation_stats(data,names):
    layers=['normalized_input','fc1','fc2']+[f'block{k}' for k in range(1,9)]+['projector','message1','message2','message3']
    rows=[]
    for ident in names:
        n=len(data[ident]['valid']);rows.append(np.random.default_rng(812).choice(n,min(n,48),replace=False))
    arrays=[np.concatenate([data[i]['rep_'+key][row] for i,row in zip(names,rows)]).astype(float) for key in layers]
    centered_arrays=[a-a.mean(0) for a in arrays]
    ranks=[]
    for key,a in zip(layers,centered_arrays):
        eig=np.linalg.eigvalsh(a.T@a);eig=np.maximum(eig,0);p=eig/max(eig.sum(),1e-12);active=p>0
        ranks.append(dict(layer=key,dimensions=a.shape[1],effective_rank=float(np.exp(-np.sum(p[active]*np.log(p[active])))),
                     stable_rank=float(eig.sum()/max(eig.max(),1e-12)),std=float(a.std()),rows=len(a)))
    norms=[np.linalg.norm(a.T@a,'fro') for a in centered_arrays]
    cka=np.zeros((len(arrays),len(arrays)))
    for i,a in enumerate(centered_arrays):
        for j in range(i+1):
            value=float(np.linalg.norm(a.T@centered_arrays[j],'fro')**2/max(norms[i]*norms[j],1e-20));cka[i,j]=cka[j,i]=value
    save_npz(RESULTS/'cka.npz',cka=cka,layers=np.array(layers))
    dump(RESULTS/'representation_stats.json',dict(layers=ranks,cka=cka,layer_names=layers,design_balanced_rows=True))


def nearest_disagreement(data,tr,va):
    result={}
    for rep in ['input','block8','projector','message3']:
        # Keep balanced64domains/design. Cross-design lookup, never same design.
        rows={i:np.random.default_rng(615).choice(len(data[i]['valid']),min(64,len(data[i]['valid'])),replace=False) for i in tr+va}
        x=np.concatenate([data[i]['rep_'+rep][rows[i]] for i in tr]);mu=x.mean(0);sd=x.std(0).clip(.01)
        target=np.concatenate([data[i]['target_vector'][rows[i],:3] for i in tr])
        z=np.concatenate([data[i]['rep_'+rep][rows[i]] for i in va]);truth=np.concatenate([data[i]['target_vector'][rows[i],:3] for i in va])
        distance,idx=NearestNeighbors(n_neighbors=1).fit((x-mu)/sd).kneighbors((z-mu)/sd)
        difference=np.linalg.norm(target[idx[:,0]]-truth,axis=1)
        order=np.argsort(distance[:,0]);n=max(1,len(order)//10)
        result[rep]=dict(query_domains=len(z),median_standardized_distance=float(np.median(distance)),
                        median_translation_disagreement_nm=float(np.median(difference)),
                        closest_decile_disagreement_nm=float(np.mean(difference[order[:n]])),
                        farther_decile_disagreement_nm=float(np.mean(difference[order[-n:]])))
    dump(RESULTS/'neighbor_disagreement.json',result)


def synthetic_collision():
    local=np.array([[0.,-1.,-2.],[0.,1.,-2.],[0.,-1.,2.],[0.,1.,2.]])
    x=np.concatenate([local+[-5,0,0],local+[5,0,0]])
    raw=dict(pos=x/NM,rotation=np.broadcast_to(np.eye(3),(8,3,3)).copy(),
             domain_ids=np.array([0]*4+[1]*4),edge_types=np.array([0,0]))
    a=dict(raw,edge_index=np.array([[0,4],[4,0]]))
    b=dict(raw,edge_index=np.array([[2,6],[6,2]]))
    ga=p10.coarse_graph(a,torch.device('cpu'));gb=p10.coarse_graph(b,torch.device('cpu'))
    ga={k:npv(v) if isinstance(v,torch.Tensor) else v for k,v in ga.items()}
    gb={k:npv(v) if isinstance(v,torch.Tensor) else v for k,v in gb.items()}
    fa=attachment_features(a,ga);fb=attachment_features(b,gb)
    olddiff=float(np.max(np.abs(ga['features']-gb['features'])));newdiff=float(np.max(np.abs(fa-fb)))
    assert olddiff<1e-7 and newdiff>.1
    dump(RESULTS/'synthetic_collision.json',dict(old_edge_max_diff=olddiff,attachment_max_diff=newdiff,
        source_positions_nm=x,edges_a=a['edge_index'],edges_b=b['edge_index'],old_features=ga['features'],
        attachment_a=fa,attachment_b=fb,scope='coarse edge aggregation only; base pooled states not asserted identical; no response labels'))


def graph_from_cache(d,device):
    return {k:torch.as_tensor(d[v],device=device,dtype=torch.long if k in ['edges','index'] else torch.float32)
            for k,v in [('edges','edges'),('features','edge_features'),('index','index'),('frames','frames'),('centers','centers')]}


def frozen_interventions(data,tr,va,device):
    _,head=models(11,device)
    trainmean=np.mean([data[i]['rep_block8'].mean(0) for i in tr],0)
    edgemean=np.mean([data[i]['edge_features'].mean(0) for i in tr],0)
    results={};reach=[]
    for ident in va:
        d=data[ident];graph=graph_from_cache(d,device);pooled=torch.as_tensor(d['rep_block8'],device=device)
        def evaluate(p,g):
            with torch.no_grad():t,r=head(p,g)
            metrics=domain_metrics(npv(t),npv(r),d)
            metrics['translation_change_nm']=float(np.sqrt(np.mean(np.sum((npv(t)-d['pred_t'])**2,1))))
            metrics['rotation_matrix_change']=float(np.sqrt(np.mean(np.sum((npv(r)-d['pred_r'])**2,(1,2)))))
            return metrics,t,r
        row={};row['original']=evaluate(pooled,graph)[0]
        for label,sl in [('counts',slice(0,5)),('length',slice(5,6)),('centers',slice(6,9)),('orientation',slice(9,18)),('all_edge_features',slice(0,18))]:
            g=dict(graph);g['features']=graph['features'].clone();g['features'][:,sl]=torch.as_tensor(edgemean[sl],device=device)
            row[label]=evaluate(pooled,g)[0]
        g=dict(graph);g['features']=graph['features'].clone()
        g['features'][:,:5]=0;g['features'][:,0]=torch.log1p(torch.expm1(graph['features'][:,:5]).sum(1))
        row['collapse_types']=evaluate(pooled,g)[0]
        g=dict(graph);g['edges']=torch.empty((2,0),device=device,dtype=torch.long);g['features']=torch.empty((0,18),device=device)
        row['no_messages']=evaluate(pooled,g)[0]
        g=dict(graph);g['edges']=graph['edges'].clone();perm=torch.as_tensor(np.random.default_rng(913).permutation(len(g['edges'][1])),device=device)
        g['edges'][1]=g['edges'][1,perm]
        row['rewired']=evaluate(pooled,g)[0]
        mean=torch.as_tensor(trainmean,device=device).expand_as(pooled)
        row['pooled_trainmean']=evaluate(mean,graph)[0]
        perm=torch.as_tensor(np.random.default_rng(914).permutation(len(pooled)),device=device)
        row['pooled_permutation']=evaluate(pooled[perm],graph)[0]
        results[ident]=row
        # One source perturbation, symmetric magnitude relative to train-mean.
        source=int(np.bincount(d['edges'][0],minlength=len(pooled)).argmax())
        pert=pooled.clone();pert[source]=torch.as_tensor(trainmean,device=device)
        _,t,r=evaluate(pert,graph)
        adj=coo_matrix((np.ones(d['edges'].shape[1]),(d['edges'][0],d['edges'][1])),shape=(len(pooled),len(pooled))).tocsr()
        distance=shortest_path(adj.T,directed=True,indices=source,unweighted=True)
        change=np.linalg.norm(npv(t)-d['pred_t'],axis=1)+np.linalg.norm((npv(r)-d['pred_r']).reshape(-1,9),axis=1)
        bydistance={str(k):dict(domains=int(np.sum(distance==k)),mean_change=float(change[distance==k].mean()) if np.any(distance==k) else 0.) for k in range(4)}
        far=distance>3
        reach.append(dict(design=ident,source_domain=source,total_domains=len(pooled),within3_fraction=float(np.mean(distance<=3)),
                          far_domains=int(far.sum()),far_max_change=float(change[far].max()) if far.any() else 0.,by_distance=bydistance,
                          finite_max_distance=float(distance[np.isfinite(distance)].max())))
    labels=list(next(iter(results.values())))
    dump(RESULTS/'ablations.json',dict(per_design=results,macro={k:macro([results[i][k] for i in va]) for k in labels},
        scope='fixed trained head computational interventions; mean replacement/rewiring/no_messages are OOD, not physical counterfactuals'))
    dump(RESULTS/'graph_reach.json',reach)
    # Attribution representative chosen solely by input size median.
    ident=sorted(va,key=lambda i:len(data[i]['x']))[len(va)//2];d=data[ident];g=graph_from_cache(d,device)
    from captum.attr import IntegratedGradients
    class Energy(torch.nn.Module):
        def __init__(self):super().__init__();self.head=head
        def forward(self,p,e):
            outputs=[]
            for v,z in zip(p,e):
                local=dict(g,features=z);t,r=self.head(v,local)
                outputs.append(t.square().sum(1).mean())
            return torch.stack(outputs)
    wrapper=Energy().eval()
    p=torch.as_tensor(d['rep_block8'],device=device)[None]
    e=g['features'][None];p0=torch.as_tensor(trainmean,device=device)[None,None].expand_as(p)
    e0=torch.as_tensor(edgemean,device=device)[None,None].expand_as(e)
    ig=IntegratedGradients(wrapper)
    attrs,delta=ig.attribute((p,e),baselines=(p0,e0),n_steps=64,internal_batch_size=1,return_convergence_delta=True)
    with torch.no_grad():actual=float(wrapper(p,e));baseline=float(wrapper(p0,e0))
    massp=float(attrs[0].abs().sum());masse=float(attrs[1].abs().sum());den=max(massp+masse,1e-12)
    groups={name:float(attrs[1][:,:,sl].abs().sum())/den for name,sl in [('counts',slice(0,5)),('length',slice(5,6)),('centers',slice(6,9)),('orientation',slice(9,18))]}
    save_npz(RESULTS/'captum_attribution.npz',pooled=npv(attrs[0]),edges=npv(attrs[1]))
    dump(RESULTS/'captum.json',dict(design=ident,output='mean squared predicted translation (nm2), no labels',
        steps=64,actual=actual,baseline=baseline,convergence_delta=float(delta.abs().max()),
        relative_delta=float(delta.abs().max())/max(abs(actual-baseline),1e-8),
        pooled_abs_mass_fraction=massp/den,edge_abs_mass_fraction=masse/den,edge_groups=groups,
        baseline_description='equal-design training mean; OOD path; attribution not causal physics'))
    print('ATTRIBUTION COMPLETE',ident,'delta',float(delta.abs().max()),flush=True)


def training_audit(data,tr,va,device):
    histories={}
    for seed in (11,22,33):
        rows=[json.loads(v) for v in (P11/'runs'/f'seed{seed}'/'history.jsonl').read_text().splitlines()]
        best=min(rows,key=lambda v:v['validation']['loss']);last=rows[-1]
        histories[str(seed)]=dict(best_epoch=best['epoch'],initial=rows[0],best=best,last=last)
    base,head=models(11,device)
    ident=sorted(tr,key=lambda i:len(data[i]['x']))[len(tr)//2];d=data[ident];raw=raw_design(ident)
    s,B,R=p10.geometry(raw,True);s=torch.as_tensor(s,device=device);g=graph_from_cache(d,device)
    base.zero_grad(set_to_none=True);head.zero_grad(set_to_none=True)
    _,h=base.encode(s);pooled=p10.segment_mean(h[:,:346],g['index'],len(g['frames']));t,r=head(pooled,g)
    tt=torch.as_tensor(d['target_t'],device=device,dtype=torch.float32);rr=torch.as_tensor(d['target_r'],device=device,dtype=torch.float32);mask=torch.as_tensor(d['valid'],device=device)
    loss=(t-tt).square().sum(1).mean()+(r[mask]-rr[mask]).square().sum((1,2)).mean();loss.backward()
    groups={'base_fc1':base.fc1,'base_fc2':base.fc2,**{f'base_block{k+1}':b for k,b in enumerate(base.residual_blocks)},
            'projector':head.projector,**{f'message{k+1}':b for k,b in enumerate(head.layers)},'translation':head.translation,'rotation':head.rotation}
    grads={name:dict(l2=float(torch.sqrt(sum(p.grad.square().sum() for p in m.parameters() if p.grad is not None))),
                     parameters=sum(p.numel() for p in m.parameters())) for name,m in groups.items()}
    dump(RESULTS/'training_audit.json',dict(histories=histories,backprop_probe_design=ident,
         gradients=grads,optimizer_steps=0,note='temporarily differentiable copies; no checkpoint updates',
         coefficient_saturation_train=float(np.mean([data[i]['node_saturation_fraction'] for i in tr])),
         coefficient_saturation_validation=float(np.mean([data[i]['node_saturation_fraction'] for i in va]))))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--device',default='cuda:0');args=ap.parse_args()
    torch.set_num_threads(2);device=torch.device(args.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    tr,va,_,_=ids();data={i:read_cache(i) for i in tr+va};start=time.time()
    representation_stats(data,tr+va);print('CKA COMPLETE',flush=True)
    nearest_disagreement(data,tr,va);synthetic_collision();training_audit(data,tr,va,device)
    frozen_interventions(data,tr,va,device)
    dump(RESULTS/'analysis_complete.json',dict(passed=True,elapsed=time.time()-start))


if __name__=='__main__':main()
