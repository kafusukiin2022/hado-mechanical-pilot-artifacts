# D4: fresh-head spatial test, after warm-start continuation selected epoch0

Written before this additional fit. D1 inner tuning selects0epochs in the runs
observed so far (zero/spatial all3seeds and shuffled seed11). The selected head
was originally fit on all68designs including the new inner tuning designs.
Its warm-start tuning loss can therefore favor no change; a zero-step result
cannot distinguish absent spatial information from a continuation/selection barrier.
Preserve D1 intact and classify it as no deployable gain, with this limitation.

Minimal correction: start a NEW DiagnosticHead from random projector/message
weights and identity-zero final heads, rather than the selected Phase11 head.
Use the same frozen seed11 backbone cache for all arms. The346->64 initial
projector is expanded to442->64, extra96columns zero, giving exactly identical
initial predictions/parameters between zero/spatial/shuffled arms for each seed.
No head parameters have seen the new inner tuning targets at initialization.
The backbone has seen all68targets during original endpoint training; disclose.

Three seeds11/22/33 x three arms x30inner epochs (54train/14tune). AdamW0.001,
weight_decay0.0001, clip5, paired order. Select epoch0..30 by inner tuning domain
transform loss, reset identical initial head, refit68 for selected epoch count.
Original validation used only for final reporting, never selection. Report same
metrics/screen as D1. Do not merge or conceal warm-start negative outcomes.
This tests the proposed spatial representation within this budget; it does not
change backbone, graph depth, targets, or residuals simultaneously.
