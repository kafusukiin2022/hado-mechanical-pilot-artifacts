#!/usr/bin/env python3
"""Independent numpy metric/target audit and CPU checkpoint reproduction."""
import json
import time
from scipy.special import expit
from common import *


def independent_fit(x,y,index):
    ts=[];rs=[];valid=[];out=np.empty_like(y)
    for k in range(index.max()+1):
        m=index==k;a=x[m];b=y[m];ac=a.mean(0);bc=b.mean(0)
        u,_,vt=np.linalg.svd((a-ac).T@(b-bc));sgn=1 if np.linalg.det(u@vt)>=0 else -1
        rot=(u@np.diag([1.,1.,sgn])@vt).T
        singular=np.linalg.svd(a-ac,compute_uv=False)
        valid.append(np.sum(singular>max(singular[0]*1e-6,1e-8))>=2)
        ts.append(bc-ac);rs.append(rot);out[m]=(a-ac)@rot.T+bc
    return np.array(ts),np.array(rs),np.array(valid),out


def independent_score(t,r,d):
    x=d['x'];y=d['target'];index=d['index'];m=d['valid'];targetr=d['target_r']
    tl=np.mean(np.sum((t-d['target_t'])**2,1));rl=np.mean(np.sum((r[m]-targetr[m])**2,(1,2)))
    angles=[]
    for a,b in zip(r[m],targetr[m]):angles.append(np.degrees(np.arccos(np.clip((np.trace(a.T@b)-1)/2,-1,1))))
    pred=np.empty_like(x)
    for k in range(len(t)):
        sel=index==k;center=x[sel].mean(0);pred[sel]=(x[sel]-center)@r[k].T+center+t[k]
    pred+=x.mean(0)-pred.mean(0)
    rms=np.sqrt(np.mean(np.sum((pred-y)**2,1)))
    return dict(loss=float(tl+rl),translation_mse_nm2=float(tl),translation_rmse_nm=float(np.sqrt(tl)),
                rotation_frobenius=float(rl),rotation_deg=float(np.mean(angles)),rigid_rmsd_nm=float(rms))


def check_rows(record,arrays,data,va):
    diff=0.;rotation=0.
    for ident in va:
        t=arrays[ident+'__t'].astype(float);r=arrays[ident+'__r'].astype(float)
        v=independent_score(t,r,data[ident]);reference=record['validation']['per_design'][ident]
        diff=max(diff,max(abs(v[k]-reference[k]) for k in v))
        rotation=max(rotation,float(np.max(np.abs(np.swapaxes(r,1,2)@r-np.eye(3)))),float(np.max(np.abs(np.linalg.det(r)-1))))
    return diff,rotation


def independent_probe(model_path,x):
    if model_path.suffix=='.npz':
        with np.load(model_path) as a:
            return ((x-a['mean'])/a['std'])@a['coef'].T+a['bias']
    m=torch.load(model_path,map_location='cpu',weights_only=False);s={k:npv(v) for k,v in m['state'].items()}
    z=((x-m['mean'])/m['std']).astype('float32')
    h=z@s['0.weight'].T+s['0.bias'];h=h*expit(h)
    return h@s['2.weight'].T+s['2.bias']


def main():
    torch.set_num_threads(2);start=time.time();tr,va,inner,tune=ids();checks={};evidence={}
    before=json.loads((RESULTS/'provenance_before.json').read_text());checks['protected_hashes']=before==provenance()
    checks['split_inner_design_disjoint']=len(inner)==54 and len(tune)==14 and not(set(inner)&set(tune)) and set(inner+tune)==set(tr) and not(set(tr)&set(va))
    data={i:read_cache(i) for i in tr+va}
    maxfit=0.;maxsse=0.;maxreconstruction=0.;node_partition={}
    reconstruction=json.loads((RESULTS/'reconstruction.json').read_text())
    for seed in (11,22,33):
        partition=[]
        for ident in tr+va:
            d=data[ident] if seed==11 else read_cache(ident,seed)
            tt,rr,valid,oracle=independent_fit(d['x'],d['target'],d['index'])
            maxfit=max(maxfit,float(np.max(np.abs(tt-d['target_t']))),float(np.max(np.abs(rr[valid]-d['target_r'][valid]))))
            assert np.array_equal(valid,d['valid'])
            row=reconstruction[str(seed)]['per_design'][ident]
            m=independent_score(d['pred_t'],d['pred_r'],d)
            maxreconstruction=max(maxreconstruction,max(abs(m[k]-row[k]) for k in m))
            maxsse=max(maxsse,abs(row['rigid_mse']+row['residual_mse']+row['cross_mse']-row['hybrid_mse']))
            # Exact domain-centroid / within-domain endpoint SSE partition.
            x=d['x'];y=d['target'];index=d['index'];pred=np.empty_like(x)
            for k in range(len(tt)):
                z=index==k;c=x[z].mean(0);pred[z]=(x[z]-c)@d['pred_r'][k].T+c+d['pred_t'][k]
            pred+=x.mean(0)-pred.mean(0)
            error=pred-y;centroid=np.empty_like(error)
            for k in range(len(tt)):
                z=index==k;centroid[z]=error[z].mean(0)
            c_sse=float(np.sum(centroid**2));w_sse=float(np.sum((error-centroid)**2));total=float(np.sum(error**2))
            assert abs(c_sse+w_sse-total)/max(total,1)<1e-10
            if ident in va:partition.append(dict(design=ident,centroid_sse=c_sse,within_domain_sse=w_sse,total_sse=total,centroid_fraction=c_sse/total))
        node_partition[str(seed)]=dict(per_design=partition,macro_centroid_fraction=float(np.mean([v['centroid_fraction'] for v in partition])),
            pooled_centroid_fraction=sum(v['centroid_sse'] for v in partition)/sum(v['total_sse'] for v in partition))
    dump(RESULTS/'sse_partition.json',node_partition)
    checks['independent_targets_and_rank_masks']=maxfit<1e-6
    checks['independent_reconstruction_metrics']=maxreconstruction<1e-6
    checks['exact_sse_decomposition']=maxsse<1e-8
    evidence.update(max_target_difference=maxfit,max_reconstruction_metric_difference=maxreconstruction,max_sse_difference=maxsse)
    # Original frozen checkpoint CPU reproduction,9full designs spanning input sizes.
    sample=[min(tr,key=lambda i:len(data[i]['x'])),sorted(va,key=lambda i:len(data[i]['x']))[len(va)//2],max(va,key=lambda i:len(data[i]['x']))]
    maxcpu=0.
    for seed in (11,22,33):
        base,head=models(seed,torch.device('cpu'))
        for ident in sample:
            raw=raw_design(ident);s,B,R=p10.geometry(raw,True);g=p10.coarse_graph(raw,torch.device('cpu'))
            with torch.no_grad():
                _,h=base.encode(torch.as_tensor(s));delta=base.readout(h,torch.as_tensor(B),torch.as_tensor(R))[0]
                pooled=p10.segment_mean(h[:,:346],g['index'],len(g['frames']));t,r=head(pooled,g)
            d=data[ident] if seed==11 else read_cache(ident,seed)
            maxcpu=max(maxcpu,float(np.max(np.abs(npv(t)-d['pred_t']))),float(np.max(np.abs(npv(r)-d['pred_r']))),float(np.max(np.abs(npv(delta)-d['base_delta']))))
    checks['original_cpu_checkpoint_reproduction_9designs']=maxcpu<1e-4;evidence['max_original_cpu_prediction_difference_nm']=maxcpu
    from followup import spatial_shuffle,new_head,tensor_data
    spatial_shuffle(data,tr+va)
    records=json.loads((RESULTS/'probes.json').read_text())+json.loads((RESULTS/'spatial_shuffle_probes.json').read_text())
    maxmetric=0.;maxrotation=0.;maxprobe=0.;selection=True;count=0
    for rec in records:
        rep=rec['representation'];kind=rec['kind'];folder=HERE/('followup' if rep=='spatial_shuffled' else 'probes')
        stem=f'{kind}_{rep}'+(f"_{rec['seed']}" if kind=='mlp' else '') if kind!='baseline' else rep
        with np.load(folder/f'{stem}_predictions.npz') as arrays:
            diff,rdiff=check_rows(rec,arrays,data,va);maxmetric=max(maxmetric,diff);maxrotation=max(maxrotation,rdiff)
            if kind!='baseline':
                x=np.concatenate([data[i]['rep_'+rep] for i in va]).astype(float)
                path=folder/(stem+('.pt' if kind=='mlp' else '.npz'))
                actual=independent_probe(path,x);reference=np.concatenate([arrays[i+'__vector'] for i in va])
                maxprobe=max(maxprobe,float(np.max(np.abs(actual-reference))))
            count+=len(va)
        if kind=='ridge':
            tune_key='inner_tune_loss' if 'inner_tune_loss' in rec['tuning'][0] else 'tune_loss'
            selection &= rec['alpha']==min(rec['tuning'],key=lambda v:v[tune_key])['alpha']
        if kind=='mlp':selection &= rec['selected_steps']==min(rec['history'],key=lambda v:v['tune_loss'])['step']
    checks['probe_inner_selection']=bool(selection)
    checks['independent_probe_predictions']=maxprobe<2e-4
    checks['independent_probe_metrics']=maxmetric<1e-4 and maxrotation<1e-5
    evidence.update(probe_validation_design_outputs=count,max_probe_vector_difference=maxprobe,max_probe_metric_difference=maxmetric,max_rotation_error=maxrotation)
    from analyze import graph_from_cache
    maxgraph=0.;maxgraphmetric=0.;selection=True;params=set();initial_hashes={}
    for filename,foldername in [('graph_followup.json','followup'),('fresh_graph.json','fresh')]:
        runs=json.loads((RESULTS/filename).read_text())['runs']
        for rec in runs:
            selection &= rec['selected_epoch']==min(rec['history'],key=lambda v:v['tune_loss'])['epoch']
            params.add(rec['parameters'])
            if filename=='fresh_graph.json':
                initial_hashes.setdefault(rec['seed'],set()).add(rec['initial_state_sha256'])
            seed=rec['seed'];arm=rec['arm'];stem=f'graph_{arm}_{seed}';model=new_head(torch.device('cpu'))
            model.load_state_dict(torch.load(HERE/foldername/f'{stem}.pt',map_location='cpu',weights_only=False)['state']);model.eval()
            tensorcache=tensor_data(data,va,torch.device('cpu'),arm)
            with np.load(HERE/foldername/f'{stem}_predictions.npz') as arrays:
                diff,rdiff=check_rows(rec,arrays,data,va);maxgraphmetric=max(maxgraphmetric,diff)
                for ident in va:
                    d=tensorcache[ident]
                    with torch.no_grad():t,r=model(d['pooled'],d['graph'])
                    maxgraph=max(maxgraph,float(np.max(np.abs(npv(t)-arrays[ident+'__t']))),float(np.max(np.abs(npv(r)-arrays[ident+'__r']))))
            # Verify every per-epoch order hash independently.
            for history,names in [(rec['history'],inner),(rec['refit_history'],tr)]:
                rng=np.random.default_rng(seed)
                for row in history[1:]:
                    digest=hashlib.sha256('\n'.join(str(i) for i in rng.permutation(names)).encode()).hexdigest()
                    selection &= row['train_order_sha256']==digest
            assert len(rec['refit_history'])==rec['selected_epoch']+1
    checks['graph_inner_selection_and_paired_orders']=bool(selection)
    checks['graph_equal_parameters_and_initialization']=len(params)==1 and all(len(v)==1 for v in initial_hashes.values())
    checks['graph_252validation_cpu_reproductions']=maxgraph<1e-4 and maxgraphmetric<1e-4
    evidence.update(max_graph_cpu_difference=maxgraph,max_graph_metric_difference=maxgraphmetric,graph_parameters=list(params))
    cka=np.load(RESULTS/'cka.npz')['cka'];checks['cka_symmetry_and_diagonal']=bool(np.allclose(cka,cka.T,atol=1e-10) and np.allclose(np.diag(cka),1,atol=1e-8))
    collision=json.loads((RESULTS/'synthetic_collision.json').read_text());checks['coarse_edge_collision']=collision['old_edge_max_diff']<1e-7 and collision['attachment_max_diff']>.1
    ig=json.loads((RESULTS/'captum.json').read_text());checks['captum_completeness']=ig['relative_delta']<.01
    reach=json.loads((RESULTS/'graph_reach.json').read_text());checks['three_hop_support']=max(v['far_max_change'] for v in reach)<1e-5
    checks['torchlens_output_unchanged']=json.loads((RESULTS/'torchlens.json').read_text())['passed']
    checks['visualization_all_nodes']=all(v['all_nodes_preserved'] for v in json.loads((RESULTS/'visualizations.json').read_text()).values())
    checks['protected_hashes_after_verify']=before==provenance()
    sourcefiles=[HERE/n for n in ['common.py','extract.py','analyze.py','probes.py','followup.py','fresh_head.py','verify.py','SPEC.md','EXPECTED_VERIFICATION.md','AMENDMENT_D.md','AMENDMENT_D4.md','visualize.py']]
    dump(RESULTS/'source_manifest.json',{str(p.relative_to(HERE)):old.sha(p) for p in sourcefiles})
    result=dict(passed=all(checks.values()),checks=checks,evidence=evidence,test_ids_decoded=False,test_files_opened=False,
                elapsed=time.time()-start,scientific_success_separate=True)
    dump(RESULTS/'verification.json',result)
    print(json.dumps(result,indent=2),flush=True)
    if not result['passed']:raise SystemExit(1)


if __name__=='__main__':main()
