#!/usr/bin/env python3
"""Paired design-unit statistics and report source data; no selection or training."""
import csv
from common import *


def paired(a,b,key,designs):
    # Average seeds within design first. Designs, not nodes/seeds, are bootstrap units.
    delta=np.array([np.mean([r['validation']['per_design'][i][key] for r in a])-
                    np.mean([r['validation']['per_design'][i][key] for r in b]) for i in designs])
    rng=np.random.default_rng(661);boots=delta[rng.integers(len(delta),size=(10000,len(delta)))].mean(1)
    return dict(mean=float(delta.mean()),design_bootstrap95=np.quantile(boots,[.025,.975]),
                per_design=dict(zip(designs,delta)),improved_designs=int(np.sum(delta<0)),
                max_regression=float(delta.max()),unit='14designs, seeds averaged first; exploratory unadjusted interval')


def main():
    tr,va,_,_=ids();probes=json.loads((RESULTS/'probes.json').read_text())+json.loads((RESULTS/'spatial_shuffle_probes.json').read_text())
    fresh=json.loads((RESULTS/'fresh_graph.json').read_text())['runs'];recon=json.loads((RESULTS/'reconstruction.json').read_text())
    probe_summary={}
    reps=sorted({r['representation'] for r in probes if r['kind']=='mlp'})
    for rep in reps:
        selected=[r for r in probes if r['kind']=='mlp' and r['representation']==rep]
        probe_summary[rep]=dict(train=macro([r['train']['macro'] for r in selected]),validation=macro([r['validation']['macro'] for r in selected]),
                                selected_steps=[r['selected_steps'] for r in selected])
    contrasts={}
    for left,right in [('spatial','block8'),('spatial','spatial_shuffled'),('spatial','dispersion'),
                       ('attachment','block8'),('attachment','attachment_shuffled'),('message3','block8')]:
        a=[r for r in probes if r['kind']=='mlp' and r['representation']==left]
        b=[r for r in probes if r['kind']=='mlp' and r['representation']==right]
        contrasts[left+'__minus__'+right]=paired(a,b,'rigid_rmsd_nm',va)
    fresh_summary={};fresh_contrasts={}
    for arm in ['zero','spatial','shuffled']:
        rows=[r for r in fresh if r['arm']==arm]
        fresh_summary[arm]=dict(train=macro([r['train']['macro'] for r in rows]),validation=macro([r['validation']['macro'] for r in rows]),
                                epochs=[r['selected_epoch'] for r in rows])
    for left,right in [('spatial','zero'),('spatial','shuffled')]:
        a=[r for r in fresh if r['arm']==left];b=[r for r in fresh if r['arm']==right]
        c=paired(a,b,'rigid_rmsd_nm',va)
        c['paired_seed_deltas']=[aa['validation']['macro']['rigid_rmsd_nm']-bb['validation']['macro']['rigid_rmsd_nm'] for aa,bb in zip(a,b)]
        c['screen_pass']=c['mean']<=-.05 and sum(v<0 for v in c['paired_seed_deltas'])>=2
        fresh_contrasts[left+'__minus__'+right]=c
    rec={split:macro([r[split] for r in recon.values()]) for split in ['train','validation']}
    result=dict(probe_summary=probe_summary,probe_contrasts=contrasts,fresh_summary=fresh_summary,fresh_contrasts=fresh_contrasts,reconstruction=rec)
    dump(RESULTS/'diagnostic_summary.json',result)
    with (RESULTS/'probe_metrics.csv').open('w',newline='') as f:
        keys=['kind','representation','seed','split','design','loss','translation_rmse_nm','rotation_deg','rigid_rmsd_nm']
        w=csv.DictWriter(f,keys);w.writeheader()
        for row in probes:
            for split in ['train','validation']:
                for ident,m in row[split]['per_design'].items():
                    w.writerow(dict(kind=row['kind'],representation=row['representation'],seed=row['seed'],split=split,design=ident,
                                    **{k:m[k] for k in keys[5:]}))
    print(json.dumps(dict(fresh=fresh_summary,contrasts=fresh_contrasts),indent=2,default=lambda v:v.tolist()),flush=True)


if __name__=='__main__':main()
