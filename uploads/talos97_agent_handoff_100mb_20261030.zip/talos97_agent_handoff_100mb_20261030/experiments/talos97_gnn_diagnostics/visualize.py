#!/usr/bin/env python3
"""All-node interactive failure views and PyVista/VTK geometry; no display needed."""
import numpy as np
import pyvista as pv
import plotly.graph_objects as go
from common import *


def lines(points,edges):
    mesh=pv.PolyData()
    mesh.points=points
    mesh.lines=np.column_stack([np.full(edges.shape[1],2),edges.T]).ravel()
    return mesh


def plot_lines(fig,start,end,name,color,visible='legendonly'):
    xyz=np.stack([start,end,np.full_like(start,np.nan)],1).reshape(-1,3)
    fig.add_trace(go.Scatter3d(x=xyz[:,0],y=xyz[:,1],z=xyz[:,2],mode='lines',name=name,
                  line=dict(color=color,width=3),visible=visible,hoverinfo='skip'))


def main():
    tr,va,_,_=ids();recon=json.loads((RESULTS/'reconstruction.json').read_text())['11']['per_design']
    median=sorted(va,key=lambda i:len(read_cache(i)['x']))[len(va)//2]
    worst=max(va,key=lambda i:recon[i]['rigid_rmsd_nm'])
    selection={median:'median validation input node count',worst:'largest seed11 rigid validation RMSD (label-selected exploratory failure)'}
    folder=HERE/'visualizations';folder.mkdir(exist_ok=True)
    summary={}
    for ident,rule in selection.items():
        d=read_cache(ident);raw=raw_design(ident);x=d['x'];ix=d['index'];y=d['target'];frames=d['frames']
        coarse=centered(rigid(x,ix,d['pred_t'],d['pred_r']),x)
        base=x+d['base_delta'];res=base-rigid(x,ix,d['base_t'],d['base_r']);hybrid=centered(coarse+res,x)
        mesh=pv.PolyData(x);mesh['domain']=ix;mesh['true_displacement_nm']=y-x;mesh['predicted_rigid_displacement_nm']=coarse-x
        mesh['base_displacement_nm']=base-x;mesh['rigid_error_nm']=np.linalg.norm(coarse-y,axis=1)
        mesh['hybrid_error_nm']=np.linalg.norm(hybrid-y,axis=1)
        mesh.save(folder/f'{ident}_initial.vtp')
        for name,points in [('target',y),('rigid',coarse),('hybrid',hybrid)]:
            out=pv.PolyData(points);out['error_nm']=np.linalg.norm(points-y,axis=1);out.save(folder/f'{ident}_{name}.vtp')
        i,j=raw['edge_index'];keep=ix[i]!=ix[j];inter=np.array([i[keep],j[keep]])
        edge_mesh=lines(x,inter);edge_mesh.cell_data['relation_type']=raw['edge_types'][keep];edge_mesh.save(folder/f'{ident}_attachments.vtp')
        c=d['centers'];lever_start=c[ix[inter[0]]];lever_end=x[inter[0]]
        leverpoints=np.concatenate([lever_start,lever_end]);n=len(lever_start)
        lever=lines(leverpoints,np.stack([np.arange(n),np.arange(n)+n]));lever.save(folder/f'{ident}_lever_arms.vtp')
        fig=go.Figure()
        for name,points,color,visible in [('Initial',x,'#a0a0a0','legendonly'),('Target',y,'#3977a8',True),
                      ('Frozen base',base,'#737373','legendonly'),('Phase11 rigid',coarse,'#d17b41',True),('Hybrid',hybrid,'#7b5e9b','legendonly')]:
            fig.add_trace(go.Scatter3d(x=points[:,0],y=points[:,1],z=points[:,2],mode='markers',name=name,
                marker=dict(size=2,color=color,opacity=.75),visible=visible,
                customdata=np.column_stack([np.arange(len(x)),ix,np.linalg.norm(points-y,axis=1)]),
                hovertemplate='node %{customdata[0]} domain %{customdata[1]}<br>error %{customdata[2]:.3f} nm<extra>'+name+'</extra>'))
        plot_lines(fig,c,c+d['target_t'],'True centroid motion','#3977a8')
        plot_lines(fig,c,c+d['pred_t'],'Predicted centroid motion','#d17b41')
        plot_lines(fig,x[inter[0]],x[inter[1]],'Interdomain attachments','#666666')
        plot_lines(fig,lever_start,lever_end,'Attachment lever arms','#8a6d49')
        fig.update_layout(title=f'{ident}: target and predicted motion (nm); {rule}',
                          scene=dict(aspectmode='data',xaxis_title='x (nm)',yaxis_title='y (nm)',zaxis_title='z (nm)'),
                          legend=dict(itemsizing='constant'),margin=dict(l=0,r=0,b=0,t=70),height=820)
        fig.write_html(folder/f'{ident}.html',include_plotlyjs=True,full_html=True)
        summary[ident]=dict(selection=rule,nodes=len(x),interdomain_edges=inter.shape[1],lever_arms=n,
                            rigid_rmsd_nm=endpoint(coarse,y),hybrid_rmsd_nm=endpoint(hybrid,y),all_nodes_preserved=True)
        assert pv.read(folder/f'{ident}_initial.vtp').n_points==len(x)
    dump(RESULTS/'visualizations.json',summary)
    print('VISUALIZATIONS',summary,flush=True)


if __name__=='__main__':main()
