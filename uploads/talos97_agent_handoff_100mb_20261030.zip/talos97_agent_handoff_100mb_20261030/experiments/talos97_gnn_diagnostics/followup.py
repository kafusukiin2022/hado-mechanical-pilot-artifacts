#!/usr/bin/env python3
"""Preregistered adaptive, matched spatial-pooling tests and one-design sanity."""
import argparse
import copy
import time
from common import *
from probes import pack,fit_ridge,linear_predict,evaluate_prediction,fit_mlp,score


def spatial_shuffle(data,names):
    for ident in names:
        d=data[ident];s=d['rep_spatial'];rng=np.random.default_rng(191+int(hashlib.sha256(ident.encode()).hexdigest()[:6],16))
        d['rep_spatial_shuffled']=np.concatenate([s[:,:346],s[rng.permutation(len(s)),346:]],1)


def run_shuffle_probe(data,tr,va,inner,tune,device):
    folder=HERE/'followup';folder.mkdir(exist_ok=True)
    rep='spatial_shuffled';fit,held,full,validation=[pack(data,n,rep) for n in [inner,tune,tr,va]]
    tuning=[]
    for alpha in [1.,10.,100.]:
        m=fit_ridge(*fit,alpha);tuning.append(dict(alpha=alpha,tune_loss=score(linear_predict(m,held[0]),*held[1:])))
    alpha=min(tuning,key=lambda v:v['tune_loss'])['alpha'];m=fit_ridge(*full,alpha)
    save_npz(folder/'ridge_spatial_shuffled.npz',**m)
    trainmetrics,_=evaluate_prediction(linear_predict(m,full[0]),tr,data)
    valmetrics,arrays=evaluate_prediction(linear_predict(m,validation[0]),va,data)
    save_npz(folder/'ridge_spatial_shuffled_predictions.npz',**arrays)
    results=[dict(kind='ridge',representation=rep,seed=None,alpha=alpha,tuning=tuning,train=trainmetrics,validation=valmetrics)]
    for seed in [11,22,33]:
        model,mu,sd,n,history=fit_mlp(fit,held,seed,device)
        del model
        model,mu,sd,_,refit=fit_mlp(full,None,seed,device,steps=n)
        torch.save(dict(state={k:v.cpu() for k,v in model.state_dict().items()},mean=mu,std=sd,
                   representation=rep,seed=seed,selected_steps=n),folder/f'mlp_spatial_shuffled_{seed}.pt')
        def pred(x):
            with torch.no_grad():return npv(model(torch.as_tensor((x-mu)/sd,device=device,dtype=torch.float32)))
        trainmetrics,_=evaluate_prediction(pred(full[0]),tr,data);valmetrics,arrays=evaluate_prediction(pred(validation[0]),va,data)
        save_npz(folder/f'mlp_spatial_shuffled_{seed}_predictions.npz',**arrays)
        results.append(dict(kind='mlp',representation=rep,seed=seed,selected_steps=n,history=history,refit_history=refit,
                            train=trainmetrics,validation=valmetrics))
    dump(RESULTS/'spatial_shuffle_probes.json',results)


def new_head(device):
    _,head=models(11,device)
    original=head.projector[0];expanded=torch.nn.Linear(442,64).to(device)
    with torch.no_grad():
        expanded.weight[:,:346].copy_(original.weight);expanded.weight[:,346:].zero_();expanded.bias.copy_(original.bias)
    head.projector[0]=expanded
    return head


def tensor_data(data,names,device,arm):
    from analyze import graph_from_cache
    result={}
    for ident in names:
        d=data[ident]
        s=d['rep_spatial'] if arm=='spatial' else d['rep_spatial_shuffled'] if arm=='shuffled' else np.concatenate([d['rep_block8'],np.zeros((len(d['valid']),96),dtype='float32')],1)
        result[ident]=dict(pooled=torch.as_tensor(s,device=device),graph=graph_from_cache(d,device),
                         translation=torch.as_tensor(d['target_t'],device=device,dtype=torch.float32),
                         rotation=torch.as_tensor(d['target_r'],device=device,dtype=torch.float32),
                         valid=torch.as_tensor(d['valid'],device=device))
    return result


def loss_head(head,d):
    t,r=head(d['pooled'],d['graph']);return old.loss_terms(t,r,d)[0]


def eval_head(head,cache,names,data=None):
    head.eval();per={};arrays={}
    with torch.no_grad():
        for ident in names:
            d=cache[ident];t,r=head(d['pooled'],d['graph'])
            if data is None:per[ident]=dict(loss=float(old.loss_terms(t,r,d)[0]))
            else:
                per[ident]=domain_metrics(npv(t),npv(r),data[ident])
                arrays[ident+'__t']=npv(t);arrays[ident+'__r']=npv(r)
    return dict(macro=macro(list(per.values())),per_design=per),arrays


def fit_head(cache,train,tune,seed,device,epochs,select=True):
    torch.manual_seed(seed);head=new_head(device)
    optimizer=torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=.0001)
    rng=np.random.default_rng(seed);history=[];best=float('inf');bestep=0;first_extra_grad=None
    for epoch in range(epochs+1):
        order_hash=None
        if epoch:
            head.train();order=[str(i) for i in rng.permutation(train)]
            order_hash=hashlib.sha256('\n'.join(order).encode()).hexdigest()
            for ident in order:
                optimizer.zero_grad(set_to_none=True);loss=loss_head(head,cache[ident]);loss.backward()
                if first_extra_grad is None:first_extra_grad=float(head.projector[0].weight.grad[:,346:].abs().sum())
                torch.nn.utils.clip_grad_norm_(head.parameters(),5);optimizer.step()
        tr,_=eval_head(head,cache,train);held,_=eval_head(head,cache,tune) if select else (tr,{})
        history.append(dict(epoch=epoch,train_loss=tr['macro']['loss'],tune_loss=held['macro']['loss'] if select else None,train_order_sha256=order_hash))
        if held['macro']['loss']<best:best=held['macro']['loss'];bestep=epoch
    return head,bestep,history,first_extra_grad


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--device',default='cuda:0');args=ap.parse_args()
    torch.set_num_threads(2);device=torch.device(args.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    if (RESULTS/'followup_complete.json').exists():raise FileExistsError('Followup exists')
    tr,va,inner,tune=ids();data={i:read_cache(i) for i in tr+va};spatial_shuffle(data,tr+va)
    folder=HERE/'followup';folder.mkdir(exist_ok=True);start=time.time()
    run_shuffle_probe(data,tr,va,inner,tune,device);print('SHUFFLE PROBES COMPLETE',flush=True)
    results=[];initial_errors={}
    for arm in ['zero','spatial','shuffled']:
        cache=tensor_data(data,tr+va,device,arm)
        initial=new_head(device);err=0.
        with torch.no_grad():
            for ident in tr+va:
                t,r=initial(cache[ident]['pooled'],cache[ident]['graph'])
                err=max(err,float(np.max(np.abs(npv(t)-data[ident]['pred_t']))),float(np.max(np.abs(npv(r)-data[ident]['pred_r']))))
        initial_errors[arm]=err;assert err<1e-5
        for seed in [11,22,33]:
            trained,n,history,grad=fit_head(cache,inner,tune,seed,device,epochs=20)
            del trained
            trained,_,refit,refitgrad=fit_head(cache,tr,[],seed,device,epochs=n,select=False)
            trainmetrics,_=eval_head(trained,cache,tr,data);valmetrics,arrays=eval_head(trained,cache,va,data)
            save_npz(folder/f'graph_{arm}_{seed}_predictions.npz',**arrays)
            torch.save(dict(state={k:v.cpu() for k,v in trained.state_dict().items()},arm=arm,seed=seed,
                       selected_epoch=n),folder/f'graph_{arm}_{seed}.pt')
            row=dict(arm=arm,seed=seed,selected_epoch=n,history=history,refit_history=refit,
                     extra_first_grad=grad,refit_extra_first_grad=refitgrad,
                     parameters=sum(p.numel() for p in trained.parameters()),train=trainmetrics,validation=valmetrics)
            results.append(row);dump(RESULTS/'graph_followup.json',dict(initial_errors=initial_errors,runs=results))
            print('GRAPH',arm,seed,'epochs',n,'train',round(trainmetrics['macro']['loss'],5),'val',round(valmetrics['macro']['loss'],5),
                  'endpoint',round(valmetrics['macro']['rigid_rmsd_nm'],5),'seconds',round(time.time()-start,1),flush=True)
            del trained
        del cache
    # One-design sanity uses only the smallest training design.
    ident=min(tr,key=lambda i:len(data[i]['x']));cache=tensor_data(data,[ident],device,'zero');torch.manual_seed(11)
    head=new_head(device);opt=torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=.0001);history=[]
    for step in range(1001):
        if step:
            opt.zero_grad(set_to_none=True);loss=loss_head(head,cache[ident]);loss.backward()
            torch.nn.utils.clip_grad_norm_(head.parameters(),5);opt.step()
        if step in [0,100,300,1000]:
            m,arrays=eval_head(head,cache,[ident],data);history.append(dict(step=step,metrics=m['macro']))
    save_npz(folder/'single_design_predictions.npz',**arrays)
    dump(RESULTS/'single_design_fit.json',dict(design=ident,history=history,seed=11,steps=1000,no_generalization_claim=True))
    dump(RESULTS/'followup_complete.json',dict(passed=True,runs=9,elapsed=time.time()-start))
    print('FOLLOWUP COMPLETE',flush=True)


if __name__=='__main__':main()
