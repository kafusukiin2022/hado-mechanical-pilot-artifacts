#!/usr/bin/env python3
"""Interactive installed Polyscope viewer; run locally with display/OpenGL."""
import argparse
from pathlib import Path
import numpy as np
import pyvista as pv
import polyscope as ps

parser=argparse.ArgumentParser();parser.add_argument('design',nargs='?',default='6hb_048');args=parser.parse_args()
folder=Path(__file__).resolve().parent/'visualizations'
initial=pv.read(folder/f'{args.design}_initial.vtp')
ps.init();ps.set_up_dir('z_up')
cloud=ps.register_point_cloud('initial (nm)',np.asarray(initial.points))
for key in ['true_displacement_nm','predicted_rigid_displacement_nm','base_displacement_nm']:
    cloud.add_vector_quantity(key,np.asarray(initial[key]),vectortype='ambient')
for key in ['rigid_error_nm','hybrid_error_nm']:
    cloud.add_scalar_quantity(key,np.asarray(initial[key]))
for name in ['target','rigid','hybrid']:
    mesh=pv.read(folder/f'{args.design}_{name}.vtp');ps.register_point_cloud(name,np.asarray(mesh.points),enabled=name!='hybrid')
for name in ['attachments','lever_arms']:
    mesh=pv.read(folder/f'{args.design}_{name}.vtp');edges=np.asarray(mesh.lines).reshape(-1,3)[:,1:]
    ps.register_curve_network(name,np.asarray(mesh.points),edges,enabled=False)
ps.show()
