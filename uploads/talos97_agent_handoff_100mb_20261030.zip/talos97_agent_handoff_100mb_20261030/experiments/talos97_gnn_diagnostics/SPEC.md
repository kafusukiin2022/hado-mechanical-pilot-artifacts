# GNN Diagnostic Plan & Spec

## Material Passport
- Origin: user-authorized internal model diagnosis; academic-research-suite experiment workflow.
- Scope: frozen localframe2m and Phase11 seeds11/22/33; hybrid is a reconstruction, not a separately trained network.
- Date: 2026-10-30. Language: Simplified Chinese report. No test access.
- Hypotheses below are competitors, not assumed conclusions.

## Questions and falsifiers

|ID|Hypothesis|Discriminating measurement|What would weaken it|
|--|--|--|--|
|H1|Initial summaries omit useful attachment/topology information|same probe on mean hidden vs mean hidden plus typed attachment positions/directions/moments; alignment-shuffled augmentation control|no held-design benefit, or identical gain from shuffled features|
|H2|Backbone discards motion information|matched train-design-selected linear/nonlinear domain-transform probes on input, early/late hidden, global context|late features retain/improve decodability; this would refute a simple loss claim|
|H3|Mean pooling/64D projector bottleneck|spatial hidden moments vs distribution-only moments; pre/post projector probes, effective rank/CKA|no probe gain before compression or from spatial information|
|H4|Three-hop graph cannot integrate relevant remote effects|trained message-layer probes; edge-group ablations; single-domain perturbation versus graph distance|remote integration unnecessary for observed errors, or messages already materially improve held-design decoding|
|H5|Prediction head/optimization is primary|refit matched small nonlinear head vs deployed outputs; train/val and single-design fitting sanity; existing gradients and histories|no head gain and easy one-design fit would shift attention toward cross-design information/generalization|
|H6|Coarse/fine incompatibility is primary|label-only oracle swaps, exact SSE decomposition, properly transported frozen residual|coarse errors dominate and replacing residual changes little|

## Data, coordinates, independence
- Reuse Phase10 streaming split reader: exactly68train/14validation, stop before test array.
- Inputs/labels loaded only by explicit allowed IDs. Hash split bytes without decoding test IDs.
- Physical positions nm = stored positions *34.072. Column-action proper rotations;
  translation is target centroid minus source centroid. Rank<2 domains excluded from rotation targets/metrics.
- Probes predict anchor-local translation(3) and rotation-matrix-minus-identity(9).
  Rotations projected to SO(3) only for evaluation, report projection convention.
- Domain weights: equal domain per design; independent unit = whole design.
  Primary score = equal-design translation MSE + valid-domain Frobenius rotation MSE;
  report translation RMSE, angle and nucleotide endpoint macro RMSD separately.
- Deterministic inner split of68train: last14 after SHA256 sorting are tuning designs,
  remaining54 fit. Scaling and probe selection use inner train only; then refit68
  with fixed selected settings. Validation never selects diagnostic hyperparameters.
- Seed11 is primary representation audit; seeds22/33 replicate reconstruction and
  main interventions where affordable. Small-model probe seeds11/22/33.
- No hypothesis becomes proven from CKA, attribution, synthetic collisions or
  label-assisted oracle fits alone. Explicitly label OOD ablations.

## A: actual path and implementation checks
Reproduce frozen endpoints and Phase11 outputs; inspect train curves, nonzero
gradients, clipping/output saturation, layer ranks and feature ranges. Trace one
complete real training design via TorchLens (with bounded saved tensors) and
capture module outputs via hooks/manual equivalent with numerical checks.
Check proper rotations, centering, loss-vs-endpoint mismatch, label uncertainty
from existing verified reports. Preserve all source/checkpoint/data hashes.

## B: representation extraction and probes
For all82designs cache domain targets, source geometry and domain-pooled input,
fc1/fc2/residual-block outputs, projector and each coarse message state.
Additional input-only features: hidden mean+global context, hidden dispersion,
position-weighted hidden moments in domain anchor frame, typed interdomain
attachment offsets/directions/second moments. Random projections are fixed seed,
not fit to labels. An aligned-vs-within-design-shuffled augmentation is a control.
Linear Ridge alpha grid {1,10,100}, inner-design selection. Nonlinear probes:
one64-wide SiLU hidden layer, AdamW lr0.003 weight_decay0.0001,150full-batch steps,
inner loss selection every10steps including0; refit full68 for selected steps.
Use same task/weights and report feature/parameter dimensions; different input
dimensions are a capacity confound, so include an equal-dimension shuffled control.
CKA and effective ranks use the same balanced deterministic domain rows.
Nearest-neighbor feature/target disagreement is descriptive, not irreducible error.

## C: functional dependence, geometry and reconstruction
- Seed11 all14validation: erase typed counts, lengths, relative centers, orientations,
  pooled states, or rewire coarse neighbors; report output change AND target score.
- Captum IG on an input-size-selected validation representative: translation-energy
  output, training-mean baselines, pooled state and18edge channels separately;
  convergence delta required. Attribution is local model reliance, not physical causality.
- Perturb one domain state and summarize effects by graph distance; compare3hop
  reach with graph diameter and held-design error. No claim that longer is better.
- Construct explicit coarse-edge aggregation collision: equal counts/distances/
  domain centers/frames with different attachment locations. Verify old edge
  summary equal and new attachment moments different. This tests encoding only;
  no invented labels or physical response claim.
- All3seeds/82designs: swap predicted translation/rotation with label oracle;
  frozen residual vs rotation-transported residual vs target-derived oracle
  residual; exact SSE cross terms and residual direction. Oracles never model outputs.
- Export representative true/predicted displacement, attachment links, lever arms,
  and error as VTK/PyVista assets plus an inspectable3D view. No GUI required.

## D: adaptive minimal follow-up
Execute only after B/C: prefer one-head refit and a single-design memorization
sanity before full backbone finetuning or conditional-residual training. A large
probe advantage is evidence to target the head/pooling; a robust attachment or
spatial advantage motivates one-factor encoding experiment. If no clear signal,
report unresolved and specify next discriminating experiment, not architecture churn.
Any additional training arm requires an amendment written before execution with
fixed data, budget, seed, endpoint and matched control. User has authorized small
diagnostic experiments; no extra approval needed for this bounded scope.

## Outputs and verification
Separate directory only; no original training history/source/checkpoint writes.
SPEC before runner; EXPECTED_VERIFICATION before experiments. Durable status/logs,
per-design metrics, cache/probe provenance, plots/3D assets, independent verifier,
and GNN_DIAGNOSTIC_REPORT_ZH.md. CPU reproduction selected outputs and independent
metric recalculation; protected hashes unchanged. Integrity pass separate from
scientific-positive result. GPU1 only after fresh idle check; isolate via
CUDA_VISIBLE_DEVICES=1; never touch occupiedGPU0. No W&B or external data upload.
