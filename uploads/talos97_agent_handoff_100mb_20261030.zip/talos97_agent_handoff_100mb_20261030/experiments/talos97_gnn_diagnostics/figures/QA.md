# Figure QA

Contract: exploratory diagnostic quantitative grid, Python183x163mm, no journal
submission claim.14validation designs;3seed means within design except seed11
linear-probe panel;10000design bootstrap95% descriptive intervals. No p-values,
no multiple-comparison-adjusted significance. Source data preserves all14designs.

|Panel|Question|Center / interval|Unit|Visual audit|
|--|--|--|--|--|
|a|Where is motion linearly decodable?|macro mean / design bootstrap95%|14designs,seed11|labels clear; uncertainty intentionally broad|
|b|Does aligned extra information help probes?|paired seed-mean change / bootstrap95%|14designs|raw points and means visible; all comparisons explicit|
|c|Which rigid component dominates endpoint error?|seed-mean macro / bootstrap95%|14designs|oracle labels explicit; axis shared|
|d|Does gain transfer to actual new graph heads?|paired seed-mean change / bootstrap95%|14designs|zero line and near-zero intervals visible|

Whole PNG and all four panels visually inspected. SVG/PDF editable text; PDF
text audit min6pt,0violations. Source preflight17pass,3warnings,0fail.
Warnings accepted: PNG300dpi rather than TIFF600dpi because this is a diagnostic
report preview, not a submission raster; bootstrap RNG is falsely identified as
simulated data by static checker (all observations are actual design metrics).
No image contrast edits or exclusions. Interactive3D exports are separately
validated as geometry, not as server-side GUI renderings.
