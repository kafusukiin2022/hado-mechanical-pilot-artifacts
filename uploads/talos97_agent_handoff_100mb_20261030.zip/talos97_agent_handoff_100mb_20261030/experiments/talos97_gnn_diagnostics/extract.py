#!/usr/bin/env python3
"""Phase A/B: frozen inference, hook extraction, label-only oracle decomposition."""
import argparse
import json
import time
import traceback
import numpy as np
import torch
from common import *


def reconstruction(d):
    x,y,ix=d['x'],d['target'],d['index']
    t,r,tt,rr=d['pred_t'],d['pred_r'],d['target_t'],d['target_r']
    base=x+d['base_delta']; basefit=rigid(x,ix,d['base_t'],d['base_r'])
    residual=base-basefit
    coarse=centered(rigid(x,ix,t,r),x)
    oracle=rigid(x,ix,tt,rr)
    transported=np.einsum('nij,nj->ni',(r@np.swapaxes(d['base_r'],1,2))[ix],residual)
    target_residual=y-oracle
    outputs={'base':base,'rigid':coarse,'hybrid':centered(coarse+residual,x),
             'transported':centered(coarse+transported,x),'oracle':oracle,
             'oracle_translation':centered(rigid(x,ix,tt,r),x),
             'oracle_rotation':centered(rigid(x,ix,t,rr),x),
             'oracle_coarse_old_residual':centered(oracle+residual,x),
             'pred_coarse_oracle_residual':centered(coarse+target_residual,x),
             'legacy_additive':centered(coarse+d['base_delta'],x)}
    # Exact centered decomposition in the same coordinate convention as hybrid.
    error=coarse-y; res=centered(residual,np.zeros_like(x))
    a=float(np.mean(np.sum(error**2,1))); b=float(np.mean(np.sum(res**2,1)))
    cross=float(2*np.mean(np.sum(error*res,1)))
    hybrid=float(np.mean(np.sum((outputs['hybrid']-y)**2,1)))
    assert abs(a+b+cross-hybrid)<1e-7
    result={k+'_rmsd_nm':endpoint(v,y) for k,v in outputs.items()}
    result.update(rigid_mse=a,residual_mse=b,cross_mse=cross,hybrid_mse=hybrid,
                  residual_rms_nm=b**.5,oracle_residual_rms_nm=endpoint(y,oracle),
                  residual_target_cos=float(np.sum(res*target_residual)/(np.linalg.norm(res)*np.linalg.norm(target_residual)+1e-12)))
    result.update(domain_metrics(t,r,d))
    long=np.linalg.norm(y-x,axis=1)>=4
    for name in ('base','rigid','hybrid','transported','oracle'):
        result[name+'_long_rmsd_nm']=endpoint(outputs[name][long],y[long]) if long.any() else 0.
    return result


def trace_actual(base,raw,device,ident):
    import torchlens
    from torchlens.options import CaptureOptions,SaveOptions
    s,B,R=p10.geometry(raw,True)
    args=tuple(torch.as_tensor(v,device=device) for v in (s,B,R))
    before=old.state_hash(base.state_dict())
    with torch.no_grad(): original=base(*args).clone()
    # Save tiny numerical previews of every actual tensor, not fullGB payloads.
    history=torchlens.trace(base,args,
        capture=CaptureOptions(layers_to_save='all',save_code_context=False,save_rng_states=False),
        save=SaveOptions(activation_transform=lambda x:x.detach().reshape(-1)[:8].cpu(),save_raw_activations=False))
    (RESULTS/'torchlens_trace.txt').write_text(str(history))
    with torch.no_grad(): after_output=base(*args)
    assert before==old.state_hash(base.state_dict())
    error=float((original-after_output).abs().max())
    dump(RESULTS/'torchlens.json',dict(passed=error<1e-5,design=ident,complete_design=True,
         nodes=len(s),saved_tensor_preview_values=8,output_unchanged_max_nm=error,
         trace_type=type(history).__name__,torchlens_version=torchlens.__version__ if hasattr(torchlens,'__version__') else '2.36.1'))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--device',default='cuda:0');args=parser.parse_args()
    torch.set_num_threads(2);device=torch.device(args.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    tr,va,inner,tune=ids();RESULTS.mkdir(parents=True,exist_ok=True)
    if (RESULTS/'extraction_complete.json').exists():raise FileExistsError('Completed extraction exists')
    before=provenance();dump(RESULTS/'provenance_before.json',before)
    dump(RESULTS/'protocol.json',dict(train_ids=tr,validation_ids=va,inner_train_ids=inner,tune_ids=tune,
        test_ids_decoded=False,test_files_opened=False,device=str(device),physical_visible=os.environ.get('CUDA_VISIBLE_DEVICES'),
        torch_version=torch.__version__,numpy_version=np.__version__))
    all_results={};max_reproduction=0.;start=time.time()
    trace_ident=None
    for seed in (11,22,33):
        base,head=models(seed,device);basehash=old.state_hash(base.state_dict());headhash=old.state_hash(head.state_dict())
        metrics={};saved=json.loads((P11/'runs'/f'seed{seed}'/'metrics.json').read_text())
        with np.load(P11/'runs'/f'seed{seed}'/'predictions_train_validation.npz') as original:
            for k,ident in enumerate(tr+va):
                raw=raw_design(ident)
                with np.load(old.DATA/'labels'/f'{ident}.npz') as f:y=f['target_pos'].astype(float)*NM
                c=capture(base,head,raw,device);g=c['graph'];x=raw['pos'].astype(float)*NM;ix=g['index']
                tt,rr,valid,oracle=old.fits(x,y,ix)
                bt,br,_,_=old.fits(x,x+c['delta'],ix)
                d=dict(x=x,target=y,index=ix,frames=g['frames'],centers=g['centers'],valid=valid,
                       target_t=tt,target_r=rr,target_vector=target_vector(tt,rr,g['frames']),
                       pred_t=c['t'],pred_r=c['r'],base_delta=c['delta'],base_t=bt,base_r=br,
                       edges=g['edges'],edge_features=g['features'])
                if seed==11:
                    d.update({'rep_'+key:value for key,value in c['pooled'].items()})
                    d.update({'rep_'+key:value for key,value in c['domain'].items()})
                    attachment=attachment_features(raw,g)
                    d['attachment']=attachment
                    d['rep_attachment']=np.concatenate([c['pooled']['block8'],attachment],1)
                    shuffled=attachment[np.random.default_rng(191+int(hashlib.sha256(ident.encode()).hexdigest()[:6],16)).permutation(len(attachment))]
                    d['rep_attachment_shuffled']=np.concatenate([c['pooled']['block8'],shuffled],1)
                    d['coeff']=c['coeff']
                    # Node states for the input-size-selected train/validation examples only.
                    if trace_ident is None:trace_ident=ident
                    d['node_saturation_fraction']=np.array(np.mean(np.abs(c['coeff'])/(8/np.sqrt(3))>.95))
                save_npz(CACHE/f'seed{seed}'/f'{ident}.npz',**d)
                metrics[ident]=reconstruction(d)
                split='train' if ident in tr else 'validation'
                expected=saved[split]['per_design'][ident]
                for name in ['base','rigid','hybrid']:
                    max_reproduction=max(max_reproduction,abs(metrics[ident][name+'_rmsd_nm']-expected[name+'_rmsd_nm']))
                max_reproduction=max(max_reproduction,float(np.max(np.abs(c['t']-original[ident+'__t']))),
                                     float(np.max(np.abs(c['r']-original[ident+'__r']))))
                if k%20==0:print('extract',seed,k+1,'of82',ident,'seconds',round(time.time()-start,1),flush=True)
                dump(RESULTS/'status.json',dict(stage='extraction',seed=seed,design=k+1,total=82,elapsed=time.time()-start))
        assert basehash==old.state_hash(base.state_dict()) and headhash==old.state_hash(head.state_dict())
        all_results[str(seed)]=dict(per_design=metrics,train=macro([metrics[i] for i in tr]),validation=macro([metrics[i] for i in va]))
        if seed==11:
            # Select smallest training input by node count, never by performance.
            sizes={i:len(read_cache(i)['x']) for i in tr};trace_ident=min(sizes,key=sizes.get)
            try:trace_actual(base,raw_design(trace_ident),device,trace_ident)
            except Exception:
                text=traceback.format_exc();(RESULTS/'torchlens_failure.txt').write_text(text)
                dump(RESULTS/'torchlens.json',dict(passed=False,design=trace_ident,compatibility_exception=text))
                print('TORCHLENS compatibility issue recorded; hook extraction remains verified',flush=True)
        del base,head
        if device.type=='cuda':torch.cuda.empty_cache()
    assert max_reproduction<1e-4,max_reproduction
    dump(RESULTS/'reconstruction.json',all_results)
    after=provenance();assert before==after
    dump(RESULTS/'extraction_complete.json',dict(passed=True,max_reproduction_error=max_reproduction,
         designs=82,seeds=[11,22,33],elapsed=time.time()-start,protected_hashes_unchanged=True))
    print('EXTRACTION COMPLETE',max_reproduction,flush=True)


if __name__=='__main__':main()
