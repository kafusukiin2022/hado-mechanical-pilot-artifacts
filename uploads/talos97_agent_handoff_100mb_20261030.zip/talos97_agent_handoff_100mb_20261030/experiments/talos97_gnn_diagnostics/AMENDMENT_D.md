# Adaptive Phase D — written after B/C, before further optimization

Observed: Ridge hidden mean loss5.894, spatial moments5.530, dispersion5.849;
typed attachment augmentation5.675 versus shuffled5.921. Three-hop graph is
functional: no-message validation endpoint2.380 vs original2.161nm. Label-only
translation replacement gives~0.533nm; rotation replacement~2.116nm.
These numbers motivate testing spatial pooling, not assuming graph uselessness.

## D1 — matched graph-head continuation with spatial moments
- Base features and all original checkpoints remain frozen.
- Use seed11 cached features and seed11 selected Phase11 head for every arm.
- Extend projector346->64 to442->64 by96zero-initialized columns. All three
  arms have exactly the same parameters and exact original initial outputs.
- Inputs: hidden mean +96true spatial moments; +96within-design-permuted spatial
  moments; +96zero columns(control). Permutations fixed by input ID and seed191.
  Original346columns remain aligned in every arm.
- Train the SAME full coarse head, direct original translation+rotation objective.
  AdamW lr0.001 weight_decay0.0001, clip5,20epochs, same shuffled design order
  for paired seeds11/22/33. No backbone updates.
- Select number of continuation epochs using inner54train/14tune, epoch0included,
  then reset to identical initial checkpoint and refit full68 for selected count.
  No validation used to select continuation hyperparameters. Original pretrained
  backbone/head already saw all68training designs; inner split isolates only the
  new continuation fit, not original pretraining.
- Save all inner epoch histories, selected counts, full refit histories, weights
  and full68/14predictions. Report paired per-design/seed differences and any
  max regression; validation remains exploratory/reused, not blind testing.
- Primary metric: transform loss. Secondary endpoint rigid RMSD. Useful screen:
  >=0.05nm mean rigid gain vs zero and >=2/3seed gains; also compare shuffle.
  Outcome is scoped to adding these spatial moments, not every kind of pooling.

## D2 — single-design fitting sanity
- Smallest training input design (6hb_001 by6176nodes), seed11 feature/head.
- Full coarse head continuation1000AdamW steps atlr0.001, clip5, report0/100/300/
  1000; no early stop, no validation selection and no claim of generalization.
- Purpose: check capacity/optimization can approach known domain targets on one
  design when input features held fixed. Compare the selected Phase11 start.

## D3 — spatial alignment probe control
Add a within-design-shuffled spatial96augmentation to the same mean features,
with exactly the same ridge/MLP selection and3probe seeds as PhaseB. This is
an alignment control; shuffled inputs may be OOD and negative results do not
establish a physical cause.

Other interventions (joint backbone tuning/conditional residual/full raw-graph
encoder) are deferred to keep factors separate; D1 directly tests the strongest
current signal. No requested model weights or histories are overwritten.
