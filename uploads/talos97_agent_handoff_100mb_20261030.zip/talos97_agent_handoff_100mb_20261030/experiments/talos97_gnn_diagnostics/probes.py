#!/usr/bin/env python3
"""Design-separated probes. Hyperparameters selected within training designs only."""
import argparse
import time
import copy
import numpy as np
import torch
from sklearn.linear_model import Ridge
from common import *

NONLINEAR_REPS=['input','block8','block8_global','spatial','dispersion','attachment',
                'attachment_shuffled','projector','message3']


def pack(data, names, rep):
    arrays=[data[i]['rep_'+rep] for i in names]
    x=np.concatenate(arrays).astype('float64')
    y=np.concatenate([data[i]['target_vector'] for i in names]).astype('float64')
    wt=np.concatenate([np.full(len(data[i]['valid']),1/(len(names)*len(data[i]['valid']))) for i in names])
    wr=np.concatenate([data[i]['valid'].astype(float)/(len(names)*max(int(data[i]['valid'].sum()),1)) for i in names])
    return x,y,wt,wr


def scaler(x,w):
    mu=np.sum(x*w[:,None],axis=0)
    sd=np.sqrt(np.sum((x-mu)**2*w[:,None],axis=0)).clip(.01)
    return mu,sd


def score(yhat,y,wt,wr):
    return float(np.sum((yhat[:,:3]-y[:,:3])**2*wt[:,None])+np.sum((yhat[:,3:]-y[:,3:])**2*wr[:,None]))


def fit_ridge(x,y,wt,wr,alpha):
    mu,sd=scaler(x,wt);z=(x-mu)/sd
    trans=Ridge(alpha=alpha,solver='cholesky').fit(z,y[:,:3],sample_weight=wt*len(wt))
    rot=Ridge(alpha=alpha,solver='cholesky').fit(z,y[:,3:],sample_weight=wr*len(wr))
    coef=np.concatenate([trans.coef_,rot.coef_]);bias=np.concatenate([trans.intercept_,rot.intercept_])
    return dict(mean=mu,std=sd,coef=coef,bias=bias)


def linear_predict(model,x):
    return ((x-model['mean'])/model['std'])@model['coef'].T+model['bias']


def evaluate_prediction(yhat,names,data):
    rows={};arrays={};offset=0
    for ident in names:
        d=data[ident];n=len(d['valid']);v=yhat[offset:offset+n];offset+=n
        t,r=decode_vector(v,d['frames']);rows[ident]=domain_metrics(t,r,d)
        arrays[ident+'__vector']=v.astype('float32')
        arrays[ident+'__t']=t.astype('float32');arrays[ident+'__r']=r.astype('float32')
    assert offset==len(yhat)
    return dict(macro=macro(list(rows.values())),per_design=rows),arrays


def nonlinear_model(dim):
    return torch.nn.Sequential(torch.nn.Linear(dim,64),torch.nn.SiLU(),torch.nn.Linear(64,12))


def fit_mlp(train,tune,seed,device,steps=150):
    x,y,wt,wr=train;mu,sd=scaler(x,wt)
    tensor=lambda a:torch.as_tensor(a,device=device,dtype=torch.float32)
    xt,yt,wt,wr=[tensor(v) for v in ((x-mu)/sd,y,wt,wr)]
    torch.manual_seed(seed);model=nonlinear_model(x.shape[1]).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.0001)
    if tune is not None:
        xv,yv,wv,rv=tune;xv=tensor((xv-mu)/sd);yv,wv,rv=[tensor(v) for v in (yv,wv,rv)]
    best=float('inf');beststep=0;history=[];state=None
    def objective(pred,target,a,b):
        return ((pred[:,:3]-target[:,:3]).square()*a[:,None]).sum()+((pred[:,3:]-target[:,3:]).square()*b[:,None]).sum()
    for step in range(steps+1):
        if step:
            opt.zero_grad(set_to_none=True);loss=objective(model(xt),yt,wt,wr)
            if not torch.isfinite(loss):raise RuntimeError('Nonfinite probe loss')
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),10);opt.step()
        if step%10==0 or step==steps:
            with torch.no_grad():
                trainloss=float(objective(model(xt),yt,wt,wr))
                value=float(objective(model(xv),yv,wv,rv)) if tune is not None else trainloss
            history.append(dict(step=step,train_loss=trainloss,tune_loss=value if tune is not None else None))
            if value<best or tune is None:
                best=value;beststep=step;state=copy.deepcopy(model.state_dict())
    model.load_state_dict(state)
    return model,mu,sd,beststep,history


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--device',default='cuda:0');args=ap.parse_args()
    torch.set_num_threads(2);device=torch.device(args.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    tr,va,inner,tune=ids();data={i:read_cache(i) for i in tr+va}
    reps=[k[4:] for k in data[tr[0]] if k.startswith('rep_')]
    folder=HERE/'probes';folder.mkdir(exist_ok=True)
    if (RESULTS/'probes_complete.json').exists():raise FileExistsError('Completed probes exist')
    results=[];start=time.time()
    for rep in reps:
        fit=pack(data,inner,rep);held=pack(data,tune,rep)
        tuning=[]
        for alpha in [1.,10.,100.]:
            model=fit_ridge(*fit,alpha)
            value=score(linear_predict(model,held[0]),*held[1:]);tuning.append(dict(alpha=alpha,inner_tune_loss=value))
        alpha=min(tuning,key=lambda v:v['inner_tune_loss'])['alpha']
        full=pack(data,tr,rep);validation=pack(data,va,rep)
        model=fit_ridge(*full,alpha);save_npz(folder/f'ridge_{rep}.npz',**model)
        trainmetrics,_=evaluate_prediction(linear_predict(model,full[0]),tr,data)
        valmetrics,arrays=evaluate_prediction(linear_predict(model,validation[0]),va,data)
        save_npz(folder/f'ridge_{rep}_predictions.npz',**arrays)
        row=dict(kind='ridge',representation=rep,seed=None,alpha=alpha,dimensions=full[0].shape[1],
                 parameters=int(model['coef'].size+model['bias'].size),tuning=tuning,
                 train=trainmetrics,validation=valmetrics)
        results.append(row);dump(RESULTS/'probes.json',results)
        print('RIDGE',rep,'train',round(trainmetrics['macro']['loss'],4),'val',round(valmetrics['macro']['loss'],4),'seconds',round(time.time()-start,1),flush=True)
    # Controls: identity and train-only constant in the same local target coordinates.
    full=pack(data,tr,'block8');validation=pack(data,va,'block8')
    for name in ['identity','train_constant']:
        vector=np.zeros(12) if name=='identity' else np.r_[np.sum(full[1][:,:3]*full[2][:,None],axis=0),np.sum(full[1][:,3:]*full[3][:,None],axis=0)]
        trainmetrics,_=evaluate_prediction(np.broadcast_to(vector,full[1].shape),tr,data)
        valmetrics,arrays=evaluate_prediction(np.broadcast_to(vector,validation[1].shape),va,data)
        save_npz(folder/f'{name}_predictions.npz',**arrays)
        results.append(dict(kind='baseline',representation=name,seed=None,train=trainmetrics,validation=valmetrics,vector=vector))
    for rep in NONLINEAR_REPS:
        fit,held,full,validation=[pack(data,n,rep) for n in [inner,tune,tr,va]]
        for seed in [11,22,33]:
            model,mu,sd,beststep,history=fit_mlp(fit,held,seed,device)
            del model
            model,mu,sd,_,refithistory=fit_mlp(full,None,seed,device,steps=beststep)
            torch.save(dict(state={k:v.cpu() for k,v in model.state_dict().items()},mean=mu,std=sd,
                       representation=rep,seed=seed,selected_steps=beststep),folder/f'mlp_{rep}_{seed}.pt')
            def predict(a):
                with torch.no_grad():return npv(model(torch.as_tensor((a-mu)/sd,device=device,dtype=torch.float32)))
            trainmetrics,_=evaluate_prediction(predict(full[0]),tr,data)
            valmetrics,arrays=evaluate_prediction(predict(validation[0]),va,data)
            save_npz(folder/f'mlp_{rep}_{seed}_predictions.npz',**arrays)
            results.append(dict(kind='mlp',representation=rep,seed=seed,selected_steps=beststep,dimensions=full[0].shape[1],
                           parameters=sum(p.numel() for p in model.parameters()),history=history,refit_history=refithistory,
                           train=trainmetrics,validation=valmetrics))
            dump(RESULTS/'probes.json',results)
            dump(RESULTS/'status.json',dict(stage='probes',representation=rep,seed=seed,elapsed=time.time()-start))
            print('MLP',rep,seed,'steps',beststep,'train',round(trainmetrics['macro']['loss'],4),'val',round(valmetrics['macro']['loss'],4),'seconds',round(time.time()-start,1),flush=True)
            del model
    dump(RESULTS/'probes_complete.json',dict(passed=True,models=len(results),selection='inner54train14tune_only',elapsed=time.time()-start))
    print('PROBES COMPLETE',len(results),flush=True)


if __name__=='__main__':main()
