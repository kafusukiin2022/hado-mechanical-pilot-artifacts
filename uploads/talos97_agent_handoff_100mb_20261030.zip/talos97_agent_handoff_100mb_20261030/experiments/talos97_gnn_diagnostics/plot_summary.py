#!/usr/bin/env python3
"""Diagnostic quantitative grid: decodability, model reliance and oracle decomposition.

Figure contract: distinguish association from deployable causal improvement.
Python/matplotlib only; 183mm wide, editable SVG and300dpi PNG, no journal claim.
Every panel uses14validation designs as the independent unit. For stochastic
models, average3seeds within each design before plotting. Intervals are10000
paired-design bootstrap95% descriptive intervals, not multiplicity-adjusted tests.
All14design observations preserved; deterministic model selection is train-only.
"""
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import *

plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],
    'font.size':7,'axes.titlesize':8,'axes.labelsize':7,'xtick.labelsize':6,'ytick.labelsize':6,
    'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,
    'legend.frameon':False})


def interval(values):
    a=np.asarray(values);rng=np.random.default_rng(661)
    bounds=np.quantile(a[rng.integers(len(a),size=(10000,len(a)))].mean(1),[.025,.975])
    return float(a.mean()),bounds


def main():
    tr,va,_,_=ids();s=json.loads((RESULTS/'diagnostic_summary.json').read_text())
    probes=json.loads((RESULTS/'probes.json').read_text());rec=json.loads((RESULTS/'reconstruction.json').read_text())
    fig,axes=plt.subplots(2,2,figsize=(183/25.4,163/25.4),layout='constrained')
    source=[]
    # a: fixed-seed linear decodability, not a causal information measure.
    names=['input','fc1','fc2','block1','block4','block8','projector','message1','message2','message3']
    ax=axes[0,0];values=[];lo=[];hi=[]
    for name in names:
        row=next(v for v in probes if v['kind']=='ridge' and v['representation']==name)
        v=[row['validation']['per_design'][i]['rigid_rmsd_nm'] for i in va];mean,b=interval(v)
        values.append(mean);lo.append(mean-b[0]);hi.append(b[1]-mean)
        source.extend(dict(panel='a',series=name,design=i,value=z) for i,z in zip(va,v))
    ax.errorbar(range(len(names)),values,yerr=[lo,hi],color='#3977a8',marker='o',markersize=3,lw=1,capsize=2)
    ax.set_xticks(range(len(names)),['Input','FC1','FC2','B1','B4','B8','Proj','M1','M2','M3'],rotation=45,ha='right',rotation_mode='anchor')
    ax.set_ylabel('Rigid RMSD (nm)');ax.set_title('a  Linear motion decoding')
    # b: effects of appended information, same paired designs.
    ax=axes[0,1];comparisons=[('spatial__minus__block8','Spatial'),('spatial__minus__spatial_shuffled','Spatial − shuffled'),
       ('attachment__minus__block8','Attachment'),('attachment__minus__attachment_shuffled','Attach − shuffled')]
    for k,(key,label) in enumerate(comparisons):
        row=s['probe_contrasts'][key];v=[row['per_design'][i] for i in va];mean,b=interval(v)
        ax.scatter(np.full(14,k)+np.linspace(-.12,.12,14),v,color='#aaaaaa',s=6,alpha=.7)
        ax.errorbar(k,mean,yerr=[[mean-b[0]],[b[1]-mean]],fmt='o',color='#3977a8',markersize=4,capsize=3)
        source.extend(dict(panel='b',series=key,design=i,value=z) for i,z in zip(va,v))
    ax.axhline(0,color='#666666',lw=.6);ax.set_xticks(range(4),[v[1] for v in comparisons],rotation=30,ha='right',rotation_mode='anchor')
    ax.set_ylabel('Paired RMSD change (nm)');ax.set_title('b  Nonlinear probe gains')
    # c: oracle swaps identify centroid translation as dominant geometric error.
    ax=axes[1,0];names=[('rigid_rmsd_nm','Predicted'),('oracle_translation_rmsd_nm','True t'),('oracle_rotation_rmsd_nm','True R'),('oracle_rmsd_nm','True t + R')]
    for k,(key,label) in enumerate(names):
        v=[np.mean([rec[str(seed)]['per_design'][i][key] for seed in [11,22,33]]) for i in va];mean,b=interval(v)
        ax.scatter(np.full(14,k)+np.linspace(-.12,.12,14),v,s=6,color='#aaaaaa',alpha=.7)
        ax.errorbar(k,mean,yerr=[[mean-b[0]],[b[1]-mean]],fmt='o',color='#d17b41',markersize=4,capsize=3)
        source.extend(dict(panel='c',series=key,design=i,value=z) for i,z in zip(va,v))
    ax.set_xticks(range(4),[v[1] for v in names]);ax.set_ylabel('Rigid RMSD (nm)');ax.set_title('c  Label-assisted oracle swaps')
    # d: matched new graph heads, the actual intervention is near zero.
    ax=axes[1,1]
    for k,(key,label) in enumerate([('spatial__minus__zero','Spatial − control'),('spatial__minus__shuffled','Spatial − shuffled')]):
        row=s['fresh_contrasts'][key];v=[row['per_design'][i] for i in va];mean,b=interval(v)
        ax.scatter(np.full(14,k)+np.linspace(-.12,.12,14),v,s=8,color='#aaaaaa',alpha=.7)
        ax.errorbar(k,mean,yerr=[[mean-b[0]],[b[1]-mean]],fmt='o',color='#d17b41',markersize=4,capsize=3)
        source.extend(dict(panel='d',series=key,design=i,value=z) for i,z in zip(va,v))
    ax.axhline(0,color='#666666',lw=.6);ax.set_xticks([0,1],['Spatial − control','Spatial − shuffled'],rotation=15,ha='right',rotation_mode='anchor')
    ax.set_ylabel('Paired RMSD change (nm)');ax.set_title('d  Matched fresh graph-head test')
    folder=HERE/'figures';folder.mkdir(exist_ok=True)
    fig.savefig(folder/'diagnostic_summary.svg');fig.savefig(folder/'diagnostic_summary.pdf')
    fig.savefig(folder/'diagnostic_summary.png',dpi=300)
    plt.close(fig)
    with (folder/'source_data.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,['panel','series','design','value']);w.writeheader();w.writerows(source)
    dump(folder/'figure_contract.json',dict(backend='python',archetype='quantitative grid',width_mm=183,height_mm=163,
         independent_units=14,interval='10000paired-design bootstrap95%, unadjusted exploratory',
         seed_aggregation='3seeds averaged within design except fixed seed11 linear probe',all_designs_preserved=True,
         exclusions=0,p_value_tests=None,claim='Probe gains do not necessarily transfer to matched graph-head improvements.'))


if __name__=='__main__':main()
