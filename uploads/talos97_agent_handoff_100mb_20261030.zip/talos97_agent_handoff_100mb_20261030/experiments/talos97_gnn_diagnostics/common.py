"""Shared input-only extraction and explicitly label-assisted diagnostic metrics."""
import hashlib
import json
import os
from pathlib import Path
import sys

os.environ.setdefault('WANDB_MODE', 'disabled')
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
import numpy as np
import torch
from scipy.spatial.transform import Rotation

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
P11 = ROOT / 'experiments/talos97_model_improvement/phase11_domain_supervision'
sys.path.insert(0, str(P11))
import run_experiment as old
from diagnostic_model import DiagnosticHead, p10

RESULTS = HERE / 'results'
CACHE = HERE / 'cache'
NM = 34.072


def dump(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    def convert(v):
        if isinstance(v, np.ndarray): return v.tolist()
        if isinstance(v, np.generic): return v.item()
        if isinstance(v, Path): return str(v)
        raise TypeError(type(v).__name__)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=convert, allow_nan=False) + '\n')
    tmp.replace(path)


def ids():
    tr, va = p10.read_train_validation_ids(old.DATA / 'split.json')
    assert len(tr) == 68 and len(va) == 14 and len(set(tr + va)) == 82
    assert va == json.loads((p10.ROOT/'experiments/talos97_model_improvement/phase1_error_localization/results/summary.json').read_text())['validation_ids']
    order = sorted(tr, key=lambda v: hashlib.sha256(v.encode()).hexdigest())
    return tr, va, order[:-14], order[-14:]


def provenance():
    tr, va, _, _ = ids()
    paths = [old.DATA/'split.json', old.DATA/'manifest.json', p10.BASE_DIR/'model.py',
             P11/'run_experiment.py', P11/'diagnostic_model.py', Path(old.PHASE10)]
    paths += [old.DATA/k/f'{i}.npz' for i in tr+va for k in ['inputs', 'labels']]
    paths += [p10.BASE_CHECKPOINTS/f'frame_{s}.pt' for s in (11,22,33)]
    paths += [P11/'runs'/f'seed{s}'/'best.pt' for s in (11,22,33)]
    paths += [P11/'runs'/f'seed{s}'/'history.jsonl' for s in (11,22,33)]
    paths += [HERE/'SPEC.md', HERE/'EXPECTED_VERIFICATION.md']
    return {str(p): old.sha(p) for p in paths}


def raw_design(ident):
    tr, va, _, _ = ids()
    if ident not in tr+va: raise ValueError('ID outside explicit train/validation boundary')
    return p10.build_raw(ident)


def models(seed, device):
    base = p10.make_model(seed, 'control', device).eval()
    head = DiagnosticHead().to(device).eval()
    head.load_state_dict(torch.load(P11/'runs'/f'seed{seed}'/'best.pt', map_location='cpu', weights_only=False)['state'])
    return base, head


def npv(x):
    return x.detach().cpu().numpy() if isinstance(x, torch.Tensor) else np.asarray(x)


def capture(base, head, raw, device):
    s, B, R = p10.geometry(raw, multiscale=True)
    st, bt, rt = [torch.as_tensor(v, device=device) for v in (s, B, R)]
    graph = p10.coarse_graph(raw, device)
    activations = {}
    handles = []
    for name, module in [('fc1',base.fc1), ('fc2',base.fc2)]:
        handles.append(module.register_forward_hook(lambda m,a,o,n=name: activations.__setitem__(n,npv(torch.nn.functional.silu(o)))))
    for k, block in enumerate(base.residual_blocks):
        handles.append(block.register_forward_hook(lambda m,a,o,n=f'block{k+1}': activations.__setitem__(n,npv(a[0]+o))))
    with torch.no_grad():
        layers, h = base.encode(st)
        delta, coeff, _, _ = base.readout(h, bt, rt)
        for handle in handles: handle.remove()
        n = len(graph['centers']); index = graph['index']
        pooled = p10.segment_mean(h[:,:346], index, n)
        manual = head.projector(pooled)
        domain = {'projector':npv(manual)}
        for k, layer in enumerate(head.layers):
            manual = layer(manual, graph['edges'], graph['features'])
            domain[f'message{k+1}'] = npv(manual)
        t, r = head(pooled, graph)
        manual_t = torch.einsum('dij,dj->di', graph['frames'], head.translation(manual))
        manual_r = p10.so3_exp(torch.einsum('dij,dj->di',graph['frames'],head.rotation(manual)))
        assert torch.max(torch.abs(manual_t-t)) < 1e-5 and torch.max(torch.abs(manual_r-r)) < 1e-5
        pooled_layers = {'input':npv(p10.segment_mean(st,index,n)),
                         'normalized_input':npv(p10.segment_mean(layers[0],index,n))}
        pooled_layers.update({name:npv(p10.segment_mean(torch.as_tensor(value,device=device),index,n)) for name,value in activations.items()})
        final = h[:,:346]
        dispersion = p10.segment_mean((final-pooled[index]).square(),index,n).clamp_min(0).sqrt()
        g = torch.cat([final.mean(0),final.max(0).values])
        pooled_layers['block8_global'] = npv(torch.cat([pooled,g.expand(n,-1)],-1))
        # Fixed label-free random projection; no learned or data-fitted alignment.
        rp = np.random.default_rng(717).normal(size=(346,32)).astype('float32') / np.sqrt(346)
        proj = final @ torch.as_tensor(rp,device=device,dtype=final.dtype)
        rel = (torch.as_tensor(raw['pos']*NM,device=device)-graph['centers'][index]).float()
        rel = torch.einsum('ni,nij->nj',rel,graph['frames'][index])/10
        moment = p10.segment_mean((proj[:,:,None]*rel[:,None,:]).flatten(1),index,n)
        pooled_layers['spatial'] = npv(torch.cat([pooled,moment],-1))
        # Same96added dimensions, no position information.
        rp96 = np.random.default_rng(718).normal(size=(346,96)).astype('float32') / np.sqrt(346)
        pooled_layers['dispersion'] = npv(torch.cat([pooled,dispersion@torch.as_tensor(rp96,device=device,dtype=final.dtype)],-1))
    return dict(s=s,B=B,R=R,graph={k:npv(v) if isinstance(v,torch.Tensor) else v for k,v in graph.items()},
                pooled=pooled_layers,domain=domain,t=npv(t),r=npv(r),delta=npv(delta),coeff=npv(coeff),
                node_final=npv(final),node_h=npv(h),node_normalized=npv(layers[0]))


def attachment_features(raw, graph):
    """Typed incident attachment positions, moments and directions in source anchor frame."""
    x = np.asarray(raw['pos'],float)*NM
    index=graph['index']; centers=graph['centers']; frames=graph['frames']; n=len(centers)
    i,j=raw['edge_index']; keep=index[i]!=index[j]
    i,j=i[keep],j[keep]; types=raw['edge_types'][keep]; d=index[i]
    rel=np.einsum('ni,nij->nj',x[i]-centers[d],frames[d])/10
    direction=x[j]-x[i]
    direction/=np.maximum(np.linalg.norm(direction,axis=1,keepdims=True),1e-8)
    direction=np.einsum('ni,nij->nj',direction,frames[d])
    upper=np.triu_indices(3)
    second=(rel[:,:,None]*rel[:,None,:])[:,upper[0],upper[1]]
    cross=np.cross(rel,direction)
    rows=np.concatenate([rel,second,direction,cross],1) # 15 dimensions per relation
    parts=[]
    for typ in range(5):
        m=types==typ; count=np.bincount(d[m],minlength=n)
        total=np.zeros((n,15));np.add.at(total,d[m],rows[m])
        parts.append(np.concatenate([np.log1p(count[:,None]),total/np.maximum(count[:,None],1)],1))
    return np.concatenate(parts,1).astype('float32')


def target_vector(t, r, frames):
    local_t = np.einsum('dji,dj->di',frames,t)
    local_r = np.einsum('dji,djk,dkl->dil',frames,r,frames)
    return np.concatenate([local_t,(local_r-np.eye(3)).reshape(-1,9)],1)


def project_rotation(m):
    u,_,vt=np.linalg.svd(m)
    fix=np.broadcast_to(np.eye(3),m.shape).copy();fix[:,-1,-1]=np.linalg.det(u@vt)
    return u@fix@vt


def decode_vector(y, frames):
    t=np.einsum('dij,dj->di',frames,y[:,:3])
    rlocal=project_rotation(y[:,3:].reshape(-1,3,3)+np.eye(3))
    r=np.einsum('dij,djk,dlk->dil',frames,rlocal,frames)
    return t,r


def rigid(x, index, t, r):
    counts=np.bincount(index);n=len(counts)
    centers=np.stack([np.bincount(index,weights=x[:,k],minlength=n)/counts for k in range(3)],1)
    return np.einsum('nij,nj->ni',r[index],x-centers[index])+centers[index]+t[index]


def centered(y,x):
    return y-y.mean(0)+x.mean(0)


def endpoint(y, target):
    return float(np.sqrt(np.mean(np.sum((y-target)**2,axis=1))))


def domain_metrics(t,r,d):
    m=d['valid'];diff=t-d['target_t'];delta=np.swapaxes(r[m],1,2)@d['target_r'][m]
    angle=np.arccos(np.clip((np.trace(delta,axis1=1,axis2=2)-1)/2,-1,1))*180/np.pi
    tl=float(np.mean(np.sum(diff**2,axis=1)))
    rl=float(np.mean(np.sum((r[m]-d['target_r'][m])**2,axis=(1,2))))
    pred=centered(rigid(d['x'],d['index'],t,r),d['x'])
    return dict(loss=tl+rl,translation_mse_nm2=tl,translation_rmse_nm=tl**.5,
                rotation_frobenius=rl,rotation_deg=float(angle.mean()),rigid_rmsd_nm=endpoint(pred,d['target']))


def read_cache(ident,seed=11):
    with np.load(CACHE/f'seed{seed}'/f'{ident}.npz') as a:
        return {k:a[k] for k in a.files}


def macro(rows):
    return {k:float(np.mean([r[k] for r in rows])) for k in rows[0]}


def save_npz(path, **arrays):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(path,**arrays)
