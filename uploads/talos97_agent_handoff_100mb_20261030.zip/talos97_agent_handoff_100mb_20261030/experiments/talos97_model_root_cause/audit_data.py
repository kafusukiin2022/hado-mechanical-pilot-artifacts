#!/usr/bin/env python3
"""Read-only TALOS97 train/validation label-noise audit; never decodes test IDs."""
from __future__ import annotations

import csv
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / "results"
SPLIT = ROOT / "experiments/talos97_endpoint_v1/data/split.json"
TRIPLICATE = ROOT / "outputs/talos97_triplicate_analysis_20261028"
PHASE7 = ROOT / "experiments/talos97_model_improvement/phase7_domain_motion_audit/results"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json_string(stream) -> str:
    first = stream.read(1)
    while first and first.isspace():
        first = stream.read(1)
    if first != '"':
        raise ValueError(f"expected JSON string, got {first!r}")
    chars = ['"']
    escaped = False
    while True:
        c = stream.read(1)
        if not c:
            raise ValueError("truncated JSON string")
        chars.append(c)
        if escaped:
            escaped = False
        elif c == "\\":
            escaped = True
        elif c == '"':
            return json.loads("".join(chars))


def skip_ws(stream) -> str:
    c = stream.read(1)
    while c and c.isspace():
        c = stream.read(1)
    return c


def read_ids(stream) -> list[str]:
    if skip_ws(stream) != "[":
        raise ValueError("expected ID array")
    out: list[str] = []
    while True:
        c = skip_ws(stream)
        if c == "]":
            return out
        if c != '"':
            raise ValueError(f"expected ID string or end, got {c!r}")
        chars = ['"']
        escaped = False
        while True:
            c = stream.read(1)
            if not c:
                raise ValueError("truncated ID")
            chars.append(c)
            if escaped:
                escaped = False
            elif c == "\\":
                escaped = True
            elif c == '"':
                out.append(json.loads("".join(chars)))
                break
        c = skip_ws(stream)
        if c == "]":
            return out
        if c != ",":
            raise ValueError(f"expected comma or array end, got {c!r}")


def read_train_val_ids(path: Path) -> tuple[list[str], list[str]]:
    """Stream through train and validation and stop before test key/value bytes."""
    with path.open("r", encoding="utf-8") as stream:
        if skip_ws(stream) != "{":
            raise ValueError("split root is not an object")
        if read_json_string(stream) != "train":
            raise ValueError("train must be the first key")
        if skip_ws(stream) != ":":
            raise ValueError("missing train colon")
        train = read_ids(stream)
        if skip_ws(stream) != ",":
            raise ValueError("missing comma after train")
        if read_json_string(stream) != "validation":
            raise ValueError("validation must be the second key")
        if skip_ws(stream) != ":":
            raise ValueError("missing validation colon")
        validation = read_ids(stream)
        return train, validation


def mean(xs: list[float]) -> float:
    return sum(xs) / len(xs) if xs else float("nan")


def quantile(xs: list[float], q: float) -> float:
    if not xs:
        return float("nan")
    x = sorted(xs)
    at = (len(x) - 1) * q
    lo = int(math.floor(at))
    hi = int(math.ceil(at))
    if lo == hi:
        return float(x[lo])
    return float(x[lo] * (hi - at) + x[hi] * (at - lo))


def pearson(xs: list[float], ys: list[float]) -> float | None:
    if len(xs) != len(ys) or len(xs) < 3:
        return None
    mx, my = mean(xs), mean(ys)
    dx, dy = [x - mx for x in xs], [y - my for y in ys]
    sx = math.sqrt(sum(x * x for x in dx))
    sy = math.sqrt(sum(y * y for y in dy))
    return sum(x * y for x, y in zip(dx, dy)) / (sx * sy) if sx and sy else None


def average_ranks(xs: list[float]) -> list[float]:
    order = sorted(range(len(xs)), key=xs.__getitem__)
    ranks = [0.0] * len(xs)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and xs[order[j]] == xs[order[i]]:
            j += 1
        rank = (i + 1 + j) / 2
        for k in order[i:j]:
            ranks[k] = rank
        i = j
    return ranks


def correlation(x: list[float], y: list[float]) -> dict[str, Any]:
    return {"n_designs": len(x), "pearson_r": pearson(x, y), "spearman_rho": pearson(average_ranks(x), average_ranks(y))}


def split_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    min_ess = [float(r["min_scalar_ess"]) for r in rows]
    pooled_rmsf = [float(r["mean_pooled_rmsf_nm"]) for r in rows]
    replica_spread = [float(r["max_pairwise_mean_rmsd_nm"]) for r in rows]
    max_replica_drifts = [
        max(float(rep["first_last_quarter_mean_rms_nm"]) for rep in r["replicas"])
        for r in rows
    ]
    mean_pairwise = [
        mean([float(c["mean_kabsch_rmsd_nm"]) for c in r["comparisons"]])
        for r in rows
    ]
    return {
        "n_designs": len(rows),
        "replicas_per_design": sorted({int(r["n_replicas"]) for r in rows}),
        "mean_pooled_rmsf_nm": mean(pooled_rmsf),
        "median_pooled_rmsf_nm": quantile(pooled_rmsf, 0.5),
        "mean_min_scalar_ess": mean(min_ess),
        "min_min_scalar_ess": min(min_ess),
        "median_min_scalar_ess": quantile(min_ess, 0.5),
        "max_min_scalar_ess": max(min_ess),
        "designs_min_ess_below_10": sum(v < 10 for v in min_ess),
        "mean_max_pairwise_replica_mean_rmsd_nm": mean(replica_spread),
        "median_max_pairwise_replica_mean_rmsd_nm": quantile(replica_spread, 0.5),
        "n_designs_max_pairwise_replica_rmsd_gt_1_5_nm": sum(v > 1.5 for v in replica_spread),
        "mean_pairwise_replica_mean_rmsd_nm": mean(mean_pairwise),
        "mean_worst_replica_first_last_quarter_drift_nm": mean(max_replica_drifts),
        "needs_review_designs": sum(r.get("agreement_status") == "needs_review" for r in rows),
        "replica_mean_disagreement_exceeds_within_quarter_mean_variation_pairs": sum(
            bool(c["mean_exceeds_within_quarter_variation"])
            for r in rows for c in r["comparisons"]
        ),
        "replica_pair_comparisons": sum(len(r["comparisons"]) for r in rows),
        "interpretation": "Equal-design descriptive summaries. ESS and replica spread are diagnostics, not a strict error floor or proof of invalid sampling.",
    }


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    train_ids, val_ids = read_train_val_ids(SPLIT)
    if len(train_ids) != 68 or len(val_ids) != 14 or len(set(train_ids + val_ids)) != 82:
        raise ValueError("unexpected frozen split")
    ids = train_ids + val_ids
    opened_summaries = [TRIPLICATE / ident / "summary.json" for ident in ids]
    for p in opened_summaries:
        if not p.is_file():
            raise FileNotFoundError(p)
    summaries = {}
    for ident, path in zip(ids, opened_summaries):
        item = json.loads(path.read_text())
        if item.get("design_id") != ident:
            raise ValueError(f"summary ID mismatch for {ident}")
        if item.get("n_replicas") != 3 or len(item.get("replicas", [])) != 3:
            raise ValueError(f"expected three replicas for {ident}")
        summaries[ident] = item

    phase7_design_path = PHASE7 / "per_design.csv"
    phase7_motion_path = PHASE7 / "motion_bins_by_design.csv"
    design_rows = read_csv(phase7_design_path)
    if len(design_rows) != 14 or {r["design"] for r in design_rows} != set(val_ids):
        raise ValueError("Phase 7 design table is not exactly the frozen validation set")
    motion_rows = read_csv(phase7_motion_path)
    if {r["design"] for r in motion_rows} - set(val_ids):
        raise ValueError("unexpected non-validation motion row")

    design_by_id = {r["design"]: r for r in design_rows}
    long_by_id = {
        (r["design"], r["model"]): r
        for r in motion_rows if r["target_motion_bin"] == ">=4nm"
    }
    rows_out = []
    for part, part_ids in (("train", train_ids), ("validation", val_ids)):
        for ident in part_ids:
            s = summaries[ident]
            row: dict[str, Any] = {
                "split": part,
                "design": ident,
                "nucleotides": int(s["nucleotides"]),
                "min_scalar_ess": float(s["min_scalar_ess"]),
                "mean_pooled_rmsf_nm": float(s["mean_pooled_rmsf_nm"]),
                "max_pairwise_replica_mean_rmsd_nm": float(s["max_pairwise_mean_rmsd_nm"]),
                "mean_pairwise_replica_mean_rmsd_nm": mean([float(c["mean_kabsch_rmsd_nm"]) for c in s["comparisons"]]),
                "worst_first_last_quarter_mean_drift_nm": max(float(r["first_last_quarter_mean_rms_nm"]) for r in s["replicas"]),
                "agreement_status": s["agreement_status"],
            }
            if part == "validation":
                d = design_by_id[ident]
                row.update({
                    "onepass_rmsd_nm": float(d["onepass_rmsd_nm"]),
                    "localframe_ensemble_rmsd_nm": float(d["localframe_ensemble_rmsd_nm"]),
                    "domain_rigid_oracle_rmsd_nm": float(d["domain_rigid_oracle_rmsd_nm"]),
                })
                for model in ("OnePass", "localframe_ensemble"):
                    b = long_by_id.get((ident, model))
                    row[f"{model}_long_target_motion_nm"] = float(b["mean_target_motion_nm"]) if b else None
                    row[f"{model}_long_predicted_motion_nm"] = float(b["mean_pred_motion_nm"]) if b else None
                    row[f"{model}_long_direction_cosine"] = float(b["mean_direction_cosine"]) if b else None
            rows_out.append(row)

    fields = list(dict.fromkeys(k for r in rows_out for k in r))
    with (OUT / "per_design_train_val.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows_out)

    train_rows = [summaries[i] for i in train_ids]
    val_rows = [summaries[i] for i in val_ids]
    val_out = [r for r in rows_out if r["split"] == "validation"]
    xs = {
        "replica_spread_nm": [r["max_pairwise_replica_mean_rmsd_nm"] for r in val_out],
        "min_ess": [r["min_scalar_ess"] for r in val_out],
        "rmsf_nm": [r["mean_pooled_rmsf_nm"] for r in val_out],
    }
    ys = {
        "onepass_rmsd_nm": [r["onepass_rmsd_nm"] for r in val_out],
        "localframe_ensemble_rmsd_nm": [r["localframe_ensemble_rmsd_nm"] for r in val_out],
        "domain_rigid_oracle_rmsd_nm": [r["domain_rigid_oracle_rmsd_nm"] for r in val_out],
    }
    correlations = {
        f"{x_name}__{y_name}": correlation(x_values, y_values)
        for x_name, x_values in xs.items() for y_name, y_values in ys.items()
    }
    hashes_before = {
        "split_sha256": sha256(SPLIT),
        "phase7_per_design_sha256": sha256(phase7_design_path),
        "phase7_motion_bins_by_design_sha256": sha256(phase7_motion_path),
        "analysis_source_sha256": sha256(Path(__file__).resolve()),
        "opened_train_validation_summary_sha256": {ident: sha256(path) for ident, path in zip(ids, opened_summaries)},
    }
    hashes_after = {
        "split_sha256": sha256(SPLIT),
        "phase7_per_design_sha256": sha256(phase7_design_path),
        "phase7_motion_bins_by_design_sha256": sha256(phase7_motion_path),
        "analysis_source_sha256": sha256(Path(__file__).resolve()),
        "opened_train_validation_summary_sha256": {ident: sha256(path) for ident, path in zip(ids, opened_summaries)},
    }
    summary = {
        "schema": "talos97_root_cause_data_audit.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "train_design_count": len(train_ids),
        "validation_design_count": len(val_ids),
        "test_ids_decoded": False,
        "test_input_opened": False,
        "test_label_opened": False,
        "test_replica_summary_opened": False,
        "test_prediction_rows_read": False,
        "model_inference": False,
        "optimizer_steps": 0,
        "checkpoint_writes": 0,
        "train": split_summary(train_rows),
        "validation": split_summary(val_rows),
        "validation_model_metrics": {
            "onepass_macro_rmsd_nm": mean(ys["onepass_rmsd_nm"]),
            "localframe_ensemble_macro_rmsd_nm": mean(ys["localframe_ensemble_rmsd_nm"]),
            "domain_rigid_oracle_macro_rmsd_nm": mean(ys["domain_rigid_oracle_rmsd_nm"]),
            "mean_pairwise_replica_rmsd_nm": mean([r["mean_pairwise_replica_mean_rmsd_nm"] for r in val_out]),
            "mean_worst_pairwise_replica_rmsd_nm": mean([r["max_pairwise_replica_mean_rmsd_nm"] for r in val_out]),
            "mean_long_motion_target_nm": mean([r["OnePass_long_target_motion_nm"] for r in val_out if r["OnePass_long_target_motion_nm"] is not None]),
            "mean_long_motion_onepass_pred_nm": mean([r["OnePass_long_predicted_motion_nm"] for r in val_out if r["OnePass_long_predicted_motion_nm"] is not None]),
            "mean_long_motion_localframe_pred_nm": mean([r["localframe_ensemble_long_predicted_motion_nm"] for r in val_out if r["localframe_ensemble_long_predicted_motion_nm"] is not None]),
        },
        "validation_design_correlations_exploratory": correlations,
        "hashes_before": hashes_before,
        "hashes_after": hashes_after,
        "hashes_unchanged": hashes_before == hashes_after,
        "summary_paths_opened": [str(p.resolve()) for p in opened_summaries],
        "validation_artifacts_opened": [str(phase7_design_path.resolve()), str(phase7_motion_path.resolve())],
    }
    (OUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    checks = {
        "train_and_validation_ids_incremental_68_14": len(train_ids) == 68 and len(val_ids) == 14,
        "only_82_train_validation_summary_paths_opened": len(opened_summaries) == 82,
        "all_opened_summaries_have_three_replicas": all(r["n_replicas"] == 3 for r in summaries.values()),
        "phase7_artifacts_exact_validation_only": len(design_rows) == 14 and {r["design"] for r in design_rows} == set(val_ids) and not ({r["design"] for r in motion_rows} - set(val_ids)),
        "test_ids_not_decoded_or_files_opened": all(summary[k] is False for k in ("test_ids_decoded", "test_input_opened", "test_label_opened", "test_replica_summary_opened", "test_prediction_rows_read")),
        "no_model_or_optimizer_activity": summary["model_inference"] is False and summary["optimizer_steps"] == 0 and summary["checkpoint_writes"] == 0,
        "provenance_hashes_unchanged": summary["hashes_unchanged"],
        "validation_correlations_are_design_level_n14": all(v["n_designs"] == 14 for v in correlations.values()),
    }
    verification = {
        "passed": all(checks.values()),
        "checks": checks,
        "designs_read": {"train": train_ids, "validation": val_ids},
        "test_ids_decoded": False,
        "test_files_opened": False,
        "optimizer_steps": 0,
        "checkpoint_writes": 0,
    }
    (OUT / "verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"summary": summary, "verification": verification}, ensure_ascii=False, indent=2))
    return 0 if verification["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
