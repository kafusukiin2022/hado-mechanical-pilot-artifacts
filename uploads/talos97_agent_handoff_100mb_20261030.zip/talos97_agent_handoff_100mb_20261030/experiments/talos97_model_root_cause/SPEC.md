# TALOS97 long-displacement root-cause audit

## Question

Separate four explanations for the long-distance node underprediction in the current endpoint regressors: (1) finite-trajectory label noise or replica variability, (2) insufficient design-level supervision, (3) model representation/receptive-field mismatch, and (4) objective/optimization mismatch. Use the already completed validation-only domain-motion audit, 82 train/validation replica summaries, existing training records, and primary literature. Do not read test IDs, test labels, or test predictions.

## Scope and fixed boundaries

- Dataset: TALOS97 endpoint-v1, 68 train / 14 validation / 15 test, 97 designs and 834,348 nucleotide nodes. Independent generalization units are designs, not nodes.
- The current target is the 1000-frame empirical mean of replica 1, aligned to the initial input. This audit must distinguish this finite-trajectory target from an equilibrium structure or a replica-independent conformational expectation.
- Open only per-design triplicate summaries for train and validation IDs, the Phase 7 validation-only `per_design.csv` and `motion_bins_by_design.csv`, and existing source/spec/report files needed to interpret prior experiments.
- Read `split.json` incrementally and stop after the validation ID array. Do not decode test IDs or open test-design summaries, inputs, labels, or predictions.
- No training, model inference, checkpoint changes, test evaluation, or resource submission.

## Questions and outputs

1. Summarize 1000-frame trajectory ESS, replica-mean disagreement, RMSF, and first-vs-last-quarter drift for train and validation designs separately.
2. For the 14 validation designs, compare replica variability with the frozen OnePass/localframe RMSD and with the >=4 nm motion-bin prediction amplitude. Report design-level correlations as exploratory descriptors only; do not treat nucleotide rows as independent or call the correlations causal.
3. Explain what the current model family does and does not represent, based on source and existing matched interventions.
4. Verify publication metadata and summarize methodological transfer limits for oxDNA/DNA-origami simulation, EBD, hierarchical message passing, long-range molecular graph models, equivariant diffusion, and torsional diffusion.
5. Recommend the smallest next discriminating experiment and a separate generative model direction if deterministic replica-mean regression is noise-limited.

## Decision language

- Distinguish observed facts, supported hypotheses, and unresolved causes.
- `needs_review` / low ESS is evidence of sampling uncertainty, not proof that a trajectory is invalid.
- Replica disagreement provides an empirical variability scale, not a strict irreducible-error lower bound.
- Validation-label domain oracles are diagnostic ceilings only.
- Do not conclude that 97 designs are either universally sufficient or inherently unusable. State the demonstrated scope: a fixed-family, design-held-out 6HB pilot with 68 train designs.

## Artifacts

- `EXPECTED_VERIFICATION.md`: data boundary and reproducibility checks.
- `audit_data.py`: read-only, validation-safe aggregate and correlation audit.
- `results/REPORT_ZH.md`: evidence synthesis, citations, model recommendation, and limits.
- `results/summary.json`, `results/per_design_train_val.csv`, `results/verification.json`: machine-readable results and provenance.
