# Expected verification

Run the analysis using the project torch environment:

```bash
/home/lijingjing/lijj/users/lht2/deeporigami/agent/hado_mechanical_pilot/.venv-torch/bin/python -m py_compile experiments/talos97_model_root_cause/audit_data.py
/home/lijingjing/lijj/users/lht2/deeporigami/agent/hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_root_cause/audit_data.py
```

The result is valid only if:

- the split reader stops immediately after the validation array and returns exactly 68 train + 14 validation IDs;
- exactly those 82 individual replica-summary JSONs are opened, and the Phase 7 rows contain only the frozen 14 validation designs;
- all 82 summaries report three replicas and finite trajectory diagnostics;
- the output reports equal-design summaries, not node-level inferential sample sizes;
- validation correlations use at most 14 design rows and are labeled exploratory;
- SHA256 hashes of the split bytes, source summary artifacts, and analysis code are recorded before/after;
- no test input, label, summary, or prediction file is opened, no test IDs are decoded, and no optimizer step or checkpoint write occurs;
- `./init.sh` remains passing and harness state is updated with the report path and evidence.
