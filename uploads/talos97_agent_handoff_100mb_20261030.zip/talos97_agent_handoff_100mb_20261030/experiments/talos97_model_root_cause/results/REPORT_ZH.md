# TALOS97 长距离构型预测失败：数据、表示与模型的根因判断

生成日期：2026-10-30。本文只讨论 TALOS97 endpoint-v1 的固定协议：输入是 `initial.dat` 的 t=0 构型，标签是 replica 1 的 1000-frame 几何平均，并做 whole-design proper Kabsch 对齐；切分为 68/14/15 个设计。节点数不能替代设计数，真正的独立泛化单位是 97 个设计。

## 结论

当前失败最像是**两个因素叠加**：

1. **标签噪声/采样不稳定已经很大**。所有 97 个设计都被原始 QC 标为 `needs_review`。训练 68 个设计的最小标量 ESS 平均 4.05（范围 2.62–6.99），验证 14 个设计平均 3.89（范围 2.73–7.44）；验证设计的 replica-mean 最大两两 Kabsch RMSD 平均 2.06 nm。标签不是无噪声的平衡构型，而是有限轨迹的经验均值。
2. **当前 OnePass/localframe 的输出表示与真实运动的尺度不匹配**。把 14 个验证设计的长位移节点合并后计算（node-pooled），≥4 nm 位移节点的目标均值为 4.936 nm，OnePass 只有 1.480 nm，localframe ensemble 只有 1.646 nm；该组仅占 9.9% 节点，却贡献约 32% pooled SSE。若先对每个设计计算长位移组均值再等权平均（design-macro），目标/OnePass/localframe 分别是 4.772/1.602/1.759 nm，详见 `results/summary.json`。按验证标签拟合的每-domain proper rigid oracle 可把宏 RMSD 降到 0.312 nm，相对 identity 减少 98.59% pooled SSE。这是诊断上限，不是可部署结果，但它直接说明目标包含强 domain-coherent SE(3) 成分。

因此，不能把失败归结为“97 个设计一定不够”或“训练没有更新”。已有诊断显示梯度有限、主干覆盖完整；加宽、换 TransformerConv、改 RMSD 目标、加节点幅度门和长短专家都没有实质解决大位移压缩。最优先的缺口是：模型没有显式预测域级刚体变量，也没有真正的粗图长程交互。

## 数据到底有没有问题

### 已确认不是格式损坏

97 行 manifest、输入/标签分离、有限性、拓扑回边、旋转正交性和固定 split 均通过；identity RMSD 为 train 2.639、validation 2.603、test 2.476 nm。输入没有 target-derived 特征，标签经过统一 Kabsch 对齐。数据管线的结构完整性没有证据显示是主要 bug。

### 已确认标签有很强的不确定性

三条 replica 都有 1000 帧，几何量和 backbone QC 通过，但时间相关导致有效样本远小于 1000。训练 68/68、验证 14/14 的最小 ESS 都低于 10；训练设计中 51/68 的最大 replica-mean disagreement 超过 1.5 nm，验证中为 12/14。验证设计的 pooled RMSF 平均 1.726 nm，replica mean 的平均 pairwise RMSD 为 1.768 nm，最坏 pairwise RMSD 平均 2.061 nm。

这些数值说明标签是“该模拟协议下的一条有限轨迹均值”，不是唯一、无噪声的真值。它们不能单独证明模拟无效：低 ESS 和 replica 分歧可能来自慢松弛、亚稳态和真实多构象分布。正确结论是，确定性单标签回归的可达到误差需要先用独立 replica/更长轨迹估计，而不能直接拿 1.2 nm 当作无条件可实现目标。

### 长位移与标签噪声有关，但不是唯一解释

验证设计层面，最大 replica spread 与 OnePass RMSD 的 exploratory Pearson 相关为 0.638，与 localframe RMSD 为 0.689；RMSF 与两者的 Spearman 相关约 0.77/0.75。样本只有 14 个设计，这些只是描述性信号，不能做显著性或因果推断。更关键的是，标签拟合 domain rigid oracle 仍为 0.312 nm，远低于 2.15–2.25 nm 的模型误差；因此噪声不能解释全部误差，表示错配仍是主要可行动因素。

## 当前模型为什么会压缩长距离

endpoint-v1 的共同输入主要是 6 维节点特征、20 维边特征、初始位置/局部 frame、拓扑边和 domain ID。OnePass/localframe 用局部向量消息传递、固定两跳平滑、pooling 和逐节点 residual readout，但没有一个明确的变量表示“整个 domain 一起转了多少、平移多少”。逐节点头在 MSE 下更容易学习跨设计平均的保守位移；若大位移方向和幅度由远端 domain 关系决定，局部表征会把协同运动压成小 residual。

这与已有图学习结果一致。Di Giovanni 等的 over-squashing 分析把远程信息失真联系到图瓶颈和高 commute/access time，并指出单纯增加深度不能保证解决问题；Topping 等提出按拓扑瓶颈重连。GraphGPS 则把局部 MPNN 与全局 attention、位置/结构编码解耦，目标就是同时保留局部几何和远程依赖。此前仅替换 TransformerConv 没有效果，说明这里需要真正的粗粒度捷径或全局变量，而不是把一个局部聚合器换成另一个。

## 文献如何指导新模型

- **EBD（Park & Shen, NeurIPS 2024, arXiv:2410.20255）**：先生成 fragment-level 粗结构，再恢复 fine detail；其 blurring 过程把细节向 fragment 均值收缩，避免随机噪声同时破坏粗结构，reverse network 保持 SE(3) 等变。DNA origami 的 fragment 应换成 base-pair/helix-segment/domain，不能直接把药物 fragment vocabulary 照搬。
- **Hierarchical Message-Passing GNN（Zhong et al., 2022, DOI:10.1007/s10618-022-00890-9）**：用 super-graph 和跨层传播给远距离节点建立 shortcut。TALOS 应构建 domain graph，而不是只在 nucleotide graph 上堆更多层。
- **GraphGPS（Rampášek et al., 2022, arXiv:2205.12454）**：局部边消息 + 全局 attention + positional/structural encoding 的组合可在线性复杂度下处理大图。对 6k–10k nucleotide 设计，建议 attention 只在 200–400 个 domain/helix-segment 节点上做，再用 scatter 回填 nucleotide。
- **Ewald message passing（Kosmala et al., ICML 2023, arXiv:2303.04791）**：对真正长程物理作用，用频域/非局部通道补充 cutoff MPNN。它不能直接替代 domain motion，但支持增加廉价全局通道的方向。
- **GeoDiff/EDM（Xu et al., ICLR 2022, arXiv:2203.02923；Hoogeboom et al., ICML 2022, arXiv:2203.17003）**：坐标 diffusion 必须满足旋转/平移等变；这适合生成多构象，但前提是标签或轨迹能够支持分布学习。
- **DNA origami/oxDNA**：Snodin et al.（NAR 2018, DOI:10.1093/nar/gky1304）显示 oxDNA 能复现 2D origami 的 helix bending，并用平均结构与 cryo-EM 比较；Pan et al.（NAR 2017, DOI:10.1093/nar/gkx378）强调 45 个 3D nanoparticles 的全局/局部 dynamics 需要 coarse-grained mechanics；Haggenmueller et al.（2024, arXiv:2409.13206）强调数千碱基对结构的长松弛和大规模模拟困难。这些工作支持“粗粒度力学层 + nucleotide rigid-body decoder”，也提醒我们 finite trajectory mean 不是简单的确定性终点。
- **Torsional Diffusion（Jing et al., NeurIPS 2022, arXiv:2206.01729）**：适用于少数可旋转键主导的小分子构象，不适合作为 DNA origami 第一版的全 nucleotide torsion 方案；DNA origami 的主要自由度包括 domain rotation、helix bending、crossover coupling 和局部 stacking。

## 建议的新模型：Domain-Frame EBD / Hierarchical SE(3) Endpoint Diffusion

第一阶段先做可验证的 endpoint 版本，之后再扩展为多构象 diffusion。

对于每个 nucleotide (i)，令 (d(i)) 为其 domain，输入为初始位置/frame 和拓扑图。模型输出：

\[
\hat x_i=R_{d(i)}(x_i-c_{d(i)})+c_{d(i)}+t_{d(i)}+\delta_i,
\]

其中 domain encoder 在 domain graph 上预测 (t_d\in\mathbb R^3)、
(\omega_d\in\mathbb R^3)，(R_d=\exp([\omega_d]_\times))；nucleotide encoder 只预测局部 residual (\delta_i) 和 frame residual。全局平移约束在输出端按设计中心消除，保证与标签 chart 一致。

结构分为四层：

1. nucleotide graph：backbone、base-pair、crossover、skip 和 spatial edges；
2. helix-segment/base-pair graph：以 8–16 个 axial block 构造稳定粗节点；
3. domain graph：domain centroid/frame、domain size、边类型和相对 frame；
4. global context：domain graph 上的 linear attention 或 Ewald-like nonlocal channel。

训练用零初始化 branch/gate，保证 epoch 0 等价于 localframe；loss 同时包括 node position、domain centroid/rotation、backbone/base-pair distance、frame orientation 和 conservative energy/geometry penalties。不要按 nucleotide 数量让最大设计支配训练，使用设计等权和 domain-size capped pooling。

Phase 8 候选已经完成只读 CPU 预检：零门控复现误差 (3.34\times10^{-8}) nm，global rotation equivariance 误差 0，domain relabel 误差 0，domain rotation determinant 在 0.9999998–1.0000002，branch gate 与两个 head 均有非零梯度。下一步若训练，必须用 paired continuation control、3 个 seed、固定 68/14 split 和 test 隔离；通过标准应是相对 matched control 至少改善 0.05 nm，而不是只看某一个 seed。

## 97 个设计够不够

**够做什么：** 97 个设计、68 个训练设计足以做一个固定 6HB 家族内的设计级 pilot，比较 identity、localframe、domain rigid、coarse-to-fine 和 noise-aware baseline；也足以发现当前长位移压缩的机制问题。

**不够保证什么：** 不能无条件支撑高容量 nucleotide-level generative model 的强泛化，不能覆盖不同 lattice、scaffold 长度、salt/temperature、拓扑族，也不能用 83 万节点数掩盖只有 68 个独立训练设计这一事实。domain graph 的有效样本量仍接近设计数，而非 domain 数；把每个 nucleotide 当独立样本会夸大统计证据。

## 最有判别力的后续实验

1. 先延长/补充 replica，至少用每设计 3–5 条独立 replica，并计算 block-bootstrap/replica covariance；把标签改为均值 + uncertainty，而不是只保存一个 replica-1 mean。
2. 在相同 3-seed、相同 50 epoch budget 下训练 Phase 8 domain-transform residual。若相对 control 没有 ≥0.05 nm 改善，说明 domain ID 或输入几何本身不能从初态预测目标运动，下一步应转向显式 coarse dynamics/条件变量，而不是继续加节点网络。
3. 做 label-noise-aware baseline：预测 domain transform 的均值和方差，loss 使用 inverse-variance weighting 或 Gaussian NLL；同时报告 oracle/replica spread 作为 noise ceiling。
4. 只有在 endpoint domain model 证明有效后，才做 EBD-style coarse-to-fine diffusion：domain/helix frame diffusion → nucleotide rigid-body decoder → oxDNA export/短 relaxation。输出必须满足 `r,a1,a3` 的 oxDNA contract。

本审计的代码、机器结果和边界验证见：`audit_data.py`、`results/summary.json`、`results/per_design_train_val.csv`、`results/verification.json`。该审计未做训练、推理或 test 读取。

## Phase 8 可学习域变换实验结果

为检验上述表示假设，随后在本机 A100 GPU 1 上执行了预注册的 3-seed × 2-arm、每臂 50 epoch 对比，共 20,400 optimizer steps；没有提交 Slurm 作业。独立核验器 v2 的 9 项完整性检查通过，test 未读、基础 checkpoint 未改。

简化的 input-only domain-transform + localframe residual 候选均值验证宏 RMSD 为 **2.178041 nm**，matched continuation 为 **2.175492 nm**，候选略差 0.002549 nm；仅 1/3 seed 略胜，三个候选 checkpoint 都选中零门 epoch 0。三 seed 集成分别为 2.157031 nm 和 2.154073 nm，仍无增益。门、平移头、旋转头都有实际训练梯度，因此负结果不是分支未连接。

这使结论更具体：**label-fitted domain rigid oracle 的确说明标签运动具有域级结构，但按当前方式从初始表示独立预测每域变换并没有学到泛化映射**。数据不稳定仍是明确因素；同时，domain 变换头可能缺少跨域关系和足够强的输入条件。该负结果不推翻 domain/helix coarse graph 假设，也不支持继续堆叠同类 per-node 模块。下一步优先做 replica-aware uncertainty / multi-replica target ablation，再实现带 typed domain edges、helix-segment 聚合和 coarse graph attention 的 Domain-Frame 模型，与容量匹配控制对照。详细逐 seed 结果和边界核验见 `experiments/talos97_model_improvement/phase8_domain_transform_residual/results/REPORT_ZH.md`。

## References

1. Park, J., & Shen, Y. (2024). *Equivariant Blurring Diffusion for Hierarchical Molecular Conformer Generation*. NeurIPS 2024. https://arxiv.org/abs/2410.20255
2. Zhong, Z., Li, C.-T., & Pang, J. (2022). *Hierarchical Message-Passing Graph Neural Networks*. https://doi.org/10.1007/s10618-022-00890-9
3. Di Giovanni, F. et al. (2023). *On Over-Squashing in Message Passing Neural Networks: The Impact of Width, Depth, and Topology*. https://arxiv.org/abs/2302.02941
4. Topping, J. et al. (2022). *Understanding over-squashing and bottlenecks on graphs via curvature*. https://arxiv.org/abs/2111.14522
5. Rampášek, L. et al. (2022). *Recipe for a General, Powerful, Scalable Graph Transformer*. https://arxiv.org/abs/2205.12454
6. Kosmala, A. et al. (2023). *Ewald-based Long-Range Message Passing for Molecular Graphs*. https://arxiv.org/abs/2303.04791
7. Xu, M. et al. (2022). *GeoDiff: a Geometric Diffusion Model for Molecular Conformation Generation*. https://arxiv.org/abs/2203.02923
8. Hoogeboom, E. et al. (2022). *Equivariant Diffusion for Molecule Generation in 3D*. https://arxiv.org/abs/2203.17003
9. Snodin, B. E. et al. (2018/2019). *Coarse-grained modelling of the structural properties of DNA origami*. https://doi.org/10.1093/nar/gky1304
10. Pan, K. et al. (2017). *Structure and conformational dynamics of scaffolded DNA origami nanoparticles*. https://doi.org/10.1093/nar/gkx378
11. Haggenmueller, S. et al. (2024). *How we simulate DNA origami*. https://arxiv.org/abs/2409.13206
12. Jing, B. et al. (2022). *Torsional Diffusion for Molecular Conformer Generation*. https://arxiv.org/abs/2206.01729
