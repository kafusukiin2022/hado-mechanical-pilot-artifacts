"""Reproducible source-only feature construction; supervision stored separately."""
import hashlib,json,shutil,zipfile,sys
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
ROOT=Path(__file__).resolve().parents[3];EXP=ROOT/'experiments/talos97_endpoint_v1';DATA=EXP/'data';SCALE=40.
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rotation(a):
 a1=a[:,3:6].copy();a1/=np.linalg.norm(a1,axis=1)[:,None];a3=a[:,6:9].copy();a3-=np.sum(a1*a3,axis=1)[:,None]*a1;a3/=np.linalg.norm(a3,axis=1)[:,None];return np.stack([a1,np.cross(a3,a1),a3],axis=2)
def preprocess(top,initial,pairs,mapping):
 lines=top.read_text().splitlines();n,ns=map(int,lines[0].split());rows=[x.split() for x in lines[1:]];assert len(rows)==n
 a=np.loadtxt(initial,skiprows=3);assert a.shape==(n,15) and np.isfinite(a).all();assert initial.open().readline().strip()=='t = 0'
 xyz=a[:,:3];center=xyz.mean(0);x=(xyz-center)/SCALE;rot=rotation(a);strand=np.array([int(r[0]) for r in rows]);back=set()
 for i,row in enumerate(rows):
  for j in map(int,row[2:4]):
   if j>=0:
    assert j<n and i in list(map(int,rows[j][2:4]));back.add((i,j))
 bp=np.loadtxt(pairs,dtype=int).reshape(-1,2);assert bp.min()>=0 and bp.max()<n
 features=np.zeros((n,6),np.float32)
 for i,row in enumerate(rows):
  if row[1] in 'ACGT':features[i,'ACGT'.index(row[1])]=1
 deg=np.zeros(n)
 for i,j in back:deg[i]+=1
 features[:,4]=deg<2;features[:,5]=deg/2
 mp=json.loads(mapping.read_text())['mapping'];assert len(mp)==n;vh=np.array([m['virtual_helix'] for m in mp]);ax=np.array([m['axial_index'] for m in mp]);domain_raw=[(m['virtual_helix'],m['axial_index']//16) for m in mp];lut={k:i for i,k in enumerate(sorted(set(domain_raw)))};domain=np.array([lut[k] for k in domain_raw],dtype=np.int64)
 edge={}
 for i,j in back:edge[i,j]=3 if vh[i]!=vh[j] else 1
 for i,j in bp:edge[int(i),int(j)]=2;edge[int(j),int(i)]=2
 for i,j in back:
  for k in map(int,rows[j][2:4]):
   if k>=0 and k!=i and (i,k) not in edge:edge[i,k]=4
 dd,ii=cKDTree(xyz).query(xyz,k=9)
 for i in range(n):
  for dist,j in zip(dd[i,1:],ii[i,1:]):
   if dist<3 and (i,int(j)) not in edge:edge[i,int(j)]=0
 keys=sorted(edge);ei=np.array(keys,dtype=np.int64).T;et=np.array([edge[k] for k in keys],dtype=np.int64);i,j=ei;v=x[j]-x[i];distance=np.linalg.norm(v,axis=1);onehot=np.eye(5)[et];length=distance[:,None]
 #20 documented source-only edge channels:5type,3vector,1distance,3a1dot,3a3dot,3a1crossdot,1same strand,1signed axial delta.
 ef=np.concatenate([onehot,v,length,rot[i,:,0]*rot[j,:,0],rot[i,:,2]*rot[j,:,2],rot[i,:,0]*rot[j,:,2],(strand[i]==strand[j])[:,None],((ax[j]-ax[i])/100.)[:,None]],axis=1).astype(np.float32);assert ef.shape[1]==20
 segedge=np.stack([domain[i],domain[j]]);idx=np.unique(segedge.T,axis=0,return_index=True)[1];segedge=segedge[:,idx];segfeatures=ef[idx]
 return dict(pos=x.astype(np.float32),rotation=rot.astype(np.float32),node_features=features,edge_index=ei,edge_types=et,edge_features=ef,domain_ids=domain,segment_edge_index=segedge,segment_edge_features=segfeatures,backbone_edges=np.array(sorted(back),np.int64).T,base_pairs=bp.T,center=center,scale=np.array(SCALE),strand=strand,box=np.fromstring(initial.read_text().splitlines()[1].split('=')[1],sep=' '))
def main():
 DATA.mkdir(parents=True,exist_ok=True);(DATA/'inputs').mkdir(exist_ok=True);(DATA/'labels').mkdir(exist_ok=True);(DATA/'designs').mkdir(exist_ok=True)
 results=json.loads((ROOT/'outputs/talos97_triplicate_analysis_20261028/batch_summary.json').read_text())['results'];rows=[]
 with zipfile.ZipFile(ROOT/'DNA_6HB_100_designs.zip') as z:
  for result in results:
   d=result['design_id'];w=DATA/'designs'/d;w.mkdir(exist_ok=True);run=ROOT/'outputs/talos100_triplicate_mixed_20261024'/d/'replica_1';mean=ROOT/'outputs/talos97_triplicate_analysis_20261028'/d/'replica_1_mean.conf';mapping=ROOT/'outputs/talos100_ensemble_pilot_20261021/input_audit'/(d+'_topology_to_cadnano.json')
   for src,name in [(run/'design.top','design.top'),(run/'initial.dat','initial.dat'),mean and (mean,'target_replica1_mean.conf'),(mapping,'topology_to_cadnano.json')]:
    shutil.copy2(src,w/name)
   (w/'designed_pairs.txt').write_bytes(z.read('dna_6hb_100/structures/'+d+'/designed_pairs.txt'))
   inp=preprocess(w/'design.top',w/'initial.dat',w/'designed_pairs.txt',w/'topology_to_cadnano.json');target=np.loadtxt(w/'target_replica1_mean.conf',skiprows=3);assert target.shape==(len(inp['pos']),15) and np.isfinite(target).all()
   x=inp['pos'].astype(float)*SCALE+inp['center'];a=target[:,:3]-target[:,:3].mean(0);b=x-x.mean(0);u,_,vt=np.linalg.svd(a.T@b);fix=np.eye(3);fix[-1,-1]=np.linalg.det(u@vt);R=u@fix@vt;y=(a@R+x.mean(0)-inp['center'])/SCALE;rt=np.einsum('ij,njk->nik',R.T,rotation(target))
   np.savez_compressed(DATA/'inputs'/(d+'.npz'),**inp);np.savez_compressed(DATA/'labels'/(d+'.npz'),target_pos=y.astype(np.float32),target_rotation=rt.astype(np.float32))
   rows.append(dict(design_id=d,nucleotides=len(x),strands=len(np.unique(inp['strand'])),source=str(run),target_replica=1,target_kind='production_time_average_1000frames',files={name:sha(w/name) for name in ['design.top','initial.dat','target_replica1_mean.conf','designed_pairs.txt','topology_to_cadnano.json']},input_cache_sha256=sha(DATA/'inputs'/(d+'.npz')),label_cache_sha256=sha(DATA/'labels'/(d+'.npz')),identity_rmsd_nm=float(np.sqrt(np.mean(np.sum((inp['pos']-y)**2,axis=1)))*SCALE*.8518)))
   print('built',d,len(x),flush=True)
 rng=np.random.default_rng(20261028);ordered=sorted(rows,key=lambda r:r['nucleotides']);splits={'train':[],'validation':[],'test':[]}
 # Five size strata, exact68/14/15 split, each random within stratum.
 for k,ids in enumerate(np.array_split(np.arange(97),5)):
  ids=rng.permutation(ids);nv=3 if k<4 else 2;nt=3
  for name,part in [('validation',ids[:nv]),('test',ids[nv:nv+nt]),('train',ids[nv+nt:])]:splits[name]+=[ordered[int(i)]['design_id'] for i in part]
 assert [len(splits[k]) for k in ['train','validation','test']]==[68,14,15];assert len(set(sum(splits.values(),[])))==97
 (DATA/'manifest.json').write_text(json.dumps(dict(schema='talos97.initial_to_replica1_mean.v1',seed=20261028,scale=SCALE,length_unit_nm=.8518,rows=rows),indent=2));(DATA/'split.json').write_text(json.dumps(splits,indent=2))
 (DATA/'README.md').write_text('# TALOS97 endpoint dataset v1\n\n97designs; input initial.dat t0 before first oxDNA minimization. Target replica1 empirical production mean (not lastframe). Source-only inputs NPZ and supervision labels NPZ are separate. 68train/14validation/15test,seed20261028,size stratified,not shape-held-out. Allrows retained,no trajectories copied. Rebuild:python experiments/talos97_endpoint_v1/scripts/build_dataset.py.\n\nEdge20channels:type5,relative normalized vector3,distance1,componentwise a1*a1(3),a3*a3(3),a1*a3(3),same strand1,axial delta/100(1). Frame vectors are in fixed initial chart; only PaiNN vector backbone has explicitly equivariant readout.\n')
 print('DONE', {k:len(v) for k,v in splits.items()},flush=True)
if __name__=='__main__':main()
