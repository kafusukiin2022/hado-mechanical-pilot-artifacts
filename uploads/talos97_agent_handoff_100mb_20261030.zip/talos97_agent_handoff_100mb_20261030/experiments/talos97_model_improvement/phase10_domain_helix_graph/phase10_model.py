"""Input-only typed coarse domain graph over the frozen local-frame basis model."""
from __future__ import annotations
import math
import torch
from torch import nn
from base_utils import segment_mean, so3_exp, NM, WIDTH


def polar_frame(rotations: torch.Tensor, domain_index: torch.Tensor, count: int) -> torch.Tensor:
    mean = segment_mean(rotations, domain_index, count)
    u, _, vh = torch.linalg.svd(mean)
    fix = torch.eye(3, dtype=mean.dtype, device=mean.device).expand_as(mean).clone()
    det = torch.linalg.det(u @ vh)
    fix[..., -1, -1] = torch.where(det < 0, -torch.ones_like(det), torch.ones_like(det))
    return u @ fix @ vh


class EdgeMessage(nn.Module):
    def __init__(self, width: int, edge_dim: int):
        super().__init__()
        self.edge_mlp = nn.Sequential(nn.Linear(width * 2 + edge_dim, width), nn.SiLU(), nn.Linear(width, width))
        self.update = nn.Sequential(nn.LayerNorm(width * 4), nn.Linear(width * 4, width), nn.SiLU(), nn.Linear(width, width))

    def forward(self, h, edge_index, edge_features):
        src, dst = edge_index
        message = self.edge_mlp(torch.cat((h[src], h[dst], edge_features), dim=-1))
        aggregate = h.new_zeros(h.shape)
        aggregate.index_add_(0, dst, message)
        counts = h.new_zeros((h.shape[0], 1))
        counts.index_add_(0, dst, h.new_ones((len(dst), 1)))
        aggregate = aggregate / counts.clamp_min(1)
        context = torch.cat((h.mean(0), h.max(0).values), dim=-1).expand(h.shape[0], -1)
        updated = h + self.update(torch.cat((h, aggregate, context), dim=-1))
        return updated, message


class DomainHelixGraphBasisNet(nn.Module):
    EDGE_DIM = 13

    def __init__(self, base_model, width=128, layers=4):
        super().__init__()
        self.base = base_model
        self.width = width
        self.domain_input = nn.Sequential(nn.Linear(346 + 3, width), nn.SiLU(), nn.Linear(width, width))
        self.graph_layers = nn.ModuleList([EdgeMessage(width, self.EDGE_DIM) for _ in range(layers)])
        self.translation_head = nn.Sequential(nn.LayerNorm(width), nn.Linear(width, width), nn.SiLU(), nn.Linear(width, 16))
        self.rotation_head = nn.Sequential(nn.LayerNorm(width), nn.Linear(width, width), nn.SiLU(), nn.Linear(width, 16))
        self.coarse_gate = nn.Parameter(torch.zeros(()))

    def load_base_state(self, state):
        self.base.load_state_dict(state, strict=True)

    def _graph(self, h2, B, R, source_pos, domain_ids, edge_index, edge_attr):
        _, domain = torch.unique(domain_ids, sorted=True, return_inverse=True)
        count = int(domain.max().item()) + 1
        source_nm = (source_pos - source_pos.mean(0, keepdim=True)) * NM
        centroid = segment_mean(source_nm, domain, count)
        frame = polar_frame(R, domain, count)
        radius2 = segment_mean((source_nm - centroid[domain]).square().sum(-1, keepdim=True), domain, count)
        size = h2.new_zeros((count, 1))
        size.index_add_(0, domain, h2.new_ones((len(domain), 1)))
        domain_scalars = torch.cat((torch.log1p(size), radius2.clamp_min(0).sqrt(), torch.linalg.vector_norm(centroid, dim=-1, keepdim=True)), -1)
        state = self.domain_input(torch.cat((segment_mean(h2, domain, count), domain_scalars), -1))

        src, dst = edge_index
        edge_vector = centroid[dst] - centroid[src]
        edge_local = torch.einsum("ei,eij->ej", edge_vector, frame[src])
        distance = torch.linalg.vector_norm(edge_vector, dim=-1, keepdim=True)
        relative_frame_trace = torch.diagonal(frame[src].transpose(-1, -2) @ frame[dst], dim1=-2, dim2=-1).sum(-1, keepdim=True) / 3
        # Input cache channels: 0:5 typed relations; 8 distance; 18 same-strand; 19 axial offset.
        # Exclude cached laboratory-frame vector/tensor components (5:8, 9:18).
        invariant_cached = torch.cat((edge_attr[:, :5], edge_attr[:, 8:9], edge_attr[:, 18:20]), -1)
        edge_features = torch.cat((invariant_cached, edge_local, distance, relative_frame_trace), -1)
        messages = None
        for layer in self.graph_layers:
            state, messages = layer(state, edge_index, edge_features)

        pooled_basis = segment_mean(B, domain, count)
        frame_axes = frame.transpose(-1, -2)
        fallback = frame_axes.repeat(1, math.ceil(pooled_basis.shape[1] / 3), 1)[:, :pooled_basis.shape[1]]
        basis_norm = torch.linalg.vector_norm(pooled_basis, dim=-1, keepdim=True)
        basis = torch.where(basis_norm > 1e-6, pooled_basis, fallback)
        unit_basis = basis / torch.linalg.vector_norm(basis, dim=-1, keepdim=True).clamp_min(1e-6)
        scale = math.sqrt(unit_basis.shape[1])
        translation = 4.0 / scale * torch.einsum("dk,dka->da", torch.tanh(self.translation_head(state)), unit_basis)
        translation = translation * torch.clamp(8.0 / torch.linalg.vector_norm(translation, dim=-1, keepdim=True).clamp_min(1e-8), max=1.0)
        omega = 0.5 / scale * torch.einsum("dk,dka->da", torch.tanh(self.rotation_head(state)), unit_basis)
        rotation = so3_exp(omega)
        relative = source_nm - centroid[domain]
        moved = torch.einsum("nij,nj->ni", rotation[domain], relative) + centroid[domain] + translation[domain]
        return {
            "domain": domain, "centroid_nm": centroid, "frame": frame, "state": state,
            "messages": messages, "edge_features": edge_features, "translation_nm": translation,
            "omega": omega, "rotation": rotation, "coarse_delta_nm": moved - source_nm,
        }

    def forward_details(self, s, B, R, source_pos, domain_ids, edge_index, edge_attr):
        layers, h = self.base.encode(s)
        h2 = layers[-1]
        local_delta = self.base.readout(h, B, R)[0]
        coarse = self._graph(h2, B, R, source_pos, domain_ids, edge_index, edge_attr)
        gate = torch.tanh(self.coarse_gate)
        delta = local_delta + gate * coarse["coarse_delta_nm"]
        delta = delta - delta.mean(0, keepdim=True)
        coarse.update({"local_delta_nm": local_delta, "delta_nm": delta, "gate": gate})
        return coarse

    def forward(self, s, B, R, source_pos, domain_ids, edge_index, edge_attr):
        return self.forward_details(s, B, R, source_pos, domain_ids, edge_index, edge_attr)["delta_nm"]
