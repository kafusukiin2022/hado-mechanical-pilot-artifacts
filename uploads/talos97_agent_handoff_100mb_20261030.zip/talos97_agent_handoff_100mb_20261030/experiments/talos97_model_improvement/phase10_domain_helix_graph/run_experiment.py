#!/usr/bin/env python3
"""Matched local-frame continuation with typed coarse domain-graph messages."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import random
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import scipy
import torch
from torch import nn


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE_DIR = ROOT / "experiments/talos97_localframe_2m"
sys.path.insert(0, str(BASE_DIR))
from model import BasisNet, geometry  # noqa: E402
from phase10_model import DomainHelixGraphBasisNet  # noqa: E402

DATA = ROOT / "experiments/talos97_endpoint_v1/data"
BASE_CHECKPOINTS = BASE_DIR / "checkpoints"
RUNS = HERE / "runs"
RESULTS = HERE / "results"
SEEDS = (11, 22, 33)
ARMS = ("control", "domain_helix_graph")
EPOCHS = 50
NM = 40.0 * 0.8518
WIDTH = 346
RESIDUAL_BLOCKS = 8
SOURCE_PATHS = (
    HERE / "SPEC.md",
    HERE / "EXPECTED_VERIFICATION.md",
    HERE / "run_experiment.py",
    HERE / "verify_results.py",
    HERE / "phase10_model.py",
    HERE / "base_utils.py",
    BASE_DIR / "model.py",
    BASE_DIR / "run_full97.py",
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def read_json_string(stream) -> str:
    first = stream.read(1)
    if first != '"':
        raise ValueError(f"expected JSON string, got {first!r}")
    chars = [first]
    escaped = False
    while True:
        char = stream.read(1)
        if not char:
            raise ValueError("truncated JSON string")
        chars.append(char)
        if escaped:
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == '"':
            return json.loads("".join(chars))


def read_id_list(stream) -> list[str]:
    while True:
        char = stream.read(1)
        if not char:
            raise ValueError("truncated split before ID list")
        if not char.isspace():
            break
    if char != "[":
        raise ValueError(f"expected ID array, got {char!r}")
    ids: list[str] = []
    while True:
        char = stream.read(1)
        while char and char.isspace():
            char = stream.read(1)
        if char == "]":
            return ids
        if char != '"':
            raise ValueError(f"expected ID string or array end, got {char!r}")
        # read_json_string expects the opening quote, which has already been consumed.
        chars = ['"']
        escaped = False
        while True:
            item = stream.read(1)
            if not item:
                raise ValueError("truncated ID string")
            chars.append(item)
            if escaped:
                escaped = False
            elif item == "\\":
                escaped = True
            elif item == '"':
                ids.append(json.loads("".join(chars)))
                break
        while True:
            delimiter = stream.read(1)
            if not delimiter:
                raise ValueError("truncated ID array")
            if not delimiter.isspace():
                break
        if delimiter == "]":
            return ids
        if delimiter != ",":
            raise ValueError(f"expected comma or array end, got {delimiter!r}")


def read_train_validation_ids(split_path: Path) -> tuple[list[str], list[str]]:
    """Decode only train and validation arrays; stop before reading test IDs."""
    with split_path.open("r", encoding="utf-8") as stream:
        while (char := stream.read(1)) and char.isspace():
            pass
        if char != "{":
            raise ValueError("split root must be an object")
        key = read_json_string_after_quote(stream)
        if key != "train":
            raise ValueError(f"expected train first in split, found {key!r}")
        expect_colon(stream)
        train_ids = read_id_list(stream)
        expect_comma(stream)
        key = read_json_string_after_quote(stream)
        if key != "validation":
            raise ValueError(f"expected validation second in split, found {key!r}")
        expect_colon(stream)
        validation_ids = read_id_list(stream)
        # Return immediately after the validation array's closing bracket.
        return train_ids, validation_ids


def read_json_string_after_quote(stream) -> str:
    while (leading := stream.read(1)) and leading.isspace():
        pass
    if leading != '"':
        raise ValueError(f"expected quoted JSON key, got {leading!r}")
    chars = ['"']
    escaped = False
    while True:
        item = stream.read(1)
        if not item:
            raise ValueError("truncated split key")
        chars.append(item)
        if escaped:
            escaped = False
        elif item == "\\":
            escaped = True
        elif item == '"':
            return json.loads("".join(chars))


def expect_colon(stream) -> None:
    while (char := stream.read(1)) and char.isspace():
        pass
    if char != ":":
        raise ValueError(f"expected colon, got {char!r}")


def expect_comma(stream) -> None:
    while (char := stream.read(1)) and char.isspace():
        pass
    if char != ",":
        raise ValueError(f"expected comma after split array, got {char!r}")


def segment_mean(values: torch.Tensor, index: torch.Tensor, count: int) -> torch.Tensor:
    result = values.new_zeros((count,) + values.shape[1:])
    result.index_add_(0, index, values)
    sizes = values.new_zeros((count,))
    sizes.index_add_(0, index, values.new_ones((len(index),)))
    shape = (count,) + (1,) * (values.ndim - 1)
    return result / sizes.clamp_min(1).reshape(shape)


def so3_exp(omega: torch.Tensor) -> torch.Tensor:
    """Stable Rodrigues exponential, with omega as an axis-angle vector."""
    x, y, z = omega.unbind(-1)
    zero = torch.zeros_like(x)
    skew = torch.stack((
        torch.stack((zero, -z, y), dim=-1),
        torch.stack((z, zero, -x), dim=-1),
        torch.stack((-y, x, zero), dim=-1),
    ), dim=-2)
    theta2 = (omega * omega).sum(-1, keepdim=True)
    theta = torch.sqrt(theta2.clamp_min(1e-16))
    a_exact = torch.sin(theta) / theta
    b_exact = (1.0 - torch.cos(theta)) / theta2.clamp_min(1e-16)
    a_series = 1.0 - theta2 / 6.0 + theta2 * theta2 / 120.0
    b_series = 0.5 - theta2 / 24.0 + theta2 * theta2 / 720.0
    small = theta2 < 1e-8
    a = torch.where(small, a_series, a_exact)[..., None]
    b = torch.where(small, b_series, b_exact)[..., None]
    identity = torch.eye(3, dtype=omega.dtype, device=omega.device).expand(omega.shape[:-1] + (3, 3))
    return identity + a * skew + b * (skew @ skew)


def load_checkpoint(seed: int, device: torch.device) -> dict[str, Any]:
    path = BASE_CHECKPOINTS / f"frame_{seed}.pt"
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    if checkpoint.get("variant") != "frame" or checkpoint.get("seed") != seed:
        raise ValueError(f"unexpected frozen checkpoint metadata in {path}")
    return checkpoint


def make_model(seed: int, arm: str, device: torch.device) -> BasisNet:
    checkpoint = load_checkpoint(seed, device)
    state = checkpoint["state"]
    if arm == "control":
        model = BasisNet(state["mean"], state["std"], k=checkpoint["k"], width=WIDTH, variant="frame")
        model.load_state_dict(state, strict=True)
    elif arm == "domain_helix_graph":
        base = BasisNet(state["mean"], state["std"], k=checkpoint["k"], width=WIDTH, variant="frame")
        base.load_state_dict(state, strict=True)
        model = DomainHelixGraphBasisNet(base, width=128, layers=4)
        model.load_base_state(state)
    else:
        raise ValueError(arm)
    return model.to(device)


def load_design(ident: str, device: torch.device, with_label: bool) -> dict[str, torch.Tensor]:
    input_path = DATA / "inputs" / f"{ident}.npz"
    with np.load(input_path) as archive:
        raw = {key: np.asarray(archive[key]) for key in archive.files}
    s, B, R = geometry(raw, multiscale=True)
    arrays = {
        "s": torch.as_tensor(s, device=device),
        "B": torch.as_tensor(B, device=device),
        "R": torch.as_tensor(R, device=device),
        "source_pos": torch.as_tensor(raw["pos"], device=device),
        "domain_ids": torch.as_tensor(raw["domain_ids"], dtype=torch.long, device=device),
        "segment_edge_index": torch.as_tensor(raw["segment_edge_index"], dtype=torch.long, device=device),
        "segment_edge_features": torch.as_tensor(raw["segment_edge_features"], dtype=torch.float32, device=device),
    }
    if with_label:
        label_path = DATA / "labels" / f"{ident}.npz"
        with np.load(label_path) as archive:
            target_pos = np.asarray(archive["target_pos"], dtype=np.float32)
        arrays["target_delta_nm"] = torch.as_tensor(
            (target_pos - raw["pos"]) * NM, device=device
        )
    return arrays


def predict(model, d):
    if isinstance(model, DomainHelixGraphBasisNet):
        return model(d["s"], d["B"], d["R"], d["source_pos"], d["domain_ids"], d["segment_edge_index"], d["segment_edge_features"])
    return model(d["s"], d["B"], d["R"])


def evaluate(model, designs: dict[str, dict[str, torch.Tensor]], ids: list[str]) -> tuple[float, dict[str, float], dict[str, np.ndarray]]:
    model.eval()
    metrics: dict[str, float] = {}
    predictions: dict[str, np.ndarray] = {}
    with torch.no_grad():
        for ident in ids:
            d = designs[ident]
            predicted_delta = predict(model, d)
            error = predicted_delta - d["target_delta_nm"]
            metrics[ident] = float(torch.sqrt(torch.mean(torch.sum(error.square(), dim=-1))).item())
            predictions[ident] = predicted_delta.detach().cpu().numpy().astype(np.float32)
    return float(np.mean(list(metrics.values()))), metrics, predictions


def data_ids_and_hashes(train_ids: list[str], validation_ids: list[str]) -> dict[str, Any]:
    protected_data = {
        str(path.resolve()): sha256(path)
        for ident in train_ids + validation_ids
        for path in (DATA / "inputs" / f"{ident}.npz", DATA / "labels" / f"{ident}.npz")
    }
    return {
        "split_sha256": sha256(DATA / "split.json"),
        "manifest_sha256": sha256(DATA / "manifest.json"),
        "selected_design_data_sha256": protected_data,
        "frozen_checkpoint_sha256": {
            str(seed): sha256(BASE_CHECKPOINTS / f"frame_{seed}.pt") for seed in SEEDS
        },
        "source_sha256": {str(path.resolve()): sha256(path) for path in SOURCE_PATHS},
    }


def relabel_domains(raw: dict[str, np.ndarray], seed: int = 941) -> dict[str, np.ndarray]:
    result = dict(raw)
    old_values, old_compact = np.unique(raw["domain_ids"], return_inverse=True)
    rng = np.random.default_rng(seed)
    new_labels = rng.permutation(len(old_values)) * 13 + 7
    result["domain_ids"] = new_labels[old_compact]
    # segment_edge_index is indexed by the sorted compact domain order.
    old_order = np.argsort(new_labels)
    old_to_new_rank = np.empty(len(old_values), dtype=np.int64)
    old_to_new_rank[old_order] = np.arange(len(old_values))
    result["segment_edge_index"] = old_to_new_rank[raw["segment_edge_index"]]
    return result


def build_raw(ident: str) -> dict[str, np.ndarray]:
    with np.load(DATA / "inputs" / f"{ident}.npz") as archive:
        return {key: np.asarray(archive[key]) for key in archive.files}


def preflight(seed: int, train_ids: list[str], validation_ids: list[str], device: torch.device) -> dict[str, Any]:
    base_hashes_before = {str((BASE_CHECKPOINTS / f"frame_{s}.pt").resolve()): sha256(BASE_CHECKPOINTS / f"frame_{s}.pt") for s in SEEDS}
    checkpoint = load_checkpoint(seed, device)
    base = make_model(seed, "control", device).eval()
    candidate = make_model(seed, "domain_helix_graph", device).eval()

    # Verify exact zero-gate equivalence on all fixed validation designs.
    validation_designs = {ident: load_design(ident, device, with_label=True) for ident in validation_ids}
    max_zero_gate_difference_nm = 0.0
    with torch.no_grad():
        for ident in validation_ids:
            d = validation_designs[ident]
            y_base = base(d["s"], d["B"], d["R"])
            y_candidate = predict(candidate, d)
            max_zero_gate_difference_nm = max(
                max_zero_gate_difference_nm,
                float(torch.linalg.vector_norm(y_base - y_candidate, dim=-1).max().item()),
            )

    # Rotation equivariance and domain-label permutation use a train design only.
    ident = train_ids[0]
    raw = build_raw(ident)
    s, B, R = geometry(raw, multiscale=True)
    sample = {
        "s": torch.as_tensor(s, device=device),
        "B": torch.as_tensor(B, device=device),
        "R": torch.as_tensor(R, device=device),
        "source_pos": torch.as_tensor(raw["pos"], device=device),
        "domain_ids": torch.as_tensor(raw["domain_ids"], dtype=torch.long, device=device),
        "segment_edge_index": torch.as_tensor(raw["segment_edge_index"], dtype=torch.long, device=device),
        "segment_edge_features": torch.as_tensor(raw["segment_edge_features"], dtype=torch.float32, device=device),
    }
    Q = torch.tensor([[0.0, -1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]], device=device)
    rotated_raw = dict(raw)
    rotated_raw["pos"] = raw["pos"] @ Q.detach().cpu().numpy().T
    rotated_raw["rotation"] = np.einsum("ij,njk->nik", Q.detach().cpu().numpy(), raw["rotation"])
    rotated_raw["segment_edge_index"] = raw["segment_edge_index"]
    rotated_raw["segment_edge_features"] = raw["segment_edge_features"]
    sr, Br, Rr = geometry(rotated_raw, multiscale=True)
    with torch.no_grad():
        pred = predict(candidate, sample)
        pred_rotated = candidate(
            torch.as_tensor(sr, device=device), torch.as_tensor(Br, device=device),
            torch.as_tensor(Rr, device=device),
            torch.as_tensor(rotated_raw["pos"], device=device), sample["domain_ids"],
            sample["segment_edge_index"], sample["segment_edge_features"],
        )
        equivariance_error = torch.linalg.vector_norm(pred_rotated - pred @ Q.T, dim=-1).max()
        relabeled_raw = relabel_domains(raw)
        sl, Bl, Rl = geometry(relabeled_raw, multiscale=True)
        pred_relabelled = candidate(
            torch.as_tensor(sl, device=device), torch.as_tensor(Bl, device=device),
            torch.as_tensor(Rl, device=device), sample["source_pos"],
            torch.as_tensor(relabeled_raw["domain_ids"], dtype=torch.long, device=device),
            torch.as_tensor(relabeled_raw["segment_edge_index"], dtype=torch.long, device=device),
            sample["segment_edge_features"],
        )
        relabel_error = torch.linalg.vector_norm(pred_relabelled - pred, dim=-1).max()

        details = candidate.forward_details(
            sample["s"], sample["B"], sample["R"], sample["source_pos"], sample["domain_ids"],
            sample["segment_edge_index"], sample["segment_edge_features"]
        )
        rewired_edge_index = sample["segment_edge_index"].clone()
        if rewired_edge_index.shape[1] < 2:
            raise ValueError("train preflight design has too few coarse edges to test message sensitivity")
        rewired_edge_index[1] = torch.roll(rewired_edge_index[1], shifts=1, dims=0)
        rewired = candidate.forward_details(
            sample["s"], sample["B"], sample["R"], sample["source_pos"], sample["domain_ids"],
            rewired_edge_index, sample["segment_edge_features"]
        )
        graph_rewire_message_difference = float((details["messages"] - rewired["messages"]).abs().max().item())
        det = torch.linalg.det(details["rotation"])
        orthogonal_error = (details["rotation"].transpose(-1, -2) @ details["rotation"]
                            - torch.eye(3, device=device)).abs().max()
        source_nm = (sample["source_pos"] - sample["source_pos"].mean(0, keepdim=True)) * NM
        domain_index = details["domain"]
        pair_distance_error = 0.0
        # For every domain, check a deterministic subset of at most 12 nodes.
        for domain in range(int(domain_index.max().item()) + 1):
            index = torch.nonzero(domain_index == domain, as_tuple=True)[0][:12]
            if len(index) < 2:
                continue
            before = torch.cdist(source_nm[index], source_nm[index])
            centroid = source_nm[index].mean(0)
            transformed = torch.einsum("ij,nj->ni", details["rotation"][domain], source_nm[index] - centroid)
            after = torch.cdist(transformed, transformed)
            pair_distance_error = max(pair_distance_error, float((before - after).abs().max().item()))

    # Small/singleton domains must remain well-defined.
    tiny_ids = torch.tensor([41, 41, 99], device=device)
    tiny_omega = torch.tensor([[0.0, 0.0, 0.0], [0.1, -0.2, 0.05]], device=device)
    tiny_rotation = so3_exp(tiny_omega)
    tiny_determinants = torch.linalg.det(tiny_rotation)

    # Disposable open-gate gradient probe with a train label; performs no optimizer step.
    probe = make_model(seed, "domain_helix_graph", device).train()
    with torch.no_grad():
        probe.coarse_gate.fill_(0.1)
    train_design = load_design(ident, device, with_label=True)
    output_open = probe.forward_details(
        train_design["s"], train_design["B"], train_design["R"],
        train_design["source_pos"], train_design["domain_ids"],
        train_design["segment_edge_index"], train_design["segment_edge_features"],
    )
    loss = torch.mean((output_open["delta_nm"] - train_design["target_delta_nm"]).square())
    loss.backward()
    gradient_sums = {
        "coarse_gate": float(probe.coarse_gate.grad.abs().sum().item()) if probe.coarse_gate.grad is not None else 0.0,
        "edge_mlp": float(sum(p.grad.abs().sum().item() for layer in probe.graph_layers for p in layer.edge_mlp.parameters() if p.grad is not None)),
        "translation_head": float(sum(p.grad.abs().sum().item() for p in probe.translation_head.parameters() if p.grad is not None)),
        "rotation_head": float(sum(p.grad.abs().sum().item() for p in probe.rotation_head.parameters() if p.grad is not None)),
    }
    with torch.no_grad():
        probe.coarse_gate.zero_()
        closed = predict(probe, train_design)
        probe.coarse_gate.fill_(0.1)
        opened = predict(probe, train_design)
        open_gate_prediction_difference_nm = float(torch.linalg.vector_norm(opened - closed, dim=-1).max().item())

    max_checkpoint_hash_after = {path: sha256(Path(path)) for path in base_hashes_before}
    checks = {
        "zero_gate_matches_base_under_1e_5_nm": max_zero_gate_difference_nm < 1e-5,
        "proper_rotation_determinants": bool(torch.isfinite(det).all() and (det - 1).abs().max() < 1e-5 and orthogonal_error < 1e-5),
        "domain_graph_transform_preserves_sampled_pair_distances": pair_distance_error < 1e-4,
        "small_domain_so3_is_finite_and_proper": bool(torch.isfinite(tiny_rotation).all() and (tiny_determinants - 1).abs().max() < 1e-5),
        "global_rotation_equivariance": float(equivariance_error.item()) < 2e-4,
        "domain_relabel_invariance": float(relabel_error.item()) < 1e-5,
        "graph_edge_rewiring_changes_messages": graph_rewire_message_difference > 1e-7,
        "open_gate_changes_prediction": open_gate_prediction_difference_nm > 1e-6,
        "gate_graph_and_both_heads_receive_nonzero_finite_gradients": all(np.isfinite(v) and v > 0 for v in gradient_sums.values()),
        "base_checkpoints_unchanged": base_hashes_before == max_checkpoint_hash_after,
        "optimizer_steps": 0,
        "test_ids_not_loaded": True,
        "test_labels_not_opened": True,
    }
    result = {
        "passed": all(v for k, v in checks.items() if isinstance(v, bool)),
        "checks": checks,
        "seed": seed,
        "training_probe_design": ident,
        "validation_ids": validation_ids,
        "max_zero_gate_difference_nm": max_zero_gate_difference_nm,
        "global_rotation_equivariance_max_error_nm": float(equivariance_error.item()),
        "domain_relabel_max_difference_nm": float(relabel_error.item()),
        "graph_edge_rewire_max_message_difference": graph_rewire_message_difference,
        "rotation_det_min": float(det.min().item()),
        "rotation_det_max": float(det.max().item()),
        "rotation_orthogonality_max_error": float(orthogonal_error.item()),
        "sampled_pair_distance_max_error_nm": pair_distance_error,
        "small_domain_rotation_determinants": tiny_determinants.detach().cpu().tolist(),
        "open_gate_prediction_difference_nm": open_gate_prediction_difference_nm,
        "gradient_abs_sums": gradient_sums,
        "base_checkpoint_sha256_before": base_hashes_before,
        "base_checkpoint_sha256_after": max_checkpoint_hash_after,
        "optimizer_steps": 0,
        "test_ids_loaded": False,
        "test_labels_opened": False,
        "test_prediction_keys_read": False,
    }
    return result


def run_arm(seed: int, arm: str, train_ids: list[str], validation_ids: list[str], designs: dict[str, dict[str, torch.Tensor]], device: torch.device) -> dict[str, Any]:
    arm_seed = seed if arm == "control" else seed + 8000
    random.seed(arm_seed)
    np.random.seed(arm_seed)
    torch.manual_seed(arm_seed)
    torch.cuda.manual_seed_all(arm_seed)
    model = make_model(seed, arm, device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    rng = np.random.default_rng(seed)
    run_dir = RUNS / f"seed{seed}_{arm}"
    run_dir.mkdir(parents=True, exist_ok=True)
    history_path = run_dir / "history.jsonl"
    if history_path.exists():
        raise FileExistsError(f"refusing to overwrite existing run {run_dir}")

    best_score = float("inf")
    best_epoch = -1
    best_state = None
    best_metrics: dict[str, float] = {}
    best_predictions: dict[str, np.ndarray] = {}
    t0 = time.time()

    def evaluate_epoch(epoch: int, branch_grad: dict[str, float]) -> None:
        nonlocal best_score, best_epoch, best_state, best_metrics, best_predictions
        score, metrics, predictions = evaluate(model, designs, validation_ids)
        row = {
            "seed": seed,
            "arm": arm,
            "epoch": epoch,
            "validation_macro_rmsd_nm": score,
            "best_validation_macro_rmsd_nm": min(best_score, score),
            "branch_gradient_abs_mean": branch_grad,
        }
        with history_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row) + "\n")
        if score < best_score:
            best_score = score
            best_epoch = epoch
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            best_metrics = metrics
            best_predictions = predictions

    model.eval()
    evaluate_epoch(0, {"coarse_gate": 0.0, "edge_mlp": 0.0, "translation_head": 0.0, "rotation_head": 0.0})
    for epoch in range(1, EPOCHS + 1):
        model.train()
        grad_values = {"coarse_gate": [], "edge_mlp": [], "translation_head": [], "rotation_head": []}
        losses = []
        epoch_order = [str(value) for value in rng.permutation(train_ids)]
        order_hash = hashlib.sha256("\n".join(epoch_order).encode()).hexdigest()
        for ident in epoch_order:
            d = designs[str(ident)]
            optimizer.zero_grad(set_to_none=True)
            predicted = predict(model, d)
            loss = torch.mean((predicted - d["target_delta_nm"]).square())
            if not torch.isfinite(loss):
                raise FloatingPointError(f"non-finite loss in seed={seed} arm={arm} epoch={epoch} design={ident}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            if isinstance(model, DomainHelixGraphBasisNet):
                grad_values["coarse_gate"].append(float(model.coarse_gate.grad.abs().sum().item()) if model.coarse_gate.grad is not None else 0.0)
                grad_values["edge_mlp"].append(float(sum(p.grad.abs().sum().item() for layer in model.graph_layers for p in layer.edge_mlp.parameters() if p.grad is not None)))
                for name, head in (("translation_head", model.translation_head), ("rotation_head", model.rotation_head)):
                    grad_values[name].append(float(sum(p.grad.abs().sum().item() for p in head.parameters() if p.grad is not None)))
            optimizer.step()
            losses.append(float(loss.detach().item()))
        grad_mean = {key: float(np.mean(values)) if values else 0.0 for key, values in grad_values.items()}
        evaluate_epoch(epoch, {**grad_mean, "train_mse_nm2": float(np.mean(losses)), "train_order_sha256": order_hash})
        atomic_json(run_dir / "status.json", {
            "seed": seed, "arm": arm, "epoch": epoch, "epochs_total": EPOCHS,
            "best_epoch": best_epoch, "best_validation_macro_rmsd_nm": best_score,
            "elapsed_seconds": time.time() - t0,
        })
        if epoch == 1 or epoch % 10 == 0 or epoch == EPOCHS:
            print(f"{arm} seed={seed} epoch={epoch} val={row_score(history_path):.6f} best={best_score:.6f} grad={grad_mean}", flush=True)

    if best_state is None or best_epoch < 0:
        raise RuntimeError("no selected checkpoint")
    checkpoint_path = run_dir / "best.pt"
    torch.save({
        "state": best_state,
        "seed": seed,
        "arm": arm,
        "best_epoch": best_epoch,
        "best_validation_macro_rmsd_nm": best_score,
    }, checkpoint_path)
    prediction_path = run_dir / "validation_predictions.npz"
    np.savez_compressed(prediction_path, **best_predictions)
    with (run_dir / "per_design_validation.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=("seed", "arm", "epoch", "design", "rmsd_nm"))
        writer.writeheader()
        for ident in validation_ids:
            writer.writerow({"seed": seed, "arm": arm, "epoch": best_epoch, "design": ident, "rmsd_nm": best_metrics[ident]})
    atomic_json(run_dir / "status.json", {
        "seed": seed, "arm": arm, "epoch": EPOCHS, "epochs_total": EPOCHS,
        "best_epoch": best_epoch, "best_validation_macro_rmsd_nm": best_score,
        "elapsed_seconds": time.time() - t0, "complete": True,
        "best_checkpoint_sha256": sha256(checkpoint_path),
        "validation_prediction_sha256": sha256(prediction_path),
    })
    return {
        "seed": seed,
        "arm": arm,
        "best_epoch": best_epoch,
        "best_validation_macro_rmsd_nm": best_score,
        "best_checkpoint_sha256": sha256(checkpoint_path),
        "validation_prediction_sha256": sha256(prediction_path),
        "elapsed_seconds": time.time() - t0,
        "per_design_validation": best_metrics,
        "final_history_row": json.loads(history_path.read_text().splitlines()[-1]),
    }


def row_score(path: Path) -> float:
    return float(json.loads(path.read_text().splitlines()[-1])["validation_macro_rmsd_nm"])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--device", default="cuda:2")
    parser.add_argument("--preflight-seed", type=int, default=11)
    args = parser.parse_args()
    torch.set_num_threads(2)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    if device.type == "cuda":
        print("DEVICE", torch.cuda.get_device_name(device), "CUDA", torch.version.cuda, flush=True)

    train_ids, validation_ids = read_train_validation_ids(DATA / "split.json")
    expected_validation_ids = json.loads((ROOT / "experiments/talos97_model_improvement/phase1_error_localization/results/summary.json").read_text())["validation_ids"]
    if len(train_ids) != 68 or len(validation_ids) != 14 or validation_ids != expected_validation_ids:
        raise ValueError("train/validation split does not match frozen 68/14 protocol")
    if len(set(train_ids + validation_ids)) != 82:
        raise ValueError("train and validation IDs must be unique and disjoint")

    RUNS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    hashes_before = data_ids_and_hashes(train_ids, validation_ids)
    preflight_result = preflight(args.preflight_seed, train_ids, validation_ids, device)
    atomic_json(RESULTS / "preflight.json", preflight_result)
    print("PREFLIGHT", json.dumps(preflight_result, ensure_ascii=False), flush=True)
    if not preflight_result["passed"]:
        raise RuntimeError("Phase 10 preflight failed; refusing to train")
    if args.preflight_only:
        return 0

    # Only the train and validation IDs decoded above are opened. The split
    # parser returned before reading the JSON test array.
    designs = {
        ident: load_design(ident, device, with_label=True)
        for ident in train_ids + validation_ids
    }
    outcomes = []
    for seed in SEEDS:
        for arm in ARMS:
            print(f"START seed={seed} arm={arm}", flush=True)
            outcomes.append(run_arm(seed, arm, train_ids, validation_ids, designs, device))
    hashes_after = data_ids_and_hashes(train_ids, validation_ids)
    summary = {
        "phase": "talos97_phase10_domain_helix_graph_v1",
        "train_ids": train_ids,
        "validation_ids": validation_ids,
        "train_design_count": len(train_ids),
        "validation_design_count": len(validation_ids),
        "test_ids_decoded": False,
        "test_input_files_opened": False,
        "test_label_files_opened": False,
        "test_prediction_keys_read": False,
        "test_inference": False,
        "model_inference_validation_only": True,
        "optimizer_steps": len(SEEDS) * len(ARMS) * EPOCHS * len(train_ids),
        "data_access_manifest": {
            "input_design_ids_opened": train_ids + validation_ids,
            "label_design_ids_opened": train_ids + validation_ids,
            "split_parser_stopped_after": "validation",
        },
        "device": str(device),
        "cuda_device_name": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "numpy_version": np.__version__,
        "scipy_version": scipy.__version__,
        "python_version": platform.python_version(),
        "epochs_per_arm": EPOCHS,
        "seeds": list(SEEDS),
        "arms": list(ARMS),
        "hashes_before": hashes_before,
        "hashes_after": hashes_after,
        "runs": outcomes,
        "original_checkpoints_modified": False,
    }
    atomic_json(RESULTS / "summary.json", summary)
    print("COMPLETE", json.dumps({
        "runs": [{"seed": row["seed"], "arm": row["arm"], "best_epoch": row["best_epoch"], "val": row["best_validation_macro_rmsd_nm"]} for row in outcomes],
        "test_ids_decoded": False,
        "optimizer_steps": summary["optimizer_steps"],
    }, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
