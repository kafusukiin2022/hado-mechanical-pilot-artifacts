import torch

NM = 40.0 * 0.8518
WIDTH = 346

def segment_mean(values, index, count):
    out = values.new_zeros((count,) + values.shape[1:])
    out.index_add_(0, index, values)
    sizes = values.new_zeros(count)
    sizes.index_add_(0, index, values.new_ones(len(index)))
    return out / sizes.clamp_min(1).reshape((count,) + (1,) * (values.ndim - 1))

def so3_exp(omega):
    x, y, z = omega.unbind(-1)
    zero = torch.zeros_like(x)
    skew = torch.stack((torch.stack((zero, -z, y), -1),
                        torch.stack((z, zero, -x), -1),
                        torch.stack((-y, x, zero), -1)), -2)
    theta2 = (omega * omega).sum(-1, keepdim=True)
    theta = torch.sqrt(theta2.clamp_min(1e-16))
    a = torch.where(theta2 < 1e-8, 1 - theta2 / 6 + theta2 * theta2 / 120,
                    torch.sin(theta) / theta)[..., None]
    b = torch.where(theta2 < 1e-8, .5 - theta2 / 24 + theta2 * theta2 / 720,
                    (1 - torch.cos(theta)) / theta2.clamp_min(1e-16))[..., None]
    identity = torch.eye(3, dtype=omega.dtype, device=omega.device).expand(omega.shape[:-1] + (3, 3))
    return identity + a * skew + b * (skew @ skew)
