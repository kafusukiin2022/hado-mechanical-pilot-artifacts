# OnePass 与 DGNN-lite：TALOS97 验证误差定位

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run + validate
- Origin Date: 2026-10-29
- Verification Status: VERIFIED
- Version Label: talos97_error_localization_v1

## 指标复现

仅用固定14个验证设计，从保存的 prediction.conf 重算官方 RMSD。OnePass=2.251087 nm；DGNN-lite=2.541945 nm。与 metrics.json 宏值的差异均不超过 1e-4 nm。未读取测试 split。

Identity 宏 RMSD=2.602642 nm；OnePass 在 14/14 个设计上改善，DGNN-lite 在 12/14 个设计上改善。

按设计配对的 OnePass-DGNN-lite 均值差为 -0.2909 nm，设计级 bootstrap 95% 区间 [-0.3404, -0.2388] nm。负值有利于 OnePass。区间按14个设计重采样，节点不作为独立样本。

## 误差最大的验证设计

|模型|设计|RMSD nm|Identity nm|相对 identity 改善 nm|P90 节点误差 nm|
|---|---|---:|---:|---:|---:|
|DGNN-lite|6hb_072|3.3929|3.4596|0.0667|5.2381|
|DGNN-lite|6hb_002|3.0594|3.0385|-0.0209|4.5912|
|OnePass|6hb_072|3.0428|3.4596|0.4168|4.6732|
|DGNN-lite|6hb_088|3.0342|3.1023|0.0681|4.5161|
|DGNN-lite|6hb_016|3.0330|3.1147|0.0816|4.3804|
|DGNN-lite|6hb_065|2.7652|2.8533|0.0881|4.0940|
|OnePass|6hb_016|2.7050|3.1147|0.4096|3.9707|
|OnePass|6hb_002|2.6704|3.0385|0.3681|4.0864|

## 节点运动幅度与残差

下表将 14 个验证设计的节点合并作描述性分层；节点不是独立实验单位。`target_progress` 是预测位移在目标位移方向上的投影除以目标位移平方，约 1 表示该投影幅度接近目标，负值表示方向相反。

|模型|目标位移|节点比例|节点误差 RMS nm|目标位移均值 nm|预测位移均值 nm|方向 cosine|target progress|平方误差占比|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|OnePass|<1nm|12.0%|1.257|0.704|1.078|0.187|0.334|3.6%|
|OnePass|1-2nm|33.2%|1.583|1.518|1.130|0.346|0.294|15.7%|
|OnePass|2-4nm|44.9%|2.391|2.809|1.278|0.545|0.275|48.5%|
|OnePass|>=4nm|9.9%|4.148|4.936|1.480|0.661|0.213|32.2%|
|DGNN-lite|<1nm|12.0%|0.820|0.704|0.420|0.097|0.067|1.2%|
|DGNN-lite|1-2nm|33.2%|1.528|1.518|0.431|0.193|0.055|11.6%|
|DGNN-lite|2-4nm|44.9%|2.774|2.809|0.431|0.293|0.044|51.6%|
|DGNN-lite|>=4nm|9.9%|4.907|4.936|0.438|0.303|0.026|35.6%|

描述性发现：OnePass 的 9.9% 节点目标位移至少 4 nm，这组节点占合并节点平方残差的约三分之一；预测位移均值仍明显小于目标位移均值。小于 1 nm 的节点则有轻度幅值过冲。DGNN-lite 各幅度组的预测位移几乎固定在 0.42–0.44 nm，显示其读出接近 identity。误差与目标位移幅度的关系本身使用了标签，只用于定位，不是推理期特征。

## Source-only error probe

- OnePass: macro design-held-out R²=-0.4146, macro MAE=0.8372 nm; pooled-node R²=-0.0212.
- DGNN-lite: macro design-held-out R²=-0.1885, macro MAE=0.9598 nm; pooled-node R²=-0.0045.

该 Ridge 是探索性 error probe：每折整设计留出，预测目标是节点残差幅度，特征只来自初始结构和模型推理输出。它不能证明模型内部因果机制，也不代表可直接用于推理的误差校正器。详细节点与分组统计见同目录 CSV。

## 证据边界与下一步

本阶段定位错误，不训练、不更新权重，也不使用测试集。若误差主要随位移幅度变化，下一阶段对 OnePass 做有界幅度/方向分离的验证集干预；若误差集中在域或配对上下文，再做对应输入/消息路径对照。Hidden-state probing、rsatoolbox、Captum 与 NNsight 干预留到误差模式明确后。任何候选仍须在原14个验证设计上重算宏 RMSD，并继续保留测试集。

原始证据与复现结果见 `per_design.csv`、`node_errors.csv`、`node_error_summary.csv`、`ridge_error_probe.csv` 和 `summary.json`。
