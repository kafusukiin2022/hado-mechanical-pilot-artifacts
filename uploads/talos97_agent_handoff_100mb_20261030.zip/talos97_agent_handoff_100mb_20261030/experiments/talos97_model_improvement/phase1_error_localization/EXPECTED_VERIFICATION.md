# Phase 1 expected verification (written before execution)

## Command

From the repository root, run:

```bash
../hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase1_error_localization/analyze_validation_errors.py
```

## Required pass conditions

1. Both frozen checkpoints, `split.json`, and `manifest.json` match the SHA-256 values recorded at the start of the run after analysis.
2. Exactly 14 frozen validation designs are analyzed for each model; no train or test prediction is loaded.
3. The script independently reconstructs the official validation macro RMSD from the stored validation predictions to absolute tolerance `1e-4 nm`:
   - OnePass `2.2510869588 nm`.
   - DGNN-lite `2.5419452276 nm`.
4. `per_design.csv` contains 28 model/design rows, with finite per-design RMSD and identity RMSD. Every row agrees with its matching stored `metrics.json` row to `1e-4 nm`.
5. `node_error_summary.csv` contains finite summaries over all validation nodes and supports the declared strata. Node-level observations are not treated as independent designs.
6. `ridge_error_probe.csv` records all 7 grouped folds for both models; each validation design is held out exactly once per model and no design overlaps between a fold's train and test groups. Report macro design-level held-out R²/MAE in addition to pooled node scores.
7. `summary.json` records counts, formulas, source hashes, baseline reproduction, bootstrap seed/resamples, and confirms `test_set_used: false` and `checkpoint_modified: false`.
8. `REPORT_ZH.md` distinguishes descriptive error localization from causal explanation, reports paired uncertainty at the design level, and names a next experiment only if a validation error pattern supports it.

## Failure handling

If scikit-learn is unavailable, stop and report the dependency instead of installing it or silently dropping the planned probe. If any baseline mismatch exceeds tolerance, a node count differs, a value is non-finite, or a hash changes, stop interpretation and report the failed condition. Do not repair checkpoints, adjust metrics, inspect test predictions, or start training in response to a failed diagnostic.
