#!/usr/bin/env python3
"""Localize frozen OnePass/DGNN-lite validation errors without inference or training."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import GroupKFold, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parents[3]
EXP = ROOT / "experiments/talos97_endpoint_v1"
RUNS = EXP / "runs"
DATA = EXP / "data"
OUT = Path(__file__).resolve().parent / "results"
MODELS = {"OnePass": "painn_onepass", "DGNN-lite": "dgnn_lite"}
SCALE_NM = 40.0 * 0.8518
BOOTSTRAP_SEED = 20261029
BOOTSTRAP_RESAMPLES = 10000


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_conf_positions(path: Path) -> np.ndarray:
    raw = np.loadtxt(path, skiprows=3)
    if raw.ndim != 2 or raw.shape[1] < 3:
        raise ValueError(f"invalid oxDNA conf coordinate table: {path}")
    return np.asarray(raw[:, :3], dtype=np.float64)


def score_nm(pred: np.ndarray, target: np.ndarray) -> float:
    return float(np.sqrt(np.square(pred - target).sum(axis=1).mean()) * SCALE_NM)


def quantile_bins(values: np.ndarray, count: int = 4) -> np.ndarray:
    order = np.argsort(np.argsort(values, kind="stable"), kind="stable")
    return np.minimum(order * count // max(len(values), 1), count - 1)


def group_rows(model: str, design: str, errors: np.ndarray, target_delta: np.ndarray,
               pred_delta: np.ndarray, degree: np.ndarray, domains: np.ndarray,
               has_pair: np.ndarray) -> list[dict]:
    target_mag = np.linalg.norm(target_delta, axis=1)
    pred_mag = np.linalg.norm(pred_delta, axis=1)
    denom = np.maximum(target_mag * pred_mag, 1e-12)
    cosine = np.sum(target_delta * pred_delta, axis=1) / denom
    progress = np.sum(target_delta * pred_delta, axis=1) / np.maximum(target_mag**2, 1e-12)
    groups: list[tuple[str, str, np.ndarray]] = [("all", "all", np.ones(len(errors), dtype=bool))]
    qbins = quantile_bins(degree)
    groups.extend(("degree_quartile", f"q{i + 1}", qbins == i) for i in range(4))
    for value in np.unique(domains):
        groups.append(("domain", str(int(value)), domains == value))
    groups.extend(("designed_pair", name, has_pair == value)
                  for name, value in (("no", False), ("yes", True)))
    for low, high, name in ((0.0, 1.0, "<1nm"), (1.0, 2.0, "1-2nm"),
                            (2.0, 4.0, "2-4nm"), (4.0, np.inf, ">=4nm")):
        groups.append(("target_motion", name, (target_mag >= low) & (target_mag < high)))

    out = []
    for group_type, group, mask in groups:
        if not mask.any():
            continue
        e = errors[mask]
        out.append({
            "model": model, "design": design, "group_type": group_type, "group": group,
            "n_nodes": int(mask.sum()),
            "rms_error_nm": float(np.sqrt(np.square(e).mean())),
            "mean_error_nm": float(e.mean()), "median_error_nm": float(np.median(e)),
            "p90_error_nm": float(np.quantile(e, 0.90)),
            "mean_target_motion_nm": float(target_mag[mask].mean()),
            "mean_pred_motion_nm": float(pred_mag[mask].mean()),
            "mean_direction_cosine": float(cosine[mask].mean()),
            "mean_target_progress": float(progress[mask].mean()),
        })
    return out


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty table: {path}")
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    split_path = DATA / "split.json"
    manifest_path = DATA / "manifest.json"
    ids = json.loads(split_path.read_text())["validation"]
    if len(ids) != 14 or len(set(ids)) != 14:
        raise ValueError(f"expected 14 unique validation designs, found {len(ids)}")

    protected = {"split": split_path, "manifest": manifest_path}
    protected.update({f"{name}_best": RUNS / model / "best.pt" for name, model in MODELS.items()})
    hashes_before = {name: sha256(path) for name, path in protected.items()}

    per_design: list[dict] = []
    node_rows: list[dict] = []
    group_summary: list[dict] = []
    model_arrays: dict[str, dict[str, list[np.ndarray]]] = {
        model: {"features": [], "target_error": [], "groups": [], "designs": []}
        for model in MODELS
    }
    model_macro: dict[str, float] = {}

    for display_name, run_name in MODELS.items():
        run = RUNS / run_name
        metrics = json.loads((run / "metrics.json").read_text())
        recorded = {row["design"]: row for row in metrics["validation"]["designs"]}
        if set(recorded) != set(ids):
            raise ValueError(f"stored validation metrics IDs differ for {display_name}")
        design_scores = []

        for ident in ids:
            with np.load(DATA / "inputs" / f"{ident}.npz") as archive:
                z = {key: archive[key] for key in archive.files}
            with np.load(DATA / "labels" / f"{ident}.npz") as archive:
                y = {key: archive[key] for key in archive.files}

            source = np.asarray(z["pos"], dtype=np.float64)
            target = np.asarray(y["target_pos"], dtype=np.float64)
            rotation = np.asarray(z["rotation"], dtype=np.float64)
            center = np.asarray(z["center"], dtype=np.float64).reshape(1, 3)
            conf_path = run / "predictions/validation" / ident / "prediction.conf"
            pred_raw = load_conf_positions(conf_path)
            if not (source.shape == target.shape == rotation.shape[:1] + (3,)):
                raise ValueError(f"coordinate/frame shapes disagree for {display_name}/{ident}")
            if pred_raw.shape != source.shape or not np.isfinite(pred_raw).all():
                raise ValueError(f"prediction shape/value invalid for {display_name}/{ident}")

            pred = (pred_raw - center) / 40.0
            official = score_nm(pred, target)
            identity = score_nm(source, target)
            stored = recorded[ident]
            if abs(official - float(stored["rmsd_nm"])) > 1e-4:
                raise ValueError(f"prediction reproduction failed: {display_name}/{ident}: {official} != {stored['rmsd_nm']}")
            if abs(identity - float(stored["identity_rmsd_nm"])) > 1e-4:
                raise ValueError(f"identity reproduction failed: {ident}: {identity} != {stored['identity_rmsd_nm']}")

            target_delta = (target - source) * SCALE_NM
            pred_delta = (pred - source) * SCALE_NM
            residual = (pred - target) * SCALE_NM
            error = np.linalg.norm(residual, axis=1)
            per_design.append({
                "model": display_name, "design": ident, "n_nodes": len(source),
                "rmsd_nm": official, "identity_rmsd_nm": identity,
                "gain_vs_identity_nm": identity - official,
                "median_node_error_nm": float(np.median(error)),
                "p90_node_error_nm": float(np.quantile(error, 0.90)),
                "mean_target_motion_nm": float(np.linalg.norm(target_delta, axis=1).mean()),
                "mean_pred_motion_nm": float(np.linalg.norm(pred_delta, axis=1).mean()),
            })
            design_scores.append(official)

            edge_index = np.asarray(z["edge_index"], dtype=np.int64)
            edge_types = np.asarray(z["edge_types"], dtype=np.int64).reshape(-1)
            if edge_index.shape != (2, len(edge_types)):
                raise ValueError(f"edge array shape mismatch for {ident}")
            degree_by_type = np.zeros((len(source), 5), dtype=np.float64)
            for edge_type in range(5):
                selected = edge_index[:, edge_types == edge_type].reshape(-1)
                degree_by_type[:, edge_type] = np.bincount(selected, minlength=len(source))
            degree = degree_by_type.sum(axis=1)
            pair_nodes = np.unique(edge_index[:, edge_types == 2]) if np.any(edge_types == 2) else np.array([], dtype=int)
            has_pair = np.zeros(len(source), dtype=bool)
            has_pair[pair_nodes] = True
            domains = np.asarray(z["domain_ids"], dtype=np.int64).reshape(-1)
            if len(domains) != len(source):
                raise ValueError(f"domain/node count mismatch for {ident}")
            group_summary.extend(group_rows(display_name, ident, error, target_delta,
                                            pred_delta, degree, domains, has_pair))
            for i in range(len(source)):
                target_motion = float(np.linalg.norm(target_delta[i]))
                pred_motion = float(np.linalg.norm(pred_delta[i]))
                node_rows.append({
                    "model": display_name, "design": ident, "node": i,
                    "domain": int(domains[i]), "degree": int(degree[i]),
                    "has_designed_pair": bool(has_pair[i]),
                    "target_motion_nm": target_motion, "pred_motion_nm": pred_motion,
                    "node_error_nm": float(error[i]),
                    "direction_cosine": float(np.dot(target_delta[i], pred_delta[i]) / max(target_motion * pred_motion, 1e-12)),
                    "target_progress": float(np.dot(target_delta[i], pred_delta[i]) / max(target_motion**2, 1e-12)),
                })

            # Source-only / inference-time features for a design-held-out error probe.
            local_source = np.einsum("nji,nj->ni", rotation, source)
            local_pred_delta = np.einsum("nji,nj->ni", rotation, pred_delta)
            domain_sizes = {int(v): int((domains == v).sum()) for v in np.unique(domains)}
            feature_parts = [
                np.asarray(z["node_features"], dtype=np.float64),
                local_source,
                local_pred_delta,
                degree_by_type,
                np.array([[domain_sizes[int(v)]] for v in domains], dtype=np.float64),
                has_pair.astype(np.float64)[:, None],
            ]
            features = np.concatenate(feature_parts, axis=1)
            if not np.isfinite(features).all() or not np.isfinite(error).all():
                raise ValueError(f"non-finite diagnostic values for {display_name}/{ident}")
            model_arrays[display_name]["features"].append(features)
            model_arrays[display_name]["target_error"].append(error)
            model_arrays[display_name]["groups"].extend([ident] * len(error))
            model_arrays[display_name]["designs"].append(ident)

        model_macro[display_name] = float(np.mean(design_scores))
        if abs(model_macro[display_name] - float(metrics["validation"]["mean_rmsd_nm"])) > 1e-4:
            raise ValueError(f"macro validation reproduction failed for {display_name}")

    # Out-of-fold predictions: each design is held out exactly once in seven folds.
    ridge_rows: list[dict] = []
    ridge_summary: dict[str, dict] = {}
    for display_name in MODELS:
        arrays = model_arrays[display_name]
        X = np.concatenate(arrays["features"], axis=0)
        y = np.concatenate(arrays["target_error"], axis=0)
        groups = np.asarray(arrays["groups"])
        cv = GroupKFold(n_splits=7)
        fold_by_design: dict[str, int] = {}
        for fold_index, (train_index, held_out_index) in enumerate(cv.split(X, y, groups), start=1):
            train_designs = set(groups[train_index])
            held_out_designs = set(groups[held_out_index])
            if train_designs & held_out_designs:
                raise ValueError(f"design leakage in GroupKFold fold {fold_index}")
            for ident in held_out_designs:
                if ident in fold_by_design:
                    raise ValueError(f"design {ident} held out more than once")
                fold_by_design[ident] = fold_index
        if set(fold_by_design) != set(ids):
            raise ValueError("GroupKFold did not hold out every validation design exactly once")
        predictions = cross_val_predict(make_pipeline(StandardScaler(), Ridge(alpha=10.0)),
                                        X, y, groups=groups, cv=cv, n_jobs=1)
        if not np.isfinite(predictions).all():
            raise ValueError(f"non-finite Ridge predictions for {display_name}")
        design_r2, design_mae = [], []
        for ident in ids:
            mask = groups == ident
            r2 = float(r2_score(y[mask], predictions[mask]))
            mae = float(mean_absolute_error(y[mask], predictions[mask]))
            ridge_rows.append({"model": display_name, "design": ident,
                               "held_out_fold": fold_by_design[ident],
                               "n_nodes": int(mask.sum()), "held_out_r2": r2,
                               "held_out_mae_nm": mae})
            design_r2.append(r2)
            design_mae.append(mae)
        ridge_summary[display_name] = {
            "macro_design_r2": float(np.mean(design_r2)),
            "macro_design_mae_nm": float(np.mean(design_mae)),
            "pooled_node_r2": float(r2_score(y, predictions)),
            "n_designs": len(ids), "n_nodes": len(y),
        }

    per_lookup = {(row["model"], row["design"]): row for row in per_design}
    differences = np.array([per_lookup[("OnePass", ident)]["rmsd_nm"] -
                            per_lookup[("DGNN-lite", ident)]["rmsd_nm"] for ident in ids])
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    sampled = rng.choice(differences, size=(BOOTSTRAP_RESAMPLES, len(differences)), replace=True).mean(axis=1)
    delta = float(differences.mean())
    ci = [float(v) for v in np.quantile(sampled, [0.025, 0.975])]

    identity_macro = float(np.mean([per_lookup[("OnePass", ident)]["identity_rmsd_nm"] for ident in ids]))
    identity_wins = {
        model: sum(per_lookup[(model, ident)]["gain_vs_identity_nm"] > 0 for ident in ids)
        for model in MODELS
    }
    motion_summary: dict[str, list[dict]] = {}
    for model in MODELS:
        current = [row for row in node_rows if row["model"] == model]
        target_motion = np.asarray([row["target_motion_nm"] for row in current])
        pred_motion = np.asarray([row["pred_motion_nm"] for row in current])
        node_error = np.asarray([row["node_error_nm"] for row in current])
        direction = np.asarray([row["direction_cosine"] for row in current])
        progress = np.asarray([row["target_progress"] for row in current])
        summary_rows = []
        for low, high, label in ((0.0, 1.0, "<1nm"), (1.0, 2.0, "1-2nm"),
                                 (2.0, 4.0, "2-4nm"), (4.0, np.inf, ">=4nm")):
            mask = (target_motion >= low) & (target_motion < high)
            summary_rows.append({
                "target_motion_bin": label,
                "n_nodes": int(mask.sum()),
                "fraction_nodes": float(mask.mean()),
                "node_rmse_nm": float(np.sqrt(np.mean(node_error[mask] ** 2))),
                "mean_target_motion_nm": float(target_motion[mask].mean()),
                "mean_pred_motion_nm": float(pred_motion[mask].mean()),
                "mean_direction_cosine": float(direction[mask].mean()),
                "mean_target_progress": float(progress[mask].mean()),
                "fraction_squared_error": float(np.square(node_error[mask]).sum() /
                                                 np.square(node_error).sum()),
            })
        motion_summary[model] = summary_rows

    hashes_after = {name: sha256(path) for name, path in protected.items()}
    if hashes_after != hashes_before:
        raise ValueError("protected checkpoint/data hashes changed during diagnostic")

    OUT.mkdir(parents=True, exist_ok=True)
    write_csv(OUT / "per_design.csv", per_design)
    write_csv(OUT / "node_errors.csv", node_rows)
    write_csv(OUT / "node_error_summary.csv", group_summary)
    write_csv(OUT / "ridge_error_probe.csv", ridge_rows)

    summary = {
        "phase": "talos97_validation_error_localization_v1",
        "validation_ids": ids,
        "n_designs": len(ids),
        "n_rows_per_model": len(ids),
        "official_validation_macro_rmsd_nm": model_macro,
        "paired_design_delta_onepass_minus_dgnn_nm": delta,
        "paired_design_bootstrap_95pct_ci_nm": ci,
        "bootstrap_seed": BOOTSTRAP_SEED,
        "bootstrap_resamples": BOOTSTRAP_RESAMPLES,
        "ridge_error_probe": ridge_summary,
        "ridge_group_folds": {"n_splits": 7, "held_out_fold_by_design": fold_by_design,
                              "every_design_held_out_once": True, "group_overlap": False},
        "identity_validation_macro_rmsd_nm": identity_macro,
        "designs_improved_vs_identity": identity_wins,
        "node_error_by_target_motion_bin": motion_summary,
        "metric_formula": "sqrt(mean_i ||pred-target||^2) * 40 * 0.8518, macro mean over 14 designs",
        "node_feature_probe": "source-only node features, local-frame source coordinates, local-frame predicted displacement, edge-type degrees, domain size, pair participation; GroupKFold(7) by design; Ridge(alpha=10)",
        "test_set_used": False,
        "checkpoint_modified": False,
        "protected_sha256_before": hashes_before,
        "protected_sha256_after": hashes_after,
        "finite_node_rows": len(node_rows),
        "node_summary_rows": len(group_summary),
        "ridge_probe_design_rows": len(ridge_rows),
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    top = sorted(per_design, key=lambda row: row["rmsd_nm"], reverse=True)
    lines = [
        "# OnePass 与 DGNN-lite：TALOS97 验证误差定位",
        "",
        "## Material Passport",
        "",
        "- Origin Skill: academic-research-suite / experiment-agent",
        "- Origin Mode: run + validate",
        "- Origin Date: 2026-10-29",
        "- Verification Status: VERIFIED" if all(hashes_before == hashes_after for _ in [0]) else "- Verification Status: FAILED",
        "- Version Label: talos97_error_localization_v1",
        "",
        "## 指标复现",
        "",
        f"仅用固定14个验证设计，从保存的 prediction.conf 重算官方 RMSD。OnePass={model_macro['OnePass']:.6f} nm；DGNN-lite={model_macro['DGNN-lite']:.6f} nm。与 metrics.json 宏值的差异均不超过 1e-4 nm。未读取测试 split。",
        "",
        f"Identity 宏 RMSD={identity_macro:.6f} nm；OnePass 在 {identity_wins['OnePass']}/14 个设计上改善，DGNN-lite 在 {identity_wins['DGNN-lite']}/14 个设计上改善。",
        "",
        f"按设计配对的 OnePass-DGNN-lite 均值差为 {delta:.4f} nm，设计级 bootstrap 95% 区间 [{ci[0]:.4f}, {ci[1]:.4f}] nm。负值有利于 OnePass。区间按14个设计重采样，节点不作为独立样本。",
        "",
        "## 误差最大的验证设计",
        "",
        "|模型|设计|RMSD nm|Identity nm|相对 identity 改善 nm|P90 节点误差 nm|",
        "|---|---|---:|---:|---:|---:|",
    ]
    for row in top[:8]:
        lines.append(f"|{row['model']}|{row['design']}|{row['rmsd_nm']:.4f}|{row['identity_rmsd_nm']:.4f}|{row['gain_vs_identity_nm']:.4f}|{row['p90_node_error_nm']:.4f}|")
    lines += [
        "", "## 节点运动幅度与残差", "",
        "下表将 14 个验证设计的节点合并作描述性分层；节点不是独立实验单位。`target_progress` 是预测位移在目标位移方向上的投影除以目标位移平方，约 1 表示该投影幅度接近目标，负值表示方向相反。",
        "", "|模型|目标位移|节点比例|节点误差 RMS nm|目标位移均值 nm|预测位移均值 nm|方向 cosine|target progress|平方误差占比|",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for model in MODELS:
        for row in motion_summary[model]:
            lines.append(f"|{model}|{row['target_motion_bin']}|{row['fraction_nodes']:.1%}|{row['node_rmse_nm']:.3f}|{row['mean_target_motion_nm']:.3f}|{row['mean_pred_motion_nm']:.3f}|{row['mean_direction_cosine']:.3f}|{row['mean_target_progress']:.3f}|{row['fraction_squared_error']:.1%}|")
    lines += ["", "描述性发现：OnePass 的 9.9% 节点目标位移至少 4 nm，这组节点占合并节点平方残差的约三分之一；预测位移均值仍明显小于目标位移均值。小于 1 nm 的节点则有轻度幅值过冲。DGNN-lite 各幅度组的预测位移几乎固定在 0.42–0.44 nm，显示其读出接近 identity。误差与目标位移幅度的关系本身使用了标签，只用于定位，不是推理期特征。", ""]
    lines += ["## Source-only error probe", ""]
    for model, result in ridge_summary.items():
        lines.append(f"- {model}: macro design-held-out R²={result['macro_design_r2']:.4f}, macro MAE={result['macro_design_mae_nm']:.4f} nm; pooled-node R²={result['pooled_node_r2']:.4f}.")
    lines += [
        "",
        "该 Ridge 是探索性 error probe：每折整设计留出，预测目标是节点残差幅度，特征只来自初始结构和模型推理输出。它不能证明模型内部因果机制，也不代表可直接用于推理的误差校正器。详细节点与分组统计见同目录 CSV。",
        "",
        "## 证据边界与下一步",
        "",
        "本阶段定位错误，不训练、不更新权重，也不使用测试集。若误差主要随位移幅度变化，下一阶段对 OnePass 做有界幅度/方向分离的验证集干预；若误差集中在域或配对上下文，再做对应输入/消息路径对照。Hidden-state probing、rsatoolbox、Captum 与 NNsight 干预留到误差模式明确后。任何候选仍须在原14个验证设计上重算宏 RMSD，并继续保留测试集。",
        "",
        "原始证据与复现结果见 `per_design.csv`、`node_errors.csv`、`node_error_summary.csv`、`ridge_error_probe.csv` 和 `summary.json`。",
    ]
    (OUT / "REPORT_ZH.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({
        "validation_macro_rmsd_nm": model_macro,
        "paired_delta_nm": delta,
        "paired_bootstrap_ci_nm": ci,
        "ridge_error_probe": ridge_summary,
        "node_rows": len(node_rows),
        "group_rows": len(group_summary),
        "report": str(OUT / "REPORT_ZH.md"),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
