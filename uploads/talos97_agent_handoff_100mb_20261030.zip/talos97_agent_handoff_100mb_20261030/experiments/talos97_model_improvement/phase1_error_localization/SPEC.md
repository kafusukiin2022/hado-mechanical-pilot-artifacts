# Phase 1: TALOS97 validation error localization

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: plan
- Origin Date: 2026-10-29
- Verification Status: UNVERIFIED
- Version Label: talos97_error_localization_v1

## Objective

Explain where the current OnePass and DGNN-lite prediction error occurs on the fixed 14-design validation split, and choose a narrow, testable intervention for the later model-improvement phase. The improvement target is validation macro RMSD near 1.2 nm against the replica-1 mean structure. Phase 1 is diagnostic only; it does not train, tune, or modify checkpoints. The test split remains unopened in this phase.

## Frozen baselines and inputs

- OnePass: `experiments/talos97_endpoint_v1/runs/painn_onepass/best.pt`, best validation epoch 48, recorded validation macro RMSD 2.2510869588 nm.
- DGNN-lite: `experiments/talos97_endpoint_v1/runs/dgnn_lite/best.pt`, best validation epoch 25, recorded validation macro RMSD 2.5419452276 nm.
- Use only the frozen validation IDs in `experiments/talos97_endpoint_v1/data/split.json`, the source-only input NPZs, replica-1 mean label NPZs, and saved validation `prediction.conf` files.
- Official score: per-design `sqrt(mean_i ||pred_i-target_i||^2) * 40 * 0.8518`, then arithmetic mean over the 14 designs. Do not weight designs by nucleotide count.
- Record SHA-256 for both checkpoints, the split, and the dataset manifest before analysis; verify they are unchanged afterward.

## Questions and analyses

1. Reproduce each model's official per-design and macro validation RMSD from saved predictions.
2. Localize residual error by design and node: error quantiles, predicted/target displacement magnitudes and directional alignment, and where error concentrates by node degree, domain, and designed-pair participation.
3. Compare OnePass and DGNN-lite by paired design-level deltas. Treat designs—not nucleotide nodes—as the independent units for uncertainty summaries; report a paired bootstrap interval over 14 designs, clearly marked exploratory.
4. As an exploratory input-level probe, use scikit-learn `StandardScaler + Ridge(alpha=10)` with 7-fold `GroupKFold` (held-out groups are whole designs) to predict node residual magnitude from source-only node/geometric/degree/domain/pair features plus model-predicted displacement expressed in the input local frame. The target residual is only the response, never a feature. This tests whether observable input context predicts error; it is not the hidden-representation phase.
5. Identify whether the leading actionable pattern is under/over-correction, topology-local error, or a small set of difficult designs. Do not infer a causal mechanism or use test outcomes.

## Hypotheses

- H1: The remaining error is partly driven by systematic displacement-amplitude or direction errors, which can be targeted by a bounded/radial readout intervention.
- H2: Error is concentrated in specific domains or pairing/topology contexts, motivating an input/readout feature intervention rather than a larger MLP.
- H3: Errors are broadly distributed across validation designs, so a single subgroup fix will not plausibly move the macro RMSD toward 1.2 nm.

## Expected artifacts

- `EXPECTED_VERIFICATION.md`, written before running analysis.
- A deterministic analysis script under this phase directory.
- `results/per_design.csv`, `results/node_errors.csv`, `results/node_error_summary.csv`, `results/ridge_error_probe.csv`, `results/summary.json`, and `results/REPORT_ZH.md`.

## Constraints

- No training, gradient update, checkpoint rewrite, test-set evaluation, or changes to the existing model/data code.
- Keep the same fixed split and target definition.
- If metrics fail reproduction, stop and resolve the discrepancy before interpreting error patterns or planning an intervention.
