# Phase 8：域级 SE(3) 变换残差实验结果

## 结果

在本机 A100 的 GPU 1 上完成了预注册的 3-seed × 2-arm、每臂 50 epoch 实验，共 20,400 个 optimizer steps。候选模型在每个设计上预测一个共享 domain rigid transform，再加原 localframe 节点残差；控制组是同一冻结 localframe checkpoint 的 matched continuation。模型选择只使用固定 14 个 validation 设计。

| seed | control 验证宏 RMSD | domain-transform 验证宏 RMSD | 候选最佳 epoch |
|---|---:|---:|---:|
| 11 | 2.174161 nm | 2.174161 nm | 0 |
| 22 | 2.174555 nm | 2.179434 nm | 0 |
| 33 | 2.177759 nm | 2.180528 nm | 0 |
| 均值 | **2.175492 nm** | **2.178041 nm** | — |

候选减控制为 **+0.002549 nm**（误差略增），只有 1/3 seed 的配对差异略微有利于候选，最大逐设计回归为 0.053119 nm。三 seed 候选全部选在 epoch 0，说明训练后的域分支没有泛化到验证集。候选未达到预注册“至少改善 0.05 nm、至少 2/3 seed 胜出、最大回归不超过 0.20 nm”的 promising 标准；1.2 nm 绝对目标也未达到。

三 seed prediction ensemble 的验证宏 RMSD：control **2.154073 nm**，domain-transform **2.157031 nm**。集成同样没有收益。

## 实现和功能核验

候选分支本身通过功能检查：epoch 0 与 frozen checkpoint 最大位置差 3.41×10⁻⁸ nm；全局旋转等变误差 0；domain ID 重标误差 0；SO(3) 行列式约为 1；采样的域内距离误差 <1×10⁻⁶ nm。预检时门、平移头和旋转头均获得有限非零梯度；实际训练中三者也有非零梯度。因此这是**具有功能、能够优化但无验证收益**的负结果，而非分支未接通。

## 核验与边界

独立核验器 v2 的 9 项检查全部通过，独立重算六次训练结果、所有选中 checkpoint 的 14 设计验证 RMSD、配对数据顺序、集成预测、训练/验证数据哈希、冻结基础 checkpoint 哈希和源文件哈希。运行只打开固定 68 train 和 14 validation 的输入/标签；test ID 未解码，test 输入、标签、预测和推理均未触碰。原始模型 checkpoint 未修改。训练在本地 `cuda:1` 执行，没有提交 Slurm 作业；曾提交的排队作业 19831 在运行前已取消。

最初的 `verify_results.py` 将“未通过 promising 科学筛选”误当作验证失败，并漏计运行脚本哈希；原始输出保留为 `verification_initial_failure.json`。`verify_results_v2.py` 将完整性核验与科学判定分开，并将 `run_a100.sbatch` 纳入源码哈希；最终 `verification.json` 通过全部检查。训练源文件、训练输出和模型选择没有被改动。

## 根因含义

根因审计中验证标签拟合的域刚体 oracle 很强，但本实验表明：仅从当前初始节点特征和每域 mean-pool hidden state 预测一个独立 domain transform，不足以学到可泛化的域运动。不能把 label-fitted oracle 当作可部署误差上限。综合结果支持“有限轨迹标签噪声显著 + 当前可预测输入/模型结构不足”的双因素判断；本次负结果具体否定的是简化共享域头的有效性，不否定需要 domain/helix coarse graph、跨域交互、replica-aware uncertainty 或完整 Domain-Frame EBD。下一步应先对各 replica 目标做 uncertainty-aware / multi-replica 验证，再构建具有 domain-edge、helix-segment 汇聚和粗图长程通信的模型，并与匹配容量控制比较。
