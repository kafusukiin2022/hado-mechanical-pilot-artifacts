# Phase 5：对齐验证宏 RMSD 的训练目标结果

## 结果

六个匹配 continuation run 均完成：控制臂和 metric-aligned 臂各含 seed 11/22/33，每个 50 epochs。两臂使用相同的模型、初始化、优化器、更新预算和每 epoch 训练设计顺序。冻结 OnePass epoch-48 checkpoint 在固定 14 个验证设计上的宏 RMSD 为 **2.251087 nm**。

|候选|三 seed 验证宏 RMSD 均值|相对冻结 OnePass|相对匹配控制|
|---|---:|---:|---:|
|原 position-MSE 控制续训|2.241036 nm|−0.010051 nm|—|
|scaled smooth per-design RMSD 目标|2.239222 nm|−0.011865 nm|−0.001814 nm|

三个 paired seed 的 intervention 减 control 差分别为 −0.002986、−0.001185、−0.001272 nm；三组均略有改善，但平均改善只有 0.001814 nm，未达到预注册的 0.05 nm 筛选门槛。没有任何验证设计相对 paired control 回归超过 0.20 nm。

训练目标与验证宏 RMSD 的口径对齐有方向正确但很小的效果。它不能把误差从约 2.24 nm 推到约 1.2 nm，也不能单独解释 local-frame 或 `trap_target` 的优势；这次结果说明简单改变设计级损失聚合不是主要瓶颈。

## 验证

`verification.json` 的 15 项检查全部通过：六个 run 各 50 个有限值 epoch；paired 训练顺序一致；固定 68/14 训练/验证划分完整；epoch-0 候选纳入；98 条 per-design 记录和 3 条 paired-seed 记录完整；初始输出等价；训练损失尺度由冻结模型在恰好 68 个训练设计上的中位 RMSD 计算（2.286727 nm），没有使用验证或测试目标；源、数据、split 和原始 checkpoint 哈希未改变。`test_rows_read=false`、`test_predictions_written=false`、`original_checkpoint_modified=false`。

训练在既有 Slurm H100 allocation **17439 / gpu17** 内完成，没有提交新作业。原 checkpoint、数据和源文件保持不变。该结果只用于固定 14 设计验证集的干预筛选，不构成盲测泛化结论。

## 后续方向

Phase 3 的向量 RMS 读出、Phase 4 的节点幅度门和本 Phase 5 的 metric-aligned loss 都只产生千分之一纳米量级的变化。下一步应转向表示/结构本身，而不是继续做同一 readout 的微调：优先设计能直接检验大位移节点是否缺少可辨识信息的表示干预，并继续保持训练、验证、测试严格隔离。约 1.2 nm 的验证目标仍未达到。
