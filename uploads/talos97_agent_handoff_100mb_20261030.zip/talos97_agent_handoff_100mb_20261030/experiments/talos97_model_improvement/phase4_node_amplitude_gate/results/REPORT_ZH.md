# Phase 4：节点位移幅度门干预结果

## 结果

六个匹配 continuation run 均完成：控制臂和 amplitude 臂各含 seed 11/22/33，每个 50 epochs，共 300 条训练历史记录。三组 paired seed 使用相同的 68 个训练设计顺序。冻结 OnePass epoch-48 checkpoint 在固定 14 个验证设计上的宏 RMSD 为 **2.251087 nm**。

|候选|三 seed 验证宏 RMSD 均值|相对冻结 OnePass|相对匹配控制|
|---|---:|---:|---:|
|原读出控制续训|2.240960 nm|−0.010127 nm|—|
|节点幅度门|2.242184 nm|−0.008903 nm|+0.001223 nm|

三个 seed 的 amplitude 减 control 差分别为 +0.001598、+0.000605、+0.001468 nm，三组均未改善。14 个验证设计×3 个 seed 的 paired 设计差中，17 项 amplitude 更低、25 项更高；最大回归仅 0.021983 nm，没有超过预设的 0.20 nm 约束，但平均改善、至少两组 seed 改善这两个主要条件均不满足。

因此按 `SPEC.md` 的预注册规则，节点幅度门是**负结果**：它没有达到 0.05 nm 的平均改善门槛，也没有显示出对 Phase 1 所见大位移低估的可检测修复。控制续训本身比冻结权重约好 0.010127 nm，说明本实验中的微小变化主要与低学习率 continuation 相容，而不是新幅度分支带来的收益。

## 验证

`verification.json` 的 12 项检查全部通过：六个 run 各完成 50 个有限值 epoch；paired 训练顺序一致；每个 run 覆盖同一 14 个验证设计；98 条 per-design 记录和 3 条 paired-seed 记录完整；初始 gain=1 的零初始化分支与冻结模型满足预设位置、旋转容差；epoch-0 候选被纳入选择；源、数据、split 和原始 checkpoint 哈希未改变。`test_rows_read=false`、`test_predictions_written=false`、`original_checkpoint_modified=false`。

训练在既有 Slurm H100 allocation **17439 / gpu17** 内完成，没有提交新作业。原 OnePass checkpoint、数据和源文件均保留不变。该结果只用于固定 14 设计验证集的干预筛选，不构成盲测泛化结论。

## 后续方向

Phase 1 的大位移节点低估并没有被直接的正值幅度读出修复；Phase 3 的向量 RMS 暴露和本 Phase 4 的幅度门均只有零点几百分之一纳米量级变化。继续追求约 1.2 nm 目标时，应优先做有明确预算和消融的结构性干预，例如匹配 50/200 epochs 的 `trap_target` 对照并单独去除 4 nm 限幅，或分离 local-frame 模型的宽度、深度、LayerNorm 和集成效应；不能把本次负结果当作目标已完成。
