# Phase 6：TransformerConv 功能核验与 TALOS97 结果

## 结论

TransformerConv 已接入 OnePass，并通过功能与训练梯度核验：它接收现有 PaiNN 标量节点状态和带特征的有向边，改变邻接关系会改变消息，打开残差 gate 会改变预测，训练中也有有限非零梯度传到 gate、TransformerConv 和输出投影。

它没有带来有实际意义的 TALOS97 验证提升。三种子 matched control 的验证宏 RMSD 均值为 **2.241031 nm**，TransformerConv 为 **2.240997 nm**，差值 **−0.0000337 nm**。这远低于预注册的 **0.05 nm** 有希望门槛，因此该结构干预判为负结果。相对冻结 OnePass 的约 0.010 nm 改善同样出现在 control，不能归因给 TransformerConv。

## 实现与训练

在 PaiNN 的 64 维 invariant scalar node state 上添加 `torch_geometric.nn.TransformerConv`：4 个 head、每头 16 维、20 维 edge features、无 attention dropout。拼接后的 64 维消息经线性层投影，并由零初始化的可训练 scalar gate 缩放后残差加回 scalar state，再进入原有 graph mean/max context 和系数读出。PaiNN vector channels、向量归一化、等变读出和损失保持不变。

训练从未修改的 OnePass epoch-48 checkpoint 开始，固定 68 个训练设计与 14 个验证设计，3 个配对种子（11、22、33），control/TransformerConv 各 50 epochs，AdamW `lr=3e-5`、`weight_decay=1e-6`，每设计一步、梯度裁剪 1.0。训练严格在现有 Slurm allocation 17439 的 gpu17/H100 上顺序完成，没有提交新作业。

## 功能与梯度证据

预检复现冻结 OnePass 验证宏 RMSD **2.25108692 nm**。零 gate TransformerConv 为 **2.25108692 nm**；14 个验证设计的最大节点位置差为 **3.30e-6 nm**，最大旋转矩阵元素差为 **2.31e-6**，低于 `1e-5` 门槛。

在训练设计 `6hb_006` 上，PyG **2.8.1** 的 TransformerConv 返回有限的 `[6856, 64]` 消息（输入有向边 `[2, 57023]`、edge features `[57023, 20]`）。重排邻居关联后消息平均绝对差为 **0.021875**；在临时打开 gate 后，预测最大节点位移差为 **0.083793 nm**。梯度探针得到 gate 梯度 `2.40e-5`（gate=0）和 `2.10e-5`（gate=0.1）、TransformerConv 梯度绝对和 `0.003803`、投影梯度绝对和 `0.002413`，全部有限且非零；这个探针使用一次性内存模型并执行零次 optimizer step，不触碰保存的 checkpoint。

冻结 checkpoint 的最终系数层为零初始化，因此它在 epoch 0 会屏蔽上游梯度。单独的 forward 敏感度探针只在 disposable 模型副本中对该最终层赋予确定性的微小非零权重；真正用于训练的初始权重仍严格来自冻结 checkpoint。训练日志进一步证明实际训练中的分支可学习：三个种子的 gate 最大绝对值分别达到 `0.00877`、`0.01190`、`0.01096`，且每个种子都记录到了非零 TransformerConv 与 projection 梯度。

## 配对结果

| Seed | Control (nm) | TransformerConv (nm) | TransformerConv − control (nm) |
|---:|---:|---:|---:|
| 11 | 2.241376 | 2.241266 | −0.000110 |
| 22 | 2.240023 | 2.239857 | −0.000166 |
| 33 | 2.241694 | 2.241869 | +0.000174 |
| **均值** | **2.241031** | **2.240997** | **−0.000034** |

三个配对中两个略有改善；没有任何一个验证设计回归超过 0.20 nm。但总体改善远低于 0.05 nm 预设阈值，故不判为 promising。当前最佳 archived TALOS97 结果及其因果解释边界见 `docs/harness/talos97_model_benchmark/WHY_BEST_MODELS_ZH.md`：扩容 local-frame 模型的宽度、深度、LayerNorm 与集成等因素相互混杂，现有结果不能归因于单一组件。

## 核验、数据边界与审计记录

`results/verification.json` 的 15 项核验全部通过：6 个 run 各有完整 50 epochs；配对训练顺序及固定 split 正确；checkpoint 仅在 epoch 0–50 中按固定验证集选择；98 条逐设计结果与 3 条 seed 配对表完整；训练分支梯度、功能 gate、PyG 版本与 TransformerConv 源文件 SHA256 均有记录。测试 ID 和测试行未加载或读取、没有生成测试预测，原始 OnePass checkpoint 未修改。训练/数据源哈希与运行前一致。

第一次执行 verifier 时发现 Python 同名模块导入冲突。全部训练已完成后，修正了 verifier 的导入别名并重新执行完整核验；这次修正只改了 verifier 文件，训练代码、模型源、PyG 实现、split、数据 manifest 和 checkpoint 哈希保持不变。运行前 verifier SHA256 为 `c35af2482b514b594294eae4da87a5b4fadbb0a031cba2ddb0e33e8fee550751`，最终 verifier SHA256 为 `ee68818a55949e2c4c8176ef0346be47fc28d5cb3ff5f3f1c6fba90fec4badd4`，该隔离变更也作为独立核验项记录。

详细结果：`summary.json`、`preflight.json`、`verification.json`、`per_design_validation.csv`、`paired_seeds.csv`；六组模型与逐 epoch 历史在 `runs/`。固定验证宏 RMSD 约 1.2 nm 的总体目标仍未达到。
