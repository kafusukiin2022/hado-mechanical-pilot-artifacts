#!/usr/bin/env python3
"""Read-only validation audit of domain motion and saved local-frame predictions."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DATA = ROOT / "experiments/talos97_endpoint_v1/data"
PHASE1 = ROOT / "experiments/talos97_model_improvement/phase1_error_localization/results"
LOCAL = ROOT / "experiments/talos97_localframe_2m"
OUT = HERE / "results"
NM = 40.0 * 0.8518
BIN_NAMES = ["<1nm", "1-2nm", "2-4nm", ">=4nm"]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def array_sha256(array: np.ndarray) -> str:
    value = np.ascontiguousarray(array)
    digest = hashlib.sha256()
    digest.update(str(value.dtype).encode())
    digest.update(json.dumps(value.shape).encode())
    digest.update(value.tobytes())
    return digest.hexdigest()


def rmsd_nm(pred: np.ndarray, target: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.sum((pred - target) ** 2, axis=-1))))


def motion_bin(motion: np.ndarray) -> np.ndarray:
    return np.select(
        [motion < 1.0, motion < 2.0, motion < 4.0],
        BIN_NAMES[:3],
        default=BIN_NAMES[3],
    )


def fit_domain_oracles(source: np.ndarray, target: np.ndarray, domain_ids: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    translation = np.empty_like(source)
    rigid = np.empty_like(source)
    sizes = []
    rigid_fit_groups = 0
    fallback_groups = 0
    for domain in np.unique(domain_ids):
        index = np.flatnonzero(domain_ids == domain)
        x = source[index]
        y = target[index]
        sizes.append(int(len(index)))
        delta = (y - x).mean(axis=0)
        translation[index] = x + delta
        # Avoid fitting rotations to tiny/degenerate groups. Those use the
        # group-translation oracle instead and are explicitly counted.
        if len(index) < 6:
            rigid[index] = translation[index]
            fallback_groups += 1
            continue
        xc = x - x.mean(axis=0, keepdims=True)
        yc = y - y.mean(axis=0, keepdims=True)
        u, _, vt = np.linalg.svd(xc.T @ yc, full_matrices=False)
        correction = np.eye(3, dtype=np.float64)
        correction[-1, -1] = 1.0 if np.linalg.det(u @ vt) >= 0 else -1.0
        rotation = u @ correction @ vt
        rigid[index] = xc @ rotation + y.mean(axis=0, keepdims=True)
        rigid_fit_groups += 1
    meta = {
        "domain_count": len(sizes),
        "domain_size_min": int(min(sizes)),
        "domain_size_median": float(np.median(sizes)),
        "domain_size_max": int(max(sizes)),
        "domains_rigid_fit_n_ge_6": rigid_fit_groups,
        "domains_using_translation_fallback_n_lt_6": fallback_groups,
    }
    return translation, rigid, meta


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    phase1_summary = json.loads((PHASE1 / "summary.json").read_text())
    validation_ids = list(phase1_summary["validation_ids"])
    if len(validation_ids) != 14 or len(set(validation_ids)) != 14:
        raise ValueError("Phase 1 does not contain the expected fixed 14 validation IDs")

    protected_paths = [
        DATA / "manifest.json",
        DATA / "split.json",
        ROOT / "experiments/talos97_endpoint_v1/runs/painn_onepass/best.pt",
        PHASE1 / "summary.json",
        PHASE1 / "per_design.csv",
        PHASE1 / "node_errors.csv",
        PHASE1.parent / "analyze_validation_errors.py",
        LOCAL / "model.py",
        LOCAL / "run_full97.py",
        LOCAL / "checkpoints/frame_11.pt",
        LOCAL / "checkpoints/frame_22.pt",
        LOCAL / "checkpoints/frame_33.pt",
        HERE / "analyze.py",
        HERE / "verify.py",
        LOCAL / "results" / "predictions" / "frame_11.npz",
        LOCAL / "results" / "predictions" / "frame_22.npz",
        LOCAL / "results" / "predictions" / "frame_33.npz",
    ]
    validation_data_paths = [
        path
        for ident in validation_ids
        for path in (DATA / "inputs" / f"{ident}.npz", DATA / "labels" / f"{ident}.npz")
    ]
    hashes_before = {str(path.resolve()): sha256(path) for path in protected_paths + validation_data_paths}

    p1_design_rows = list(csv.DictReader((PHASE1 / "per_design.csv").open()))
    p1_scores = {
        row["design"]: float(row["rmsd_nm"])
        for row in p1_design_rows
        if row["model"] == "OnePass" and row["design"] in validation_ids
    }
    if set(p1_scores) != set(validation_ids):
        raise ValueError("Phase 1 OnePass per-design rows do not match the frozen validation set")

    onepass_nodes = [
        row for row in csv.DictReader((PHASE1 / "node_errors.csv").open())
        if row["model"] == "OnePass" and row["design"] in validation_ids
    ]
    if not onepass_nodes:
        raise ValueError("No Phase 1 OnePass validation node rows found")

    per_design_rows: list[dict[str, Any]] = []
    localframe_nodes: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    localframe_prediction_hashes: dict[str, dict[str, str]] = {str(seed): {} for seed in (11, 22, 33)}
    domain_metadata: dict[str, dict[str, Any]] = {}
    total_identity_sse = 0.0
    total_translation_sse = 0.0
    total_rigid_sse = 0.0

    prediction_files = {
        seed: np.load(LOCAL / "results" / "predictions" / f"frame_{seed}.npz")
        for seed in (11, 22, 33)
    }
    try:
        for ident in validation_ids:
            with np.load(DATA / "inputs" / f"{ident}.npz") as inp:
                source = np.asarray(inp["pos"], dtype=np.float64) * NM
                domain_ids = np.asarray(inp["domain_ids"], dtype=np.int64)
            with np.load(DATA / "labels" / f"{ident}.npz") as label:
                target = np.asarray(label["target_pos"], dtype=np.float64) * NM
            if source.shape != target.shape or source.shape[0] != domain_ids.shape[0]:
                raise ValueError(f"input/label/domain shape mismatch for validation design {ident}")
            target_delta = target - source
            seed_deltas = []
            for seed, archive in prediction_files.items():
                # Only the frozen validation key is accessed. Never enumerate
                # or decode non-validation keys in the saved prediction archive.
                saved_pred_delta = np.asarray(archive[ident])
                if saved_pred_delta.shape != source.shape or not np.isfinite(saved_pred_delta).all():
                    raise ValueError(f"invalid saved frame prediction for {ident} seed {seed}")
                localframe_prediction_hashes[str(seed)][ident] = array_sha256(saved_pred_delta)
                seed_deltas.append(saved_pred_delta.astype(np.float64))
            ensemble_delta = np.mean(seed_deltas, axis=0)
            frame_prediction = source + ensemble_delta
            translation_oracle, rigid_oracle, domain_meta = fit_domain_oracles(source, target, domain_ids)
            domain_metadata[ident] = domain_meta

            identity_error = rmsd_nm(source, target)
            translation_error = rmsd_nm(translation_oracle, target)
            rigid_error = rmsd_nm(rigid_oracle, target)
            total_identity_sse += float(np.square(source - target).sum())
            total_translation_sse += float(np.square(translation_oracle - target).sum())
            total_rigid_sse += float(np.square(rigid_oracle - target).sum())
            per_design_rows.append({
                "design": ident,
                "nodes": int(len(source)),
                "onepass_rmsd_nm": p1_scores[ident],
                "identity_rmsd_nm": identity_error,
                "localframe_ensemble_rmsd_nm": rmsd_nm(frame_prediction, target),
                "domain_translation_oracle_rmsd_nm": translation_error,
                "domain_rigid_oracle_rmsd_nm": rigid_error,
                "domain_translation_sse_reduction_vs_identity": 1.0 - float(np.square(translation_oracle - target).sum()) / max(float(np.square(source - target).sum()), 1e-30),
                "domain_rigid_sse_reduction_vs_identity": 1.0 - float(np.square(rigid_oracle - target).sum()) / max(float(np.square(source - target).sum()), 1e-30),
                **domain_meta,
            })
            motion = np.linalg.norm(target_delta, axis=1)
            local_error = np.linalg.norm(frame_prediction - target, axis=1)
            local_pred_motion = np.linalg.norm(ensemble_delta, axis=1)
            dot = np.sum(ensemble_delta * target_delta, axis=1)
            cosine = dot / np.maximum(local_pred_motion * motion, 1e-12)
            progress = dot / np.maximum(motion ** 2, 1e-12)
            localframe_nodes[ident] = (motion, np.stack([local_error, local_pred_motion, cosine, progress], axis=1))
    finally:
        for archive in prediction_files.values():
            archive.close()

    # Validation-only motion strata; summarize by pooled nodes but also keep
    # per-design rows so designs remain the independent unit for interpretation.
    motion_rows: list[dict[str, Any]] = []
    for model_name in ("OnePass", "localframe_ensemble"):
        if model_name == "OnePass":
            grouped: dict[tuple[str, str], list[dict[str, str]]] = {}
            for row in onepass_nodes:
                grouped.setdefault((row["design"], row["target_motion_bin"] if "target_motion_bin" in row else ""), []).append(row)
            # Existing Phase 1 CSV stores numeric motion rather than a bin label.
            model_arrays = {
                ident: (
                    np.asarray([float(row["target_motion_nm"]) for row in onepass_nodes if row["design"] == ident]),
                    np.asarray([float(row["node_error_nm"]) for row in onepass_nodes if row["design"] == ident]),
                    np.asarray([float(row["pred_motion_nm"]) for row in onepass_nodes if row["design"] == ident]),
                    np.asarray([float(row["direction_cosine"]) for row in onepass_nodes if row["design"] == ident]),
                    np.asarray([float(row["target_progress"]) for row in onepass_nodes if row["design"] == ident]),
                )
                for ident in validation_ids
            }
        else:
            model_arrays = {
                ident: (localframe_nodes[ident][0], *[localframe_nodes[ident][1][:, k] for k in range(4)])
                for ident in validation_ids
            }
        all_sse = sum(float(np.square(values[1]).sum()) for values in model_arrays.values())
        for bin_name in BIN_NAMES:
            design_bin_rows = []
            for ident, values in model_arrays.items():
                motion, error, pred_motion, cosine, progress = values
                bins = motion_bin(motion)
                mask = bins == bin_name
                if not mask.any():
                    continue
                design_bin_rows.append({
                    "model": model_name,
                    "design": ident,
                    "target_motion_bin": bin_name,
                    "n_nodes": int(mask.sum()),
                    "node_rmse_nm": float(np.sqrt(np.mean(error[mask] ** 2))),
                    "mean_target_motion_nm": float(np.mean(motion[mask])),
                    "mean_pred_motion_nm": float(np.mean(pred_motion[mask])),
                    "mean_direction_cosine": float(np.mean(cosine[mask])),
                    "mean_target_progress": float(np.mean(progress[mask])),
                    "fraction_squared_error": float(np.square(error[mask]).sum() / max(all_sse, 1e-30)),
                })
            pooled_count = sum(row["n_nodes"] for row in design_bin_rows)
            pooled_sse = sum(row["node_rmse_nm"] ** 2 * row["n_nodes"] for row in design_bin_rows)
            total_nodes = sum(len(values[0]) for values in model_arrays.values())
            motion_rows.append({
                "model": model_name,
                "target_motion_bin": bin_name,
                "n_nodes": pooled_count,
                "fraction_nodes": pooled_count / total_nodes,
                "pooled_node_rmse_nm": float(np.sqrt(pooled_sse / max(pooled_count, 1))),
                "mean_design_node_rmse_nm": float(np.mean([row["node_rmse_nm"] for row in design_bin_rows])),
                "mean_target_motion_nm": float(np.average([row["mean_target_motion_nm"] for row in design_bin_rows], weights=[row["n_nodes"] for row in design_bin_rows])),
                "mean_pred_motion_nm": float(np.average([row["mean_pred_motion_nm"] for row in design_bin_rows], weights=[row["n_nodes"] for row in design_bin_rows])),
                "mean_direction_cosine": float(np.average([row["mean_direction_cosine"] for row in design_bin_rows], weights=[row["n_nodes"] for row in design_bin_rows])),
                "mean_target_progress": float(np.average([row["mean_target_progress"] for row in design_bin_rows], weights=[row["n_nodes"] for row in design_bin_rows])),
                "fraction_squared_error": float(sum(row["fraction_squared_error"] for row in design_bin_rows)),
                "design_rows": design_bin_rows,
            })

    # Flatten design-level bin records separately for transparent checks.
    per_design_motion = [row for motion_row in motion_rows for row in motion_row.pop("design_rows")]
    onepass_node_total = len(onepass_nodes)
    localframe_node_total = sum(len(v[0]) for v in localframe_nodes.values())
    if onepass_node_total != localframe_node_total:
        raise ValueError(f"node count mismatch: OnePass CSV={onepass_node_total}, localframe={localframe_node_total}")

    hashes_after = {str(path.resolve()): sha256(path) for path in protected_paths + validation_data_paths}
    result = {
        "phase": "talos97_phase7_domain_motion_audit_v1",
        "validation_ids": validation_ids,
        "validation_design_count": len(validation_ids),
        "validation_node_count": localframe_node_total,
        "domain_fit_policy": "fit proper rigid transforms only for domains with >=6 nodes; use translation for smaller domains",
        "domain_metadata_by_design": domain_metadata,
        "domain_translation_macro_rmsd_nm": float(np.mean([row["domain_translation_oracle_rmsd_nm"] for row in per_design_rows])),
        "domain_rigid_macro_rmsd_nm": float(np.mean([row["domain_rigid_oracle_rmsd_nm"] for row in per_design_rows])),
        "domain_translation_pooled_sse_reduction": 1.0 - total_translation_sse / max(total_identity_sse, 1e-30),
        "domain_rigid_pooled_sse_reduction": 1.0 - total_rigid_sse / max(total_identity_sse, 1e-30),
        "models": {
            "onepass_macro_rmsd_nm": float(np.mean([row["onepass_rmsd_nm"] for row in per_design_rows])),
            "identity_macro_rmsd_nm": float(np.mean([row["identity_rmsd_nm"] for row in per_design_rows])),
            "localframe_ensemble_macro_rmsd_nm": float(np.mean([row["localframe_ensemble_rmsd_nm"] for row in per_design_rows])),
        },
        "motion_bin_rows": motion_rows,
        "hashes_before": hashes_before,
        "hashes_after": hashes_after,
        "localframe_validation_prediction_array_sha256": localframe_prediction_hashes,
        "localframe_prediction_archive_sha256": {
            str(seed): hashes_before[str((LOCAL / "results" / "predictions" / f"frame_{seed}.npz").resolve())]
            for seed in (11, 22, 33)
        },
        "test_ids_loaded": False,
        "test_rows_read": False,
        "test_prediction_keys_read": False,
        "model_inference": False,
        "optimizer_steps": 0,
        "original_checkpoints_modified": False,
        "oracle_fits_use_validation_labels": True,
        "domain_oracles_are_deployable_predictions": False,
    }
    (OUT / "per_design.csv").write_text("")
    with (OUT / "per_design.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(per_design_rows[0]))
        writer.writeheader(); writer.writerows(per_design_rows)
    with (OUT / "motion_bins.csv").open("w", newline="") as f:
        fields = [key for key in motion_rows[0] if key != "design_rows"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader(); writer.writerows(motion_rows)
    with (OUT / "motion_bins_by_design.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(per_design_motion[0]))
        writer.writeheader(); writer.writerows(per_design_motion)
    (OUT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "validation_design_count": len(validation_ids),
        "validation_node_count": localframe_node_total,
        "models": result["models"],
        "domain_translation_macro_rmsd_nm": result["domain_translation_macro_rmsd_nm"],
        "domain_rigid_macro_rmsd_nm": result["domain_rigid_macro_rmsd_nm"],
        "domain_translation_pooled_sse_reduction": result["domain_translation_pooled_sse_reduction"],
        "domain_rigid_pooled_sse_reduction": result["domain_rigid_pooled_sse_reduction"],
        "test_rows_read": False,
    }, indent=2))


if __name__ == "__main__":
    main()
