# Phase 7：域运动与 localframe 验证误差审计

## 结论

固定 14 个验证设计、共 118,342 个节点上，OnePass 宏平均 RMSD 为 **2.2511 nm**，保存的 `localframe_2m` 三种子 ensemble 为 **2.1570 nm**，identity 为 **2.6026 nm**。localframe ensemble 在 14 个设计中有 13 个优于 OnePass，平均降低 **0.0941 nm（4.18%）**；逐运动幅度分层也都略有改善，但大位移误差仍很明显。

域级 oracle 给出很强的结构信号：每个域单独拟合平移后宏平均 RMSD 为 **0.6030 nm**；每域拟合 proper rigid transform 后为 **0.3123 nm**。相对 identity，二者分别减少 **94.73%** 和 **98.59% pooled SSE**。这说明目标位移在当前 `domain_ids` 内高度可由一致的粗粒度运动解释，是下一项可学习域变换加局部残差干预的依据。

这些 oracle 使用验证目标拟合，属于诊断上限，不是可部署预测，也不能证明 `localframe_2m` 的提升由域级刚体运动造成。模型因果解释仍受宽度、深度、LayerNorm、位置专用读出和三种子集成等混杂因素限制。**约 1.2 nm 的目标尚未达到。**

## 按目标位移分层

下表中的节点比例由固定验证标签决定；节点汇总用于描述，设计仍是独立实验单位。`target progress` 接近 1 表示预测在目标位移方向上的投影接近目标幅度。

|模型|目标位移|节点比例|节点误差 RMS (nm)|目标位移均值 (nm)|预测位移均值 (nm)|方向 cosine|target progress|pooled SSE 占比|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|OnePass|<1 nm|12.0%|1.257|0.704|1.078|0.187|0.334|3.60%|
|OnePass|1–2 nm|33.2%|1.583|1.518|1.130|0.346|0.294|15.75%|
|OnePass|2–4 nm|44.9%|2.391|2.809|1.278|0.545|0.275|48.49%|
|OnePass|≥4 nm|9.9%|4.148|4.936|1.480|0.661|0.213|32.17%|
|localframe ensemble|<1 nm|12.0%|1.188|0.704|1.025|0.212|0.361|3.47%|
|localframe ensemble|1–2 nm|33.2%|1.530|1.518|1.124|0.375|0.325|15.91%|
|localframe ensemble|2–4 nm|44.9%|2.307|2.809|1.325|0.589|0.307|48.80%|
|localframe ensemble|≥4 nm|9.9%|3.968|4.936|1.646|0.721|0.253|31.82%|

`localframe_2m` 的改善覆盖所有四个幅度区间；在 ≥4 nm 组，预测平均幅度从 1.480 nm 增至 1.646 nm、方向 cosine 从 0.661 增至 0.721，但相对目标 4.936 nm 仍严重不足。大位移组只占 9.9% 节点，却仍贡献约 32% pooled SSE，是继续改善的首要误差来源之一。

## 域级 oracle

|评估|宏平均 RMSD (nm)|相对 identity pooled SSE 减少|
|---|---:|---:|
|Identity|2.6026|—|
|每域平移 oracle|0.6030|94.73%|
|每域 rigid oracle|0.3123|98.59%|

每个设计的域中位大小均为 30 个节点；每设计有 243–387 个域。少于 6 个节点的域在 rigid oracle 中采用平移 fallback，数量逐设计写入 `per_design.csv`。每域刚体变换通过 Kabsch 对齐该验证域的输入与标签，并修正为 determinant 为正的旋转。

这个结果表示“域内部运动存在很强的共同成分”，不能被解释为模型只需精确预测这些 oracle 变换即可达到对应分数：这些变换直接从待评估目标拟合，包含验证标签信息。下一项应让模型仅从输入和训练数据预测域级变换，并将节点级局部残差作为补充；同时用匹配续训对照确定新增结构是否带来泛化收益。

## 核验与数据边界

独立 verifier 的 **11 项检查全部通过**，包括：固定 14 个 ID 和 118,342 个节点、OnePass/identity/localframe 逐设计 RMSD 重算、每个设计和每个 bin 的所有 motion 指标重算、域平移与 proper rigid oracle 及域元数据重算、宏平均和 pooled SSE 汇总重算，以及数据/模型/源文件/预测归档哈希前后相等。

分析只解码 14 个验证输入和标签，并只通过明确的验证 ID 访问三份 localframe 预测归档。预测归档另做完整文件字节哈希以核对来源，但没有枚举归档键或解码任何测试预测数组。`split.json` 只做字节哈希，没有解析测试 ID。验证结果记录 `test_ids_loaded=false`、`test_rows_read=false`、`test_prediction_keys_read=false`；没有模型推理、训练、optimizer step 或检查点修改。

可复现命令见 `EXPECTED_VERIFICATION.md`。数据表为 `per_design.csv`、`motion_bins.csv`、`motion_bins_by_design.csv`，机器可读摘要与逐项结果分别为 `summary.json` 和 `verification.json`。
