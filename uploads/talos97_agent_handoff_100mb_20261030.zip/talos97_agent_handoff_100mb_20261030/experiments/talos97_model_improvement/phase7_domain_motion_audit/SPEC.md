# Phase 7: validation-only domain-motion and local-frame error audit

## Question

OnePass misses much of the large target displacement, while the validation-selected `localframe_2m` ensemble performs modestly better and uses fixed local/multiscale/domain geometry. Determine whether localframe's gains concentrate in large-motion nodes and whether target motion is coherent within the existing `domain_ids` under translation or rigid-body transforms. This decides whether a hierarchical domain-motion readout is a defensible next intervention.

## Scope and data boundary

- Read exactly the 14 validation design IDs already recorded in `phase1_error_localization/results/summary.json`.
- Read only those designs' `inputs/*.npz`, `labels/*.npz`, and validation rows in Phase 1 CSVs.
- For saved localframe predictions, access only the 14 validation keys in the three existing `frame_{11,22,33}.npz` archives; do not enumerate or load other prediction keys.
- Do not decode `split.json`; record only its byte hash. Do not load test IDs, labels, or prediction arrays.
- Do not run model inference, training, optimizer steps, or modify any checkpoint. Domain translation/rigid transforms fit to target labels are validation-only oracle diagnostics, not deployable predictions.

## Analyses

1. Recompute validation per-design RMSD for source identity, the frozen OnePass (from verified Phase 1 summaries), and the saved validation-selected three-seed localframe ensemble.
2. Compare OnePass and localframe ensemble node errors, predicted displacement, direction cosine, and target progress in the frozen `<1`, `1–2`, `2–4`, and `>=4 nm` target-motion bins.
3. Fit a constant target displacement per domain and a proper rigid transform per domain using validation labels only. Report per-design macro RMSD and pooled squared-error reduction relative to identity. Mark both as non-deployable oracle upper bounds.
4. Report per-design domain counts, group sizes, and translation/rigid-motion coherence. No node-level significance claims; designs are the independent units.

## Provenance

Hash the OnePass checkpoint, data manifest and split bytes, Phase 1 validation artifacts, localframe prediction archives and checkpoints, localframe source, and this audit script before and after. Preserve inputs and prior experiment outputs. Save the exact 14 validation IDs and `test_ids_loaded=false`, `test_rows_read=false`, `test_prediction_keys_read=false` flags.

## Decision use

If per-domain rigid oracle approaches or beats 1.2 nm and yields a substantial reduction over identity, prioritize a preregistered trainable coarse-domain transform plus local residual experiment. If it remains far above 1.2 nm, domain rigidity alone is insufficient; do not present it as the next solution. In either case, this audit itself does not count as a model improvement.
