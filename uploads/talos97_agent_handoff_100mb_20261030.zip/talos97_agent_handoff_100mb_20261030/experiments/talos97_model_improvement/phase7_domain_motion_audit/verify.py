#!/usr/bin/env python3
"""Independently recompute Phase 7 validation-only audit outputs."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE / "results"
DATA = ROOT / "experiments/talos97_endpoint_v1/data"
PHASE1 = ROOT / "experiments/talos97_model_improvement/phase1_error_localization/results"
LOCAL = ROOT / "experiments/talos97_localframe_2m"
NM = 40.0 * 0.8518
BIN_NAMES = ["<1nm", "1-2nm", "2-4nm", ">=4nm"]
MODELS = ("OnePass", "localframe_ensemble")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def array_sha256(array: np.ndarray) -> str:
    a = np.ascontiguousarray(array)
    h = hashlib.sha256()
    h.update(str(a.dtype).encode())
    h.update(json.dumps(a.shape).encode())
    h.update(a.tobytes())
    return h.hexdigest()


def close(actual: float, expected: float, tol: float = 1e-8) -> bool:
    return bool(np.isfinite(actual) and np.isfinite(expected) and abs(float(actual) - float(expected)) <= tol)


def rmsd(pred: np.ndarray, target: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.sum((pred - target) ** 2, axis=-1))))


def target_bin(motion: np.ndarray) -> np.ndarray:
    return np.select([motion < 1.0, motion < 2.0, motion < 4.0], BIN_NAMES[:3], default=BIN_NAMES[3])


def fit_domain_oracles(source: np.ndarray, target: np.ndarray, domain_ids: np.ndarray):
    """Independent label-fitted diagnostic; never a deployable prediction."""
    translation = np.empty_like(source)
    rigid = np.empty_like(source)
    sizes = []
    rigid_groups = 0
    fallback_groups = 0
    for domain in np.unique(domain_ids):
        idx = np.flatnonzero(domain_ids == domain)
        x = source[idx]
        y = target[idx]
        sizes.append(len(idx))
        translation[idx] = x + (y - x).mean(axis=0)
        if len(idx) < 6:
            rigid[idx] = translation[idx]
            fallback_groups += 1
            continue
        xc = x - x.mean(axis=0, keepdims=True)
        yc = y - y.mean(axis=0, keepdims=True)
        u, _, vt = np.linalg.svd(xc.T @ yc, full_matrices=False)
        correction = np.eye(3, dtype=np.float64)
        correction[-1, -1] = 1.0 if np.linalg.det(u @ vt) >= 0 else -1.0
        rotation = u @ correction @ vt
        rigid[idx] = xc @ rotation + y.mean(axis=0, keepdims=True)
        rigid_groups += 1
    metadata = {
        "domain_count": len(sizes),
        "domain_size_min": int(min(sizes)),
        "domain_size_median": float(np.median(sizes)),
        "domain_size_max": int(max(sizes)),
        "domains_rigid_fit_n_ge_6": rigid_groups,
        "domains_using_translation_fallback_n_lt_6": fallback_groups,
    }
    return translation, rigid, metadata


def row_matches(actual: dict[str, str], expected: dict[str, float], tol: float = 1e-7) -> bool:
    return all(close(float(actual[key]), value, tol) for key, value in expected.items())


def build_motion_rows(model_arrays: dict[str, dict[str, tuple[np.ndarray, ...]]]):
    aggregate_rows = []
    design_rows = []
    for model_name in MODELS:
        arrays = model_arrays[model_name]
        total_nodes = sum(len(values[0]) for values in arrays.values())
        total_sse = sum(float(np.square(values[1]).sum()) for values in arrays.values())
        for bin_name in BIN_NAMES:
            by_design = []
            for ident, values in arrays.items():
                motion, error, pred_motion, cosine, progress = values
                mask = target_bin(motion) == bin_name
                if not mask.any():
                    continue
                count = int(mask.sum())
                error_sse = float(np.square(error[mask]).sum())
                row = {
                    "model": model_name,
                    "design": ident,
                    "target_motion_bin": bin_name,
                    "n_nodes": count,
                    "node_rmse_nm": float(np.sqrt(error_sse / count)),
                    "mean_target_motion_nm": float(np.mean(motion[mask])),
                    "mean_pred_motion_nm": float(np.mean(pred_motion[mask])),
                    "mean_direction_cosine": float(np.mean(cosine[mask])),
                    "mean_target_progress": float(np.mean(progress[mask])),
                    "fraction_squared_error": error_sse / max(total_sse, 1e-30),
                }
                by_design.append(row)
                design_rows.append(row)
            count = sum(row["n_nodes"] for row in by_design)
            bin_sse = sum(row["node_rmse_nm"] ** 2 * row["n_nodes"] for row in by_design)
            weights = [row["n_nodes"] for row in by_design]
            aggregate_rows.append({
                "model": model_name,
                "target_motion_bin": bin_name,
                "n_nodes": count,
                "fraction_nodes": count / total_nodes,
                "pooled_node_rmse_nm": float(np.sqrt(bin_sse / max(count, 1))),
                "mean_design_node_rmse_nm": float(np.mean([row["node_rmse_nm"] for row in by_design])),
                "mean_target_motion_nm": float(np.average([row["mean_target_motion_nm"] for row in by_design], weights=weights)),
                "mean_pred_motion_nm": float(np.average([row["mean_pred_motion_nm"] for row in by_design], weights=weights)),
                "mean_direction_cosine": float(np.average([row["mean_direction_cosine"] for row in by_design], weights=weights)),
                "mean_target_progress": float(np.average([row["mean_target_progress"] for row in by_design], weights=weights)),
                "fraction_squared_error": sum(row["fraction_squared_error"] for row in by_design),
            })
    return aggregate_rows, design_rows


def main() -> int:
    summary = json.loads((OUT / "summary.json").read_text())
    phase1 = json.loads((PHASE1 / "summary.json").read_text())
    validation_ids = list(phase1["validation_ids"])
    validation_set = set(validation_ids)
    per_design = list(csv.DictReader((OUT / "per_design.csv").open(newline="")))
    motion = list(csv.DictReader((OUT / "motion_bins.csv").open(newline="")))
    motion_design = list(csv.DictReader((OUT / "motion_bins_by_design.csv").open(newline="")))
    p1_rows = list(csv.DictReader((PHASE1 / "per_design.csv").open(newline="")))
    p1_scores = {
        row["design"]: float(row["rmsd_nm"])
        for row in p1_rows
        if row["model"] == "OnePass" and row["design"] in validation_set
    }
    onepass_nodes = [
        row for row in csv.DictReader((PHASE1 / "node_errors.csv").open(newline=""))
        if row["model"] == "OnePass" and row["design"] in validation_set
    ]

    checks: dict[str, bool] = {}
    checks["fixed_14_validation_designs_only"] = bool(
        len(validation_ids) == 14
        and len(validation_set) == 14
        and len(per_design) == 14
        and {row["design"] for row in per_design} == validation_set
        and set(summary.get("validation_ids", [])) == validation_set
        and all(row["design"] in validation_set for row in motion_design)
    )
    checks["onepass_phase1_rows_are_complete"] = bool(
        set(p1_scores) == validation_set
        and len(onepass_nodes) == sum(int(row["nodes"]) for row in per_design)
        and {row["design"] for row in onepass_nodes} == validation_set
    )

    model_arrays: dict[str, dict[str, tuple[np.ndarray, ...]]] = {
        "OnePass": {},
        "localframe_ensemble": {},
    }
    by_design = {row["design"]: row for row in per_design}
    oracle_rows = {}
    identity_sse_total = 0.0
    translation_sse_total = 0.0
    rigid_sse_total = 0.0
    observed_prediction_hashes: dict[str, dict[str, str]] = {str(seed): {} for seed in (11, 22, 33)}
    archives = {
        seed: np.load(LOCAL / "results" / "predictions" / f"frame_{seed}.npz")
        for seed in (11, 22, 33)
    }
    try:
        for ident in validation_ids:
            with np.load(DATA / "inputs" / f"{ident}.npz") as inp:
                source = np.asarray(inp["pos"], dtype=np.float64) * NM
                domain_ids = np.asarray(inp["domain_ids"], dtype=np.int64)
            with np.load(DATA / "labels" / f"{ident}.npz") as label:
                target = np.asarray(label["target_pos"], dtype=np.float64) * NM
            if source.shape != target.shape or source.shape[0] != len(domain_ids):
                raise ValueError(f"input/label/domain shape mismatch for validation design {ident}")

            p1 = [row for row in onepass_nodes if row["design"] == ident]
            if len(p1) != len(source) or len({row["node"] for row in p1}) != len(source):
                raise ValueError(f"Phase 1 OnePass node rows are incomplete or duplicated for {ident}")
            onepass_values = tuple(np.asarray([float(row[key]) for row in p1]) for key in (
                "target_motion_nm", "node_error_nm", "pred_motion_nm", "direction_cosine", "target_progress"
            ))
            model_arrays["OnePass"][ident] = onepass_values

            deltas = []
            for seed, archive in archives.items():
                # Index only the frozen validation key; never enumerate archive keys.
                prediction_delta = np.asarray(archive[ident])
                if prediction_delta.shape != source.shape or not np.isfinite(prediction_delta).all():
                    raise ValueError(f"invalid validation prediction for {ident}, seed {seed}")
                observed_prediction_hashes[str(seed)][ident] = array_sha256(prediction_delta)
                deltas.append(prediction_delta.astype(np.float64))
            ensemble_delta = np.mean(deltas, axis=0)
            ensemble_prediction = source + ensemble_delta
            motion_nodes = np.linalg.norm(target - source, axis=1)
            error_nodes = np.linalg.norm(ensemble_prediction - target, axis=1)
            predicted_motion = np.linalg.norm(ensemble_delta, axis=1)
            dot = np.sum(ensemble_delta * (target - source), axis=1)
            cosine = dot / np.maximum(predicted_motion * motion_nodes, 1e-12)
            progress = dot / np.maximum(motion_nodes ** 2, 1e-12)
            model_arrays["localframe_ensemble"][ident] = (
                motion_nodes, error_nodes, predicted_motion, cosine, progress
            )

            translation, rigid, meta = fit_domain_oracles(source, target, domain_ids)
            identity_error = rmsd(source, target)
            translation_error = rmsd(translation, target)
            rigid_error = rmsd(rigid, target)
            target_sse = float(np.square(target - source).sum())
            translation_sse = float(np.square(translation - target).sum())
            rigid_sse = float(np.square(rigid - target).sum())
            identity_sse_total += target_sse
            translation_sse_total += translation_sse
            rigid_sse_total += rigid_sse
            oracle_rows[ident] = {
                "identity_rmsd_nm": identity_error,
                "localframe_ensemble_rmsd_nm": rmsd(ensemble_prediction, target),
                "domain_translation_oracle_rmsd_nm": translation_error,
                "domain_rigid_oracle_rmsd_nm": rigid_error,
                "domain_translation_sse_reduction_vs_identity": 1.0 - translation_sse / max(target_sse, 1e-30),
                "domain_rigid_sse_reduction_vs_identity": 1.0 - rigid_sse / max(target_sse, 1e-30),
                **meta,
            }
            if len(source) != int(by_design[ident]["nodes"]):
                checks["per_design_node_counts_recompute"] = False
    finally:
        for archive in archives.values():
            archive.close()

    checks.setdefault("per_design_node_counts_recompute", True)
    checks["per_design_metrics_recompute"] = bool(
        all(ident in by_design for ident in validation_ids)
        and all(close(float(by_design[ident]["onepass_rmsd_nm"]), p1_scores[ident], 1e-4) for ident in validation_ids)
        and all(
            row_matches(by_design[ident], {
                "identity_rmsd_nm": oracle_rows[ident]["identity_rmsd_nm"],
                "localframe_ensemble_rmsd_nm": oracle_rows[ident]["localframe_ensemble_rmsd_nm"],
            })
            for ident in validation_ids
        )
    )
    checks["domain_oracle_metrics_and_group_metadata_recompute"] = bool(
        all(
            row_matches(by_design[ident], {
                key: value for key, value in oracle_rows[ident].items()
                if key not in ("domain_count", "domain_size_min", "domain_size_median", "domain_size_max",
                               "domains_rigid_fit_n_ge_6", "domains_using_translation_fallback_n_lt_6")
            })
            and all(
                int(by_design[ident][key]) == int(oracle_rows[ident][key])
                for key in ("domain_count", "domain_size_min", "domain_size_max",
                            "domains_rigid_fit_n_ge_6", "domains_using_translation_fallback_n_lt_6")
            )
            and close(float(by_design[ident]["domain_size_median"]), oracle_rows[ident]["domain_size_median"])
            for ident in validation_ids
        )
        and all(
            float(by_design[ident]["domain_translation_oracle_rmsd_nm"])
            <= float(by_design[ident]["identity_rmsd_nm"]) + 1e-8
            and float(by_design[ident]["domain_rigid_oracle_rmsd_nm"])
            <= float(by_design[ident]["identity_rmsd_nm"]) + 1e-8
            for ident in validation_ids
        )
        and summary.get("oracle_fits_use_validation_labels") is True
        and summary.get("domain_oracles_are_deployable_predictions") is False
    )

    expected_motion, expected_motion_design = build_motion_rows(model_arrays)
    aggregate_keys = (
        "n_nodes", "fraction_nodes", "pooled_node_rmse_nm", "mean_design_node_rmse_nm",
        "mean_target_motion_nm", "mean_pred_motion_nm", "mean_direction_cosine",
        "mean_target_progress", "fraction_squared_error",
    )
    design_keys = (
        "n_nodes", "node_rmse_nm", "mean_target_motion_nm", "mean_pred_motion_nm",
        "mean_direction_cosine", "mean_target_progress", "fraction_squared_error",
    )
    actual_motion = {(row["model"], row["target_motion_bin"]): row for row in motion}
    expected_motion_map = {(row["model"], row["target_motion_bin"]): row for row in expected_motion}
    actual_design_motion = {
        (row["model"], row["design"], row["target_motion_bin"]): row for row in motion_design
    }
    expected_design_motion = {
        (row["model"], row["design"], row["target_motion_bin"]): row for row in expected_motion_design
    }
    checks["all_motion_bin_metrics_recompute"] = bool(
        set(actual_motion) == set(expected_motion_map)
        and all(
            row_matches(actual_motion[key], {field: float(expected_motion_map[key][field]) for field in aggregate_keys})
            and int(actual_motion[key]["n_nodes"]) == expected_motion_map[key]["n_nodes"]
            for key in expected_motion_map
        )
        and set(actual_design_motion) == set(expected_design_motion)
        and all(
            row_matches(actual_design_motion[key], {field: float(expected_design_motion[key][field]) for field in design_keys})
            and int(actual_design_motion[key]["n_nodes"]) == expected_design_motion[key]["n_nodes"]
            for key in expected_design_motion
        )
        and sum(len(values[0]) for values in model_arrays["OnePass"].values())
        == sum(len(values[0]) for values in model_arrays["localframe_ensemble"].values())
        == summary.get("validation_node_count")
    )

    observed_archive_hashes = {
        str(seed): sha256(LOCAL / "results" / "predictions" / f"frame_{seed}.npz")
        for seed in (11, 22, 33)
    }
    checks["only_validation_prediction_arrays_accessed"] = bool(
        observed_prediction_hashes == summary.get("localframe_validation_prediction_array_sha256")
        and all(set(rows) == validation_set for rows in observed_prediction_hashes.values())
    )
    checks["prediction_archives_hashed_and_unchanged"] = bool(
        observed_archive_hashes == summary.get("localframe_prediction_archive_sha256")
        and all(
            str((LOCAL / "results" / "predictions" / f"frame_{seed}.npz").resolve()) in summary.get("hashes_before", {})
            for seed in (11, 22, 33)
        )
    )

    hashes_before = summary.get("hashes_before", {})
    hashes_after = summary.get("hashes_after", {})
    current_hashes = {path: sha256(Path(path)) for path in hashes_before}
    checks["protected_sources_inputs_labels_checkpoints_and_split_unchanged"] = bool(
        bool(hashes_before)
        and hashes_before == hashes_after == current_hashes
        and current_hashes.get(str((ROOT / "experiments/talos97_endpoint_v1/runs/painn_onepass/best.pt").resolve()))
        == phase1["protected_sha256_before"]["OnePass_best"]
    )

    model_metrics = {
        "onepass_macro_rmsd_nm": float(np.mean([p1_scores[ident] for ident in validation_ids])),
        "identity_macro_rmsd_nm": float(np.mean([oracle_rows[ident]["identity_rmsd_nm"] for ident in validation_ids])),
        "localframe_ensemble_macro_rmsd_nm": float(np.mean([oracle_rows[ident]["localframe_ensemble_rmsd_nm"] for ident in validation_ids])),
    }
    checks["summary_macro_and_oracle_aggregates_recompute"] = bool(
        all(close(summary["models"][key], value) for key, value in model_metrics.items())
        and close(summary["domain_translation_macro_rmsd_nm"], np.mean([
            oracle_rows[ident]["domain_translation_oracle_rmsd_nm"] for ident in validation_ids
        ]))
        and close(summary["domain_rigid_macro_rmsd_nm"], np.mean([
            oracle_rows[ident]["domain_rigid_oracle_rmsd_nm"] for ident in validation_ids
        ]))
        and close(summary["domain_translation_pooled_sse_reduction"], 1.0 - translation_sse_total / max(identity_sse_total, 1e-30))
        and close(summary["domain_rigid_pooled_sse_reduction"], 1.0 - rigid_sse_total / max(identity_sse_total, 1e-30))
    )
    checks["test_split_and_model_state_untouched"] = bool(
        summary.get("test_ids_loaded") is False
        and summary.get("test_rows_read") is False
        and summary.get("test_prediction_keys_read") is False
        and summary.get("model_inference") is False
        and summary.get("optimizer_steps") == 0
        and summary.get("original_checkpoints_modified") is False
        and checks["only_validation_prediction_arrays_accessed"]
    )

    verification = {
        "passed": all(checks.values()),
        "checks": checks,
        "validation_design_count": len(validation_ids),
        "validation_node_count": summary.get("validation_node_count"),
        "models": model_metrics,
        "domain_translation_oracle_macro_rmsd_nm": summary.get("domain_translation_macro_rmsd_nm"),
        "domain_rigid_oracle_macro_rmsd_nm": summary.get("domain_rigid_macro_rmsd_nm"),
        "test_ids_loaded": False,
        "test_rows_read": False,
        "test_prediction_keys_read": False,
        "model_inference": False,
        "optimizer_steps": 0,
        "original_checkpoints_modified": False,
    }
    (OUT / "verification.json").write_text(json.dumps(verification, indent=2) + "\n")
    print(json.dumps(verification, indent=2))
    return 0 if verification["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
