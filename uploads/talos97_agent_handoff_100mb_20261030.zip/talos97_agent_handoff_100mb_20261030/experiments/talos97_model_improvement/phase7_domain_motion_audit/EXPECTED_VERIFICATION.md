# Phase 7 expected verification

Run from the repository root:

```bash
/home/lijingjing/lijj/users/lht2/deeporigami/agent/hado_mechanical_pilot/.venv-torch/bin/python -m py_compile experiments/talos97_model_improvement/phase7_domain_motion_audit/analyze.py experiments/talos97_model_improvement/phase7_domain_motion_audit/verify.py
/home/lijingjing/lijj/users/lht2/deeporigami/agent/hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase7_domain_motion_audit/analyze.py
/home/lijingjing/lijj/users/lht2/deeporigami/agent/hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase7_domain_motion_audit/verify.py
```

Required checks:

- Exactly the frozen 14 validation IDs appear in all per-design outputs; no other design IDs appear.
- OnePass per-design results match the frozen Phase 1 report within `1e-4 nm`; saved localframe ensemble values recompute from only the three validation prediction keys and validation labels.
- Every per-design and pooled motion-bin metric recomputes from Phase 1 validation node rows or the saved localframe validation predictions, using the fixed bin edges.
- The verifier independently refits domain translation and proper rotations from validation labels, recomputes each oracle RMSD, per-design group metadata, macro score, and pooled SSE reduction. Both oracle types must be finite, no worse than source identity up to numerical tolerance, and explicitly marked as label-fitted validation diagnostics.
- Input, label, complete prediction-archive byte, selected validation-array, checkpoint, source, manifest, split-byte, and Phase 1 artifact hashes match before/after. Only the 14 validation keys are indexed and decoded from prediction archives; archives are not enumerated.
- `test_ids_loaded`, `test_rows_read`, and `test_prediction_keys_read` are all false; zero model inference and optimizer steps; original OnePass/localframe checkpoints are unchanged.

The audit may not be described as training or proof of deployable domain-transform performance.
