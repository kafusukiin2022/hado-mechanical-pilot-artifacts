#!/usr/bin/env python3
"""Independent verification for the Phase 10 matched domain-transform run."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = ROOT / "experiments/talos97_localframe_2m"
DATA = ROOT / "experiments/talos97_endpoint_v1/data"
PHASE1 = ROOT / "experiments/talos97_model_improvement/phase1_error_localization/results"
RUNS = HERE / "runs"
RESULTS = HERE / "results"
SEEDS = (11, 22, 33)
ARMS = ("control", "domain_graph")
NM = 40.0 * 0.8518
WIDTH = 346
SOURCE_PATHS = (
    HERE / "SPEC.md",
    HERE / "EXPECTED_VERIFICATION.md",
    HERE / "run_experiment.py",
    HERE / "verify_results.py",
    BASE / "model.py",
    BASE / "run_full97.py",
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def close(a: float, b: float, tol: float = 1e-6) -> bool:
    return bool(np.isfinite(a) and np.isfinite(b) and abs(float(a) - float(b)) <= tol)


def rmsd(prediction: np.ndarray, target: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.sum((prediction - target) ** 2, axis=-1))))


def read_only_train_validation_ids(path: Path) -> tuple[list[str], list[str]]:
    """Parse through the validation JSON array and stop before the test key/value."""
    # Import only the streaming parser; it returns immediately after validation.
    import importlib.util
    spec = importlib.util.spec_from_file_location("phase10_runner_for_split", HERE / "run_experiment.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load split streaming parser")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.read_train_validation_ids(path)


def hash_expected_paths(hashes: dict[str, str]) -> dict[str, str]:
    return {path: sha256(Path(path)) for path in hashes}


def load_val_data(ident: str) -> tuple[np.ndarray, np.ndarray]:
    with np.load(DATA / "inputs" / f"{ident}.npz") as inp:
        source = np.asarray(inp["pos"], dtype=np.float64)
    with np.load(DATA / "labels" / f"{ident}.npz") as label:
        target = np.asarray(label["target_pos"], dtype=np.float64)
    if source.shape != target.shape:
        raise ValueError(f"input/target shape mismatch for validation design {ident}")
    return source, (target - source) * NM


def verify_run(seed: int, arm: str, validation_ids: list[str]) -> dict:
    run_dir = RUNS / f"seed{seed}_{arm}"
    status = json.loads((run_dir / "status.json").read_text())
    if not status.get("complete"):
        raise ValueError(f"run not marked complete: seed={seed} arm={arm}")
    rows = [json.loads(line) for line in (run_dir / "history.jsonl").read_text().splitlines() if line.strip()]
    epochs = [int(row["epoch"]) for row in rows]
    if epochs != list(range(51)):
        raise ValueError(f"expected epoch 0..50, got {epochs[:3]}...{epochs[-3:]}")
    if any(not np.isfinite(float(row["validation_macro_rmsd_nm"])) for row in rows):
        raise ValueError(f"non-finite validation history: seed={seed} arm={arm}")
    if arm == "domain_graph":
        branch_rows = [row for row in rows if int(row["epoch"]) > 0]
        for branch in ("domain_gate", "translation_head", "rotation_head", "projector", "message_0", "message_1", "message_2"):
            gradients = [float(row["branch_gradient_abs_mean"][branch]) for row in branch_rows]
            if not gradients or not np.isfinite(gradients).all() or max(gradients) <= 0:
                raise ValueError(f"missing nonzero training gradients for {branch}, seed={seed}")
    per_design = list(csv.DictReader((run_dir / "per_design_validation.csv").open(newline="")))
    if len(per_design) != 14 or {row["design"] for row in per_design} != set(validation_ids):
        raise ValueError(f"invalid selected per-design rows for seed={seed} arm={arm}")
    if any(row["seed"] != str(seed) or row["arm"] != arm for row in per_design):
        raise ValueError(f"incorrect selected validation metadata for seed={seed} arm={arm}")
    selected_epoch = int(status["best_epoch"])
    if selected_epoch != min(range(51), key=lambda e: rows[e]["validation_macro_rmsd_nm"]):
        raise ValueError("best epoch not selected from history")
    if any(int(row["epoch"]) != selected_epoch for row in per_design):
        raise ValueError(f"per-design rows have wrong selected epoch for seed={seed} arm={arm}")
    prediction_path = run_dir / "validation_predictions.npz"
    checkpoint_path = run_dir / "best.pt"
    if sha256(prediction_path) != status["validation_prediction_sha256"] or sha256(checkpoint_path) != status["best_checkpoint_sha256"]:
        raise ValueError(f"selected artifact hash mismatch for seed={seed} arm={arm}")
    with np.load(prediction_path) as predictions:
        keys = set(predictions.files)
        if keys != set(validation_ids):
            raise ValueError(f"prediction archive is not validation-only for seed={seed} arm={arm}")
        design_metrics = {}
        for ident in validation_ids:
            source_pos, target_delta = load_val_data(ident)
            predicted_delta = np.asarray(predictions[ident], dtype=np.float64)
            if predicted_delta.shape != target_delta.shape or not np.isfinite(predicted_delta).all():
                raise ValueError(f"invalid selected validation prediction {ident}")
            design_metrics[ident] = rmsd(predicted_delta, target_delta)
    per_design_map = {row["design"]: row for row in per_design}
    if any(not close(design_metrics[ident], float(per_design_map[ident]["rmsd_nm"]), 1e-6) for ident in validation_ids):
        raise ValueError(f"selected validation RMSD does not recompute for seed={seed} arm={arm}")
    macro = float(np.mean(list(design_metrics.values())))
    if not close(macro, float(status["best_validation_macro_rmsd_nm"]), 1e-6):
        raise ValueError(f"selected macro RMSD does not match status for seed={seed} arm={arm}")
    history_selected = rows[selected_epoch]
    if not close(macro, float(history_selected["validation_macro_rmsd_nm"]), 1e-6):
        raise ValueError(f"selected macro RMSD does not match history for seed={seed} arm={arm}")
    return {
        "seed": seed,
        "arm": arm,
        "selected_epoch": selected_epoch,
        "macro_rmsd_nm": macro,
        "per_design_rmsd_nm": design_metrics,
        "history_rows": len(rows),
        "max_domain_gate_gradient": max((float(r["branch_gradient_abs_mean"]["domain_gate"]) for r in rows[1:]), default=0.0) if arm == "domain_graph" else 0.0,
        "max_translation_head_gradient": max((float(r["branch_gradient_abs_mean"]["translation_head"]) for r in rows[1:]), default=0.0) if arm == "domain_graph" else 0.0,
        "max_rotation_head_gradient": max((float(r["branch_gradient_abs_mean"]["rotation_head"]) for r in rows[1:]), default=0.0) if arm == "domain_graph" else 0.0,
        "prediction_keys": sorted(keys),
    }


def main() -> int:
    summary = json.loads((RESULTS / "summary.json").read_text())
    train_ids, validation_ids = read_only_train_validation_ids(DATA / "split.json")
    phase1_ids = json.loads((PHASE1 / "summary.json").read_text())["validation_ids"]
    checks: dict[str, bool] = {}

    checks["frozen_68_14_split_and_access_boundary"] = bool(
        len(train_ids) == 68 and len(validation_ids) == 14
        and validation_ids == phase1_ids
        and len(set(train_ids + validation_ids)) == 82
        and summary.get("train_ids") == train_ids
        and summary.get("validation_ids") == validation_ids
        and summary.get("test_ids_decoded") is False
        and summary.get("test_input_files_opened") is False
        and summary.get("test_label_files_opened") is False
        and summary.get("test_prediction_keys_read") is False
        and summary.get("test_inference") is False
        and summary.get("data_access_manifest", {}).get("split_parser_stopped_after") == "validation"
        and summary.get("data_access_manifest", {}).get("input_design_ids_opened") == train_ids + validation_ids
        and summary.get("data_access_manifest", {}).get("label_design_ids_opened") == train_ids + validation_ids
    )
    checks["run_order_and_epoch_coverage"] = True
    expected_order = [(seed, arm) for seed in SEEDS for arm in ARMS]
    observed_order = [(int(row["seed"]), row["arm"]) for row in summary.get("runs", [])]
    checks["run_order_and_epoch_coverage"] = observed_order == expected_order
    verified_runs = {}
    for seed in SEEDS:
        for arm in ARMS:
            verified_runs[(seed, arm)] = verify_run(seed, arm, validation_ids)
    checks["all_six_runs_and_selected_metrics_recompute"] = all(
        verified_runs[(seed, arm)]["history_rows"] == 51
        and np.isfinite(verified_runs[(seed, arm)]["macro_rmsd_nm"])
        for seed in SEEDS for arm in ARMS
    )
    checks["paired_training_orders_match"] = True
    for seed in SEEDS:
        left = [json.loads(line) for line in (RUNS / f"seed{seed}_control/history.jsonl").read_text().splitlines()]
        right = [json.loads(line) for line in (RUNS / f"seed{seed}_domain_graph/history.jsonl").read_text().splitlines()]
        checks["paired_training_orders_match"] &= all(
            left[epoch]["branch_gradient_abs_mean"].get("train_order_sha256")
            == right[epoch]["branch_gradient_abs_mean"].get("train_order_sha256")
            for epoch in range(1, 51)
        )

    paired = {}
    seed_differences = []
    max_design_regression = -float("inf")
    for seed in SEEDS:
        control = verified_runs[(seed, "control")]
        candidate = verified_runs[(seed, "domain_graph")]
        difference = candidate["macro_rmsd_nm"] - control["macro_rmsd_nm"]
        seed_differences.append(difference)
        max_design_regression = max(
            max_design_regression,
            max(candidate["per_design_rmsd_nm"][ident] - control["per_design_rmsd_nm"][ident] for ident in validation_ids),
        )
        paired[str(seed)] = {
            "control_macro_rmsd_nm": control["macro_rmsd_nm"],
            "domain_graph_macro_rmsd_nm": candidate["macro_rmsd_nm"],
            "candidate_minus_control_nm": difference,
            "best_epochs": {"control": control["selected_epoch"], "domain_graph": candidate["selected_epoch"]},
        }
    control_macro_mean = float(np.mean([verified_runs[(seed, "control")]["macro_rmsd_nm"] for seed in SEEDS]))
    candidate_macro_mean = float(np.mean([verified_runs[(seed, "domain_graph")]["macro_rmsd_nm"] for seed in SEEDS]))
    improvement = control_macro_mean - candidate_macro_mean
    seeds_improved = sum(delta < 0 for delta in seed_differences)
    promising = bool(
        improvement >= 0.05 and seeds_improved >= 2 and max_design_regression <= 0.20
    )
    # Verification checks that the preregistered decision inputs are finite
    # and available. A scientifically negative screen is a valid experiment,
    # not a verification failure.
    checks["predeclared_promising_rule_recomputed"] = bool(
        len(seed_differences) == 3
        and np.isfinite([*seed_differences, improvement, max_design_regression]).all()
        and 0 <= seeds_improved <= 3
    )
    checks["branch_gradients_reach_gate_and_both_heads"] = bool(all(
        verified_runs[(seed, "domain_graph")][key] > 0
        for seed in SEEDS for key in (
            "max_domain_gate_gradient", "max_translation_head_gradient", "max_rotation_head_gradient"
        )
    ))

    ensembles = {}
    for arm in ARMS:
        ensemble_per_design = {}
        for ident in validation_ids:
            deltas = []
            for seed in SEEDS:
                archive = np.load(RUNS / f"seed{seed}_{arm}/validation_predictions.npz")
                try:
                    deltas.append(np.asarray(archive[ident], dtype=np.float64))
                finally:
                    archive.close()
            _, target_delta = load_val_data(ident)
            ensemble_per_design[ident] = rmsd(np.mean(deltas, axis=0), target_delta)
        ensembles[arm] = {
            "per_design_rmsd_nm": ensemble_per_design,
            "macro_rmsd_nm": float(np.mean(list(ensemble_per_design.values()))),
        }
    checks["ensemble_metrics_recompute"] = bool(
        all(np.isfinite(row["macro_rmsd_nm"]) for row in ensembles.values())
        and set(ensembles["control"]["per_design_rmsd_nm"]) == set(validation_ids)
        and set(ensembles["domain_graph"]["per_design_rmsd_nm"]) == set(validation_ids)
    )

    hashes_before = summary.get("hashes_before", {})
    hashes_after = summary.get("hashes_after", {})
    current = hash_expected_paths(hashes_before.get("selected_design_data_sha256", {}))
    checkpoint_current = {
        seed: sha256(BASE / "checkpoints" / f"frame_{seed}.pt") for seed in SEEDS
    }
    source_current = {str(path.resolve()): sha256(path) for path in SOURCE_PATHS}
    checks["data_checkpoint_source_and_split_hashes_unchanged"] = bool(
        hashes_before == hashes_after
        and current == hashes_before.get("selected_design_data_sha256", {})
        and sha256(DATA / "split.json") == hashes_before.get("split_sha256")
        and sha256(DATA / "manifest.json") == hashes_before.get("manifest_sha256")
        and {str(seed): value for seed, value in checkpoint_current.items()}
        == hashes_before.get("frozen_checkpoint_sha256")
        and source_current == hashes_before.get("source_sha256")
        and hashes_before.get("frozen_checkpoint_sha256") == hashes_after.get("frozen_checkpoint_sha256")
    )
    checks["only_phase10_output_paths_written"] = bool(
        bool(summary.get("output_paths"))
        and all(Path(path).resolve().is_relative_to(HERE.resolve()) for path in summary.get("output_paths", []))
        and summary.get("original_checkpoints_modified") is False
        and summary.get("optimizer_steps") == 6 * 50 * 68
    )

    extra = verify_checkpoints_and_diagnostics(train_ids, validation_ids)
    checks.update(extra["checks"])
    verification = {
        "additional_verification": extra,
        "passed": all(checks.values()),
        "checks": checks,
        "paired_seed_results": paired,
        "control_seed_mean_macro_rmsd_nm": control_macro_mean,
        "domain_graph_seed_mean_macro_rmsd_nm": candidate_macro_mean,
        "mean_candidate_minus_control_nm": candidate_macro_mean - control_macro_mean,
        "mean_improvement_nm": improvement,
        "seeds_improved": seeds_improved,
        "maximum_per_design_regression_nm": max_design_regression,
        "promising_by_preregistered_rule": promising,
        "ensemble_results": ensembles,
        "absolute_target_1_2_nm_reached_by_candidate_seed_mean": candidate_macro_mean <= 1.2,
        "absolute_target_1_2_nm_reached_by_candidate_ensemble": ensembles["domain_graph"]["macro_rmsd_nm"] <= 1.2,
        "validation_design_count": len(validation_ids),
        "train_design_count": len(train_ids),
        "test_ids_decoded": False,
        "test_input_files_opened": False,
        "test_label_files_opened": False,
        "test_prediction_keys_read": False,
        "test_inference": False,
        "original_checkpoints_modified": False,
    }
    verification["verifier_sha256"] = sha256(Path(__file__).resolve())
    (RESULTS / "verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(verification, ensure_ascii=False, indent=2))
    return 0 if verification["passed"] else 1


def verify_checkpoints_and_diagnostics(train_ids, validation_ids):
    import importlib.util
    import torch
    spec = importlib.util.spec_from_file_location("phase10_checkpoint_reproduction", HERE / "run_experiment.py")
    runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
    torch.set_num_threads(2)
    device = torch.device("cpu")
    max_difference = 0.; maximum_metric_difference = 0.
    diagnostics = {}; coarse_recompute_ok = True
    for ident in train_ids + validation_ids:
        raw = runner.build_raw(ident); graph = runner.coarse_graph(raw, device)
        # Independent dictionary aggregation, distinct from runner's vectorized grouping.
        pairs = {}; domain = np.unique(raw["domain_ids"], return_inverse=True)[1]
        for (i, j), typ in zip(raw["edge_index"].T, raw["edge_types"]):
            a,b = int(domain[i]), int(domain[j])
            if a != b:
                pairs.setdefault((a,b), np.zeros(5, np.int64))[int(typ)] += 1
        actual = {tuple(pair): value for pair, value in zip(graph["edges"].T.numpy(), graph["relation_counts"].numpy())}
        coarse_recompute_ok &= set(actual) == set(pairs) and all(np.array_equal(actual[key], pairs[key]) for key in pairs)
    for seed in SEEDS:
        for arm in ARMS:
            model = runner.make_model(seed, arm, device)
            ck = torch.load(RUNS / f"seed{seed}_{arm}/best.pt", map_location=device, weights_only=False)
            model.load_state_dict(ck["state"], strict=True); model.eval()
            rows = []
            with np.load(RUNS / f"seed{seed}_{arm}/validation_predictions.npz") as saved, torch.no_grad():
                for ident in validation_ids:
                    d = runner.load_design(ident, device, True)
                    if arm == "domain_graph":
                        details = model.forward_details(d["s"], d["B"], d["R"], d["source_pos"], d["domain_ids"], d["coarse"])
                        pred = details["delta_nm"].numpy()
                    else:
                        pred = model(d["s"], d["B"], d["R"]).numpy()
                    stored = np.asarray(saved[ident]); max_difference = max(max_difference, float(np.linalg.norm(pred-stored, axis=1).max()))
                    target = d["target_delta_nm"].numpy(); source = d["source_pos"].numpy() * NM
                    mask = np.linalg.norm(target,axis=1) >= 4
                    row = dict(design=ident, long_nodes=int(mask.sum()), rmsd_nm=rmsd(pred.astype(float),target.astype(float)))
                    if mask.any():
                        true_amp = float(np.linalg.norm(target[mask],axis=1).mean())
                        row.update(long_true_mean_nm=true_amp, long_pred_mean_nm=float(np.linalg.norm(pred[mask],axis=1).mean()),
                                   long_amplitude_ratio=float(np.linalg.norm(pred[mask],axis=1).mean())/true_amp,
                                   long_endpoint_rmsd_nm=rmsd(pred[mask].astype(float),target[mask].astype(float)))
                    # Label-fitted domain oracle only for diagnostics, not used by model.
                    domain = d["coarse"]["index"].numpy(); trans_errors=[]; angles=[]; within=[]
                    for idx in range(len(d["coarse"]["frames"])):
                        m = domain == idx; xx=source[m].astype(float); yy=(source[m]+target[m]).astype(float)
                        xc=xx.mean(0); yc=yy.mean(0); u,_,vt=np.linalg.svd((xx-xc).T@(yy-yc))
                        fix=np.eye(3);fix[-1,-1]=np.linalg.det(vt.T@u.T); rr=vt.T@fix@u.T
                        fitted=(xx-xc)@rr.T+yc; within.append(rmsd(fitted,yy))
                        if arm == "domain_graph":
                            gate=float(details["domain_gate"])
                            # Rotation/translation describe the ungated raw proper-transform branch;
                            # fractional displacement gate is NOT a proper rotation interpolation.
                            tt=details["domain_translation_nm"][idx].numpy()
                            rp=details["domain_rotation"][idx].numpy()
                            trans_errors.append(float(np.linalg.norm(tt-(yc-xc))))
                            angles.append(float(np.arccos(np.clip((np.trace(rp.T@rr)-1)/2,-1,1))*180/np.pi))
                    row["domain_rigid_oracle_mean_nm"]=float(np.mean(within))
                    if arm == "domain_graph":
                        row.update(gate=gate, raw_domain_translation_error_mean_nm=float(np.mean(trans_errors)),
                                   raw_domain_rotation_error_mean_deg=float(np.mean(angles)))
                    rows.append(row)
            diagnostics[f"seed{seed}_{arm}"] = rows
    preflight=json.loads((RESULTS/"preflight.json").read_text())
    return dict(checks=dict(checkpoint_predictions_reproduced_all84=max_difference < 1e-4,
                            independently_recomputed_all_coarse_relation_counts=bool(coarse_recompute_ok),
                            functional_preflight_all_pass=bool(preflight["passed"] and all(preflight["checks"].values()))),
                checkpoint_max_prediction_difference_nm=max_difference, diagnostics=diagnostics,
                diagnostic_note="Domain transforms are raw ungated branch vs validation label-fitted oracles; diagnostics only, not inference inputs.")


if __name__ == "__main__":
    raise SystemExit(main())
