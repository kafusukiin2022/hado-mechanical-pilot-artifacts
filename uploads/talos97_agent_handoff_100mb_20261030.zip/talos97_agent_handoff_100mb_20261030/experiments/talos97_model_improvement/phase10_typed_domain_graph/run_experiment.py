#!/usr/bin/env python3
"""Matched local-frame continuation with a learned domain SE(3) residual."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import random
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import scipy
import torch
from torch import nn


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE_DIR = ROOT / "experiments/talos97_localframe_2m"
sys.path.insert(0, str(BASE_DIR))
from model import BasisNet, NM as BASIS_NM, geometry  # noqa: E402

DATA = ROOT / "experiments/talos97_endpoint_v1/data"
BASE_CHECKPOINTS = BASE_DIR / "checkpoints"
RUNS = HERE / "runs"
RESULTS = HERE / "results"
SEEDS = (11, 22, 33)
ARMS = ("control", "domain_graph")
EPOCHS = 50
NM = 40.0 * 0.8518
WIDTH = 346
RESIDUAL_BLOCKS = 8
SOURCE_PATHS = (
    HERE / "SPEC.md",
    HERE / "EXPECTED_VERIFICATION.md",
    HERE / "run_experiment.py",
    HERE / "verify_results.py",
    BASE_DIR / "model.py",
    BASE_DIR / "run_full97.py",
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def read_json_string(stream) -> str:
    first = stream.read(1)
    if first != '"':
        raise ValueError(f"expected JSON string, got {first!r}")
    chars = [first]
    escaped = False
    while True:
        char = stream.read(1)
        if not char:
            raise ValueError("truncated JSON string")
        chars.append(char)
        if escaped:
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == '"':
            return json.loads("".join(chars))


def read_id_list(stream) -> list[str]:
    while True:
        char = stream.read(1)
        if not char:
            raise ValueError("truncated split before ID list")
        if not char.isspace():
            break
    if char != "[":
        raise ValueError(f"expected ID array, got {char!r}")
    ids: list[str] = []
    while True:
        char = stream.read(1)
        while char and char.isspace():
            char = stream.read(1)
        if char == "]":
            return ids
        if char != '"':
            raise ValueError(f"expected ID string or array end, got {char!r}")
        # read_json_string expects the opening quote, which has already been consumed.
        chars = ['"']
        escaped = False
        while True:
            item = stream.read(1)
            if not item:
                raise ValueError("truncated ID string")
            chars.append(item)
            if escaped:
                escaped = False
            elif item == "\\":
                escaped = True
            elif item == '"':
                ids.append(json.loads("".join(chars)))
                break
        while True:
            delimiter = stream.read(1)
            if not delimiter:
                raise ValueError("truncated ID array")
            if not delimiter.isspace():
                break
        if delimiter == "]":
            return ids
        if delimiter != ",":
            raise ValueError(f"expected comma or array end, got {delimiter!r}")


def read_train_validation_ids(split_path: Path) -> tuple[list[str], list[str]]:
    """Decode only train and validation arrays; stop before reading test IDs."""
    with split_path.open("r", encoding="utf-8") as stream:
        while (char := stream.read(1)) and char.isspace():
            pass
        if char != "{":
            raise ValueError("split root must be an object")
        key = read_json_string_after_quote(stream)
        if key != "train":
            raise ValueError(f"expected train first in split, found {key!r}")
        expect_colon(stream)
        train_ids = read_id_list(stream)
        expect_comma(stream)
        key = read_json_string_after_quote(stream)
        if key != "validation":
            raise ValueError(f"expected validation second in split, found {key!r}")
        expect_colon(stream)
        validation_ids = read_id_list(stream)
        # Return immediately after the validation array's closing bracket.
        return train_ids, validation_ids


def read_json_string_after_quote(stream) -> str:
    while (leading := stream.read(1)) and leading.isspace():
        pass
    if leading != '"':
        raise ValueError(f"expected quoted JSON key, got {leading!r}")
    chars = ['"']
    escaped = False
    while True:
        item = stream.read(1)
        if not item:
            raise ValueError("truncated split key")
        chars.append(item)
        if escaped:
            escaped = False
        elif item == "\\":
            escaped = True
        elif item == '"':
            return json.loads("".join(chars))


def expect_colon(stream) -> None:
    while (char := stream.read(1)) and char.isspace():
        pass
    if char != ":":
        raise ValueError(f"expected colon, got {char!r}")


def expect_comma(stream) -> None:
    while (char := stream.read(1)) and char.isspace():
        pass
    if char != ",":
        raise ValueError(f"expected comma after split array, got {char!r}")


def segment_mean(values: torch.Tensor, index: torch.Tensor, count: int) -> torch.Tensor:
    result = values.new_zeros((count,) + values.shape[1:])
    result.index_add_(0, index, values)
    sizes = values.new_zeros((count,))
    sizes.index_add_(0, index, values.new_ones((len(index),)))
    shape = (count,) + (1,) * (values.ndim - 1)
    return result / sizes.clamp_min(1).reshape(shape)


def so3_exp(omega: torch.Tensor) -> torch.Tensor:
    """Stable Rodrigues exponential, with omega as an axis-angle vector."""
    x, y, z = omega.unbind(-1)
    zero = torch.zeros_like(x)
    skew = torch.stack((
        torch.stack((zero, -z, y), dim=-1),
        torch.stack((z, zero, -x), dim=-1),
        torch.stack((-y, x, zero), dim=-1),
    ), dim=-2)
    theta2 = (omega * omega).sum(-1, keepdim=True)
    theta = torch.sqrt(theta2.clamp_min(1e-16))
    a_exact = torch.sin(theta) / theta
    b_exact = (1.0 - torch.cos(theta)) / theta2.clamp_min(1e-16)
    a_series = 1.0 - theta2 / 6.0 + theta2 * theta2 / 120.0
    b_series = 0.5 - theta2 / 24.0 + theta2 * theta2 / 720.0
    small = theta2 < 1e-8
    a = torch.where(small, a_series, a_exact)[..., None]
    b = torch.where(small, b_series, b_exact)[..., None]
    identity = torch.eye(3, dtype=omega.dtype, device=omega.device).expand(omega.shape[:-1] + (3, 3))
    return identity + a * skew + b * (skew @ skew)


def coarse_graph(raw, device):
    """Aggregate every inter-domain edge; all features use initial geometry only."""
    _, inverse = np.unique(raw["domain_ids"], return_inverse=True)
    count = int(inverse.max()) + 1
    first = np.full(count, len(inverse), dtype=np.int64)
    np.minimum.at(first, inverse, np.arange(len(inverse)))
    frames = np.asarray(raw["rotation"], dtype=np.float64)[first]
    x = np.asarray(raw["pos"], dtype=np.float64) * NM
    sizes = np.bincount(inverse, minlength=count)
    centers = np.stack([np.bincount(inverse, weights=x[:, k], minlength=count) for k in range(3)], 1) / sizes[:, None]
    ni, nj = raw["edge_index"]
    di, dj = inverse[ni], inverse[nj]
    keep = di != dj
    pair, group = np.unique(np.stack([di[keep], dj[keep]], 1), axis=0, return_inverse=True)
    counts = np.zeros((len(pair), 5), dtype=np.float64)
    np.add.at(counts, (group, raw["edge_types"][keep]), 1)
    multiplicity = counts.sum(1)
    distances = np.linalg.norm(x[nj[keep]] - x[ni[keep]], axis=1)
    lengths = np.bincount(group, weights=distances, minlength=len(pair)) / np.maximum(multiplicity, 1)
    i, j = pair.T
    relative = np.einsum("da,dab->db", centers[j] - centers[i], frames[i])
    orientation = np.einsum("dai,daj->dij", frames[i], frames[j])
    edge = np.concatenate([np.log1p(counts), lengths[:, None] / 10, relative / 10, orientation.reshape(-1, 9)], 1)
    assert edge.shape == (len(pair), 18) and np.isfinite(edge).all()
    assert int(counts.sum()) == int(keep.sum())
    return {
        "index": torch.as_tensor(inverse, device=device, dtype=torch.long),
        "edges": torch.as_tensor(pair.T.copy(), device=device, dtype=torch.long),
        "features": torch.as_tensor(edge, device=device, dtype=torch.float32),
        "frames": torch.as_tensor(frames, device=device, dtype=torch.float32),
        "centers": torch.as_tensor(centers, device=device, dtype=torch.float32),
        "relation_counts": torch.as_tensor(counts, device=device, dtype=torch.float32),
        "nucleotide_inter_edges": int(keep.sum()),
    }


class DomainMessageLayer(nn.Module):
    def __init__(self):
        super().__init__()
        self.message = nn.Sequential(nn.Linear(146, 64), nn.SiLU(), nn.Linear(64, 64))
        self.update = nn.Sequential(nn.Linear(128, 64), nn.SiLU(), nn.Linear(64, 64))
        self.norm = nn.LayerNorm(64)

    def forward(self, h, edges, features):
        i, j = edges
        msg = self.message(torch.cat([h[i], h[j], features], -1))
        total = torch.zeros_like(h).index_add(0, i, msg)
        degree = torch.bincount(i, minlength=len(h)).clamp_min(1).to(h.dtype)[:, None]
        return self.norm(h + self.update(torch.cat([h, total / degree], -1)))


class DomainTransformBasisNet(BasisNet):
    """Input-only typed coarse graph and proper domain transforms."""
    def __init__(self, state, k=16):
        super().__init__(state["mean"], state["std"], k=k, width=WIDTH, variant="frame")
        self.domain_projector = nn.Sequential(nn.Linear(WIDTH, 64), nn.SiLU())
        self.domain_messages = nn.ModuleList([DomainMessageLayer() for _ in range(3)])
        self.domain_translation_head = nn.Sequential(nn.Linear(64, 256), nn.SiLU(), nn.Linear(256, 3))
        self.domain_rotation_head = nn.Sequential(nn.Linear(64, 256), nn.SiLU(), nn.Linear(256, 3))
        self.domain_gate = nn.Parameter(torch.zeros(()))

    def load_base_state(self, state):
        missing, unexpected = self.load_state_dict(state, strict=False)
        expected = {key for key in self.state_dict() if key.startswith("domain_")}
        if set(missing) != expected or unexpected:
            raise ValueError(f"base mismatch {missing} {unexpected}")

    def forward_details(self, s, B, R, source_pos, domain_ids, coarse):
        _, h = self.encode(s)
        local_delta = self.readout(h, B, R)[0]
        index = coarse["index"]
        h_domain = self.domain_projector(segment_mean(h[:, :WIDTH], index, len(coarse["frames"])))
        for layer in self.domain_messages:
            h_domain = layer(h_domain, coarse["edges"], coarse["features"])
        tc = torch.tanh(self.domain_translation_head(h_domain))
        rc = torch.tanh(self.domain_rotation_head(h_domain))
        translation = 4 / math.sqrt(3) * torch.einsum("dij,dj->di", coarse["frames"], tc)
        norm = torch.linalg.vector_norm(translation, dim=-1, keepdim=True)
        translation = translation * (8 / norm.clamp_min(1e-8)).clamp(max=1)
        omega = .5 / math.sqrt(3) * torch.einsum("dij,dj->di", coarse["frames"], rc)
        rotation = so3_exp(omega)
        source_nm = source_pos * NM
        relative = source_nm - coarse["centers"][index]
        domain_delta = torch.einsum("nij,nj->ni", rotation[index], relative) - relative + translation[index]
        gate = torch.tanh(self.domain_gate)
        delta = local_delta + gate * domain_delta
        delta = delta - delta.mean(0, keepdim=True)
        return dict(delta_nm=delta, local_delta_nm=local_delta, domain_delta_nm=domain_delta,
                    domain_translation_nm=translation, domain_omega_rad=omega, domain_rotation=rotation,
                    domain_index=index, domain_gate=gate, domain_hidden=h_domain)

    def forward(self, s, B, R, source_pos, domain_ids, coarse):
        return self.forward_details(s, B, R, source_pos, domain_ids, coarse)["delta_nm"]


def branch_gradients(model):
    def magnitude(parameters):
        return float(sum(p.grad.abs().sum().item() for p in parameters if p.grad is not None))
    return {"domain_gate": magnitude([model.domain_gate]),
            "translation_head": magnitude(model.domain_translation_head.parameters()),
            "rotation_head": magnitude(model.domain_rotation_head.parameters()),
            "projector": magnitude(model.domain_projector.parameters()),
            **{f"message_{k}": magnitude(layer.parameters()) for k, layer in enumerate(model.domain_messages)}}


def load_checkpoint(seed: int, device: torch.device) -> dict[str, Any]:
    path = BASE_CHECKPOINTS / f"frame_{seed}.pt"
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    if checkpoint.get("variant") != "frame" or checkpoint.get("seed") != seed:
        raise ValueError(f"unexpected frozen checkpoint metadata in {path}")
    return checkpoint


def make_model(seed: int, arm: str, device: torch.device) -> BasisNet:
    checkpoint = load_checkpoint(seed, device)
    state = checkpoint["state"]
    if arm == "control":
        model = BasisNet(state["mean"], state["std"], k=checkpoint["k"], width=WIDTH, variant="frame")
        model.load_state_dict(state, strict=True)
    elif arm == "domain_graph":
        model = DomainTransformBasisNet(state, k=checkpoint["k"])
        model.load_base_state(state)
    else:
        raise ValueError(arm)
    return model.to(device)


def load_design(ident: str, device: torch.device, with_label: bool) -> dict[str, torch.Tensor]:
    input_path = DATA / "inputs" / f"{ident}.npz"
    with np.load(input_path) as archive:
        raw = {key: np.asarray(archive[key]) for key in archive.files}
    s, B, R = geometry(raw, multiscale=True)
    arrays = {
        "s": torch.as_tensor(s, device=device),
        "B": torch.as_tensor(B, device=device),
        "R": torch.as_tensor(R, device=device),
        "source_pos": torch.as_tensor(raw["pos"], device=device),
        "domain_ids": torch.as_tensor(raw["domain_ids"], dtype=torch.long, device=device),
        "coarse": coarse_graph(raw, device),
    }
    if with_label:
        label_path = DATA / "labels" / f"{ident}.npz"
        with np.load(label_path) as archive:
            target_pos = np.asarray(archive["target_pos"], dtype=np.float32)
        arrays["target_delta_nm"] = torch.as_tensor(
            (target_pos - raw["pos"]) * NM, device=device
        )
    return arrays


def evaluate(model: BasisNet, designs: dict[str, dict[str, torch.Tensor]], ids: list[str]) -> tuple[float, dict[str, float], dict[str, np.ndarray]]:
    model.eval()
    metrics: dict[str, float] = {}
    predictions: dict[str, np.ndarray] = {}
    with torch.no_grad():
        for ident in ids:
            d = designs[ident]
            predicted_delta = model(d["s"], d["B"], d["R"], d["source_pos"], d["domain_ids"], d["coarse"]) if isinstance(model, DomainTransformBasisNet) else model(d["s"], d["B"], d["R"])
            error = predicted_delta - d["target_delta_nm"]
            metrics[ident] = float(torch.sqrt(torch.mean(torch.sum(error.square(), dim=-1))).item())
            predictions[ident] = predicted_delta.detach().cpu().numpy().astype(np.float32)
    return float(np.mean(list(metrics.values()))), metrics, predictions


def data_ids_and_hashes(train_ids: list[str], validation_ids: list[str]) -> dict[str, Any]:
    protected_data = {
        str(path.resolve()): sha256(path)
        for ident in train_ids + validation_ids
        for path in (DATA / "inputs" / f"{ident}.npz", DATA / "labels" / f"{ident}.npz")
    }
    return {
        "split_sha256": sha256(DATA / "split.json"),
        "manifest_sha256": sha256(DATA / "manifest.json"),
        "selected_design_data_sha256": protected_data,
        "frozen_checkpoint_sha256": {
            str(seed): sha256(BASE_CHECKPOINTS / f"frame_{seed}.pt") for seed in SEEDS
        },
        "source_sha256": {str(path.resolve()): sha256(path) for path in SOURCE_PATHS},
    }


def relabel_domains(raw: dict[str, np.ndarray], seed: int = 941) -> dict[str, np.ndarray]:
    result = dict(raw)
    old_values, old_compact = np.unique(raw["domain_ids"], return_inverse=True)
    rng = np.random.default_rng(seed)
    new_labels = rng.permutation(len(old_values)) * 13 + 7
    result["domain_ids"] = new_labels[old_compact]
    # segment_edge_index is indexed by the sorted compact domain order.
    old_order = np.argsort(new_labels)
    old_to_new_rank = np.empty(len(old_values), dtype=np.int64)
    old_to_new_rank[old_order] = np.arange(len(old_values))
    result["segment_edge_index"] = old_to_new_rank[raw["segment_edge_index"]]
    return result


def build_raw(ident: str) -> dict[str, np.ndarray]:
    with np.load(DATA / "inputs" / f"{ident}.npz") as archive:
        return {key: np.asarray(archive[key]) for key in archive.files}


def preflight(seed, train_ids, validation_ids, device):
    torch.manual_seed(seed)
    base = make_model(seed, "control", device).eval()
    candidate = make_model(seed, "domain_graph", device).eval()
    def detail(model, d):
        return model.forward_details(d["s"], d["B"], d["R"], d["source_pos"], d["domain_ids"], d["coarse"])
    def convert(raw):
        s, B, R = geometry(raw, multiscale=True)
        return dict(s=torch.as_tensor(s, device=device), B=torch.as_tensor(B, device=device),
                    R=torch.as_tensor(R, device=device), source_pos=torch.as_tensor(raw["pos"], device=device),
                    domain_ids=torch.as_tensor(raw["domain_ids"], device=device), coarse=coarse_graph(raw, device))
    zero_error = 0.
    with torch.no_grad():
        for ident in validation_ids:
            d = load_design(ident, device, False)
            zero_error = max(zero_error, float((detail(candidate, d)["delta_nm"] - base(d["s"], d["B"], d["R"])).norm(dim=1).max()))
    raw = build_raw(train_ids[0]); d = convert(raw)
    Q = np.array([[0., -1., 0.], [1., 0., 0.], [0., 0., 1.]], np.float32)
    rotated = dict(raw, pos=raw["pos"] @ Q.T, rotation=np.einsum("ij,njk->nik", Q, raw["rotation"]))
    with torch.no_grad():
        closed = detail(candidate, d)
        candidate.domain_gate.fill_(.1)
        opened = detail(candidate, d)
        yr = detail(candidate, convert(rotated))["delta_nm"]
        equiv_error = float((yr - opened["delta_nm"] @ torch.as_tensor(Q, device=device).T).norm(dim=1).max())
        relabel_error = float((detail(candidate, convert(relabel_domains(raw)))["delta_nm"] - opened["delta_nm"]).norm(dim=1).max())
        rewired = dict(d); cg = dict(d["coarse"]); cg["edges"] = cg["edges"].clone()
        cg["edges"][1] = (cg["edges"][1] + 1) % len(cg["frames"])
        rewired["coarse"] = cg
        erased = dict(d); cg2 = dict(d["coarse"]); cg2["features"] = cg2["features"].clone(); cg2["features"][:, :5] = 0
        erased["coarse"] = cg2
        rew = detail(candidate, rewired); er = detail(candidate, erased)
        rewire_message = float((rew["domain_hidden"] - opened["domain_hidden"]).abs().mean())
        rewire_prediction = float((rew["delta_nm"] - opened["delta_nm"]).norm(dim=1).max())
        type_message = float((er["domain_hidden"] - opened["domain_hidden"]).abs().mean())
        type_prediction = float((er["delta_nm"] - opened["delta_nm"]).norm(dim=1).max())
        rot = opened["domain_rotation"]
        det_error = float((torch.linalg.det(rot) - 1).abs().max())
        orth_error = float((rot.transpose(-1,-2) @ rot - torch.eye(3, device=device)).abs().max())
        distance_error = 0.
        for domain in range(len(rot)):
            ix = torch.nonzero(opened["domain_index"] == domain).flatten()[:12]
            if len(ix) > 1:
                xx = d["source_pos"][ix] * NM
                yy = xx @ rot[domain].T
                # differences evaluated after subtracting a common origin (stable in float32).
                xx = xx - xx[0]; yy = xx @ rot[domain].T
                distance_error = max(distance_error, float((torch.cdist(xx,xx) - torch.cdist(yy,yy)).abs().max()))
        open_difference = float((opened["delta_nm"] - closed["delta_nm"]).norm(dim=1).max())
    # Largest train design only; no optimizer step. One backwards verifies all branch layers.
    largest = max(train_ids, key=lambda ident: len(build_raw(ident)["pos"]))
    big = load_design(largest, device, True)
    candidate.train(); candidate.zero_grad(set_to_none=True)
    output = detail(candidate, big)
    loss = (output["delta_nm"] - big["target_delta_nm"]).square().mean()
    loss.backward(); gradients = branch_gradients(candidate)
    stats = {}
    for ident in train_ids + validation_ids:
        graph = coarse_graph(build_raw(ident), torch.device("cpu"))
        stats[ident] = dict(domains=len(graph["frames"]), domain_edges=graph["edges"].shape[1],
                           inter_nt_edges=graph["nucleotide_inter_edges"], counts_by_type=graph["relation_counts"].sum(0).tolist())
    checks = dict(zero_gate=zero_error < 1e-5, open_gate_equivariance=equiv_error < 2e-4,
                  relabel_invariance=relabel_error < 1e-5, proper_rotations=det_error < 1e-5 and orth_error < 1e-5,
                  rigid_distance=distance_error < 1e-4, open_gate_active=open_difference > 1e-6,
                  neighbor_messages=rewire_message > 1e-6, neighbor_predictions=rewire_prediction > 1e-6,
                  typed_messages=type_message > 1e-6, typed_predictions=type_prediction > 1e-6,
                  all_branch_gradients=all(np.isfinite(v) and v > 0 for v in gradients.values()),
                  largest_train_backward=bool(torch.isfinite(loss)), graph_counts_conserved=all(abs(sum(v["counts_by_type"]) - v["inter_nt_edges"]) < .5 for v in stats.values()))
    return dict(passed=all(checks.values()), checks=checks, zero_gate_max_nm=zero_error,
                open_gate_equivariance_max_nm=equiv_error, relabel_max_nm=relabel_error,
                det_error=det_error, orthogonality_error=orth_error, rigid_distance_error_nm=distance_error,
                open_prediction_difference_nm=open_difference, rewire_message_difference=rewire_message,
                rewire_prediction_difference_nm=rewire_prediction, type_message_difference=type_message,
                type_prediction_difference_nm=type_prediction, gradients=gradients,
                largest_train_design=largest, largest_train_nodes=len(big["s"]), optimizer_steps=0,
                parameter_count=sum(p.numel() for p in candidate.parameters()), graph_statistics=stats,
                peak_cuda_allocated_mb=torch.cuda.max_memory_allocated(device)/1024**2 if device.type == "cuda" else 0,
                test_ids_decoded=False, test_input_files_opened=False, test_label_files_opened=False)


def run_arm(seed: int, arm: str, train_ids: list[str], validation_ids: list[str], designs: dict[str, dict[str, torch.Tensor]], device: torch.device) -> dict[str, Any]:
    arm_seed = seed if arm == "control" else seed + 8000
    random.seed(arm_seed)
    np.random.seed(arm_seed)
    torch.manual_seed(arm_seed)
    torch.cuda.manual_seed_all(arm_seed)
    model = make_model(seed, arm, device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    rng = np.random.default_rng(seed)
    run_dir = RUNS / f"seed{seed}_{arm}"
    run_dir.mkdir(parents=True, exist_ok=True)
    history_path = run_dir / "history.jsonl"
    if history_path.exists():
        raise FileExistsError(f"refusing to overwrite existing run {run_dir}")

    best_score = float("inf")
    best_epoch = -1
    best_state = None
    best_metrics: dict[str, float] = {}
    best_predictions: dict[str, np.ndarray] = {}
    t0 = time.time()

    def evaluate_epoch(epoch: int, branch_grad: dict[str, float]) -> None:
        nonlocal best_score, best_epoch, best_state, best_metrics, best_predictions
        score, metrics, predictions = evaluate(model, designs, validation_ids)
        row = {
            "seed": seed,
            "arm": arm,
            "epoch": epoch,
            "validation_macro_rmsd_nm": score,
            "best_validation_macro_rmsd_nm": min(best_score, score),
            "branch_gradient_abs_mean": branch_grad,
        }
        with history_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row) + "\n")
        if score < best_score:
            best_score = score
            best_epoch = epoch
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            best_metrics = metrics
            best_predictions = predictions

    model.eval()
    evaluate_epoch(0, {"domain_gate": 0.0, "translation_head": 0.0, "rotation_head": 0.0})
    for epoch in range(1, EPOCHS + 1):
        model.train()
        grad_values = {key: [] for key in ("domain_gate", "translation_head", "rotation_head", "projector", "message_0", "message_1", "message_2")}
        losses = []
        epoch_order = [str(value) for value in rng.permutation(train_ids)]
        order_hash = hashlib.sha256("\n".join(epoch_order).encode()).hexdigest()
        for ident in epoch_order:
            d = designs[str(ident)]
            optimizer.zero_grad(set_to_none=True)
            if isinstance(model, DomainTransformBasisNet):
                output = model.forward_details(d["s"], d["B"], d["R"], d["source_pos"], d["domain_ids"], d["coarse"])
                predicted = output["delta_nm"]
            else:
                predicted = model(d["s"], d["B"], d["R"])
            loss = torch.mean((predicted - d["target_delta_nm"]).square())
            if not torch.isfinite(loss):
                raise FloatingPointError(f"non-finite loss in seed={seed} arm={arm} epoch={epoch} design={ident}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            if isinstance(model, DomainTransformBasisNet):
                for key, value in branch_gradients(model).items():
                    grad_values[key].append(value)
            optimizer.step()
            losses.append(float(loss.detach().item()))
        grad_mean = {key: float(np.mean(values)) if values else 0.0 for key, values in grad_values.items()}
        evaluate_epoch(epoch, {**grad_mean, "train_mse_nm2": float(np.mean(losses)), "train_order_sha256": order_hash})
        atomic_json(run_dir / "status.json", {
            "seed": seed, "arm": arm, "epoch": epoch, "epochs_total": EPOCHS,
            "best_epoch": best_epoch, "best_validation_macro_rmsd_nm": best_score,
            "elapsed_seconds": time.time() - t0,
        })
        if epoch == 1 or epoch % 10 == 0 or epoch == EPOCHS:
            print(f"{arm} seed={seed} epoch={epoch} val={row_score(history_path):.6f} best={best_score:.6f} grad={grad_mean}", flush=True)

    if best_state is None or best_epoch < 0:
        raise RuntimeError("no selected checkpoint")
    checkpoint_path = run_dir / "best.pt"
    torch.save({
        "state": best_state,
        "seed": seed,
        "arm": arm,
        "best_epoch": best_epoch,
        "best_validation_macro_rmsd_nm": best_score,
    }, checkpoint_path)
    prediction_path = run_dir / "validation_predictions.npz"
    np.savez_compressed(prediction_path, **best_predictions)
    with (run_dir / "per_design_validation.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=("seed", "arm", "epoch", "design", "rmsd_nm"))
        writer.writeheader()
        for ident in validation_ids:
            writer.writerow({"seed": seed, "arm": arm, "epoch": best_epoch, "design": ident, "rmsd_nm": best_metrics[ident]})
    atomic_json(run_dir / "status.json", {
        "seed": seed, "arm": arm, "epoch": EPOCHS, "epochs_total": EPOCHS,
        "best_epoch": best_epoch, "best_validation_macro_rmsd_nm": best_score,
        "elapsed_seconds": time.time() - t0, "complete": True,
        "best_checkpoint_sha256": sha256(checkpoint_path),
        "validation_prediction_sha256": sha256(prediction_path),
    })
    return {
        "seed": seed,
        "arm": arm,
        "best_epoch": best_epoch,
        "best_validation_macro_rmsd_nm": best_score,
        "best_checkpoint_sha256": sha256(checkpoint_path),
        "validation_prediction_sha256": sha256(prediction_path),
        "elapsed_seconds": time.time() - t0,
        "per_design_validation": best_metrics,
        "final_history_row": json.loads(history_path.read_text().splitlines()[-1]),
    }


def row_score(path: Path) -> float:
    return float(json.loads(path.read_text().splitlines()[-1])["validation_macro_rmsd_nm"])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--preflight-seed", type=int, default=11)
    args = parser.parse_args()
    os.environ["WANDB_MODE"] = "disabled"
    torch.set_num_threads(2)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    if device.type == "cuda":
        print("DEVICE", torch.cuda.get_device_name(device), "CUDA", torch.version.cuda, flush=True)

    train_ids, validation_ids = read_train_validation_ids(DATA / "split.json")
    expected_validation_ids = json.loads((ROOT / "experiments/talos97_model_improvement/phase1_error_localization/results/summary.json").read_text())["validation_ids"]
    if len(train_ids) != 68 or len(validation_ids) != 14 or validation_ids != expected_validation_ids:
        raise ValueError("train/validation split does not match frozen 68/14 protocol")
    if len(set(train_ids + validation_ids)) != 82:
        raise ValueError("train and validation IDs must be unique and disjoint")

    RUNS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    hashes_before = data_ids_and_hashes(train_ids, validation_ids)
    preflight_result = preflight(args.preflight_seed, train_ids, validation_ids, device)
    atomic_json(RESULTS / "preflight.json", preflight_result)
    print("PREFLIGHT", json.dumps(preflight_result, ensure_ascii=False), flush=True)
    if not preflight_result["passed"]:
        raise RuntimeError("Phase 10 preflight failed; refusing to train")
    if args.preflight_only:
        return 0

    # Only the train and validation IDs decoded above are opened. The split
    # parser returned before reading the JSON test array.
    designs = {
        ident: load_design(ident, device, with_label=True)
        for ident in train_ids + validation_ids
    }
    outcomes = []
    for seed in SEEDS:
        for arm in ARMS:
            print(f"START seed={seed} arm={arm}", flush=True)
            outcomes.append(run_arm(seed, arm, train_ids, validation_ids, designs, device))
    hashes_after = data_ids_and_hashes(train_ids, validation_ids)
    summary = {
        "phase": "talos97_phase10_domain_graph_residual_v1",
        "train_ids": train_ids,
        "validation_ids": validation_ids,
        "train_design_count": len(train_ids),
        "validation_design_count": len(validation_ids),
        "output_paths": [str(path.resolve()) for path in HERE.rglob("*") if path.is_file()],
        "test_ids_decoded": False,
        "test_input_files_opened": False,
        "test_label_files_opened": False,
        "test_prediction_keys_read": False,
        "test_inference": False,
        "model_inference_validation_only": True,
        "optimizer_steps": len(SEEDS) * len(ARMS) * EPOCHS * len(train_ids),
        "data_access_manifest": {
            "input_design_ids_opened": train_ids + validation_ids,
            "label_design_ids_opened": train_ids + validation_ids,
            "split_parser_stopped_after": "validation",
        },
        "device": str(device),
        "cuda_device_name": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "numpy_version": np.__version__,
        "scipy_version": scipy.__version__,
        "python_version": platform.python_version(),
        "epochs_per_arm": EPOCHS,
        "seeds": list(SEEDS),
        "arms": list(ARMS),
        "hashes_before": hashes_before,
        "hashes_after": hashes_after,
        "runs": outcomes,
        "original_checkpoints_modified": False,
    }
    atomic_json(RESULTS / "summary.json", summary)
    print("COMPLETE", json.dumps({
        "runs": [{"seed": row["seed"], "arm": row["arm"], "best_epoch": row["best_epoch"], "val": row["best_validation_macro_rmsd_nm"]} for row in outcomes],
        "test_ids_decoded": False,
        "optimizer_steps": summary["optimizer_steps"],
    }, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
