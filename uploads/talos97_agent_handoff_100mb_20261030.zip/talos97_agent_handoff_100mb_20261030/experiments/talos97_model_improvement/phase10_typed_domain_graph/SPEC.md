# Phase 10: typed domain graph with explicit communication

## Material Passport
- Mode: code experiment, implementation + run
- Objective: improve fixed-14 validation macro RMSD toward 1.2 nm
- Data: frozen 68 train / 14 validation, initial-only features, no test access
- Status at registration: implementation/training not started

## Hypothesis and domain audit
Existing domains are input cadnano `(virtual_helix, axial_index // 16)` segments,
not inferred mechanical bodies. Phase 7 label-fitted rigid oracle is an optimistic
diagnostic. Phase 8 independent pooled SE(3) heads failed to improve validation.
Hypothesis: typed inter-segment communication plus relative orientation makes
coherent displacement more predictable. Keep the existing segmentation and local
residual; no new label processing, losses, dataset, or training budget.

## Architecture fixed before implementation
Start from the three frozen localframe2m checkpoints. Pool h2 per domain and
project 346->64. Use the first nucleotide's input proper frame in each domain as
an equivariant anchor (deterministic input row order, not a learned ID embedding).
Aggregate ALL inter-domain nucleotide edges by ordered domain pair: five log1p
relation counts (0 spatial, 1 backbone, 2 paired, 3 crossover, 4 two-hop backbone),
mean nucleotide distance in nm/10, relative centroid in receiver frame /10, and
relative anchor orientation flattened (9). Thus 18 invariant edge channels.
Drop self-domain edges; do not use the lossy first-edge segment feature cache.
Three independent 64-wide residual message layers: MLP([h_receiver,h_sender,e])
->64, mean incoming messages, MLP([h,mean])->64 residual + LayerNorm. Shared heads
64->256->3 emit bounded translation/axis-angle coefficients in the anchor frame.
Use 4/sqrt(3) nm and 0.5/sqrt(3) rad scales, cap translation norm at 8 nm.
SO(3) exponential yields proper rotations around input domain centroids. Add a
single zero-initialized tanh gate times the domain displacement to the unchanged
local residual; subtract global mean displacement. Full backbone fine-tuning.
This tests a graph-based domain branch as a package: frame readout and added
capacity differ from Phase 8. A positive result would require later graphless /
capacity-matched ablation before attributing causality solely to communication.

## Fixed experiment
- Same fixed 68/14 split and validation-selected frame_11/22/33.pt bases.
- Paired control/domain_graph, seeds11/22/33, epoch0 plus50 epochs, AdamW1e-3,
  weight_decay1e-4, gradient clip5, per-design node MSE, identical design orders.
- Best checkpoint by 14-design mean RMSD over epochs0..50; report seed mean and
  ensemble separately, no test inference or selection, W&B disabled.
- Promising only if mean gain >=0.05nm, >=2/3 paired seeds improve, maximum
  paired per-design regression <=0.20nm. Negative result is not integrity failure.
- Report long-node >=4nm amplitude/endpoint errors and domain translation/rotation
  diagnostics (validation label fits are descriptive only, never model inputs).
- No automatic hyperparameter search or repeat of completed runs.

## Resource and provenance
Use local A100 cuda:1 only after fresh idle check (user previously established
three local A100s). No shared Slurm device; any later high-memory submission must
exclude gpu29. Six runs total20400 steps. Keep initial data, split, normalization,
base weights and all source hashes unchanged. Streaming split parser stops after
validation. Hash-only whole split; no test arrays or IDs decoded. Source changes
only inside this Phase10 directory and harness state files. Record runtime/access
manifest, histories, selected weights/predictions, preflight and verifier outputs.
