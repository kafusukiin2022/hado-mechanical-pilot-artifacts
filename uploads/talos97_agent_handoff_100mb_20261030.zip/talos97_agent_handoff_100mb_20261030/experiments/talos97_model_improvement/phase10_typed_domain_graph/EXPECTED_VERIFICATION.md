# Expected verification (registered before implementation)
1. Zero gate reproduces all frozen validation predictions within1e-5nm.
2. Open-gate SO(3) equivariance <2e-4nm, domain integer relabel invariance <1e-5nm;
   proper rotations/orthogonality <1e-5; sampled within-domain distances <1e-4nm.
3. Coarse edges recompute from all inter-domain nucleotide edges, counts conserved;
   source-only18channels finite, train/validation graph statistics recorded.
4. Open gate changes outputs; neighbor rewiring and edge-type erasure change graph
   messages AND predictions. Nonzero finite gradients into gate, both transform
   heads, projector and all three message layers with a train-only disposable probe.
5. Largest train design forward/backward finite on selected A100 before full run.
6. All six runs epoch0..50, 20400 total steps, paired identical data orders; real
   graph-arm training gradients recorded and nonzero for all three layers.
7. Independently recompute84 per-design metrics, seed mean, ensemble, best epoch,
   screen decision and long-motion diagnostics; reproduce selected checkpoints'
   predictions (all14validation designs) independently within1e-4nm max node norm.
8. All before/after/current protected data/base/source hashes agree, validation-only
   prediction keys; streaming access manifest contains exactly68+14designs.
9. No test input/label/prediction access; no original checkpoint modified. Scientific
   negative is reported honestly and does not fail an otherwise valid integrity run.
