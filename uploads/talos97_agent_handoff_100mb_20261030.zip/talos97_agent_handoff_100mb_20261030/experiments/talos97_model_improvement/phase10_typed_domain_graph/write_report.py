"""Render verified Phase10 results without training or selecting new checkpoints."""
import json
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
r=HERE/'results'
v=json.loads((r/'verification.json').read_text())
p=json.loads((r/'preflight.json').read_text())
assert v['passed'], 'Do not produce final success report for failed verification'
lines=['# Phase 10：带类型边的 domain 图实验', '', '## Material Passport',
       '- 类型：固定协议机器学习实验；结果来源为本地训练及独立复算。',
       '- 数据：68 train / 14 validation；不读取 test。',
       '- 状态：六组训练完成；独立核验通过。', '',
       '## 主要结果', '',
       f"科学筛选：**{'通过' if v['promising_by_preregistered_rule'] else '未通过'}**。完整性通过不代表模型有效。",
       f"三 seed 最佳验证 RMSD 均值：control **{v['control_seed_mean_macro_rmsd_nm']:.6f} nm**；domain-graph **{v['domain_graph_seed_mean_macro_rmsd_nm']:.6f} nm**；改善 **{v['mean_improvement_nm']:.6f} nm**。",
       f"严格小于零的原始计数为{v['seeds_improved']}/3；seed11仅改善1.385e-10 nm，视为数值持平，不能算实质收益。最大配对设计级退化 {v['maximum_per_design_regression_nm']:.6f} nm。",
       '', '| Seed | control nm | graph nm | graph−control nm | best epochs control/graph |', '|---|---:|---:|---:|---|']
for seed,row in v['paired_seed_results'].items():
    e=row['best_epochs'];lines.append(f"|{seed}|{row['control_macro_rmsd_nm']:.6f}|{row['domain_graph_macro_rmsd_nm']:.6f}|{row['candidate_minus_control_nm']:+.6f}|{e['control']}/{e['domain_graph']}|")
lines += ['',f"三 seed ensemble：control {v['ensemble_results']['control']['macro_rmsd_nm']:.6f} nm；graph {v['ensemble_results']['domain_graph']['macro_rmsd_nm']:.6f} nm。ensemble 不等于 seed 分数均值。",
          '目标为约1.2 nm；本轮是否达到：'+str(v['absolute_target_1_2_nm_reached_by_candidate_ensemble'])+'。', '',
          '## 长位移诊断', '',
          '长节点定义为标签位移幅度≥4 nm。以下为每个设计长节点均值后，跨设计等权、跨seed等权；跳过没有长节点的设计。不是节点池化统计。', '',
          '| Arm | true amplitude nm | predicted amplitude nm | amplitude ratio | long endpoint RMSD nm |', '|---|---:|---:|---:|---:|']
diag=v['additional_verification']['diagnostics']
for arm in ('control','domain_graph'):
    rows=[row for key,rs in diag.items() if key.endswith('_'+arm) for row in rs if row['long_nodes']]
    means=[np.mean([row[k] for row in rows]) for k in ('long_true_mean_nm','long_pred_mean_nm','long_amplitude_ratio','long_endpoint_rmsd_nm')]
    lines.append('|'+arm+'|'+'|'.join(f'{value:.6f}' for value in means)+'|')
lines += ['', '## Domain 变换诊断', '',
          '标签拟合 proper-rigid oracle 仅用于诊断。下表比较**未乘gate的原始变换分支**和标签拟合变换；输出还叠加local残差，且gate作用于位移，所以这些角度不能解释为最终预测的旋转误差。各domain等权后各设计等权。', '',
          '| Seed | gate | raw translation error nm | raw rotation error deg | mean domain rigid oracle nm |', '|---|---:|---:|---:|---:|']
for seed in (11,22,33):
    rows=diag[f'seed{seed}_domain_graph']
    vals=[np.mean([row[k] for row in rows]) for k in ('gate','raw_domain_translation_error_mean_nm','raw_domain_rotation_error_mean_deg','domain_rigid_oracle_mean_nm')]
    lines.append(f'|{seed}|'+'|'.join(f'{x:.6f}' for x in vals)+'|')
lines += ['', '## 实现与核验', '',
          'Domain 仍为virtual_helix × floor(axial_index/16)；它是设计片段，不是学习出的完整刚体域。输入锚frame取域内第一个核苷酸，依赖固定的核苷酸顺序，但不依赖domain整数编号。',
          '所有跨域核苷酸边按有向域对聚合五类计数、平均距离、接收域局部相对质心和相对frame。三个64维消息层后预测共享proper SE(3)变换，再加原localframe残差。配对碱基均在域内，因而本数据域间paired计数为0。',
          f"参数量{p['parameter_count']:,}；最大训练设计{p['largest_train_nodes']}节点；预检峰值{p['peak_cuda_allocated_mb']:.2f} MiB。",
          f"预检{len(p['checks'])}项通过；独立核验{len(v['checks'])}项通过；全部84组checkpoint/validation预测CPU重现最大节点偏差{v['additional_verification']['checkpoint_max_prediction_difference_nm']:.3e} nm。",
          '验证器独立字典聚合重算全部82设计域间类型计数；重算84设计级指标、best epoch、配对顺序、ensemble、长位移与domain诊断，并核对数据/原checkpoint/源文件hash。',
          '完整输入split仅hash；streaming parser在validation列表后立即停止。无test输入、标签、预测读取/生成；无W&B提交；GPU0未用于本实验。', '',
          '## 解释边界', '',
          '本轮同时增加粗图通信、anchor-frame readout和容量；即使正结果，也需要后续graphless/capacity-matched消融才能将收益归因于域间通信。',
          '3 seeds和反复使用固定14验证设计不支持显著性或形状泛化声明；标签来自有限轨迹均值且ESS偏低，未在本轮改变监督。',
          '零门使epoch0保持原模型；若最佳epoch为0，选中模型并未获得有效domain分支收益。',
          '本轮是位置端点诊断，不是EBD diffusion实现或完整oxDNA刚体输出验收；未新增方向预测/物理可运行性声明。', '',
          '## 复现命令', '', '```bash',
          '../hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase10_typed_domain_graph/verify_results.py',
          '../hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase10_typed_domain_graph/write_report.py',
          '```', '训练脚本拒绝覆盖已有history；不要直接重复启动六组训练。', '', '## 后续建议（未执行）', '', '本次三层局部粗图分支没有缓解大位移低估，暂不重复加深或调宽。下一项有区分力的诊断是仅在train拟合domain变换监督，冻结原backbone，检查粗分支能否先拟合训练域运动，再用独立validation评估；可区分端点联合MSE下分支竞争与domain运动可预测性问题。该实验需另写SPEC，不能将标签拟合变换作为推理输入。', '更长程图通信和replica-aware监督仍是未验证假设，本轮结果不能证明它们必然有效。']
(r/'REPORT_ZH.md').write_text('\n'.join(lines)+'\n')
print(r/'REPORT_ZH.md')
