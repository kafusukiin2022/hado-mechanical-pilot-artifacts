# Phase 10：带类型边的 domain 图实验

## Material Passport
- 类型：固定协议机器学习实验；结果来源为本地训练及独立复算。
- 数据：68 train / 14 validation；不读取 test。
- 状态：六组训练完成；独立核验通过。

## 主要结果

科学筛选：**未通过**。完整性通过不代表模型有效。
三 seed 最佳验证 RMSD 均值：control **2.175492 nm**；domain-graph **2.176664 nm**；改善 **-0.001173 nm**。
严格小于零的原始计数为1/3；seed11仅改善1.385e-10 nm，视为数值持平，不能算实质收益。最大配对设计级退化 0.053119 nm。

| Seed | control nm | graph nm | graph−control nm | best epochs control/graph |
|---|---:|---:|---:|---|
|11|2.174161|2.174161|-0.000000|0/0|
|22|2.174555|2.175304|+0.000749|6/6|
|33|2.177759|2.180528|+0.002769|19/0|

三 seed ensemble：control 2.154073 nm；graph 2.155920 nm。ensemble 不等于 seed 分数均值。
目标为约1.2 nm；本轮是否达到：False。

## 长位移诊断

长节点定义为标签位移幅度≥4 nm。以下为每个设计长节点均值后，跨设计等权、跨seed等权；跳过没有长节点的设计。不是节点池化统计。

| Arm | true amplitude nm | predicted amplitude nm | amplitude ratio | long endpoint RMSD nm |
|---|---:|---:|---:|---:|
|control|4.772269|1.849605|0.391173|3.652987|
|domain_graph|4.772269|1.780895|0.376755|3.682644|

## Domain 变换诊断

标签拟合 proper-rigid oracle 仅用于诊断。下表比较**未乘gate的原始变换分支**和标签拟合变换；输出还叠加local残差，且gate作用于位移，所以这些角度不能解释为最终预测的旋转误差。各domain等权后各设计等权。

| Seed | gate | raw translation error nm | raw rotation error deg | mean domain rigid oracle nm |
|---|---:|---:|---:|---:|
|11|0.000000|2.416598|36.043951|0.230115|
|22|0.022195|3.204382|43.652137|0.230115|
|33|0.000000|2.421744|35.986566|0.230115|

## 实现与核验

Domain 仍为virtual_helix × floor(axial_index/16)；它是设计片段，不是学习出的完整刚体域。输入锚frame取域内第一个核苷酸，依赖固定的核苷酸顺序，但不依赖domain整数编号。
所有跨域核苷酸边按有向域对聚合五类计数、平均距离、接收域局部相对质心和相对frame。三个64维消息层后预测共享proper SE(3)变换，再加原localframe残差。配对碱基均在域内，因而本数据域间paired计数为0。
参数量2,218,982；最大训练设计9942节点；预检峰值761.44 MiB。
预检13项通过；独立核验12项通过；全部84组checkpoint/validation预测CPU重现最大节点偏差5.516e-06 nm。
验证器独立字典聚合重算全部82设计域间类型计数；重算84设计级指标、best epoch、配对顺序、ensemble、长位移与domain诊断，并核对数据/原checkpoint/源文件hash。
完整输入split仅hash；streaming parser在validation列表后立即停止。无test输入、标签、预测读取/生成；无W&B提交；GPU0未用于本实验。

## 解释边界

本轮同时增加粗图通信、anchor-frame readout和容量；即使正结果，也需要后续graphless/capacity-matched消融才能将收益归因于域间通信。
3 seeds和反复使用固定14验证设计不支持显著性或形状泛化声明；标签来自有限轨迹均值且ESS偏低，未在本轮改变监督。
零门使epoch0保持原模型；若最佳epoch为0，选中模型并未获得有效domain分支收益。
本轮是位置端点诊断，不是EBD diffusion实现或完整oxDNA刚体输出验收；未新增方向预测/物理可运行性声明。

## 复现命令

```bash
../hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase10_typed_domain_graph/verify_results.py
../hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase10_typed_domain_graph/write_report.py
```
训练脚本拒绝覆盖已有history；不要直接重复启动六组训练。

## 后续建议（未执行）

本次三层局部粗图分支没有缓解大位移低估，暂不重复加深或调宽。下一项有区分力的诊断是仅在train拟合domain变换监督，冻结原backbone，检查粗分支能否先拟合训练域运动，再用独立validation评估；可区分端点联合MSE下分支竞争与domain运动可预测性问题。该实验需另写SPEC，不能将标签拟合变换作为推理输入。
更长程图通信和replica-aware监督仍是未验证假设，本轮结果不能证明它们必然有效。
