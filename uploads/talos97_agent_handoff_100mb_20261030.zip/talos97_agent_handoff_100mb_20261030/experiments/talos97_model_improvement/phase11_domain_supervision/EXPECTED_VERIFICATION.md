1. Frozen base parameters have zero gradients and unchanged hashes.
2. Proper Kabsch targets have finite rotations with determinant +1; source/target shapes match.
3. Domain branch receives nonzero gradients; epoch-0 branch is zero-gated.
4. All six seed/validation histories are complete; selected metrics recompute from saved predictions.
5. Train/validation-only access and protected hashes pass; no test access.
6. Report train-vs-validation domain translation/rotation errors and endpoint RMSD separately.

Execution clarifications supersede vague scaffold points above:
- Three runs x50epochs; train/validation histories epoch0..50. Branch identity
  initialization replaces zero-gate; nonzero gradient probe perturbs disposable
  heads and tests all message layers/projector/heads, no optimizer steps.
- Full-base state hash must match original before/after EVERY run. All base
  parameters requires_grad=False; optimizer includes branch parameters only.
- Independent Kabsch re-fit and SO3 checks for all82designs; label rotation rank
  validity mask. Reconstruction residual computed only from frozen predictions.
- Verify best epoch by transform loss; CPU reproduce all82train/validation saved
  outputs per seed and recompute domain/endpoint/long-motion metrics within1e-4.
- Verify input rotation/relabel invariance, target rigid-fit synthetic convention,
  oracle hybrid invariant when oracle substituted, all source/data/ckpt hashes.
