# Phase 11: frozen-backbone domain rigid supervision diagnostic

Question: can the input-only domain graph predict the label-fitted domain rigid motion when the localframe backbone is frozen?

Protocol: three seeds (11,22,33), fixed 68 train / 14 validation, no test access. Load the frozen localframe2m checkpoint and freeze every BasisNet parameter. Train only the domain graph branch for 50 epochs, one train design per step, AdamW 1e-3, weight decay 1e-4, clip 5. Targets are computed from each train/validation label by per-domain proper Kabsch fit: target translation is target centroid minus source centroid, target rotation maps centered source coordinates to centered target coordinates. Target fitting is diagnostic supervision only; no target transform is used as an input.

Report train and validation domain translation RMSE, rotation geodesic error, rigid-fit reconstruction RMSD, and final nucleotide RMSD after adding the predicted coarse transform to the frozen local residual. Select by validation domain-transform loss; no test selection. Candidate is useful only if both train and validation transform errors improve over epoch zero; no claim of generalization from 14 designs.

All split/data/checkpoint/source hashes are recorded. The parser stops after validation; test IDs, files, labels, and predictions are never opened. W&B disabled. This experiment is diagnostic and does not replace the Phase10 endpoint-MSE comparison.

## Execution clarification (before runner implementation/training)
Use the verified Phase10 typed-domain architecture (64-wide projector,3message
layers,all18edge channels). The earlier copied model.py/base_utils.py scaffold is
unused. Frozen localframe features and input-only graph are cached under no_grad.
Branch heads emit unconstrained anchor-local translation(nm) and axis-angle(rad);
no gate or tanh/range clipping. Both final linear heads start at zero (identity).
The previous zero-gate requirement is superseded by identity initialization:
a fixed zero gate would prevent direct rotation/translation supervision.

Loss per design is equal-domain mean squared Euclidean translation error(nm^2)
plus 1nm^2 times equal-domain squared Frobenius rotation-matrix error. Rotation
loss/angle metrics exclude rank<2 source domains (reported explicitly), where a
rigid rotation is not identifiable. Translation uses every domain. Select by
mean validation transform loss, evaluate train and validation every epoch0..50.
Log translation RMSE and mean geodesic angle separately; no optimizer selection
by endpoint metrics. No early stop/retry/hyperparameter search,3runs=10200steps.

Raw rigid-only prediction is x+domain_delta. Secondary legacy additive prediction
is x+domain_delta+frozen_base_delta (possible double counting, do not use it to
judge transform predictability). Main hybrid reconstruction removes the frozen
base prediction's own input-to-base per-domain rigid component, retaining only
its within-domain deformation residual, then adds that residual to the predicted
rigid structure. This removal depends ONLY on input and frozen predictions, never
labels. Also report frozen base, identity and label-fitted rigid oracle baselines.
Label oracles are diagnostic/optimistic only, not deployable predictions.

Training fitting criterion: loss reduction>=10% vs identity and non-increasing
translation RMSE and rotation angle (tolerate1e-6numeric). Apply independently to
train/validation, requiring>=2/3seeds for each classification. A failure at this
50epoch budget does not prove motion is unlearnable. Endpoint improvement is a
separate outcome; identify any rotation/translation tradeoff. Long-motion mask is
true displacement>=4nm; report amplitude ratio and endpoint RMSD, design-macro.

Runtime correction before any optimizer step: attempt01 failed at AdamW default-device context check becauseGPU0occupied. Preserve attempt01 all artifacts; explicitly set current CUDA device to requestedGPU1. Hyperparameters/model/data unchanged; no completed run retried.
