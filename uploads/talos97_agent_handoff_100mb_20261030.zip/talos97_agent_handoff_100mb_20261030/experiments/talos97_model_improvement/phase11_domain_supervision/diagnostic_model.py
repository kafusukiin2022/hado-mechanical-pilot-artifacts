"""Phase10 typed scalar graph with unconstrained, identity-initialized SE3 heads."""
import importlib.util
from pathlib import Path
import torch
from torch import nn

PHASE10 = Path(__file__).resolve().parent.parent / 'phase10_typed_domain_graph/run_experiment.py'
spec = importlib.util.spec_from_file_location('phase10_frozen_dependency', PHASE10)
p10 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p10)

class DiagnosticHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.projector = nn.Sequential(nn.Linear(346,64), nn.SiLU())
        self.layers = nn.ModuleList([p10.DomainMessageLayer() for _ in range(3)])
        self.translation = nn.Sequential(nn.Linear(64,256), nn.SiLU(), nn.Linear(256,3))
        self.rotation = nn.Sequential(nn.Linear(64,256), nn.SiLU(), nn.Linear(256,3))
        for head in (self.translation,self.rotation):
            nn.init.zeros_(head[-1].weight); nn.init.zeros_(head[-1].bias)
    def forward(self, pooled_h, graph):
        h = self.projector(pooled_h)
        for layer in self.layers:
            h = layer(h, graph['edges'], graph['features'])
        t = torch.einsum('dij,dj->di',graph['frames'],self.translation(h))
        omega = torch.einsum('dij,dj->di',graph['frames'],self.rotation(h))
        return t, p10.so3_exp(omega)
