"""Report verified direct-domain supervision without changing selection."""
import json
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;R=P/'results'
v=json.loads((R/'verification.json').read_text());assert v['passed']
pf=json.loads((R/'preflight.json').read_text())
lines=['# Phase11：冻结 backbone 的 domain 运动监督诊断','','## Material Passport','- 计算实验，固定68 train/14 validation，3 seeds×50epochs。','- 数据为有限轨迹均值标签；无test读取/推理；W&B禁用。','- 状态：训练完成，独立核验通过。','','## 结论',
       f"预注册拟合筛选：train {v['train_seeds_passing']}/3；validation {v['validation_seeds_passing']}/3。要求损失至少下降10%、平移RMSE与旋转角均不退化；不能只看总损失。",'',
       '|Seed|Best epoch|Train loss 0→best|Val loss 0→best|Train t RMSE nm 0→best|Val t RMSE nm 0→best|Train angle ° 0→best|Val angle ° 0→best|',
       '|---|---:|---|---|---|---|---|---|']
for seed,d in v['seed_results'].items():
 cells=[]
 for group,key in [('train','loss'),('validation','loss'),('train','translation_rmse_nm'),('validation','translation_rmse_nm'),('train','rotation_deg'),('validation','rotation_deg')]:
  q=d[group];cells.append(f"{q['baseline'][key]:.4f}→{q['selected'][key]:.4f}")
 lines.append(f"|{seed}|{d['best_epoch']}|"+'|'.join(cells)+'|')
lines+=['','## 节点重建（与domain损失分开解释）','','|Seed|Split|Frozen base nm|Rigid-only nm|Hybrid nm|Legacy additive nm|Label rigid oracle nm|','|---|---|---:|---:|---:|---:|---:|']
for seed,d in v['seed_results'].items():
 for group in ('train','validation'):
  q=d[group]['selected'];lines.append(f'|{seed}|{group}|'+ '|'.join(f'{q[k]:.6f}' for k in ['base_rmsd_nm','rigid_rmsd_nm','hybrid_rmsd_nm','additive_rmsd_nm','oracle_rmsd_nm'])+'|')
lines+=['','Hybrid仅保留冻结base预测中去掉其自身domain刚体运动后的域内残差，再加预测domain变换；残差构造不读标签。Legacy additive直接把完整domain运动加到base全部位移，会重复计数，单列次要结果。Label oracle用标签拟合，不能当作可部署模型。','','## 长位移节点（>=4nm）','','下列为每设计长节点均值/误差后，设计等权再seed等权；仅含存在长节点的设计。幅度比为先逐设计求比值再取平均。','', '|Split|Base amplitude ratio|Rigid ratio|Hybrid ratio|Base long RMSD nm|Rigid long RMSD nm|Hybrid long RMSD nm|','|---|---:|---:|---:|---:|---:|---:|']
for group in ('train','validation'):
 rows=[d[group]['selected'] for d in v['seed_results'].values()]
 keys=['base_long_ratio','rigid_long_ratio','hybrid_long_ratio','base_long_rmsd_nm','rigid_long_rmsd_nm','hybrid_long_rmsd_nm']
 lines.append('|'+group+'|'+'|'.join(f'{np.mean([q[k] for q in rows]):.6f}' for k in keys)+'|')
lines+=['','## 机制与限制','','这不是Phase10的严格单因素消融：backbone被冻结、节点MSE改为domain变换监督、移除了幅度上限/零门，并按domain变换损失选点。只能诊断该固定预算下domain运动的可拟合性/验证表现，不能仅凭本轮认定联合损失竞争是唯一根因。',
       f"输入几何rank<2的domain共{pf['rotation_unidentifiable_domains']}个，旋转不可唯一辨识，已从旋转损失与角度统计排除；平移保留。Domain仍是virtual_helix×16轴向位点片段。", 
       '损失是平移向量平方误差加旋转矩阵平方Frobenius误差（1nm²权重），每设计domain等权、设计等权。它与节点macro RMSD不是同一个目标。',
       '每个seed使用其原始验证选中的localframe2m冻结checkpoint；缓存仅含初始几何与冻结base输出。直接标签变换仅用于loss/metrics。',
       '重复使用固定14验证设计、有限轨迹标签及3个seed不足以给出显著性、构象多模态或形状泛化结论。50epochs下失败也不等于不可学习。', '',
       '## 解释与下一步（未执行）', '', '3/3训练与验证都能部分拟合domain运动，排除了该分支完全无法学习任何运动的说法。但绝对误差仍大，且目标/架构/门控同时变化，不能证明联合MSE竞争是唯一根因。', 'Rigid-only在三个seed验证集上略优于base，但收益远低于0.05nm；加入base域内残差会回退，提示下一步应检验条件化的局部残差重训练，而非原样叠加冻结残差。训练后期loss下降而验证回升，需控制过拟合；未启动额外训练。', '', '## 完整性与运行记录', '',
       f"预检{len(pf['checks'])}项通过；独立核验{len(v['checks'])}项通过；246组设计CPU重现最大坐标偏差{v['max_prediction_coordinate_difference_nm']:.3e}nm。", 
       '三套冻结base状态hash前后与原checkpoint一致；所有数据、split、源文件hash核对通过。runner只训练DiagnosticHead参数，不把base参数交给优化器。',
       '首次attempt01在首个AdamW更新前因默认CUDA上下文触及占满的GPU0而退出；原日志/epoch0/runner完整归档。显式set_device(cuda1)后正常执行，模型/超参数/数据不变，无隐藏完整重跑。',
       '当前实际代码为diagnostic_model.py、run_experiment.py、verify_results_v2.py；初始复制的model.py/base_utils.py未使用。原verify_results.py保持训练时hash不变：第一次仅在JSON输出时失败，v2显式转换NumPy类型，并仅比较可辨识domain的旋转矩阵；没有重训。', '',
       '## 复现', '', '从仓库根运行：','```bash',
       '../hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase11_domain_supervision/verify_results_v2.py',
       '../hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase11_domain_supervision/write_report.py','```','不要覆盖或重启已有训练history。']
(R/'REPORT_ZH.md').write_text('\n'.join(lines)+'\n');print(R/'REPORT_ZH.md')
