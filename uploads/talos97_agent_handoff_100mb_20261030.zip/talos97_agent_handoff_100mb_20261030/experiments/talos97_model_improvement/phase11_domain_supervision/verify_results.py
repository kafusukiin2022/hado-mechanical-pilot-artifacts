#!/usr/bin/env python3
"""Independent numeric re-fitting/metric recomputation + CPU checkpoint reproduction."""
import json
from pathlib import Path
import numpy as np
import torch
import run_experiment as run
from diagnostic_model import DiagnosticHead
HERE=Path(__file__).resolve().parent

def independent_targets(x,y,index):
    """SVD of target-source covariance (opposite convention to runner)."""
    ts=[];rs=[];mask=[];oracle=np.empty_like(x)
    for k in range(int(index.max())+1):
        m=index==k;a=x[m];b=y[m];ac=a.mean(0);bc=b.mean(0)
        u,_,vt=np.linalg.svd((b-bc).T@(a-ac))
        fix=np.eye(3);fix[2,2]=np.linalg.det(u@vt);rot=u@fix@vt
        sv=np.linalg.svd(a-ac,compute_uv=False);rank=sum(sv>max(sv[0]*1e-6,1e-8))
        ts.append(bc-ac);rs.append(rot);mask.append(rank>=2);oracle[m]=(a-ac)@rot.T+bc
    return np.array(ts),np.array(rs),np.array(mask),oracle

def independent_metrics(t,r,x,y,index,bt,br,oracle):
    tt,rr,valid,oracle=independent_targets(x,y,index)
    t_error=np.sum((t-tt)**2,axis=1).mean()
    r_error=np.sum((r[valid]-rr[valid])**2,axis=(1,2)).mean() if valid.any() else 0.
    trace=np.trace(np.swapaxes(r[valid],1,2)@rr[valid],axis1=1,axis2=2)
    angles=np.degrees(np.arccos(np.clip((trace-1)/2,-1,1)))
    result=dict(loss=t_error+r_error,translation_rmse_nm=np.sqrt(t_error),rotation_deg=angles.mean() if valid.any() else 0.,
                rotation_frobenius=r_error,domains=len(t),identifiable_rotation_domains=int(valid.sum()))
    centers=np.stack([x[index==k].mean(0) for k in range(len(t))])
    rigid=np.einsum('nij,nj->ni',r[index],x-centers[index])+centers[index]+t[index]
    center=lambda a:a-a.mean(0)+x.mean(0)
    preds=dict(rigid=center(rigid),hybrid=center(rigid+br),additive=center(rigid+bt),base=x+bt,identity=x,oracle=oracle)
    long=np.linalg.norm(y-x,axis=1)>=4;result['long_nodes']=int(long.sum())
    for name,z in preds.items():
        result[name+'_rmsd_nm']=float(np.sqrt(np.mean(np.sum((z-y)**2,axis=1))))
        if long.any():
            result[name+'_long_ratio']=float(np.linalg.norm((z-x)[long],axis=1).mean()/np.linalg.norm((y-x)[long],axis=1).mean())
            result[name+'_long_rmsd_nm']=float(np.sqrt(np.mean(np.sum((z-y)[long]**2,axis=1))))
    return result,preds

def main():
    torch.set_num_threads(2)
    summary=json.loads((run.RESULTS/'summary.json').read_text());train,val=run.p10.read_train_validation_ids(run.DATA/'split.json')
    checks={};checks['split_68_14_boundary']=len(train)==68 and len(val)==14 and summary['train_ids']==train and summary['validation_ids']==val and not summary['test_ids_decoded'] and not summary['test_files_opened'] and not summary['test_inference']
    checks['protected_current_hashes']=summary['hashes_before']==summary['hashes_after']==run.protected(train+val)
    pf=json.loads((run.RESULTS/'preflight.json').read_text());checks['functional_preflight']=pf['passed'] and all(pf['checks'].values())
    all_counts=[];reproduced=[];max_prediction_diff=0.;max_metric_diff=0.;max_target_diff=0.;all_frozen=True;all_epochs=True;all_grads=True
    recomputed={};seed_results={}
    for seed in run.SEEDS:
        base=run.base_model(seed,torch.device('cpu'));cache=run.load_cache(base,train+val,torch.device('cpu'))
        folder=HERE/'runs'/f'seed{seed}';status=json.loads((folder/'status.json').read_text())
        histories=[json.loads(s) for s in (folder/'history.jsonl').read_text().splitlines()]
        all_epochs &= status['complete'] and [s['epoch'] for s in histories]==list(range(51)) and status['optimizer_steps']==3400
        best=min(range(51),key=lambda k:histories[k]['validation']['loss'])
        all_epochs &= best==status['best_epoch']
        # Every train epoch order hash checked independently from seeded RNG.
        rng=np.random.default_rng(seed)
        for row in histories[1:]:
            order=[str(i) for i in rng.permutation(train)]
            import hashlib
            all_epochs &= row['train_order_sha256']==hashlib.sha256('\n'.join(order).encode()).hexdigest()
        for prefix in ('projector','translation','rotation','layers.0','layers.1','layers.2'):
            gs=[sum(v for k,v in row['gradient_sums'].items() if k.startswith(prefix)) for row in histories[1:]]
            all_grads &= bool(np.isfinite(gs).all() and max(gs)>0)
        ck=torch.load(folder/'best.pt',map_location='cpu',weights_only=False)
        all_frozen &= status['base_before']==status['base_after']==ck['base_state_sha256']==run.state_hash(base.state_dict()) and all(not p.requires_grad and p.grad is None for p in base.parameters())
        all_epochs &= status['checkpoint_sha256']==run.sha(folder/'best.pt') and status['prediction_sha256']==run.sha(folder/'predictions_train_validation.npz')
        model=DiagnosticHead();model.load_state_dict(ck['state'],strict=True);model.eval()
        saved_metrics=json.loads((folder/'metrics.json').read_text());per={}
        with np.load(folder/'predictions_train_validation.npz') as arrays, torch.no_grad():
            expected={i+'__'+k for i in train+val for k in ('t','r','rigid','hybrid','additive')}
            all_epochs &= set(arrays.files)==expected
            for ident in train+val:
                d=cache[ident];raw=run.p10.build_raw(ident);x=raw['pos'].astype(float)*run.NM;idx=np.unique(raw['domain_ids'],return_inverse=True)[1]
                with np.load(run.DATA/'labels'/f'{ident}.npz') as a:y=a['target_pos'].astype(float)*run.NM
                tt,rr,valid,oracle=independent_targets(x,y,idx)
                max_target_diff=max(max_target_diff,float(np.max(np.abs(tt-d['translation'].numpy()))),float(np.max(np.abs(rr-d['rotation'].numpy()))))
                all_frozen &= np.array_equal(valid,d['valid'].numpy()) and np.max(np.abs(np.linalg.det(rr)-1))<1e-8
                t,r=model(d['pooled'],d['graph']);t=t.numpy().astype(float);r=r.numpy().astype(float)
                max_prediction_diff=max(max_prediction_diff,float(np.max(np.abs(t-arrays[ident+'__t']))),float(np.max(np.abs(r-arrays[ident+'__r']))))
                bt=d['base_delta'].numpy().astype(float)
                _,_,_,basefit=independent_targets(x,x+bt,idx)
                residual=x+bt-basefit
                max_target_diff=max(max_target_diff,float(np.max(np.abs(residual-d['base_residual'].numpy()))))
                m,preds=independent_metrics(t,r,x,y,idx,bt,residual,oracle);per[ident]=m
                group='train' if ident in train else 'validation'
                for k,v in m.items():
                    # rotation angles near zero are float32-sensitive; allow0.002degree only there.
                    diff=abs(v-saved_metrics[group]['per_design'][ident][k])
                    if k=='rotation_deg':all_frozen &= diff<.002
                    else:max_metric_diff=max(max_metric_diff,diff)
                for name in ('rigid','hybrid','additive'):
                    max_prediction_diff=max(max_prediction_diff,float(np.max(np.abs(preds[name]-arrays[ident+'__'+name]))))
                reproduced.append([seed,ident])
        stats={}
        for group,ids in (('train',train),('validation',val)):
            keys=set.intersection(*(set(per[i]) for i in ids))
            macro={k:float(np.mean([per[i][k] for i in ids])) for k in sorted(keys)}
            for k,v in macro.items():
                diff=abs(v-saved_metrics[group]['macro'][k])
                if k=='rotation_deg':all_frozen &= diff<.002
                else:max_metric_diff=max(max_metric_diff,diff)
            baseline=histories[0][group]
            improved=macro['loss']<=baseline['loss']*.9 and macro['translation_rmse_nm']<=baseline['translation_rmse_nm']+1e-6 and macro['rotation_deg']<=baseline['rotation_deg']+1e-6
            stats[group]=dict(baseline=baseline,selected=macro,passes_fitting_screen=bool(improved))
        seed_results[str(seed)]=dict(best_epoch=best,**stats);recomputed[str(seed)]=per
    checks['all_runs_best_epochs_orders_hashes_prediction_keys']=bool(all_epochs)
    checks['frozen_base_matches_original_all_runs']=bool(all_frozen)
    checks['all_layers_nonzero_real_training_gradients']=bool(all_grads)
    checks['independent_target_and_residual_refits']=max_target_diff<1e-4
    checks['all246_cpu_prediction_reproduction']=len(reproduced)==246 and max_prediction_diff<1e-4
    checks['independent_selected_metrics_recompute']=max_metric_diff<1e-4
    checks['optimizer_steps_10200']=summary['optimizer_steps']==10200
    result=dict(passed=all(checks.values()),checks=checks,seed_results=seed_results,
        max_prediction_coordinate_difference_nm=max_prediction_diff,max_metric_difference=max_metric_diff,max_target_difference=max_target_diff,
        train_seeds_passing=sum(v['train']['passes_fitting_screen'] for v in seed_results.values()),
        validation_seeds_passing=sum(v['validation']['passes_fitting_screen'] for v in seed_results.values()),
        test_files_opened=False,verifier_sha256=run.sha(Path(__file__)))
    run.atomic(run.RESULTS/'verification.json',result);run.atomic(run.RESULTS/'independent_per_design.json',recomputed)
    print(json.dumps(result,indent=2));return 0 if result['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
