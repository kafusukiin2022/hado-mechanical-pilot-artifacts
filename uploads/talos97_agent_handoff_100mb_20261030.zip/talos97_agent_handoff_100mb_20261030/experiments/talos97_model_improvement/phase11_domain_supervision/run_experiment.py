#!/usr/bin/env python3
"""Frozen-backbone direct domain supervision, validation-only selection."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import time
import numpy as np
import torch
from diagnostic_model import DiagnosticHead, p10, PHASE10

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
DATA=ROOT/'experiments/talos97_endpoint_v1/data'
BASE=ROOT/'experiments/talos97_localframe_2m'
RESULTS=HERE/'results'
SEEDS=(11,22,33)
EPOCHS=50
NM=34.072
SOURCES=[HERE/n for n in ('SPEC.md','EXPECTED_VERIFICATION.md','diagnostic_model.py','run_experiment.py','verify_results.py')]+[PHASE10,BASE/'model.py']

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def atomic(path,d):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');tmp.replace(path)

def state_hash(state):
    h=hashlib.sha256()
    for k,v in sorted(state.items()):
        h.update(k.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()

def fits(x,y,index):
    """Proper column-action rotations and centroid translations in nm (float64)."""
    count=int(index.max())+1;ts=[];rs=[];valid=[];pred=np.empty_like(y,dtype=float)
    for k in range(count):
        m=index==k;a=x[m].astype(float);b=y[m].astype(float);c=a.mean(0);q=b.mean(0)
        u,s,vt=np.linalg.svd((a-c).T@(b-q));fix=np.eye(3);fix[-1,-1]=np.linalg.det(vt.T@u.T)
        r=vt.T@fix@u.T;t=q-c
        sv=np.linalg.svd(a-c,compute_uv=False);rank=int(np.sum(sv>max(sv[0]*1e-6,1e-8)))
        ts.append(t);rs.append(r);valid.append(rank>=2)
        pred[m]=(a-c)@r.T+c+t
    return np.asarray(ts),np.asarray(rs),np.asarray(valid),pred

def protected(ids):
    paths=SOURCES+[DATA/'split.json',DATA/'manifest.json']
    paths += [BASE/'checkpoints'/f'frame_{seed}.pt' for seed in SEEDS]
    paths += [DATA/k/f'{i}.npz' for i in ids for k in ('inputs','labels')]
    return {str(p.resolve()):sha(p) for p in paths}

def base_model(seed,device):
    base=p10.make_model(seed,'control',device).eval()
    for p in base.parameters():p.requires_grad_(False)
    return base

def load_cache(base,ids,device):
    cache={}
    for ident in ids:
        raw=p10.build_raw(ident)
        with np.load(DATA/'labels'/f'{ident}.npz') as a:target=a['target_pos'].astype(float)*NM
        x=raw['pos'].astype(float)*NM
        graph=p10.coarse_graph(raw,device);index=graph['index'].cpu().numpy()
        tt,rr,valid,oracle=fits(x,target,index)
        s,B,R=p10.geometry(raw,multiscale=True)
        with torch.no_grad():
            s,B,R=[torch.as_tensor(v,device=device) for v in (s,B,R)]
            _,h=base.encode(s);delta=base.readout(h,B,R)[0].cpu().numpy().astype(float)
            pooled=p10.segment_mean(h[:,:346],graph['index'],len(graph['frames'])).detach()
        _,_,_,base_fit=fits(x,x+delta,index)
        residual=x+delta-base_fit  # input and frozen prediction ONLY
        def tensor(v,dtype=torch.float32):return torch.as_tensor(v,device=device,dtype=dtype)
        cache[ident]=dict(graph=graph,pooled=pooled,x=tensor(x),target=tensor(target),
                         translation=tensor(tt),rotation=tensor(rr),valid=tensor(valid,torch.bool),
                         oracle=tensor(oracle),base_delta=tensor(delta),base_residual=tensor(residual))
    return cache

def loss_terms(t,r,d):
    translation=(t-d['translation']).square().sum(-1).mean()
    mask=d['valid'];rotation=(r[mask]-d['rotation'][mask]).square().sum((-1,-2)).mean() if mask.any() else r.sum()*0
    return translation+rotation,translation,rotation

def reconstruct(t,r,d):
    index=d['graph']['index'];center=d['graph']['centers'];x=d['x']
    rigid=torch.einsum('nij,nj->ni',r[index],x-center[index])+center[index]+t[index]
    def centered(y):return y-y.mean(0)+x.mean(0)
    return {'rigid':centered(rigid),'hybrid':centered(rigid+d['base_residual']),
            'additive':centered(rigid+d['base_delta'])}

def metrics(t,r,d):
    loss,tl,rl=loss_terms(t,r,d);m=d['valid']
    trace=(r[m].transpose(-1,-2)@d['rotation'][m]).diagonal(dim1=-2,dim2=-1).sum(-1)
    angle=torch.acos(((trace-1)/2).clamp(-1,1))*180/np.pi
    out=dict(loss=float(loss),translation_rmse_nm=float(tl.sqrt()),rotation_deg=float(angle.mean()) if len(angle) else 0,
             rotation_frobenius=float(rl),domains=len(t),identifiable_rotation_domains=int(m.sum()))
    predictions=reconstruct(t,r,d)
    predictions.update(base=d['x']+d['base_delta'],identity=d['x'],oracle=d['oracle'])
    long=(d['target']-d['x']).norm(dim=1)>=4
    out['long_nodes']=int(long.sum())
    for name,y in predictions.items():
        out[name+'_rmsd_nm']=float((y-d['target']).square().sum(-1).mean().sqrt())
        if long.any():
            out[name+'_long_ratio']=float((y-d['x'])[long].norm(dim=1).mean()/(d['target']-d['x'])[long].norm(dim=1).mean())
            out[name+'_long_rmsd_nm']=float((y-d['target'])[long].square().sum(-1).mean().sqrt())
    return out

def evaluate(model,cache,ids,save=False):
    model.eval();per={};arrays={}
    with torch.no_grad():
        for ident in ids:
            d=cache[ident];t,r=model(d['pooled'],d['graph']);per[ident]=metrics(t,r,d)
            if save:
                arrays[ident+'__t']=t.cpu().numpy();arrays[ident+'__r']=r.cpu().numpy()
                for name,y in reconstruct(t,r,d).items():arrays[ident+'__'+name]=y.cpu().numpy()
    keys=set.intersection(*(set(row) for row in per.values()))
    macro={k:float(np.mean([row[k] for row in per.values()])) for k in sorted(keys)}
    return dict(macro=macro,per_design=per),arrays

def preflight(base,model,cache,train):
    d=cache[max(train,key=lambda i:len(cache[i]['x']))]
    with torch.no_grad():t,r=model(d['pooled'],d['graph'])
    checks={'identity_init':float(t.abs().max())==0 and float((r-torch.eye(3,device=r.device)).abs().max())<1e-7,
            'base_frozen':all(not p.requires_grad for p in base.parameters()),
            'targets_proper':all(float((torch.linalg.det(c['rotation'])-1).abs().max())<1e-5 for c in cache.values())}
    # Disposable open-head probe permits gradients into all upstream message layers.
    probe=DiagnosticHead().to(d['x'].device);probe.load_state_dict(model.state_dict())
    with torch.no_grad():
        for h in (probe.translation,probe.rotation):h[-1].weight.normal_(0,.001)
    t,r=probe(d['pooled'],d['graph']);loss=loss_terms(t,r,d)[0];loss.backward()
    groups={'projector':probe.projector,'translation':probe.translation,'rotation':probe.rotation,
            **{f'layer_{k}':layer for k,layer in enumerate(probe.layers)}}
    grads={k:float(sum(p.grad.abs().sum() for p in mod.parameters() if p.grad is not None)) for k,mod in groups.items()}
    checks['all_branch_gradients']=all(np.isfinite(v) and v>0 for v in grads.values())
    checks['base_no_grad']=all(p.grad is None for p in base.parameters())
    checks['finite_largest_backward']=bool(torch.isfinite(loss))
    # SE3 equivariance of open-head outputs, with cached scalar invariants unchanged.
    q=d['x'].new_tensor([[0,-1,0],[1,0,0],[0,0,1]])
    g=dict(d['graph']);g['frames']=q@g['frames']
    with torch.no_grad():
        ta,ra=probe(d['pooled'],d['graph']);tb,rb=probe(d['pooled'],g)
        equiv=max(float((tb-ta@q.T).abs().max()),float((rb-q@ra@q.T).abs().max()))
    checks['cached_frame_equivariance']=equiv<2e-5
    # End-to-end input rotation and integer domain relabeling, train sample only.
    ident=max(train,key=lambda i:len(cache[i]['x']))
    raw=p10.build_raw(ident);qn=q.cpu().numpy()
    rotated=dict(raw,pos=raw['pos']@qn.T,rotation=np.einsum('ij,njk->nik',qn,raw['rotation']))
    def encode_raw(raw):
        s,B,R=p10.geometry(raw,multiscale=True);g=p10.coarse_graph(raw,d['x'].device)
        with torch.no_grad():
            _,h=base.encode(torch.as_tensor(s,device=d['x'].device))
            pooled=p10.segment_mean(h[:,:346],g['index'],len(g['frames']))
            return probe(pooled,g)
    with torch.no_grad():
        tr,rr=encode_raw(rotated);t0,r0=encode_raw(raw)
        end_error=max(float((tr-t0@q.T).abs().max()),float((rr-q@r0@q.T).abs().max()))
        tl,rl=encode_raw(p10.relabel_domains(raw))
        # Relabel maps domain order; compare per-node translations/rotations.
        original=p10.coarse_graph(raw,d['x'].device)['index']
        relabeled=p10.coarse_graph(p10.relabel_domains(raw),d['x'].device)['index']
        relabel_error=max(float((tl[relabeled]-t0[original]).abs().max()),float((rl[relabeled]-r0[original]).abs().max()))
    checks['end_to_end_rotation']=end_error<2e-4
    checks['domain_relabel']=relabel_error<1e-5
    rng=np.random.default_rng(993);sx=rng.normal(size=(30,3));sq=np.array([[0.,-1.,0.],[1.,0.,0.],[0.,0.,1.]])
    st=np.array([1.,2.,3.]);sy=(sx-sx.mean(0))@sq.T+sx.mean(0)+st
    ft,fr,fv,fy=fits(sx,sy,np.zeros(30,dtype=int))
    checks['synthetic_kabsch_convention']=bool(np.max(np.abs(fr[0]-sq))<1e-10 and np.max(np.abs(ft[0]-st))<1e-10 and np.max(np.abs(fy-sy))<1e-10)
    return dict(passed=all(checks.values()),checks=checks,gradients=grads,frame_equivariance_error=equiv,end_to_end_error=end_error,relabel_error=relabel_error,
                largest_nodes=len(d['x']),optimizer_steps=0,
                rotation_unidentifiable_domains=sum(int((~v['valid']).sum()) for v in cache.values()))

def run_seed(seed,train,val,device):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    base=base_model(seed,device);before=state_hash(base.state_dict());cache=load_cache(base,train+val,device)
    model=DiagnosticHead().to(device)
    if seed==11:
        pf=preflight(base,model,cache,train);atomic(RESULTS/'preflight.json',pf)
        if not pf['passed']:raise RuntimeError('preflight failed')
    folder=HERE/'runs'/f'seed{seed}';folder.mkdir(parents=True,exist_ok=True)
    history=folder/'history.jsonl'
    if history.exists():raise FileExistsError(history)
    optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
    rng=np.random.default_rng(seed);best=float('inf');best_epoch=-1;best_state=None;start=time.time()
    for epoch in range(EPOCHS+1):
        order_hash=None;gradient_sums={}
        if epoch:
            model.train();order=[str(i) for i in rng.permutation(train)];order_hash=hashlib.sha256('\n'.join(order).encode()).hexdigest()
            for ident in order:
                d=cache[ident];optimizer.zero_grad(set_to_none=True)
                t,r=model(d['pooled'],d['graph']);loss=loss_terms(t,r,d)[0]
                if not torch.isfinite(loss):raise RuntimeError('nonfinite loss')
                loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5)
                for k,p in model.named_parameters():
                    if p.grad is not None:gradient_sums[k]=gradient_sums.get(k,0)+float(p.grad.abs().sum())
                optimizer.step()
        tr,_=evaluate(model,cache,train);va,_=evaluate(model,cache,val)
        row=dict(epoch=epoch,train=tr['macro'],validation=va['macro'],train_order_sha256=order_hash,gradient_sums=gradient_sums)
        with history.open('a') as f:f.write(json.dumps(row)+'\n')
        if va['macro']['loss']<best:
            best=va['macro']['loss'];best_epoch=epoch;best_state={k:v.cpu().clone() for k,v in model.state_dict().items()}
        atomic(folder/'status.json',dict(seed=seed,epoch=epoch,best_epoch=best_epoch,best_loss=best,complete=False,elapsed_seconds=time.time()-start))
        if epoch%10==0 or epoch==1:print('seed',seed,'epoch',epoch,'trainloss',tr['macro']['loss'],'valloss',va['macro']['loss'],'best',best_epoch,flush=True)
    assert state_hash(base.state_dict())==before and all(p.grad is None for p in base.parameters())
    model.load_state_dict(best_state);tr,arrays=evaluate(model,cache,train,True);va,arr=evaluate(model,cache,val,True);arrays.update(arr)
    np.savez_compressed(folder/'predictions_train_validation.npz',**arrays)
    torch.save(dict(state=best_state,seed=seed,best_epoch=best_epoch,base_state_sha256=before),folder/'best.pt')
    atomic(folder/'metrics.json',dict(train=tr,validation=va))
    status=dict(seed=seed,epoch=50,best_epoch=best_epoch,best_loss=best,complete=True,base_before=before,base_after=state_hash(base.state_dict()),
                checkpoint_sha256=sha(folder/'best.pt'),prediction_sha256=sha(folder/'predictions_train_validation.npz'),optimizer_steps=50*len(train),elapsed_seconds=time.time()-start)
    atomic(folder/'status.json',status);return status

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--device',default='cuda:1');args=parser.parse_args()
    os.environ['WANDB_MODE']='disabled';torch.set_num_threads(2)
    device=torch.device(args.device)
    if device.type=='cuda':torch.cuda.set_device(device)
    train,val=p10.read_train_validation_ids(DATA/'split.json')
    assert len(train)==68 and len(val)==14 and len(set(train+val))==82
    before=protected(train+val);atomic(RESULTS/'provenance_before.json',before)
    statuses=[run_seed(seed,train,val,device) for seed in SEEDS]
    after=protected(train+val)
    atomic(RESULTS/'summary.json',dict(train_ids=train,validation_ids=val,runs=statuses,hashes_before=before,hashes_after=after,
        optimizer_steps=3*50*68,device=str(device),torch_version=torch.__version__,numpy_version=np.__version__,
        test_ids_decoded=False,test_files_opened=False,test_inference=False,base_unchanged=True))
    assert before==after
    print('ALL TRAINING COMPLETE',flush=True)

if __name__=='__main__':main()
