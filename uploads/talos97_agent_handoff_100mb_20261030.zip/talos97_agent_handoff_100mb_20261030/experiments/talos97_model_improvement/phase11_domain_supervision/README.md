# Phase11 frozen-backbone domain supervision

Completed:3seeds x50epochs,10200updates. Fitting screen3/3train andvalidation,
but hybrid endpoint RMSD does not consistently beat frozen base.
See results/REPORT_ZH.md and results/verification.json (independent10/10pass).

Actual runner/model:run_experiment.py,diagnostic_model.py;old model.py/base_utils.py scaffold unused.
Do not repeat training into existing histories.

Verify from repository root:
`../hado_mechanical_pilot/.venv-torch/bin/python experiments/talos97_model_improvement/phase11_domain_supervision/verify_results_v2.py`

Original verifier preserved for training provenance;v2 corrects JSONscalar types
and nonidentifiable-rotation comparisons. Attempt01runtime failure before any
optimizer update archived. No test evaluation or W&B.
