#!/usr/bin/env python3
"""Run from any working directory; CPU only; no full-dataset/test access."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'experiments/talos97_gnn_diagnostics'))
import common as c


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path);args=ap.parse_args()
    torch.set_num_threads(2)
    manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
    bad=[name for name,digest in manifest.items() if not (ROOT/name).is_file() or sha(ROOT/name)!=digest]
    if bad:raise RuntimeError('Package hash failures: '+str(bad))
    subset=json.loads((ROOT/'SUBSET.json').read_text());selected=subset['train']+subset['validation']
    expected=json.loads((ROOT/'experiments/talos97_gnn_diagnostics/results/reconstruction.json').read_text())
    records=[];maxcoordinate=0.;maxmetric=0.
    for seed in [11,22,33]:
        base,head=c.models(seed,torch.device('cpu'))
        originals=np.load(ROOT/f'experiments/talos97_model_improvement/phase11_domain_supervision/runs/seed{seed}/predictions_subset.npz')
        for ident in selected:
            raw=c.p10.build_raw(ident)
            with np.load(c.old.DATA/'labels'/f'{ident}.npz') as a:y=a['target_pos'].astype(float)*c.NM
            x=raw['pos'].astype(float)*c.NM;s,B,R=c.p10.geometry(raw,True);g=c.p10.coarse_graph(raw,torch.device('cpu'))
            with torch.no_grad():
                _,h=base.encode(torch.as_tensor(s));delta=c.npv(base.readout(h,torch.as_tensor(B),torch.as_tensor(R))[0])
                pooled=c.p10.segment_mean(h[:,:346],g['index'],len(g['frames']));t,r=head(pooled,g)
            t,r=c.npv(t),c.npv(r);ix=c.npv(g['index'])
            _,_,_,basefit=c.old.fits(x,x+delta,ix)
            pred=c.centered(c.rigid(x,ix,t,r),x);hybrid=c.centered(pred+x+delta-basefit,x)
            values={'base_rmsd_nm':c.endpoint(x+delta,y),'rigid_rmsd_nm':c.endpoint(pred,y),'hybrid_rmsd_nm':c.endpoint(hybrid,y)}
            reference=expected[str(seed)]['per_design'][ident]
            maxmetric=max(maxmetric,max(abs(v-reference[k]) for k,v in values.items()))
            maxcoordinate=max(maxcoordinate,float(np.max(np.abs(t-originals[ident+'__t']))),float(np.max(np.abs(r-originals[ident+'__r']))),
                              float(np.max(np.abs(pred-originals[ident+'__rigid']))),float(np.max(np.abs(hybrid-originals[ident+'__hybrid']))))
            records.append(dict(seed=seed,design=ident,split='train' if ident in subset['train'] else 'validation',**values))
            print(f'{seed} {ident}: base={values["base_rmsd_nm"]:.6f} rigid={values["rigid_rmsd_nm"]:.6f} hybrid={values["hybrid_rmsd_nm"]:.6f}',flush=True)
        originals.close()
    result=dict(passed=maxcoordinate<1e-4 and maxmetric<1e-4,hash_files_checked=len(manifest),
                subset_designs=len(selected),seed_design_outputs=len(records),records=records,
                max_prediction_coordinate_error_nm=maxcoordinate,max_endpoint_metric_error_nm=maxmetric,
                test_data_used=False,training_performed=False,device='cpu',
                torch_version=torch.__version__,numpy_version=np.__version__,
                full68_14_reproduction=False)
    if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
    if not result['passed']:raise SystemExit(1)


if __name__=='__main__':main()
