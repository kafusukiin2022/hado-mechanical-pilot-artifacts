# DNA Origami EBD Plan

This project direction is to adapt EBD as the main hierarchy-aware generative backbone for DNA origami conformer generation, with an oxDNA-compatible output target. The model may use coarse hierarchy internally, but the first useful deliverable must be a predicted nucleotide rigid-body configuration that can be written to an oxDNA `.dat` or `.conf` file and opened in oxView with the matching `.top` file.

## Long-Term Direction

- Target hardware: NVIDIA A6000 or A100.
- Primary backbone: EBD-style hierarchical endpoint diffusion.
- Required output target: per-nucleotide oxDNA rigid-body state, not only coarse centers.
- Secondary module: torsional diffusion only for interpretable rotations on a coarse graph after the exportable output path exists.
- Avoid starting with unconstrained full nucleotide-backbone torsion diffusion from `.top` alone.

## Rationale

Torsional Diffusion is designed for small molecules where conformational flexibility is dominated by a limited set of freely rotatable bonds. It keeps local structure fixed and diffuses only torsion angles. DNA origami does not fit that assumption directly: relaxation can involve helix bending, domain rotation, crossover constraints, local stacking, and global bending. A `.top` file only gives strand prev/next relations and does not by itself define base-pair, crossover, helix, or domain structure.

EBD is a better starting point because it is coarse-to-fine. It first generates a coarse fragment-level 3D structure, then restores fine atom-level detail. DNA origami naturally has hierarchy:

- level 0: nucleotide
- level 1: base pair or base-pair center
- level 2: helix segment
- level 3: domain, bundle, or connected component

The important change for this project is that "fine detail" means oxDNA nucleotide rigid bodies. Predicting only one 3D coordinate per nucleotide is still a coarse representation and is not enough to write a valid oxDNA configuration. The exportable output must include each nucleotide position and local orientation frame.

## First-Version Mainline

Use EBD-style hierarchical endpoint diffusion rather than full torsional diffusion, but make the final decoder export oxDNA-compatible nucleotide states.

Inputs:
- oxDNA `.top` file, preserving nucleotide order.
- Initial oxDNA `.dat` or `.conf` file.
- Optional relaxed/final oxDNA `.dat` or `.conf` file for supervised targets.
- Topology/design graph derived from or aligned to the `.top`.
- Backbone edges.
- Base-pair/complement edges.
- Crossover edges.
- Strand, helix, and domain IDs.
- Initial nucleotide rigid-body conformation.
- Coarse node coordinates, such as base-pair or helix-segment centers.
- Local frames, including oxDNA nucleotide frame directions and derived helix/base-pair frames.

Outputs:
- Predicted per-nucleotide position and orientation:
  - `r_i`: nucleotide position.
  - `a1_i`: oxDNA nucleotide orientation vector.
  - `a3_i`: oxDNA nucleotide orientation vector.
- Exported oxDNA `.dat` or `.conf` file with nucleotide rows in `.top` order.
- Optional velocities and angular velocities initialized to zero or inherited from the input template.
- Coarse diagnostic outputs such as base-pair centers, helix-segment frames, and displacement fields.

Diffusion:
- Coarse stage: predict final coarse base-pair, helix-segment, or domain frame displacement.
- Fine stage: condition on coarse final structure and reconstruct each nucleotide rigid body.
- Export stage: normalize frames, enforce file ordering, write oxDNA configuration, and validate with oxView-oriented checks.

First-version target:

- Predict displacement and rotation from the initial oxDNA state to the aligned relaxed oxDNA state.
- Train the hierarchy on base-pair or helix-segment frames, then decode to per-nucleotide `r_i, a1_i, a3_i`.
- Treat oxDNA short relaxation as an allowed post-processing step for local geometry cleanup, not as a substitute for producing a valid configuration.

## Torsional Module Role

Do not directly diffuse every nucleotide backbone dihedral in the first version. Instead, define coarse, interpretable rotational degrees of freedom:

- Relative rotation between adjacent helix segments.
- Relative twist or bend across crossover-connected domain frames.
- Hinge-like angles between bundles or domains.

In this framing:

- EBD is the main architecture.
- Torsional Diffusion is an auxiliary module over coarse graph rotations.

## oxDNA Export Requirement

The model result is not considered useful unless it can be converted into an oxDNA configuration file that loads with the original `.top` in oxView.

Minimum export contract:

- Same nucleotide count and ordering as the `.top`.
- One row per nucleotide with position, `a1`, `a3`, velocity, and angular velocity fields.
- `a1` and `a3` are finite, unit-length, and mutually valid as an oxDNA local frame.
- No NaN or infinite coordinates.
- Box/header fields are inherited from the template or generated large enough for the predicted structure.
- The file opens in oxView with the matching `.top`.

See `docs/OXDNA_OUTPUT_SPEC.md` for the detailed output specification.

## Definition Table To Build Next

For each hierarchy level, define:

- Node meaning.
- Edge meaning.
- Coordinate and frame construction from oxDNA frames.
- Final target alignment.
- Baseline computation.
- Decoder path to nucleotide `r_i, a1_i, a3_i`.
- Export and validation checks needed before oxView loading.

The next design decision is whether the first coarse training target should operate at base-pair frame level or helix-segment frame level. The final output requirement is fixed: nucleotide rigid-body states that can be exported to oxDNA.

## Information Needed Before Implementation

See `docs/DNA_ORIGAMI_OPEN_QUESTIONS.md`.

## Wireframe 6HB Candidate Priority (2026-07-31)

The paired Athena/Mango harness now records an application-oriented 6HB
evidence synthesis at
`../../athena_generativesnupi/docs/6HB_APPLICATION_RESEARCH_20260731.md` and
an indexable companion graph at
`../../athena_generativesnupi/docs/6HB_KNOWLEDGE_GRAPH.json`.

For the first topology-to-conformation inverse-design benchmark, prioritize
compact tetrahedral 6HB cages at 42--84 bp edges, then compare a planar
triangle/pentagon and a hollow octahedral cage. Each sample must retain strict
Mango/TALOS/tacoxDNA/oxDNA acceptance metadata. This ordering is an
evidence-backed experimental priority, not a claim that tetrahedra are the
universally optimal DNA-origami structure.
