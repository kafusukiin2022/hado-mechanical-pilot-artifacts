# Representation diagnostic tools

Installed for the current TALOS97 analysis environment (not the legacy `ebd` conda environment):

```bash
../hado_mechanical_pilot/.venv-torch/bin/python your_analysis.py
```

Requested packages: TorchLens (real intermediate tensors and execution paths),
Captum (feature/layer attribution and ablation), Polyscope (interactive 3D),
and PyVista/VTK (3D data processing and visualization).
Linear and nonlinear probing are analysis methods rather than a separate package;
the environment provides PyTorch and scikit-learn (`Ridge`, `MLPRegressor`).
Use whole-design train/validation separation for probes, not random node splits.

Installation preserves the existing torch, numpy, scipy, scikit-learn and
torch-geometric versions using explicit constraints:

```bash
uv pip install --python ../hado_mechanical_pilot/.venv-torch/bin/python \
  --constraint outputs/representation_tools_install_20261030/constraints.txt \
  torchlens captum polyscope pyvista
```

Installation versions and CPU smoke results are recorded in
`outputs/representation_tools_install_20261030/verification.json`.
Re-run the checks with:

```bash
../hado_mechanical_pilot/.venv-torch/bin/python \
  outputs/representation_tools_install_20261030/smoke.py
uv pip check --python ../hado_mechanical_pilot/.venv-torch/bin/python
```

Smoke scope: TorchLens forward recording; Captum integrated gradients and feature
ablation; linear/nonlinear regressor fitting; PyVista/VTK point-cloud file
roundtrip; Polyscope import and API availability. No GPU, project dataset, or
checkpoint is used. Interactive GUI rendering is not included in this check;
Polyscope needs a display/OpenGL context. PyVista offscreen rendering also needs
a working rendering backend and is not established by successful file I/O.

This installation does not run representation analysis or retrain a model.

Verified installed versions: TorchLens 2.36.1, Captum 0.9.0, Polyscope 2.6.1,
PyVista 0.49.2, VTK 9.7.1. All CPU smoke checks and dependency checks passed.
TorchLens 2.x uses `torchlens.trace(model, x)`; the older
`log_forward_pass` entry point is no longer active.
