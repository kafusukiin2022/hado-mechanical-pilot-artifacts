# Verification

This document defines how agents prove that work is complete.

## Standard Command

Run:

```bash
./init.sh
```

## Current Behavior

`init.sh` checks:
- Git status, when available.
- Whether common project manifests exist.
- Whether required harness files are present.

The downloaded `EBD/` repository has its own environment and execution instructions in `EBD/README.md`. The conda environment, datasets, checkpoints, training, generation, and evaluation have not been run by this harness.

## EBD Repository Checks

Basic repository check:

```bash
cd EBD && git remote -v
```

Use CodeGraph for structural exploration inside `EBD/` when the index is available.

## EBD GPU Environment

Use and verification instructions are in `docs/EBD_ENVIRONMENT.md`.

## oxDNA Export Verification

The DNA origami adaptation is not complete if it only predicts coordinates. Export-oriented work must also verify the contract in `docs/OXDNA_OUTPUT_SPEC.md`:

- Generated nucleotide row count matches the `.top`.
- Predicted `r`, `a1`, and `a3` values are finite.
- Orientation vectors are normalized and form valid local frames.
- Box/header fields are present and contain the predicted structure.
- The generated `.dat` or `.conf` opens with the matching `.top` in oxView.

Current local checks:

```bash
python3 -m unittest discover -s tests -v
python3 -m py_compile oxdna_export/*.py ebd_oxdna/*.py scripts/oxdna_roundtrip.py scripts/ebd_oxdna_predict.py scripts/ebd_oxdna_bridge_smoke.py scripts/ebd_oxdna_egnn_smoke.py
bash -n jobs/geodiff_fam_oxdna_roundtrip_smoke.slurm
```

Roundtrip a real oxDNA input:

```bash
python3 scripts/oxdna_roundtrip.py \
  --top path/to/design.top \
  --input path/to/input.dat \
  --output outputs/roundtrip.dat
```

Optional Slurm smoke run when real files are available:

```bash
TOP_FILE=/abs/path/design.top \
CONF_FILE=/abs/path/input.dat \
sbatch jobs/geodiff_fam_oxdna_roundtrip_smoke.slurm
```

Real-data smoke evidence from the nupack `2e6_2000_all` dataset is recorded under `outputs/real_oxdna_roundtrip/`. The current check validates existing `triangle.top`, `start.conf`, and `md_last.conf` pairs as format-compatible inputs and outputs; it does not imply every design reached the same MD step.

## EBD oxDNA Model-Output Verification

The first model-output path is verified with synthetic tests and the small real `101_50_bp_nicked` design.

Identity smoke:

```bash
python3 scripts/ebd_oxdna_predict.py \
  --top /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/triangle.top \
  --start /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/start.conf \
  --mode identity \
  --output outputs/ebd_oxdna_model_smoke/101_50_bp_nicked/predicted_identity.conf
```

Overfit smoke:

```bash
python3 scripts/ebd_oxdna_predict.py \
  --top /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/triangle.top \
  --start /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/start.conf \
  --target /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/md_last.conf \
  --mode overfit \
  --epochs 200 \
  --output outputs/ebd_oxdna_model_smoke/101_50_bp_nicked/predicted_overfit.conf
```

Both outputs should be revalidated with `scripts/oxdna_roundtrip.py`. Manual oxView loading still requires a graphical/browser session with the matching `.top`.

An oxView auto-loader page is available at:

```text
outputs/ebd_oxdna_model_smoke/101_50_bp_nicked/open_ebd_oxdna_predictions.html
```

Serve `/home/lijingjing/lijj/users/lht2/deeporigami/agent` and open:

```text
http://127.0.0.1:<port>/Geodiff_fam/outputs/ebd_oxdna_model_smoke/101_50_bp_nicked/open_ebd_oxdna_predictions.html
```

## oxView Comparison Page Verification

Reusable comparison-page instructions are stored in `docs/templates/OXVIEW_COMPARISON_TEMPLATE.md`.

For the current DGNN-lite comparison page:

```bash
ps -p "$(cat outputs/oxview_compare_130_15_243/http_8001.pid)" -o pid,stat,cmd
curl -I http://127.0.0.1:8001/outputs/oxview_compare_130_15_243/index.html
curl -I http://127.0.0.1:8001/outputs/oxview_compare_130_15_243/viewer.html
curl -I http://127.0.0.1:8001/oxdna-viewer/
```

Model files used by oxView must have a numeric first header line, for example:

```text
t = 2000000
```

If a model pane says it loaded but appears blank while the original pane works, check that the page is using `model_dgnn_lite_200e_oxview.conf`, not the raw training export with a non-numeric timestep label.

## DGNN-lite Watson-Crick / Helix Physical Evaluation

To score whether an existing `.conf` prediction respects complementary pairing and local helix rules, run:

```bash
python3 scripts/ebd_oxdna_physical_eval.py \
  --top /abs/path/design.top \
  --start /abs/path/start.conf \
  --target /abs/path/md_last.conf \
  --predicted /abs/path/predicted.conf \
  --summary-json outputs/physical_eval_summary.json
```

The resulting JSON records:

- `predicted_wc_complementarity`
- `predicted_wc_occupancy`
- `predicted_wc_precision`
- `predicted_wc_recall`
- `predicted_wc_f1`
- `reference_pair_distance_rms_error`
- `helix_step_distance_mae`
- `helix_step_axis_score`
- aggregate `wc_helix_rule_score`

Current real-design evidence:

```bash
python3 scripts/ebd_oxdna_physical_eval.py \
  --top /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/triangle.top \
  --start /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/start.conf \
  --target /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/md_last.conf \
  --predicted /home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/manual_a30_dgnn_lite_ntstrat_adamw_coswarm_200e/101_50_bp_nicked.conf \
  --summary-json /home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/manual_a30_dgnn_lite_ntstrat_adamw_coswarm_200e/101_50_bp_nicked_physical_metrics.json
```

That run produced `wc_helix_rule_score=0.4392829768216692`, with `predicted_wc_f1=0.25`, `predicted_wc_conflict_rate=1.0`, and `helix_step_axis_score=0.32088017721588796`, which is concrete evidence that this DGNN-lite prediction is still far from physically meaningful duplex structure even when a prediction file exists.

## EBD oxDNA Torch Bridge Verification

Run the bridge smoke in the EBD conda environment:

```bash
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python \
  scripts/ebd_oxdna_bridge_smoke.py \
  --top /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/triangle.top \
  --start /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/start.conf \
  --device cpu
```

Expected output includes:

```text
bridge=torch
rows=102
x_shape=(102, 3)
edge_index_shape=(2, 198)
node_frame_shape=(102, 2, 3)
```

## EBD EGNN Forward Smoke

Small-design smoke:

```bash
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python \
  scripts/ebd_oxdna_egnn_smoke.py \
  --top /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/triangle.top \
  --start /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/101_50_bp_nicked/oxdna_run/start.conf \
  --device cpu
```

Largest-design smoke:

```bash
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python \
  scripts/ebd_oxdna_egnn_smoke.py \
  --top /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/105_honeycomb-74-final2/oxdna_run/triangle.top \
  --start /home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/105_honeycomb-74-final2/oxdna_run/start.conf \
  --device cpu
```

Expected output includes `model=egnn` and `pred_shape=(N, 3)`.

## Add Stack-Specific Verification

When a project stack is added, update this file and `init.sh` with concrete commands such as:
- `npm test`, `npm run build`, or `npm run check` for Node.js projects.
- `pytest` for Python projects.
- `cargo test` for Rust projects.

## Completion Rule

Before claiming a task is complete, record:
- Commands run.
- Whether each command passed.
- Any skipped checks and the reason they were skipped.
