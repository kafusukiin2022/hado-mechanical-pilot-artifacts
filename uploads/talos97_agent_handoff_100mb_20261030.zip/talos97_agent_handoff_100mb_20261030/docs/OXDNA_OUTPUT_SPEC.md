# oxDNA Output Specification

This specification defines the first exportable prediction target for the DNA origami EBD adaptation.

## Objective

Given an oxDNA topology and an initial oxDNA configuration, generate a predicted relaxed configuration that can be written as an oxDNA `.dat` or `.conf` file and opened in oxView with the original `.top` file.

The model may use coarse hierarchy internally, but the external output is nucleotide-level:

```text
nucleotide_i -> r_i, a1_i, a3_i
```

## Required Inputs

- `.top`: oxDNA topology file. This defines nucleotide count, strand membership, sequence, and neighbor ordering.
- Initial `.dat` or `.conf`: template configuration with positions, orientation vectors, velocities, angular velocities, and box/header information.
- Derived graph features:
  - Backbone edges from topology order.
  - Base-pair or complement edges.
  - Crossover edges.
  - Strand IDs.
  - Optional helix, domain, bundle, or connected-component IDs.
- Optional supervised target `.dat` or `.conf`: relaxed/final configuration aligned to the initial design.

## Required Prediction

For each nucleotide in `.top` order, predict:

- `r_i`: 3D position.
- `a1_i`: oxDNA orientation vector.
- `a3_i`: oxDNA orientation vector.

The first implementation may predict these through a structured decoder:

1. Predict coarse base-pair or helix-segment frames.
2. Decode each nucleotide rigid body from the local coarse frame and initial local offsets.
3. Normalize and repair frames before writing.

This keeps the generative backbone coarse and hierarchy-aware while still producing a fine oxDNA-compatible artifact.

## File Writing Contract

The writer must preserve:

- Nucleotide count.
- Nucleotide row order from the `.top`.
- Configuration header fields where possible.
- Box dimensions large enough to contain the predicted structure.

The writer may initialize:

- Velocity to `0 0 0`.
- Angular velocity to `0 0 0`.

Alternatively, velocities and angular velocities may be copied from the input template when the prediction is intended as a continuation state.

## Validation Checks

Before claiming an exported configuration is valid, run automated checks for:

- Row count matches the `.top` nucleotide count.
- Every row has finite numeric values.
- `a1_i` and `a3_i` are nonzero and normalized within tolerance.
- Orientation vectors form a valid local frame within oxDNA tolerance.
- Backbone neighbor distances are within a configurable physical range when that check is enabled.
- Base-pair/complement distances are within a configurable physical range when complement edges are known.
- Box dimensions are present and positive. Coordinates may be unwrapped and slightly outside `[0, box]`; this should be reported as a warning by default, not a hard format failure. Use strict box containment only for wrapped-coordinate workflows.
- No severe coordinate explosions relative to the initial structure.

Manual validation for early versions:

- Open the generated `.dat` or `.conf` with the matching `.top` in oxView.
- Confirm the structure is visible, not exploded, and preserves expected strand connectivity.

## Training Targets

Preferred first target:

```text
Delta_r_i = r_final_aligned_i - r_initial_i
Delta_frame_i = relative orientation from initial frame to final aligned frame
```

Coarse targets may be computed at base-pair or helix-segment level:

- Coarse center displacement.
- Coarse frame rotation.
- Domain or bundle-level displacement.

The nucleotide decoder must map these coarse predictions back to `r_i, a1_i, a3_i`.

## Non-Goals For First Version

- Do not require fully unconstrained nucleotide-level torsional diffusion.
- Do not require predicting thermodynamically perfect relaxed structures without oxDNA cleanup.
- Do not treat a coordinate-only prediction as an exportable result.
- Do not change the `.top` unless a separate topology-editing task is explicitly started.

## Success Criteria

The first version succeeds when it can:

1. Read a `.top` and initial `.dat` or `.conf`.
2. Build the coarse hierarchy used by the EBD-style model.
3. Produce per-nucleotide `r_i, a1_i, a3_i`.
4. Write an oxDNA configuration file in `.top` order.
5. Pass automated export sanity checks.
6. Load in oxView with the matching `.top`.
