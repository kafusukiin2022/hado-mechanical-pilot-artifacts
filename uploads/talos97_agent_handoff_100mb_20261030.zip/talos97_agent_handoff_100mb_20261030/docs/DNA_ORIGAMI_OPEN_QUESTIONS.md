# DNA Origami Open Questions

Archive these questions before implementing the DNA origami adaptation.

## Inputs

- What inputs exist beyond `.top`: oxDNA `.dat/.conf`, trajectory files, design annotations, or other metadata?
- Which oxDNA configuration filename extension and format variant should be treated as canonical for this project: `.dat`, `.conf`, or both?
- Does the initial configuration already contain valid nucleotide `r`, `a1`, and `a3` rows for every `.top` nucleotide?
- How are base-pair or complement edges determined?
- How are crossover edges determined?
- Are helix IDs, domain IDs, bundle IDs, or connected-component IDs already available, or must they be inferred?

## Targets

- Do final targets come from oxDNA relaxation, experimental structures, or another simulator?
- Should target alignment use whole-origami Kabsch, per-domain alignment, per-helix alignment, or another constrained alignment?
- Should velocities and angular velocities in generated oxDNA files be zeroed or inherited from the initial/template configuration?
- Should the supervised target be per-nucleotide `r,a1,a3`, coarse frame displacement plus reconstruction, or both?

## First Model Cut

- Should the first coarse level be base-pair frames or helix-segment frames?
- Should generation predict absolute final rigid-body states, displacement/rotation fields, or score/noise targets?
- What tolerance should define an acceptable reconstructed oxDNA local frame before writing?
- Should the first decoder use template local offsets from the initial configuration, learned nucleotide offsets, or a hybrid?

## Data Scale

- How many designs are available?
- How many conformers per design are available?
- Is trajectory data available, or only initial/final states?
- How much sequence diversity is present?

## Evaluation

- What is the priority order among RMSD, domain-frame error, crossover constraint error, helix bending, end-to-end distance, and other task-specific observables?
- What are the required oxDNA export sanity checks before oxView inspection?
- What counts as oxView success: file loads only, visually connected strands, or geometry close enough for oxDNA relaxation?
