# Architecture

This document should describe the project structure once application code exists.

## Current State

- The root directory contains the harness files.
- `EBD/` contains the cloned PyTorch implementation of "Equivariant Blurring Diffusion for Hierarchical Molecular Conformer Generation".
- The harness remains stack-neutral; EBD-specific setup is documented in `EBD/README.md`.
- The DNA origami adaptation direction is stored in `docs/DNA_ORIGAMI_EBD_PLAN.md`.
- The oxDNA export target is specified in `docs/OXDNA_OUTPUT_SPEC.md`.
- `oxdna_export/` contains the first standalone oxDNA topology/configuration parser, writer, and validation utilities.
- `scripts/oxdna_roundtrip.py` provides a smoke-test CLI for reading, validating, writing, and revalidating a single oxDNA configuration frame.
- `ebd_oxdna/` contains the first DNA-origami model-output path around EBD boundaries:
  - `adapter.py` reads `.top` plus `start.conf` and optional target `.conf` into an `OxDNASample`.
  - `decoder.py` converts predicted nucleotide rigid bodies back to an `OxDNAFrame`.
  - `baselines.py` provides the identity/template model path and a tiny trainable global-translation overfit baseline.
  - `ebd_bridge.py` exposes conservative future EBD tensor-boundary shapes and optional torch tensor bridge inputs without modifying upstream EBD internals.
  - `ebd_mapping.py` maps nucleotide/strand oxDNA data into the tensor contract expected by EBD `EGNN.forward()`.
- `scripts/ebd_oxdna_predict.py` is the model-output CLI: `.top + start.conf -> adapter -> baseline/model -> decoder -> validator -> predicted.conf`.
- `scripts/ebd_oxdna_bridge_smoke.py` verifies torch tensor bridge shapes, dtype, and device for `.top + start.conf` samples.
- `scripts/ebd_oxdna_egnn_smoke.py` runs a no-training upstream EBD EGNN forward pass on mapped oxDNA tensors.
- `jobs/geodiff_fam_oxdna_roundtrip_smoke.slurm` is a GeoTDM-style cluster smoke template for running the roundtrip on real `.top` and `.dat/.conf` inputs.
- The installed GPU environment is documented in `docs/EBD_ENVIRONMENT.md`.
- Open DNA origami design questions are archived in `docs/DNA_ORIGAMI_OPEN_QUESTIONS.md`.
- `docs/templates/OXVIEW_COMPARISON_TEMPLATE.md` records the reusable oxView comparison-page pattern for original oxDNA `.conf` files versus model-generated `.conf` outputs.
- `outputs/oxview_compare_130_15_243/` is the first concrete comparison-page instance and should be used as the reference implementation for future browser comparisons.

## Current DNA Origami Model-Output Flow

The accepted smoke path is:

```text
triangle.top + start.conf
        -> ebd_oxdna.adapter.load_oxdna_sample
        -> IdentityRigidBodyBaseline or GlobalTranslationOverfitBaseline
        -> ebd_oxdna.decoder.decode_to_oxdna_frame
        -> oxdna_export.validate.validate_frame
        -> predicted_identity.conf or predicted_overfit.conf
```

The overfit baseline is deliberately small. It proves training/inference/export mechanics only; it is not evidence of final EBD model quality.

## Current EBD Bridge Flow

The bridge smoke path is:

```text
triangle.top + start.conf
        -> ebd_oxdna.adapter.load_oxdna_sample
        -> ebd_oxdna.ebd_bridge.build_torch_bridge_inputs
        -> x: float32 [N, 3]
        -> edge_index: int64 [2, E]
        -> node_frame: float32 [N, 2, 3]
```

For `101_50_bp_nicked`, the current CPU bridge smoke reports `N=102` and `E=198` directed backbone edges.

## Current EBD Smoke Mapping

The first EBD-compatible smoke uses:

```text
atom-level nodes   = nucleotides
fragment-level nodes = strands
atom graph         = directed backbone prev/next edges from .top
fragment graph     = fully connected over strands
m_mat / bm_mat     = sparse strand-membership matrices
```

This is only a compatibility mapping for no-training forward smoke. It is not yet the final DNA origami hierarchy.

## Update When Code Is Added

Record:
- Primary modules and responsibilities.
- Data flow and external dependencies.
- Entry points and commands.
- Known constraints and invariants.
- Areas that agents should avoid changing without explicit instruction.
