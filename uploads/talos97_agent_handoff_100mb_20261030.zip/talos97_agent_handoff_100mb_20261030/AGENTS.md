# AGENTS.md

This directory uses a lightweight harness for AI coding agents. The harness keeps work scoped, restartable, and verifiable across sessions.

## Startup Workflow

Before writing code:
1. Read this file.
2. Read `feature_list.json` to understand active work.
3. Read `progress.md` for recent decisions, evidence, and blockers.
4. If resuming a prior session, read `session-handoff.md`.
5. Run `./init.sh` before making substantial changes, or explain why it is not applicable.

## Working Rules

- Work on one feature or fix at a time.
- Prefer the smallest change that satisfies the current request.
- Do not overwrite user changes. If local changes affect the task, work with them or ask.
- Record meaningful decisions, blockers, and verification evidence in `progress.md`.
- Update `feature_list.json` when a feature starts, pauses, completes, or is blocked.
- Do not claim completion until verification has been run or the skipped verification is documented.

## CodeGraph First

Use CodeGraph before regex or text search for structural code exploration. This reduces search time and avoids rebuilding call graphs manually.

- For project files and folders, use `codegraph_files` before `rg --files` or `find`.
- For symbol lookup, use `codegraph_search` before `rg`.
- For "how does this work" questions, start with `codegraph_context`.
- For call relationships, use `codegraph_callers`, `codegraph_callees`, `codegraph_trace`, or `codegraph_impact`.
- Use `rg` only for literal strings, comments, log messages, config keys, or when CodeGraph is unavailable.
- After editing code, run `codegraph sync <project>` before relying on CodeGraph for post-edit structure.
- If a codebase is not indexed and the user has asked to use CodeGraph, initialize it with `codegraph init -i` from that codebase root.

## Research Direction

- Keep the DNA origami direction in `docs/DNA_ORIGAMI_EBD_PLAN.md` in mind.
- Check `docs/DNA_ORIGAMI_OPEN_QUESTIONS.md` before implementing the DNA origami adaptation.
- Use the installed EBD environment documented in `docs/EBD_ENVIRONMENT.md`.
- EBD is the primary architecture for hierarchical endpoint diffusion.
- Prediction outputs must be convertible to oxDNA `.dat`/`.conf` files and open in oxView; see `docs/OXDNA_OUTPUT_SPEC.md`.
- Torsional Diffusion is a secondary coarse-graph rotational module, not the first full backbone diffusion target.
- Target deployment hardware is NVIDIA A6000 or A100.

## GPU Scheduling Rules

- Do not submit high-memory EBD/oxDNA jobs to `gpu29`.
- Evidence: A30 job `427879` on `gpu29` OOMed during the largest-design EGNN step probe, while A30 job `427625` on `gpu30` completed the largest-design EGNN overfit with peak CUDA reserved memory `13130.00 MiB`.
- High-memory Slurm scripts should include `#SBATCH --exclude=gpu29` or an equivalent submission-time exclusion.
- Prefer A6000 or A100 for large EBD/oxDNA memory probes and long overfit runs unless the user explicitly approves another GPU class.

## Required Artifacts

- `AGENTS.md`: Runtime instructions for coding agents.
- `feature_list.json`: Feature and task state tracker.
- `progress.md`: Session continuity log.
- `session-handoff.md`: Handoff template for restartable sessions.
- `init.sh`: Standard startup and verification script.
- `docs/ARCHITECTURE.md`: Project architecture notes.
- `docs/VERIFICATION.md`: Verification commands and expectations.
- `docs/EBD_ENVIRONMENT.md`: Installed EBD environment and use instructions.
- `docs/DNA_ORIGAMI_EBD_PLAN.md`: Stored research direction and open information needs.
- `docs/DNA_ORIGAMI_OPEN_QUESTIONS.md`: Archived questions to answer before implementation.
- `docs/OXDNA_OUTPUT_SPEC.md`: Required nucleotide rigid-body output and oxDNA/oxView export contract.
- `docs/templates/OXVIEW_COMPARISON_TEMPLATE.md`: Reusable pattern for oxView side-by-side comparison pages.

## Scope Control

Every active task should have:
- A clear objective.
- A bounded file or module scope when possible.
- A verification path.
- A recorded outcome.

Avoid unrelated refactors, dependency churn, and broad rewrites unless they are explicitly requested or necessary for correctness.

## Definition of Done

A task is done when:
- [ ] The requested behavior or artifact is implemented.
- [ ] Relevant verification commands pass.
- [ ] Any skipped verification is documented with a reason.
- [ ] `progress.md` records what changed and what remains.
- [ ] `feature_list.json` reflects the latest status.
- [ ] The next agent can resume from the current files without hidden context.

## End of Session

Before ending a work session:
1. Update `progress.md` with summary, verification, blockers, and next steps.
2. Update `feature_list.json` statuses and evidence.
3. Refresh `session-handoff.md` if work is incomplete or risky.
4. Leave the repository in a restartable state.
