# 6HB DNA — DynaProt-M 思想改造的完整协方差训练代码

此工程依据你上传的原始 `RMSF_local_basic_code_20261114 (1).zip` 改造，并保留其 `backbone.py` 几何编码及 GNO 的类型化拓扑边扩散思路。

**明确范围**：这是 **DynaProt-M-inspired Gaussian GNO**，不是官方 DynaProt 的 IPA 主干、Evoformer 或 DynaProt-J，也不能使用 DynaProt 蛋白质预训练权重。节点是 **DNA 的 nucleotide**，不是蛋白质 residue。项目代码完整；但你上传的包没有真实 `.npz` 输入、`statistics.npz` 标签、权重和 MD 轨迹，必须将本包合并到你原来包含数据的完整工程根目录再跑真实训练。

## 1. 真实输入输出（与你确认的定义一致）

- **输入**（预测时只需要这些）：`experiments/talos97_endpoint_v1/data/inputs/6hb_001.npz`，包含 `pos`, `rotation`, `node_features`, `edge_index`, `edge_types`, `domain_ids`, `segment_edge_index`。节点顺序固定为 oxDNA topology 行号；`pos` 仍按原始工程的归一化尺度使用，**不要再乘以 nm 系数来喂入几何编码器**。初始 `rotation[i]` 是列向量局部坐标基，满足正交、右手。
- **监督标签**：`outputs/talos97_directional_persistence_20261104/labels/6hb_001/statistics.npz` 的 `covariance_q`，形状 `[N,3,3]`，单位 **nm²**。它是 2000 帧 Kabsch 对齐到初始设计后，在初始设计**全局**坐标框架内、减去**时间均值**得到的协方差；并非初始位移的二阶矩；标签不需要再进行 34.072 倍或其他 nm 转换。
- **训练内部**：由初始 `R_i` 计算 `cov_local_target=R_i.T @ covariance_q[i] @ R_i`；模型用 6 个 Cholesky 参数生成 `cov_local=LL.T`，然后得到 `cov_global=R_i @ cov_local @ R_i.T`。损失为局部矩阵 Log-Euclidean/Frobenius + 从全局预测协方差计算的 RMSF MSE。对 SPD 目标作 1e-6 nm² 的 jitter **仅用于矩阵对数**，RMSF 目标不修改。
- **预测输出**：`prediction.npz` 的 `covariance_global_nm2[N,3,3]`, `covariance_local_nm2[N,3,3]`, `rmsf_nm[N]`, `node_index[N]`。保留兼容字段 `marginal_covariances`, `rmsf`；提供 `rmsf.csv`。**推理只需要输入结构，无需 MD 轨迹或标签。**

核心式：

```
Σ_i(local) = L_i L_i^T
Σ_i(global) = R_i Σ_i(local) R_i^T
RMSF_i(nm) = sqrt(trace(Σ_i(global)))
```

## 2. 环境

Python >=3.10；依赖 `torch`、`numpy`、`scipy`，详细见 `requirements_dynaprot.txt`。可用 CPU 验证，也可用 CUDA 训练。**不能保证真实 731,578 节点、85 个设计全部能装进 GPU；训练脚本每次只将一个设计搬到显存，缓解显存压力。**

```bash
pip install -r requirements_dynaprot.txt
```

## 3. 合并到你原来的完整工程

解压后，把 `experiments/talos97_rmsf_scalar/dynaprot_style/` 以及保留的原 `backbone.py` 位置放到完整工程里，保持下面相对路径：

```
YOUR_PROJECT_ROOT/
├── experiments/
│   ├── talos97_endpoint_v1/data/inputs/
│   │   ├── 6hb_001.npz
│   │   └── ...
│   └── talos97_rmsf_scalar/
│       ├── backbone.py
│       ├── covariance_aux20m_20261102/effective_split.json
│       └── dynaprot_style/
│           ├── model.py
│           ├── data_io.py
│           ├── audit.py
│           ├── train.py
│           ├── predict.py
│           └── smoke_test.py
└── outputs/
    └── talos97_directional_persistence_20261104/labels/
        ├── 6hb_001/statistics.npz
        └── ...
```

不要从本压缩包中寻找这些真实输入和标签；它们没有被上传。

## 4. 先用合成数据做自检

```bash
python experiments/talos97_rmsf_scalar/dynaprot_style/smoke_test.py
```

测试了：几何输入、SO(3) 旋转等变、矩阵 SPD、trace → RMSF、反向传播、真实目录形状的嵌套 `statistics.npz/covariance_q`、短训、最佳权重与推理。**不代表真实数据模型效果。**

## 5. 正式训练之前：审计设计、标签和原 split

```bash
python experiments/talos97_rmsf_scalar/dynaprot_style/audit.py \
  --project-root /path/to/YOUR_PROJECT_ROOT \
  --report /path/to/YOUR_PROJECT_ROOT/results/dynaprot_m/audit.csv
```

会统计所有标签设计数量、原 split 的 train/validation 数量、能够同时找到输入和标签的数量、缺失 ID、矩阵 PSD、节点数量是否匹配。用户提供的信息显示 85 个设计、其中 69/71 个训练设计拥有标签，但完整标签实际未上传，**这里只能在你真实工程中核实**。

`6hb_024`、`6hb_051` 尚待质量复核。训练脚本**默认排除**这两个设计；若它们经 QC 通过，明确使用 `--exclude-designs` 后接新的排除列表（不能用默认列表即可）。若有更多缺失的验证标签，需要决定是否接受改变原来的 18 设计验证集，否则建议先补齐标签。

## 6. 完整训练命令

在任何目录执行（指定完整工程路径）：

```bash
python /path/to/YOUR_PROJECT_ROOT/experiments/talos97_rmsf_scalar/dynaprot_style/train.py \
  --project-root /path/to/YOUR_PROJECT_ROOT \
  --out /path/to/YOUR_PROJECT_ROOT/results/dynaprot_m_seed11 \
  --epochs 120 \
  --patience 25 \
  --lr 1e-4 \
  --width 128 \
  --hops 8 \
  --edge-mode geometry \
  --seed 11 \
  --device cuda \
  --skip-missing \
  --save-val-predictions
```

- `--labels` 未指定时默认读取 `outputs/talos97_directional_persistence_20261104/labels/<design>/statistics.npz`，键 `covariance_q`。如果标签位置不同，显式指定 `--labels /full/path/to/labels`。
- `--inputs` 未指定时默认读取 `experiments/talos97_endpoint_v1/data/inputs/<design>.npz`。
- `--split` 未指定时默认使用原上传包的 `effective_split.json`，**按设计划分，禁止节点混分**。
- 默认严格模式：遇到缺失标签就报错。示例用 `--skip-missing` 明确允许从 train / validation 排除缺失标签，并把所有变动写入 `manifest.json`。**这样得到的验证指标不能直接当成原 18 设计协议的指标**。
- 默认排除 `6hb_024`、`6hb_051`：是否纳入取决于之前的 QC 结果。
- 使用 `--audit-historical-rmsf` 可比较 `sqrt(trace(covariance_q))` 与历史 CSV `rmsf_nm` 的差距；使用 `--require-historical-rmsf-match` 会在没有对比通过时中止。注意历史 RMSF 的目标定义必须确实相同。
- `--select-by rmse` 默认按验证集 **设计宏平均 RMSE（nm）** 选择 `best.pt`。改为 `--select-by combined` 则按双目标损失选最优模型。和历史 GNO 对比需要同一验证设计列表。

不修改原始全局标签文件；日志/权重均写到 `--out` 目录：

```
results/dynaprot_m_seed11/
├── best.pt                     # 最优模型及训练归一化参数
├── history.csv                 # 训练与验证逐 epoch 曲线
├── manifest.json               # 实际 train/val ID、缺失、排除、输入标签 SHA256
├── summary.json                # 训练集及验证集宏指标
├── train_per_design.csv        # 每设计的 RMSF 与协方差误差
├── validation_per_design.csv   # 同上
└── validation_predictions/     # 若启用 --save-val-predictions
    ├── 6hb_004.npz
    └── ...
```

验证指标含：`rmse_nm`, `mae_nm`, `bias_nm`, `spearman`, `top20_mae_nm`, `top20_bias_nm`, `bottom20_mae_nm`, `bottom20_bias_nm`, `std_ratio`, `cov_frobenius_nm2`, `cov_log_loss`。每个设计分别计算，再取宏平均（不能把所有节点混成单个样本）。

## 7. 使用一个从未出现过的 DNA 初态进行推理

```bash
python /path/to/YOUR_PROJECT_ROOT/experiments/talos97_rmsf_scalar/dynaprot_style/predict.py \
  --checkpoint /path/to/YOUR_PROJECT_ROOT/results/dynaprot_m_seed11/best.pt \
  --input /path/to/YOUR_PROJECT_ROOT/experiments/talos97_endpoint_v1/data/inputs/6hb_100.npz \
  --out /path/to/YOUR_PROJECT_ROOT/results/pred_6hb_100
```

输出 `prediction.npz`, `rmsf.csv`, `metadata.json`。无需加载任何 MD 轨迹。

```python
import numpy as np
with np.load('results/pred_6hb_100/prediction.npz') as data:
    cov = data['covariance_global_nm2']  # [N,3,3], nm²
    rmsf = data['rmsf_nm']               # [N], nm
    assert np.allclose(rmsf**2, np.trace(cov, axis1=1, axis2=2), atol=1e-5)
```

## 8. 局限性、与论文区别

1. **不是官方 DynaProt 原架构**：用了你原始 `backbone.BasisNet.encode` + GNO 图扩散 + Gaussian Cholesky head，未直接替换为 IPA / DynaProt-J。结构级、数据标签级的思想与 DynaProt-M 相似。
2. **不是原始历史 GNO 的逐权重兼容版本**：因为旧 `GNOModel` 依赖上传包中缺失的运行时数据、缓存和 feature building 模块。新 GaussianGNO 使用可独立运行的几何特征 + 图扩散，不能直接载入旧权重；要严格公平比较，需要固定拆分、标签定义、训练预算并复现原额外特征。
3. **没有真实性能报告**：只通过合成数据的 smoke test，未得到真实 `covariance_q` 文件，不能宣称已经训练了 85 个设计或优于旧 GNO。
4. **物理含义**：输出为 2000 帧有限观测窗口内的逐节点协方差，不可直接称为无限时间或充分平衡的统计协方差；也不含 `i≠j` 的跨核苷酸协方差或构象跃迁速率。
5. **单位**：原 `pos` 继续使用原工程归一化单位；标签/预测 RMSF 是 nm，协方差是 nm²。局部 / 全局变换只旋转矩阵，不改尺度。
6. **标签一致性**：如果 `covariance_q` 没保存 `topology_row`，程序只能依靠形状验证，并依赖你已通过 oxDNA topology 和 SHA256 做的离线顺序核对。不能仅靠 `[N,3,3]` 证明行号对应。
7. **矩阵主轴**：最大特征值的特征向量是无符号轴；若相邻主特征值接近，主轴不稳定。不建议直接以主轴的有向角度进行训练。

如果你决定要 **真正复刻 DynaProt 的 IPA 主干** 而不仅是迁移它的协方差目标，应在拿到官方代码许可、所需结构输入和适当几何特征后另建架构分支，而不是称这里的 GNO 为官方 DynaProt。
