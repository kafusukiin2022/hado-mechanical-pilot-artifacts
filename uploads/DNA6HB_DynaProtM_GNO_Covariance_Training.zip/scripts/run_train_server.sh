#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
args=(
  --project-root "$PROJECT_ROOT"
  --inputs "$INPUTS_DIR"
  --labels "$LABELS_DIR"
  --split "$SPLIT_FILE"
  --out "$RESULTS_DIR"
  --epochs "${EPOCHS:-120}"
  --patience "${PATIENCE:-25}"
  --lr "${LR:-1e-4}"
  --width "${WIDTH:-128}"
  --hops "${HOPS:-8}"
  --edge-mode "${EDGE_MODE:-geometry}"
  --seed "${SEED:-11}"
  --threads "${OMP_NUM_THREADS:-2}"
  --device "$DEVICE"
)
if [[ "${SKIP_MISSING:-0}" == "1" ]]; then
  args+=(--skip-missing)
fi
if [[ "${SAVE_VAL_PREDICTIONS:-1}" == "1" ]]; then
  args+=(--save-val-predictions)
fi
"$PYTHON_BIN" "$SCRIPT_ROOT/train.py" "${args[@]}" "$@"
