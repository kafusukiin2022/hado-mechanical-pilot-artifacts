#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
if [[ $# -ne 1 ]]; then
  echo "Usage: bash scripts/run_predict_server.sh 6hb_100" >&2
  exit 2
fi
design="$1"
if [[ ! "$design" =~ ^[A-Za-z0-9_-]+$ ]]; then
  echo 'Design ID must be alphanumeric, hyphen or underscore' >&2
  exit 2
fi
ckpt="$RESULTS_DIR/best.pt"
input="$INPUTS_DIR/$design.npz"
[[ -f "$ckpt" ]] || { echo "Missing checkpoint: $ckpt" >&2; exit 2; }
[[ -f "$input" ]] || { echo "Missing input: $input" >&2; exit 2; }
"$PYTHON_BIN" "$SCRIPT_ROOT/predict.py" \
  --checkpoint "$ckpt" \
  --input "$input" \
  --out "$RESULTS_DIR/predictions/$design" \
  --device "$DEVICE"
