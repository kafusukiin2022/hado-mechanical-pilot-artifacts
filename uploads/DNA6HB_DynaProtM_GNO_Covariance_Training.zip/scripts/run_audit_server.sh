#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
mkdir -p "$RESULTS_DIR"
"$PYTHON_BIN" "$SCRIPT_ROOT/audit.py" \
  --project-root "$PROJECT_ROOT" \
  --inputs "$INPUTS_DIR" \
  --labels "$LABELS_DIR" \
  --split "$SPLIT_FILE" \
  --report "$RESULTS_DIR/audit.csv"
