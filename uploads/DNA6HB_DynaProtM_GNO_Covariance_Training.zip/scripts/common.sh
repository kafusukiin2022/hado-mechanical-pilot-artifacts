#!/usr/bin/env bash
# Shared path/config handling for server scripts. Not a standalone entry point.
set -euo pipefail
CODE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ENV_FILE:-$CODE_ROOT/.env}"
if [[ ! -f "$ENV_FILE" ]]; then
  echo "Missing config: $ENV_FILE" >&2
  echo "Copy $CODE_ROOT/.env.example to $CODE_ROOT/.env and edit paths." >&2
  exit 2
fi
# shellcheck disable=SC1090
source "$ENV_FILE"
: "${PROJECT_ROOT:?PROJECT_ROOT must be set in .env}"
: "${INPUTS_DIR:?INPUTS_DIR must be set in .env}"
: "${LABELS_DIR:?LABELS_DIR must be set in .env}"
: "${SPLIT_FILE:?SPLIT_FILE must be set in .env}"
: "${RESULTS_DIR:?RESULTS_DIR must be set in .env}"
PYTHON_BIN="${PYTHON_BIN:-python}"
DEVICE="${DEVICE:-auto}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
for path in "$PROJECT_ROOT" "$INPUTS_DIR" "$LABELS_DIR"; do
  if [[ ! -d "$path" ]]; then
    echo "Directory not found: $path" >&2
    exit 2
  fi
done
if [[ ! -f "$SPLIT_FILE" ]]; then
  echo "Split file not found: $SPLIT_FILE" >&2
  exit 2
fi
SCRIPT_ROOT="$CODE_ROOT/experiments/talos97_rmsf_scalar/dynaprot_style"
