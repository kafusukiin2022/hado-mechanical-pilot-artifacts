#!/usr/bin/env python3
"""Rank input-only mechanical geometry candidates by design-wise RMSF-error association.

This is a post-hoc descriptive diagnostic. It never fits a model and never uses
the label to construct features. Node-level correlations are computed inside
each design, then macro-averaged over designs to avoid pooling correlated nodes.
"""
import csv
import hashlib
import json
from collections import deque
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree
from scipy.stats import rankdata, spearmanr

ROOT = Path(__file__).resolve().parents[3]
DATA = ROOT / "experiments/talos97_endpoint_v1/data"
LABELS = ROOT / "outputs/talos97_triplicate_analysis_20261028"
PRED = np.load(ROOT / "experiments/talos97_rmsf_scalar/results/transfer_ensemble_predictions.npz")
MANIFEST = json.loads((ROOT / "experiments/talos97_rmsf_scalar/results/manifest.json").read_text())
SPLITS = json.loads((DATA / "split.json").read_text())
SPLIT_OF = {d: s for s, ids in SPLITS.items() for d in ids}
IDS = sum((SPLITS[k] for k in ("train", "validation", "test")), [])
SCALE_OX = 40.0


def rho(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    ok = np.isfinite(a) & np.isfinite(b)
    if ok.sum() < 3 or np.std(a[ok]) < 1e-12 or np.std(b[ok]) < 1e-12:
        return np.nan
    return float(spearmanr(a[ok], b[ok]).correlation)


def partial_rank_rho(x, y, controls):
    """Within-design Spearman partial correlation via residualized ranks."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    c = np.asarray(controls, float)
    if c.ndim == 1:
        c = c[:, None]
    ok = np.isfinite(x) & np.isfinite(y) & np.isfinite(c).all(1)
    if ok.sum() < 5:
        return np.nan
    xr, yr = rankdata(x[ok]), rankdata(y[ok])
    cr = np.column_stack([rankdata(c[ok, j]) for j in range(c.shape[1])])
    design = np.column_stack([np.ones(len(xr)), cr])
    rx = xr - design @ np.linalg.lstsq(design, xr, rcond=None)[0]
    ry = yr - design @ np.linalg.lstsq(design, yr, rcond=None)[0]
    if np.std(rx) < 1e-12 or np.std(ry) < 1e-12:
        return np.nan
    return float(np.corrcoef(rx, ry)[0, 1])


def multi_source_distance(adjacency, sources):
    dist = np.full(len(adjacency), np.inf)
    q = deque()
    for i in sources:
        if dist[i] != 0:
            dist[i] = 0
            q.append(int(i))
    while q:
        i = q.popleft()
        for j in adjacency[i]:
            if not np.isfinite(dist[j]):
                dist[j] = dist[i] + 1
                q.append(j)
    return dist


def make_features(z, mapping):
    x = np.asarray(z["pos"], float) * SCALE_OX
    rot = np.asarray(z["rotation"], float)
    n = len(x)
    edge, et = np.asarray(z["edge_index"]), np.asarray(z["edge_types"])
    dom = np.asarray(z["domain_ids"])
    vh = np.asarray([m["virtual_helix"] for m in mapping])
    ax = np.asarray([m["axial_index"] for m in mapping], int)

    # Per-helix normalized axial location and local helix support.
    u = np.zeros(n)
    end_steps = np.zeros(n)
    helix_span = np.ones(n)
    for h in np.unique(vh):
        m = vh == h
        lo, hi = ax[m].min(), ax[m].max()
        u[m] = .5 if hi == lo else (ax[m] - lo) / (hi - lo)
        end_steps[m] = np.minimum(ax[m] - lo, hi - ax[m])
        helix_span[m] = max(hi - lo, 1)
    end_prox = 1 - 2 * np.minimum(u, 1-u)
    nvh = len(np.unique(vh))
    by_ax = {q: set(vh[ax == q].tolist()) for q in np.unique(ax)}
    coverage = np.array([len(set().union(*(by_ax.get(q, set()) for q in range(a-8, a+9)))) / max(nvh, 1) for a in ax])

    # Typed graph counts/distances.
    out = {}
    for typ, name in enumerate(("spatial_edge_count", "intrahelix_backbone_count", "basepair_edge_count", "crossover_edge_count", "twohop_edge_count")):
        out[name] = np.bincount(edge[0, et == typ], minlength=n).astype(float)
    cross_seed = np.flatnonzero(out["crossover_edge_count"] > 0)
    out["backbone_steps_to_crossover"] = np.full(n, np.nan)

    # Backbone chain graph distances to a strand terminus and crossover support.
    bedges = np.asarray(z["backbone_edges"], int)
    adj = [set() for _ in range(n)]
    for i, j in bedges.T:
        adj[i].add(j); adj[j].add(i)
    endpoints = [i for i, a in enumerate(adj) if len(a) <= 1]
    end_dist = multi_source_distance(adj, endpoints)
    cross_dist = multi_source_distance(adj, cross_seed)
    out["backbone_steps_to_strand_end"] = np.where(np.isfinite(end_dist), end_dist, np.nan)
    out["backbone_steps_to_crossover"] = np.where(np.isfinite(cross_dist), cross_dist, np.nan)

    # Per-node bond geometry: local bend of the backbone and incident bond length.
    bond_len = np.full(n, np.nan)
    bend = np.full(n, np.nan)
    for i, neigh in enumerate(adj):
        if neigh:
            vec = np.stack([x[j] - x[i] for j in neigh])
            lengths = np.linalg.norm(vec, axis=1)
            bond_len[i] = lengths.mean()
            if len(neigh) >= 2:
                unit = vec / np.maximum(lengths[:, None], 1e-12)
                cos = np.clip(unit @ unit.T, -1, 1)
                vals = cos[np.triu_indices(len(neigh), 1)]
                bend[i] = np.mean(1 + vals)  # 0 for a straight two-neighbor chain.
    out["mean_backbone_bond_length"] = bond_len
    out["local_backbone_bend"] = bend

    # Pair geometry, symmetrized across each designed pair.
    bp = np.asarray(z["base_pairs"], int)
    partner_dist = np.full(n, np.nan); pair_axis_dot = np.full(n, np.nan)
    pair_frame_dot = np.full(n, np.nan)
    pair_count = np.zeros(n)
    accum_d = np.zeros(n); accum_axis = np.zeros(n); accum_frame = np.zeros(n)
    for i, j in bp.T:
        d = np.linalg.norm(x[i] - x[j])
        a = abs(float(rot[i, :, 0] @ rot[j, :, 0]))
        f = float(np.mean(np.abs(np.sum(rot[i] * rot[j], axis=0))))
        for k in (i, j):
            pair_count[k] += 1; accum_d[k] += d; accum_axis[k] += a; accum_frame[k] += f
    m = pair_count > 0
    partner_dist[m] = accum_d[m] / pair_count[m]
    pair_axis_dot[m] = accum_axis[m] / pair_count[m]
    pair_frame_dot[m] = accum_frame[m] / pair_count[m]
    out["designed_pair_distance"] = partner_dist
    out["paired_axis_alignment_absdot"] = pair_axis_dot
    out["paired_frame_alignment"] = pair_frame_dot
    out["is_designed_paired"] = m.astype(float)

    # Local packing density, distance dispersion and anisotropy from initial geometry.
    tree = cKDTree(x)
    for r in (1.5, 2.5, 4.0):
        out[f"neighbors_within_{r:g}ox"] = np.asarray([len(v)-1 for v in tree.query_ball_point(x, r)])
    d, ix = tree.query(x, k=min(9, n), workers=1)
    out["nearest8_mean_distance"] = d[:, 1:].mean(1)
    out["nearest8_distance_sd"] = d[:, 1:].std(1)
    aniso = np.full((n, 3), np.nan)
    for i in range(n):
        ids = ix[i, 1:]
        v = x[ids] - x[i]
        cov = v.T @ v / max(len(v), 1)
        eig = np.linalg.eigvalsh(cov)
        aniso[i] = eig
    out["local_shape_lambda_min"] = aniso[:, 0]
    out["local_shape_lambda_mid"] = aniso[:, 1]
    out["local_shape_lambda_max"] = aniso[:, 2]
    out["local_shape_anisotropy"] = aniso[:, 2] / np.maximum(aniso.sum(1), 1e-12)

    # Bundle-axis centerline proxy and radial position relative to local centerline.
    centers = {q: x[ax == q].mean(0) for q in np.unique(ax)}
    radial = np.array([np.linalg.norm(x[i] - centers[a]) for i, a in enumerate(ax)])
    out["radial_distance_to_axial_centerline"] = radial
    local_radius = {q: np.nanpercentile(radial[ax == q], 90) for q in np.unique(ax)}
    out["normalized_cross_section_radius"] = np.array([radial[i] / max(local_radius[a], 1e-8) for i, a in enumerate(ax)])
    curvature = np.full(n, np.nan)
    for i, a in enumerate(ax):
        if a-4 in centers and a+4 in centers:
            curvature[i] = np.linalg.norm(centers[a-4] + centers[a+4] - 2*centers[a])
    out["centerline_second_difference"] = curvature
    out["axial_end_proximity"] = end_prox
    out["local_helix_coverage"] = coverage
    out["end_distance_axial_steps"] = end_steps
    out["helix_axial_span"] = helix_span

    # Multi-scale endpoint radial basis and centerline curvature/torsion.
    # Axial-index units are explicit; no RMSF label enters these quantities.
    for scale in (1, 2, 4, 8, 16, 32):
        out[f"end_rbf_lambda_{scale}"] = np.exp(-end_steps / float(scale))
    curvature_by_scale = {}
    for h in (1, 2, 4, 8):
        kval = np.full(n, np.nan)
        tau = np.full(n, np.nan)
        for i, a in enumerate(ax):
            if all(q in centers for q in (a-h, a, a+h)):
                kval[i] = np.linalg.norm(centers[a-h] + centers[a+h] - 2*centers[a]) / (h*h)
            if all(q in centers for q in (a-2*h, a-h, a+h, a+2*h)):
                p0, p1, p2, p3 = (centers[a-2*h], centers[a-h], centers[a+h], centers[a+2*h])
                b1, b2, b3 = p1-p0, p2-p1, p3-p2
                denom = np.linalg.norm(b1)*np.linalg.norm(b2)*np.linalg.norm(b3)
                tau[i] = float(np.dot(np.cross(b1, b2), b3) / max(denom, 1e-12))
        curvature_by_scale[h] = kval
        out[f"centerline_curvature_scale_{h}"] = kval
        out[f"centerline_signed_torsion_scale_{h}"] = tau

    # Candidate interactions: boundary/curvature effects under sparse support.
    sparse = 1.0 - coverage
    out["end_x_sparse_support"] = end_prox * sparse
    out["end_distance_x_sparse_support"] = end_steps * sparse
    for h, kval in curvature_by_scale.items():
        out[f"curvature_{h}_x_sparse_support"] = kval * sparse
    out["end_x_abs_curvature_4"] = end_prox * np.abs(curvature_by_scale[4])

    # Domain support and within-domain position.
    _, did = np.unique(dom, return_inverse=True)
    nd = did.max() + 1
    counts = np.bincount(did, minlength=nd)
    dc = np.stack([np.bincount(did, weights=x[:, k], minlength=nd) for k in range(3)], axis=1) / counts[:, None]
    out["domain_size"] = counts[did].astype(float)
    out["distance_to_domain_centroid"] = np.linalg.norm(x - dc[did], axis=1)
    se = np.asarray(z["segment_edge_index"], int)
    graph = [set() for _ in range(nd)]
    for i, j in se.T:
        if i != j:
            graph[i].add(j); graph[j].add(i)
    out["domain_graph_degree"] = np.asarray([len(graph[i]) for i in did], float)

    # Axial/surface support by bundle slice (distinct helices and local radial support).
    out["local_crossover_fraction"] = out["crossover_edge_count"] / np.maximum(np.bincount(edge[0], minlength=n), 1)

    # Broadcast rod-level summaries to each node to test whether rod identity/context
    # carries information beyond the local node geometry.
    for name in ("helix_axial_span", "centerline_curvature_scale_4", "centerline_curvature_scale_8",
                 "local_helix_coverage", "local_crossover_fraction", "domain_size"):
        v = out[name]
        rod_mean = np.full(n, np.nan)
        for h in np.unique(vh):
            m = vh == h
            finite = m & np.isfinite(v)
            if finite.any():
                rod_mean[m] = np.mean(v[finite])
        out[f"rod_mean_{name}"] = rod_mean
    return out


def main():
    rows = []
    partial_rows = []
    for design in IDS:
        label_path = LABELS / design / "per_nucleotide_statistics.csv"
        assert MANIFEST["labels"].get(str(label_path)) == hashlib.sha256(label_path.read_bytes()).hexdigest()
        with label_path.open(newline="") as f:
            rr = list(csv.DictReader(f))
        assert [int(r["topology_row"]) for r in rr] == list(range(len(rr)))
        y = np.asarray([float(r["pooled_rmsf_nm"]) for r in rr])
        pred = PRED[design].astype(float)
        err = np.abs(pred-y)
        with np.load(DATA / "inputs" / f"{design}.npz") as z:
            raw = {k: np.asarray(z[k]) for k in z.files}
        mp = json.loads((DATA / "designs" / design / "topology_to_cadnano.json").read_text())
        assert mp["unique_mapping"] and len(mp["mapping"]) == len(err)
        assert [m["topology_row"] for m in mp["mapping"]] == list(range(len(err)))
        feats = make_features(raw, mp["mapping"])
        for name, val in feats.items():
            rows.append({"design": design, "split": SPLIT_OF[design], "feature": name,
                         "rho_abs_error": rho(val, err), "mean_abs_error_nm": float(err.mean()),
                         "feature_median": float(np.nanmedian(val[np.isfinite(val)])) if np.isfinite(val).any() else np.nan,
                         "feature_sd": float(np.nanstd(val[np.isfinite(val)])) if np.isfinite(val).any() else np.nan})
        for name, controls in (
            ("end_x_abs_curvature_4|controls=end,curvature", ("axial_end_proximity", "centerline_curvature_scale_4")),
            ("end_x_sparse_support|controls=end,coverage", ("axial_end_proximity", "local_helix_coverage")),
            ("curvature_4_x_sparse_support|controls=curvature,coverage", ("centerline_curvature_scale_4", "local_helix_coverage")),
        ):
            partial_rows.append({"design": design, "split": SPLIT_OF[design], "feature": name,
                "partial_spearman_abs_error": partial_rank_rho(feats[name.split("|")[0]], err,
                    np.column_stack([feats[c] for c in controls]))})
        print("processed", design, flush=True)

    summary = {}
    for split in ("train", "validation", "test", "all"):
        ds = IDS if split == "all" else SPLITS[split]
        summary[split] = {}
        for name in sorted({r["feature"] for r in rows}):
            q = [r for r in rows if r["feature"] == name and r["design"] in ds]
            vals = np.asarray([r["rho_abs_error"] for r in q], float)
            vals = vals[np.isfinite(vals)]
            summary[split][name] = {
                "designs": int(len(vals)),
                "macro_spearman_abs_error": float(np.mean(vals)) if len(vals) else None,
                "median_spearman_abs_error": float(np.median(vals)) if len(vals) else None,
                "positive_designs": int(np.sum(vals > 0)),
                "positive_fraction": float(np.mean(vals > 0)) if len(vals) else None,
            }
    summary["partial_interactions"] = {}
    for name in sorted({r["feature"] for r in partial_rows}):
        for split in ("train", "validation", "test", "all"):
            ds = IDS if split == "all" else SPLITS[split]
            q = [r["partial_spearman_abs_error"] for r in partial_rows if r["feature"] == name and r["design"] in ds]
            vals = np.asarray(q, float); vals = vals[np.isfinite(vals)]
            summary["partial_interactions"].setdefault(name, {})[split] = {
                "designs": int(len(vals)), "macro_partial_spearman": float(np.mean(vals)) if len(vals) else None,
                "positive_designs": int(np.sum(vals > 0)), "negative_designs": int(np.sum(vals < 0))}
    out = Path(__file__).resolve().parent
    with (out / "mechanical_candidate_design_correlations.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    (out / "mechanical_candidate_summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    print(json.dumps(summary["test"], indent=2))


if __name__ == "__main__":
    main()
