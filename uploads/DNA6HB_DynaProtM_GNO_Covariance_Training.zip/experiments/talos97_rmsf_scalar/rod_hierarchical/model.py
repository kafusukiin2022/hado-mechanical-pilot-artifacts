"""Rod/endpoint hierarchical RMSF regressor on top of the frozen local-frame encoder."""
from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F


def _pool_rods(h, rod_index, axial_u, n_rods):
    means, maxima, ends = [], [], []
    for r in range(n_rods):
        ids = torch.nonzero(rod_index == r, as_tuple=False).flatten()
        if ids.numel() == 0:
            raise ValueError(f"empty rod id {r}")
        hr = h[ids]
        means.append(hr.mean(0))
        maxima.append(hr.max(0).values)
        ur = axial_u[ids]
        left = ids[ur <= .1]
        right = ids[ur >= .9]
        if left.numel() == 0:
            left = ids[ur == ur.min()]
        if right.numel() == 0:
            right = ids[ur == ur.max()]
        el, er = h[left].mean(0), h[right].mean(0)
        # Endpoint identity is exchangeable: retain endpoint mean and difference magnitude.
        ends.append(torch.cat(((el + er) * .5, torch.abs(el - er)), dim=0))
    return torch.stack(means), torch.stack(maxima), torch.stack(ends)


class RodMessage(nn.Module):
    def __init__(self, width):
        super().__init__()
        self.message = nn.Sequential(nn.Linear(width * 2, width), nn.SiLU(), nn.Linear(width, width))
        self.update = nn.Sequential(nn.LayerNorm(width * 4), nn.Linear(width * 4, width), nn.SiLU(), nn.Linear(width, width))

    def forward(self, h, edge_index):
        if edge_index.numel() == 0:
            agg = torch.zeros_like(h)
        else:
            src, dst = edge_index
            msg = self.message(torch.cat((h[src], h[dst]), dim=-1))
            agg = torch.zeros_like(h).index_add_(0, dst, msg)
            count = h.new_zeros((len(h), 1)).index_add_(0, dst, h.new_ones((len(dst), 1)))
            agg = agg / count.clamp_min(1)
        global_context = torch.cat((h.mean(0), h.max(0).values)).expand(len(h), -1)
        return h + self.update(torch.cat((h, agg, global_context), dim=-1))


class RodHierarchicalRMSF(nn.Module):
    """Node geometry -> rod pooling/endpoint anchors -> rod graph -> node RMSF."""
    def __init__(self, base_encoder, feature_mean, feature_std, baseline_nm, width=128, rod_layers=2, feature_width=96):
        super().__init__()
        self.base = base_encoder
        self.register_buffer("feature_mean", torch.as_tensor(feature_mean).float())
        self.register_buffer("feature_std", torch.as_tensor(feature_std).float().clamp_min(.01))
        self.feature_width = int(feature_width)
        self.feature_encoder = nn.Sequential(
            nn.Linear(len(feature_mean), self.feature_width), nn.SiLU(), nn.LayerNorm(self.feature_width),
            nn.Linear(self.feature_width, self.feature_width), nn.SiLU())
        self.node_encoder = nn.Sequential(nn.Linear(346 + self.feature_width, width), nn.SiLU(), nn.LayerNorm(width),
                                          nn.Linear(width, width), nn.SiLU())
        self.rod_encoder = nn.Sequential(nn.Linear(width * 2 + width * 2, width * 2), nn.SiLU(),
                                         nn.Linear(width * 2, width), nn.SiLU())
        self.rod_layers = nn.ModuleList([RodMessage(width) for _ in range(rod_layers)])
        self.node_update = nn.Sequential(nn.Linear(width * 6, width * 2), nn.SiLU(), nn.LayerNorm(width * 2),
                                         nn.Linear(width * 2, width), nn.SiLU(), nn.Linear(width, 1))
        nn.init.zeros_(self.node_update[-1].weight)
        nn.init.constant_(self.node_update[-1].bias, float(torch.log(torch.expm1(torch.tensor(float(baseline_nm))))))

    def forward(self, s, engineered, rod_index, axial_u, rod_edge_index):
        layers, _ = self.base.encode(s)
        h = self.node_encoder(torch.cat((layers[-1], self.feature_encoder((engineered - self.feature_mean) / self.feature_std)), dim=-1))
        n_rods = int(rod_index.max().item()) + 1
        rod_mean, rod_max, endpoint_pair = _pool_rods(h, rod_index, axial_u, n_rods)
        rod = self.rod_encoder(torch.cat((rod_mean, rod_max, endpoint_pair), dim=-1))
        for layer in self.rod_layers:
            rod = layer(rod, rod_edge_index)
        rod_context = rod[rod_index]
        endpoint_context = endpoint_pair[rod_index]
        global_context = torch.cat((h.mean(0), h.max(0).values)).expand(len(h), -1)
        node_context = torch.cat((h, rod_context, endpoint_context, global_context), dim=-1)
        return F.softplus(self.node_update(node_context).squeeze(-1))
