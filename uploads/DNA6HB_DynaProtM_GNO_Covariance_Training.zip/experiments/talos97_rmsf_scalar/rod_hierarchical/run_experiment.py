#!/usr/bin/env python3
"""Train a local-only rod/endpoint hierarchical RMSF model on TALOS97."""
from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
from scipy.stats import spearmanr

HERE = Path(__file__).resolve().parent
EXP = HERE.parent
ROOT = EXP.parents[1]
DATA = ROOT / "experiments/talos97_endpoint_v1/data"
LABELS = ROOT / "outputs/talos97_triplicate_analysis_20261028"
PRETRAIN = ROOT / "experiments/talos97_localframe_2m/checkpoints"
BASELINE_PRED = EXP / "results/transfer_ensemble_predictions.npz"
SCREEN = EXP / "posthoc_diagnostic/mechanical_candidate_summary.json"
ANALYSIS_DIR = EXP / "posthoc_diagnostic"
OUT = Path(os.environ.get("ROD_RMSF_OUT", str(HERE / "runs/seeded36_positive_train_features_20261031")))
SEEDS = (int(os.environ["ROD_RMSF_SEED"]),) if os.environ.get("ROD_RMSF_SEED") else (11, 22, 33)
EPOCHS = 200
LR = 1e-3
WEIGHT_DECAY = 1e-4
CLIP = 5.0
WIDTH = int(os.environ.get("ROD_RMSF_WIDTH", "128"))
FEATURE_WIDTH = int(os.environ.get("ROD_RMSF_FEATURE_WIDTH", "96"))
ROD_LAYERS = 2

sys.path.insert(0, str(EXP))
sys.path.insert(0, str(ANALYSIS_DIR))
from backbone import BasisNet, load_inputs
from model import RodHierarchicalRMSF
import analyze_mechanical_candidates as candidate


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def torch_load(path, map_location="cpu"):
    # The project ebd environment includes older torch releases without weights_only.
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError as exc:
        if "weights_only" not in str(exc):
            raise
        return torch.load(path, map_location=map_location)


def write_json(path, value):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def metric(pred, y):
    pred, y = np.asarray(pred, float), np.asarray(y, float)
    corr = float(np.corrcoef(pred, y)[0, 1]) if np.std(pred) > 1e-12 and np.std(y) > 1e-12 else None
    rank = float(spearmanr(pred, y)[0]) if corr is not None else None
    return {"rmse_nm": float(np.sqrt(np.mean((pred-y)**2))),
            "mae_nm": float(np.mean(np.abs(pred-y))), "pearson": corr, "spearman": rank}


def to_device(q, key, device):
    value = q[key]
    if isinstance(value, np.ndarray):
        value = torch.from_numpy(value)
    return value.to(device, non_blocking=True)


def label_data(design):
    path = LABELS / design / "per_nucleotide_statistics.csv"
    with path.open(newline="") as f:
        rr = list(csv.DictReader(f))
    if [int(r["topology_row"]) for r in rr] != list(range(len(rr))):
        raise ValueError(f"label topology row mismatch: {design}")
    y = np.asarray([float(r["pooled_rmsf_nm"]) for r in rr], np.float32)
    if not np.isfinite(y).all() or (y < 0).any():
        raise ValueError(f"invalid RMSF target: {design}")
    return y


def make_rod_graph(raw, mapping):
    vh = np.asarray([m["virtual_helix"] for m in mapping], int)
    ax = np.asarray([m["axial_index"] for m in mapping], int)
    unique = np.unique(vh)
    lut = {int(v): i for i, v in enumerate(unique)}
    rod_index = np.asarray([lut[int(v)] for v in vh], np.int64)
    axial_u = np.zeros(len(vh), np.float32)
    for v in unique:
        mask = vh == v
        lo, hi = int(ax[mask].min()), int(ax[mask].max())
        axial_u[mask] = .5 if hi == lo else (ax[mask] - lo) / (hi - lo)
    e = np.asarray(raw["edge_index"], int)
    et = np.asarray(raw["edge_types"], int)
    pairs = set()
    for i, j in e[:, et == 3].T:
        ri, rj = int(rod_index[i]), int(rod_index[j])
        if ri != rj:
            pairs.add((ri, rj)); pairs.add((rj, ri))
    edges = np.asarray(sorted(pairs), np.int64)
    if edges.size == 0:
        edges = np.empty((0, 2), np.int64)
    return rod_index, axial_u, edges.T.copy(), unique


def load_design(design, selected, load_target=True):
    s, _, _ = load_inputs(DATA, design)
    input_path = DATA / "inputs" / f"{design}.npz"
    with np.load(input_path) as z:
        raw = {k: np.asarray(z[k]) for k in z.files}
    map_path = DATA / "designs" / design / "topology_to_cadnano.json"
    mapping_obj = json.loads(map_path.read_text())
    mapping = mapping_obj["mapping"]
    if not mapping_obj["unique_mapping"] or len(mapping) != len(s):
        raise ValueError(f"non-unique/mismatched topology mapping: {design}")
    if [m["topology_row"] for m in mapping] != list(range(len(s))):
        raise ValueError(f"mapping row mismatch: {design}")
    feats = candidate.make_features(raw, mapping)
    f = np.stack([feats[name] for name in selected], axis=1).astype(np.float32)
    rod_index, axial_u, rod_edges, unique_vh = make_rod_graph(raw, mapping)
    if len(s) != len(f) or len(f) != len(rod_index):
        raise ValueError(f"node count mismatch: {design}")
    y = label_data(design) if load_target else None
    if y is not None and len(y) != len(s):
        raise ValueError(f"label count mismatch: {design}")
    return {
        "s": torch.from_numpy(np.asarray(s, np.float32)), "f": f,
        "rod_index": torch.from_numpy(rod_index), "axial_u": torch.from_numpy(axial_u),
        "rod_edges": torch.from_numpy(rod_edges), "vh": unique_vh,
        "y": None if y is None else torch.from_numpy(y),
        "input_sha": sha(input_path), "label_sha": sha(LABELS / design / "per_nucleotide_statistics.csv") if load_target else None,
        "map_sha": sha(map_path),
    }


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(2)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; this run is intended for one local A100")
    device = torch.device("cuda:0")
    OUT.mkdir(parents=True, exist_ok=False)
    (OUT / "checkpoints").mkdir()

    split = json.loads((DATA / "split.json").read_text())
    assert [len(split[k]) for k in ("train", "validation", "test")] == [68, 14, 15]
    screen = json.loads(SCREEN.read_text())
    selected = sorted([name for name, stats in screen["train"].items()
                       if stats["macro_spearman_abs_error"] > 0])
    if len(selected) != 36:
        raise ValueError(f"Expected 36 train-positive candidate features, got {len(selected)}")
    selection = {"criterion": "training-split design-macro Spearman(feature, abs existing-model RMSF error) > 0",
                 "split_used_for_selection": "train_only", "selected_count": len(selected),
                 "features": [{"name": name, "train_macro_rho": screen["train"][name]["macro_spearman_abs_error"]}
                              for name in selected], "validation_or_test_used_for_selection": False}
    write_json(OUT / "feature_selection.json", selection)

    source_paths = [HERE / "model.py", HERE / "run_experiment.py", EXP / "backbone.py",
                    EXP / "train.py", EXP / "SPEC.md", SCREEN, ANALYSIS_DIR / "analyze_mechanical_candidates.py",
                    ANALYSIS_DIR / "verify_interaction_partials.py", DATA / "split.json", DATA / "manifest.json"]
    split_ids = split["train"] + split["validation"]
    manifest_rows = {r["design_id"]: r for r in json.loads((DATA / "manifest.json").read_text())["rows"]}
    data = {}
    hashes = {str(p): sha(p) for p in source_paths}
    for d in split_ids:
        inp = DATA / "inputs" / f"{d}.npz"
        if sha(inp) != manifest_rows[d]["input_cache_sha256"]:
            raise ValueError(f"input cache hash mismatch: {d}")
        data[d] = load_design(d, selected, load_target=True)
        if data[d]["input_sha"] != manifest_rows[d]["input_cache_sha256"]:
            raise ValueError(f"input hash changed during load: {d}")
        hashes[str(inp)] = data[d]["input_sha"]
        hashes[str(LABELS / d / "per_nucleotide_statistics.csv")] = data[d]["label_sha"]
        hashes[str(DATA / "designs" / d / "topology_to_cadnano.json")] = data[d]["map_sha"]

    train_features = np.concatenate([data[d]["f"] for d in split["train"]], axis=0)
    feature_median = np.nanmedian(train_features, axis=0)
    if not np.isfinite(feature_median).all():
        raise ValueError("selected feature has no finite training values")
    for d in split_ids:
        f = data[d]["f"]
        bad = ~np.isfinite(f)
        if bad.any():
            f[bad] = np.broadcast_to(feature_median, f.shape)[bad]
        data[d]["f"] = f
    design_means = np.stack([data[d]["f"].mean(0) for d in split["train"]])
    design_second = np.stack([(data[d]["f"] ** 2).mean(0) for d in split["train"]])
    fmean = design_means.mean(0)
    fstd = np.maximum(design_second.mean(0) - fmean**2, 0) ** .5
    fstd = np.maximum(fstd, .01).astype(np.float32)
    fmean = fmean.astype(np.float32)

    frame_ckpts = {}
    for seed in SEEDS:
        p = PRETRAIN / f"frame_{seed}.pt"
        frame_ckpts[seed] = torch_load(p, map_location="cpu")["state"]
        hashes[str(p)] = sha(p)
    first_state = frame_ckpts[SEEDS[0]]
    base_mean, base_std = first_state["mean"], first_state["std"]
    baseline = float(np.mean([float(data[d]["y"].mean()) for d in split["train"]]))
    if any(not torch.allclose(state["mean"], base_mean, atol=1e-6) or not torch.allclose(state["std"], base_std, atol=1e-6)
           for state in frame_ckpts.values()):
        raise ValueError("pretrained seeds use inconsistent input normalization")
    write_json(OUT / "manifest.json", {
        "split": split, "train_validation_loaded": True, "test_loaded": False,
        "features": selection, "feature_mean": fmean.tolist(), "feature_std": fstd.tolist(),
        "feature_imputation_median": feature_median.tolist(), "baseline_train_mean_nm": baseline,
        "seeds": SEEDS, "epochs": EPOCHS, "lr": LR, "weight_decay": WEIGHT_DECAY,
        "clip_grad_norm": CLIP, "width": WIDTH, "feature_width": FEATURE_WIDTH, "rod_layers": ROD_LAYERS,
        "device": torch.cuda.get_device_name(0), "torch": torch.__version__, "source_and_data_hashes": hashes,
    })
    print(f"DATA_READY designs={len(data)} features={len(selected)} baseline={baseline:.5f} gpu={torch.cuda.get_device_name(0)}", flush=True)

    def make(seed):
        torch.manual_seed(seed)
        base = BasisNet(base_mean, base_std, width=346, variant="frame")
        base.load_state_dict(frame_ckpts[seed], strict=True)
        return RodHierarchicalRMSF(base, fmean, fstd, baseline, width=WIDTH, rod_layers=ROD_LAYERS,
                                   feature_width=FEATURE_WIDTH).to(device)

    # Largest-design forward/backward gate before any long optimization.
    largest = max(split["train"], key=lambda d: len(data[d]["y"]))
    gate_model = make(SEEDS[0])
    q = data[largest]
    args = [to_device(q, k, device) for k in ("s", "f", "rod_index", "axial_u", "rod_edges")]
    yy = q["y"].to(device)
    opt = torch.optim.AdamW(gate_model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    gate_rows = []
    for step in range(2):
        opt.zero_grad(set_to_none=True)
        pred = gate_model(*args)
        if pred.shape != yy.shape or not torch.isfinite(pred).all() or (pred < 0).any():
            raise ValueError("largest-design forward output invalid")
        loss = torch.mean((pred-yy)**2)
        loss.backward()
        grad = torch.nn.utils.clip_grad_norm_(gate_model.parameters(), CLIP)
        if not torch.isfinite(grad):
            raise ValueError("largest-design gradient invalid")
        opt.step()
        gate_rows.append({"step": step+1, "mse": float(loss.detach()), "grad_norm": float(grad)})
    write_json(OUT / "gate.json", {"passed": True, "design": largest, "nodes": len(yy),
        "rods": int(q["rod_index"].max())+1, "params": sum(p.numel() for p in gate_model.parameters()), "steps": gate_rows})
    del gate_model, opt, pred, loss, yy, args
    torch.cuda.empty_cache()

    histories, best_runs = [], []
    (OUT / "history.jsonl").touch()
    for seed in SEEDS:
        model = make(seed)
        optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
        rng = np.random.default_rng(seed)
        best, best_epoch, start = float("inf"), 0, time.time()
        for epoch in range(1, EPOCHS + 1):
            model.train(); train_losses = []
            for d in rng.permutation(split["train"]):
                q = data[d]
                args = [to_device(q, k, device) for k in ("s", "f", "rod_index", "axial_u", "rod_edges")]
                y = q["y"].to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                pred = model(*args)
                loss = torch.mean((pred-y)**2)
                if not torch.isfinite(loss):
                    raise ValueError(f"non-finite train loss {d} seed {seed} epoch {epoch}")
                loss.backward()
                grad = torch.nn.utils.clip_grad_norm_(model.parameters(), CLIP)
                if not torch.isfinite(grad):
                    raise ValueError("non-finite gradient")
                optimizer.step()
                train_losses.append(float(loss.detach()))
                del args, y, pred, loss
            model.eval()
            scores = []
            with torch.no_grad():
                for d in split["validation"]:
                    q = data[d]
                    args = [to_device(q, k, device) for k in ("s", "f", "rod_index", "axial_u", "rod_edges")]
                    y = q["y"].to(device, non_blocking=True)
                    scores.append(float(torch.mean((model(*args)-y)**2).sqrt()))
            score = float(np.mean(scores))
            if not np.isfinite(score):
                raise ValueError("non-finite validation macro RMSE")
            if score < best:
                best, best_epoch = score, epoch
                torch.save({"state": model.state_dict(), "seed": seed, "epoch": epoch,
                            "val_macro_rmse_nm": best, "selected_features": selected},
                           OUT / "checkpoints" / f"rod_hierarchical_seed{seed}_best.pt")
            row = {"seed": seed, "epoch": epoch, "train_mse_nm2": float(np.mean(train_losses)),
                   "val_macro_rmse_nm": score, "best_epoch": best_epoch,
                   "best_val_macro_rmse_nm": best, "seconds": time.time()-start}
            with (OUT / "history.jsonl").open("a") as f:
                f.write(json.dumps(row) + "\n")
            if epoch == 1 or epoch % 10 == 0:
                print(f"seed={seed} epoch={epoch} val={score:.5f} best={best:.5f} sec={time.time()-start:.1f}", flush=True)
            write_json(OUT / "status.json", {"status": "training", **row})
        torch.save({"state": model.state_dict(), "seed": seed, "epoch": EPOCHS,
                    "optimizer": optimizer.state_dict()}, OUT / "checkpoints" / f"rod_hierarchical_seed{seed}_last.pt")
        best_runs.append({"seed": seed, "best_epoch": best_epoch, "best_val_macro_rmse_nm": best,
                          "seconds": time.time()-start})
        del model, optimizer
        torch.cuda.empty_cache()
    write_json(OUT / "selection.json", {"runs": best_runs, "criterion": "per-seed validation macro RMSE",
                                         "test_loaded": False})

    # Only now open test labels and inputs, after all checkpoint choices are frozen.
    test_ids = split["test"]
    for d in test_ids:
        data[d] = load_design(d, selected, load_target=True)
        hashes[str(DATA / "inputs" / f"{d}.npz")] = data[d]["input_sha"]
        hashes[str(LABELS / d / "per_nucleotide_statistics.csv")] = data[d]["label_sha"]
        hashes[str(DATA / "designs" / d / "topology_to_cadnano.json")] = data[d]["map_sha"]

    all_predictions = {}
    metric_rows = []
    for seed in SEEDS:
        ck = torch_load(OUT / "checkpoints" / f"rod_hierarchical_seed{seed}_best.pt", map_location="cpu")
        model = make(seed); model.load_state_dict(ck["state"]); model.eval()
        pred_by_design = {}
        with torch.no_grad():
            for d in split["train"] + split["validation"] + split["test"]:
                q = data[d]
                args = [to_device(q, k, device) for k in ("s", "f", "rod_index", "axial_u", "rod_edges")]
                pred = model(*args).cpu().numpy()
                pred_by_design[d] = pred
                metric_rows.append({"arm": "rod_hierarchical", "seed": seed,
                                    "split": next(k for k in ("train", "validation", "test") if d in split[k]),
                                    "design": d, **metric(pred, q["y"].numpy())})
        all_predictions[seed] = pred_by_design
        np.savez_compressed(OUT / f"rod_hierarchical_seed{seed}_predictions.npz", **pred_by_design)
        del model
        torch.cuda.empty_cache()

    ensemble = {d: np.mean([all_predictions[s][d] for s in SEEDS], axis=0)
                for d in split["train"] + split["validation"] + split["test"]}
    np.savez_compressed(OUT / "rod_hierarchical_ensemble_predictions.npz", **ensemble)
    baseline_npz = np.load(BASELINE_PRED)
    for d in split["train"] + split["validation"] + split["test"]:
        metric_rows.append({"arm": "existing_transfer_ensemble", "seed": 0,
                            "split": next(k for k in ("train", "validation", "test") if d in split[k]),
                            "design": d, **metric(baseline_npz[d], data[d]["y"].numpy())})
        metric_rows.append({"arm": "rod_hierarchical_ensemble", "seed": 0,
                            "split": next(k for k in ("train", "validation", "test") if d in split[k]),
                            "design": d, **metric(ensemble[d], data[d]["y"].numpy())})
    with (OUT / "per_design_metrics.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(metric_rows[0])); w.writeheader(); w.writerows(metric_rows)

    macro = {}
    for arm in sorted({r["arm"] for r in metric_rows}):
        macro[arm] = {}
        for part in ("train", "validation", "test"):
            subset = [r for r in metric_rows if r["arm"] == arm and r["split"] == part]
            macro[arm][part] = {k: float(np.mean([r[k] for r in subset if r[k] is not None]))
                                for k in ("rmse_nm", "mae_nm", "pearson", "spearman")}
    # Paired design bootstrap of the test RMSE difference: rod model minus existing ensemble.
    old = np.asarray([next(r["rmse_nm"] for r in metric_rows if r["arm"] == "existing_transfer_ensemble" and r["design"] == d) for d in test_ids])
    new = np.asarray([next(r["rmse_nm"] for r in metric_rows if r["arm"] == "rod_hierarchical_ensemble" and r["design"] == d) for d in test_ids])
    delta = new - old
    rng = np.random.default_rng(20261031)
    boot = np.asarray([np.mean(delta[rng.integers(0, len(delta), len(delta))]) for _ in range(10000)])
    result = {"macro_metrics": macro, "test_paired_rmse_delta_nm": {
        "rod_minus_existing_per_design_macro": float(delta.mean()), "median_per_design_delta_nm": float(np.median(delta)),
        "designs_improved": int((delta < 0).sum()), "designs_total": len(delta),
        "bootstrap_95_percentile_nm": [float(np.quantile(boot, .025)), float(np.quantile(boot, .975))]},
        "selection": best_runs, "selected_feature_count": len(selected), "selected_features": selected,
        "test_was_loaded_after_checkpoint_selection": True}
    write_json(OUT / "summary.json", result)
    # Verify all source/input/label/topology hashes still match current files.
    changed = [path for path, digest in hashes.items() if sha(path) != digest]
    if changed:
        raise ValueError(f"unexpected source/data changes: {changed[:5]}")
    write_json(OUT / "verification.json", {"passed": True, "hashes_unchanged": len(hashes),
        "train_validation_designs": len(split["train"])+len(split["validation"]), "test_designs": len(test_ids),
        "selected_features": len(selected), "seeds": list(SEEDS), "epochs_per_seed": EPOCHS,
        "test_loaded_after_selection": True, "feature_selection_train_only": True,
        "gate": json.loads((OUT / "gate.json").read_text()), "checkpoints": {
            p.name: sha(p) for p in sorted((OUT / "checkpoints").glob("*best.pt"))}})
    write_json(OUT / "status.json", {"status": "complete", "summary": result})
    print("COMPLETE", json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
