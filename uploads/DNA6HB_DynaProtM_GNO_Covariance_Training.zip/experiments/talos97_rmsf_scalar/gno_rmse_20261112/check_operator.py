import ast,json
from pathlib import Path
import torch
b=Path(__file__).resolve().parent
module=ast.parse((b/'run.py').read_text()); ns={'torch':torch}
exec(compile(ast.Module(body=[n for n in module.body if isinstance(n,ast.ClassDef) and n.name=='GNOModel'],type_ignores=[]),'model','exec'),ns)
class Base(torch.nn.Module):
 def __init__(self):
  super().__init__();self.node_update=torch.nn.Sequential(*[torch.nn.Identity() for _ in range(6)])
 def forward(self,h):return self.node_update(h).sum(-1)*0+1
h=torch.randn(6,128);e=torch.tensor([[0,1,1,2,2,3,3,4,4,5],[1,0,2,1,3,2,4,3,5,4]])
f=torch.randn(10,7);deg=torch.ones(6);results={}
for arm in ['local','backbone','gno_topology','gno_geometry']:
 torch.manual_seed(11);m=ns['GNOModel'](Base(),arm)
 # Nonzero head exercises the integral path, not merely zero-init identity.
 torch.nn.init.normal_(m.readout.weight,std=.1)
 y=m([h],e,deg,f)
 perm=torch.tensor([5,2,1,4,0,3]);inv=torch.argsort(perm)
 yp=m([h[perm]],inv[e],deg,f)
 assert torch.allclose(yp,y[perm],atol=1e-6)
 loss=((y-2)**2).mean().add(1e-8).sqrt();loss.backward()
 assert all(torch.isfinite(p.grad).all() for p in m.parameters() if p.grad is not None)
 if arm=='gno_topology':
  f2=f.clone();f2[:,4:]+=10
  assert torch.allclose(y,m([h],e,deg,f2))
 results[arm]={'permutation_pass':True,'gradient_pass':True}
# RMSE has nm units and differs from MSE; zero residual remains finite.
p=torch.tensor([1.,3.],requires_grad=True);loss=(p.square().mean()+1e-8).sqrt();assert abs(loss.item()-5**.5)<1e-6
(b/'operator_verification.json').write_text(json.dumps(results,indent=2)+'\n');print(results)
