"""Matched signed-source diffusion ablation for modal RMSF prediction."""
from __future__ import annotations
import csv, hashlib, json, os, sys, time
from pathlib import Path
import numpy as np
import torch
from scipy.stats import rankdata, spearmanr

B=Path(__file__).resolve().parent; EXP=B.parent
sys.path[:0]=[str(EXP/'rod_hierarchical'),str(EXP),str(EXP/'posthoc_diagnostic')]
import run_experiment as re
sys.path.insert(0,str(EXP/'modal_compliance20m_20261102'))
from modal import CONFIG,NAMES
from model import RodHierarchicalRMSF
from backbone import BasisNet

CACHE=EXP/'modal_compliance20m_20261102'
LABELS=EXP/'covariance_aux20m_20261102'
SOURCE=EXP/'continuation20m_20261102'
ARMS=['local','backbone','gno_topology','gno_geometry']

def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)

def metrics(p,y):
    p=np.asarray(p,float);y=np.asarray(y,float); k=max(1,int(np.ceil(.2*len(y))))
    hi=np.argsort(y,kind='stable')[-k:];lo=np.argsort(y,kind='stable')[:k]
    rho=float(spearmanr(p,y)[0]) if np.std(p)>0 and np.std(y)>0 else 0.
    return dict(rmse_nm=float(np.sqrt(np.mean((p-y)**2))),mae_nm=float(np.mean(abs(p-y))),spearman=rho,
      top20_mae_nm=float(np.mean(abs(p[hi]-y[hi]))),top20_bias_nm=float(np.mean(p[hi]-y[hi])),
      bottom20_mae_nm=float(np.mean(abs(p[lo]-y[lo]))),bottom20_bias_nm=float(np.mean(p[lo]-y[lo])),
      std_ratio=float(np.std(p)/max(np.std(y),1e-12)))

def graph_edges(raw,kind):
    n=len(raw['pos'])
    if kind=='backbone': e=np.asarray(raw['backbone_edges'],int)
    elif kind=='topology': e=np.asarray(raw['edge_index'][:,np.isin(raw['edge_types'],[1,2,3])],int).T
    elif kind=='spatial': e=np.asarray(raw['edge_index'][:,np.asarray(raw['edge_types'])==0],int).T
    else: raise ValueError(kind)
    if e.ndim==2 and e.shape[0]==2 and e.shape[1]!=2: e=e.T
    if e.size==0:return np.empty((2,0),np.int64),np.zeros(n,np.float32)
    und=np.unique(np.sort(e,axis=1),axis=0)
    directed=np.concatenate([und,und[:,::-1]],axis=0)
    # P f at i is the mean over i's neighbors; row stochastic and label-free.
    src=directed[:,1].astype(np.int64);dst=directed[:,0].astype(np.int64)
    deg=np.bincount(dst,minlength=n).astype(np.float32)
    return np.stack([src,dst]),np.maximum(deg,1.)

class GNOModel(torch.nn.Module):
    """Learned edge integral kernel, recurrent multiscale field, local skip."""
    def __init__(self,base,arm):
        super().__init__(); self.base=base; self.arm=arm
        self.lift=torch.nn.Linear(128,16)
        self.kernel=torch.nn.Sequential(torch.nn.Linear(7,32),torch.nn.SiLU(),torch.nn.Linear(32,16))
        self.scale=torch.nn.Linear(128,6)
        self.readout=torch.nn.Linear(32,1)
        torch.nn.init.zeros_(self.readout.weight); torch.nn.init.zeros_(self.readout.bias)
        def capture(_module,args): self.embedding=args[0]
        self.base.node_update[5].register_forward_pre_hook(capture)

    def forward(self,args,edges,degree,edge_features=None):
        base=self.base(*args); h=self.embedding; source=self.lift(h)
        src,dst=edges
        if self.arm.startswith('gno'):
            feat=edge_features.clone()
            if self.arm=='gno_topology': feat[:,4:]=0
            kernel=torch.nn.functional.softplus(self.kernel(feat))+.001
        else: kernel=source.new_ones((len(src),16))
        denom=torch.zeros_like(source).index_add_(0,dst,kernel).clamp_min(1e-8)
        cur=source; states=[source]
        limit=8 if self.arm=='backbone' else 16
        for step in range(1,limit+1):
            nxt=torch.zeros_like(source).index_add_(0,dst,cur[src]*kernel)/denom
            cur=.2*source+.8*nxt
            if step in (1,2,4,8,16):states.append(cur)
        if self.arm=='local': out=source
        else:
            weights=torch.softmax(self.scale(h)[:,:len(states)],-1)
            out=sum(weights[:,k:k+1]*v for k,v in enumerate(states))
        correction=torch.tanh(self.readout(torch.cat((source,out),-1)).squeeze(-1))
        self.last_source=source; self.last_correction=correction
        return (base+correction).clamp_min(1e-6)


def main():
    torch.set_num_threads(2);torch.set_num_interop_threads(2)
    if not torch.cuda.is_available():raise RuntimeError('A100 CUDA is required')
    arm=os.environ['FUNGUS_ARM'];assert arm in ARMS
    protocol=json.loads((B/'protocol.json').read_text());seed=int(os.environ.get('GNO_SEED','11'));device='cuda:0'
    original=json.loads((SOURCE/'split.json').read_text());effective=json.loads((LABELS/'effective_split.json').read_text())
    for row in effective['excluded_training_designs']:
        assert row['design']=='6hb_015' or 'PBC cut detected count=' in row['reason'],row
    assert len(effective['train'])==71 and len(effective['validation'])==18 and effective['validation']==original['validation']
    split={'train':effective['train'],'validation':effective['validation']}
    cache=json.loads((CACHE/'cache_manifest.json').read_text());assert cache['passed'] and not cache['targets_read'] and cache['config']==CONFIG
    qc=json.loads((SOURCE/'label_verification.json').read_text());assert qc['passed']
    label_qc=json.loads((LABELS/'label_verification.json').read_text());assert label_qc['passed']
    source_labels={r['design_id']:r for r in qc['rows']};cache_rows={r['design']:r for r in cache['rows']}
    first=split['train'][0]
    with np.load(re.DATA/'inputs'/(first+'.npz')) as z:raw={k:z[k] for k in z.files}
    mapping=json.loads((re.DATA/'designs'/first/'topology_to_cadnano.json').read_text())['mapping']
    selected=sorted(re.candidate.make_features(raw,mapping));data={};provenance={}
    for d in split['train']+split['validation']:
        q=re.load_design(d,selected,load_target=False);ip=re.DATA/'inputs'/(d+'.npz')
        assert q['input_sha']==cache_rows[d]['input_sha256']
        cp=CACHE/'cache'/(d+'.npz');assert re.sha(cp)==cache_rows[d]['feature_sha256']
        with np.load(cp) as z:modal=z['features'].copy()
        q['f']=np.concatenate([q['f'],modal],axis=1)
        lp=SOURCE/'labels'/d/'per_nucleotide_statistics.csv';assert re.sha(lp)==source_labels[d]['label_sha256']
        with lp.open() as f:rows=list(csv.DictReader(f))
        assert [int(r['topology_row']) for r in rows]==list(range(len(q['s'])))
        q['y']=torch.tensor([float(r['rmsf_nm']) for r in rows],dtype=torch.float32)
        with np.load(ip) as z:raw={k:z[k] for k in z.files}
        kind='backbone' if arm=='backbone' else 'topology'
        edges,degree=graph_edges(raw,kind)
        q['diff_edges']=torch.tensor(edges,dtype=torch.long);q['degree']=torch.tensor(degree,dtype=torch.float32)
        # Same edge set for both GNO arms; geometry only conditions kernel weights.
        distance=np.linalg.norm(raw['pos'][edges[0]]-raw['pos'][edges[1]],axis=1)
        pairs={}
        for (i,j),t in zip(raw['edge_index'].T,raw['edge_types']):
            if int(t) in (1,2,3): pairs.setdefault(tuple(sorted((int(i),int(j)))),set()).add(int(t))
        ef=np.zeros((edges.shape[1],7),np.float32)
        for ei,(i,j) in enumerate(edges.T):
            for t in pairs.get(tuple(sorted((int(i),int(j)))),set()):ef[ei,t-1]=1
        ef[:,3]=1
        ef[:,4:]=np.stack((np.log1p(distance),np.exp(-distance),1/(1+distance)),axis=1)
        q['permutation']=torch.tensor(ef,dtype=torch.float32)
        print('loaded',d,flush=True)
        data[d]=q
        for p in (ip,cp,lp,re.DATA/'designs'/d/'topology_to_cadnano.json'):provenance[str(p)]=re.sha(p)
    train=split['train'];median=np.nanmedian(np.concatenate([data[d]['f'] for d in train]),axis=0)
    assert np.isfinite(median).all()
    for q in data.values():
        bad=~np.isfinite(q['f']);q['f'][bad]=np.broadcast_to(median,q['f'].shape)[bad]
    def norm(key):
        means=np.stack([np.asarray(data[d][key]).mean(0) for d in train]);secs=np.stack([(np.asarray(data[d][key])**2).mean(0) for d in train])
        m=means.mean(0);return m,np.maximum(np.maximum(secs.mean(0)-m*m,0)**.5,.01)
    sm,ss=norm('s');fm,fs=norm('f');baseline=float(np.mean([float(data[d]['y'].mean()) for d in train]))
    # Keep the failed compatibility attempt intact; this corrected run is isolated.
    out=B/'results'/('seed%d'%seed)/arm;out.mkdir(parents=True,exist_ok=False)
    for p in (B/'run.py',B/'protocol.json',CACHE/'modal.py',CACHE/'cache_manifest.json',SOURCE/'split.json',LABELS/'effective_split.json',EXP/'backbone.py',EXP/'rod_hierarchical/model.py',EXP/'rod_hierarchical/run_experiment.py'):
        provenance[str(p)]=re.sha(p)
    write(out/'manifest.json',dict(protocol=protocol,arm=arm,split=split,config=CONFIG,features=selected+NAMES,
      scalar_mean=sm.tolist(),scalar_std=ss.tolist(),feature_mean=fm.tolist(),feature_std=fs.tolist(),baseline_nm=baseline,
      graph='input-only multi-scale GNO; '+arm,gpu=torch.cuda.get_device_name(0),hashes=provenance))
    def make():
        torch.manual_seed(seed);base=BasisNet(sm,ss,width=346,variant='frame')
        core=RodHierarchicalRMSF(base,fm,fs,baseline,width=128,feature_width=96,rod_layers=2)
        return GNOModel(core,arm).to(device)
    def args(q):return [re.to_device(q,k,device) for k in ('s','f','rod_index','axial_u','rod_edges')]
    model=make();init_hash=hashlib.sha256(b''.join(p.detach().cpu().numpy().tobytes() for p in model.parameters())).hexdigest()
    largest=max(train,key=lambda d:len(data[d]['y']));q=data[largest];gate=make()
    pp=gate(args(q),q['diff_edges'].to(device),q['degree'].to(device),q['permutation'].to(device))
    loss=torch.sqrt((pp-q['y'].to(device)).square().mean()+1e-8)
    loss.backward()
    gate_grads=[p.grad for p in gate.parameters() if p.grad is not None]
    assert torch.isfinite(loss) and all(torch.isfinite(g).all() for g in gate_grads)
    gn=torch.nn.utils.clip_grad_norm_(gate.parameters(),5.)
    assert torch.isfinite(gn) and all(torch.isfinite(g).all() for g in gate_grads)
    write(out/'gate.json',dict(passed=True,design=largest,nodes=len(q['y']),loss=float(loss.detach()),grad_norm=float(gn),parameters=sum(p.numel() for p in model.parameters()),initial_sha256=init_hash))
    del gate,pp,loss;torch.cuda.empty_cache()
    opt=torch.optim.AdamW(model.parameters(),lr=protocol['lr'],weight_decay=protocol['weight_decay']);rng=np.random.default_rng(seed)
    best=float('inf');best_epoch=0;start=time.monotonic();run_epochs=[]
    for epoch in range(1,protocol['max_epochs']+1):
        model.train();losses=[]
        for d in rng.permutation(train):
            q=data[d];opt.zero_grad(set_to_none=True)
            pred=model(args(q),q['diff_edges'].to(device),q['degree'].to(device),q['permutation'].to(device))
            loss=torch.sqrt((pred-q['y'].to(device)).square().mean()+1e-8)
            assert torch.isfinite(loss);loss.backward()
            grads=[p.grad for p in model.parameters() if p.grad is not None]
            assert all(torch.isfinite(g).all() for g in grads)
            grad=torch.nn.utils.clip_grad_norm_(model.parameters(),5.)
            assert torch.isfinite(grad) and all(torch.isfinite(g).all() for g in grads)
            opt.step();losses.append(float(loss.detach()))
        model.eval();val=[]
        with torch.no_grad():
            for d in split['validation']:
                q=data[d];pred=model(args(q),q['diff_edges'].to(device),q['degree'].to(device),q['permutation'].to(device));val.append(float((pred-q['y'].to(device)).square().mean().sqrt()))
        score=float(np.mean(val));assert np.isfinite(score)
        if score<best:
            best=score;best_epoch=epoch;torch.save(dict(state=model.state_dict(),epoch=epoch,seed=seed,val_macro_rmse=best),out/'best.pt')
        row=dict(epoch=epoch,train_objective=float(np.mean(losses)),val_macro_rmse=score,best=best,best_epoch=best_epoch,seconds=time.monotonic()-start)
        with (out/'history.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        write(out/'status.json',dict(stage='training',**row))
        if epoch==1 or epoch%10==0:print(arm,row,flush=True)
        if epoch-best_epoch>=protocol['patience']:break
    ck=re.torch_load(out/'best.pt');model.load_state_dict(ck['state']);model.eval();preds={};rows=[]
    with torch.no_grad():
        for part,ids in split.items():
            for d in ids:
                q=data[d];p=model(args(q),q['diff_edges'].to(device),q['degree'].to(device),q['permutation'].to(device)).cpu().numpy();preds[d]=p
                row=dict(design=d,split=part,**metrics(p,q['y'].numpy()),mean_source=float(model.last_source.mean()),mean_abs_correction_nm=float(np.mean(abs(model.last_correction.detach().cpu().numpy()))))
                rows.append(row)
    np.savez_compressed(out/'predictions.npz',**preds)
    macro={}
    for part,subset in [('train_effective',[r for r in rows if r['split']=='train']),('validation18',[r for r in rows if r['split']=='validation']),('validation17_exclude009_posthoc',[r for r in rows if r['split']=='validation' and r['design']!='6hb_009'])]:
        macro[part]={k:float(np.mean([r[k] for r in subset])) for k in ('rmse_nm','mae_nm','top20_mae_nm','top20_bias_nm','bottom20_mae_nm','bottom20_bias_nm','std_ratio','spearman')}
    changed=[p for p,h in provenance.items() if re.sha(Path(p))!=h];assert not changed,changed
    write(out/'evaluation.json',dict(arm=arm,seed=seed,best_epoch=ck['epoch'],stopped_epoch=epoch,macro=macro,per_design=rows,source_hashes_unchanged=True,initial_trainable_sha256=init_hash))
    write(out/'status.json',dict(stage='complete',best_epoch=ck['epoch'],stopped_epoch=epoch))

if __name__=='__main__':main()
