"""Strict, topology-row-aligned data IO for 6HB oxDNA covariance supervision.

The GNO input uses per-nucleotide geometry from initial.dat; MD-derived
covariance_q targets are GLOBAL-frame time-centered position covariances (nm^2).
"""
from __future__ import annotations
import csv, hashlib, json
from pathlib import Path
import numpy as np
import torch
from model import load_input

DEFAULT_LABEL_REL = Path('outputs/talos97_directional_persistence_20261104/labels')
DEFAULT_INPUT_REL = Path('experiments/talos97_endpoint_v1/data/inputs')
DEFAULT_SPLIT_REL = Path('experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/effective_split.json')


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_split(path: Path) -> dict:
    split = json.loads(path.read_text(encoding='utf-8'))
    train, val = list(split['train']), list(split['validation'])
    if len(set(train)) != len(train) or len(set(val)) != len(val):
        raise ValueError('duplicate design IDs in split')
    if set(train) & set(val):
        raise ValueError('train/validation overlap')
    if not train or not val:
        raise ValueError('split must have nonempty training and validation')
    return {'train': train, 'validation': val}


def load_covariance(path: Path, n: int, psd_tolerance: float = 1e-5) -> dict:
    """Load global covariance_q with units nm^2. Never convert it using 34.072.

    Covariance is centered around trajectory's TIME mean, not the initial pose.
    A small SPD jitter is used only for matrix-log loss, not RMSF labels.
    """
    with np.load(path, allow_pickle=False) as z:
        if 'covariance_q' not in z:
            raise KeyError(f'{path}: expected key covariance_q, found {z.files}')
        a = np.asarray(z['covariance_q'], dtype=np.float64)
        if 'topology_row' in z:
            row = np.asarray(z['topology_row']).reshape(-1)
            if not np.array_equal(row, np.arange(n)):
                raise ValueError(f'{path}: topology_row mismatch')
    if a.shape != (n, 3, 3):
        raise ValueError(f'{path}: expected ({n},3,3), got {a.shape}')
    if not np.isfinite(a).all():
        raise ValueError(f'{path}: nonfinite covariance')
    asym = float(np.abs(a - a.swapaxes(-1, -2)).max())
    if asym > 1e-4:
        raise ValueError(f'{path}: asymmetric covariance max difference {asym:g}')
    a = (a + a.swapaxes(-1, -2)) / 2
    eigval = np.linalg.eigvalsh(a)
    min_eig = float(eigval.min())
    if min_eig < -psd_tolerance:
        raise ValueError(f'{path}: PSD failure min eigenvalue {min_eig:g} nm^2')
    # Small negative eig from floating point is projected to 0.
    if min_eig < 0:
        vals, vecs = np.linalg.eigh(a)
        a = (vecs * np.maximum(vals, 0)[..., None, :]) @ vecs.swapaxes(-1, -2)
        a = (a + a.swapaxes(-1, -2)) / 2
    rmsf = np.sqrt(np.maximum(np.trace(a, axis1=-2, axis2=-1), 0))
    return {'cov': a.astype(np.float32), 'rmsf': rmsf.astype(np.float32),
            'min_eig_nm2': min_eig, 'max_asym_nm2': asym}


def read_scalar_rmsf(path: Path, n: int) -> np.ndarray:
    """Optional audit only. Never use the CSV as covariance training targets."""
    with path.open(newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    if len(rows) != n or [int(r['topology_row']) for r in rows] != list(range(n)):
        raise ValueError(f'{path}: topology_row mismatch')
    y = np.array([float(r['rmsf_nm']) for r in rows], dtype=np.float32)
    if not np.isfinite(y).all():
        raise ValueError(f'{path}: nonfinite RMSF')
    return y


def load_design(project_root: Path, input_root: Path, label_root: Path,
                design: str, scalar_audit_root: Path | None = None,
                rmsf_check_tolerance_nm: float = 1e-3) -> dict:
    ip = input_root / f'{design}.npz'
    lp = label_root / design / 'statistics.npz'
    if not ip.is_file():
        raise FileNotFoundError(f'Missing input: {ip}')
    if not lp.is_file():
        raise FileNotFoundError(f'Missing label: {lp}')
    q = load_input(ip)
    target = load_covariance(lp, q['n'])
    r = q['R'].numpy().astype(np.float64)
    gram = r.transpose(0, 2, 1) @ r
    rot_err = float(np.max(np.abs(gram - np.eye(3)[None])))
    det = np.linalg.det(r)
    if rot_err > 1e-3 or np.any(det < 0.99):
        raise ValueError(f'{design}: rotation frames not SO(3): err={rot_err:g}, det_min={det.min():g}')
    q['cov_target'] = torch.from_numpy(target['cov'])
    q['rmsf_target'] = torch.from_numpy(target['rmsf'])
    # Local targets are geometrically equivalent to global covariance labels.
    local = r.transpose(0,2,1) @ target['cov'].astype(np.float64) @ r
    q['cov_local_target'] = torch.from_numpy(local.astype(np.float32))
    details = {'design': design, 'n': q['n'], 'input_sha256': sha256_file(ip),
               'label_sha256': sha256_file(lp), 'min_eigenvalue_nm2': target['min_eig_nm2'],
               'max_asymmetry_nm2': target['max_asym_nm2'], 'frame_orthogonality_error': rot_err}
    if scalar_audit_root:
        csv_path = scalar_audit_root / design / 'per_nucleotide_statistics.csv'
        if csv_path.is_file():
            old_y = read_scalar_rmsf(csv_path, q['n'])
            delta = np.abs(old_y - target['rmsf'])
            details['historical_rmsf_max_abs_diff_nm'] = float(delta.max())
            details['historical_rmsf_mae_nm'] = float(delta.mean())
            details['historical_rmsf_agrees'] = bool(delta.max() <= rmsf_check_tolerance_nm)
        else:
            details['historical_rmsf_audit'] = 'not found'
    q['audit'] = details
    return q


def prepare_dataset(project_root: Path, split_path: Path, input_root: Path,
                    label_root: Path, excluded: set[str], skip_missing: bool,
                    scalar_audit_root: Path | None = None,
                    rmsf_check_tolerance_nm: float = 1e-3) -> tuple[dict, dict, dict]:
    split = load_split(split_path)
    items, used = {}, {'train': [], 'validation': []}
    dropped = []
    for group in ('train', 'validation'):
        for design in split[group]:
            if design in excluded:
                dropped.append({'design': design, 'split': group, 'reason': 'explicit exclusion'})
                continue
            ip = input_root / f'{design}.npz'
            lp = label_root / design / 'statistics.npz'
            missing = [str(p) for p in (ip, lp) if not p.is_file()]
            if missing:
                if not skip_missing:
                    raise FileNotFoundError(f'{design}: missing {missing}. Add --skip-missing only if you accept a modified split.')
                dropped.append({'design': design, 'split': group, 'reason': 'missing files', 'paths': missing})
                continue
            items[design] = load_design(project_root, input_root, label_root, design,
                                        scalar_audit_root, rmsf_check_tolerance_nm)
            used[group].append(design)
            print(f'loaded {group}: {design}, n={items[design]["n"]}', flush=True)
    if not used['train'] or not used['validation']:
        raise ValueError('train or validation set empty after filtering')
    manifest = {'original_split': split, 'used_split': used, 'excluded_or_missing': dropped,
                'designs': [items[k]['audit'] for k in used['train'] + used['validation']]}
    return used, items, manifest
