"""Inference from ONE initial 6HB input .npz; no MD trajectory required."""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
import numpy as np
import torch
from model import GaussianGNO, load_input


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--input',type=Path,required=True,help='initial-design input NPZ')
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--device',default='auto')
    a=p.parse_args()
    device=torch.device('cuda' if a.device=='auto' and torch.cuda.is_available() else
                        'cpu' if a.device=='auto' else a.device)
    ck=torch.load(a.checkpoint,map_location='cpu',weights_only=True)
    cfg=ck['config']
    model=GaussianGNO(ck['mean'],ck['std'], ck['baseline_rmsf_nm'],
                      width=cfg['width'],hops=cfg['hops'],mode=cfg['mode'],
                      edge_mode=cfg['edge_mode']).to(device)
    model.load_state_dict(ck['model_state']);model.eval()
    q=load_input(a.input)
    with torch.no_grad():
        pr=model(q['s'].to(device),q['R'].to(device),q['edges'].to(device),
                 q['edge_features'].to(device))
    cov=pr['marginal_covariances'].cpu().numpy()
    local=pr['local_covariances'].cpu().numpy()
    rmsf=pr['rmsf'].cpu().numpy()
    a.out.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(a.out/'prediction.npz',
       marginal_covariances=cov, covariance_global_nm2=cov,
       covariance_local_nm2=local, rmsf=rmsf, rmsf_nm=rmsf,
       node_index=np.arange(len(rmsf),dtype=np.int32),input_pos=q['pos'])
    with (a.out/'rmsf.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['topology_row','predicted_rmsf_nm'])
        w.writerows((i,float(v)) for i,v in enumerate(rmsf))
    (a.out/'metadata.json').write_text(json.dumps({
       'node_type':'DNA nucleotide','node_order':'oxDNA topology row',
       'rmsf_unit':'nm','covariance_unit':'nm^2',
       'covariance_global_frame':'initial-design global frame',
       'covariance_local_frame':'initial nucleotide rotation frame (columns)',
       'input_pos_unit':'unchanged from NPZ',
       'input_required':'initial geometry only; no MD trajectory or velocity',
       'model':'DynaProt-M-inspired Gaussian GNO, NOT official IPA DynaProt',
       'checkpoint':str(a.checkpoint)},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'wrote {len(rmsf)} nucleotides to {a.out}')

if __name__=='__main__':main()
