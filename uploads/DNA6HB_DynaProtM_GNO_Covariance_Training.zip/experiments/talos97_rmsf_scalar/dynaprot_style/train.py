"""Train a DynaProt-M-inspired Gaussian GNO on 6HB nucleotide covariance_q.

This is a DNA adaptation using the user's original BasisNet/GNO input schema,
NOT a byte-for-byte reproduction of DynaProt's IPA network.

Input: initial-design geometry only. Supervision: time-centered Kabsch-aligned
covariance_q, global reference-frame, nm^2. Prediction: no MD trajectory needed.
"""
from __future__ import annotations
import argparse, csv, json, math, random, time
from pathlib import Path
import numpy as np
import torch
from model import GaussianGNO, covariance_logfrob_loss
from data_io import (DEFAULT_INPUT_REL, DEFAULT_LABEL_REL, DEFAULT_SPLIT_REL,
                     prepare_dataset)


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument('--project-root', type=Path, required=True, help='full original project with data')
    p.add_argument('--inputs', type=Path, default=None, help='overrides project-root/<inputs>')
    p.add_argument('--labels', type=Path, default=None, help='folder containing <design>/statistics.npz')
    p.add_argument('--split', type=Path, default=None, help='JSON with train and validation arrays')
    p.add_argument('--out', type=Path, required=True, help='new training output directory')
    p.add_argument('--exclude-designs', nargs='*', default=['6hb_024', '6hb_051'],
                   help='designs withheld pending the original strict QC')
    p.add_argument('--skip-missing', action='store_true',
                   help='explicitly drop designs with missing labels, including validation; logged in manifest')
    p.add_argument('--audit-historical-rmsf', action='store_true',
                   help='compare RMSF derived from covariance to historical CSV where available')
    p.add_argument('--require-historical-rmsf-match', action='store_true',
                   help='fail if compared historical RMSF differs by >--rmsf-tolerance')
    p.add_argument('--rmsf-tolerance', type=float, default=1e-3)
    p.add_argument('--epochs', type=int, default=120)
    p.add_argument('--patience', type=int, default=25)
    p.add_argument('--lr', type=float, default=1e-4)
    p.add_argument('--width', type=int, default=128)
    p.add_argument('--hops', type=int, default=8, choices=[2, 4, 8, 16])
    p.add_argument('--edge-mode', choices=['geometry','topology'], default='geometry')
    p.add_argument('--cov-loss-weight', type=float, default=1.0,
                   help='weight for local Log-Euclidean covariance loss')
    p.add_argument('--rmsf-loss-weight', type=float, default=1.0,
                   help='weight for global RMSF MSE (nm^2)')
    p.add_argument('--spd-jitter-nm2', type=float, default=1e-6,
                   help='added to TARGET covariance for matrix log ONLY')
    p.add_argument('--select-by', choices=['rmse','combined'], default='rmse',
                   help='RMSE (historical-style metric) or combined loss for best checkpoint')
    p.add_argument('--save-val-predictions', action='store_true')
    p.add_argument('--device', default='auto', help='auto, cpu, cuda or cuda:0')
    p.add_argument('--seed', type=int, default=11)
    p.add_argument('--threads', type=int, default=2)
    return p.parse_args()


def at_root(root: Path, path: Path | None, default: Path) -> Path:
    v = path if path is not None else default
    return v if v.is_absolute() else root / v


def to_device(q: dict, device: torch.device) -> dict:
    return {k: (v.to(device, non_blocking=True) if isinstance(v, torch.Tensor) else v)
            for k, v in q.items() if k not in ('audit','pos')}


def normalize_training(data: dict, train: list[str]) -> tuple[np.ndarray, np.ndarray, float]:
    # Macro normalization: one vote per design, not per nucleotide.
    mu = np.stack([data[d]['s'].numpy().mean(axis=0, dtype=np.float64) for d in train])
    ms2 = np.stack([(data[d]['s'].numpy().astype(np.float64)**2).mean(axis=0) for d in train])
    mean = mu.mean(axis=0)
    std = np.maximum(np.sqrt(np.maximum(ms2.mean(axis=0) - mean**2, 0)), 0.01)
    baseline = float(np.mean([data[d]['rmsf_target'].numpy().mean() for d in train]))
    return mean.astype(np.float32), std.astype(np.float32), baseline


def loss_parts(out, q, jitter: float, cov_weight: float, rmsf_weight: float):
    # Both outputs & targets are expressed in the fixed INITIAL design frame.
    # Compute covariance loss in initial nucleotide local frames. It equals the
    # global-frame Frobenius log-matrix loss under an orthogonal transform.
    target_local = q['cov_local_target']
    eye = torch.eye(3, device=target_local.device, dtype=target_local.dtype).unsqueeze(0)
    cov_log = covariance_logfrob_loss(out['local_covariances'].float(),
                                      target_local.float() + float(jitter) * eye)
    rmsf_mse = (out['rmsf'] - q['rmsf_target']).square().mean()
    combined = cov_weight * cov_log + rmsf_weight * rmsf_mse
    return combined, cov_log, rmsf_mse


def score_design(out, q) -> dict:
    pred_t = out['rmsf'].detach().float()
    y_t = q['rmsf_target'].float()
    delta = pred_t - y_t
    co = out['marginal_covariances'].float()
    target = q['cov_target'].float()
    fro = (co - target).square().sum((-2, -1)).sqrt().mean()
    pred = pred_t.cpu().numpy()
    y = y_t.cpu().numpy()
    n = len(y)
    count = max(1, int(np.ceil(0.2*n)))
    ascending = np.argsort(y, kind='stable')
    hi, lo = ascending[-count:], ascending[:count]
    # Rank correlation without requiring optional statistics dependencies.
    from scipy.stats import spearmanr
    rho = float(spearmanr(pred,y).statistic) if np.std(pred)>0 and np.std(y)>0 else 0.0
    return {'rmse_nm': float(delta.square().mean().sqrt()),
            'mae_nm': float(delta.abs().mean()),
            'bias_nm': float(delta.mean()),
            'spearman': rho,
            'top20_mae_nm': float(np.abs(pred[hi]-y[hi]).mean()),
            'top20_bias_nm': float((pred[hi]-y[hi]).mean()),
            'bottom20_mae_nm': float(np.abs(pred[lo]-y[lo]).mean()),
            'bottom20_bias_nm': float((pred[lo]-y[lo]).mean()),
            'std_ratio': float(np.std(pred) / max(np.std(y), 1e-12)),
            'cov_frobenius_nm2': float(fro)}


def evaluate(model, data, names, device, args):
    model.eval()
    per = []
    with torch.no_grad():
        for design in names:
            q = to_device(data[design], device)
            out = model(q['s'], q['R'], q['edges'], q['edge_features'])
            combined, covlog, rmsfmse = loss_parts(out, q, args.spd_jitter_nm2,
                                                   args.cov_loss_weight, args.rmsf_loss_weight)
            row = {'design': design, 'n': q['n'], 'loss': float(combined),
                   'cov_log_loss': float(covlog), 'rmsf_mse_nm2': float(rmsfmse)}
            row.update(score_design(out, q))
            per.append(row)
    macro = {k: float(np.mean([d[k] for d in per])) for k in
             ('loss','cov_log_loss','rmsf_mse_nm2','rmse_nm','mae_nm','bias_nm','spearman', 'top20_mae_nm', 'top20_bias_nm', 'bottom20_mae_nm', 'bottom20_bias_nm', 'std_ratio','cov_frobenius_nm2')}
    macro['num_designs'] = len(per)
    macro['num_nodes'] = int(sum(d['n'] for d in per))
    return macro, per


def write_csv(path, rows):
    if not rows:
        return
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    a = parse_args()
    if a.epochs <= 0 or a.patience <= 0 or a.lr <= 0 or a.spd_jitter_nm2 <= 0:
        raise ValueError('epochs/patience/lr/spd-jitter must be positive')
    if a.cov_loss_weight < 0 or a.rmsf_loss_weight < 0 or (a.cov_loss_weight+a.rmsf_loss_weight) == 0:
        raise ValueError('invalid loss weights')
    torch.set_num_threads(a.threads)
    random.seed(a.seed)
    np.random.seed(a.seed)
    torch.manual_seed(a.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(a.seed)
    device = torch.device('cuda' if (a.device == 'auto' and torch.cuda.is_available()) else
                          ('cpu' if a.device == 'auto' else a.device))
    root = a.project_root.resolve()
    inputs = at_root(root, a.inputs, DEFAULT_INPUT_REL)
    labels = at_root(root, a.labels, DEFAULT_LABEL_REL)
    split_path = at_root(root, a.split, DEFAULT_SPLIT_REL)
    historical = (root / 'experiments/talos97_rmsf_scalar/continuation20m_20261102/labels') \
        if a.audit_historical_rmsf or a.require_historical_rmsf_match else None
    split, data, manifest = prepare_dataset(root, split_path, inputs, labels,
                                            set(a.exclude_designs), a.skip_missing, historical, a.rmsf_tolerance)
    if a.require_historical_rmsf_match:
        for item in manifest['designs']:
            if item.get('historical_rmsf_agrees') is not True:
                raise ValueError(f'historical RMSF check failed: {item["design"]}: {item}')
    mean, std, baseline = normalize_training(data, split['train'])
    model = GaussianGNO(mean, std, baseline_rmsf_nm=baseline, width=a.width, hops=a.hops,
                        mode='anisotropic', edge_mode=a.edge_mode).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0)
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    config = {'width':a.width, 'hops':a.hops, 'edge_mode':a.edge_mode, 'mode':'anisotropic'}
    manifest.update({'model':'DNA Gaussian GNO, DynaProt-M-inspired (NOT original IPA network)',
                     'label_definition':'per-nucleotide temporal covariance, Kabsch-aligned, global design frame',
                     'input_reference':'initial.dat, topology row, SO(3) column local axes',
                     'units':{'rmsf':'nm', 'covariance':'nm^2'},
                     'paths':{'project_root':str(root),'inputs':str(inputs),'labels':str(labels),'split':str(split_path)},
                     'settings':vars(a) | {'project_root':str(root),'inputs':str(inputs), 'labels':str(labels),
                                         'split':str(split_path), 'out':str(out)}})
    # JSON-safe pathlib args
    manifest['settings'] = {k: str(v) if isinstance(v,Path) else v for k,v in manifest['settings'].items()}
    (out / 'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    if manifest['excluded_or_missing']:
        print('WARNING: modified split:', json.dumps(manifest['excluded_or_missing'],ensure_ascii=False), flush=True)
    print(f'training={len(split["train"])} validation={len(split["validation"])} device={device} baseline={baseline:.4f}nm',flush=True)
    best = math.inf
    best_epoch = 0
    history = []
    rng = np.random.default_rng(a.seed)
    t0 = time.time()
    for epoch in range(1, a.epochs + 1):
        model.train()
        train_losses = []
        for design in rng.permutation(split['train']):
            q = to_device(data[str(design)], device)
            optimizer.zero_grad(set_to_none=True)
            output = model(q['s'], q['R'], q['edges'], q['edge_features'])
            loss, _, _ = loss_parts(output, q, a.spd_jitter_nm2,
                                    a.cov_loss_weight, a.rmsf_loss_weight)
            if not torch.isfinite(loss):
                raise FloatingPointError(f'non-finite loss at epoch={epoch} design={design}')
            loss.backward()
            grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            if not torch.isfinite(grad_norm):
                raise FloatingPointError(f'non-finite gradient at epoch={epoch} design={design}')
            optimizer.step()
            train_losses.append(float(loss.detach()))
            del q, output, loss
        val, _ = evaluate(model, data, split['validation'], device, a)
        key = val['rmse_nm'] if a.select_by == 'rmse' else val['loss']
        improved = key < best - 1e-9
        if improved:
            best, best_epoch = key, epoch
            checkpoint = {'model_state': model.state_dict(), 'mean': torch.from_numpy(mean),
                          'std': torch.from_numpy(std), 'baseline_rmsf_nm': baseline,
                          'config':config, 'epoch':epoch, 'selection_metric':a.select_by,
                          'selection_value':best, 'val_metrics':val,
                          'train_designs':split['train'], 'validation_designs':split['validation'],
                          'rmsf_unit':'nm', 'covariance_unit':'nm^2', 'label_key':'covariance_q'}
            torch.save(checkpoint, out / 'best.pt')
        entry = {'epoch':epoch,'train_loss':float(np.mean(train_losses)),
                 'val_loss':val['loss'],'val_rmse_nm':val['rmse_nm'],'val_mae_nm':val['mae_nm'],
                 'val_cov_frobenius_nm2':val['cov_frobenius_nm2'], 'best_epoch':best_epoch,
                 'elapsed_sec':round(time.time()-t0,2)}
        history.append(entry)
        write_csv(out/'history.csv', history)
        if epoch == 1 or epoch % 5 == 0 or improved:
            print(entry,flush=True)
        if epoch - best_epoch >= a.patience:
            print(f'early stopping at epoch {epoch}',flush=True)
            break
    # Restore best and give honest per-design validation and training metrics.
    ck = torch.load(out/'best.pt', map_location='cpu', weights_only=True)
    model.load_state_dict(ck['model_state'])
    train_macro, train_rows = evaluate(model, data, split['train'], device, a)
    val_macro, val_rows = evaluate(model, data, split['validation'], device, a)
    write_csv(out/'train_per_design.csv', train_rows)
    write_csv(out/'validation_per_design.csv', val_rows)
    (out/'summary.json').write_text(json.dumps({'best_epoch': best_epoch,'select_by':a.select_by,
        'train_macro':train_macro,'validation_macro':val_macro,'selection_value':best},
        indent=2,ensure_ascii=False)+'\n', encoding='utf-8')
    if a.save_val_predictions:
        pred_root = out/'validation_predictions'
        pred_root.mkdir(exist_ok=True)
        model.eval()
        with torch.no_grad():
            for d in split['validation']:
                q = to_device(data[d], device)
                pr = model(q['s'],q['R'],q['edges'],q['edge_features'])
                np.savez_compressed(pred_root/f'{d}.npz',
                    rmsf_nm=pr['rmsf'].cpu().numpy(),
                    covariance_global_nm2=pr['marginal_covariances'].cpu().numpy(),
                    covariance_local_nm2=pr['local_covariances'].cpu().numpy(),
                    target_rmsf_nm=q['rmsf_target'].cpu().numpy(),
                    target_covariance_global_nm2=q['cov_target'].cpu().numpy())
    print(f'DONE: best epoch {best_epoch}, validation macro RMSE {val_macro["rmse_nm"]:.5f}nm, {out / "best.pt"}',flush=True)

if __name__ == '__main__':
    main()
