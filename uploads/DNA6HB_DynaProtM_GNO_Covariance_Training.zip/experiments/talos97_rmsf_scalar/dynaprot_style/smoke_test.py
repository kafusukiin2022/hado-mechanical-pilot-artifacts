"""End-to-end tests on synthetic 6HB-shaped data (no user's MD inputs needed)."""
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
import numpy as np
import torch
from model import GaussianGNO, load_input, covariance_logfrob_loss
from data_io import load_covariance


def example(seed=1):
    rng=np.random.default_rng(seed)
    n=12
    x=rng.normal(size=(n,3)).astype('float32')
    r=np.broadcast_to(np.eye(3,dtype=np.float32),(n,3,3)).copy()
    undirected=[(i,i+1,1) for i in range(n-1)]+[(i,i+6,2) for i in range(6)]+[(5,6,3)]
    ed=undirected+[(j,i,t) for i,j,t in undirected]
    return {'pos':x,'rotation':r,
            'node_features':rng.normal(size=(n,4)).astype('float32'),
            'edge_index':np.asarray([(i,j) for i,j,t in ed],dtype=np.int64).T,
            'edge_types':np.asarray([t for i,j,t in ed],dtype=np.int64),
            'domain_ids':np.array([0]*6+[1]*6,dtype=np.int64),
            'segment_edge_index':np.asarray([[0,1],[1,0]],dtype=np.int64)}


def true_cov(n=12,shift=0.0):
    a=np.zeros((n,3,3),dtype=np.float32)
    a[:,0,0]=0.025+shift
    a[:,1,1]=0.040+shift
    a[:,2,2]=0.055+shift
    a[:,0,1]=a[:,1,0]=0.002
    a[:,0,2]=a[:,2,0]=0.001
    return a


def run():
    torch.set_num_threads(2)
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp); base=Path(__file__).resolve().parent
        raw=example(); input_path=tmp/'input.npz';np.savez_compressed(input_path,**raw)
        q=load_input(input_path)
        mean=q['s'].mean(0).numpy();std=q['s'].std(0).clamp_min(0.01).numpy()
        model=GaussianGNO(mean,std,width=32,hops=2,mode='anisotropic')
        pr=model(q['s'],q['R'],q['edges'],q['edge_features'])
        assert pr['marginal_covariances'].shape==(12,3,3)
        assert pr['local_covariances'].shape==(12,3,3)
        assert bool((torch.linalg.eigvalsh(pr['marginal_covariances'])>0).all())
        assert torch.allclose(pr['rmsf']**2,torch.diagonal(pr['marginal_covariances'],dim1=-2,dim2=-1).sum(-1),atol=1e-6)
        loss=covariance_logfrob_loss(pr['local_covariances'],torch.eye(3)[None].repeat(12,1,1)*.05)
        loss.backward()
        assert torch.isfinite(model.head[-1].bias.grad).all()
        # Rotating the whole initial design rotates GLOBAL covariance and
        # does not change local-frame covariance or RMSF.
        Q=np.array([[0.,-1.,0.],[1.,0.,0.],[0.,0.,1.]],dtype=np.float32)
        rot={k:v.copy() for k,v in raw.items()}
        rot['pos']=raw['pos']@Q.T
        rot['rotation']=np.einsum('ij,njk->nik',Q,raw['rotation'])
        rotpath=tmp/'rot.npz';np.savez_compressed(rotpath,**rot)
        qq=load_input(rotpath)
        out2=model(qq['s'],qq['R'],qq['edges'],qq['edge_features'])
        expect=torch.tensor(Q)@pr['marginal_covariances'].detach()@torch.tensor(Q).T
        assert torch.allclose(out2['marginal_covariances'],expect,atol=3e-4,rtol=3e-4)
        assert torch.allclose(out2['local_covariances'],pr['local_covariances'].detach(),atol=3e-4,rtol=3e-4)
        print('geometry, SPD, trace-RMSF, local frame, rotation-equivariance, backward: PASS')
        # Simulates the exact nested covariance_q label and initial input schema.
        project=tmp/'project'
        inputs=project/'experiments/talos97_endpoint_v1/data/inputs'
        labels=project/'outputs/talos97_directional_persistence_20261104/labels'
        inputs.mkdir(parents=True)
        ids=['6hb_mock001','6hb_mock002','6hb_mock003']
        for i,d in enumerate(ids):
            np.savez_compressed(inputs/f'{d}.npz',**example(i+10))
            dest=labels/d;dest.mkdir(parents=True)
            np.savez_compressed(dest/'statistics.npz',covariance_q=true_cov(12,0.002*i))
            cov=load_covariance(dest/'statistics.npz',12)
            assert np.isclose(cov['rmsf'][0]**2,np.trace(true_cov(12,.002*i)[0]))
        split=project/'split.json';split.write_text(json.dumps({'train':ids[:2],'validation':ids[2:]}))
        audit=project/'audit.csv'
        subprocess.run([sys.executable,str(base/'audit.py'),'--project-root',str(project),
                        '--split',str(split),'--report',str(audit)],
                       check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        assert audit.is_file()
        output=project/'training_run'
        cmd=[sys.executable,str(base/'train.py'),'--project-root',str(project),
             '--split',str(split),'--out',str(output),'--epochs','2','--patience','2',
             '--width','32','--hops','2','--threads','2','--device','cpu']
        subprocess.run(cmd,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        assert (output/'best.pt').is_file()
        assert (output/'validation_per_design.csv').is_file()
        assert (output/'manifest.json').is_file()
        checkpoint=torch.load(output/'best.pt',weights_only=True,map_location='cpu')
        assert checkpoint['label_key']=='covariance_q' and checkpoint['config']['mode']=='anisotropic'
        prediction=project/'prediction'
        subprocess.run([sys.executable,str(base/'predict.py'),
                        '--checkpoint',str(output/'best.pt'),'--input',str(inputs/f'{ids[2]}.npz'),
                        '--out',str(prediction),'--device','cpu'],
                       check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        with np.load(prediction/'prediction.npz') as z:
            c=z['covariance_global_nm2'];cl=z['covariance_local_nm2'];r=z['rmsf_nm']
            assert c.shape==cl.shape==(12,3,3) and r.shape==(12,)
            assert np.allclose(r**2,np.trace(c,axis1=1,axis2=2),rtol=1e-4,atol=1e-5)
        print('nested covariance_q train, checkpoint, val metrics, predict: PASS')
    print('ALL TESTS PASSED — synthetic fixture, NOT real 6HB validation.')

if __name__=='__main__':run()
