"""Convert aligned 3D MD trajectories to one marginal covariance per DNA node.

IMPORTANT: trajectory arrays MUST already be unwrapped across periodic boundaries.
No PBC unwrapping is performed here. Output covariances in nm^2.
"""
import argparse, json
from pathlib import Path
import numpy as np


def aligned_to_reference(X, reference):
    """Rigid Kabsch superposition: X and reference are [N,3] row coordinates."""
    center_x = X.mean(axis=0)
    center_y = reference.mean(axis=0)
    H = (X - center_x).T @ (reference - center_y)
    U, _, Vt = np.linalg.svd(H)
    D = np.eye(3)
    D[-1, -1] = np.linalg.det(U @ Vt)
    R = U @ D @ Vt
    return (X - center_x) @ R + center_y


def load_traj(path, key):
    if path.suffix == '.npy':
        return np.load(path, allow_pickle=False)
    with np.load(path, allow_pickle=False) as z:
        return z[key]


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input', type=Path, required=True, help='original design input NPZ with pos [N,3]')
    p.add_argument('--trajectories', type=Path, nargs='+', required=True,
                   help='.npy [T,N,3] or .npz with --key')
    p.add_argument('--key', default='positions')
    p.add_argument('--scale-to-nm', type=float, required=True,
                   help='explicit conversion factor from raw coordinate unit to nm')
    p.add_argument('--already-aligned', action='store_true')
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    if args.scale_to_nm <= 0:
        raise ValueError('scale-to-nm must be positive')
    with np.load(args.input, allow_pickle=False) as raw:
        ref = np.asarray(raw['pos'], dtype=np.float64) * args.scale_to_nm
    covs = []
    total_frames = 0
    all_frames = []
    for path in args.trajectories:
        traj = np.asarray(load_traj(path, args.key), dtype=np.float64)
        if traj.ndim != 3 or traj.shape[1:] != ref.shape or len(traj) < 2:
            raise ValueError(f'expected [T,{len(ref)},3], T>=2 in {path}')
        if not np.isfinite(traj).all():
            raise ValueError(f'nonfinite trajectory coordinates in {path}')
        traj = traj * args.scale_to_nm
        if not args.already_aligned:
            traj = np.stack([aligned_to_reference(frame, ref) for frame in traj])
        # Center each replica independently; average replica covariance estimates.
        # This matches the notion of local fluctuations rather than drift among replicates.
        d = traj - traj.mean(axis=0, keepdims=True)
        cov = np.einsum('tni,tnj->nij', d, d) / len(d)
        covs.append(cov)
        total_frames += len(traj)
    marginal_cov = np.mean(covs, axis=0).astype(np.float32)
    rmsf = np.sqrt(np.trace(marginal_cov, axis1=-2, axis2=-1)).astype(np.float32)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.out, marginal_covariances=marginal_cov, rmsf=rmsf)
    meta = {'source': [str(f) for f in args.trajectories], 'num_replicates': len(covs),
            'total_frames': total_frames, 'alignment': ('already_aligned' if args.already_aligned else 'Kabsch_to_reference'),
            'unwrapped_pbc_required': True, 'scale_to_nm': args.scale_to_nm,
            'node_type': 'DNA_nucleotide', 'covariance_unit': 'nm^2'}
    args.out.with_suffix('.json').write_text(json.dumps(meta, indent=2, ensure_ascii=False) + '\n')
    print(f'wrote {len(rmsf)} nodes to {args.out} ({total_frames} frames)')

if __name__ == '__main__':
    main()
