"""Non-training audit of available statistics.npz covariance_q and original splits."""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
import numpy as np
from data_io import DEFAULT_INPUT_REL, DEFAULT_LABEL_REL, DEFAULT_SPLIT_REL, load_split, load_covariance


def at_root(root, path, rel):
    p = path if path is not None else rel
    return p if p.is_absolute() else root / p


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project-root',type=Path,required=True)
    p.add_argument('--inputs',type=Path)
    p.add_argument('--labels',type=Path)
    p.add_argument('--split',type=Path)
    p.add_argument('--report',type=Path)
    a=p.parse_args()
    root=a.project_root.resolve()
    inputs=at_root(root,a.inputs,DEFAULT_INPUT_REL)
    labels=at_root(root,a.labels,DEFAULT_LABEL_REL)
    sp=at_root(root,a.split,DEFAULT_SPLIT_REL)
    split=load_split(sp)
    folders={x.name for x in labels.iterdir() if x.is_dir() and (x/'statistics.npz').is_file()}
    rows=[]
    for grp in ('train','validation'):
        for d in split[grp]:
            ip=inputs/f'{d}.npz'; lab=labels/d/'statistics.npz'
            row={'design':d,'split':grp,'input_exists':ip.is_file(),
                 'label_exists':lab.is_file(),'node_count':'','status':'missing'}
            if ip.is_file() and lab.is_file():
                try:
                    with np.load(ip,allow_pickle=False) as z:
                        n=len(z['pos'])
                    c=load_covariance(lab,n)
                    row.update(node_count=n, status='PASS',
                               min_eigenvalue_nm2=c['min_eig_nm2'],max_asymmetry_nm2=c['max_asym_nm2'])
                except Exception as e:
                    row.update(status='FAIL',error=str(e))
            rows.append(row)
    summary={'covariance_label_designs_total':len(folders),
             'split_total':{g:len(split[g]) for g in split},
             'split_passing':{g:sum(r['status']=='PASS' and r['split']==g for r in rows)
                              for g in split},
             'missing_split_designs':[r['design'] for r in rows if r['status']=='missing'],
             'failed_designs':[{k:r[k] for k in ('design','error')} for r in rows if r['status']=='FAIL'],
             'label_designs_outside_split':sorted(folders-set(split['train']+split['validation']))}
    print(json.dumps(summary,indent=2,ensure_ascii=False))
    if a.report:
        a.report.parent.mkdir(parents=True,exist_ok=True)
        with a.report.open('w',newline='',encoding='utf-8') as f:
            cols=['design','split','input_exists','label_exists','node_count','status',
                  'min_eigenvalue_nm2','max_asymmetry_nm2','error']
            writer=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore')
            writer.writeheader(); writer.writerows(rows)
        print('audit report:',a.report)
    if summary['failed_designs']:
        raise SystemExit('QC failed: see report')

if __name__=='__main__':main()
