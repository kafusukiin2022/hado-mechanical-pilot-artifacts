"""DynaProt-inspired marginal covariance GNO for the original 6HB DNA nodes.

Not an implementation of DynaProt's IPA model. This reuses the user's BasisNet
input geometry and the typed-edge diffusion idea of their existing GNO, but
replaces the scalar RMSF readout with an SPD covariance readout.
"""
from __future__ import annotations

import sys
from pathlib import Path
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

EXP = Path(__file__).resolve().parents[1]
if str(EXP) not in sys.path:
    sys.path.insert(0, str(EXP))
from backbone import BasisNet, geometry  # noqa: E402


def graph_from_input(raw, edge_mode="geometry"):
    """Construct a directed, label-free topology graph and 7-d edge features.

    Matches the GNO's use of edge types 1,2,3 and distance-related channels.
    Returned tensors/arrays refer to original input coordinate units.
    """
    if edge_mode not in ("geometry", "topology"):
        raise ValueError("edge_mode must be geometry or topology")
    pos = np.asarray(raw["pos"], dtype=np.float32)
    original = np.asarray(raw["edge_index"], dtype=np.int64)
    types = np.asarray(raw["edge_types"], dtype=np.int64)
    if original.ndim != 2 or original.shape[0] != 2 or len(types) != original.shape[1]:
        raise ValueError("edge_index must be [2,E], edge_types [E]")
    relations = {}
    for (i, j), t in zip(original.T, types):
        if int(i) == int(j) or int(t) not in (1, 2, 3):
            continue
        a, b = sorted((int(i), int(j)))
        relations.setdefault((a, b), set()).add(int(t))
    if relations:
        pairs = np.asarray(sorted(relations), dtype=np.int64)
        directed = np.concatenate((pairs, pairs[:, ::-1]), axis=0)
    else:
        directed = np.empty((0, 2), dtype=np.int64)
    edges = directed.T.copy()
    f = np.zeros((len(directed), 7), dtype=np.float32)
    for k, (i, j) in enumerate(directed):
        for t in relations[(min(int(i), int(j)), max(int(i), int(j)))]:
            f[k, t - 1] = 1.0
    f[:, 3] = 1.0
    if len(directed) and edge_mode == "geometry":
        d = np.linalg.norm(pos[edges[1]] - pos[edges[0]], axis=-1)
        f[:, 4] = np.log1p(d)
        f[:, 5] = np.exp(-d)
        f[:, 6] = 1.0 / (1.0 + d)
    return edges, f


def load_input(npz_path):
    with np.load(npz_path, allow_pickle=False) as z:
        raw = {k: z[k] for k in z.files}
    s, _B, R = geometry(raw, multiscale=True)
    edges, feat = graph_from_input(raw)
    n = len(s)
    if np.asarray(raw["pos"]).shape != (n, 3) or R.shape != (n, 3, 3):
        raise ValueError("invalid position/rotation shapes")
    if not np.isfinite(s).all() or not np.isfinite(R).all():
        raise ValueError("nonfinite input features")
    return {"s": torch.from_numpy(s), "R": torch.from_numpy(R),
            "edges": torch.from_numpy(edges), "edge_features": torch.from_numpy(feat),
            "pos": np.asarray(raw["pos"], dtype=np.float32).copy(),
            "n": n}


def covariance_from_cholesky_params(a, mode="anisotropic", eps=1e-5):
    """Returns [N,3,3] in local coordinates; output has RMSF units nm."""
    n = a.shape[0]
    if mode == "isotropic":
        # RMSF = sqrt(3)*sigma (nm). 1 scalar/node, no spurious anisotropy.
        sig = F.softplus(a[:, 0]) + eps
        return torch.diag_embed(sig.unsqueeze(-1).expand(n, 3).square())
    if mode != "anisotropic" or a.shape[-1] != 6:
        raise ValueError("expected six parameters for anisotropic covariance")
    L = a.new_zeros((n, 3, 3))
    L[:, 0, 0] = F.softplus(a[:, 0]) + eps
    L[:, 1, 0] = a[:, 1]
    L[:, 1, 1] = F.softplus(a[:, 2]) + eps
    L[:, 2, 0] = a[:, 3]
    L[:, 2, 1] = a[:, 4]
    L[:, 2, 2] = F.softplus(a[:, 5]) + eps
    return L @ L.transpose(-2, -1)


class GaussianGNO(nn.Module):
    """Typed edge diffusion + local-to-global SPD covariance, in nm^2.

    `isotropic`: can train against scalar RMSF only, and is identifiable.
    `anisotropic`: requires aligned 3D MD covariance targets [N,3,3].
    """
    def __init__(self, mean, std, baseline_rmsf_nm=0.3,
                 width=128, hops=8, mode="isotropic", edge_mode="geometry"):
        super().__init__()
        if hops not in (2, 4, 8, 16):
            raise ValueError("hops must be 2,4,8,16")
        if mode not in ("isotropic", "anisotropic"):
            raise ValueError("mode must be isotropic or anisotropic")
        self.mode, self.hops, self.edge_mode = mode, hops, edge_mode
        self.width = int(width)
        self.baseline_rmsf_nm = float(baseline_rmsf_nm)
        self.base = BasisNet(mean, std, width=width, variant="frame")
        hdim = 3 * width
        self.lift = nn.Linear(hdim, 16)
        self.kernel = nn.Sequential(nn.Linear(7, 32), nn.SiLU(), nn.Linear(32, 16))
        self.sample_steps = [0] + [k for k in (1, 2, 4, 8, 16) if k <= hops]
        self.scale = nn.Linear(hdim, len(self.sample_steps))
        self.head = nn.Sequential(nn.Linear(hdim + 32, width), nn.SiLU(),
                                  nn.Linear(width, 1 if mode == "isotropic" else 6))
        nn.init.zeros_(self.head[-1].weight)
        rmsf = max(float(baseline_rmsf_nm), 1e-3)
        sigma = rmsf / np.sqrt(3)
        raw = float(np.log(np.expm1(sigma)))
        if mode == "isotropic":
            nn.init.constant_(self.head[-1].bias, raw)
        else:
            with torch.no_grad():
                self.head[-1].bias[:] = self.head[-1].bias.new_tensor([raw, 0, raw, 0, 0, raw])

    def forward(self, s, R, edges, edge_features):
        """s [N,F], R [N,3,3] (column frames), edges [2,E], feats [E,7]."""
        _layers, h = self.base.encode(s)
        srcfield = self.lift(h)
        src, dst = edges
        if src.numel():
            feat = edge_features
            if self.edge_mode == "topology":
                feat = edge_features.clone()
                feat[:, 4:] = 0.0
            kernel = F.softplus(self.kernel(feat)) + 1e-3
            denom = torch.zeros_like(srcfield).index_add(0, dst, kernel).clamp_min(1e-8)
        else:
            kernel = edge_features.new_zeros((0, 16))
            denom = srcfield.new_ones(srcfield.shape)
        cur = srcfield
        snapshots = [srcfield]
        for step in range(1, self.hops + 1):
            nex = torch.zeros_like(srcfield).index_add(0, dst, cur[src] * kernel) / denom
            cur = 0.2 * srcfield + 0.8 * nex
            if step in self.sample_steps:
                snapshots.append(cur)
        weights = torch.softmax(self.scale(h), dim=-1)
        aggregate = torch.stack(snapshots, dim=1)
        diffused = (aggregate * weights.unsqueeze(-1)).sum(dim=1)
        params = self.head(torch.cat([h, srcfield, diffused], dim=-1))
        local_cov = covariance_from_cholesky_params(params, mode=self.mode)
        # Input R columns are the local basis; rotates covariances covariantly.
        cov = R @ local_cov @ R.transpose(-2, -1)
        rmsf = torch.sqrt(torch.diagonal(cov, dim1=-2, dim2=-1).sum(-1).clamp_min(1e-12))
        return {"marginal_covariances": cov, "local_covariances": local_cov, "rmsf": rmsf}


class _StableLogSPD(torch.autograd.Function):
    """Symmetric matrix log with stable Frechet gradients for repeated eigenvalues.

    torch.linalg.eigh's standard eigenvector backward can produce NaNs when
    an initially isotropic covariance has repeated eigenvalues. For a matrix
    function log(A), the divided-difference Frechet derivative stays finite.
    """
    @staticmethod
    def forward(ctx, m):
        symmetric = 0.5 * (m + m.transpose(-2, -1))
        values, vectors = torch.linalg.eigh(symmetric)
        values = values.clamp_min(1e-9)
        ctx.save_for_backward(values, vectors)
        return (vectors * values.log().unsqueeze(-2)) @ vectors.transpose(-2, -1)

    @staticmethod
    def backward(ctx, grad_output):
        values, vectors = ctx.saved_tensors
        logvalues = values.log()
        denominator = values.unsqueeze(-1) - values.unsqueeze(-2)
        numerator = logvalues.unsqueeze(-1) - logvalues.unsqueeze(-2)
        tol = 1e-6 * torch.maximum(values.unsqueeze(-1), values.unsqueeze(-2))
        is_near = denominator.abs() <= tol
        safe_diff = torch.where(is_near, torch.ones_like(denominator), denominator)
        divided = torch.where(is_near,
                              1.0 / (0.5 * (values.unsqueeze(-1) + values.unsqueeze(-2))),
                              numerator / safe_diff)
        rotated_grad = vectors.transpose(-2, -1) @ grad_output @ vectors
        rotated_grad = 0.5 * (rotated_grad + rotated_grad.transpose(-2, -1))
        result = vectors @ (divided * rotated_grad) @ vectors.transpose(-2, -1)
        return 0.5 * (result + result.transpose(-2, -1))


def log_spd(m):
    return _StableLogSPD.apply(m)


def covariance_logfrob_loss(pred_cov, target_cov):
    return (log_spd(pred_cov) - log_spd(target_cov)).square().sum((-1, -2)).mean()
