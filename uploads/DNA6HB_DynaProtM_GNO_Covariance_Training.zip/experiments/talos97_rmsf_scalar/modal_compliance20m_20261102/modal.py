"""Input-only rotation/translation-of-blocks elastic-network descriptor.

Arbitrary stiffness units: this is not a calibrated oxDNA Hessian or RMSF.
Only initial coordinates, fixed domains and source-only typed edges are read.
"""
import numpy as np
from scipy.linalg import eigh, qr

CONFIG = dict(blocks='existing (virtual_helix, axial_index//16)',
              spring_weights={'0': .1, '1': 10., '2': 5., '3': 10.},
              modes=[8, 16, 32], zero_relative_tolerance=1e-9,
              mass='unit per nucleotide plus intrinsic rotational inertia 0.1 ox^2 per nucleotide',
              twohop='excluded', coincident='zero-rest isotropic spring',
              bonded_beam_transverse_ratio=.1, bonded_beam_angular_ratio=.1,
              thermal_scale='none; arbitrary compliance units')
NAMES = [f'modal_{kind}_{k}' for k in CONFIG['modes']
         for kind in ('log_compliance', 'log_relative_compliance')]


def skew(v):
    x, y, z = v
    return np.array([[0., -z, y], [z, 0., -x], [-y, x, 0.]])


def system(raw):
    x = np.asarray(raw['pos'], float) * float(raw['scale'])
    x -= x.mean(0)
    _, domain = np.unique(raw['domain_ids'], return_inverse=True)
    count = np.bincount(domain)
    centers = np.stack([np.bincount(domain, weights=x[:, a]) / count
                        for a in range(3)], axis=1)
    offsets = x - centers[domain]
    basis = np.stack([np.concatenate([np.eye(3), -skew(r)], axis=1) for r in offsets])
    blocks, angular, whitening, indices, columns = [], [], [], [], 0
    for d in range(len(count)):
        ids = np.flatnonzero(domain == d)
        b = basis[ids]
        g = np.einsum('nai,naj->ij', b, b)
        g[3:, 3:] += len(ids) * .1 * np.eye(3)
        w, u = eigh(g)
        good = w > max(w.max(), 1.) * 1e-12
        whiten = u[:, good] / np.sqrt(w[good])
        blocks.append(np.einsum('nai,ij->naj', b, whiten))
        angular.append(whiten[3:])
        whitening.append(whiten)
        indices.append(np.arange(columns, columns + good.sum()))
        columns += int(good.sum())
    h = np.zeros((columns, columns))
    # Select one undirected spring per nucleotide pair. Spatial edges can be
    # asymmetric; accept either direction without double-counting reciprocity.
    edges = {}
    for (i, j), typ in zip(np.asarray(raw['edge_index']).T, raw['edge_types']):
        if str(int(typ)) not in CONFIG['spring_weights'] or i == j:
            continue
        key = (min(int(i), int(j)), max(int(i), int(j)))
        weight = CONFIG['spring_weights'][str(int(typ))]
        edges[key] = max(edges.get(key, 0.), weight)
    local = np.zeros(len(x), int)
    for d in range(len(count)):
        local[domain == d] = np.arange(count[d])
    used = 0
    for (i, j), weight in edges.items():
        di, dj = domain[i], domain[j]
        if di == dj:
            continue
        r = x[j] - x[i]
        length = np.linalg.norm(r)
        ix = np.r_[indices[di], indices[dj]]
        if length < 1e-10:
            # Some source designs put crossover endpoints at exactly the same
            # position. A zero-rest vector spring has a well-defined Hessian
            # and still annihilates every global rigid motion at this point.
            v = np.concatenate([-blocks[di][local[i]], blocks[dj][local[j]]], axis=1)
            stiffness = v.T @ v
        else:
            unit = r / length
            a = -(unit @ blocks[di][local[i]])
            b = unit @ blocks[dj][local[j]]
            v = np.r_[a, b]
            stiffness = np.outer(v, v)
        h[np.ix_(ix, ix)] += weight * stiffness
        if weight == 10.:
            # Bonded beam regularization supplies bending/torsion stiffness
            # missing from a central-force-only network. Global rotation has
            # d_j-d_i = omega cross r and omega_j=omega_i, hence zero energy.
            beam = np.concatenate([-blocks[di][local[i]] + .5 * skew(r) @ angular[di],
                                   blocks[dj][local[j]] + .5 * skew(r) @ angular[dj]], axis=1)
            twist = np.concatenate([-angular[di], angular[dj]], axis=1)
            h[np.ix_(ix, ix)] += weight * (.1 * beam.T @ beam + .1 * twist.T @ twist)
        used += 1
    # Represent the six whole-design rigid motions in mass-whitened space.
    rigid = np.zeros((columns, 6))
    for d in range(len(count)):
        target = np.block([[np.eye(3), -skew(centers[d])], [np.zeros((3, 3)), np.eye(3)]])
        rigid[indices[d]] = np.linalg.solve(whitening[d], target)
    q, r = qr(rigid, mode='economic')
    if np.min(np.abs(np.diag(r))) < 1e-8:
        raise ValueError('whole-design rigid motion rank < 6')
    return h, q, blocks, indices, domain, local, used


def compute(raw, details=False):
    h, rigid, blocks, indices, domain, local, used = system(raw)
    scale = max(float(np.abs(h).sum(1).max()), 1.)
    rigid_error = float(np.linalg.norm(h @ rigid) / scale)
    if rigid_error > 1e-8:
        raise ValueError('rigid motion is not in Hessian nullspace')
    # Lift exactly the six global null modes above the physical spectrum.
    lifted = h + (2 * scale) * (rigid @ rigid.T)
    upper = min(47, len(h) - 7)
    values, vectors = eigh(lifted, subset_by_index=[0, upper])
    tol = CONFIG['zero_relative_tolerance'] * scale
    if values[0] <= tol:
        raise ValueError('extra floppy/negative mode; do not silently truncate: %g' % values[0])
    if len(values) < 33:
        raise ValueError('too few physical modes')
    u = np.empty((len(domain), 3, len(values)))
    for d in range(len(blocks)):
        mask = domain == d
        u[mask] = np.einsum('nai,ik->nak', blocks[d], vectors[indices[d]])
    power = (u ** 2).sum(1)
    features, actual = [], {}
    for k in CONFIG['modes']:
        # Include a complete near-degenerate eigenspace at each cutoff.
        stop = k
        while stop < len(values) and abs(values[stop] - values[k-1]) <= 1e-7 * max(values[k-1], tol):
            stop += 1
        if stop == len(values):
            raise ValueError('mode cutoff reaches eigensolver boundary')
        compliance = (power[:, :stop] / values[:stop]).sum(1)
        features += [np.log1p(compliance), np.log(np.maximum(compliance / compliance.mean(), 1e-12))]
        actual[str(k)] = stop
    out = np.stack(features, axis=1).astype(np.float32)
    residual = np.linalg.norm(lifted @ vectors - vectors * values, axis=0)
    relative_residual = float(np.max(residual / np.maximum(values, tol)))
    if not np.isfinite(out).all() or relative_residual > .01:
        raise ValueError('nonfinite features or unreliable eigensolver residual')
    info = dict(nodes=len(domain), blocks=len(blocks), degrees_of_freedom=len(h),
                interblock_springs=used, eigenvalues=values.tolist(), actual_modes=actual,
                rigid_null_residual=rigid_error, max_relative_eigen_residual=relative_residual,
                stiffness_scale=scale, extra_null_modes=0)
    return (out, info, (h, rigid, u, values)) if details else (out, info)
