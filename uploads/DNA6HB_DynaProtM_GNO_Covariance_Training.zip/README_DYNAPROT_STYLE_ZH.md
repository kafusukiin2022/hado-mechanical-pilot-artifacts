# 旧版说明

本文件对应早期只有标量 RMSF 标签的增量改造。**当前推荐使用根目录的 `README_DYNAPROT_COVARIANCE_FULL_ZH.md`**，其中已适配 `outputs/talos97_directional_persistence_20261104/labels/<design>/statistics.npz` 的 `covariance_q`。请勿直接照旧版命令训练。
