# DNA6HB DynaProt-M 风格 Gaussian GNO：服务器配置

本项目基于用户提供的原 GNO 源码。**不是官方 DynaProt 的 IPA 网络复现**，而是通过局部 `3×3` 协方差 + Cholesky 参数化实现的 DNA 核苷酸预测模型。压缩包只有源代码，**不含真实 NPZ 输入、MD 协方差标签与训练权重**。

## 1. Python / CUDA 环境

建议使用 Linux + Python 3.10 或更新版，单独创建虚拟环境（任选一套）：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
```

首先按服务器 NVIDIA 驱动和 CUDA 配置安装合适版本的 **PyTorch**，参考官方安装指令：https://pytorch.org/get-started/locally/ 。然后执行：

```bash
pip install -r requirements_dynaprot.txt
python -c "import torch; print(torch.__version__); print('CUDA:', torch.cuda.is_available())"
```

注意：`requirements_dynaprot.txt` 中 `torch>=2.1` 不固定 CUDA 构建，**仅运行 pip install 不保证有 GPU 支持**。NumPy 和 SciPy 为其它必要依赖。

## 2. 修改服务器配置（仅启动脚本使用）

```bash
cp .env.example .env
nano .env
```

必需修改：

| 变量 | 含义 | 示例 |
|---|---|---|
| `PROJECT_ROOT` | 服务器上**真实**完整数据工程根目录 | `/data/dna6hb` |
| `INPUTS_DIR` | 初始结构 NPZ 输入目录 | `$PROJECT_ROOT/experiments/talos97_endpoint_v1/data/inputs` |
| `LABELS_DIR` | 设计目录下面放 `statistics.npz` 的根目录 | `$PROJECT_ROOT/outputs/talos97_directional_persistence_20261104/labels` |
| `SPLIT_FILE` | 设计级 train/validation 划分 JSON | `$PROJECT_ROOT/experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/effective_split.json` |
| `RESULTS_DIR` | checkpoint、日志、预测结果输出目录 | `$PROJECT_ROOT/results/dynaprot_m_seed11` |

`INPUTS_DIR`、`LABELS_DIR` 和 `SPLIT_FILE` 的默认值依赖原工程文件层级。如果你的真实数据位置不同，就直接写**绝对路径**。

不必改（视环境调整）：

- `PYTHON_BIN=python`：先激活 venv/conda，或改成服务器上的 Python 绝对路径。
- `DEVICE=auto`：自动优先 CUDA；也可设 `cuda`, `cuda:0`, `cpu`。
- `CUDA_VISIBLE_DEVICES`：可选；不写则使用进程可见的 GPU；`"0"` 仅让 CUDA 看见宿主机 GPU 0，此时程序内仍用 `cuda:0`。
- `OMP_NUM_THREADS`：可选 CPU 线程数，默认 2。
- `EPOCHS` / `PATIENCE` / `LR` / `WIDTH` / `HOPS` / `EDGE_MODE` / `SEED`：训练超参，可保留默认值。
- `SKIP_MISSING=0`：默认对缺失输入/标签报错；设为 1 则丢弃缺失设计（**可能改变验证集，需审慎**）。
- `SAVE_VAL_PREDICTIONS=1`：保存每个验证设计的预测。

**关键说明：** 以上 `.env` 变量只由 `scripts/*.sh` 启动脚本读取，原生的 `train.py` / `predict.py` **不会自动读取 `.env`**。如你直接运行 Python，仍需传 `--project-root`、`--labels`、`--inputs`、`--split`、`--out` 等 CLI 参数；它们不需要单独设置为系统变量。

## 3. 实际数据结构（不随压缩包提供）

```text
/data/dna6hb/
├── experiments/talos97_endpoint_v1/data/inputs/6hb_001.npz
├── experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/effective_split.json
└── outputs/talos97_directional_persistence_20261104/labels/6hb_001/statistics.npz
```

初始 NPZ 需要包含原 GNO 输入的 `pos`、`rotation`、`node_features`、`edge_index`、`edge_types` 等实际特征字段。标签 NPZ 必须包含 `covariance_q`，维度 `(N,3,3)`，单位 **nm²**，节点按 oxDNA topology 行号排列。训练用局部协方差监督，推理只读初始 NPZ，不需要 MD 轨迹。

## 4. 从解压目录执行

```bash
# 代码自测（不依赖你的真实数据）
python experiments/talos97_rmsf_scalar/dynaprot_style/smoke_test.py

# 审计真实标签、划分、协方差形状和 PSD
bash scripts/run_audit_server.sh

# 训练：读取 .env，默认排除 6hb_024、6hb_051
bash scripts/run_train_server.sh

# 训练完成后，使用一个新设计的初始结构推理
bash scripts/run_predict_server.sh 6hb_100
```

如果训练时报缺少设计，先查看 `audit.csv` 和终端输出。尽量保持原始 train/validation 划分；仅在接受验证设计列表变化时才设置 `SKIP_MISSING=1`。

## 5. 可选：不通过 .env 直接调用

```bash
python experiments/talos97_rmsf_scalar/dynaprot_style/train.py \
  --project-root /data/dna6hb \
  --inputs /data/dna6hb/experiments/talos97_endpoint_v1/data/inputs \
  --labels /data/dna6hb/outputs/talos97_directional_persistence_20261104/labels \
  --split /data/dna6hb/experiments/talos97_rmsf_scalar/covariance_aux20m_20261102/effective_split.json \
  --out /data/dna6hb/results/dynaprot_m_seed11 \
  --device auto
```

注意 `.env` / shell 变量不能改变模型预期字段 `covariance_q` 的名字，也不能把纳米平方标签重复放缩。若目录包含多个设计，模型会在训练阶段逐个搬运至 GPU；是否适应显存依赖结构大小与图边数。
