# RMSF local模型基本代码

历史gno_rmse_20261112 seed11/local，最佳epoch55。17设计排除009后处理宏RMSE0.314253nm；checkpoint当时按包含009的18设计选择。

本包仅包含7个Python源文件、训练配置和数据拆分。保留原工程相对路径。不含权重、数据、标签、缓存、预测或训练日志。依赖Python、numpy、scipy、torch。

模型类在gno_rmse_20261112/run.py的GNOModel；基础编码器backbone.py的BasisNet；层次模型rod_hierarchical/model.py的RodHierarchicalRMSF；训练入口同run.py；特征构造在posthoc_diagnostic/analyze_mechanical_candidates.py和modal_compliance20m_20261102/modal.py。

原训练入口：FUNGUS_ARM=local GNO_SEED=11 python experiments/talos97_rmsf_scalar/gno_rmse_20261112/run.py。
原脚本依赖原工程的数据和缓存，且特征模块在导入时读取历史结果配置。因此这是原始代码摘录包，单独解压后不能直接训练或推理；须配合原工程数据。未改写原代码。
