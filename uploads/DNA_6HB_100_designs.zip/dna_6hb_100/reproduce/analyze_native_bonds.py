from pathlib import Path
import json,subprocess,numpy as np,sys
ROOT=Path(__file__).resolve().parents[1];EXE=ROOT/'software/bin/DNAnalysis'

def analyze(folder):
    folder=Path(folder).resolve();pairs=[tuple(map(int,x.split())) for x in (folder/'designed_pairs.txt').read_text().splitlines() if x.strip()]
    (folder/'native_bonds.op').write_text('{\norder_parameter = bond\nname = all_native_bonds\n'+''.join(f'pair{i} = {a}, {b}\n' for i,(a,b) in enumerate(pairs,1))+'}\n')
    trajectory=folder/'short_md.trajectory.dat'
    text=trajectory.read_text();headers=[int(line.split('=')[1]) for line in text.splitlines() if line.startswith('t =')]
    source=trajectory.name
    appended_final=not headers or headers[-1]!=5000
    if appended_final:
        source='native_hb_source.dat';(folder/source).write_text(text.rstrip()+'\n'+(folder/'short_md.last.dat').read_text())
    inp='''interaction_type = DNA2
salt_concentration = 0.5
T = 300K
topology = design.top
trajectory_file = short_md.trajectory.dat
verlet_skin = 0.2
external_forces = 0
seed = 20261020
analysis_data_output_1 = {
name = native_hb.metrics.dat
print_every = 1
col_1 = {
type = step
}
col_2 = {
type = hb_list
only_count = true
order_parameters_file = native_bonds.op
}
col_3 = {
type = hb_list
only_count = true
}
}
'''
    inp=inp.replace('trajectory_file = short_md.trajectory.dat','trajectory_file = '+source)
    (folder/'native_hb_analysis.input').write_text(inp)
    with (folder/'native_hb_analysis.log').open('w') as log:r=subprocess.run([str(EXE),'native_hb_analysis.input'],cwd=folder,stdout=log,stderr=subprocess.STDOUT,timeout=90)
    if r.returncode:raise RuntimeError((folder/'native_hb_analysis.log').read_text()[-1500:])
    x=np.atleast_2d(np.loadtxt(folder/'native_hb.metrics.dat'));assert np.isfinite(x).all()
    result={'designed_basepairs':len(pairs),'frames_analyzed':len(x),'final_configuration_appended':appended_final,'last_step_analyzed':int(x[-1,0]),'native_hb_final':int(x[-1,1]),'native_hb_min':int(x[:,1].min()),'native_hb_final_fraction':float(x[-1,1]/len(pairs)),'native_hb_min_fraction':float(x[:,1].min()/len(pairs)),'all_hb_final':int(x[-1,2]),'off_target_hb_final':int(x[-1,2]-x[-1,1])}
    (folder/'native_hb_result.json').write_text(json.dumps(result,indent=2));return result

if __name__=='__main__':print(json.dumps(analyze(Path(sys.argv[1])),indent=2),flush=True)
