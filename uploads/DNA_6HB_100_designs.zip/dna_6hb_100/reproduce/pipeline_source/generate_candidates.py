"""Generate convex polyhedral candidates; exact graph isomorphism, not geometry, defines novelty."""
from pathlib import Path
import sys, json, random, itertools, collections, time
import numpy as np
from scipy.spatial import ConvexHull
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'deps'))
import networkx as nx

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'work/candidates'
OUT.mkdir(parents=True,exist_ok=True)

def read_ply(path):
    lines=path.read_text().splitlines()
    nv=int(next(x for x in lines if x.startswith('element vertex')).split()[-1])
    nf=int(next(x for x in lines if x.startswith('element face')).split()[-1])
    start=lines.index('end_header')+1
    xyz=np.array([[float(z) for z in x.split()[:3]] for x in lines[start:start+nv]])
    faces=[]
    for x in lines[start+nv:start+nv+nf]:
        v=list(map(int,x.split()));faces.append(v[1:1+v[0]])
    return xyz,faces

def graph_of(n,faces):
    g=nx.Graph();g.add_nodes_from(range(n))
    for f in faces:g.add_edges_from(zip(f,f[1:]+f[:1]))
    return g

def hull_poly(points):
    hull=ConvexHull(points)
    ids=sorted(set(map(int,hull.vertices))); p=points[ids]; remap={v:i for i,v in enumerate(ids)}
    groups={}
    for tri,eq in zip(hull.simplices,hull.equations):
        key=tuple(np.round(eq,8));groups.setdefault(key,set()).update(map(int,tri))
    faces=[]
    for eq,vs in groups.items():
        f=list(vs); q=points[f]; c=q.mean(axis=0); normal=np.array(eq[:3]);u=q[0]-c;u/=np.linalg.norm(u);v=np.cross(normal,u)
        order=np.argsort(np.arctan2((q-c)@v,(q-c)@u))
        faces.append([remap[f[i]] for i in order])
    return p,faces

def write_ply(path,p,faces):
    header=['ply','format ascii 1.0',f'element vertex {len(p)}','property float32 x','property float32 y','property float32 z',f'element face {len(faces)}','property list uint8 int32 vertex_indices','end_header']
    body=[' '.join(f'{z:.10f}' for z in v) for v in p]+[str(len(f))+' '+' '.join(map(str,f)) for f in faces]
    path.write_text('\n'.join(header+body)+'\n')

def metric(p,g):
    ll=np.array([np.linalg.norm(p[a]-p[b]) for a,b in g.edges])
    angles=[]
    for a in g:
        for b,c in itertools.combinations(g[a],2):
            u=p[b]-p[a];v=p[c]-p[a]
            angles.append(float(np.degrees(np.arccos(np.clip(np.dot(u,v)/np.linalg.norm(u)/np.linalg.norm(v),-1,1)))))
    return dict(edge_ratio_mean=float(ll.mean()/ll.min()),edge_ratio_max=float(ll.max()/ll.min()),min_vertex_angle_deg=min(angles),edge_budget_proxy=float(len(ll)*ll.mean()/ll.min()))

def main():
    baseline=[];bl=[]
    for base in [ROOT/'tools/TALOS/make/input',ROOT/'tools/athena/sample_inputs/3D']:
        for f in sorted(base.glob('*.ply')):
            p,faces=read_ply(f);g=graph_of(len(p),faces)
            baseline.append(g);bl.append({'path':str(f.relative_to(ROOT)),'V':len(g),'E':g.number_of_edges(),'F':len(faces),'edges':[list(e) for e in sorted(g.edges())]})
    (ROOT/'work/baseline_graphs.json').write_text(json.dumps(bl,indent=2))
    buckets=collections.defaultdict(list)
    for g in baseline:buckets[(len(g),g.number_of_edges(),nx.weisfeiler_lehman_graph_hash(g))].append(g)
    rng=np.random.default_rng(20261020)
    pool=np.array([v for v in itertools.product([-1.,0.,1.],repeat=3) if any(abs(x)==1 for x in v)])
    accepted=[]; seen=collections.defaultdict(list); t=time.time()
    for it in range(45000):
        n=int(rng.integers(7,13)); p=pool[rng.choice(len(pool),size=n,replace=False)].copy()
        try:p,faces=hull_poly(p)
        except Exception:continue
        if not 6<=len(p)<=10 or max(map(len,faces))>6:continue
        g=graph_of(len(p),faces);E=g.number_of_edges()
        if not 11<=E<=20 or max(dict(g.degree).values())>6:continue
        if len(p)-E+len(faces)!=2:continue
        key=(len(g),E,nx.weisfeiler_lehman_graph_hash(g))
        if any(nx.is_isomorphic(g,b) for b in buckets[key]):continue
        if any(nx.is_isomorphic(g,b) for b in seen[key]):continue
        m=metric(p,g)
        if m['min_vertex_angle_deg']<34:continue
        if nx.node_connectivity(g)<3:continue
        seen[key].append(g)
        accepted.append((p,faces,g,m))
        if len(accepted)>=900:break
    accepted.sort(key=lambda x:(x[3]['edge_budget_proxy'],x[3]['edge_ratio_max']))
    manifest=[]
    for i,(p,faces,g,m) in enumerate(accepted,1):
        name=f'cand_{i:04d}';write_ply(OUT/(name+'.ply'),p,faces)
        item={'candidate_id':name,'V':len(p),'E':g.number_of_edges(),'F':len(faces),'degree_sequence':sorted(dict(g.degree).values()),'face_sizes':sorted(map(len,faces)),'wl_hash':nx.weisfeiler_lehman_graph_hash(g),'edges':[list(e) for e in sorted(g.edges())],**m}
        manifest.append(item)
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({'candidates':len(accepted),'baseline_files':len(baseline),'seconds':round(time.time()-t,1),'best':manifest[:5]}),flush=True)

if __name__=='__main__':main()
