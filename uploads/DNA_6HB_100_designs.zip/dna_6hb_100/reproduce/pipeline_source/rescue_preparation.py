from pathlib import Path
import json,shutil,time,sys
from run_v2 import stage,backbone_audit,rgyr,OUT
folder=OUT/'structures'/(sys.argv[1] if len(sys.argv)>1 else '6hb_009');previous=json.loads((folder/'simulation_result.json').read_text());assert previous.get('protocol_version')==2 and previous.get('failure_stage')=='conditioning_limit'
attempt=folder/'attempt_02_conditioning_limit';attempt.mkdir(exist_ok=True);shutil.copy2(folder/'simulation_result.json',attempt/'result.json')
result={**previous,'protocol_version':3,'status':'failed','failure_stage':None,'fallback_reason':'Two bonds remained stretched after level-100 capped minimization; increase only preparation force cap, keep full production FENE unchanged.'};result['stages']=list(previous['stages']);t=time.time();conf='conditioning_3.last.dat'
for k in range(1,3):
    name=f'rescue_conditioning_{k}';entry=stage(folder,name,conf,1500,result['seed'],1000,False);result['stages'].append(entry)
    if entry['returncode'] or not entry.get('finite'):result['failure_stage']=name;break
    conf=name+'.last.dat';b=backbone_audit(folder,conf);entry.update(b)
    print(name,b,flush=True)
    if b['outside_fene_range']==0:break
else:result['failure_stage']='fallback_conditioning_limit'
if not result.get('failure_stage'):
    entry=stage(folder,'short_md',conf,5000,result['seed'],None,True);result['stages'].append(entry)
    if entry['returncode']==0 and entry.get('finite') and entry.get('last_step')==5000 and max(abs(entry['potential_energy_min_per_nt']),abs(entry['potential_energy_max_per_nt']))<100:
        result['status']='passed_short_md';audit=json.loads((folder/'conversion_audit.json').read_text());result['hb_final_fraction_of_designed_bp']=entry['hb_count_final']/audit['designed_basepairs'];result['hb_min_fraction_of_designed_bp']=entry['hb_count_min']/audit['designed_basepairs'];result['rg_initial_oxdna']=rgyr(folder/'initial.dat');result['rg_final_oxdna']=rgyr(folder/'short_md.last.dat');result['rg_fractional_change']=result['rg_final_oxdna']/result['rg_initial_oxdna']-1
    else:result['failure_stage']='short_md'
result['fallback_seconds']=round(time.time()-t,3);(folder/'simulation_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
