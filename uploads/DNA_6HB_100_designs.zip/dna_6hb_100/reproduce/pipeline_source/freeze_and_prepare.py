from pathlib import Path
import json,shutil,hashlib,datetime,concurrent.futures,sys,csv
import numpy as np
from prepare_oxdna import prepare
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/dna_6hb_100';OUT.mkdir(parents=True,exist_ok=True)

def make(item):
    dst=OUT/'structures'/item['design_id'];dst.parent.mkdir(exist_ok=True)
    shutil.copytree(ROOT/'work/designed'/item['candidate_id'],dst,dirs_exist_ok=True)
    cad=next(dst.glob('*caDNAno.json'));j=json.loads(cad.read_text())
    assert len(j['vstrands'])==6*item['E'],(item['candidate_id'],len(j['vstrands']),item['E'])
    item['virtual_helix_count']=len(j['vstrands'])
    item['conversion']=prepare(dst)
    return item

if __name__=='__main__':
    all=[json.loads(p.read_text()) for p in (ROOT/'work/designed').glob('*/design_audit.json')]
    eligible=[x for x in all if x.get('design_status')=='passed_connectivity' and x['total_nt']<10000 and x['staple_min_nt']>=20 and x['staple_max_nt']<=60]
    eligible.sort(key=lambda x:(x['total_nt'],x['candidate_id']));eligible=eligible[:100]
    assert len(eligible)==100
    for i,x in enumerate(eligible,1):x['design_id']=f'6hb_{i:03d}'
    payload=json.dumps(eligible,sort_keys=True).encode();digest=hashlib.sha256(payload).hexdigest()
    selected=np.random.default_rng(20261020).choice(100,20,replace=False).tolist()
    protocol={'selection_frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selection_sha256':digest,'sampling_method':'numpy.random.default_rng(20261020).choice(100,20,replace=False)','sample_seed':20261020,'sample_zero_based_indices':selected,'sample_design_ids':[eligible[i]['design_id'] for i in selected],'design_population_size':100,'preparation':{'minimum_steps':1500,'capped_md_steps':1500,'max_backbone_force':5},'short_md':{'steps':5000,'dt':0.002,'T_K':300,'salt_concentration_M':0.5,'interaction_type':'DNA2','external_forces':False,'max_backbone_force':None},'pass_criterion':'oxDNA exits 0, completes all 5000 full-force MD steps, all saved energies and coordinates finite; report H-bonds and Rg separately','failures_replaced':False}
    (OUT/'sampling_protocol.json').write_text(json.dumps(protocol,indent=2))
    (OUT/'selection_before_simulation.json').write_bytes(payload)
    shutil.copy2(ROOT/'work/baseline_graphs.json',OUT/'baseline_graphs.json');shutil.copy2(ROOT/'work/software_provenance.json',OUT/'software_provenance.json')
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        items=list(ex.map(make,eligible))
    (OUT/'design_manifest.json').write_text(json.dumps(items,indent=2))
    fields=['design_id','candidate_id','total_nt','scaffold_nt','staple_nt','staple_count','staple_min_nt','staple_max_nt','designed_bp','unpaired_nt','V','E','F','minimum_edge_bp','vertex_design','cross_section','edge_ratio_mean','edge_ratio_max','min_vertex_angle_deg','virtual_helix_count']
    with (OUT/'design_manifest.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(items)
    print(json.dumps({'count':len(items),'mean_total_nt':sum(x['total_nt'] for x in items)/100,'range_total_nt':[min(x['total_nt'] for x in items),max(x['total_nt'] for x in items)],'sample_ids':protocol['sample_design_ids']}),flush=True)
