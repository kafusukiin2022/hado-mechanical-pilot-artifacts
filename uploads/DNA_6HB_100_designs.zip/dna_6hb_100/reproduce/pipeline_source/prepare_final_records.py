from pathlib import Path
import json,shutil,re
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results/dna_6hb_100';protocol=json.loads((OUT/'sampling_protocol.json').read_text());index=[]
for name in protocol['sample_design_ids']:
    folder=OUT/'structures'/name;attempt=folder/'attempt_01_weak_preparation';p=attempt/'result.json';category='legacy_time_column_bookkeeping_error' if (attempt/'bookkeeping_precheck.json').exists() else 'no_completed_initial_full_md_attempt'
    if p.exists():
        data=json.loads(p.read_text())
        if data.get('failure_reason')=='nonfinite_or_incomplete' and data.get('failure_stage')=='minimize' and data.get('stages',[{}])[0].get('returncode')==0:
            p.rename(attempt/'bookkeeping_precheck.json');category='legacy_time_column_bookkeeping_error'
            (attempt/'README_zh.txt').write_text('bookkeeping_precheck.json 是早期检查器把 energy.dat 的时间列误作步数而留下的记录，不是物理失败，不纳入最终通过率。原生初始最小化正常完成；真实步数见根目录 minimize.last.dat 的 t=1500 和 minimize.log 的正常结束记录。正式数值结果以根目录 simulation_result.json 和 short_md.log 为准。\n')
        elif data.get('failure_stage')=='short_md':
            category='weak_preparation_rejected_by_native_fene_check'
            (attempt/'README_zh.txt').write_text('此尝试使用较弱准备，生产段被 oxDNA 原生 FENE 键长检查拒绝启动；保留输入、错误日志及结果。后续在同一结构上增强最小化并重新接受完整 FENE 势检查，未更换抽样对象。\n')
    p=folder/'attempt_02_conditioning_limit'
    if p.exists():(p/'README_zh.txt').write_text('此记录为达到初版增强最小化的轮数上限，尚未完成生产 MD。后续使用更高准备力上限；正式 MD 始终采用完整 FENE 势、无力上限和外部约束。结果见根目录。\n')
    result_path=folder/'simulation_result.json';result=json.loads(result_path.read_text())
    result['runtime_scope']='The recorded run block excludes shared initial minimization and earlier preparation attempts; native per-stage timings remain in each log.'
    result_path.write_text(json.dumps(result,indent=2));index.append({'design_id':name,'initial_attempt_category':category,'conditioning_limit_recorded':p.exists(),'final_protocol_version':result.get('protocol_version'),'final_status':result.get('status')})
(OUT/'attempts_index.json').write_text(json.dumps(index,indent=2))
# Preserve original scripts, and the exact final postprocessing recipes.
for name in ['rescue_preparation.py','test_fene_ready.py','finalize_validation.py','prepare_final_records.py','plot_energy.py']:
    shutil.copy2(ROOT/'work'/name,OUT/'reproduce/pipeline_source'/name)
print(json.dumps({'attempt_records_indexed':len(index),'categories':{c:sum(x['initial_attempt_category']==c for x in index) for c in sorted(set(x['initial_attempt_category'] for x in index))}}),flush=True)
