"""Run authentic TALOS on unique candidates; retain native files and inspect nucleotide connectivity."""
from pathlib import Path
import json, sys, time, subprocess, shutil, concurrent.futures, collections, csv
from generate_candidates import read_ply, graph_of, metric

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'work/talos_batch';(RUN/'input').mkdir(parents=True,exist_ok=True)
OUT=ROOT/'work/designed';OUT.mkdir(exist_ok=True)
(RUN/'env.txt').write_text('para_platform linux\npara_cut_stap_method max\npara_min_cut_stap 20\npara_max_cut_stap 60\npara_set_seq_scaf 0\n')

def inspect_cndo(path):
    lines=path.read_text().splitlines();top={};active=False
    for line in lines:
        if line.startswith('dnaTop'):active=True;continue
        if active and not line.strip():break
        if active:
            x=line.strip().split(',');i=int(x[1]);top[i]=(int(x[2]),int(x[3]),int(x[4]),x[5].strip())
    comp={'A':'T','T':'A','C':'G','G':'C'};errors=[]
    for i,(up,dn,across,base) in top.items():
        if base not in comp:errors.append(f'invalid_base:{i}')
        if up!=-1 and (up not in top or top[up][1]!=i):errors.append(f'nonreciprocal_5prime:{i}')
        if dn!=-1 and (dn not in top or top[dn][0]!=i):errors.append(f'nonreciprocal_3prime:{i}')
        if across!=-1 and (across not in top or top[across][2]!=i or comp.get(base)!=top[across][3]):errors.append(f'invalid_pair:{i}')
    starts=[i for i,x in top.items() if x[0]==-1];strands=[];seen=set()
    for start in starts:
        cur=start;strand=[]
        while cur!=-1 and cur not in seen:
            seen.add(cur);strand.append(cur);cur=top[cur][1]
        strands.append(strand)
    if len(seen)!=len(top):errors.append('circular_or_unreachable_nt')
    strands.sort(key=len,reverse=True)
    lens=[len(x) for x in strands]
    return {'total_nt':len(top),'scaffold_nt':lens[0] if lens else 0,'staple_nt':sum(lens[1:]),'strand_count':len(lens),'staple_count':max(0,len(lens)-1),'staple_min_nt':min(lens[1:]) if len(lens)>1 else 0,'staple_max_nt':max(lens[1:]) if len(lens)>1 else 0,'unpaired_nt':sum(x[2]==-1 for x in top.values()),'designed_bp':sum(x[2]!=-1 for x in top.values())//2,'connectivity_errors':errors},top,strands

def run(item):
    name=item['candidate_id'];dest=OUT/name;meta=dest/'design_audit.json'
    if meta.exists():return json.loads(meta.read_text())
    dest.mkdir(exist_ok=True)
    source=ROOT/'work/optimized'/(name+'.ply')
    if not source.exists():source=ROOT/'work/candidates'/(name+'.ply')
    shutil.copy2(source,RUN/'input'/(name+'.ply'));shutil.copy2(source,dest/'target.ply')
    p,faces=read_ply(source);g=graph_of(len(p),faces);m=metric(p,g)
    log=dest/'talos.log';t=time.time()
    try:
        with log.open('w') as f:r=subprocess.run([str(ROOT/'tools/TALOS/build-linux/TALOS'),name+'.ply','1','1','42'],cwd=RUN,stdout=f,stderr=subprocess.STDOUT,timeout=35)
        folder=RUN/'output'/(name+'_6HB_42bp_Flat');cndos=list(folder.glob('*.cndo'))
        result={**item,**m,'geometry_source':str(source.relative_to(ROOT)),'talos_returncode':r.returncode,'talos_seconds':round(time.time()-t,3),'vertex_design':'flat','cross_section':'6HB_honeycomb_section_1','minimum_edge_bp':42,'design_status':'failed'}
        if r.returncode==0 and cndos:
            audit,top,strands=inspect_cndo(cndos[0]);result.update(audit)
            if not audit['connectivity_errors']:
                result['design_status']='passed_connectivity'
            for path in folder.iterdir():
                if path.suffix in ['.cndo','.json','.csv'] or path.name in ['TXT_TALOS.txt','TXT_Edge_Length.txt'] or path.name.endswith('_04_six_hb_lines.bild'):
                    shutil.copy2(path,dest/path.name)
            if strands:
                sequence=''.join(top[i][3] for i in strands[0]);(dest/'scaffold.fasta').write_text('>'+name+'_custom_length_scaffold_5to3\n'+sequence+'\n')
            with (dest/'strands_5to3.csv').open('w') as f:
                w=csv.writer(f);w.writerow(['strand','role','length_nt','sequence_5to3','cndo_nt_ids_5to3'])
                for i,st in enumerate(strands,1):w.writerow([i,'scaffold' if i==1 else 'staple',len(st),''.join(top[j][3] for j in st),' '.join(map(str,st))])
        if folder.exists():shutil.rmtree(folder)
    except Exception as e:result={**item,'design_status':'exception','error':str(e),'talos_seconds':round(time.time()-t,3)}
    meta.write_text(json.dumps(result,indent=2));return result

if __name__=='__main__':
    items=json.loads((ROOT/'work/candidates/manifest.json').read_text())
    recomputed=[]
    for x in items:
        source=ROOT/'work/optimized'/(x['candidate_id']+'.ply')
        if not source.exists():continue
        p,faces=read_ply(source);g=graph_of(len(p),faces)
        recomputed.append({**x,**metric(p,g)})
    recomputed.sort(key=lambda x:x['edge_budget_proxy'])
    limit=int(sys.argv[1]) if len(sys.argv)>1 else 250;recomputed=recomputed[:limit]
    t=time.time();results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
        for i,r in enumerate(ex.map(run,recomputed),1):
            results.append(r)
            if i%10==0:
                good=[x for x in results if x['design_status']=='passed_connectivity'];nts=sorted(x['total_nt'] for x in good)
                print(json.dumps({'done':i,'valid':len(good),'under_10000':sum(n<10000 for n in nts),'mean_lowest_100':round(sum(nts[:100])/len(nts[:100]),2) if nts else None,'seconds':round(time.time()-t,1)}),flush=True)
    (ROOT/'work/design_results.json').write_text(json.dumps(results,indent=2))
    print('complete',len(results),round(time.time()-t,1),flush=True)
