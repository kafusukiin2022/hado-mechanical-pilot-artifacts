from pathlib import Path
import numpy as np,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results/dna_6hb_100'

def plot():
    summary=json.loads((OUT/'validation_summary.json').read_text());rows=summary['rows'];series={}
    for row in rows:
        if row['status']=='passed_short_md':series[row['design_id']]=np.atleast_2d(np.loadtxt(OUT/'structures'/row['design_id']/'short_md.metrics.dat'))
    bounds=[float(y) for a in series.values() for y in [a[:,1].min(),a[:,1].max()]]
    ymin=min(bounds)-.03 if bounds else -2.;ymax=max(bounds)+.03 if bounds else -1.
    fig,axs=plt.subplots(4,5,figsize=(15,10.2),sharex=True,sharey=True,facecolor='#fcfcfa')
    for ax,row in zip(axs.ravel(),rows):
        name=row['design_id'];ax.set_facecolor('#ffffff');ax.spines[['top','right']].set_visible(False)
        if name in series:
            a=series[name];ax.plot(a[:,0]*.001,a[:,1],color='#1d6379',lw=1.4)
            ax.set_title(f"{name} | Native HB {row['native_hb_final_fraction']:.1%}",fontsize=9,loc='left')
        else:
            ax.text(.5,.5,'Pending' if row['status']=='pending' else 'Failed; see log',ha='center',va='center',transform=ax.transAxes,color='#7a746c',fontsize=10)
            ax.set_title(name,fontsize=9,loc='left')
        ax.set_xlim(0,5);ax.set_ylim(ymin,ymax);ax.grid(axis='y',alpha=.17);ax.tick_params(labelsize=8)
    fig.suptitle(f"oxDNA2 short MD | {summary['passed']} passed, {summary['failed']} failed, {summary['pending']} pending / 20\nFull FENE; no force caps or external restraints; 300 K; dt = 0.001",fontsize=15,y=.99,color='#20343b')
    fig.supxlabel('Time (oxDNA units)',fontsize=11);fig.supylabel('Potential energy / nucleotide (oxDNA units)',fontsize=11)
    fig.tight_layout(rect=[.02,.025,1,.93]);fig.savefig(OUT/'energy_traces.png',dpi=175,facecolor=fig.get_facecolor());plt.close(fig)

if __name__=='__main__':plot()
