"""Optimize edge uniformity while constraining polygon planarity and convexity."""
from pathlib import Path
import json, sys, time, concurrent.futures
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial import ConvexHull
from generate_candidates import read_ply, write_ply, graph_of, metric, hull_poly

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'work/candidates'
OUT=ROOT/'work/optimized';OUT.mkdir(exist_ok=True)

def opt(item):
    p,faces=read_ply(SRC/(item['candidate_id']+'.ply'))
    g=graph_of(len(p),faces);edges=np.array(list(g.edges()))
    p-=p.mean(axis=0)
    lengths=np.linalg.norm(p[edges[:,0]]-p[edges[:,1]],axis=1);p/=np.mean(lengths)
    triples=np.array([f[:3] for f in faces])
    other=[np.array([j for j in range(len(p)) if j not in f]) for f in faces]
    def residual(x):
        q=x.reshape(-1,3);a=q[triples[:,1]]-q[triples[:,0]];b=q[triples[:,2]]-q[triples[:,0]]
        normals=np.cross(a,b);normals/=np.maximum(np.linalg.norm(normals,axis=1)[:,None],1e-8)
        r=[np.linalg.norm(q[edges[:,0]]-q[edges[:,1]],axis=1)-1.,q.mean(axis=0)]
        for j,f in enumerate(faces):
            if len(f)>3:r.append(60*((q[f[3:]]-q[f[0]])@normals[j]))
            r.append(8*np.maximum((q[other[j]]-q[f[0]])@normals[j]+0.035,0))
        return np.concatenate(r)
    result=least_squares(residual,p.ravel(),max_nfev=100,ftol=1e-5,xtol=1e-5,gtol=1e-5)
    q=result.x.reshape(-1,3)
    # Exact same labeled convex graph required; do not silently alter topology.
    valid=True
    try:
        hull=ConvexHull(q)
        valid=len(hull.vertices)==len(q) and hull.volume>0.05
        # Planarity can be approximate at solver tolerance; check signed face support directly.
        for f in faces:
            normal=np.cross(q[f[1]]-q[f[0]],q[f[2]]-q[f[0]])
            normal/=np.linalg.norm(normal)
            if max(abs((q[f]-q[f[0]])@normal))>0.002:valid=False
            if np.max((q-q[f[0]])@normal)>0.002:valid=False
        m=metric(q,g)
        if m['edge_budget_proxy']>=item['edge_budget_proxy'] or m['min_vertex_angle_deg']<34:valid=False
    except Exception:valid=False
    if not valid:q=p;m=metric(p,g)
    write_ply(OUT/(item['candidate_id']+'.ply'),q,faces)
    return {**item,**m,'geometry_optimized':valid,'optimization_nfev':result.nfev}

if __name__=='__main__':
    items=json.loads((SRC/'manifest.json').read_text());t=time.time();out=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        for i,x in enumerate(ex.map(opt,items),1):
            out.append(x)
            if i%25==0:print('optimized',i,'elapsed',round(time.time()-t,1),flush=True)
    out.sort(key=lambda x:x['edge_budget_proxy'])
    (OUT/'manifest.json').write_text(json.dumps(out,indent=2))
    print('complete',len(out),round(time.time()-t,1),flush=True)
