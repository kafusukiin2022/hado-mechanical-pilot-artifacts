from pathlib import Path
import sys,json,subprocess, numpy as np, shutil, time
from design_batch import inspect_cndo
ROOT=Path(__file__).resolve().parents[1]

def prepare(folder):
    folder=Path(folder);cn=next(folder.glob('*.cndo'))
    with (folder/'conversion.log').open('w') as log:
        r=subprocess.run([sys.executable,str(ROOT/'tools/tacoxDNA/src/CanDo_oxDNA.py'),str(cn),'-b','200'],stdout=log,stderr=subprocess.STDOUT,timeout=60)
    if r.returncode:raise RuntimeError('tacoxDNA exit '+str(r.returncode))
    top=Path(str(cn)+'.top');conf=Path(str(cn)+'.oxdna')
    shutil.move(top,folder/'design.top');shutil.move(conf,folder/'initial.dat')
    data=np.loadtxt(folder/'initial.dat',skiprows=3)
    tlines=(folder/'design.top').read_text().splitlines();n,s=map(int,tlines[0].split())
    assert data.shape==(n,15) and np.isfinite(data).all()
    assert len(tlines)==n+1
    a1=data[:,3:6];a3=data[:,6:9]
    assert np.max(np.abs(np.linalg.norm(a1,axis=1)-1))<0.002
    assert np.max(np.abs(np.linalg.norm(a3,axis=1)-1))<0.002
    assert np.max(np.abs(np.sum(a1*a3,axis=1)))<0.002
    topology=[x.split() for x in tlines[1:]]
    assert len(set(int(x[0]) for x in topology))==s
    for i,x in enumerate(topology):
        n3,n5=map(int,x[2:])
        if n3!=-1:assert 0<=n3<n and int(topology[n3][3])==i
        if n5!=-1:assert 0<=n5<n and int(topology[n5][2])==i
    data[:,:3]+=100-data[:,:3].mean(axis=0)
    assert data[:,:3].min()>5 and data[:,:3].max()<195
    with (folder/'initial.dat').open('w') as f:
        f.write('t = 0\nb = 200 200 200\nE = 0 0 0\n')
        np.savetxt(f,data,fmt='%.9f')
    audit,nt,strands=inspect_cndo(cn)
    # The old oxDNA topology is ordered 3'->5'; reconstruct the converter's ID mapping.
    starts=[i for i,x in nt.items() if x[1]==-1];mapping={}
    for start in starts:
        cur=start
        while cur!=-1 and cur not in mapping:
            mapping[cur]=len(mapping);cur=nt[cur][0]
    assert len(mapping)==n
    pairs=[(mapping[i],mapping[x[2]]) for i,x in nt.items() if x[2]>i]
    (folder/'designed_pairs.txt').write_text('\n'.join(f'{a} {b}' for a,b in pairs)+'\n')
    result={'nucleotides':n,'strands':s,'designed_basepairs':len(pairs),'finite':True,'orientation_and_bonds_valid':True,'box_oxdna_units':200}
    (folder/'conversion_audit.json').write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__':print(json.dumps(prepare(Path(sys.argv[1]).resolve())),flush=True)
