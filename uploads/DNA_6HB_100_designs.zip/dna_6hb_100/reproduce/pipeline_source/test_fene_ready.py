from pathlib import Path
import json,time,shutil,numpy as np,sys
from run_v2 import OUT,stage,backbone_audit,rgyr
folder=OUT/'structures'/'6hb_046';previous=json.loads((folder/'simulation_result.json').read_text());conf='rescue_conditioning_1.last.dat';b=backbone_audit(folder,conf);assert b['outside_fene_range']==0
assert 'END OF THE SIMULATION, everything went OK!' in (folder/'rescue_conditioning_1.log').read_text()
archive=folder/'attempt_03_unused_extra_minimization';archive.mkdir(exist_ok=True)
for p in folder.glob('rescue_conditioning_2.*'):shutil.move(p,archive/p.name)
(archive/'README.txt').write_text('This additional minimization was interrupted after the first strong minimization had already produced a configuration inside the native FENE domain. It is not used as a completed stage or a production configuration.\n')
metrics=np.atleast_2d(np.loadtxt(folder/'rescue_conditioning_1.metrics.dat'));entry={'stage':'rescue_conditioning_1','returncode':0,'requested_steps':1500,'last_step':1500,'finite':True,'capped_backbone_force':1000,'external_forces':False,'reused_completed_stage':True,'native_fene_domain_verified':True,**b}
result={**previous,'protocol_version':3,'status':'failed','failure_stage':None,'stages':list(previous['stages'])+[entry],'readiness_criterion':'all bonds inside native FENE interval [0.5064,1.0064]; full unmodified MD remains the acceptance test'}
t=time.time();md=stage(folder,'short_md',conf,5000,result['seed'],None,True);result['stages'].append(md)
if md['returncode']==0 and md.get('finite') and md.get('last_step')==5000 and max(abs(md['potential_energy_min_per_nt']),abs(md['potential_energy_max_per_nt']))<100:
    result['status']='passed_short_md';audit=json.loads((folder/'conversion_audit.json').read_text());result['hb_final_fraction_of_designed_bp']=md['hb_count_final']/audit['designed_basepairs'];result['hb_min_fraction_of_designed_bp']=md['hb_count_min']/audit['designed_basepairs'];result['rg_initial_oxdna']=rgyr(folder/'initial.dat');result['rg_final_oxdna']=rgyr(folder/'short_md.last.dat');result['rg_fractional_change']=result['rg_final_oxdna']/result['rg_initial_oxdna']-1
else:result['failure_stage']='short_md'
result['fallback_md_seconds']=round(time.time()-t,3);(folder/'simulation_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
