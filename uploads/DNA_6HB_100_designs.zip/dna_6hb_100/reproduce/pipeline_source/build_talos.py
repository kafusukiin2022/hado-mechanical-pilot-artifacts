from pathlib import Path
import subprocess, json, shutil, re

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'tools' / 'TALOS' / 'src'
BUILD = ROOT / 'tools' / 'TALOS' / 'build-linux'
BUILD.mkdir(exist_ok=True)
# Preserve the downloaded upstream sources; port a separate working copy.
for p in SOURCE.glob('*.f90'):
    s = p.read_text(errors='replace')
    # Parenthesize each logical comparison so mixed AND/OR expressions retain precedence.
    for match in reversed(list(re.finditer(r'(==|/=)\s*\.(true|false)\.', s, flags=re.I))):
        stop = match.start()
        j = stop - 1
        while s[j].isspace(): j -= 1
        while j >= 0:
            if s[j] == ')':
                depth = 1; j -= 1
                while depth:
                    if s[j] == ')': depth += 1
                    if s[j] == '(': depth -= 1
                    j -= 1
            elif s[j].isalnum() or s[j] in '_%.': j -= 1
            else: break
        start = j + 1
        expr = s[start:stop].strip()
        s = s[:start] + '(' + expr + (' .eqv. ' if match[1]=='==' else ' .neqv. ') + '.'+match[2]+'.)' + s[match.end():]
    s = s.replace('2**31-1', 'huge(0)')
    s = re.sub(r'function (\w+) result\(', r'function \1() result(', s, flags=re.I)
    s = s.replace('if(0 .and.', 'if(.false. .and.')
    s = re.sub(r'=\s*\["', '= [character(len=200) :: "', s)
    if p.name == '4_Basepair.f90':
        s = s.replace('double precision :: i\n', 'integer :: i\n', 1)
    (BUILD / p.name).write_text(s)
(BUILD / 'Ifport.f90').write_text('''module Ifport
implicit none
contains
logical function SYSTEMQQ(command)
character(*), intent(in) :: command
integer :: status
if (index(command, 'title ') == 1 .or. index(command, 'mode ') == 1 .or. &
    command == 'color' .or. command == 'date /t' .or. command == 'cls') then
    SYSTEMQQ = .true.
    return
end if
call execute_command_line(command, exitstat=status)
SYSTEMQQ = status == 0
end function SYSTEMQQ
end module Ifport
''')
p = BUILD / 'Importer.f90'
s = p.read_text(errors='replace')
s = s.replace('if(index(ctemp, "format"))', 'if(index(ctemp, "format") > 0)')
s = s.replace('if(index(ctemp, "property float32 z") .or. index(ctemp, "property float z"))', 'if(index(ctemp, "property float32 z") > 0 .or. index(ctemp, "property float z") > 0)')
s = s.replace('if(index(ctemp,"end_header"))', 'if(index(ctemp,"end_header") > 0)')
p.write_text(s)
order = 'Ifport Data_Bound Data_DNA Data_Geom Data_Mesh Data_Prob Para List Math Mani SpanTree Importer Exam_Platonic Exam_Archi Exam_Johnson Exam_Catalan Exam_Miscel 3_Section 1_Input 2_ModGeo 4_Basepair 5_Route 6_SeqDesign 7_Output TALOS'.split()
compiler_root = ROOT / 'deps/apt/root/usr'
compiler = compiler_root / 'bin/x86_64-linux-gnu-gfortran-13'
cmd = [str(compiler), '-B'+str(compiler_root/'lib/gcc/x86_64-linux-gnu/13'), '-L'+str(compiler_root/'lib/gcc/x86_64-linux-gnu/13'), '-O2', '-std=legacy', '-fdec', '-ffree-line-length-none', '-fallow-argument-mismatch', '-fbacktrace']
with (ROOT/'work/talos_build.log').open('w') as log:
    for name in order:
        print('compiling', name, flush=True)
        r = subprocess.run(cmd + ['-c', name + '.f90'], cwd=BUILD, stdout=log, stderr=subprocess.STDOUT)
        if r.returncode:
            print((ROOT/'work/talos_build.log').read_text()[-10000:]);raise SystemExit(r.returncode)
    r = subprocess.run(['gcc', '-O2', '-o', 'TALOS'] + [n+'.o' for n in order] + [str(compiler_root/'lib/gcc/x86_64-linux-gnu/13/libgfortran.a'), '-lquadmath', '-lm'], cwd=BUILD, stdout=log, stderr=subprocess.STDOUT)
    print('link',r.returncode,flush=True)
    if r.returncode: print((ROOT/'work/talos_build.log').read_text()[-10000:])
    raise SystemExit(r.returncode)
