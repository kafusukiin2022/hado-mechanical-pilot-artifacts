from pathlib import Path
import sys,json,itertools,collections,hashlib,time
import numpy as np
from generate_candidates import read_ply,graph_of
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'deps'))
import networkx as nx
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results/dna_6hb_100'
items=json.loads((OUT/'design_manifest.json').read_text());baselines=json.loads((OUT/'baseline_graphs.json').read_text())
basegraphs=[]
for x in baselines:
    g=nx.Graph();g.add_nodes_from(range(x['V']));g.add_edges_from(x['edges']);basegraphs.append(g)
graphs=[];audit=[];duplicates=[];baseline_matches=[]
for item in items:
    name=item['design_id'];folder=OUT/'structures'/name;p,faces=read_ply(folder/'target.ply');g=graph_of(len(p),faces)
    counts=collections.Counter(tuple(sorted(e)) for f in faces for e in zip(f,f[1:]+f[:1]))
    assert all(v==2 for v in counts.values())
    assert len(g)-g.number_of_edges()+len(faces)==2
    assert nx.node_connectivity(g)>=3
    assert nx.is_connected(g)
    assert sorted(map(list,sorted(g.edges())))==sorted(item['edges'])
    assert nx.is_isomorphic(g, nx.Graph(item['edges']))
    matches=[baselines[i]['path'] for i,b in enumerate(basegraphs) if len(b)==len(g) and b.number_of_edges()==g.number_of_edges() and nx.is_isomorphic(g,b)]
    if matches:baseline_matches.append({'id':name,'matches':matches})
    for j,b in enumerate(graphs):
        if len(b)==len(g) and b.number_of_edges()==g.number_of_edges() and nx.is_isomorphic(g,b):duplicates.append([items[j]['design_id'],name])
    graphs.append(g)
    audit.append({'design_id':name,'V':len(g),'E':g.number_of_edges(),'F':len(faces),'genus':0,'closed_manifold_edges':True,'node_connectivity':nx.node_connectivity(g),'baseline_exact_isomorphism_matches':matches,'virtual_helices_per_edge':6,'total_nt':item['total_nt']})
result={'designs_audited':100,'baseline_files':len(basegraphs),'talos_builtin_files':sum('/TALOS/' in x['path'] for x in baselines),'athena_3d_files':sum('/athena/' in x['path'] for x in baselines),'pairwise_comparisons':4950,'cross_baseline_comparisons':100*len(basegraphs),'duplicate_pairs':duplicates,'baseline_matches':baseline_matches,'all_total_nt_below_10000':all(x['total_nt']<10000 for x in items),'mean_total_nt':np.mean([x['total_nt'] for x in items]),'items':audit,'interpretation':'Novelty means non-isomorphic polyhedral 1-skeleton graphs relative to the downloaded baseline files; all surfaces are genus zero. No claim of literature-wide novelty.'}
(OUT/'topology_audit.json').write_text(json.dumps(result,indent=2))
assert not duplicates and not baseline_matches
fig=plt.figure(figsize=(19,21),facecolor='#fcfcfa')
for i,item in enumerate(items):
    ax=fig.add_subplot(10,10,i+1,projection='3d');p,faces=read_ply(OUT/'structures'/item['design_id']/'target.ply');g=graph_of(len(p),faces)
    for a,b in g.edges():ax.plot(*p[[a,b]].T,color='#1d6379',lw=1.15,alpha=.95)
    ax.scatter(*p.T,s=7,color='#c27840',depthshade=False)
    ax.view_init(elev=19,azim=38);ax.set_axis_off();ax.set_box_aspect([1,1,1]);c=p.mean(axis=0);r=np.ptp(p,axis=0).max()/2*1.1
    ax.set_xlim(c[0]-r,c[0]+r);ax.set_ylim(c[1]-r,c[1]+r);ax.set_zlim(c[2]-r,c[2]+r)
    ax.set_title(f"{item['design_id']}  {item['total_nt']} nt",fontsize=7,pad=-7,color='#20343b')
fig.suptitle('100 distinct polyhedral graphs | 6HB edges | 42 bp minimum\n8,630.38 nt mean (scaffold + staples)',fontsize=17,y=.988,color='#20343b')
fig.subplots_adjust(left=.01,right=.99,bottom=.01,top=.956,wspace=0,hspace=.08)
fig.savefig(OUT/'structure_atlas.png',dpi=145,facecolor=fig.get_facecolor());plt.close(fig)
print(json.dumps({k:v for k,v in result.items() if k!='items'}),flush=True)
