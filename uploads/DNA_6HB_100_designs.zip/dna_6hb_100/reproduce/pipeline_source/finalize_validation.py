from pathlib import Path
import json,csv,datetime,zipfile,hashlib,sys,numpy as np
from analyze_native_bonds import analyze
from run_v2 import backbone_audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results/dna_6hb_100';DEL=ROOT/'deliverables'
protocol=json.loads((OUT/'sampling_protocol.json').read_text());manifest=json.loads((OUT/'design_manifest.json').read_text());byid={x['design_id']:x for x in manifest}
rows=[];finished=[];passed=[];failed=[]
for name in protocol['sample_design_ids']:
    folder=OUT/'structures'/name;p=folder/'simulation_result.json';r=json.loads(p.read_text()) if p.exists() else {}
    if r.get('protocol_version',0)<2:r={'folder':name,'protocol_version':3,'status':'pending'}
    if name in ['6hb_046','6hb_064'] and r.get('protocol_version')==2 and r.get('status')=='failed':
        r={'folder':name,'protocol_version':3,'status':'pending','retry_in_progress':True,'previous_attempt_recorded':True}
    if r['status']=='passed_short_md':
        with (folder/'short_md.last.dat').open() as f:last=int(f.readline().split('=')[1])
        assert last==5000
        coords=np.loadtxt(folder/'short_md.last.dat',skiprows=3);assert coords.shape==(byid[name]['total_nt'],15) and np.isfinite(coords).all()
        assert 'END OF THE SIMULATION, everything went OK!' in (folder/'short_md.log').read_text()
        b=backbone_audit(folder,'short_md.last.dat');assert b['outside_fene_range']==0
        hbpath=folder/'native_hb_result.json';hb=json.loads(hbpath.read_text()) if hbpath.exists() else analyze(folder)
        assert hb['last_step_analyzed']==5000
        r.update({'final_backbone_audit':b,'native_hb_analysis':hb});p.write_text(json.dumps(r,indent=2));passed.append(r)
    elif r['status']=='failed':failed.append(r)
    if r['status']!='pending':finished.append(r)
    md=next((s for s in r.get('stages',[]) if s['stage']=='short_md'),{})
    hb=r.get('native_hb_analysis',{})
    row={'design_id':name,'total_nt':byid[name]['total_nt'],'status':r['status'],'protocol_version':r.get('protocol_version',2),'completed_md_steps':md.get('last_step',0),'conditioning_rounds':sum(s['stage'].startswith('conditioning') for s in r.get('stages',[])),'fallback_rounds':sum(s['stage'].startswith('rescue_conditioning') for s in r.get('stages',[])),'potential_energy_final_per_nt':md.get('potential_energy_final_per_nt'),'potential_energy_min_per_nt':md.get('potential_energy_min_per_nt'),'potential_energy_max_per_nt':md.get('potential_energy_max_per_nt'),'native_hb_final_fraction':hb.get('native_hb_final_fraction'),'native_hb_min_fraction':hb.get('native_hb_min_fraction'),'off_target_hb_final':hb.get('off_target_hb_final'),'rg_fractional_change':r.get('rg_fractional_change'),'failure_stage':r.get('failure_stage')}
    rows.append(row)
    (folder/'validation_status.json').write_text(json.dumps({'status':r['status'],'selected_for_random_sample':True,'protocol_version':2},indent=2))
for x in manifest:
    if x['design_id'] not in protocol['sample_design_ids']:(OUT/'structures'/x['design_id']/'validation_status.json').write_text(json.dumps({'status':'not_simulated','selected_for_random_sample':False},indent=2))
snapshot={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selected':20,'completed':len(finished),'passed':len(passed),'failed':len(failed),'pending':20-len(finished),'completed_pass_rate':len(passed)/len(finished) if finished else None,'all_20_checked':len(finished)==20,'sample_replacements':0,'rows':rows}
if len(finished)==20:
    (OUT/'sample_results.json').write_text(json.dumps(finished,indent=2))
    protocol['completed_utc']=snapshot['updated_utc'];protocol['final_completed_count']=20;protocol['final_passed_count']=len(passed);protocol['final_failed_count']=len(failed)
    (OUT/'sampling_protocol.json').write_text(json.dumps(protocol,indent=2))
(OUT/'validation_summary.json').write_text(json.dumps(snapshot,indent=2))
with (OUT/'sample_results.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
report=f'''# 验证结果：100 种 6HB 多面体

本包记录实际 TALOS 设计与 oxDNA2 数值短跑。更新时间（UTC）：{snapshot['updated_utc']}。

100 个设计平均 **8,630.38 nt**，范围 **6,176–9,996 nt**；每个设计都是 6HB，最短边设置 42 bp。nt 为定制长度支架加全部订书钉链；不能换成整条 M13 后仍使用此计数。

| 随机抽样状态 | 数量 |
|---|---:|
| 固定抽取 | 20 |
| 已完成最终协议 | {len(finished)} |
| 完成 5,000 步完整势 MD 并通过数值标准 | {len(passed)} |
| 最终协议失败 | {len(failed)} |
| 仍待完成 | {20-len(finished)} |
| 更换过抽样模型 | 0 |

'''
if len(finished)==20:report+=f"最终数值短跑通过率：**{len(passed)}/20 = {len(passed)/20:.0%}**。\n\n"
else:report+='这是部分结果；未完成样本没有计为通过，也未据此推断最终通过率。\n\n'
report+='''全部 100 个模型互相以及相对 TALOS 的 40 个、ATHENA 的 54 个参照 PLY 均无精确图同构匹配。指多面体连接图；全部曲面亏格仍为 0，不是不同曲面拓扑，也不代表全领域文献新颖性。

## 实际模拟协议

oxDNA2，CPU 双精度，300 K，模型盐浓度 0.5 M。先复用成功完成的 1,500 步初始最小化，再按同一规则做最多 3 轮、每轮 1,500 步的增强最小化。增强阶段仅用于准备，骨架力上限 100，并优先保留额外的 0.01 键长缓冲。

仍未就绪时，允许最多两轮、每轮 1,500 步的准备上限 1,000 最小化；逐一检查骨架键处于原生 FENE 允许域内部（约 0.5064–1.0064），随后由完整势 MD 的实际运行判断是否通过。更强上限仍只用于准备阶段；原先达到准备上限的记录完整保留。

生产段 5,000 步，dt=0.001，完整未截断 FENE 势，无外部约束、配对弹簧或骨架力上限。数值通过要求：程序正常退出、末态实际步数为 5,000、所有保存能量和坐标为有限数、每 nt 势能绝对值小于 100。另检查末态全部骨架键，并用 DNAnalysis 对实际轨迹中的设计配对单独计数。

初版较弱准备曾留下过长骨架键，导致完整 FENE 检查拒绝启动；保留这些尝试的日志。最终使用同一 20 个样本和统一增强规则，未通过换模型提高比例。`sampling_protocol.json` 包含冻结清单哈希、随机种子和协议修订原因。

## 结果怎么核对

`sample_results.csv` 给出全部 20 个抽样 ID、状态、实际步数、每 nt 势能范围、设计配对氢键保留比例和回转半径变化。

每个完成目录有 `simulation_result.json`、实际 `.input`、`.log`、`.energy.dat`、`.metrics.dat`、`.trajectory.dat` 和 `.last.dat`。`native_hb.metrics.dat` 来自 DNAnalysis，对 `designed_pairs.txt` 中每一对预期配对逐一评估，并与总氢键数区分。原尝试在 `attempt_01_weak_preparation/`。

未抽中的 80 个结构只完成 TALOS 设计、精确图去重、原生序列/CNDO/oxDNA 数量一致性及格式检查，没有标为动力学通过。

5,000 步只覆盖 5 个 oxDNA 时间单位，属于数值和短时结构保持筛查。**不是实验折叠率、长期稳定性或“没有稳定性损失”的证明。**未进行湿实验，也未对全部序列做二级结构/误配优化。
'''
if passed:
    lo=min(r['native_hb_analysis']['native_hb_final_fraction'] for r in passed);hi=max(r['native_hb_analysis']['native_hb_final_fraction'] for r in passed);rg=max(abs(r['rg_fractional_change']) for r in passed)
    report+=f'\n已通过样本的末态设计氢键保留比例为 **{lo:.2%}–{hi:.2%}**；相对转换初态的最大回转半径变化绝对值为 **{rg:.2%}**。\n'
(OUT/'SUMMARY_zh.md').write_text(report)
from plot_energy import plot
plot()
files=[]
for name in ['README_zh.md','RUN_zh.md','SUMMARY_zh.md','sampling_protocol.json','validation_summary.json','sample_results.csv','sequence_crosscheck.json','attempts_index.json','energy_traces.png']:
    if (OUT/name).exists():files.append(OUT/name)
files+=list((OUT/'reproduce').glob('*.py'))
for x in manifest:
    folder=OUT/'structures'/x['design_id'];files.append(folder/'validation_status.json');files+=list(folder.glob('*.input'))
for r in finished:
    folder=OUT/'structures'/r['folder']
    for p in folder.rglob('*'):
        if p.is_file() and (p.name.startswith(('minimize.','conditioning_','rescue_conditioning_','short_md.','native_hb')) or p.name in ['simulation_result.json','native_bonds.op'] or any(x.startswith('attempt_') for x in p.parts)):files.append(p)
files=list(dict.fromkeys(files));archive=DEL/'DNA_6HB_20_validation.zip';hashes={}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as z:
    for path in files:
        data=path.read_bytes();rel=str(path.relative_to(OUT));hashes[rel]=hashlib.sha256(data).hexdigest();z.writestr('dna_6hb_100/'+rel,data)
    data=json.dumps(finished,indent=2).encode()
    z.writestr('dna_6hb_100/sample_results.json',data);hashes['sample_results.json']=hashlib.sha256(data).hexdigest()
    z.writestr('dna_6hb_100/sample_results_snapshot.json',data);hashes['sample_results_snapshot.json']=hashlib.sha256(data).hexdigest()
    z.writestr('dna_6hb_100/VALIDATION_FILE_SHA256.json',json.dumps(hashes,indent=2))
print(json.dumps({'completed':len(finished),'passed':len(passed),'failed':len(failed),'pending':20-len(finished),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}),flush=True)
