from pathlib import Path
import json,subprocess,time,sys, numpy as np
ROOT=Path(__file__).resolve().parents[1]
EXE=ROOT/'software/bin/oxDNA'

def input_text(stage,conf,steps,seed,cap=None,md=True):
    txt=f'''backend = CPU
backend_precision = double
sim_type = {'MD' if md else 'min'}
interaction_type = DNA2
salt_concentration = 0.5
T = 300K
steps = {steps}
dt = 0.002
verlet_skin = 0.2
topology = design.top
conf_file = {conf}
trajectory_file = {stage}.trajectory.dat
lastconf_file = {stage}.last.dat
energy_file = {stage}.energy.dat
print_conf_interval = {max(1000,steps//4)}
print_energy_every = {max(100,steps//20)}
time_scale = linear
restart_step_counter = 1
refresh_vel = 1
seed = {seed}
no_stdout_energy = 1
external_forces = 0
'''
    if cap is not None:txt+=f'max_backbone_force = {cap}\nmax_backbone_force_far = {cap}\n'
    if md:txt+='thermostat = langevin\ndiff_coeff = 2.5\n'
    else:txt+='minimization_max_step = 0.002\n'
    txt+=f'''data_output_1 = {{
name = {stage}.metrics.dat
print_every = {max(100,steps//20)}
col_1 = {{
type = step
}}
col_2 = {{
type = potential_energy
}}
col_3 = {{
type = hb_list
only_count = true
}}
}}
'''
    return txt

def rgyr(path):
    x=np.loadtxt(path,skiprows=3)[:,:3]
    return float(np.sqrt(np.mean(np.sum((x-x.mean(axis=0))**2,axis=1))))

def run(folder,seed=314159,production_steps=5000,preparation_steps=1500):
    folder=Path(folder).resolve();start=time.time();result={'folder':folder.name,'seed':seed,'status':'failed','stages':[]}
    # A force cap is used only for the two preparation stages. The final test has no cap or external restraints.
    stages=[('minimize','initial.dat',preparation_steps,5,False),('equilibrate','minimize.last.dat',preparation_steps,5,True),('short_md','equilibrate.last.dat',production_steps,None,True)]
    for stage,conf,steps,cap,md in stages:
        inp=folder/(stage+'.input');inp.write_text(input_text(stage,conf,steps,seed,cap,md))
        t=time.time()
        try:
            lastpath=folder/(stage+'.last.dat');logpath=folder/(stage+'.log')
            reuse=False
            if lastpath.exists() and logpath.exists():
                with lastpath.open() as f:saved_step=int(f.readline().split('=')[1])
                reuse=saved_step==steps and 'END OF THE SIMULATION, everything went OK!' in logpath.read_text()
            if not reuse:
                with logpath.open('w') as log:
                    proc=subprocess.run([str(EXE),inp.name],cwd=folder,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
                returncode=proc.returncode
            else:returncode=0
            entry={'stage':stage,'returncode':returncode,'requested_steps':steps,'seconds':round(time.time()-t,3),'capped_backbone_force':cap,'external_forces':False,'reused_completed_stage':reuse}
            result['stages'].append(entry)
            if returncode:
                result['failure_stage']=stage;result['log_tail']=(folder/(stage+'.log')).read_text()[-2500:];break
            energy=np.atleast_2d(np.loadtxt(folder/(stage+'.energy.dat')))
            metrics=np.atleast_2d(np.loadtxt(folder/(stage+'.metrics.dat')))
            coords=np.loadtxt(folder/(stage+'.last.dat'),skiprows=3)
            entry['finite']=bool(np.isfinite(energy).all() and np.isfinite(metrics).all() and np.isfinite(coords).all())
            with lastpath.open() as f:entry['last_step']=int(f.readline().split('=')[1])
            entry['last_energy_time_oxdna']=float(energy[-1,0]);entry['potential_energy_final_per_nt']=float(metrics[-1,1]);entry['hb_count_final']=int(metrics[-1,2])
            if not entry['finite'] or entry['last_step']<steps:
                result['failure_stage']=stage;result['failure_reason']='nonfinite_or_incomplete';break
            if stage=='short_md':
                entry['potential_energy_min_per_nt']=float(metrics[:,1].min());entry['potential_energy_max_per_nt']=float(metrics[:,1].max())
                entry['hb_count_min']=int(metrics[:,2].min())
                if np.max(np.abs(metrics[:,1]))<100:
                    result['status']='passed_short_md'
                else:
                    result['failure_stage']=stage;result['failure_reason']='excessive_absolute_potential_energy_per_nt'
        except Exception as e:result['failure_stage']=stage;result['failure_reason']=str(e);break
    result['seconds']=round(time.time()-start,3)
    if (folder/'short_md.last.dat').exists():
        audit=json.loads((folder/'conversion_audit.json').read_text())
        result['rg_initial_oxdna']=rgyr(folder/'initial.dat');result['rg_final_oxdna']=rgyr(folder/'short_md.last.dat')
        result['rg_fractional_change']=result['rg_final_oxdna']/result['rg_initial_oxdna']-1
        if result['stages'][-1].get('hb_count_final') is not None:result['hb_final_fraction_of_designed_bp']=result['stages'][-1]['hb_count_final']/audit['designed_basepairs']
    (folder/'simulation_result.json').write_text(json.dumps(result,indent=2));return result

if __name__=='__main__':print(json.dumps(run(sys.argv[1],production_steps=int(sys.argv[2]) if len(sys.argv)>2 else 5000),indent=2),flush=True)
