#!/usr/bin/env python3
"""Run the frozen random sample, or one chosen structure, with the bundled protocol."""
from pathlib import Path
import argparse, json, concurrent.futures, shutil
import simulate, protocol_v2

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--oxdna',help='oxDNA executable (default: bundled Linux binary or PATH)')
p.add_argument('--workers',type=int,default=4)
p.add_argument('--design',help='one design ID, e.g. 6hb_033; default: all 20 frozen sample IDs')
a=p.parse_args()
if a.oxdna:simulate.EXE=Path(a.oxdna).resolve()
elif not simulate.EXE.exists():
    found=shutil.which('oxDNA')
    if not found:p.error('oxDNA executable unavailable; extract the software archive or pass --oxdna /absolute/path/oxDNA')
    simulate.EXE=Path(found)
protocol_v2.EXE=simulate.EXE
protocol=json.loads((ROOT/'sampling_protocol.json').read_text())
names=[a.design] if a.design else protocol['sample_design_ids']
for name in names:
    if not (ROOT/'structures'/name/'design.top').exists():p.error('unknown design '+name)

def one(spec):
    i,name=spec
    saved=ROOT/'structures'/name/'simulation_result.json'
    if saved.exists():
        existing=json.loads(saved.read_text())
        last=ROOT/'structures'/name/'short_md.last.dat'
        log=ROOT/'structures'/name/'short_md.log'
        completed_files=last.exists() and log.exists() and 'END OF THE SIMULATION, everything went OK!' in log.read_text()
        if existing.get('protocol_version',0)>=2 and existing.get('status')=='passed_short_md' and completed_files:
            print(name,'reuse completed strict MD result',flush=True)
            return existing
    index=protocol['sample_design_ids'].index(name) if name in protocol['sample_design_ids'] else int(name.split('_')[1])+100
    result=protocol_v2.one((index,name))
    print(name,result['status'],flush=True)
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,a.workers)) as ex:results=list(ex.map(one,enumerate(names)))
if not a.design:(ROOT/'sample_results.json').write_text(json.dumps(results,indent=2))
print(json.dumps({'completed':len(results),'passed':sum(r['status']=='passed_short_md' for r in results)},indent=2))
