from pathlib import Path
import json,time,datetime,shutil,concurrent.futures,subprocess,numpy as np,sys
from simulate import input_text,EXE,rgyr
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT

def backbone_audit(folder,conf):
    x=np.loadtxt(folder/conf,skiprows=3);a1=x[:,3:6];a3=x[:,6:9];back=x[:,:3]-.3400*a1+.3408*np.cross(a3,a1)
    t=[line.split() for line in (folder/'design.top').read_text().splitlines()[1:]]
    pairs=np.array([(i,int(v[2])) for i,v in enumerate(t) if int(v[2])!=-1])
    r=np.linalg.norm(back[pairs[:,0]]-back[pairs[:,1]],axis=1)
    return {'min_backbone_bond':float(r.min()),'max_backbone_bond':float(r.max()),'outside_fene_range':int(sum((r<.5064)|(r>1.0064))),'outside_margin':int(sum((r<.5164)|(r>.9964)))}

def stage(folder,name,conf,steps,seed,cap=None,md=True):
    text=input_text(name,conf,steps,seed,cap,md)
    if md and cap is None:text=text.replace('dt = 0.002','dt = 0.001')
    if not md and cap is not None and cap>=100:text=text.replace('minimization_max_step = 0.002','minimization_max_step = 0.003')
    (folder/(name+'.input')).write_text(text)
    t=time.time()
    with (folder/(name+'.log')).open('w') as log:r=subprocess.run([str(EXE),name+'.input'],cwd=folder,stdout=log,stderr=subprocess.STDOUT,timeout=1000)
    entry={'stage':name,'returncode':r.returncode,'requested_steps':steps,'seconds':round(time.time()-t,3),'capped_backbone_force':cap,'external_forces':False}
    if r.returncode:
        entry['log_tail']=(folder/(name+'.log')).read_text()[-2000:];return entry
    data=np.loadtxt(folder/(name+'.last.dat'),skiprows=3)
    energy=np.atleast_2d(np.loadtxt(folder/(name+'.energy.dat')));metrics=np.atleast_2d(np.loadtxt(folder/(name+'.metrics.dat')))
    with (folder/(name+'.last.dat')).open() as f:step=int(f.readline().split('=')[1])
    entry.update({'finite':bool(np.isfinite(data).all() and np.isfinite(energy).all() and np.isfinite(metrics).all()),'last_step':step,'last_energy_time_oxdna':float(energy[-1,0]),'potential_energy_final_per_nt':float(metrics[-1,1]),'potential_energy_min_per_nt':float(metrics[:,1].min()),'potential_energy_max_per_nt':float(metrics[:,1].max()),'hb_count_final':int(metrics[-1,2]),'hb_count_min':int(metrics[:,2].min())})
    return entry

def one(spec):
    idx,name=spec;folder=OUT/'structures'/name;t=time.time();seed=20261020+idx
    old=folder/'simulation_result.json';attempt=folder/'attempt_01_weak_preparation';attempt.mkdir(exist_ok=True)
    if old.exists() and json.loads(old.read_text()).get('protocol_version',1)<2:shutil.copy2(old,attempt/'result.json')
    for ext in ['input','log']:
        src=folder/('short_md.'+ext)
        if src.exists():shutil.copy2(src,attempt/src.name)
    result={'folder':name,'seed':seed,'protocol_version':3,'status':'failed','stages':[],'production_dt':.001,'production_steps':5000,'external_forces':False}
    conf='minimize.last.dat'
    try:
        # The first-stage minimization is shared, successful, and unchanged for every sampled design.
        if not (folder/'minimize.last.dat').exists() or not (folder/'minimize.log').exists() or 'END OF THE SIMULATION, everything went OK!' not in (folder/'minimize.log').read_text():
            first=stage(folder,'minimize','initial.dat',1500,seed,5,False);result['stages'].append(first)
            if first['returncode'] or not first.get('finite'):raise RuntimeError('Initial minimization failed')
        for k in range(1,6):
            st=f'conditioning_{k}' if k<=3 else f'rescue_conditioning_{k-3}'
            cap=100 if k<=3 else 1000
            entry=stage(folder,st,conf,1500,seed,cap,False);result['stages'].append(entry)
            if entry['returncode'] or not entry.get('finite') or entry.get('last_step')!=1500:
                result['failure_stage']=st;break
            conf=st+'.last.dat';b=backbone_audit(folder,conf);entry.update(b)
            if b['outside_margin']==0 or (cap>=1000 and b['outside_fene_range']==0):break
        else:
            result['failure_stage']='conditioning_limit'
        if not result.get('failure_stage'):
            entry=stage(folder,'short_md',conf,5000,seed,None,True);result['stages'].append(entry)
            if entry['returncode']==0 and entry.get('finite') and entry.get('last_step')==5000 and max(abs(entry['potential_energy_min_per_nt']),abs(entry['potential_energy_max_per_nt']))<100:
                result['status']='passed_short_md'
                audit=json.loads((folder/'conversion_audit.json').read_text());result['hb_final_fraction_of_designed_bp']=entry['hb_count_final']/audit['designed_basepairs'];result['hb_min_fraction_of_designed_bp']=entry['hb_count_min']/audit['designed_basepairs']
                result['rg_initial_oxdna']=rgyr(folder/'initial.dat');result['rg_final_oxdna']=rgyr(folder/'short_md.last.dat');result['rg_fractional_change']=result['rg_final_oxdna']/result['rg_initial_oxdna']-1
            else:result['failure_stage']='short_md'
    except Exception as e:result['failure_reason']=str(e)
    result['seconds']=round(time.time()-t,3);(folder/'simulation_result.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({'design_id':name,'status':result['status'],'failure_stage':result.get('failure_stage'),'seconds':result['seconds'],'hb_fraction':result.get('hb_final_fraction_of_designed_bp'),'conditioning_rounds':sum(x['stage'].startswith('conditioning') for x in result['stages'])}),flush=True)
    return result

if __name__=='__main__':
    raise SystemExit('Use run_validation.py to select a design or the frozen sample.')
