#!/usr/bin/env python3
"""Regenerate native TALOS outputs in a separate directory, preserving supplied files."""
from pathlib import Path
import argparse,json,subprocess,shutil
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--talos');p.add_argument('--design',required=True);a=p.parse_args()
exe=Path(a.talos).resolve() if a.talos else ROOT/'software/bin/TALOS'
if not exe.exists():p.error('Extract the software archive or pass --talos /absolute/path/TALOS')
source=ROOT/'structures'/a.design/'target.ply'
if not source.exists():p.error('unknown design '+a.design)
run=ROOT/'regenerated'/a.design;(run/'input').mkdir(parents=True,exist_ok=True)
shutil.copy2(source,run/'input'/(a.design+'.ply'))
(run/'env.txt').write_text('para_platform linux\npara_cut_stap_method max\npara_min_cut_stap 20\npara_max_cut_stap 60\npara_set_seq_scaf 0\n')
with (run/'talos.log').open('w') as f:r=subprocess.run([str(exe),a.design+'.ply','1','1','42'],cwd=run,stdout=f,stderr=subprocess.STDOUT)
print('TALOS exit',r.returncode,'output',run/'output')
raise SystemExit(r.returncode)
