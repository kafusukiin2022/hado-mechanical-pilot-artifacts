# 运行说明

三个压缩包都以 `dna_6hb_100/` 为根目录。解压到同一父目录即可合并设计、验证结果和软件。

Linux 环境：

```bash
python -m pip install numpy
chmod +x software/bin/*
python reproduce/run_validation.py --workers 4
```

已有 oxDNA 可通过 `--oxdna /absolute/path/oxDNA` 指定。默认复用已经完成的最终完整势 MD 结果；其余结构会先生成初始最小化，按全部骨架键长度决定是否需要更多增强最小化，再运行完整 FENE 势短跑。要重新运行，请先复制整个结构目录，或将已有阶段日志及末态文件移出原目录保留。

单个结构：

```bash
python reproduce/run_validation.py --design 6hb_033 --workers 1
python reproduce/regenerate_talos.py --design 6hb_033
```

TALOS 重生成保存在 `regenerated/`，不会覆盖交付的原生设计文件。

建议使用脚本自动检查骨架键。若已有通过的准备末态，可按实际 `short_md.input` 中的 `conf_file` 手工运行；对未抽样结构，下面展示最多五轮准备的顺序：

```bash
cd structures/6hb_001
../../software/bin/oxDNA minimize.input
../../software/bin/oxDNA conditioning_1.input
../../software/bin/oxDNA conditioning_2.input
../../software/bin/oxDNA conditioning_3.input
../../software/bin/oxDNA rescue_conditioning_1.input
../../software/bin/oxDNA rescue_conditioning_2.input
../../software/bin/oxDNA short_md.input
```

oxDNA 拓扑 `design.top` 与 `initial.dat` 配套，不能混用其他结构的文件。已通过验证的 20 个目录另有 `short_md.last.dat`。未抽样的 80 个目录没有验证通过标记。

`reproduce/pipeline_source/` 保存本次生成、优化、筛选、转换及审计脚本，保留原会话工作区的相对目录布局以便审阅。上面的两个运行入口按交付目录布局编写，可直接使用。

随附二进制为 Ubuntu 24.04 x86_64 CPU 版本；在其他系统可使用源码和本机编译器构建。ATHENA 官方归档包含其原始应用源文件及内嵌工具，本次未验证 GUI 在其他操作系统上的启动。
