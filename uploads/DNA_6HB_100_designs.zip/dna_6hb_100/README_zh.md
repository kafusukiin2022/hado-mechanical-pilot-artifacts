# 100 种轻量 6HB DNA 多面体设计

本包提供 100 套由真实 TALOS 程序生成的设计、DNA 链序列、oxDNA 拓扑及初始坐标。总核苷酸数按**一份设计所需的支架链 + 全部订书钉链**相加，不把 bp 当作 nt，也不只统计支架链。

## 已完成的设计约束

| 项目 | 实际结果 |
|---|---:|
| 结构数 | 100 |
| 100 个结构的总 nt 平均值 | 8,630.38 nt |
| 单个结构总 nt 范围 | 6,176–9,996 nt |
| 边截面 | 蜂窝排列 6HB，逐模型核对为每条几何边 6 条虚拟双螺旋 |
| TALOS 最短边设置 | 42 bp，保留原生最短边限制 |
| 顶点方案 | Flat |
| 订书钉链长度 | 每条均在 20–60 nt 范围内 |
| 支架 | 单条、按各设计实际长度截取的定制序列 |
| 相同连接图的候选对 | 0 / 4,950 次精确图同构比较 |
| 与参照数据集相同的连接图 | 0 / 9,400 次精确图同构比较 |

参照数据集来自下载的 TALOS 内置 40 个 PLY 和 ATHENA 的 54 个 3D PLY。逐项参照图见 `baseline_graphs.json`；审计结果见 `topology_audit.json`。这里的“拓扑不同”指多面体顶点—边连接图不相同（精确无标号图同构），不是坐标、旋转、尺寸或边长变化。全部表面都是 genus 0；不声称它们具有不同的曲面亏格，也不声称在所有已发表文献中首次出现。

## 文件怎么用

每个 `structures/6hb_XXX/` 目录包含：

- `target.ply`：该结构的输入几何，可在 ATHENA 中打开；配合 6HB、Flat、42 bp 参数重新设计。
- `*_15_JSON_caDNAno.json`：TALOS 原生 caDNAno 设计。
- `*_16_CNDO.cndo`：TALOS 原生、具有链连接和碱基配对信息的 CanDo 文件。
- `*_17_sequence.csv`：TALOS 原生序列表。
- `scaffold.fasta`、`strands_5to3.csv`：精确长度的支架和全部链的 5′→3′ 序列。
- `design.top`、`initial.dat`：通过 tacoxDNA 从该 CNDO 转出的 oxDNA 文件。
- `minimize.input`、`conditioning_*.input`、`short_md.input`：初始最小化、增强最小化和正式短跑参数。旧准备阶段文件仅用于失败记录；请使用最终复现脚本。
- `design_audit.json`、`conversion_audit.json`、`talos.log`：真实设计、核苷酸连接与转换检查记录。

支架序列使用 TALOS 的 M13mp18 序列来源，但交付的是**设计实际需要长度的定制支架**。直接使用整条 7,249 nt 的商业 M13 支架会留下额外尾链，不能仍按此处的 nt 总数计算，也不属于本次模拟体系。序列由路由生成，未额外进行序列级误配/二级结构优化。

`initial.dat` 是几何转换的初态，顶点和单链环处可能有高能接触，必须先松弛。不要将它当作已平衡构象直接运行完整 FENE 势的生产模拟。抽样模型在完成后另带 `short_md.last.dat`，可作为已经完成本次短跑的构象。

## 随机抽样与数值检查

100 个设计在模拟前固定，人口清单哈希与随机抽取方法记录在 `sampling_protocol.json`。使用 `numpy.random.default_rng(20261020).choice(100,20,replace=False)`，20 个被抽中样本不因结果失败而更换。抽样结果见 `sample_results.json`；进行中时该文件只包含已完成样本；全部 20 个状态以 `validation_summary.json` 为准。

最终自适应协议（初版较弱松弛留下长骨架键，导致完整 FENE 检查拒绝启动；原尝试日志保留在 `attempt_01_weak_preparation/`，未更换任何抽样模型）：

1. oxDNA2 CPU 双精度；300 K；`salt_concentration = 0.5` M。
2. 先做 1,500 步初始最小化，使用骨架力上限 5；再按统一规则做最多 3 轮、每轮 1,500 步的增强最小化，准备阶段骨架力上限 100，最大位移步幅 0.003。仍未就绪时，允许再做最多 2 轮、每轮 1,500 步的上限 1,000 增强最小化；完整 FENE 生产段不使用这些上限。逐一检查全部骨架键长度处于 oxDNA 原生 FENE 允许范围内部（约 0.5064–1.0064）后才进入正式 MD；默认准备还使用额外的 0.01 缓冲。正式 MD 保留 oxDNA 自身的骨架检查。
3. **5,000 步完整 oxDNA2 MD**；`dt = 0.001`；无骨架力上限，无外部约束或配对弹簧。
4. 按退出码、最终配置的实际步数、全部保存能量/坐标是否为有限数，以及短跑中每 nt 势能绝对值 < 100 判定数值短跑是否通过。另列氢键保留与回转半径变化。

注意：oxDNA 默认 `energy.dat` 的首列是模拟时间；真正步数读取末态配置 `t = ...`，并与 `metrics.dat` 的 `type = step` 对照。该短跑只覆盖 5 个 oxDNA 时间单位，不能证明实验折叠产率、长期稳定性、热稳定性，也不能证明相对其他设计没有刚度损失。

盐参数是 oxDNA2 的模型输入，不应直接当作实验中的二价离子配方。此工作未进行湿实验；未宣称“实验 20 个有 70–80% 成功”。

## 软件与可复现性

源码下载记录与提交号、归档 SHA-256 见 `software_provenance.json`。

- TALOS: https://github.com/lcbb/TALOS ，提交 `816af443d1523263ce2e62a04535d55f55b538b0`。
- ATHENA: https://github.com/lcbb/athena ，提交 `70052339c85c145b7d2e5abb73a4aa0c10a0c689`。
- oxDNA: https://github.com/lorenzo-rovigatti/oxDNA ，提交 `75ae96f063954b2f29524bb897c274aee7ba4466`。
- tacoxDNA: https://github.com/lorenzo-rovigatti/tacoxDNA ，提交 `b8a1706d27548c96dcb13eabc8e5b9340bf241c3`。

TALOS 的输入/路由/序列算法使用下载的原始程序；为 GNU Fortran/Linux 做了语法、控制台命令及输出单元类型兼容，改动清单和源文件随最终包交付。未更改 42 bp 最短边限制、6HB 截面或 FENE 生产势。oxDNA 已通过官方 `test_run` 的 15/15 项测试。

ATHENA 源码已下载，本次在无桌面的环境中使用 TALOS 命令行生成，未启动 ATHENA GUI。ATHENA 的输入 PLY 已全部提供；所附 TALOS v1 命令行与 ATHENA 内嵌新版后端的参数接口不同，勿混用命令行参数。

最终的 `SUMMARY_zh.md`、`sample_results.csv` 与状态文件以实际完成结果为准。未抽中的 80 个模型只完成设计及格式/连接检查，不标记为通过动力学验证。
