# TALOS97 endpoint dataset v1

97designs; input initial.dat t0 before first oxDNA minimization. Target replica1 empirical production mean (not lastframe). Source-only inputs NPZ and supervision labels NPZ are separate. 68train/14validation/15test,seed20261028,size stratified,not shape-held-out. Allrows retained,no trajectories copied. Rebuild:python experiments/talos97_endpoint_v1/scripts/build_dataset.py.

Edge20channels:type5,relative normalized vector3,distance1,componentwise a1*a1(3),a3*a3(3),a1*a3(3),same strand1,axial delta/100(1). Frame vectors are in fixed initial chart; only PaiNN vector backbone has explicitly equivariant readout.
