# TALOS97 mean-coordinate labels
97 label NPZs, matching the uploaded inputs by design ID and topology row. These are replica1 production-trajectory empirical mean configurations (1000 frames), not the final frame, not triplicate pooled means and not RMSF labels.
Use labels/6hb_009.npz with inputs/6hb_009.npz. NPZ fields and coordinate normalization follow the original dataset builder. The original dataset README, manifest and split are included. Source NPZ files are byte-identical to the verified endpoint-v1 dataset. SHA256SUMS.json provides per-label checksums.
