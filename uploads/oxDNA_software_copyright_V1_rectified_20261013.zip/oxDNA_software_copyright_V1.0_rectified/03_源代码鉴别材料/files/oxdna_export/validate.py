import math
from dataclasses import dataclass
from typing import List

from .io import OxDNAFrame, OxDNATopology, Vector3


@dataclass(frozen=True)
class ValidationReport:
    ok: bool
    errors: List[str]
    warnings: List[str]


def validate_frame(
    topology: OxDNATopology,
    frame: OxDNAFrame,
    unit_tolerance: float = 1e-3,
    orthogonality_tolerance: float = 1e-3,
    box_margin: float = 0.0,
    require_box_containment: bool = False,
) -> ValidationReport:
    errors = []
    warnings = []

    if len(frame.rows) != topology.num_nucleotides:
        errors.append(
            "row count mismatch: topology has {}, frame has {}".format(
                topology.num_nucleotides, len(frame.rows)
            )
        )

    if not _all_finite(frame.box):
        errors.append("box contains non-finite values")
    elif any(value <= 0.0 for value in frame.box):
        errors.append("box dimensions must be positive")

    for idx, row in enumerate(frame.rows):
        labeled_vectors = [
            ("position", row.position),
            ("a1", row.a1),
            ("a3", row.a3),
            ("velocity", row.velocity),
            ("angular_velocity", row.angular_velocity),
        ]
        for label, vector in labeled_vectors:
            if not _all_finite(vector):
                errors.append("row {} {} contains non-finite values".format(idx, label))

        if _all_finite(row.a1):
            a1_norm = _norm(row.a1)
            if abs(a1_norm - 1.0) > unit_tolerance:
                errors.append("row {} a1 is not unit length: {:.6g}".format(idx, a1_norm))
        if _all_finite(row.a3):
            a3_norm = _norm(row.a3)
            if abs(a3_norm - 1.0) > unit_tolerance:
                errors.append("row {} a3 is not unit length: {:.6g}".format(idx, a3_norm))
        if _all_finite(row.a1) and _all_finite(row.a3):
            dot = _dot(row.a1, row.a3)
            if abs(dot) > orthogonality_tolerance:
                errors.append("row {} a1/a3 are not orthogonal: dot={:.6g}".format(idx, dot))

        if _all_finite(row.position) and _all_finite(frame.box):
            for axis, (coord, box) in enumerate(zip(row.position, frame.box)):
                if coord < -box_margin or coord > box + box_margin:
                    message = "row {} position axis {} is outside box: {:.6g} not in [{:.6g}, {:.6g}]".format(
                            idx, axis, coord, -box_margin, box + box_margin
                    )
                    if require_box_containment:
                        errors.append(message)
                    else:
                        warnings.append(message)
                    break

    return ValidationReport(ok=not errors, errors=errors, warnings=warnings)


def _all_finite(vector: Vector3) -> bool:
    return all(math.isfinite(value) for value in vector)


def _norm(vector: Vector3) -> float:
    return math.sqrt(_dot(vector, vector))


def _dot(left: Vector3, right: Vector3) -> float:
    return sum(a * b for a, b in zip(left, right))
