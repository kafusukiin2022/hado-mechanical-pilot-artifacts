from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple


Vector3 = Tuple[float, float, float]


@dataclass(frozen=True)
class OxDNATopologyRow:
    strand_id: int
    base: str
    prev_idx: int
    next_idx: int


@dataclass(frozen=True)
class OxDNATopology:
    num_nucleotides: int
    num_strands: int
    rows: List[OxDNATopologyRow]


@dataclass(frozen=True)
class OxDNAConfigRow:
    position: Vector3
    a1: Vector3
    a3: Vector3
    velocity: Vector3
    angular_velocity: Vector3


@dataclass(frozen=True)
class OxDNAFrame:
    time: str
    box: Vector3
    energy: str
    rows: List[OxDNAConfigRow]


def read_topology(path: str) -> OxDNATopology:
    with open(path, "r") as handle:
        header = handle.readline().split()
        if len(header) < 2:
            raise ValueError("Invalid oxDNA topology header")
        num_nucleotides = int(header[0])
        num_strands = int(header[1])

        rows = []
        for row_idx in range(num_nucleotides):
            parts = handle.readline().split()
            if len(parts) < 4:
                raise ValueError("Invalid topology row {}".format(row_idx + 2))
            rows.append(
                OxDNATopologyRow(
                    strand_id=int(parts[0]),
                    base=parts[1].upper(),
                    prev_idx=int(parts[2]),
                    next_idx=int(parts[3]),
                )
            )

    if len(rows) != num_nucleotides:
        raise ValueError("Topology row count does not match header")
    return OxDNATopology(num_nucleotides, num_strands, rows)


def read_config(path: str, expected_rows: Optional[int] = None) -> OxDNAFrame:
    with open(path, "r") as handle:
        time_line = handle.readline()
        box_line = handle.readline()
        energy_line = handle.readline()
        if not time_line or not box_line or not energy_line:
            raise ValueError("Incomplete oxDNA configuration header")
        time = _parse_header_value(time_line, "t")
        box_values = _parse_header_value(box_line, "b").split()
        if len(box_values) < 3:
            raise ValueError("Invalid oxDNA box header")
        box = _vector3(box_values[:3])
        energy = _parse_header_value(energy_line, "E")

        rows = []
        for line_idx, line in enumerate(handle, start=4):
            if not line.strip():
                continue
            parts = line.split()
            if len(parts) < 15:
                raise ValueError("Configuration row {} has fewer than 15 columns".format(line_idx))
            values = [float(part) for part in parts[:15]]
            rows.append(
                OxDNAConfigRow(
                    position=tuple(values[0:3]),
                    a1=tuple(values[3:6]),
                    a3=tuple(values[6:9]),
                    velocity=tuple(values[9:12]),
                    angular_velocity=tuple(values[12:15]),
                )
            )

    if expected_rows is not None and len(rows) != expected_rows:
        raise ValueError(
            "Configuration has {} rows, expected {}".format(len(rows), expected_rows)
        )
    return OxDNAFrame(time=time, box=box, energy=energy, rows=rows)


def write_config(frame: OxDNAFrame, path: str) -> None:
    with open(path, "w") as handle:
        handle.write("t = {}\n".format(frame.time))
        handle.write("b = {}\n".format(_format_vector(frame.box)))
        handle.write("E = {}\n".format(frame.energy))
        for row in frame.rows:
            values = (
                row.position
                + row.a1
                + row.a3
                + row.velocity
                + row.angular_velocity
            )
            handle.write("{}\n".format(_format_vector(values)))


def _parse_header_value(line: str, key: str) -> str:
    prefix = "{} =".format(key)
    if not line.startswith(prefix):
        raise ValueError("Expected header '{}' but got {!r}".format(prefix, line.rstrip()))
    return line.split("=", 1)[1].strip()


def _vector3(values: Sequence[str]) -> Vector3:
    return (float(values[0]), float(values[1]), float(values[2]))


def _format_vector(values: Sequence[float]) -> str:
    return " ".join("{:.12g}".format(value) for value in values)
