#!/usr/bin/env python3
"""Build checksum-bound target-free design-edge sidecars for a manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ebd_oxdna.design_edges import build_design_edge_sidecar
from ebd_oxdna.design_edges import sha256_file


INDEX_SCHEMA = "ebd_oxdna.design_edge_sidecar_index"
INDEX_SCHEMA_VERSION = 1
_SAFE_ID = re.compile(r"^[A-Za-z0-9_.-]+$")


def _json_bytes(payload):
    return (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _write_atomic(path, data):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(data)
    os.replace(str(temporary), str(path))


def build_sidecars(
    manifest_path,
    output_dir,
    include_start_spatial=False,
    spatial_cutoff=8.0,
    max_spatial_neighbors=12,
):
    manifest_path = Path(manifest_path).absolute()
    output_dir = Path(output_dir).absolute()
    try:
        entries = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError("invalid training manifest {}: {}".format(manifest_path, exc)) from exc
    if not isinstance(entries, list) or not entries:
        raise ValueError("training manifest must be a nonempty list")
    indexed = {}
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("training manifest entries must be objects")
        sample_id = str(entry.get("id") or "")
        if not _SAFE_ID.fullmatch(sample_id):
            raise ValueError("unsafe or missing sample id {!r}".format(sample_id))
        if sample_id in indexed:
            raise ValueError("duplicate sample id {!r}".format(sample_id))
        indexed[sample_id] = entry

    built = {}
    totals = {name: 0 for name in ("base_pair", "crossover", "duplex_step", "start_spatial")}
    for sample_id in sorted(indexed):
        sidecar = build_design_edge_sidecar(
            indexed[sample_id],
            include_start_spatial=include_start_spatial,
            spatial_cutoff=spatial_cutoff,
            max_spatial_neighbors=max_spatial_neighbors,
        )
        built[sample_id] = sidecar
        for name in totals:
            totals[name] += sidecar["counts"][name]

    output_dir.mkdir(parents=True, exist_ok=True)
    sidecar_dir = output_dir / "sidecars"
    sidecar_dir.mkdir(parents=True, exist_ok=True)
    index_records = {}
    inventory = {}
    for sample_id in sorted(built):
        path = sidecar_dir / "{}.design_edges.json".format(sample_id)
        data = _json_bytes(built[sample_id])
        _write_atomic(path, data)
        relative = str(path.relative_to(output_dir))
        digest = hashlib.sha256(data).hexdigest()
        inventory[relative] = digest
        index_records[sample_id] = {
            "path": str(path),
            "sha256": digest,
            "fingerprint": built[sample_id]["fingerprint"],
            "counts": built[sample_id]["counts"],
        }

    index = {
        "schema": INDEX_SCHEMA,
        "schema_version": INDEX_SCHEMA_VERSION,
        "manifest": str(manifest_path),
        "manifest_sha256": sha256_file(manifest_path),
        "include_start_spatial": bool(include_start_spatial),
        "spatial_cutoff": float(spatial_cutoff),
        "max_spatial_neighbors": int(max_spatial_neighbors),
        "sidecar_count": len(index_records),
        "sidecars": index_records,
    }
    report = {
        "schema": "ebd_oxdna.design_edge_sidecar_report",
        "schema_version": 1,
        "manifest": str(manifest_path),
        "manifest_sha256": index["manifest_sha256"],
        "sample_count": len(index_records),
        "source_kind_counts": {"explicit_design": len(index_records)},
        "target_dependency_count": 0,
        "edge_totals": totals,
        "include_start_spatial": bool(include_start_spatial),
    }
    for filename, payload in (
        ("design_edge_sidecars.json", index),
        ("design_edge_report.json", report),
    ):
        data = _json_bytes(payload)
        _write_atomic(output_dir / filename, data)
        inventory[filename] = hashlib.sha256(data).hexdigest()
    inventory_lines = [
        "{}  {}".format(inventory[name], name) for name in sorted(inventory)
    ]
    inventory_lines.append("{}  {}".format(index["manifest_sha256"], manifest_path))
    _write_atomic(
        output_dir / "ARTIFACT_SHA256SUMS",
        ("\n".join(inventory_lines) + "\n").encode("utf-8"),
    )
    return report


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--include-start-spatial", action="store_true")
    parser.add_argument("--spatial-cutoff", type=float, default=8.0)
    parser.add_argument("--max-spatial-neighbors", type=int, default=12)
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    report = build_sidecars(
        args.manifest,
        args.output_dir,
        include_start_spatial=args.include_start_spatial,
        spatial_cutoff=args.spatial_cutoff,
        max_spatial_neighbors=args.max_spatial_neighbors,
    )
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
