#!/usr/bin/env python3
import faulthandler
import argparse
import hashlib
import json
import math
import os
import pickle
import random
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

faulthandler.enable(all_threads=True)

from ebd_oxdna.adapter import load_oxdna_sample
from ebd_oxdna.decoder import decode_to_oxdna_frame
from ebd_oxdna.defect_dataset import load_optional_defect_contract
from ebd_oxdna.defect_features import DEFECT_CHANNELS
from ebd_oxdna.defect_features import DEFECT_FEATURE_SCHEMA
from ebd_oxdna.defect_features import DEFECT_NORMALIZATION
from ebd_oxdna.design_edges import build_typed_graph
from ebd_oxdna.design_edges import load_design_edge_sidecar
from ebd_oxdna.design_edges import load_design_edge_sidecar_index
from ebd_oxdna.physical_metrics import compute_wc_helix_metrics
from ebd_oxdna.physical_metrics import build_reference_duplex_geometry
from ebd_oxdna.physical_metrics import _build_duplex_steps
from ebd_oxdna.physical_metrics import reference_nonpair_repulsion_loss
from ebd_oxdna.physical_metrics import reference_pair_assignment_margin_loss
from ebd_oxdna.physical_metrics import reference_pair_axis_loss
from ebd_oxdna.physical_metrics import reference_pair_center_loss
from ebd_oxdna.physical_metrics import reference_pair_conflict_loss
from ebd_oxdna.physical_metrics import reference_pair_frame_loss
from ebd_oxdna.physical_metrics import reference_helix_step_axis_loss
from ebd_oxdna.physical_metrics import reference_helix_step_distance_loss
from ebd_oxdna.physical_metrics import reference_pair_distance_loss
from ebd_oxdna.physical_metrics import soft_partner_exclusivity_loss
from ebd_oxdna.oxdna_energy_loss import OxDNAEnergyConfig
from ebd_oxdna.oxdna_energy_loss import oxdna_energy_loss
from ebd_oxdna.shared_rigid_bundle import build_inference_bundle
from ebd_oxdna.shared_rigid_bundle import write_inference_bundle
from oxdna_export.io import write_config
from oxdna_export.validate import validate_frame
from scripts.ebd_oxdna_egnn_overfit import (
    WandbRun,
    _build_electrostatic_edges,
    _build_identity_inputs,
    _build_shared_rigid_features,
    _electrostatic_energy,
    _orientation_score,
    _orthonormalize_frame,
    _positions_from_tensor,
    _rmsd_tensor,
    _torch_memory_summary,
)


BASE_EDGE_FEATURE_NAMES = [
    "relative_x",
    "relative_y",
    "relative_z",
    "relative_distance",
    "same_strand",
    "backbone",
    "cross_strand",
    "complementary",
    "local_index_delta",
    "direction_compatibility",
]

TARGET_SCHEMA = {
    "endpoint_positions": {"units": "oxDNA", "optional": True},
    "mean_positions": {"units": "oxDNA", "optional": True},
    "rmsf": {"units": "oxDNA", "optional": True},
    "pca": {"units": "oxDNA^2", "optional": True},
    "k_eff": {"units": "force/length", "optional": True},
}


def _log_wandb_epoch(wandb_run, epoch, record, learning_rate, val_record=None):
    if getattr(wandb_run, "_wandb", None) is None:
        return
    payload = {
        "train/loss": record["loss"],
        "train/position_loss": record["position_loss"],
        "train/rmsd": record["rmsd"],
        "train/orientation_loss": record["orientation_loss"],
        "train/os": record["os"],
        "train/conflict_rate": record["conflict_rate"],
        "train/oxdna_energy_loss": record.get("oxdna_energy_loss", 0.0),
        "train/lr": learning_rate,
    }
    if val_record is not None:
        if val_record.get("loss") is not None:
            payload["val/loss"] = val_record["loss"]
        if val_record.get("position_loss") is not None:
            payload["val/position_loss"] = val_record["position_loss"]
        if val_record.get("orientation_loss") is not None:
            payload["val/orientation_loss"] = val_record["orientation_loss"]
        if val_record.get("rmsd") is not None:
            payload["val/rmsd"] = val_record["rmsd"]
        if val_record.get("os") is not None:
            payload["val/os"] = val_record["os"]
        if val_record.get("conflict_rate") is not None:
            payload["val/conflict_rate"] = val_record["conflict_rate"]
        if val_record.get("oxdna_energy_loss") is not None:
            payload["val/oxdna_energy_loss"] = val_record["oxdna_energy_loss"]
    wandb_run._wandb.log(payload, step=epoch)


def _legacy_duplex_losses_enabled(args):
    return bool(getattr(args, "enable_legacy_duplex_losses", False))


def _final_physical_metrics_enabled(args):
    return bool(getattr(args, "compute_final_physical_metrics", False))


def _log_wandb_summary(wandb_run, summary, sample_summaries):
    if getattr(wandb_run, "_wandb", None) is None:
        return

    train_samples = [sample for sample in sample_summaries if sample["split"] == "train"]
    val_samples = [sample for sample in sample_summaries if sample["split"] == "val"]

    def _mean_metric(samples, key):
        if not samples:
            return None
        return sum(float(sample[key]) for sample in samples) / float(len(samples))

    def _mean_assignment_metric(samples, key):
        values = []
        for sample in samples:
            metrics = sample.get("pair_logit_assignment_metrics") or {}
            value = metrics.get(key)
            if value is not None:
                values.append(float(value))
        if not values:
            return None
        return sum(values) / float(len(values))

    payload = {
        "summary/elapsed_seconds": summary["elapsed_seconds"],
        "summary/epochs_ran": summary["epochs_ran"],
        "summary/num_samples": summary["num_samples"],
        "summary/num_train_samples": summary["num_train_samples"],
        "summary/num_val_samples": summary["num_val_samples"],
        "summary/train_mean_final_rmsd": _mean_metric(train_samples, "final_rmsd"),
        "summary/train_mean_final_os": _mean_metric(train_samples, "final_os"),
        "summary/train_mean_decoded_pair_f1": _mean_assignment_metric(train_samples, "decoded_pair_f1"),
        "summary/val_mean_final_rmsd": _mean_metric(val_samples, "final_rmsd"),
        "summary/val_mean_final_os": _mean_metric(val_samples, "final_os"),
        "summary/val_mean_decoded_pair_f1": _mean_assignment_metric(val_samples, "decoded_pair_f1"),
    }
    if "cuda_max_allocated_mib" in summary:
        payload["summary/cuda_max_allocated_mib"] = summary["cuda_max_allocated_mib"]
    if "cuda_max_reserved_mib" in summary:
        payload["summary/cuda_max_reserved_mib"] = summary["cuda_max_reserved_mib"]
    wandb_run._wandb.log(payload)


def _timing_log(enabled, label, seconds):
    if enabled:
        print("timing phase={} seconds={:.6f}".format(label, seconds), flush=True)


def _debug_phase_log(enabled, epoch, sample_id, phase, seconds):
    if enabled:
        print(
            "timing phase=train_sample_{} epoch={} id={} seconds={:.6f}".format(
                phase,
                epoch,
                sample_id,
                seconds,
            ),
            flush=True,
        )


def _chunked_pair_head_logits(torch, pair_head, pos_h, ori_h, row, col, graph_edge_features, chunk_size=8192):
    total_edges = int(row.shape[0])
    if total_edges == 0:
        return torch.empty((0,), dtype=pos_h.dtype, device=pos_h.device)
    if chunk_size is None or chunk_size <= 0 or total_edges <= chunk_size:
        edge_inputs = torch.cat([pos_h[row], ori_h[row], pos_h[col], ori_h[col], graph_edge_features], dim=1)
        return pair_head(edge_inputs).squeeze(1)
    logits = []
    for start_idx in range(0, total_edges, chunk_size):
        end_idx = min(start_idx + chunk_size, total_edges)
        edge_inputs = torch.cat(
            [
                pos_h[row[start_idx:end_idx]],
                ori_h[row[start_idx:end_idx]],
                pos_h[col[start_idx:end_idx]],
                ori_h[col[start_idx:end_idx]],
                graph_edge_features[start_idx:end_idx],
            ],
            dim=1,
        )
        logits.append(pair_head(edge_inputs).squeeze(1))
    return torch.cat(logits, dim=0)


def _model_forward(model, args, features, inputs, active):
    if args.model_kind == "dgnn-lite":
        outputs = model(
            features,
            inputs["x_a"],
            active["start_a1"],
            active["start_a3"],
            active["position_scale"],
            active["graph_edges"],
            active["graph_edge_features"],
            active["candidate_wc_edge_mask"],
        )
    elif args.model_kind == "dgnn-physic":
        outputs = model(
            features,
            inputs["x_a"],
            active["start_a1"],
            active["start_a3"],
            active["position_scale"],
            active["graph_edges"],
            active["graph_edge_features"],
            active["edge_relation_ids"],
        )
    else:
        outputs = model(
            features,
            inputs["x_a"],
            active["start_a1"],
            active["start_a3"],
            active["position_scale"],
            active["graph_edges"] if args.model_kind == "graph-shared" else None,
        )
    if isinstance(outputs, tuple) and len(outputs) == 4:
        pred_positions, pred_a1, pred_a3, aux_outputs = outputs
        return pred_positions, pred_a1, pred_a3, aux_outputs
    pred_positions, pred_a1, pred_a3 = outputs
    return pred_positions, pred_a1, pred_a3, {}


def _apply_start_rmsd_residual_gate(torch, args, active, pred_positions, pred_a1, pred_a3):
    threshold = getattr(args, "start_rmsd_residual_gate_threshold", 0.0)
    if threshold <= 0.0:
        return pred_positions, pred_a1, pred_a3, torch.ones((), dtype=pred_positions.dtype, device=pred_positions.device)
    sharpness = max(float(getattr(args, "start_rmsd_residual_gate_sharpness", 1.0)), 1e-6)
    min_scale = float(getattr(args, "start_rmsd_residual_min_scale", 0.0))
    min_scale = min(max(min_scale, 0.0), 1.0)
    inputs = active["inputs"]
    start_rmsd = _rmsd_tensor(inputs["x_a"], inputs["target_x_a"])
    gate = torch.sigmoid((start_rmsd - float(threshold)) / sharpness)
    gate = min_scale + (1.0 - min_scale) * gate
    gated_positions = inputs["x_a"] + gate * (pred_positions - inputs["x_a"])
    gated_a1, gated_a3 = _orthonormalize_frame(
        torch,
        active["start_a1"] + gate * (pred_a1 - active["start_a1"]),
        active["start_a3"] + gate * (pred_a3 - active["start_a3"]),
    )
    return gated_positions, gated_a1, gated_a3, gate


def _forward_with_residual_gate(torch, model, args, features, inputs, active):
    pred_positions, pred_a1, pred_a3, aux_outputs = _model_forward(
        model,
        args,
        features,
        inputs,
        active,
    )
    pred_positions, pred_a1, pred_a3, gate = _apply_start_rmsd_residual_gate(
        torch,
        args=args,
        active=active,
        pred_positions=pred_positions,
        pred_a1=pred_a1,
        pred_a3=pred_a3,
    )
    aux_outputs["residual_gate_scale"] = gate
    return pred_positions, pred_a1, pred_a3, aux_outputs


def _evaluate_validation_metrics(
    torch,
    model,
    prepared_samples,
    train_id_set,
    args,
    evaluation_id_set=None,
):
    val_rmsd_values = []
    val_os_values = []
    val_position_loss_values = []
    val_orientation_loss_values = []
    val_total_loss_values = []
    val_conflict_values = []
    val_oxdna_energy_values = []
    model.eval()
    inference_context = getattr(torch, "inference_mode", torch.no_grad)
    with inference_context():
        for prepared in prepared_samples:
            include_sample = False
            if args.split_mode == "sample":
                sample_id = prepared["entry"]["id"]
                include_sample = (
                    sample_id in evaluation_id_set
                    if evaluation_id_set is not None
                    else sample_id not in train_id_set
                )
            else:
                include_sample = int(prepared["node_val_mask"].sum().detach().cpu()) > 0
            if not include_sample:
                continue
            active = _prepared_on_device(torch, prepared, args.device) if args.stage_samples_on_cpu else prepared
            inputs = active["inputs"]
            train_features = _feature_noise(torch, active["features"], args.feature_noise_std, training=True)
            pred_positions, pred_a1, pred_a3, aux_outputs = _forward_with_residual_gate(
                torch,
                model,
                args,
                train_features,
                inputs,
                active,
            )
            mask = active["node_val_mask"] if args.split_mode == "node" else None
            rmsd = _masked_rmsd(torch, pred_positions, inputs["target_x_a"], mask)
            os_score = _masked_orientation_score(
                torch,
                pred_a1,
                pred_a3,
                inputs["target_a1"],
                inputs["target_a3"],
                mask,
            )
            position_error = pred_positions - inputs["target_x_a"]
            if mask is not None:
                position_error = position_error[mask]
            position_loss = torch.mean(position_error ** 2)
            orientation_loss = 1.0 - os_score
            position_loss = _mask_optional_target_loss(
                torch,
                position_loss,
                active.get("target_masks"),
                "endpoint_positions",
            )
            orientation_loss = _mask_optional_target_loss(
                torch,
                orientation_loss,
                active.get("target_masks"),
                "endpoint_positions",
            )
            pair_classification_loss = (
                _pair_classification_loss(
                    torch,
                    active,
                    aux_outputs.get("pair_logits"),
                )
                if args.pair_classification_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_logit_exclusivity_loss = (
                _pair_logit_exclusivity_loss(
                    torch,
                    active,
                    aux_outputs.get("pair_logits"),
                )
                if args.pair_logit_exclusivity_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_logit_symmetry_loss = (
                _pair_logit_symmetry_loss(
                    torch,
                    active,
                    aux_outputs.get("pair_logits"),
                )
                if args.pair_logit_symmetry_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            electrostatic_energy = (
                _electrostatic_energy(
                    torch,
                    pred_positions,
                    active["electrostatic_edges"],
                    args.electrostatic_debye_length,
                    args.electrostatic_coefficient,
                )
                if args._active_electrostatic_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            oxdna_energy = (
                _compute_oxdna_energy_loss(torch, args, active, pred_positions, pred_a1, pred_a3).total
                if args._active_oxdna_energy_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            loss = (
                position_loss
                + args._active_orientation_loss_weight * orientation_loss
                + args.pair_classification_loss_weight * pair_classification_loss
                + args.pair_logit_exclusivity_loss_weight * pair_logit_exclusivity_loss
                + args.pair_logit_symmetry_loss_weight * pair_logit_symmetry_loss
                + args._active_electrostatic_loss_weight * electrostatic_energy
                + args._active_oxdna_energy_loss_weight * oxdna_energy
            )
            if not torch.isnan(rmsd):
                val_rmsd_values.append(float(rmsd.detach().cpu()))
            if not torch.isnan(os_score):
                val_os_values.append(float(os_score.detach().cpu()))
            if not torch.isnan(position_loss):
                val_position_loss_values.append(float(position_loss.detach().cpu()))
            if not torch.isnan(orientation_loss):
                val_orientation_loss_values.append(float(orientation_loss.detach().cpu()))
            if not torch.isnan(loss):
                val_total_loss_values.append(float(loss.detach().cpu()))
            if not torch.isnan(oxdna_energy):
                val_oxdna_energy_values.append(float(oxdna_energy.detach().cpu()))
            conflict_rate = _training_conflict_rate(torch, active, pred_positions, args)
            val_conflict_values.append(float(conflict_rate))
    if not val_rmsd_values and not val_os_values and not val_total_loss_values:
        return None
    return {
        "loss": sum(val_total_loss_values) / float(len(val_total_loss_values)) if val_total_loss_values else None,
        "position_loss": sum(val_position_loss_values) / float(len(val_position_loss_values)) if val_position_loss_values else None,
        "orientation_loss": sum(val_orientation_loss_values) / float(len(val_orientation_loss_values)) if val_orientation_loss_values else None,
        "rmsd": sum(val_rmsd_values) / float(len(val_rmsd_values)) if val_rmsd_values else None,
        "os": sum(val_os_values) / float(len(val_os_values)) if val_os_values else None,
        "conflict_rate": sum(val_conflict_values) / float(len(val_conflict_values)) if val_conflict_values else None,
        "oxdna_energy_loss": sum(val_oxdna_energy_values) / float(len(val_oxdna_energy_values)) if val_oxdna_energy_values else None,
    }


def _compute_oxdna_energy_loss(torch, args, active, pred_positions, pred_a1, pred_a3):
    inputs = active["inputs"]
    config = OxDNAEnergyConfig(
        backbone_weight=args.oxdna_energy_backbone_weight,
        stacking_weight=args.oxdna_energy_stacking_weight,
        hbond_weight=args.oxdna_energy_hbond_weight,
        cross_stack_weight=args.oxdna_energy_cross_stack_weight,
        excluded_volume_weight=args.oxdna_energy_excluded_volume_weight,
        excluded_volume_cutoff=args.oxdna_energy_excluded_volume_cutoff,
        excluded_volume_softness=args.oxdna_energy_excluded_volume_softness,
        excluded_volume_max_pairs=args.oxdna_energy_excluded_volume_max_pairs,
    )
    return oxdna_energy_loss(
        torch,
        pred_positions=pred_positions,
        pred_a1=pred_a1,
        pred_a3=pred_a3,
        target_positions=inputs["target_x_a"],
        target_a1=inputs["target_a1"],
        target_a3=inputs["target_a3"],
        backbone_edges=active["backbone_edges"],
        reference_pairs=active["reference_pairs"],
        helix_steps=active["helix_steps"],
        config=config,
    )


def _mlp_layers(torch, dims, dropout):
    layers = []
    for index in range(len(dims) - 1):
        layers.append(torch.nn.Linear(dims[index], dims[index + 1]))
        if index < len(dims) - 2:
            layers.append(torch.nn.SiLU())
            if dropout > 0:
                layers.append(torch.nn.Dropout(dropout))
    return torch.nn.Sequential(*layers)


def _feature_noise(torch, features, std, training):
    if not training or std <= 0:
        return features
    return features + torch.randn_like(features) * std


def _loss_weight_scale(epoch, total_epochs, ramp_epochs):
    if ramp_epochs <= 0:
        return 1.0
    capped = min(max(epoch, 1), total_epochs)
    return min(1.0, float(capped) / float(max(1, ramp_epochs)))


def _zero_like_loss(torch, reference_tensor):
    return torch.zeros((), dtype=reference_tensor.dtype, device=reference_tensor.device)


def _mask_optional_target_loss(torch, loss, target_masks, target_name):
    """Apply an explicit scalar target mask without synthesizing a label."""

    del torch
    if target_masks is None:
        target_masks = {}
    mask = target_masks.get(target_name, target_name == "endpoint_positions")
    if type(mask) is not bool:
        raise ValueError("target mask {} must be boolean".format(target_name))
    return loss * float(mask)


def _epoch_part_values(parts):
    return tuple(float(part.detach().cpu()) if hasattr(part, "detach") else float(part) for part in parts)


def _build_scheduler(torch, optimizer, scheduler_name, total_epochs, warmup_epochs, min_lr_scale):
    if scheduler_name == "none":
        return None

    def _lr_lambda(epoch_index):
        step = epoch_index + 1
        if warmup_epochs > 0 and step <= warmup_epochs:
            return float(step) / float(max(1, warmup_epochs))
        if total_epochs <= warmup_epochs:
            return 1.0
        progress = float(step - warmup_epochs) / float(max(1, total_epochs - warmup_epochs))
        progress = min(max(progress, 0.0), 1.0)
        cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
        return min_lr_scale + (1.0 - min_lr_scale) * cosine

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=_lr_lambda)


def _clone_state_dict(value):
    if isinstance(value, dict):
        return {key: _clone_state_dict(item) for key, item in value.items()}
    if hasattr(value, "detach"):
        return value.detach().clone()
    return value


def build_checkpoint_metadata(
    args,
    defect_feature_schema=None,
    relation_vocabulary=None,
    target_schema=None,
    split_audit_hash=None,
):
    """Build JSON-safe preprocessing metadata stored inside each checkpoint."""

    if defect_feature_schema is None:
        defect_feature_schema = DEFECT_FEATURE_SCHEMA
    if relation_vocabulary is None:
        relation_vocabulary = ["default", "cut_backbone"]
    if target_schema is None:
        target_schema = TARGET_SCHEMA
    if split_audit_hash is None:
        split_audit_hash = getattr(args, "split_audit_hash", None)
    return {
        "schema": "ebd_oxdna.shared_rigid_checkpoint_metadata",
        "schema_version": 1,
        "legacy_feature_dimension": bool(
            getattr(args, "legacy_feature_dimension", False)
        ),
        "defect_feature_schema": json.loads(
            json.dumps(defect_feature_schema, sort_keys=True)
        ),
        "relation_vocabulary": list(relation_vocabulary),
        "normalization_constants": json.loads(
            json.dumps(DEFECT_NORMALIZATION, sort_keys=True)
        ),
        "target_schema": json.loads(json.dumps(target_schema, sort_keys=True)),
        "split_audit_hash": split_audit_hash,
        "static_graph_cache_schema": 1,
    }


def _extract_model_state_dict(checkpoint):
    if not isinstance(checkpoint, dict):
        raise ValueError("checkpoint must contain a state dictionary")
    state_dict = checkpoint.get("model_state_dict")
    return state_dict if isinstance(state_dict, dict) else checkpoint


def _save_model_state_dict(
    torch,
    path,
    state_dict,
    checkpoint_metadata=None,
):
    if not path:
        return
    directory = os.path.dirname(os.path.abspath(path))
    if directory:
        os.makedirs(directory, exist_ok=True)
    payload = state_dict
    if checkpoint_metadata is not None:
        payload = {
            "checkpoint_schema": "ebd_oxdna.shared_rigid_checkpoint",
            "checkpoint_schema_version": 1,
            "model_state_dict": state_dict,
            "checkpoint_metadata": checkpoint_metadata,
        }
    torch.save(payload, path)


def _paths_alias(left, right):
    left_path = os.path.realpath(os.path.abspath(left))
    right_path = os.path.realpath(os.path.abspath(right))
    if left_path == right_path:
        return True
    if os.path.exists(left_path) and os.path.exists(right_path):
        try:
            return os.path.samefile(left_path, right_path)
        except OSError:
            return False
    return False


def _validate_training_file_paths(args, entries, assignment_realized_variants):
    destinations = [
        ("summary JSON", args.summary_json),
        (
            "training manifest snapshot",
            os.path.join(args.output_dir, "training_manifest_snapshot.json"),
        ),
        (
            "inference bundle",
            args.save_inference_bundle
            or os.path.join(args.output_dir, "inference_bundle.json"),
        ),
    ]
    if args.save_model_state:
        destinations.append(("final checkpoint", args.save_model_state))
    if args.save_best_model_state:
        destinations.append(("best checkpoint", args.save_best_model_state))

    for entry in entries:
        sample_id = entry["id"]
        destinations.append(
            (
                "prediction for {}".format(sample_id),
                os.path.join(args.output_dir, "{}.conf".format(sample_id)),
            )
        )
        if args.write_assignment_realized_conf:
            destinations.append(
                (
                    "assignment realization for {}".format(sample_id),
                    os.path.join(
                        args.output_dir,
                        "{}_assignment_realized.conf".format(sample_id),
                    ),
                )
            )
            for variant in assignment_realized_variants:
                destinations.append(
                    (
                        "assignment realization {} for {}".format(
                            variant["name"],
                            sample_id,
                        ),
                        os.path.join(
                            args.output_dir,
                            "{}_assignment_realized_{}.conf".format(
                                sample_id,
                                variant["name"],
                            ),
                        ),
                    )
                )
        if args.write_reference_pair_frame_conf:
            destinations.append(
                (
                    "reference pair frame for {}".format(sample_id),
                    os.path.join(
                        args.output_dir,
                        "{}_reference_pair_frame.conf".format(sample_id),
                    ),
                )
            )

    for index, (label, path) in enumerate(destinations):
        for other_label, other_path in destinations[:index]:
            if _paths_alias(path, other_path):
                raise ValueError(
                    "output path collision: {} and {} resolve to {}".format(
                        other_label,
                        label,
                        os.path.realpath(os.path.abspath(path)),
                    )
                )

    sources = [("manifest", args.manifest)]
    if getattr(args, "design_edge_sidecars", None):
        sources.append(("design-edge sidecar index", args.design_edge_sidecars))
    if args.init_model_state:
        sources.append(("initial checkpoint", args.init_model_state))
    for entry in entries:
        for key in (
            "top",
            "start",
            "target",
            "cadnano_json",
            "virt2nuc",
            "design_edge_sidecar",
            "canonical_map",
            "defect_sidecar",
            "start_pair_file",
            "final_pair_file",
        ):
            if entry.get(key):
                sources.append(("{} {}".format(entry["id"], key), entry[key]))

    for label, path in destinations:
        for source_label, source_path in sources:
            if _paths_alias(path, source_path):
                raise ValueError(
                    "output path {} would overwrite input {}: {}".format(
                        label,
                        source_label,
                        os.path.realpath(os.path.abspath(path)),
                    )
                )


def _best_monitor_direction(metric_name):
    return "max" if metric_name.endswith("/os") else "min"


def _best_monitor_initial_value(metric_name):
    return -float("inf") if _best_monitor_direction(metric_name) == "max" else float("inf")


def _best_monitor_is_better(metric_name, candidate, best_value):
    if _best_monitor_direction(metric_name) == "max":
        return candidate > best_value
    return candidate < best_value


def _resolve_best_model_monitor(args, val_ids):
    if args.best_model_monitor != "auto":
        return args.best_model_monitor
    if args.split_mode == "sample" and val_ids:
        return "val/loss"
    return "train/loss"


def _best_monitor_candidate(metric_name, train_record, val_record):
    scope, key = metric_name.split("/", 1)
    record = train_record if scope == "train" else val_record
    if record is None:
        return None
    value = record.get(key)
    if value is None:
        return None
    return float(value)


class SharedRigidMLP:
    def __init__(self, torch, input_dim, hidden_dim, device, scale_normalized_residuals=False, dropout=0.0):
        self.torch = torch
        self.scale_normalized_residuals = scale_normalized_residuals
        self.module = _mlp_layers(torch, [input_dim, hidden_dim, hidden_dim, 9], dropout).to(device)
        for layer in self.module:
            if isinstance(layer, torch.nn.Linear):
                torch.nn.init.xavier_uniform_(layer.weight)
                torch.nn.init.zeros_(layer.bias)

    def parameters(self):
        return self.module.parameters()

    def _modules(self):
        return [self.module]

    def train(self):
        for module in self._modules():
            module.train()
        return self

    def eval(self):
        for module in self._modules():
            module.eval()
        return self

    def state_dict(self):
        return self.module.state_dict()

    def load_state_dict(self, state_dict):
        self.module.load_state_dict(state_dict)

    def __call__(self, features, start_positions, start_a1, start_a3, position_scale, graph_edges=None, graph_edge_features=None):
        residual = self.module(features)
        position_residual = residual[:, 0:3]
        if self.scale_normalized_residuals:
            position_residual = position_residual * position_scale
        pred_positions = start_positions + position_residual
        pred_a1, pred_a3 = _orthonormalize_frame(
            self.torch,
            start_a1 + residual[:, 3:6],
            start_a3 + residual[:, 6:9],
        )
        return pred_positions, pred_a1, pred_a3


class GraphSharedRigidModel(SharedRigidMLP):
    def __init__(self, torch, input_dim, hidden_dim, device, message_passing_steps, scale_normalized_residuals=False, dropout=0.0):
        self.torch = torch
        self.scale_normalized_residuals = scale_normalized_residuals
        self.message_passing_steps = message_passing_steps
        self.encoder = _mlp_layers(torch, [input_dim, hidden_dim, hidden_dim], dropout).to(device)
        self.message = _mlp_layers(torch, [hidden_dim * 2, hidden_dim, hidden_dim], dropout).to(device)
        self.update = _mlp_layers(torch, [hidden_dim * 2, hidden_dim, hidden_dim], dropout).to(device)
        self.decoder = _mlp_layers(torch, [hidden_dim, hidden_dim, 9], dropout).to(device)
        for module in (self.encoder, self.message, self.update, self.decoder):
            for layer in module:
                if isinstance(layer, torch.nn.Linear):
                    torch.nn.init.xavier_uniform_(layer.weight)
                    torch.nn.init.zeros_(layer.bias)

    def parameters(self):
        return list(self.encoder.parameters()) + list(self.message.parameters()) + list(self.update.parameters()) + list(self.decoder.parameters())

    def _modules(self):
        return [self.encoder, self.message, self.update, self.decoder]

    def state_dict(self):
        return {
            "encoder": self.encoder.state_dict(),
            "message": self.message.state_dict(),
            "update": self.update.state_dict(),
            "decoder": self.decoder.state_dict(),
        }

    def load_state_dict(self, state_dict):
        self.encoder.load_state_dict(state_dict["encoder"])
        self.message.load_state_dict(state_dict["message"])
        self.update.load_state_dict(state_dict["update"])
        self.decoder.load_state_dict(state_dict["decoder"])

    def __call__(self, features, start_positions, start_a1, start_a3, position_scale, graph_edges=None, graph_edge_features=None):
        h = self.encoder(features)
        if graph_edges is not None and graph_edges.numel() > 0:
            row, col = graph_edges
            for _ in range(self.message_passing_steps):
                msg = self.message(self.torch.cat([h[row], h[col]], dim=1))
                agg = self.torch.zeros_like(h)
                agg.index_add_(0, col, msg)
                counts = self.torch.zeros((h.shape[0], 1), dtype=h.dtype, device=h.device)
                counts.index_add_(0, col, self.torch.ones((msg.shape[0], 1), dtype=h.dtype, device=h.device))
                agg = agg / counts.clamp(min=1.0)
                h = h + self.update(self.torch.cat([h, agg], dim=1))
        residual = self.decoder(h)
        position_residual = residual[:, 0:3]
        if self.scale_normalized_residuals:
            position_residual = position_residual * position_scale
        pred_positions = start_positions + position_residual
        pred_a1, pred_a3 = _orthonormalize_frame(
            self.torch,
            start_a1 + residual[:, 3:6],
            start_a3 + residual[:, 6:9],
        )
        return pred_positions, pred_a1, pred_a3


class DgnnLiteRigidModel(SharedRigidMLP):
    def __init__(
        self,
        torch,
        input_dim,
        edge_dim,
        hidden_dim,
        device,
        message_passing_steps,
        scale_normalized_residuals=False,
        dropout=0.0,
        wc_edge_mode="message_all",
    ):
        self.torch = torch
        self.scale_normalized_residuals = scale_normalized_residuals
        self.message_passing_steps = message_passing_steps
        self.wc_edge_mode = wc_edge_mode
        self.pos_encoder = _mlp_layers(torch, [input_dim + 3, hidden_dim, hidden_dim], dropout).to(device)
        self.ori_encoder = _mlp_layers(torch, [input_dim + 6, hidden_dim, hidden_dim], dropout).to(device)
        message_input_dim = hidden_dim * 4 + edge_dim
        self.edge_message = _mlp_layers(torch, [message_input_dim, hidden_dim, hidden_dim], dropout).to(device)
        self.pos_update = _mlp_layers(torch, [hidden_dim * 2, hidden_dim, hidden_dim], dropout).to(device)
        self.ori_update = _mlp_layers(torch, [hidden_dim * 2, hidden_dim, hidden_dim], dropout).to(device)
        self.pos_decoder = _mlp_layers(torch, [hidden_dim, hidden_dim, 3], dropout).to(device)
        self.ori_decoder = _mlp_layers(torch, [hidden_dim, hidden_dim, 6], dropout).to(device)
        self.pair_head = _mlp_layers(torch, [message_input_dim, hidden_dim, 1], dropout).to(device)
        self.pair_message = _mlp_layers(torch, [message_input_dim, hidden_dim, hidden_dim], dropout).to(device)
        self.pair_gate = _mlp_layers(torch, [message_input_dim, hidden_dim, 1], dropout).to(device)
        for module in (
            self.pos_encoder,
            self.ori_encoder,
            self.edge_message,
            self.pos_update,
            self.ori_update,
            self.pos_decoder,
            self.ori_decoder,
            self.pair_head,
            self.pair_message,
            self.pair_gate,
        ):
            for layer in module:
                if isinstance(layer, torch.nn.Linear):
                    torch.nn.init.xavier_uniform_(layer.weight)
                    torch.nn.init.zeros_(layer.bias)

    def parameters(self):
        params = []
        for module in (
            self.pos_encoder,
            self.ori_encoder,
            self.edge_message,
            self.pos_update,
            self.ori_update,
            self.pos_decoder,
            self.ori_decoder,
            self.pair_head,
            self.pair_message,
            self.pair_gate,
        ):
            params.extend(module.parameters())
        return params

    def _modules(self):
        return [
            self.pos_encoder,
            self.ori_encoder,
            self.edge_message,
            self.pos_update,
            self.ori_update,
            self.pos_decoder,
            self.ori_decoder,
            self.pair_head,
            self.pair_message,
            self.pair_gate,
        ]

    def state_dict(self):
        return {
            "pos_encoder": self.pos_encoder.state_dict(),
            "ori_encoder": self.ori_encoder.state_dict(),
            "edge_message": self.edge_message.state_dict(),
            "pos_update": self.pos_update.state_dict(),
            "ori_update": self.ori_update.state_dict(),
            "pos_decoder": self.pos_decoder.state_dict(),
            "ori_decoder": self.ori_decoder.state_dict(),
            "pair_head": self.pair_head.state_dict(),
            "pair_message": self.pair_message.state_dict(),
            "pair_gate": self.pair_gate.state_dict(),
        }

    def load_state_dict(self, state_dict):
        self.pos_encoder.load_state_dict(state_dict["pos_encoder"])
        self.ori_encoder.load_state_dict(state_dict["ori_encoder"])
        self.edge_message.load_state_dict(state_dict["edge_message"])
        self.pos_update.load_state_dict(state_dict["pos_update"])
        self.ori_update.load_state_dict(state_dict["ori_update"])
        self.pos_decoder.load_state_dict(state_dict["pos_decoder"])
        self.ori_decoder.load_state_dict(state_dict["ori_decoder"])
        if "pair_head" in state_dict:
            self.pair_head.load_state_dict(state_dict["pair_head"])
        if "pair_message" in state_dict:
            self.pair_message.load_state_dict(state_dict["pair_message"])
        if "pair_gate" in state_dict:
            self.pair_gate.load_state_dict(state_dict["pair_gate"])

    def __call__(
        self,
        features,
        start_positions,
        start_a1,
        start_a3,
        position_scale,
        graph_edges=None,
        graph_edge_features=None,
        pair_edge_mask=None,
    ):
        pos_h = self.pos_encoder(self.torch.cat([features, start_positions / position_scale], dim=1))
        ori_h = self.ori_encoder(self.torch.cat([features, start_a1, start_a3], dim=1))
        pair_logits = None
        if graph_edges is not None and graph_edges.numel() > 0:
            row, col = graph_edges
            if graph_edge_features is None:
                graph_edge_features = self.torch.zeros((row.shape[0], 0), dtype=features.dtype, device=features.device)
            ordinary_edge_mask = None
            if pair_edge_mask is not None and self.wc_edge_mode in ("readout_only", "last_layer"):
                ordinary_edge_mask = ~pair_edge_mask
            for step_idx in range(self.message_passing_steps):
                edge_inputs = self.torch.cat([pos_h[row], ori_h[row], pos_h[col], ori_h[col], graph_edge_features], dim=1)
                agg = self.torch.zeros_like(pos_h)
                counts = self.torch.zeros((pos_h.shape[0], 1), dtype=pos_h.dtype, device=pos_h.device)
                if ordinary_edge_mask is not None:
                    msg_inputs = edge_inputs[ordinary_edge_mask]
                    msg_col = col[ordinary_edge_mask]
                else:
                    msg_inputs = edge_inputs
                    msg_col = col
                if msg_inputs.shape[0] > 0:
                    msg = self.edge_message(msg_inputs)
                    agg.index_add_(0, msg_col, msg)
                    counts.index_add_(0, msg_col, self.torch.ones((msg.shape[0], 1), dtype=pos_h.dtype, device=pos_h.device))
                agg = agg / counts.clamp(min=1.0)
                pair_agg = self.torch.zeros_like(pos_h)
                pair_counts = self.torch.zeros((pos_h.shape[0], 1), dtype=pos_h.dtype, device=pos_h.device)
                use_pair_message = self.wc_edge_mode == "message_all" or (
                    self.wc_edge_mode == "last_layer" and step_idx == self.message_passing_steps - 1
                )
                if use_pair_message and pair_edge_mask is not None and int(pair_edge_mask.sum().detach().cpu()) > 0:
                    pair_inputs = edge_inputs[pair_edge_mask]
                    pair_col = col[pair_edge_mask]
                    pair_msg = self.pair_message(pair_inputs)
                    pair_gate = self.torch.sigmoid(self.pair_gate(pair_inputs))
                    gated_pair_msg = pair_msg * pair_gate
                    pair_agg.index_add_(0, pair_col, gated_pair_msg)
                    pair_counts.index_add_(
                        0,
                        pair_col,
                        self.torch.ones((gated_pair_msg.shape[0], 1), dtype=pos_h.dtype, device=pos_h.device),
                    )
                pair_agg = pair_agg / pair_counts.clamp(min=1.0)
                pos_h = pos_h + self.pos_update(self.torch.cat([pos_h, agg + pair_agg], dim=1))
                ori_h = ori_h + self.ori_update(self.torch.cat([ori_h, agg + pair_agg], dim=1))
            pair_logits = _chunked_pair_head_logits(
                self.torch,
                self.pair_head,
                pos_h,
                ori_h,
                row,
                col,
                graph_edge_features,
            )
        position_residual = self.pos_decoder(pos_h)
        if self.scale_normalized_residuals:
            position_residual = position_residual * position_scale
        orientation_residual = self.ori_decoder(ori_h)
        pred_positions = start_positions + position_residual
        pred_a1, pred_a3 = _orthonormalize_frame(
            self.torch,
            start_a1 + orientation_residual[:, 0:3],
            start_a3 + orientation_residual[:, 3:6],
        )
        return pred_positions, pred_a1, pred_a3, {"pair_logits": pair_logits}


class DgnnPhysicRigidModel(DgnnLiteRigidModel):
    def __init__(
        self,
        torch,
        input_dim,
        edge_dim,
        hidden_dim,
        device,
        message_passing_steps,
        relation_count,
        scale_normalized_residuals=False,
        dropout=0.0,
    ):
        self.relation_count = relation_count
        super().__init__(
            torch,
            input_dim,
            edge_dim,
            hidden_dim,
            device,
            message_passing_steps,
            scale_normalized_residuals=scale_normalized_residuals,
            dropout=dropout,
            wc_edge_mode="message_all",
        )
        self.relation_embedding = torch.nn.Embedding(relation_count, hidden_dim).to(device)
        torch.nn.init.xavier_uniform_(self.relation_embedding.weight)

    def parameters(self):
        params = list(super().parameters())
        params.extend(self.relation_embedding.parameters())
        return params

    def _modules(self):
        return super()._modules() + [self.relation_embedding]

    def state_dict(self):
        state = super().state_dict()
        state["relation_embedding"] = self.relation_embedding.state_dict()
        state["relation_count"] = self.relation_count
        return state

    def load_state_dict(self, state_dict):
        super().load_state_dict(state_dict)
        if "relation_embedding" in state_dict:
            self.relation_embedding.load_state_dict(state_dict["relation_embedding"])

    def __call__(
        self,
        features,
        start_positions,
        start_a1,
        start_a3,
        position_scale,
        graph_edges=None,
        graph_edge_features=None,
        edge_relation_ids=None,
    ):
        pos_h = self.pos_encoder(self.torch.cat([features, start_positions / position_scale], dim=1))
        ori_h = self.ori_encoder(self.torch.cat([features, start_a1, start_a3], dim=1))
        pair_logits = None
        if graph_edges is not None and graph_edges.numel() > 0:
            row, col = graph_edges
            if graph_edge_features is None:
                graph_edge_features = self.torch.zeros((row.shape[0], 0), dtype=features.dtype, device=features.device)
            if edge_relation_ids is None:
                edge_relation_ids = self.torch.zeros(row.shape[0], dtype=self.torch.long, device=features.device)
            edge_relation_ids = edge_relation_ids.to(features.device)
            for _step_idx in range(self.message_passing_steps):
                relation_h = self.relation_embedding(edge_relation_ids)
                edge_inputs = self.torch.cat([pos_h[row], ori_h[row], pos_h[col], ori_h[col], graph_edge_features], dim=1)
                base_msg = self.edge_message(edge_inputs)
                pair_msg = self.pair_message(edge_inputs) * self.torch.sigmoid(self.pair_gate(edge_inputs))
                msg = base_msg + pair_msg + relation_h
                agg = self.torch.zeros_like(pos_h)
                counts = self.torch.zeros((pos_h.shape[0], 1), dtype=pos_h.dtype, device=pos_h.device)
                agg.index_add_(0, col, msg)
                counts.index_add_(0, col, self.torch.ones((msg.shape[0], 1), dtype=pos_h.dtype, device=pos_h.device))
                agg = agg / counts.clamp(min=1.0)
                pos_h = pos_h + self.pos_update(self.torch.cat([pos_h, agg], dim=1))
                ori_h = ori_h + self.ori_update(self.torch.cat([ori_h, agg], dim=1))
            pair_logits = _chunked_pair_head_logits(
                self.torch,
                self.pair_head,
                pos_h,
                ori_h,
                row,
                col,
                graph_edge_features,
            )
        position_residual = self.pos_decoder(pos_h)
        if self.scale_normalized_residuals:
            position_residual = position_residual * position_scale
        orientation_residual = self.ori_decoder(ori_h)
        pred_positions = start_positions + position_residual
        pred_a1, pred_a3 = _orthonormalize_frame(
            self.torch,
            start_a1 + orientation_residual[:, 0:3],
            start_a3 + orientation_residual[:, 3:6],
        )
        return pred_positions, pred_a1, pred_a3, {"pair_logits": pair_logits}


def _normalize_manifest_entries(path, entries):
    if not isinstance(entries, list) or not entries:
        raise ValueError("manifest must be a non-empty JSON list")
    normalized = []
    base_dir = os.path.dirname(os.path.abspath(path))
    for idx, entry in enumerate(entries):
        if not isinstance(entry, dict):
            raise ValueError("manifest entry {} must be an object".format(idx))
        supplied_id = entry.get("id")
        task9_sample_id = entry.get("sample_id")
        if supplied_id is not None and task9_sample_id is not None and supplied_id != task9_sample_id:
            raise ValueError("manifest id and sample_id must match")
        sample_id = supplied_id or task9_sample_id or "sample_{}".format(idx)
        if not isinstance(sample_id, str) or not sample_id:
            raise ValueError("manifest sample identifier must be a nonempty string")

        converted_artifacts = _optional_manifest_object(
            entry, "converted_artifacts"
        )
        source_artifacts = _optional_manifest_object(entry, "source_artifacts")
        gnn_record = _optional_manifest_object(entry, "gnn")
        top = _coalesce_manifest_artifact_path(
            base_dir,
            "topology",
            entry.get("top"),
            _artifact_reference(
                converted_artifacts,
                ("topology", "top", "topology_path"),
                "converted topology",
            ),
            required=True,
        )
        start = _coalesce_manifest_artifact_path(
            base_dir,
            "initial configuration",
            entry.get("start"),
            _artifact_reference(
                converted_artifacts,
                (
                    "initial_configuration",
                    "configuration",
                    "start",
                    "configuration_path",
                    "initial_configuration_path",
                ),
                "converted initial configuration",
            ),
            required=True,
        )
        normalized_entry = {
            "id": sample_id,
            "top": top,
            "start": start,
        }
        for key in (
            "schema",
            "schema_version",
            "sample_id",
            "parent_hashes",
            "parent_content_hash",
            "family_id",
            "plan_id",
            "variant_id",
            "defect_type",
            "distribution",
            "budget",
            "selected_site_ids",
            "variant_manifest",
            "seeds",
            "replica_id",
            "loading_condition",
            "source_artifacts",
            "converted_artifacts",
            "tool_versions",
            "simulation",
            "analysis",
            "gnn",
            "failure_reason",
        ):
            if key in entry:
                normalized_entry[key] = entry[key]
        targets, target_masks, target_units = _normalize_target_contract(
            base_dir, entry
        )
        normalized_entry["targets"] = targets
        normalized_entry["target_masks"] = target_masks
        normalized_entry["target_units"] = target_units
        if targets["endpoint_positions"] is not None:
            normalized_entry["target"] = targets["endpoint_positions"]
        if entry.get("target_provenance") is not None:
            normalized_entry["target_provenance"] = entry["target_provenance"]
        for key in (
            "group_id",
            "graph_hash",
            "graph_family",
            "edge_length",
            "md_steps",
            "input_spec",
            "source_run_dir",
            "parent_id",
            "split_group_id",
            "plan_sha256",
            "defect_sidecar_sha256",
            "graph_input_hash",
            "content_sha256",
        ):
            if entry.get(key) is not None:
                normalized_entry[key] = entry[key]
        split_group_id = entry.get("split_group_id")
        if split_group_id is None and entry.get("parent_id") is not None:
            split_group_id = entry.get("group_id") or entry["parent_id"]
        if split_group_id is not None:
            normalized_entry["split_group_id"] = split_group_id
            normalized_entry["group_id"] = split_group_id
        static_graph_inputs = entry.get("static_graph_inputs")
        if static_graph_inputs is None and isinstance(entry.get("materialization"), dict):
            static_graph_inputs = entry["materialization"].get("static_graph_inputs")
        if static_graph_inputs is not None:
            if not isinstance(static_graph_inputs, dict):
                raise ValueError("static_graph_inputs must be an object")
            normalized_entry["static_graph_inputs"] = dict(static_graph_inputs)
        defect_sidecar = _coalesce_manifest_artifact_path(
            base_dir,
            "defect sidecar",
            entry.get("defect_sidecar"),
            _artifact_reference(
                gnn_record,
                ("artifact", "defect_sidecar"),
                "GNN defect sidecar",
            ),
        )
        if defect_sidecar:
            normalized_entry["defect_sidecar"] = defect_sidecar
        nested_defect_hash = gnn_record.get("sha256") if gnn_record else None
        declared_defect_hash = entry.get("defect_sidecar_sha256")
        if (
            declared_defect_hash is not None
            and nested_defect_hash is not None
            and declared_defect_hash != nested_defect_hash
        ):
            raise ValueError("defect sidecar hashes disagree")
        if declared_defect_hash is None and nested_defect_hash is not None:
            normalized_entry["defect_sidecar_sha256"] = nested_defect_hash

        canonical_map = _coalesce_manifest_artifact_path(
            base_dir,
            "canonical map",
            entry.get("canonical_map"),
            _artifact_reference(
                converted_artifacts,
                ("canonical_map", "mapping", "canonical_map_path"),
                "converted canonical map",
            ),
        )
        if canonical_map:
            normalized_entry["canonical_map"] = canonical_map
        cadnano_json = _coalesce_manifest_artifact_path(
            base_dir,
            "caDNAno source",
            entry.get("cadnano_json"),
            _artifact_reference(
                source_artifacts,
                ("cadnano", "source_cadnano", "cadnano_path"),
                "source caDNAno artifact",
            ),
        )
        if cadnano_json:
            normalized_entry["cadnano_json"] = cadnano_json
        virt2nuc = _coalesce_manifest_artifact_path(
            base_dir,
            "virt2nuc mapping",
            entry.get("virt2nuc"),
            _artifact_reference(
                converted_artifacts,
                ("virt2nuc", "virt2nuc_path"),
                "converted virt2nuc artifact",
            ),
        )
        if virt2nuc:
            normalized_entry["virt2nuc"] = virt2nuc
        if entry.get("start_pair_file"):
            normalized_entry["start_pair_file"] = _manifest_path(base_dir, entry["start_pair_file"])
        if entry.get("final_pair_file"):
            normalized_entry["final_pair_file"] = _manifest_path(base_dir, entry["final_pair_file"])
        _fill_explicit_reference_paths(normalized_entry)
        normalized.append(normalized_entry)
    return normalized


def _optional_manifest_object(entry, key):
    value = entry.get(key)
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("{} must be an object".format(key))
    return value


def _artifact_reference(container, keys, label):
    references = []
    for key in keys:
        if key not in container or container[key] is None:
            continue
        value = container[key]
        if isinstance(value, dict):
            value = value.get("path")
            if value is None:
                raise ValueError("{} has no path".format(label))
        if not isinstance(value, str) or not value:
            raise ValueError("{} path must be a nonempty string".format(label))
        references.append(value)
    if not references:
        return None
    normalized = {os.path.normpath(value) for value in references}
    if len(normalized) != 1:
        raise ValueError("{} aliases disagree".format(label))
    return references[0]


def _coalesce_manifest_artifact_path(
    base_dir, label, direct_reference, nested_reference, required=False
):
    references = []
    for value in (direct_reference, nested_reference):
        if value is None:
            continue
        if isinstance(value, dict):
            value = value.get("path")
        if not isinstance(value, str) or not value:
            raise ValueError("{} path must be a nonempty string".format(label))
        references.append(_manifest_path(base_dir, value))
    if not references:
        if required:
            raise ValueError("manifest entry has no {} path".format(label))
        return None
    if len(set(references)) != 1:
        raise ValueError("manifest {} paths disagree".format(label))
    return references[0]


def _normalize_target_contract(base_dir, entry):
    raw_targets = entry.get("targets")
    if raw_targets is None:
        raw_targets = {}
    if not isinstance(raw_targets, dict):
        raise ValueError("targets must be an object")
    raw_masks = entry.get("target_masks")
    if raw_masks is None:
        raw_masks = {}
    if not isinstance(raw_masks, dict):
        raise ValueError("target_masks must be an object")
    raw_units = entry.get("target_units")
    if raw_units is None:
        raw_units = {}
    if not isinstance(raw_units, dict):
        raise ValueError("target_units must be an object")

    targets = {}
    masks = {}
    units = {}
    for name, schema in TARGET_SCHEMA.items():
        raw_value = raw_targets.get(name)
        embedded_mask = None
        embedded_units = None
        if isinstance(raw_value, dict):
            embedded_mask = raw_value.get("mask")
            embedded_units = raw_value.get("units")
            raw_value = raw_value.get("values")
        if name == "endpoint_positions" and raw_value is None:
            raw_value = entry.get("target")
        if isinstance(raw_value, str):
            value = _manifest_path(base_dir, raw_value)
        else:
            value = raw_value
        mask = raw_masks.get(name, embedded_mask)
        if mask is None:
            mask = value is not None
        if type(mask) is not bool:
            raise ValueError("target mask {} must be boolean".format(name))
        if mask and value is None:
            raise ValueError("target {} is masked present but has no values".format(name))
        targets[name] = value
        masks[name] = mask
        units[name] = raw_units.get(name, embedded_units or schema["units"])
    unknown_masks = set(raw_masks).difference(TARGET_SCHEMA)
    if unknown_masks:
        raise ValueError(
            "unsupported target masks: {}".format(", ".join(sorted(unknown_masks)))
        )
    return targets, masks, units


def _load_manifest_with_sha256(path):
    with open(path, "rb") as handle:
        payload = handle.read()
    entries = json.loads(payload.decode("utf-8"))
    return _normalize_manifest_entries(path, entries), hashlib.sha256(payload).hexdigest()


def _load_manifest(path):
    entries, _digest = _load_manifest_with_sha256(path)
    return entries


def _fill_explicit_reference_paths(entry):
    if not entry.get("virt2nuc"):
        candidate = os.path.abspath(
            os.path.join(os.path.dirname(entry["top"]), os.pardir, "tacoxdna", "virt2nuc")
        )
        if os.path.exists(candidate):
            entry["virt2nuc"] = candidate
    if not entry.get("cadnano_json"):
        candidate = _find_cadnano_json_for_sample(entry["id"])
        if candidate is not None:
            entry["cadnano_json"] = candidate


def _find_cadnano_json_for_sample(sample_id):
    roots = []
    env_root = os.environ.get("EBD_OXDNA_CADNANO_JSON_ROOT")
    if env_root:
        roots.append(env_root)
    roots.append("/home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/json")
    filename = "{}.json".format(sample_id)
    for root in roots:
        if not root or not os.path.isdir(root):
            continue
        direct = os.path.join(root, filename)
        if os.path.exists(direct):
            return os.path.abspath(direct)
        for current_root, _dirs, files in os.walk(root):
            if filename in files:
                return os.path.abspath(os.path.join(current_root, filename))
    return None


def _manifest_path(base_dir, value):
    if os.path.isabs(value):
        return value
    return os.path.abspath(os.path.join(base_dir, value))


def _split_ids(
    sample_ids,
    val_fraction,
    val_ids_text,
    seed,
    split_strategy="random",
    nucleotide_counts=None,
    group_ids=None,
):
    explicit_val = [item.strip() for item in val_ids_text.split(",") if item.strip()]
    if explicit_val:
        val_set = set(explicit_val)
        train_ids = [sample_id for sample_id in sample_ids if sample_id not in val_set]
        val_ids = [sample_id for sample_id in sample_ids if sample_id in val_set]
    elif val_fraction > 0:
        val_count = int(round(len(sample_ids) * val_fraction))
        val_count = max(1, min(len(sample_ids) - 1, val_count))
        if split_strategy == "topology-grouped":
            if nucleotide_counts is None or group_ids is None:
                raise ValueError(
                    "topology-grouped split requires nucleotide_counts and group_ids"
                )
            missing = [sample_id for sample_id in sample_ids if not group_ids.get(sample_id)]
            if missing:
                raise ValueError(
                    "topology-grouped split has samples without group ids: {}".format(
                        ",".join(missing)
                    )
                )
            grouped = {}
            for sample_id in sample_ids:
                grouped.setdefault(group_ids[sample_id], []).append(sample_id)
            if len(grouped) < 2:
                raise ValueError("topology-grouped split requires at least two groups")

            group_order = sorted(grouped)
            random.Random(seed).shuffle(group_order)
            total_nt = sum(nucleotide_counts[sample_id] for sample_id in sample_ids)
            sample_count = len(sample_ids)
            choices = {0: (0, ())}
            for group_id in group_order:
                members = grouped[group_id]
                group_count = len(members)
                group_nt = sum(nucleotide_counts[sample_id] for sample_id in members)
                updates = {}
                for count, (nt_count, selected_groups) in list(choices.items()):
                    new_count = count + group_count
                    if new_count >= sample_count:
                        continue
                    candidate = (nt_count + group_nt, selected_groups + (group_id,))
                    expected_nt = total_nt * new_count / float(sample_count)
                    incumbent = choices.get(new_count) or updates.get(new_count)
                    if incumbent is None or (
                        abs(candidate[0] - expected_nt), candidate[1]
                    ) < (
                        abs(incumbent[0] - expected_nt), incumbent[1]
                    ):
                        updates[new_count] = candidate
                choices.update(updates)
            candidate_counts = [count for count in choices if 0 < count < sample_count]
            selected_count = min(
                candidate_counts,
                key=lambda count: (
                    abs(count - val_count),
                    abs(choices[count][0] - total_nt * count / float(sample_count)),
                    choices[count][1],
                ),
            )
            selected_groups = set(choices[selected_count][1])
            val_set = {
                sample_id
                for sample_id in sample_ids
                if group_ids[sample_id] in selected_groups
            }
        elif split_strategy == "nt-stratified":
            if nucleotide_counts is None:
                raise ValueError("nt-stratified split requires nucleotide_counts")
            rng = random.Random(seed)
            ranked = sorted(
                sample_ids,
                key=lambda sample_id: (nucleotide_counts[sample_id], rng.random(), sample_id),
            )
            val_ranked = []
            used = set()
            for bucket_index in range(val_count):
                start = int(round(bucket_index * len(ranked) / float(val_count)))
                end = int(round((bucket_index + 1) * len(ranked) / float(val_count)))
                bucket = [sample_id for sample_id in ranked[start:end] if sample_id not in used]
                if not bucket:
                    continue
                pick_index = rng.randrange(len(bucket))
                picked = bucket[pick_index]
                val_ranked.append(picked)
                used.add(picked)
            if len(val_ranked) < val_count:
                remaining = [sample_id for sample_id in ranked if sample_id not in used]
                val_ranked.extend(remaining[: val_count - len(val_ranked)])
            val_set = set(val_ranked)
        else:
            shuffled = list(sample_ids)
            random.Random(seed).shuffle(shuffled)
            val_set = set(shuffled[:val_count])
        train_ids = [sample_id for sample_id in sample_ids if sample_id not in val_set]
        val_ids = [sample_id for sample_id in sample_ids if sample_id in val_set]
    else:
        train_ids = list(sample_ids)
        val_ids = []
    if not train_ids:
        raise ValueError("train split is empty")
    return train_ids, val_ids


def _build_split_audit(entries, train_id_set, val_id_set, test_id_set):
    split_sets = {
        "train": set(train_id_set),
        "val": set(val_id_set),
        "test": set(test_id_set),
    }
    parent_ids = {}
    split_group_ids = {}
    for split_name, sample_ids in split_sets.items():
        parent_ids[split_name] = sorted(
            {
                entry["parent_id"]
                for entry in entries
                if entry["id"] in sample_ids and entry.get("parent_id")
            }
        )
        split_group_ids[split_name] = sorted(
            {
                entry.get("split_group_id")
                or entry.get("group_id")
                or entry.get("graph_hash")
                for entry in entries
                if entry["id"] in sample_ids
                and (
                    entry.get("split_group_id")
                    or entry.get("group_id")
                    or entry.get("graph_hash")
                )
            }
        )
    for left, right in (("train", "val"), ("train", "test"), ("val", "test")):
        if set(parent_ids[left]).intersection(parent_ids[right]):
            raise ValueError("{} and {} parent_id values overlap".format(left, right))
        if set(split_group_ids[left]).intersection(split_group_ids[right]):
            raise ValueError(
                "{} and {} split_group_id values overlap".format(left, right)
            )
    payload = {
        "schema": "ebd_oxdna.split_audit",
        "schema_version": 1,
        "parent_ids": parent_ids,
        "split_group_ids": split_group_ids,
    }
    encoded = json.dumps(
        payload,
        allow_nan=False,
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("ascii")
    payload["sha256"] = hashlib.sha256(encoded).hexdigest()
    return payload


def _append_fourier_features(torch, features, num_frequencies):
    if num_frequencies <= 0:
        return features
    coord = features[:, 0:3]
    parts = [features]
    for freq in range(num_frequencies):
        scale = float(2 ** freq)
        parts.append(torch.sin(scale * coord))
        parts.append(torch.cos(scale * coord))
    return torch.cat(parts, dim=1)


def _append_design_features(torch, features, sample, mode):
    if mode == "none":
        return features
    positions = torch.tensor([list(row) for row in sample.positions], dtype=features.dtype, device=features.device)
    center = torch.mean(positions, dim=0, keepdim=True)
    centered = positions - center
    scale = torch.std(centered).clamp(min=1.0)
    mins = torch.min(centered / scale, dim=0)[0]
    maxs = torch.max(centered / scale, dim=0)[0]
    span = maxs - mins
    rg = torch.sqrt(torch.mean(torch.sum((centered / scale) ** 2, dim=1))).view(1)

    strand_counts = {}
    for row in sample.topology.rows:
        strand_counts[row.strand_id] = strand_counts.get(row.strand_id, 0) + 1
    strand_lengths = torch.tensor(
        list(strand_counts.values()),
        dtype=features.dtype,
        device=features.device,
    )
    num_nodes = float(max(1, sample.num_nucleotides))
    num_strands = float(max(1, len(strand_counts)))
    scalar_stats = torch.tensor(
        [
            num_nodes,
            num_strands,
            len(sample.backbone_edges) / num_nodes,
            float(torch.mean(strand_lengths).detach().cpu()) / num_nodes,
            float(torch.std(strand_lengths).detach().cpu()) / num_nodes if strand_lengths.numel() > 1 else 0.0,
        ],
        dtype=features.dtype,
        device=features.device,
    )
    scalar_stats = torch.log1p(scalar_stats)
    design = torch.cat([scalar_stats, span, rg], dim=0).view(1, -1)
    design = design.expand(features.shape[0], design.shape[1])
    return torch.cat([features, design], dim=1)


def _append_physical_node_features(torch, features, sample, position_scale):
    device = features.device
    dtype = features.dtype
    rows = sample.topology.rows
    base_to_idx = {"A": 0, "C": 1, "G": 2, "T": 3, "U": 3}
    base_features = torch.zeros((sample.num_nucleotides, 4), dtype=dtype, device=device)
    strand_counts = {}
    strand_members = {}
    for idx, row in enumerate(rows):
        base_features[idx, base_to_idx.get(row.base.upper(), 0)] = 1.0
        strand_counts[row.strand_id] = strand_counts.get(row.strand_id, 0) + 1
        strand_members.setdefault(row.strand_id, []).append(idx)
    strand_ids = sorted(strand_members)
    strand_to_rank = {strand_id: rank for rank, strand_id in enumerate(strand_ids)}
    local_index = {}
    for strand_id, members in strand_members.items():
        for local_idx, node_idx in enumerate(members):
            local_index[node_idx] = local_idx
    positions = torch.tensor([list(row) for row in sample.positions], dtype=dtype, device=device)
    velocities = torch.tensor([list(row.velocity) for row in sample.start_frame.rows], dtype=dtype, device=device)
    angular = torch.tensor([list(row.angular_velocity) for row in sample.start_frame.rows], dtype=dtype, device=device)
    box = torch.tensor(list(sample.start_frame.box), dtype=dtype, device=device).clamp(min=1e-6)
    norm_positions = positions / box.view(1, 3)
    velocity_scale = torch.norm(velocities, p=2, dim=1, keepdim=True).clamp(min=1.0)
    angular_scale = torch.norm(angular, p=2, dim=1, keepdim=True).clamp(min=1.0)
    scalar_rows = []
    phase_rows = []
    for idx, row in enumerate(rows):
        strand_len = float(max(1, strand_counts[row.strand_id]))
        local = float(local_index[idx])
        local_norm = local / float(max(1, strand_counts[row.strand_id] - 1))
        phase = 2.0 * math.pi * local / 10.5
        scalar_rows.append(
            [
                float(strand_to_rank[row.strand_id]) / float(max(1, len(strand_ids) - 1)),
                local_norm,
                strand_len / float(max(1, sample.num_nucleotides)),
                1.0 if row.prev_idx >= 0 else 0.0,
                1.0 if row.next_idx >= 0 else 0.0,
                1.0 if row.prev_idx < 0 or row.next_idx < 0 else 0.0,
            ]
        )
        phase_rows.append([math.sin(phase), math.cos(phase)])
    scalar = torch.tensor(scalar_rows, dtype=dtype, device=device)
    phase = torch.tensor(phase_rows, dtype=dtype, device=device)
    extra = torch.cat(
        [
            base_features,
            scalar,
            phase,
            norm_positions,
            velocities / velocity_scale,
            angular / angular_scale,
        ],
        dim=1,
    )
    names = [
        "base_A",
        "base_C",
        "base_G",
        "base_T",
        "strand_rank_norm",
        "local_index_norm",
        "strand_length_fraction",
        "has_prev",
        "has_next",
        "is_nick_or_end",
        "phase_sin",
        "phase_cos",
        "box_position_x",
        "box_position_y",
        "box_position_z",
        "velocity_x",
        "velocity_y",
        "velocity_z",
        "angular_velocity_x",
        "angular_velocity_y",
        "angular_velocity_z",
    ]
    return torch.cat([features, extra], dim=1), names


def _position_scale(torch, sample, device):
    positions = torch.tensor([list(row) for row in sample.positions], dtype=torch.float32, device=device)
    center = torch.mean(positions, dim=0, keepdim=True)
    return torch.std(positions - center).clamp(min=1.0)


def _is_wc_complementary(sample, src, dst):
    base_src = sample.topology.rows[src].base
    base_dst = sample.topology.rows[dst].base
    return (
        (base_src == "A" and base_dst == "T")
        or (base_src == "T" and base_dst == "A")
        or (base_src == "C" and base_dst == "G")
        or (base_src == "G" and base_dst == "C")
    )


def _candidate_wc_edges(sample, positions, candidate_wc_cutoff, candidate_wc_top_k):
    candidates_by_src = {}
    rows = sample.topology.rows
    for src in range(sample.num_nucleotides):
        src_row = rows[src]
        ranked = []
        for dst in range(sample.num_nucleotides):
            if src == dst:
                continue
            dst_row = rows[dst]
            if src_row.strand_id == dst_row.strand_id:
                continue
            if not _is_wc_complementary(sample, src, dst):
                continue
            dist_sq = sum((positions[src][axis] - positions[dst][axis]) ** 2 for axis in range(3))
            if candidate_wc_cutoff > 0 and dist_sq > candidate_wc_cutoff ** 2:
                continue
            ranked.append((dist_sq, dst))
        ranked.sort(key=lambda item: item[0])
        candidates_by_src[src] = [dst for _dist_sq, dst in ranked[:candidate_wc_top_k]]

    edges = []
    for src, dst_list in candidates_by_src.items():
        for dst in dst_list:
            edges.append((src, dst))
    return edges


def _target_wc_edges_oxview_like(sample, candidate_wc_cutoff):
    if sample.target_positions is None or sample.target_a1 is None:
        return []

    cutoff = candidate_wc_cutoff if candidate_wc_cutoff > 0 else 0.6
    rows = sample.topology.rows
    positions = sample.target_positions
    a1 = sample.target_a1
    ns_positions = [
        (
            positions[idx][0] + 0.34 * a1[idx][0],
            positions[idx][1] + 0.34 * a1[idx][1],
            positions[idx][2] + 0.34 * a1[idx][2],
        )
        for idx in range(sample.num_nucleotides)
    ]

    try:
        from scipy.spatial import cKDTree
    except ImportError:
        cKDTree = None

    if cKDTree is not None:
        tree = cKDTree(ns_positions)
        neighbor_lists = tree.query_ball_point(ns_positions, r=cutoff)
    else:
        cutoff_sq = cutoff * cutoff
        neighbor_lists = []
        for src in range(sample.num_nucleotides):
            neighbors = []
            for dst in range(sample.num_nucleotides):
                dist_sq = sum((ns_positions[src][axis] - ns_positions[dst][axis]) ** 2 for axis in range(3))
                if dist_sq <= cutoff_sq:
                    neighbors.append(dst)
            neighbor_lists.append(neighbors)

    pair = [-1] * sample.num_nucleotides
    strand_ids = sorted({row.strand_id for row in rows})
    traversal_order = []
    for strand_id in strand_ids:
        traversal_order.extend([idx for idx, row in enumerate(rows) if row.strand_id == strand_id])

    for src in traversal_order:
        if pair[src] != -1:
            continue
        src_row = rows[src]
        best_dst = -1
        best_dist = cutoff
        for dst in neighbor_lists[src]:
            if src == dst:
                continue
            if src_row.prev_idx == dst or src_row.next_idx == dst:
                continue
            if not _is_wc_complementary(sample, src, dst):
                continue
            orient = sum(a1[src][axis] * a1[dst][axis] for axis in range(3))
            if orient >= -0.85:
                continue
            dist = math.sqrt(sum((ns_positions[src][axis] - ns_positions[dst][axis]) ** 2 for axis in range(3)))
            if dist < best_dist:
                best_dst = dst
                best_dist = dist
        if best_dst != -1:
            pair[src] = best_dst
            pair[best_dst] = src

    edges = []
    for src, dst in enumerate(pair):
        if dst != -1:
            edges.append((src, dst))
    return edges


def _candidate_edge_conflict_rate(torch, prepared, pred_positions, pair_cutoff):
    edge_tensor = prepared.get("candidate_wc_edges")
    if edge_tensor is None or edge_tensor.numel() == 0:
        return None
    row, col = edge_tensor
    if row.numel() == 0:
        return 0.0
    distances = torch.norm(pred_positions[row] - pred_positions[col], p=2, dim=1)
    active = distances <= pair_cutoff
    active_rows = row[active].detach().cpu().tolist()
    active_cols = col[active].detach().cpu().tolist()
    partner_sets = {}
    for src, dst in zip(active_rows, active_cols):
        src = int(src)
        dst = int(dst)
        partner_sets.setdefault(src, set()).add(dst)
        partner_sets.setdefault(dst, set()).add(src)
    conflicting_nodes = sum(1 for partners in partner_sets.values() if len(partners) > 1)
    return float(conflicting_nodes) / float(max(1, prepared["sample"].num_nucleotides))


def _reference_pair_endpoint_conflict_rate(torch, prepared, pred_positions, pair_cutoff):
    reference_pairs = prepared.get("reference_pairs") or []
    if not reference_pairs:
        return 0.0
    endpoints = sorted(set(int(node) for pair in reference_pairs for node in pair))
    if len(endpoints) <= 1:
        return 0.0
    endpoint_tensor = torch.tensor(endpoints, dtype=torch.long, device=pred_positions.device)
    endpoint_positions = pred_positions[endpoint_tensor]
    distances = torch.cdist(endpoint_positions, endpoint_positions, p=2)
    endpoint_set = set(endpoints)
    reference_pair_set = set(tuple(sorted((int(src), int(dst)))) for src, dst in reference_pairs)
    partner_counts = {node: 0 for node in endpoints}
    rows = prepared["sample"].topology.rows
    for local_src, src in enumerate(endpoints):
        for local_dst in range(local_src + 1, len(endpoints)):
            dst = endpoints[local_dst]
            if rows[src].strand_id == rows[dst].strand_id:
                continue
            if float(distances[local_src, local_dst].detach().cpu()) > pair_cutoff:
                continue
            if tuple(sorted((src, dst))) not in reference_pair_set:
                partner_counts[src] += 1
                partner_counts[dst] += 1
            else:
                partner_counts[src] += 1
                partner_counts[dst] += 1
    conflicting_nodes = sum(1 for node in endpoint_set if partner_counts.get(node, 0) > 1)
    return float(conflicting_nodes) / float(max(1, prepared["sample"].num_nucleotides))


def _training_conflict_rate(torch, prepared, pred_positions, args):
    conflict_rate = _candidate_edge_conflict_rate(torch, prepared, pred_positions, args.wc_pair_cutoff)
    if conflict_rate is not None:
        return conflict_rate
    if (
        args.pair_conflict_loss_weight != 0.0
        or args.soft_partner_exclusivity_loss_weight != 0.0
        or args.nonpair_repulsion_loss_weight != 0.0
    ):
        return _reference_pair_endpoint_conflict_rate(torch, prepared, pred_positions, args.wc_pair_cutoff)
    return 0.0


def _compat_unpickle_virt2nuc(path):
    class _CompatVirt2NucPlaceholder(object):
        def __setstate__(self, state):
            self.state = state

    class _CompatUnpickler(pickle.Unpickler):
        def find_class(self, module, name):
            if module == "libs.cadnano_utils" and name == "vhelix_vbase_to_nucleotide":
                return _CompatVirt2NucPlaceholder
            return super().find_class(module, name)

    with open(path, "rb") as handle:
        loaded = _CompatUnpickler(handle).load()
    if isinstance(loaded, tuple) and loaded:
        if isinstance(loaded[0], dict):
            return loaded[0]
        loaded = loaded[0]
    state = getattr(loaded, "state", None)
    if isinstance(state, dict):
        return state
    if isinstance(getattr(loaded, "__dict__", None), dict):
        return loaded.__dict__
    raise ValueError("Unsupported virt2nuc pickle structure in {}".format(path))


def _load_explicit_reference_pairs(entry):
    cadnano_path = entry.get("cadnano_json")
    virt2nuc_path = entry.get("virt2nuc")
    if not cadnano_path or not virt2nuc_path:
        return []
    if not os.path.exists(cadnano_path) or not os.path.exists(virt2nuc_path):
        return []

    with open(cadnano_path, "r") as handle:
        cadnano = json.load(handle)
    state = _compat_unpickle_virt2nuc(virt2nuc_path)
    scaf = state.get("_scaf", {})
    stap = state.get("_stap", {})
    if not isinstance(scaf, dict) or not isinstance(stap, dict):
        return []

    pairs = set()
    for vstrand in cadnano.get("vstrands", []):
        vh = vstrand.get("num")
        scaf_rows = vstrand.get("scaf", [])
        stap_rows = vstrand.get("stap", [])
        for vb, scaf_row in enumerate(scaf_rows):
            if vb >= len(stap_rows):
                continue
            stap_row = stap_rows[vb]
            scaffold_present = len(scaf_row) >= 2 and (scaf_row[0] != -1 or scaf_row[1] != -1)
            staple_present = len(stap_row) >= 2 and (stap_row[0] != -1 or stap_row[1] != -1)
            key = (vh, vb)
            if not scaffold_present or not staple_present:
                continue
            if key not in scaf or key not in stap:
                continue
            _scaf_strand, scaf_ids = scaf[key]
            _stap_strand, stap_ids = stap[key]
            if len(scaf_ids) != 1 or len(stap_ids) != 1:
                continue
            src = int(scaf_ids[0])
            dst = int(stap_ids[0])
            if src == dst:
                continue
            pair = (src, dst) if src < dst else (dst, src)
            pairs.add(pair)
    return sorted(pairs)


def _load_pair_list(path):
    if path is None or not os.path.exists(path):
        return []
    frames = []
    current = []
    with open(path, "r") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith("#"):
                if current:
                    frames.append(current)
                    current = []
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            src = int(parts[0])
            dst = int(parts[1])
            if src == dst:
                continue
            pair = (src, dst) if src < dst else (dst, src)
            current.append(pair)
    if current:
        frames.append(current)
    if not frames:
        return []
    return sorted(set(frames[-1]))


def _pair_state_feature_tensor(torch, graph_edges, start_pairs, final_pairs):
    if graph_edges.numel() == 0:
        return torch.empty((0, 4), dtype=torch.float32, device=graph_edges.device)
    start_set = set((int(src), int(dst)) if int(src) < int(dst) else (int(dst), int(src)) for src, dst in start_pairs)
    final_set = set((int(src), int(dst)) if int(src) < int(dst) else (int(dst), int(src)) for src, dst in final_pairs)
    rows, cols = graph_edges.detach().cpu().tolist()
    features = []
    for src, dst in zip(rows, cols):
        pair = (int(src), int(dst)) if int(src) < int(dst) else (int(dst), int(src))
        in_start = pair in start_set
        in_final = pair in final_set
        if in_start and in_final:
            features.append([1.0, 0.0, 0.0, 0.0])  # kept
        elif in_start and not in_final:
            features.append([0.0, 1.0, 0.0, 0.0])  # broken
        elif (not in_start) and in_final:
            features.append([0.0, 0.0, 1.0, 0.0])  # formed
        else:
            features.append([0.0, 0.0, 0.0, 1.0])  # never-pair / wrong-contact
    return torch.tensor(features, dtype=torch.float32, device=graph_edges.device)


PHYSICAL_EDGE_RELATIONS = [
    "backbone_forward",
    "backbone_reverse",
    "spatial",
]


def _build_physical_graph_edges(
    torch,
    sample,
    base_graph_edges,
    start_pairs,
    final_pairs,
    reference_pairs,
    helix_steps,
    candidate_wc_edge_list,
    device,
):
    relation_to_id = {name: idx for idx, name in enumerate(PHYSICAL_EDGE_RELATIONS)}
    edge_relation = {}

    def add_edge(src, dst, relation):
        edge = (int(src), int(dst))
        if edge not in edge_relation:
            edge_relation[edge] = relation

    rows = sample.topology.rows
    for idx, row in enumerate(rows):
        if row.next_idx >= 0:
            add_edge(idx, row.next_idx, "backbone_forward")
        if row.prev_idx >= 0:
            add_edge(idx, row.prev_idx, "backbone_reverse")

    del start_pairs, final_pairs, reference_pairs, helix_steps, candidate_wc_edge_list

    if base_graph_edges.numel() > 0:
        for src, dst in zip(base_graph_edges[0].detach().cpu().tolist(), base_graph_edges[1].detach().cpu().tolist()):
            add_edge(src, dst, "spatial")

    edges = sorted(edge_relation)
    if not edges:
        return (
            torch.empty((2, 0), dtype=torch.long, device=device),
            torch.empty((0,), dtype=torch.long, device=device),
            list(PHYSICAL_EDGE_RELATIONS),
        )
    edge_tensor = torch.tensor(
        [[src for src, _dst in edges], [dst for _src, dst in edges]],
        dtype=torch.long,
        device=device,
    )
    relation_ids = torch.tensor(
        [relation_to_id[edge_relation[edge]] for edge in edges],
        dtype=torch.long,
        device=device,
    )
    return edge_tensor, relation_ids, list(PHYSICAL_EDGE_RELATIONS)


def _canonical_pair_tuple(src, dst):
    src = int(src)
    dst = int(dst)
    return (src, dst) if src < dst else (dst, src)


def _build_physical_graph_edge_features(torch, sample, graph_edges, edge_relation_ids, edge_relation_names, position_scale, start_pairs, final_pairs):
    base_features = _build_graph_edge_features(torch, sample, graph_edges, position_scale)
    if graph_edges.numel() == 0:
        return base_features, []
    relation_one_hot = torch.nn.functional.one_hot(
        edge_relation_ids,
        num_classes=len(edge_relation_names),
    ).to(dtype=base_features.dtype, device=base_features.device)
    rows, cols = graph_edges.detach().cpu().tolist()
    strand_positions = {}
    local_index_map = {}
    for idx, top_row in enumerate(sample.topology.rows):
        strand_positions.setdefault(top_row.strand_id, [])
        strand_positions[top_row.strand_id].append(idx)
    for members in strand_positions.values():
        for local_idx, node_idx in enumerate(members):
            local_index_map[node_idx] = local_idx
    phase_rows = []
    for src, dst in zip(rows, cols):
        phase_src = 2.0 * math.pi * float(local_index_map[int(src)]) / 10.5
        phase_dst = 2.0 * math.pi * float(local_index_map[int(dst)]) / 10.5
        delta = phase_dst - phase_src
        phase_rows.append([math.sin(delta), math.cos(delta)])
    phase_features = torch.tensor(phase_rows, dtype=base_features.dtype, device=base_features.device)
    del start_pairs, final_pairs
    features = torch.cat([base_features, relation_one_hot, phase_features], dim=1)
    names = (
        [
            "edge_rel_x",
            "edge_rel_y",
            "edge_rel_z",
            "edge_distance",
            "edge_same_strand",
            "edge_backbone",
            "edge_cross_strand",
            "edge_complementary",
            "edge_local_index_delta",
            "edge_direction_compatibility",
        ]
        + ["edge_relation_{}".format(name) for name in edge_relation_names]
        + ["edge_phase_delta_sin", "edge_phase_delta_cos"]
    )
    return features, names


def _build_graph_edges(
    torch,
    sample,
    graph_mode,
    graph_cutoff,
    max_spatial_neighbors,
    device,
    include_candidate_wc_edges=False,
    candidate_wc_top_k=0,
    candidate_wc_cutoff=0.0,
):
    edges = []
    seen = set()
    backbone_seen = set()
    for src, dst in sample.backbone_edges:
        backbone_seen.add((src, dst))
        backbone_seen.add((dst, src))
        for edge in ((src, dst), (dst, src)):
            if edge not in seen:
                seen.add(edge)
                edges.append(edge)
    if graph_mode == "cutoff" and graph_cutoff > 0:
        try:
            from scipy.spatial import cKDTree
        except ImportError:
            cKDTree = None
        positions = [list(row) for row in sample.positions]
        if cKDTree is not None:
            tree = cKDTree(positions)
            for src, neighbors in enumerate(tree.query_ball_point(positions, r=graph_cutoff)):
                ranked = []
                for dst in neighbors:
                    if dst == src:
                        continue
                    dist_sq = sum((positions[src][axis] - positions[dst][axis]) ** 2 for axis in range(3))
                    ranked.append((dist_sq, dst))
                ranked.sort(key=lambda item: item[0])
                for _dist_sq, dst in ranked[:max_spatial_neighbors]:
                    edge = (src, dst)
                    if edge not in seen:
                        seen.add(edge)
                        edges.append(edge)
    if include_candidate_wc_edges and candidate_wc_top_k > 0:
        for edge in _target_wc_edges_oxview_like(sample, candidate_wc_cutoff):
            if edge not in seen:
                seen.add(edge)
                edges.append(edge)
    if not edges:
        return torch.empty((2, 0), dtype=torch.long, device=device)
    return torch.tensor([[src for src, _dst in edges], [dst for _src, dst in edges]], dtype=torch.long, device=device)


def _build_graph_edge_features(torch, sample, graph_edges, position_scale):
    if graph_edges.numel() == 0:
        return torch.empty((0, 10), dtype=torch.float32, device=graph_edges.device)
    positions = torch.tensor([list(row) for row in sample.positions], dtype=torch.float32, device=graph_edges.device)
    row, col = graph_edges
    rel = (positions[col] - positions[row]) / position_scale
    dist = torch.norm(rel, p=2, dim=1, keepdim=True)
    strand_ids = [top_row.strand_id for top_row in sample.topology.rows]
    same_strand = torch.tensor(
        [[1.0 if strand_ids[int(src)] == strand_ids[int(dst)] else 0.0] for src, dst in zip(row.detach().cpu().tolist(), col.detach().cpu().tolist())],
        dtype=torch.float32,
        device=graph_edges.device,
    )
    backbone_edges = set()
    for src, dst in sample.backbone_edges:
        backbone_edges.add((src, dst))
        backbone_edges.add((dst, src))
    backbone = torch.tensor(
        [[1.0 if (int(src), int(dst)) in backbone_edges else 0.0] for src, dst in zip(row.detach().cpu().tolist(), col.detach().cpu().tolist())],
        dtype=torch.float32,
        device=graph_edges.device,
    )
    local_index_map = {}
    strand_positions = {}
    for idx, top_row in enumerate(sample.topology.rows):
        strand_positions.setdefault(top_row.strand_id, [])
        strand_positions[top_row.strand_id].append(idx)
    for members in strand_positions.values():
        for local_idx, node_idx in enumerate(members):
            local_index_map[node_idx] = local_idx
    cross_strand = 1.0 - same_strand
    complementary = torch.tensor(
        [[1.0 if _is_wc_complementary(sample, int(src), int(dst)) else 0.0] for src, dst in zip(row.detach().cpu().tolist(), col.detach().cpu().tolist())],
        dtype=torch.float32,
        device=graph_edges.device,
    )
    local_index_delta = torch.tensor(
        [[
            abs(
                float(local_index_map[int(src)])
                - float(local_index_map[int(dst)])
            )
        ] for src, dst in zip(row.detach().cpu().tolist(), col.detach().cpu().tolist())],
        dtype=torch.float32,
        device=graph_edges.device,
    )
    direction_compatibility = torch.tensor(
        [[
            1.0
            if (
                sample.topology.rows[int(src)].next_idx == int(dst)
                or sample.topology.rows[int(src)].prev_idx == int(dst)
                or (
                    sample.topology.rows[int(src)].next_idx >= 0
                    and sample.topology.rows[int(dst)].prev_idx >= 0
                )
                or (
                    sample.topology.rows[int(src)].prev_idx >= 0
                    and sample.topology.rows[int(dst)].next_idx >= 0
                )
            )
            else 0.0
        ] for src, dst in zip(row.detach().cpu().tolist(), col.detach().cpu().tolist())],
        dtype=torch.float32,
        device=graph_edges.device,
    )
    return torch.cat(
        [
            rel,
            dist,
            same_strand,
            backbone,
            cross_strand,
            complementary,
            local_index_delta,
            direction_compatibility,
        ],
        dim=1,
    )


def _attach_cut_backbone_relation(
    torch,
    sample,
    graph_edges,
    graph_edge_features,
    edge_relation_ids,
    edge_relation_names,
    candidate_wc_edge_mask,
    position_scale,
    defect_contract,
    preserve_design_edge_v1=False,
):
    relation = defect_contract["cut_backbone"]
    sidecar = defect_contract.get("sidecar")
    relation_names = list(edge_relation_names)
    expose_relation = sidecar is not None or not preserve_design_edge_v1
    if expose_relation and "cut_backbone" not in relation_names:
        relation_names.append("cut_backbone")
    existing_count = graph_edges.shape[1]
    cut_edges = relation["edges"]
    if cut_edges:
        if "cut_backbone" not in relation_names:
            relation_names.append("cut_backbone")
        existing_edges = set(
            zip(
                graph_edges[0].detach().cpu().tolist(),
                graph_edges[1].detach().cpu().tolist(),
            )
        )
        overlap = existing_edges.intersection(tuple(edge) for edge in cut_edges)
        if overlap:
            raise ValueError("cut_backbone relation overlaps an intact graph edge")
        cut_tensor = torch.tensor(
            cut_edges, dtype=torch.long, device=graph_edges.device
        ).t().contiguous()
        cut_features = _build_graph_edge_features(
            torch, sample, cut_tensor, position_scale
        )
        feature_padding = graph_edge_features.shape[1] - cut_features.shape[1]
        if feature_padding < 0:
            raise ValueError("cut_backbone base features exceed graph feature width")
        if feature_padding:
            cut_features = torch.cat(
                [
                    cut_features,
                    torch.zeros(
                        (cut_features.shape[0], feature_padding),
                        dtype=cut_features.dtype,
                        device=cut_features.device,
                    ),
                ],
                dim=1,
            )
        graph_edges = torch.cat([graph_edges, cut_tensor], dim=1)
        graph_edge_features = torch.cat(
            [graph_edge_features, cut_features], dim=0
        )
        cut_relation_id = relation_names.index("cut_backbone")
        edge_relation_ids = torch.cat(
            [
                edge_relation_ids,
                torch.full(
                    (len(cut_edges),),
                    cut_relation_id,
                    dtype=torch.long,
                    device=edge_relation_ids.device,
                ),
            ]
        )
        candidate_wc_edge_mask = torch.cat(
            [
                candidate_wc_edge_mask,
                torch.zeros(
                    len(cut_edges),
                    dtype=torch.bool,
                    device=candidate_wc_edge_mask.device,
                ),
            ]
        )
    cut_backbone_edge_mask = torch.zeros(
        graph_edges.shape[1], dtype=torch.bool, device=graph_edges.device
    )
    if cut_edges:
        cut_backbone_edge_mask[existing_count:] = True
    physical_loss_mask = torch.ones(
        graph_edges.shape[1], dtype=torch.float32, device=graph_edges.device
    )
    physical_loss_mask[cut_backbone_edge_mask] = 0.0
    return (
        graph_edges,
        graph_edge_features,
        edge_relation_ids,
        relation_names,
        candidate_wc_edge_mask,
        cut_backbone_edge_mask,
        physical_loss_mask,
    )


def _prepare_sample(
    torch,
    entry,
    device,
    electrostatic_cutoff,
    fourier_features,
    design_features,
    graph_mode,
    graph_cutoff,
    max_graph_neighbors,
    include_candidate_wc_edges,
    candidate_wc_top_k,
    candidate_wc_cutoff,
    restrict_pair_losses_to_candidate_wc_edges=False,
    physical_graph=False,
    design_edge_sidecar_path=None,
    require_explicit_design_edges=False,
    edge_family_pair=False,
    edge_family_crossover=False,
    edge_family_duplex_step=False,
    edge_family_start_spatial=False,
    legacy_feature_dimension=False,
):
    sample = load_oxdna_sample(entry["top"], entry["start"], entry.get("target"))
    inputs = _build_identity_inputs(torch, sample, device)
    features, start_a1, start_a3 = _build_shared_rigid_features(torch, sample, device)
    node_feature_names = []
    if physical_graph:
        features, physical_node_names = _append_physical_node_features(torch, features, sample, None)
        node_feature_names.extend(physical_node_names)
    features = _append_fourier_features(torch, features, fourier_features)
    features = _append_design_features(torch, features, sample, design_features)
    if legacy_feature_dimension:
        if entry.get("defect_sidecar"):
            raise ValueError(
                "legacy feature dimension cannot consume a defect sidecar"
            )
        defect_contract = {
            "features": None,
            "cut_backbone": {
                "relation_name": "cut_backbone",
                "edges": [],
                "physical_loss_mask": [],
            },
            "sidecar": None,
        }
    else:
        defect_contract = load_optional_defect_contract(
            sample,
            entry,
            device=device,
            dtype=features.dtype,
        )
        features = torch.cat([features, defect_contract["features"]], dim=1)
        node_feature_names.extend(DEFECT_CHANNELS)
    position_scale = _position_scale(torch, sample, device)
    design_sidecar = None
    typed_graph = None
    if design_edge_sidecar_path:
        if graph_mode != "backbone" or graph_cutoff != 0.0:
            raise ValueError("typed design edges require --graph-mode backbone and --graph-cutoff 0")
        if include_candidate_wc_edges or candidate_wc_top_k > 0:
            raise ValueError("typed design edges cannot be combined with target-derived candidate WC edges")
        if physical_graph:
            raise ValueError("typed design edges cannot be combined with the legacy physical graph")
        design_sidecar = load_design_edge_sidecar(
            design_edge_sidecar_path,
            entry,
            required=True,
        )
        typed_graph = build_typed_graph(
            sample,
            design_sidecar,
            pair=edge_family_pair,
            crossover=edge_family_crossover,
            duplex_step=edge_family_duplex_step,
            start_spatial=edge_family_start_spatial,
        )
        graph_edges = (
            torch.tensor(typed_graph["edges"], dtype=torch.long, device=device).t().contiguous()
            if typed_graph["edges"]
            else torch.empty((2, 0), dtype=torch.long, device=device)
        )
        base_edge_features = _build_graph_edge_features(
            torch, sample, graph_edges, position_scale
        )
        relation_features = torch.tensor(
            typed_graph["relations"], dtype=torch.float32, device=device
        )
        graph_edge_features = torch.cat(
            [base_edge_features, relation_features], dim=1
        )
        candidate_wc_edge_list = []
    else:
        if require_explicit_design_edges or any(
            (
                edge_family_pair,
                edge_family_crossover,
                edge_family_duplex_step,
                edge_family_start_spatial,
            )
        ):
            raise ValueError("explicit design-edge sidecar is required for this graph configuration")
        graph_edges = _build_graph_edges(
            torch,
            sample,
            graph_mode,
            graph_cutoff,
            max_graph_neighbors,
            device,
            include_candidate_wc_edges=include_candidate_wc_edges,
            candidate_wc_top_k=candidate_wc_top_k,
            candidate_wc_cutoff=candidate_wc_cutoff,
        )
        graph_edge_features = _build_graph_edge_features(
            torch, sample, graph_edges, position_scale
        )
        candidate_wc_edge_list = []
        if include_candidate_wc_edges and candidate_wc_top_k > 0:
            candidate_wc_edge_list = _target_wc_edges_oxview_like(
                sample,
                candidate_wc_cutoff,
            )
    candidate_wc_edges = (
        torch.tensor(
            [
                [src for src, _dst in candidate_wc_edge_list],
                [dst for _src, dst in candidate_wc_edge_list],
            ],
            dtype=torch.long,
            device=device,
        )
        if candidate_wc_edge_list
        else torch.empty((2, 0), dtype=torch.long, device=device)
    )
    candidate_wc_edge_set = set(candidate_wc_edge_list)
    graph_edge_list = list(zip(graph_edges[0].detach().cpu().tolist(), graph_edges[1].detach().cpu().tolist()))
    candidate_wc_edge_mask = torch.tensor(
        [edge in candidate_wc_edge_set for edge in graph_edge_list],
        dtype=torch.bool,
        device=device,
    )
    electrostatic_edges = _build_electrostatic_edges(
        torch,
        sample,
        sample.positions,
        electrostatic_cutoff,
        device,
    )
    explicit_reference_pairs = (
        [tuple(pair) for pair in design_sidecar["edges"]["base_pair"]]
        if design_sidecar is not None
        else _load_explicit_reference_pairs(entry)
    )
    explicit_start_pairs = _load_pair_list(entry.get("start_pair_file"))
    explicit_final_pairs = _load_pair_list(entry.get("final_pair_file"))
    reference_pairs_geometric_proxy = None
    helix_steps_geometric_proxy = None
    start_pairs = explicit_start_pairs
    if explicit_reference_pairs:
        reference_pairs = explicit_reference_pairs
        reference_pair_source = "explicit_design"
    else:
        duplex_geometry = build_reference_duplex_geometry(
            torch,
            sample,
            inputs["target_x_a"],
            pair_cutoff=4.0,
        )
        reference_pairs = duplex_geometry["reference_pairs"]
        reference_pair_source = "geometric_proxy"
        reference_pairs_geometric_proxy = duplex_geometry["reference_pairs"]
        helix_steps_geometric_proxy = duplex_geometry["helix_steps"]
    final_pairs = explicit_final_pairs if explicit_final_pairs else reference_pairs
    pair_state_source = (
        "explicit_start_final"
        if explicit_start_pairs and explicit_final_pairs
        else ("explicit_final_only" if explicit_final_pairs else None)
    )
    edge_relation_ids = torch.zeros(graph_edges.shape[1], dtype=torch.long, device=device)
    edge_relation_names = (
        typed_graph["relation_names"] if typed_graph is not None else ["default"]
    )
    edge_feature_names = (
        BASE_EDGE_FEATURE_NAMES
        + ["relation_{}".format(name) for name in edge_relation_names]
        if typed_graph is not None
        else []
    )
    if physical_graph:
        graph_edges, edge_relation_ids, edge_relation_names = _build_physical_graph_edges(
            torch,
            sample,
            graph_edges,
            start_pairs,
            final_pairs,
            reference_pairs,
            _build_duplex_steps(sample, reference_pairs),
            candidate_wc_edge_list,
            device,
        )
        graph_edge_features, edge_feature_names = _build_physical_graph_edge_features(
            torch,
            sample,
            graph_edges,
            edge_relation_ids,
            edge_relation_names,
            position_scale,
            start_pairs,
            final_pairs,
        )
        candidate_wc_edge_set = set()
        candidate_wc_edge_list = sorted(candidate_wc_edge_set)
        candidate_wc_edges = (
            torch.tensor(
                [
                    [src for src, _dst in candidate_wc_edge_list],
                    [dst for _src, dst in candidate_wc_edge_list],
                ],
                dtype=torch.long,
                device=device,
            )
            if candidate_wc_edge_list
            else torch.empty((2, 0), dtype=torch.long, device=device)
        )
        graph_edge_list = list(zip(graph_edges[0].detach().cpu().tolist(), graph_edges[1].detach().cpu().tolist()))
        candidate_wc_edge_mask = torch.tensor(
            [edge in candidate_wc_edge_set for edge in graph_edge_list],
            dtype=torch.bool,
            device=device,
        )
    elif typed_graph is None:
        edge_feature_names = []
    (
        graph_edges,
        graph_edge_features,
        edge_relation_ids,
        edge_relation_names,
        candidate_wc_edge_mask,
        cut_backbone_edge_mask,
        physical_loss_mask,
    ) = _attach_cut_backbone_relation(
        torch,
        sample,
        graph_edges,
        graph_edge_features,
        edge_relation_ids,
        edge_relation_names,
        candidate_wc_edge_mask,
        position_scale,
        defect_contract,
        preserve_design_edge_v1=(
            legacy_feature_dimension
            or (typed_graph is not None and defect_contract["sidecar"] is None)
        ),
    )
    pair_supervision_edge_mask = torch.ones(graph_edges.shape[1], dtype=torch.bool, device=device)
    if restrict_pair_losses_to_candidate_wc_edges:
        pair_supervision_edge_mask = candidate_wc_edge_mask.clone()
    candidate_pair_state_features = torch.empty((graph_edges.shape[1], 0), dtype=torch.float32, device=device)
    graph_edge_features = torch.cat([graph_edge_features, candidate_pair_state_features], dim=1)
    backbone_edges = (
        torch.tensor(sample.backbone_edges, dtype=torch.long, device=device)
        if sample.backbone_edges
        else torch.empty((0, 2), dtype=torch.long, device=device)
    )
    return {
        "entry": entry,
        "sample": sample,
        "inputs": inputs,
        "features": features,
        "start_a1": start_a1,
        "start_a3": start_a3,
        "position_scale": position_scale,
        "graph_edges": graph_edges,
        "graph_edge_features": graph_edge_features,
        "node_feature_names": node_feature_names,
        "edge_feature_names": edge_feature_names,
        "edge_relation_ids": edge_relation_ids,
        "edge_relation_names": edge_relation_names,
        "cut_backbone_edge_mask": cut_backbone_edge_mask,
        "physical_loss_mask": physical_loss_mask,
        "candidate_pair_state_features": candidate_pair_state_features,
        "candidate_wc_edges": candidate_wc_edges,
        "candidate_wc_edge_mask": candidate_wc_edge_mask,
        "pair_supervision_edge_mask": pair_supervision_edge_mask,
        "electrostatic_edges": electrostatic_edges,
        "backbone_edges": backbone_edges,
        "start_pairs": start_pairs,
        "final_pairs": final_pairs,
        "pair_state_source": pair_state_source,
        "reference_pairs": reference_pairs,
        "reference_pair_source": reference_pair_source,
        "reference_pairs_geometric_proxy": reference_pairs_geometric_proxy,
        "helix_steps": _build_duplex_steps(sample, reference_pairs),
        "helix_steps_geometric_proxy": helix_steps_geometric_proxy,
        "design_edge_sidecar": os.path.abspath(design_edge_sidecar_path) if design_edge_sidecar_path else None,
        "design_edge_fingerprint": design_sidecar.get("fingerprint") if design_sidecar is not None else None,
        "design_edge_counts": design_sidecar.get("counts") if design_sidecar is not None else None,
        "design_edge_relation_counts": typed_graph.get("relation_counts") if typed_graph is not None else None,
        "design_edge_enabled_families": typed_graph.get("enabled_families") if typed_graph is not None else None,
        "design_crossover_edges": (
            [tuple(edge) for edge in design_sidecar["edges"]["crossover"]]
            if design_sidecar is not None
            else []
        ),
        "defect_sidecar": (
            os.path.abspath(entry["defect_sidecar"])
            if isinstance(entry.get("defect_sidecar"), str)
            else None
        ),
        "defect_feature_schema": (
            None if legacy_feature_dimension else DEFECT_FEATURE_SCHEMA
        ),
        "target_masks": dict(
            entry.get("target_masks") or {"endpoint_positions": True}
        ),
    }


def _file_fingerprint(path):
    stat = os.stat(path)
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return {
        "path": os.path.abspath(path),
        "size": stat.st_size,
        "sha256": digest.hexdigest(),
    }


def _optional_file_fingerprint(path):
    if not path:
        return None
    abs_path = os.path.abspath(path)
    if os.path.exists(abs_path):
        return _file_fingerprint(abs_path)
    return {
        "path": abs_path,
        "missing": True,
    }


def _sample_cache_path(entry, args, cache_dir):
    if not cache_dir:
        return None
    payload = {
        "top": _file_fingerprint(entry["top"]),
        "start": _file_fingerprint(entry["start"]),
        "cadnano_json": _optional_file_fingerprint(entry.get("cadnano_json")),
        "virt2nuc": _optional_file_fingerprint(entry.get("virt2nuc")),
        "design_edge_sidecar": _optional_file_fingerprint(entry.get("design_edge_sidecar")),
        "design_edge_sidecar_sha256": entry.get("design_edge_sidecar_sha256"),
        "design_edge_fingerprint": entry.get("design_edge_fingerprint"),
        "canonical_map": _optional_file_fingerprint(entry.get("canonical_map")),
        "defect_sidecar": _optional_file_fingerprint(entry.get("defect_sidecar")),
        "defect_sidecar_sha256": entry.get("defect_sidecar_sha256"),
        "plan_sha256": entry.get("plan_sha256"),
        "static_graph_inputs": entry.get("static_graph_inputs"),
        "electrostatic_cutoff": args.electrostatic_cutoff,
        "fourier_features": args.fourier_features,
        "design_features": args.design_features,
        "graph_mode": args.graph_mode,
        "graph_cutoff": args.graph_cutoff,
        "max_graph_neighbors": args.max_graph_neighbors,
        "include_candidate_wc_edges": args.include_candidate_wc_edges,
        "candidate_wc_top_k": args.candidate_wc_top_k,
        "candidate_wc_cutoff": args.candidate_wc_cutoff,
        "restrict_pair_losses_to_candidate_wc_edges": args.restrict_pair_losses_to_candidate_wc_edges,
        "physical_graph": bool(args.physical_graph or args.model_kind == "dgnn-physic"),
        "require_explicit_design_edges": bool(
            getattr(args, "require_explicit_design_edges", False)
        ),
        "edge_family_pair": bool(getattr(args, "edge_family_pair", False)),
        "edge_family_crossover": bool(
            getattr(args, "edge_family_crossover", False)
        ),
        "edge_family_duplex_step": bool(
            getattr(args, "edge_family_duplex_step", False)
        ),
        "edge_family_start_spatial": bool(
            getattr(args, "edge_family_start_spatial", False)
        ),
        "legacy_feature_dimension": bool(
            getattr(args, "legacy_feature_dimension", False)
        ),
        "cache_version": int(getattr(args, "cache_version", 1)),
    }
    digest = __import__("hashlib").sha1(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
    safe_id = "".join(ch if ch.isalnum() or ch in ("-", "_", ".") else "_" for ch in entry["id"])
    return os.path.join(cache_dir, "{}_{}.pt".format(safe_id, digest[:16]))


def _refresh_cached_supervision(torch, prepared, entry, device):
    """Refresh target-dependent fields while retaining the cached static graph."""

    sample = load_oxdna_sample(entry["top"], entry["start"], entry.get("target"))
    if sample.num_nucleotides != prepared["sample"].num_nucleotides:
        raise ValueError("cached static graph node count no longer matches sample")
    inputs = _build_identity_inputs(torch, sample, device)
    explicit_reference_pairs = _load_explicit_reference_pairs(entry)
    if prepared.get("design_edge_fingerprint") is not None:
        reference_pairs = list(prepared["reference_pairs"])
        reference_pair_source = "explicit_design"
        reference_pairs_geometric_proxy = None
        helix_steps_geometric_proxy = None
    elif explicit_reference_pairs:
        reference_pairs = explicit_reference_pairs
        reference_pair_source = "explicit_design"
        reference_pairs_geometric_proxy = None
        helix_steps_geometric_proxy = None
    else:
        if inputs["target_x_a"] is None:
            raise ValueError(
                "endpoint target is required when no explicit design pairs are available"
            )
        duplex_geometry = build_reference_duplex_geometry(
            torch,
            sample,
            inputs["target_x_a"],
            pair_cutoff=4.0,
        )
        reference_pairs = duplex_geometry["reference_pairs"]
        reference_pair_source = "geometric_proxy"
        reference_pairs_geometric_proxy = duplex_geometry["reference_pairs"]
        helix_steps_geometric_proxy = duplex_geometry["helix_steps"]
    start_pairs = _load_pair_list(entry.get("start_pair_file"))
    explicit_final_pairs = _load_pair_list(entry.get("final_pair_file"))
    final_pairs = explicit_final_pairs if explicit_final_pairs else reference_pairs
    pair_state_source = (
        "explicit_start_final"
        if start_pairs and explicit_final_pairs
        else ("explicit_final_only" if explicit_final_pairs else None)
    )
    prepared.update(
        {
            "entry": entry,
            "sample": sample,
            "inputs": inputs,
            "start_pairs": start_pairs,
            "final_pairs": final_pairs,
            "pair_state_source": pair_state_source,
            "reference_pairs": reference_pairs,
            "reference_pair_source": reference_pair_source,
            "reference_pairs_geometric_proxy": reference_pairs_geometric_proxy,
            "helix_steps": _build_duplex_steps(sample, reference_pairs),
            "helix_steps_geometric_proxy": helix_steps_geometric_proxy,
            "target_masks": dict(entry.get("target_masks") or {"endpoint_positions": True}),
        }
    )
    return prepared


def _prepare_sample_with_cache(
    torch,
    entry,
    device,
    electrostatic_cutoff,
    fourier_features,
    design_features,
    graph_mode,
    graph_cutoff,
    max_graph_neighbors,
    include_candidate_wc_edges,
    candidate_wc_top_k,
    candidate_wc_cutoff,
    restrict_pair_losses_to_candidate_wc_edges=False,
    physical_graph=False,
    cache_dir=None,
    args=None,
):
    cache_path = _sample_cache_path(entry, args, cache_dir) if cache_dir else None
    if cache_path and os.path.exists(cache_path):
        cached = torch.load(cache_path, map_location="cpu")
        target_dependent_graph = bool(
            physical_graph
            or (include_candidate_wc_edges and candidate_wc_top_k > 0)
        )
        if not target_dependent_graph:
            return _refresh_cached_supervision(torch, cached, entry, device)
    prepared = _prepare_sample(
        torch,
        entry,
        device,
        electrostatic_cutoff,
        fourier_features,
        design_features,
        graph_mode,
        graph_cutoff,
        max_graph_neighbors,
        include_candidate_wc_edges,
        candidate_wc_top_k,
        candidate_wc_cutoff,
        restrict_pair_losses_to_candidate_wc_edges,
        physical_graph,
        design_edge_sidecar_path=entry.get("design_edge_sidecar"),
        require_explicit_design_edges=bool(
            getattr(args, "require_explicit_design_edges", False)
        ),
        edge_family_pair=bool(getattr(args, "edge_family_pair", False)),
        edge_family_crossover=bool(
            getattr(args, "edge_family_crossover", False)
        ),
        edge_family_duplex_step=bool(
            getattr(args, "edge_family_duplex_step", False)
        ),
        edge_family_start_spatial=bool(
            getattr(args, "edge_family_start_spatial", False)
        ),
        legacy_feature_dimension=bool(
            getattr(args, "legacy_feature_dimension", False)
        ),
    )
    if cache_path:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        torch.save(prepared, cache_path)
    return prepared


def _move_inputs(torch, value, device):
    if isinstance(value, dict):
        return {key: _move_inputs(torch, item, device) for key, item in value.items()}
    if hasattr(value, "to"):
        return value.to(device)
    return value


def _prepared_on_device(torch, prepared, device):
    return {
        "entry": prepared["entry"],
        "sample": prepared["sample"],
        "inputs": _move_inputs(torch, prepared["inputs"], device),
        "features": prepared["features"].to(device),
        "start_a1": prepared["start_a1"].to(device),
        "start_a3": prepared["start_a3"].to(device),
        "position_scale": prepared["position_scale"].to(device),
        "graph_edges": prepared["graph_edges"].to(device),
        "graph_edge_features": prepared["graph_edge_features"].to(device),
        "node_feature_names": prepared.get("node_feature_names", []),
        "edge_feature_names": prepared.get("edge_feature_names", []),
        "edge_relation_ids": prepared.get("edge_relation_ids", torch.empty((0,), dtype=torch.long)).to(device),
        "edge_relation_names": prepared.get("edge_relation_names", ["default"]),
        "cut_backbone_edge_mask": prepared.get(
            "cut_backbone_edge_mask",
            torch.zeros(prepared["graph_edges"].shape[1], dtype=torch.bool),
        ).to(device),
        "physical_loss_mask": prepared.get(
            "physical_loss_mask",
            torch.ones(prepared["graph_edges"].shape[1], dtype=torch.float32),
        ).to(device),
        "candidate_pair_state_features": prepared["candidate_pair_state_features"].to(device),
        "candidate_wc_edges": prepared["candidate_wc_edges"].to(device),
        "candidate_wc_edge_mask": prepared["candidate_wc_edge_mask"].to(device),
        "pair_supervision_edge_mask": prepared["pair_supervision_edge_mask"].to(device),
        "electrostatic_edges": prepared["electrostatic_edges"].to(device),
        "backbone_edges": prepared["backbone_edges"].to(device),
        "start_pairs": prepared["start_pairs"],
        "final_pairs": prepared["final_pairs"],
        "pair_state_source": prepared["pair_state_source"],
        "reference_pairs": prepared["reference_pairs"],
        "reference_pair_source": prepared["reference_pair_source"],
        "reference_pairs_geometric_proxy": prepared["reference_pairs_geometric_proxy"],
        "helix_steps": prepared["helix_steps"],
        "helix_steps_geometric_proxy": prepared["helix_steps_geometric_proxy"],
        "design_edge_sidecar": prepared.get("design_edge_sidecar"),
        "design_edge_fingerprint": prepared.get("design_edge_fingerprint"),
        "design_edge_counts": prepared.get("design_edge_counts"),
        "design_edge_relation_counts": prepared.get("design_edge_relation_counts"),
        "design_edge_enabled_families": prepared.get("design_edge_enabled_families"),
        "design_crossover_edges": prepared.get("design_crossover_edges", []),
        "defect_sidecar": prepared.get("defect_sidecar"),
        "defect_feature_schema": prepared.get("defect_feature_schema"),
        "target_masks": dict(prepared.get("target_masks") or {"endpoint_positions": True}),
        "node_train_mask": prepared["node_train_mask"].to(device),
        "node_val_mask": prepared["node_val_mask"].to(device),
    }


def _sample_metrics(torch, prepared, pred_positions, pred_a1, pred_a3, args):
    inputs = prepared["inputs"]
    electrostatic = _electrostatic_energy(
        torch,
        pred_positions,
        prepared["electrostatic_edges"],
        args.electrostatic_debye_length,
        args.electrostatic_coefficient,
    )
    target_positions = inputs["target_x_a"]
    target_a1 = inputs["target_a1"]
    target_a3 = inputs["target_a3"]
    rmsd = _rmsd_tensor(pred_positions, target_positions)
    os_score = _orientation_score(torch, pred_a1, pred_a3, target_a1, target_a3)
    return rmsd, os_score, electrostatic


def _edge_distance_rms_error(torch, edges, reference_positions, pred_positions):
    if not edges:
        return None
    edge_index = torch.tensor(edges, dtype=torch.long, device=pred_positions.device)
    reference_distances = torch.norm(
        reference_positions[edge_index[:, 1]] - reference_positions[edge_index[:, 0]],
        p=2,
        dim=1,
    )
    predicted_distances = torch.norm(
        pred_positions[edge_index[:, 1]] - pred_positions[edge_index[:, 0]],
        p=2,
        dim=1,
    )
    return torch.sqrt(torch.mean((predicted_distances - reference_distances) ** 2))


def _reference_pair_set(prepared):
    return set(tuple(sorted((src, dst))) for src, dst in prepared["reference_pairs"])


def _pair_index_tensor(torch, pairs, device):
    if pairs is None:
        return None
    if torch.is_tensor(pairs):
        if pairs.numel() == 0:
            return None
        pair_index = pairs.to(device=device, dtype=torch.long)
    else:
        if not pairs:
            return None
        pair_index = torch.tensor(pairs, dtype=torch.long, device=device)
    return pair_index.view(-1, 2)


def _pair_node_representation(torch, positions, a1, a3, reference_pairs, eps=1e-8):
    pair_index = _pair_index_tensor(torch, reference_pairs, positions.device)
    if pair_index is None:
        return positions, a1, a3
    pair_positions = 0.5 * (positions[pair_index[:, 0]] + positions[pair_index[:, 1]])
    pair_axis = positions[pair_index[:, 1]] - positions[pair_index[:, 0]]
    pair_a1, pair_a3 = _orthonormalize_frame(
        torch,
        pair_axis,
        0.5 * (a3[pair_index[:, 0]] + a3[pair_index[:, 1]]),
        eps=eps,
    )
    return pair_positions, pair_a1, pair_a3


def _filtered_pair_edges(prepared, pair_logits):
    graph_edges = prepared["graph_edges"]
    if pair_logits is None or graph_edges.numel() == 0:
        return graph_edges, pair_logits
    supervision_mask = prepared.get("pair_supervision_edge_mask")
    if supervision_mask is not None:
        if int(supervision_mask.sum().detach().cpu()) == 0:
            return graph_edges[:, supervision_mask], pair_logits[supervision_mask]
        graph_edges = graph_edges[:, supervision_mask]
        pair_logits = pair_logits[supervision_mask]
    return graph_edges, pair_logits


def _decode_pair_logits_one_to_one(torch, prepared, pair_logits):
    graph_edges, pair_logits = _filtered_pair_edges(prepared, pair_logits)
    if pair_logits is None or graph_edges.numel() == 0:
        return []
    row, col = graph_edges
    pair_scores = {}
    for idx, (src, dst) in enumerate(zip(row.detach().cpu().tolist(), col.detach().cpu().tolist())):
        src = int(src)
        dst = int(dst)
        if src == dst:
            continue
        pair = tuple(sorted((src, dst)))
        score = float(pair_logits[idx].detach().cpu())
        if pair not in pair_scores or score > pair_scores[pair]:
            pair_scores[pair] = score
    ranked = sorted(pair_scores.items(), key=lambda item: (-item[1], item[0]))
    used = set()
    decoded = []
    for pair, _score in ranked:
        src, dst = pair
        if src in used or dst in used:
            continue
        decoded.append(pair)
        used.add(src)
        used.add(dst)
    return sorted(decoded)


def _pair_assignment_metrics(prepared, decoded_pairs):
    decoded_pair_set = set(tuple(sorted((src, dst))) for src, dst in decoded_pairs)
    reference_pair_set = _reference_pair_set(prepared)
    matched = decoded_pair_set & reference_pair_set
    decoded_node_count = {}
    for src, dst in decoded_pair_set:
        decoded_node_count[src] = decoded_node_count.get(src, 0) + 1
        decoded_node_count[dst] = decoded_node_count.get(dst, 0) + 1
    conflicting_nodes = sum(1 for count in decoded_node_count.values() if count > 1)
    num_nodes = max(1, prepared["sample"].num_nucleotides)
    precision = (
        float(len(matched)) / float(len(decoded_pair_set))
        if decoded_pair_set
        else 0.0
    )
    recall = (
        float(len(matched)) / float(len(reference_pair_set))
        if reference_pair_set
        else 0.0
    )
    f1 = (
        2.0 * precision * recall / (precision + recall)
        if (precision + recall) > 0
        else 0.0
    )
    occupancy = (
        min(1.0, float(2 * len(decoded_pair_set)) / float(2 * len(reference_pair_set)))
        if reference_pair_set
        else 0.0
    )
    node_scan = _pair_node_partner_scan_metrics(reference_pair_set, decoded_pair_set)
    metrics = {
        "decoded_pair_count": len(decoded_pair_set),
        "decoded_pair_precision": precision,
        "decoded_pair_recall": recall,
        "decoded_pair_f1": f1,
        "decoded_pair_occupancy": occupancy,
        "decoded_pair_conflict_rate": float(conflicting_nodes) / float(num_nodes),
    }
    metrics.update(node_scan)
    return metrics


def _pair_node_partner_scan_metrics(reference_pair_set, decoded_pair_set):
    decoded_partner = {}
    for src, dst in decoded_pair_set:
        decoded_partner[src] = dst
        decoded_partner[dst] = src
    matched_pairs = 0
    unmatched_nodes = set()
    for src, dst in reference_pair_set:
        if decoded_partner.get(src) == dst and decoded_partner.get(dst) == src:
            matched_pairs += 1
        else:
            unmatched_nodes.add(src)
            unmatched_nodes.add(dst)
    reference_nodes = set()
    for src, dst in reference_pair_set:
        reference_nodes.add(src)
        reference_nodes.add(dst)
    decoded_nodes = set()
    for src, dst in decoded_pair_set:
        decoded_nodes.add(src)
        decoded_nodes.add(dst)
    extra_predicted_nodes = decoded_nodes - reference_nodes
    pair_recall = (
        float(matched_pairs) / float(len(reference_pair_set))
        if reference_pair_set
        else 0.0
    )
    node_recall = (
        float(len(reference_nodes - unmatched_nodes)) / float(len(reference_nodes))
        if reference_nodes
        else 0.0
    )
    return {
        "decoded_pair_node_scan_matched_pair_count": matched_pairs,
        "decoded_pair_node_scan_unmatched_reference_pair_count": len(reference_pair_set) - matched_pairs,
        "decoded_pair_node_scan_unmatched_reference_node_count": len(unmatched_nodes),
        "decoded_pair_node_scan_extra_predicted_node_count": len(extra_predicted_nodes),
        "decoded_pair_node_scan_reference_pair_recall": pair_recall,
        "decoded_pair_node_scan_reference_node_recall": node_recall,
    }


def _edge_tensor_to_pairs(edge_tensor):
    if edge_tensor is None or edge_tensor.numel() == 0:
        return []
    rows, cols = edge_tensor.detach().cpu().tolist()
    return [(int(src), int(dst)) for src, dst in zip(rows, cols)]


def _realize_decoded_pair_geometry(torch, prepared, pred_positions, decoded_pairs, eps=1e-8):
    reference_pair_set = _reference_pair_set(prepared)
    if not decoded_pairs or not reference_pair_set:
        return pred_positions
    target_positions = prepared["inputs"]["target_x_a"]
    realized = pred_positions.clone()
    used = set()
    for src, dst in decoded_pairs:
        pair = tuple(sorted((int(src), int(dst))))
        if pair not in reference_pair_set:
            continue
        src, dst = pair
        if src in used or dst in used:
            continue
        target_axis = target_positions[dst] - target_positions[src]
        target_distance = torch.norm(target_axis, p=2).clamp(min=eps)
        target_unit = target_axis / target_distance
        target_center = 0.5 * (target_positions[src] + target_positions[dst])
        realized[src] = target_center - 0.5 * target_distance * target_unit
        realized[dst] = target_center + 0.5 * target_distance * target_unit
        used.add(src)
        used.add(dst)
    return realized


def _realize_reference_pair_frame_geometry(torch, prepared, pred_positions):
    if prepared.get("reference_pair_source") != "explicit_design":
        raise ValueError("reference pair-frame realization requires explicit_design reference pairs")
    reference_pairs = prepared.get("reference_pairs") or []
    if not reference_pairs:
        return pred_positions
    target_positions = prepared["inputs"]["target_x_a"]
    realized = pred_positions.clone()
    for src, dst in reference_pairs:
        realized[int(src)] = target_positions[int(src)]
        realized[int(dst)] = target_positions[int(dst)]
    return realized


def _cross_strand_neighbor_pairs(torch, sample, positions, margin):
    if margin <= 0:
        return []
    rows = sample.topology.rows
    try:
        from scipy.spatial import cKDTree
    except Exception:
        cKDTree = None

    if cKDTree is not None:
        coords = positions.detach().cpu().numpy()
        tree = cKDTree(coords)
        candidate_pairs = sorted(tree.query_pairs(r=margin, output_type="set"))
    else:
        candidate_pairs = [
            (src, dst)
            for src in range(sample.num_nucleotides)
            for dst in range(src + 1, sample.num_nucleotides)
            if torch.norm(positions[src] - positions[dst], p=2) < margin
        ]

    cross_strand_pairs = []
    for src, dst in candidate_pairs:
        src = int(src)
        dst = int(dst)
        if rows[src].strand_id == rows[dst].strand_id:
            continue
        cross_strand_pairs.append((src, dst))
    return cross_strand_pairs


def _repel_nonselected_cross_pairs(torch, sample, positions, decoded_pairs, margin, steps, eps=1e-8):
    if steps <= 0 or margin <= 0:
        return positions
    decoded_pair_set = set(tuple(sorted((int(src), int(dst)))) for src, dst in decoded_pairs)
    node_to_group = {}
    groups = []
    for src, dst in decoded_pair_set:
        group_index = len(groups)
        groups.append((src, dst))
        node_to_group[src] = group_index
        node_to_group[dst] = group_index
    for idx in range(sample.num_nucleotides):
        if idx not in node_to_group:
            node_to_group[idx] = len(groups)
            groups.append((idx,))

    realized = positions.clone()
    fallback_axis = torch.tensor([1.0, 0.0, 0.0], dtype=positions.dtype, device=positions.device)
    for _step in range(steps):
        moved = False
        for src, dst in _cross_strand_neighbor_pairs(torch, sample, realized, margin):
            pair = tuple(sorted((src, dst)))
            if pair in decoded_pair_set:
                continue
            src_group = node_to_group[src]
            dst_group = node_to_group[dst]
            if src_group == dst_group:
                continue
            delta = realized[src] - realized[dst]
            distance = torch.norm(delta, p=2)
            if float(distance.detach().cpu()) >= margin:
                continue
            direction = delta / distance.clamp(min=eps)
            if float(distance.detach().cpu()) < eps:
                direction = fallback_axis
            correction = 0.5 * (margin - distance + 1e-4) * direction
            for node in groups[src_group]:
                realized[node] = realized[node] + correction
            for node in groups[dst_group]:
                realized[node] = realized[node] - correction
            moved = True
        if not moved:
            break
    return realized


def _assignment_realized_summary(
    torch,
    active,
    decoded_pair_assignment,
    pred_positions,
    pred_a1,
    pred_a3,
    args,
    repulsion_margin=None,
    repulsion_steps=None,
):
    if repulsion_margin is None:
        repulsion_margin = args.assignment_realized_repulsion_margin
    if repulsion_steps is None:
        repulsion_steps = args.assignment_realized_repulsion_steps
    realized_positions = (
        _realize_decoded_pair_geometry(
            torch,
            active,
            pred_positions,
            decoded_pair_assignment,
        )
        if decoded_pair_assignment
        else pred_positions
    )
    realized_positions = _repel_nonselected_cross_pairs(
        torch,
        active["sample"],
        realized_positions,
        decoded_pair_assignment,
        repulsion_margin,
        repulsion_steps,
    )
    rmsd, os_score, electrostatic = _sample_metrics(
        torch,
        active,
        realized_positions,
        pred_a1,
        pred_a3,
        args,
    )
    physical_metrics, physical_metrics_proxy = _sample_physical_metrics(
        torch,
        active,
        realized_positions,
        pred_a1,
        pred_a3,
        args,
    )
    return {
        "positions": realized_positions,
        "repulsion_margin": repulsion_margin,
        "repulsion_steps": repulsion_steps,
        "rmsd": float(rmsd.detach().cpu()),
        "os": float(os_score.detach().cpu()),
        "electrostatic_energy": float(electrostatic.detach().cpu()),
        "physical_rule_metrics": physical_metrics.to_dict(),
        "physical_rule_metrics_geometric_proxy": (
            physical_metrics_proxy.to_dict() if physical_metrics_proxy is not None else None
        ),
    }


def _reference_pair_frame_summary(torch, active, pred_positions, pred_a1, pred_a3, args):
    realized_positions = _realize_reference_pair_frame_geometry(torch, active, pred_positions)
    rmsd, os_score, electrostatic = _sample_metrics(
        torch,
        active,
        realized_positions,
        pred_a1,
        pred_a3,
        args,
    )
    physical_metrics, physical_metrics_proxy = _sample_physical_metrics(
        torch,
        active,
        realized_positions,
        pred_a1,
        pred_a3,
        args,
    )
    return {
        "positions": realized_positions,
        "rmsd": float(rmsd.detach().cpu()),
        "os": float(os_score.detach().cpu()),
        "electrostatic_energy": float(electrostatic.detach().cpu()),
        "physical_rule_metrics": physical_metrics.to_dict(),
        "physical_rule_metrics_geometric_proxy": (
            physical_metrics_proxy.to_dict() if physical_metrics_proxy is not None else None
        ),
    }


def _parse_assignment_realized_variants(spec):
    variants = []
    if not spec:
        return variants
    for raw_item in spec.split(","):
        item = raw_item.strip()
        if not item:
            continue
        parts = item.split(":")
        if len(parts) != 3:
            raise ValueError(
                "assignment-realized variant {!r} must use name:margin:steps".format(item)
            )
        name, margin_text, steps_text = parts
        safe_name = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in name)
        if not safe_name:
            raise ValueError("assignment-realized variant name cannot be empty")
        variants.append({
            "name": safe_name,
            "repulsion_margin": float(margin_text),
            "repulsion_steps": int(steps_text),
        })
    return variants


def _write_assignment_realized_conf(
    sample,
    pred_a1,
    pred_a3,
    assignment_realized,
    output_path,
    time_label,
):
    assignment_frame = decode_to_oxdna_frame(
        sample,
        _positions_from_tensor(assignment_realized["positions"]),
        _positions_from_tensor(pred_a1),
        _positions_from_tensor(pred_a3),
        time=time_label,
        box=sample.target_frame.box if sample.target_frame is not None else sample.start_frame.box,
        energy=sample.target_frame.energy if sample.target_frame is not None else sample.start_frame.energy,
    )
    assignment_report = validate_frame(sample.topology, assignment_frame)
    if not assignment_report.ok:
        raise RuntimeError(
            "assignment-realized validation failed for {}: {}".format(
                output_path,
                assignment_report.errors,
            )
        )
    write_config(assignment_frame, output_path)
    return assignment_report.warnings


def _pair_classification_loss(torch, prepared, pair_logits):
    if pair_logits is None:
        return torch.tensor(0.0, dtype=torch.float32)
    graph_edges, pair_logits = _filtered_pair_edges(prepared, pair_logits)
    if graph_edges.numel() == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    row, col = graph_edges
    num_nodes = _prepared_num_nodes(prepared, graph_edges)
    pair_min = torch.minimum(row, col)
    pair_max = torch.maximum(row, col)
    pair_key = pair_min.to(dtype=torch.long) * num_nodes + pair_max.to(dtype=torch.long)
    reference_pairs = prepared.get("reference_pairs") or []
    if not reference_pairs:
        targets = torch.zeros_like(pair_logits)
    else:
        reference_tensor = torch.tensor(
            sorted(
                (int(src), int(dst)) if int(src) < int(dst) else (int(dst), int(src))
                for src, dst in reference_pairs
            ),
            dtype=torch.long,
            device=pair_logits.device,
        )
        reference_key = reference_tensor[:, 0] * num_nodes + reference_tensor[:, 1]
        targets = _tensor_key_membership(torch, pair_key, reference_key).to(dtype=pair_logits.dtype)
    return torch.nn.functional.binary_cross_entropy_with_logits(pair_logits, targets)


def _pair_logit_exclusivity_loss(torch, prepared, pair_logits):
    if pair_logits is None:
        return torch.tensor(0.0, dtype=torch.float32)
    graph_edges = prepared["graph_edges"]
    if graph_edges.numel() == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    supervision_mask = prepared.get("pair_supervision_edge_mask")
    if supervision_mask is not None:
        if int(supervision_mask.sum().detach().cpu()) == 0:
            return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
        graph_edges = graph_edges[:, supervision_mask]
        pair_logits = pair_logits[supervision_mask]
    row, col = graph_edges
    if row.numel() == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    probs = torch.sigmoid(pair_logits)
    num_nodes = prepared["sample"].num_nucleotides
    node_index = torch.cat([row, col], dim=0)
    node_probs = torch.cat([probs, probs], dim=0)
    conflict_sums = torch.zeros(num_nodes, dtype=pair_logits.dtype, device=pair_logits.device)
    conflict_sums.index_add_(0, node_index, node_probs)
    conflict_counts = torch.zeros(num_nodes, dtype=pair_logits.dtype, device=pair_logits.device)
    conflict_counts.index_add_(0, node_index, torch.ones_like(node_probs))
    active = conflict_counts > 1.0
    if int(active.sum().detach().cpu()) == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    return torch.mean(torch.clamp(conflict_sums[active] - 1.0, min=0.0))


def _pair_logit_symmetry_loss(torch, prepared, pair_logits):
    if pair_logits is None:
        return torch.tensor(0.0, dtype=torch.float32)
    graph_edges = prepared["graph_edges"]
    if graph_edges.numel() == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    supervision_mask = prepared.get("pair_supervision_edge_mask")
    if supervision_mask is not None:
        if int(supervision_mask.sum().detach().cpu()) == 0:
            return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
        graph_edges = graph_edges[:, supervision_mask]
        pair_logits = pair_logits[supervision_mask]
    row, col = graph_edges
    if row.numel() == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    num_nodes = _prepared_num_nodes(prepared, graph_edges)
    edge_index = row.to(dtype=torch.long) * num_nodes + col.to(dtype=torch.long)
    reverse_index = col.to(dtype=torch.long) * num_nodes + row.to(dtype=torch.long)
    index_to_pos = {
        int(key): idx
        for idx, key in enumerate(edge_index.detach().cpu().tolist())
    }
    reverse_positions = torch.tensor(
        [index_to_pos.get(int(key), -1) for key in reverse_index.detach().cpu().tolist()],
        dtype=torch.long,
        device=pair_logits.device,
    )
    valid = reverse_positions >= 0
    if int(valid.sum().detach().cpu()) == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    forward = pair_logits[valid]
    reverse = pair_logits[reverse_positions[valid]]
    unique = edge_index[valid] < reverse_index[valid]
    if int(unique.sum().detach().cpu()) == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    return torch.mean((forward[unique] - reverse[unique]) ** 2)


def _pair_logit_sinkhorn_loss(torch, prepared, pair_logits, sinkhorn_iters=5, epsilon=1e-6):
    if pair_logits is None:
        return torch.tensor(0.0, dtype=torch.float32)
    graph_edges = prepared["graph_edges"]
    if graph_edges.numel() == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    supervision_mask = prepared.get("pair_supervision_edge_mask")
    if supervision_mask is not None:
        if int(supervision_mask.sum().detach().cpu()) == 0:
            return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
        graph_edges = graph_edges[:, supervision_mask]
        pair_logits = pair_logits[supervision_mask]
    row, col = graph_edges
    if row.numel() == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)

    candidate_nodes = torch.unique(torch.cat([row, col], dim=0))
    if int(candidate_nodes.numel()) <= 1:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)

    num_nodes = _prepared_num_nodes(prepared, graph_edges)
    size = int(candidate_nodes.numel())
    node_to_index = torch.full(
        (num_nodes,),
        -1,
        dtype=torch.long,
        device=pair_logits.device,
    )
    node_to_index[candidate_nodes] = torch.arange(size, dtype=torch.long, device=pair_logits.device)
    score_matrix = torch.full((size, size), -20.0, dtype=pair_logits.dtype, device=pair_logits.device)
    score_matrix[node_to_index[row], node_to_index[col]] = pair_logits

    score_matrix = score_matrix - torch.diag_embed(
        torch.full((size,), 20.0, dtype=pair_logits.dtype, device=pair_logits.device)
    )
    transport = torch.exp(score_matrix)
    for _ in range(sinkhorn_iters):
        transport = transport / torch.clamp(transport.sum(dim=1, keepdim=True), min=epsilon)
        transport = transport / torch.clamp(transport.sum(dim=0, keepdim=True), min=epsilon)

    losses = []
    row_sums = transport.sum(dim=1)
    col_sums = transport.sum(dim=0)
    losses.append(torch.mean((row_sums - 1.0) ** 2))
    losses.append(torch.mean((col_sums - 1.0) ** 2))

    losses.append(torch.mean((torch.sigmoid(pair_logits) - transport[node_to_index[row], node_to_index[col]]) ** 2))

    return sum(losses) / float(len(losses))


def _pair_partner_selection_loss(torch, prepared, pair_logits, epsilon=1e-6):
    if pair_logits is None:
        return torch.tensor(0.0, dtype=torch.float32)
    graph_edges = prepared["graph_edges"]
    if graph_edges.numel() == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    supervision_mask = prepared.get("pair_supervision_edge_mask")
    if supervision_mask is not None:
        if int(supervision_mask.sum().detach().cpu()) == 0:
            return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
        graph_edges = graph_edges[:, supervision_mask]
        pair_logits = pair_logits[supervision_mask]
    row, col = graph_edges
    if row.numel() == 0:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    reference_pairs = prepared.get("reference_pairs", [])
    if not reference_pairs:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    reference_tensor = torch.tensor(
        sorted(
            (int(src), int(dst)) if int(src) < int(dst) else (int(dst), int(src))
            for src, dst in reference_pairs
        ),
        dtype=torch.long,
        device=pair_logits.device,
    )
    losses = []
    row_to_indices = _group_edge_indices_by_node(torch, row, pair_logits.device)
    col_to_indices = _group_edge_indices_by_node(torch, col, pair_logits.device)
    pair_key = torch.minimum(row, col).to(dtype=torch.long) * _prepared_num_nodes(prepared, graph_edges) + torch.maximum(row, col).to(dtype=torch.long)
    reference_key = reference_tensor[:, 0] * _prepared_num_nodes(prepared, graph_edges) + reference_tensor[:, 1]
    for src, dst in reference_tensor.detach().cpu().tolist():
        src = int(src)
        dst = int(dst)
        target_key = src * _prepared_num_nodes(prepared, graph_edges) + dst
        src_indices = row_to_indices.get(src)
        if src_indices is not None and int(src_indices.numel()) > 1:
            logits = pair_logits[src_indices]
            local_targets = pair_key[src_indices] == target_key
            if int(local_targets.sum().detach().cpu()) > 0:
                losses.append(torch.nn.functional.cross_entropy(logits.unsqueeze(0), torch.tensor([int(torch.nonzero(local_targets, as_tuple=False).flatten()[0])], dtype=torch.long, device=pair_logits.device)))
        dst_indices = col_to_indices.get(dst)
        if dst_indices is not None and int(dst_indices.numel()) > 1:
            logits = pair_logits[dst_indices]
            local_targets = pair_key[dst_indices] == target_key
            if int(local_targets.sum().detach().cpu()) > 0:
                losses.append(torch.nn.functional.cross_entropy(logits.unsqueeze(0), torch.tensor([int(torch.nonzero(local_targets, as_tuple=False).flatten()[0])], dtype=torch.long, device=pair_logits.device)))
    if not losses:
        return torch.tensor(0.0, dtype=pair_logits.dtype, device=pair_logits.device)
    return torch.mean(torch.stack(losses))


def _prepared_num_nodes(prepared, graph_edges=None):
    sample = prepared.get("sample")
    if sample is not None and hasattr(sample, "num_nucleotides"):
        return int(sample.num_nucleotides)
    if graph_edges is not None and graph_edges.numel() > 0:
        return int(graph_edges.max().detach().cpu()) + 1
    reference_pairs = prepared.get("reference_pairs") or []
    if reference_pairs:
        return max(int(max(max(src, dst) for src, dst in reference_pairs)) + 1, 1)
    return 1


def _group_edge_indices_by_node(torch, node_index_tensor, device):
    groups = {}
    if node_index_tensor.numel() == 0:
        return groups
    node_ids = torch.unique(node_index_tensor).detach().cpu().tolist()
    for node_id in node_ids:
        indices = torch.nonzero(node_index_tensor == int(node_id), as_tuple=False).flatten()
        if int(indices.numel()) > 0:
            groups[int(node_id)] = indices.to(device=device)
    return groups


def _tensor_key_membership(torch, query_keys, reference_keys):
    if reference_keys.numel() == 0:
        return torch.zeros_like(query_keys, dtype=torch.bool)
    reference_keys = reference_keys.view(-1).to(dtype=torch.long)
    query_keys = query_keys.view(-1).to(dtype=torch.long)
    reference_sorted, _ = torch.sort(reference_keys)
    positions = torch.searchsorted(reference_sorted, query_keys)
    positions = torch.clamp(positions, max=reference_sorted.numel() - 1)
    return reference_sorted[positions] == query_keys


def _sample_physical_metrics(torch, prepared, pred_positions, pred_a1, pred_a3, args):
    primary = compute_wc_helix_metrics(
        torch,
        prepared["sample"],
        pred_positions,
        pred_a1,
        pred_a3,
        target_positions=prepared["inputs"]["target_x_a"],
        pair_cutoff=args.wc_pair_cutoff,
        reference_pairs=prepared["reference_pairs"],
        helix_steps=prepared["helix_steps"],
    )
    proxy = None
    if prepared.get("reference_pair_source") == "geometric_proxy":
        proxy = compute_wc_helix_metrics(
            torch,
            prepared["sample"],
            pred_positions,
            pred_a1,
            pred_a3,
            target_positions=prepared["inputs"]["target_x_a"],
            pair_cutoff=args.wc_pair_cutoff,
            reference_pairs=prepared.get("reference_pairs_geometric_proxy"),
            helix_steps=prepared.get("helix_steps_geometric_proxy"),
        )
    return primary, proxy


def _masked_rmsd(torch, pred, target, mask):
    if mask is None:
        return _rmsd_tensor(pred, target)
    if int(mask.sum().detach().cpu()) == 0:
        return torch.tensor(float("nan"), dtype=pred.dtype, device=pred.device)
    return _rmsd_tensor(pred[mask], target[mask])


def _masked_orientation_score(torch, pred_a1, pred_a3, target_a1, target_a3, mask):
    if mask is None:
        return _orientation_score(torch, pred_a1, pred_a3, target_a1, target_a3)
    if int(mask.sum().detach().cpu()) == 0:
        return torch.tensor(float("nan"), dtype=pred_a1.dtype, device=pred_a1.device)
    return _orientation_score(torch, pred_a1[mask], pred_a3[mask], target_a1[mask], target_a3[mask])


def _build_node_split_masks(torch, sample_id, num_nodes, val_fraction, seed, device):
    if val_fraction <= 0:
        train_mask = torch.ones(num_nodes, dtype=torch.bool, device=device)
        val_mask = torch.zeros(num_nodes, dtype=torch.bool, device=device)
        return train_mask, val_mask
    indices = list(range(num_nodes))
    random.Random("{}:{}:{}".format(seed, sample_id, num_nodes)).shuffle(indices)
    val_count = int(round(num_nodes * val_fraction))
    val_count = max(1, min(num_nodes - 1, val_count))
    val_indices = indices[:val_count]
    train_mask = torch.ones(num_nodes, dtype=torch.bool, device=device)
    val_mask = torch.zeros(num_nodes, dtype=torch.bool, device=device)
    train_mask[val_indices] = False
    val_mask[val_indices] = True
    return train_mask, val_mask


def _refine_prediction(torch, prepared, pred_positions, pred_a1, pred_a3, args):
    if args.refine_steps <= 0:
        return pred_positions, pred_a1, pred_a3, None
    position_delta = torch.nn.Parameter(torch.zeros_like(pred_positions))
    a1_delta = torch.nn.Parameter(torch.zeros_like(pred_a1))
    a3_delta = torch.nn.Parameter(torch.zeros_like(pred_a3))
    optimizer = torch.optim.Adam([position_delta, a1_delta, a3_delta], lr=args.refine_learning_rate)
    inputs = prepared["inputs"]
    last_record = None
    for step in range(1, args.refine_steps + 1):
        optimizer.zero_grad()
        refined_positions = pred_positions.detach() + position_delta
        refined_a1, refined_a3 = _orthonormalize_frame(
            torch,
            pred_a1.detach() + a1_delta,
            pred_a3.detach() + a3_delta,
        )
        position_loss = torch.mean((refined_positions - inputs["target_x_a"]) ** 2)
        os_score = _orientation_score(torch, refined_a1, refined_a3, inputs["target_a1"], inputs["target_a3"])
        orientation_loss = 1.0 - os_score
        electrostatic_energy = _electrostatic_energy(
            torch,
            refined_positions,
            prepared["electrostatic_edges"],
            args.electrostatic_debye_length,
            args.electrostatic_coefficient,
        )
        drift_loss = torch.mean(position_delta ** 2)
        loss = (
            position_loss
            + args.refine_orientation_loss_weight * orientation_loss
            + args.refine_electrostatic_loss_weight * electrostatic_energy
            + args.refine_drift_loss_weight * drift_loss
        )
        loss.backward()
        if args.refine_grad_clip > 0:
            torch.nn.utils.clip_grad_norm_([position_delta, a1_delta, a3_delta], args.refine_grad_clip)
        optimizer.step()
        if step == 1 or step == args.refine_steps:
            last_record = {
                "step": step,
                "loss": float(loss.detach().cpu()),
                "position_loss": float(position_loss.detach().cpu()),
                "orientation_loss": float(orientation_loss.detach().cpu()),
                "os": float(os_score.detach().cpu()),
                "electrostatic_energy": float(electrostatic_energy.detach().cpu()),
                "drift_loss": float(drift_loss.detach().cpu()),
            }
    refined_positions = pred_positions.detach() + position_delta.detach()
    refined_a1, refined_a3 = _orthonormalize_frame(
        torch,
        pred_a1.detach() + a1_delta.detach(),
        pred_a3.detach() + a3_delta.detach(),
    )
    return refined_positions, refined_a1, refined_a3, last_record


def main(argv=None):
    parser = argparse.ArgumentParser(description="Jointly train one shared rigid residual MLP over oxDNA manifest entries.")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--summary-json", required=True)
    parser.add_argument("--save-model-state", default=None)
    parser.add_argument("--save-best-model-state", default=None)
    parser.add_argument(
        "--save-inference-bundle",
        default=None,
        help="Compact model/preprocessing JSON; defaults to OUTPUT_DIR/inference_bundle.json.",
    )
    parser.add_argument(
        "--best-model-monitor",
        choices=[
            "auto",
            "train/loss",
            "val/loss",
            "train/rmsd",
            "val/rmsd",
            "train/os",
            "val/os",
            "train/oxdna_energy_loss",
            "val/oxdna_energy_loss",
        ],
        default="auto",
        help="Metric used for --save-best-model-state. auto keeps legacy behavior: val/loss when a sample val split exists, else train/loss.",
    )
    parser.add_argument("--init-model-state", default=None)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--epochs", type=int, default=1000)
    parser.add_argument("--optimizer", choices=["adam", "adamw"], default="adam")
    parser.add_argument("--learning-rate", type=float, default=5e-3)
    parser.add_argument("--weight-decay", type=float, default=0.0)
    parser.add_argument("--scheduler", choices=["none", "cosine_warmup"], default="none")
    parser.add_argument("--warmup-epochs", type=int, default=0)
    parser.add_argument("--min-lr-scale", type=float, default=0.1)
    parser.add_argument("--model-kind", choices=["shared-mlp", "graph-shared", "dgnn-lite", "dgnn-physic"], default="shared-mlp")
    parser.add_argument("--shared-hidden-dim", type=int, default=256)
    parser.add_argument("--fourier-features", type=int, default=0)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--feature-noise-std", type=float, default=0.0)
    parser.add_argument(
        "--design-features",
        choices=["none", "stats"],
        default="none",
        help="Append per-design global statistics to every node feature without using memorized sample ids.",
    )
    parser.add_argument(
        "--legacy-feature-dimension",
        action="store_true",
        help="Keep the pre-defect node dimension for loading an old checkpoint; defect sidecars are rejected in this mode.",
    )
    parser.add_argument("--scale-normalized-residuals", action="store_true")
    parser.add_argument("--message-passing-steps", type=int, default=2)
    parser.add_argument("--graph-mode", choices=["backbone", "cutoff"], default="cutoff")
    parser.add_argument("--graph-cutoff", type=float, default=0.0)
    parser.add_argument("--max-graph-neighbors", type=int, default=16)
    parser.add_argument("--include-candidate-wc-edges", action="store_true")
    parser.add_argument("--physical-graph", action="store_true", help="Add physical node features and typed physical edges for dgnn-physic.")
    parser.add_argument(
        "--wc-edge-mode",
        choices=["message_all", "readout_only", "last_layer"],
        default="message_all",
        help="How candidate WC edges affect DGNN-lite: full message passing, pair readout only, or final-layer-only injection.",
    )
    parser.add_argument("--candidate-wc-top-k", type=int, default=0)
    parser.add_argument("--candidate-wc-cutoff", type=float, default=0.0)
    parser.add_argument("--restrict-pair-losses-to-candidate-wc-edges", action="store_true")
    parser.add_argument(
        "--design-edge-sidecars",
        default=None,
        help="Checksum-bound design_edge_sidecars.json built for this manifest.",
    )
    parser.add_argument("--require-explicit-design-edges", action="store_true")
    parser.add_argument("--edge-family-pair", action="store_true")
    parser.add_argument("--edge-family-crossover", action="store_true")
    parser.add_argument("--edge-family-duplex-step", action="store_true")
    parser.add_argument("--edge-family-start-spatial", action="store_true")
    parser.add_argument("--orientation-loss-weight", type=float, default=1.0)
    parser.add_argument("--electrostatic-loss-weight", type=float, default=0.0)
    parser.add_argument("--loss-weight-schedule", choices=["constant", "linear_ramp"], default="constant")
    parser.add_argument("--loss-weight-ramp-epochs", type=int, default=0)
    parser.add_argument("--electrostatic-cutoff", type=float, default=2.5)
    parser.add_argument("--electrostatic-debye-length", type=float, default=1.2576)
    parser.add_argument("--electrostatic-coefficient", type=float, default=1.4131)
    parser.add_argument("--wc-pair-cutoff", type=float, default=4.0)
    parser.add_argument("--pair-distance-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-assignment-margin-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-assignment-margin", type=float, default=4.0)
    parser.add_argument("--pair-center-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-axis-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-frame-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-classification-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-logit-exclusivity-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-logit-symmetry-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-logit-sinkhorn-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-partner-selection-loss-weight", type=float, default=0.0)
    parser.add_argument("--pair-conflict-loss-weight", type=float, default=0.0)
    parser.add_argument("--soft-partner-exclusivity-loss-weight", type=float, default=0.0)
    parser.add_argument("--helix-step-loss-weight", type=float, default=0.0)
    parser.add_argument("--helix-step-axis-loss-weight", type=float, default=0.0)
    parser.add_argument("--nonpair-repulsion-loss-weight", type=float, default=0.0)
    parser.add_argument("--nonpair-repulsion-margin", type=float, default=4.0)
    parser.add_argument("--oxdna-energy-loss-weight", type=float, default=0.0)
    parser.add_argument("--oxdna-energy-ramp-epochs", type=int, default=0)
    parser.add_argument("--oxdna-energy-backbone-weight", type=float, default=1.0)
    parser.add_argument("--oxdna-energy-stacking-weight", type=float, default=0.25)
    parser.add_argument("--oxdna-energy-hbond-weight", type=float, default=1.0)
    parser.add_argument("--oxdna-energy-cross-stack-weight", type=float, default=0.25)
    parser.add_argument("--oxdna-energy-excluded-volume-weight", type=float, default=0.1)
    parser.add_argument("--oxdna-energy-excluded-volume-cutoff", type=float, default=1.2)
    parser.add_argument("--oxdna-energy-excluded-volume-softness", type=float, default=0.2)
    parser.add_argument("--oxdna-energy-excluded-volume-max-pairs", type=int, default=200000)
    parser.add_argument(
        "--enable-legacy-duplex-losses",
        action="store_true",
        help="Opt back into old WC/pair/helix/nonpair training losses. Default keeps only RMSD/OS plus oxDNA energy.",
    )
    parser.add_argument(
        "--compute-final-physical-metrics",
        action="store_true",
        help="Opt into slow final compute_wc_helix_metrics diagnostics. Default skips them.",
    )
    parser.add_argument(
        "--start-rmsd-residual-gate-threshold",
        type=float,
        default=0.0,
        help="If >0, shrink model residuals for samples whose start RMSD is below this threshold.",
    )
    parser.add_argument(
        "--start-rmsd-residual-gate-sharpness",
        type=float,
        default=1.0,
        help="Sigmoid sharpness for --start-rmsd-residual-gate-threshold.",
    )
    parser.add_argument(
        "--start-rmsd-residual-min-scale",
        type=float,
        default=0.0,
        help="Minimum residual scale used by the start-RMSD gate.",
    )
    parser.add_argument(
        "--write-assignment-realized-conf",
        action="store_true",
        help="Write a diagnostic conf whose matched decoded one-to-one pairs are realized with explicit reference pair geometry.",
    )
    parser.add_argument(
        "--write-reference-pair-frame-conf",
        action="store_true",
        help="Write a diagnostic conf that realizes all explicit reference pairs in a pair-frame/base-pair-first upper-bound representation.",
    )
    parser.add_argument("--assignment-realized-repulsion-margin", type=float, default=0.0)
    parser.add_argument("--assignment-realized-repulsion-steps", type=int, default=0)
    parser.add_argument(
        "--assignment-realized-repulsion-variants",
        default="",
        help="Optional comma-separated name:margin:steps variants exported from the same decoded assignment.",
    )
    parser.add_argument("--refine-steps", type=int, default=0)
    parser.add_argument("--refine-learning-rate", type=float, default=5e-3)
    parser.add_argument("--refine-orientation-loss-weight", type=float, default=5.0)
    parser.add_argument("--refine-electrostatic-loss-weight", type=float, default=0.0)
    parser.add_argument("--refine-drift-loss-weight", type=float, default=0.0)
    parser.add_argument("--refine-grad-clip", type=float, default=1.0)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--log-every", type=int, default=100)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--wandb", action="store_true", help="Log training metrics to Weights & Biases.")
    parser.add_argument("--wandb-mode", default=None, help="W&B mode override, for example online or offline.")
    parser.add_argument(
        "--debug-phase-timing",
        action="store_true",
        help="Print coarse timing splits for preparation, training, validation, and final export.",
    )
    parser.add_argument(
        "--max-samples",
        type=int,
        default=0,
        help="Diagnostic cap on the number of manifest samples to load and train on; 0 keeps all samples.",
    )
    parser.add_argument(
        "--sample-cache-dir",
        default=None,
        help="Optional disk cache for prepared sample .pt bundles, keyed by manifest fingerprints and cache version.",
    )
    parser.add_argument(
        "--cache-version",
        type=int,
        default=1,
        help="Bump this when sample graph construction changes so cached .pt files are regenerated.",
    )
    parser.add_argument(
        "--split-mode",
        choices=["sample", "node"],
        default="sample",
        help="sample holds out whole designs; node trains on every design and holds out nodes inside each design.",
    )
    parser.add_argument(
        "--split-strategy",
        choices=["random", "nt-stratified", "topology-grouped"],
        default="random",
        help="For sample splits, choose random, nucleotide-stratified, or topology-grouped validation designs.",
    )
    parser.add_argument("--val-fraction", type=float, default=0.0)
    parser.add_argument("--val-ids", default="", help="Comma-separated sample ids to hold out for validation.")
    parser.add_argument(
        "--test-ids",
        default="",
        help="Comma-separated sample ids excluded from training/checkpoint selection and reported as test.",
    )
    parser.add_argument("--stage-samples-on-cpu", action="store_true", help="Keep per-sample tensors on CPU and move one sample at a time to the training device.")
    args = parser.parse_args(argv)
    design_edge_mode = bool(args.design_edge_sidecars)
    requested_design_families = any(
        (
            args.edge_family_pair,
            args.edge_family_crossover,
            args.edge_family_duplex_step,
            args.edge_family_start_spatial,
        )
    )
    if (args.require_explicit_design_edges or requested_design_families) and not design_edge_mode:
        raise ValueError("--design-edge-sidecars is required for explicit design-edge flags")
    if design_edge_mode:
        if args.graph_mode != "backbone" or args.graph_cutoff != 0.0:
            raise ValueError("design-edge ablations require --graph-mode backbone and --graph-cutoff 0")
        if args.include_candidate_wc_edges or args.candidate_wc_top_k > 0:
            raise ValueError("design-edge ablations forbid target-derived candidate WC edges")
        if args.physical_graph or args.model_kind == "dgnn-physic":
            raise ValueError("design-edge ablations forbid the legacy physical graph")
    assignment_realized_variants = _parse_assignment_realized_variants(
        args.assignment_realized_repulsion_variants
    )

    import torch

    torch.manual_seed(args.seed)
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("requested CUDA device but torch.cuda.is_available() is false")
    torch_device = torch.device(args.device)
    if torch_device.type == "cuda":
        torch.cuda.set_device(torch_device)
        torch.cuda.reset_peak_memory_stats(torch_device.index if torch_device.index is not None else None)

    start_time = time.time()
    timing_enabled = args.debug_phase_timing
    phase_t0 = time.perf_counter()
    manifest_path = os.path.abspath(args.manifest)
    entries, manifest_sha256 = _load_manifest_with_sha256(args.manifest)
    manifest_entry_count = len(entries)
    unavailable_endpoint_targets = [
        entry["id"]
        for entry in entries
        if not entry["target_masks"]["endpoint_positions"]
        or not entry.get("target")
    ]
    if unavailable_endpoint_targets:
        raise ValueError(
            "shared-rigid endpoint training requires a real endpoint_positions target; unavailable for {}".format(
                ", ".join(unavailable_endpoint_targets[:5])
            )
        )
    design_edge_index = None
    if design_edge_mode:
        design_edge_index = load_design_edge_sidecar_index(
            args.design_edge_sidecars,
            manifest_sha256=manifest_sha256,
            entries=entries,
            required=True,
        )
        for entry in entries:
            sample_id = entry["id"]
            entry["design_edge_sidecar"] = design_edge_index["sidecars"][sample_id]
            entry["design_edge_sidecar_sha256"] = design_edge_index[
                "sidecar_sha256"
            ][sample_id]
            entry["design_edge_fingerprint"] = design_edge_index["fingerprints"][
                sample_id
            ]
    if args.max_samples > 0:
        entries = entries[: args.max_samples]
    manifest_snapshot_path = os.path.abspath(
        os.path.join(args.output_dir, "training_manifest_snapshot.json")
    )
    _validate_training_file_paths(args, entries, assignment_realized_variants)
    os.makedirs(args.output_dir, exist_ok=True)
    with open(manifest_snapshot_path, "w") as handle:
        json.dump(entries, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
    with open(manifest_snapshot_path, "rb") as handle:
        manifest_snapshot_sha256 = hashlib.sha256(handle.read()).hexdigest()
    sample_device = "cpu" if args.stage_samples_on_cpu else args.device
    prepared_samples = []
    for entry in entries:
        sample_t0 = time.perf_counter()
        prepared_samples.append(
            _prepare_sample_with_cache(
                torch,
                entry,
                sample_device,
                args.electrostatic_cutoff,
                args.fourier_features,
                args.design_features,
                args.graph_mode,
                args.graph_cutoff,
                args.max_graph_neighbors,
                args.include_candidate_wc_edges,
                args.candidate_wc_top_k,
                args.candidate_wc_cutoff,
                args.restrict_pair_losses_to_candidate_wc_edges,
                args.physical_graph or args.model_kind == "dgnn-physic",
                cache_dir=args.sample_cache_dir,
                args=args,
            )
        )
        if timing_enabled:
            print(
                "timing phase=prepare_sample id={} seconds={:.6f}".format(
                    entry["id"], time.perf_counter() - sample_t0
                ),
                flush=True,
            )
    _timing_log(timing_enabled, "prepare_samples", time.perf_counter() - phase_t0)
    if args.split_mode == "node":
        train_ids = [entry["id"] for entry in entries]
        val_ids = []
        test_ids = []
        if args.val_ids or args.test_ids:
            raise ValueError("--val-ids/--test-ids are only supported with --split-mode sample")
    else:
        nucleotide_counts = {
            prepared["entry"]["id"]: prepared["sample"].num_nucleotides
            for prepared in prepared_samples
        }
        group_ids = {
            entry["id"]: entry.get("group_id") or entry.get("graph_hash")
            for entry in entries
        }
        train_ids, val_ids = _split_ids(
            [entry["id"] for entry in entries],
            args.val_fraction,
            args.val_ids,
            args.seed,
            split_strategy=args.split_strategy,
            nucleotide_counts=nucleotide_counts,
            group_ids=group_ids,
        )
        all_sample_ids = {entry["id"] for entry in entries}
        test_ids = [
            item.strip() for item in args.test_ids.split(",") if item.strip()
        ]
        unknown_test_ids = sorted(set(test_ids) - all_sample_ids)
        if unknown_test_ids:
            raise ValueError(
                "--test-ids contains unknown samples: {}".format(
                    ", ".join(unknown_test_ids[:5])
                )
            )
        if set(test_ids).intersection(val_ids):
            raise ValueError("validation and test sample IDs must be disjoint")
        train_ids = [sample_id for sample_id in train_ids if sample_id not in set(test_ids)]
        if not train_ids:
            raise ValueError("sample split has no training samples")
    train_id_set = set(train_ids)
    val_id_set = set(val_ids)
    test_id_set = set(test_ids)
    best_metric_name = _resolve_best_model_monitor(args, val_ids)
    has_validation_samples = bool(val_ids) if args.split_mode == "sample" else args.val_fraction > 0.0
    if best_metric_name.startswith("val/") and not has_validation_samples:
        raise ValueError(
            "--best-model-monitor {} requires validation samples".format(
                best_metric_name
            )
        )
    split_groups = {
        "train": sorted(
            {
                entry.get("group_id") or entry.get("graph_hash")
                for entry in entries
                if entry["id"] in train_id_set
                and (entry.get("group_id") or entry.get("graph_hash"))
            }
        ),
        "val": sorted(
            {
                entry.get("group_id") or entry.get("graph_hash")
                for entry in entries
                if entry["id"] in val_id_set
                and (entry.get("group_id") or entry.get("graph_hash"))
            }
        ),
        "test": sorted(
            {
                entry.get("group_id") or entry.get("graph_hash")
                for entry in entries
                if entry["id"] in test_id_set
                and (entry.get("group_id") or entry.get("graph_hash"))
            }
        ),
    }
    if set(split_groups["train"]).intersection(split_groups["val"]):
        raise ValueError("train and validation groups overlap")
    if set(split_groups["train"]).intersection(split_groups["test"]):
        raise ValueError("train and test groups overlap")
    if set(split_groups["val"]).intersection(split_groups["test"]):
        raise ValueError("validation and test groups overlap")
    split_audit = _build_split_audit(
        entries,
        train_id_set,
        val_id_set,
        test_id_set,
    )
    args.split_audit_hash = split_audit["sha256"]
    for prepared in prepared_samples:
        sample_id = prepared["entry"]["id"]
        num_nodes = prepared["sample"].num_nucleotides
        if args.split_mode == "node":
            train_mask, val_mask = _build_node_split_masks(
                torch,
                sample_id,
                num_nodes,
                args.val_fraction,
                args.seed,
                prepared["features"].device,
            )
        else:
            train_mask = torch.ones(num_nodes, dtype=torch.bool, device=prepared["features"].device)
            val_mask = torch.zeros(num_nodes, dtype=torch.bool, device=prepared["features"].device)
        prepared["node_train_mask"] = train_mask
        prepared["node_val_mask"] = val_mask
    input_dim = prepared_samples[0]["features"].shape[1]
    edge_feature_dim = prepared_samples[0]["graph_edge_features"].shape[1]
    if any(
        prepared["features"].shape[1] != input_dim
        or prepared["graph_edge_features"].shape[1] != edge_feature_dim
        for prepared in prepared_samples
    ):
        raise ValueError("prepared samples do not share fixed node and edge dimensions")
    relation_vocabulary = []
    for prepared in prepared_samples:
        for relation_name in prepared.get("edge_relation_names", ["default"]):
            if relation_name not in relation_vocabulary:
                relation_vocabulary.append(relation_name)
    if not args.legacy_feature_dimension and "cut_backbone" not in relation_vocabulary:
        relation_vocabulary.append("cut_backbone")
    checkpoint_feature_schema = (
        {
            "name": "legacy_pre_defect_features",
            "version": 1,
            "channels": [],
            "normalization": {},
        }
        if args.legacy_feature_dimension
        else DEFECT_FEATURE_SCHEMA
    )
    checkpoint_metadata = build_checkpoint_metadata(
        args,
        defect_feature_schema=checkpoint_feature_schema,
        relation_vocabulary=relation_vocabulary,
        target_schema=TARGET_SCHEMA,
        split_audit_hash=split_audit["sha256"],
    )
    if args.model_kind == "graph-shared":
        model = GraphSharedRigidModel(
            torch,
            input_dim,
            args.shared_hidden_dim,
            args.device,
            args.message_passing_steps,
            scale_normalized_residuals=args.scale_normalized_residuals,
            dropout=args.dropout,
        )
    elif args.model_kind == "dgnn-lite":
        model = DgnnLiteRigidModel(
            torch,
            input_dim,
            edge_feature_dim,
            args.shared_hidden_dim,
            args.device,
            args.message_passing_steps,
            scale_normalized_residuals=args.scale_normalized_residuals,
            dropout=args.dropout,
            wc_edge_mode=args.wc_edge_mode,
        )
    elif args.model_kind == "dgnn-physic":
        model = DgnnPhysicRigidModel(
            torch,
            input_dim,
            edge_feature_dim,
            args.shared_hidden_dim,
            args.device,
            args.message_passing_steps,
            relation_count=len(prepared_samples[0].get("edge_relation_names", ["default"])),
            scale_normalized_residuals=args.scale_normalized_residuals,
            dropout=args.dropout,
        )
    else:
        model = SharedRigidMLP(
            torch,
            input_dim,
            args.shared_hidden_dim,
            args.device,
            scale_normalized_residuals=args.scale_normalized_residuals,
            dropout=args.dropout,
        )
    if args.init_model_state:
        checkpoint = torch.load(args.init_model_state, map_location=args.device)
        loaded_metadata = (
            checkpoint.get("checkpoint_metadata")
            if isinstance(checkpoint, dict)
            else None
        )
        if loaded_metadata is None and not args.legacy_feature_dimension:
            raise ValueError(
                "checkpoint has no feature schema; use --legacy-feature-dimension for a pre-defect checkpoint"
            )
        if loaded_metadata is not None:
            loaded_legacy = bool(loaded_metadata.get("legacy_feature_dimension", False))
            if loaded_legacy != bool(args.legacy_feature_dimension):
                raise ValueError("checkpoint feature dimension mode does not match CLI mode")
            loaded_schema = loaded_metadata.get("defect_feature_schema") or {}
            if loaded_schema.get("channels") != checkpoint_feature_schema["channels"]:
                raise ValueError("checkpoint defect feature schema does not match loader")
        model.load_state_dict(_extract_model_state_dict(checkpoint))
    if args.optimizer == "adamw":
        optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    else:
        optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = _build_scheduler(
        torch,
        optimizer,
        args.scheduler,
        args.epochs,
        args.warmup_epochs,
        args.min_lr_scale,
    )
    wandb_run = WandbRun.create(
        enabled=args.wandb,
        mode=args.wandb_mode,
        config={
            "model": "shared_rigid_mlp_joint",
            "manifest": os.path.abspath(args.manifest),
            "output_dir": os.path.abspath(args.output_dir),
            "summary_json": os.path.abspath(args.summary_json),
            "save_model_state": os.path.abspath(args.save_model_state) if args.save_model_state else None,
            "save_best_model_state": os.path.abspath(args.save_best_model_state) if args.save_best_model_state else None,
            "save_inference_bundle": (
                os.path.abspath(args.save_inference_bundle)
                if args.save_inference_bundle
                else os.path.abspath(os.path.join(args.output_dir, "inference_bundle.json"))
            ),
            "best_model_monitor": args.best_model_monitor,
            "init_model_state": os.path.abspath(args.init_model_state) if args.init_model_state else None,
            "device": args.device,
            "epochs": args.epochs,
            "optimizer": args.optimizer,
            "learning_rate": args.learning_rate,
            "weight_decay": args.weight_decay,
            "scheduler": args.scheduler,
            "warmup_epochs": args.warmup_epochs,
            "min_lr_scale": args.min_lr_scale,
            "model_kind": args.model_kind,
            "shared_hidden_dim": args.shared_hidden_dim,
            "fourier_features": args.fourier_features,
            "dropout": args.dropout,
            "feature_noise_std": args.feature_noise_std,
            "design_features": args.design_features,
            "scale_normalized_residuals": args.scale_normalized_residuals,
            "message_passing_steps": args.message_passing_steps,
            "graph_mode": args.graph_mode,
            "graph_cutoff": args.graph_cutoff,
            "max_graph_neighbors": args.max_graph_neighbors,
            "include_candidate_wc_edges": args.include_candidate_wc_edges,
            "wc_edge_mode": args.wc_edge_mode,
            "candidate_wc_top_k": args.candidate_wc_top_k,
            "candidate_wc_cutoff": args.candidate_wc_cutoff,
            "design_edge_sidecars": (
                os.path.abspath(args.design_edge_sidecars)
                if args.design_edge_sidecars
                else None
            ),
            "design_edge_sidecars_sha256": (
                design_edge_index["index_sha256"] if design_edge_index else None
            ),
            "require_explicit_design_edges": args.require_explicit_design_edges,
            "edge_family_pair": args.edge_family_pair,
            "edge_family_crossover": args.edge_family_crossover,
            "edge_family_duplex_step": args.edge_family_duplex_step,
            "edge_family_start_spatial": args.edge_family_start_spatial,
            "stage_samples_on_cpu": args.stage_samples_on_cpu,
            "start_rmsd_residual_gate_threshold": args.start_rmsd_residual_gate_threshold,
            "start_rmsd_residual_gate_sharpness": args.start_rmsd_residual_gate_sharpness,
            "start_rmsd_residual_min_scale": args.start_rmsd_residual_min_scale,
            "orientation_loss_weight": args.orientation_loss_weight,
            "electrostatic_loss_weight": args.electrostatic_loss_weight,
            "loss_weight_schedule": args.loss_weight_schedule,
            "loss_weight_ramp_epochs": args.loss_weight_ramp_epochs,
            "electrostatic_cutoff": args.electrostatic_cutoff,
            "electrostatic_debye_length": args.electrostatic_debye_length,
            "electrostatic_coefficient": args.electrostatic_coefficient,
            "split_mode": args.split_mode,
            "val_fraction": args.val_fraction,
            "val_ids": args.val_ids,
            "test_ids": args.test_ids,
            "seed": args.seed,
        },
    )

    start_metrics = {}
    phase_t0 = time.perf_counter()
    for prepared in prepared_samples:
        metric_prepared = _prepared_on_device(torch, prepared, args.device) if args.stage_samples_on_cpu else prepared
        sample_id = prepared["entry"]["id"]
        inputs = metric_prepared["inputs"]
        start_rmsd, start_os, start_elec = _sample_metrics(
            torch,
            metric_prepared,
            inputs["x_a"],
            inputs["a1"],
            inputs["a3"],
            args,
        )
        target_elec = _electrostatic_energy(
            torch,
            inputs["target_x_a"],
            metric_prepared["electrostatic_edges"],
            args.electrostatic_debye_length,
            args.electrostatic_coefficient,
        )
        start_metrics[sample_id] = {
            "start_rmsd": float(start_rmsd.detach().cpu()),
            "start_os": float(start_os.detach().cpu()),
            "start_electrostatic_energy": float(start_elec.detach().cpu()),
            "target_electrostatic_energy": float(target_elec.detach().cpu()),
        }
    _timing_log(timing_enabled, "start_metrics", time.perf_counter() - phase_t0)

    history = []
    args._active_orientation_loss_weight = args.orientation_loss_weight
    args._active_electrostatic_loss_weight = args.electrostatic_loss_weight
    args._active_oxdna_energy_loss_weight = args.oxdna_energy_loss_weight
    best_metric_value = _best_monitor_initial_value(best_metric_name)
    best_state = None
    train_phase_t0 = time.perf_counter()
    validation_total_seconds = 0.0
    for epoch in range(1, args.epochs + 1):
        model.train()
        optimizer.zero_grad()
        total_loss_value = 0.0
        epoch_parts = []
        if args.loss_weight_schedule == "linear_ramp":
            weight_scale = _loss_weight_scale(epoch, args.epochs, args.loss_weight_ramp_epochs)
        else:
            weight_scale = 1.0
        args._active_orientation_loss_weight = args.orientation_loss_weight * weight_scale
        args._active_electrostatic_loss_weight = args.electrostatic_loss_weight * weight_scale
        oxdna_weight_scale = _loss_weight_scale(epoch, args.epochs, args.oxdna_energy_ramp_epochs)
        args._active_oxdna_energy_loss_weight = args.oxdna_energy_loss_weight * oxdna_weight_scale
        for prepared in prepared_samples:
            if prepared["entry"]["id"] not in train_id_set:
                continue
            sample_t0 = time.perf_counter()
            sample_id = prepared["entry"]["id"]
            debug_first_train_sample = timing_enabled and epoch == 1 and len(epoch_parts) == 0
            if debug_first_train_sample:
                print(
                    "timing phase=train_sample_start epoch={} id={}".format(epoch, sample_id),
                    flush=True,
                )
            active = _prepared_on_device(torch, prepared, args.device) if args.stage_samples_on_cpu else prepared
            inputs = active["inputs"]
            forward_t0 = time.perf_counter()
            pred_positions, pred_a1, pred_a3, aux_outputs = _forward_with_residual_gate(
                torch,
                model,
                args,
                active["features"],
                inputs,
                active,
            )
            if debug_first_train_sample:
                _debug_phase_log(timing_enabled, epoch, sample_id, "forward", time.perf_counter() - forward_t0)
            train_mask = active["node_train_mask"] if args.split_mode == "node" else None
            position_error = pred_positions - inputs["target_x_a"]
            if train_mask is not None:
                position_error = position_error[train_mask]
            position_loss = torch.mean(position_error ** 2)
            train_rmsd = _masked_rmsd(torch, pred_positions, inputs["target_x_a"], train_mask)
            os_score = _masked_orientation_score(
                torch,
                pred_a1,
                pred_a3,
                inputs["target_a1"],
                inputs["target_a3"],
                train_mask,
            )
            orientation_loss = 1.0 - os_score
            position_loss = _mask_optional_target_loss(
                torch,
                position_loss,
                active.get("target_masks"),
                "endpoint_positions",
            )
            orientation_loss = _mask_optional_target_loss(
                torch,
                orientation_loss,
                active.get("target_masks"),
                "endpoint_positions",
            )
            electrostatic_energy = _electrostatic_energy(
                torch,
                pred_positions,
                active["electrostatic_edges"],
                args.electrostatic_debye_length,
                args.electrostatic_coefficient,
            )
            pair_distance_loss = (
                reference_pair_distance_loss(
                    torch,
                    pred_positions,
                    inputs["target_x_a"],
                    active["reference_pairs"],
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_distance_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_assignment_margin_loss = (
                reference_pair_assignment_margin_loss(
                    torch,
                    active["sample"],
                    pred_positions,
                    inputs["target_x_a"],
                    active["reference_pairs"],
                    _edge_tensor_to_pairs(active["candidate_wc_edges"]),
                    margin=args.pair_assignment_margin,
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_assignment_margin_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_center_loss = (
                reference_pair_center_loss(
                    torch,
                    pred_positions,
                    inputs["target_x_a"],
                    active["reference_pairs"],
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_center_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_axis_loss = (
                reference_pair_axis_loss(
                    torch,
                    pred_positions,
                    inputs["target_x_a"],
                    active["reference_pairs"],
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_axis_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_frame_loss = (
                reference_pair_frame_loss(
                    torch,
                    pred_positions,
                    pred_a1,
                    pred_a3,
                    inputs["target_x_a"],
                    inputs["target_a1"],
                    inputs["target_a3"],
                    active["reference_pairs"],
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_frame_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_classification_loss = (
                _pair_classification_loss(
                    torch,
                    active,
                    aux_outputs.get("pair_logits"),
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_classification_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_logit_exclusivity_loss = (
                _pair_logit_exclusivity_loss(
                    torch,
                    active,
                    aux_outputs.get("pair_logits"),
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_logit_exclusivity_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_logit_symmetry_loss = (
                _pair_logit_symmetry_loss(
                    torch,
                    active,
                    aux_outputs.get("pair_logits"),
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_logit_symmetry_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_logit_sinkhorn_loss = (
                _pair_logit_sinkhorn_loss(
                    torch,
                    active,
                    aux_outputs.get("pair_logits"),
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_logit_sinkhorn_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_partner_selection_loss = (
                _pair_partner_selection_loss(
                    torch,
                    active,
                    aux_outputs.get("pair_logits"),
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_partner_selection_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            pair_conflict_loss = (
                reference_pair_conflict_loss(
                    torch,
                    active["sample"],
                    pred_positions,
                    pair_cutoff=args.wc_pair_cutoff,
                )
                if _legacy_duplex_losses_enabled(args) and args.pair_conflict_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            soft_partner_exclusivity = (
                soft_partner_exclusivity_loss(
                    torch,
                    active["sample"],
                    pred_positions,
                    pair_cutoff=args.wc_pair_cutoff,
                    temperature=1.0,
                )
                if _legacy_duplex_losses_enabled(args) and args.soft_partner_exclusivity_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            helix_step_loss = (
                reference_helix_step_distance_loss(
                    torch,
                    pred_positions,
                    inputs["target_x_a"],
                    active["helix_steps"],
                )
                if _legacy_duplex_losses_enabled(args) and args.helix_step_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            helix_step_axis_loss = (
                reference_helix_step_axis_loss(
                    torch,
                    pred_positions,
                    inputs["target_x_a"],
                    active["helix_steps"],
                )
                if _legacy_duplex_losses_enabled(args) and args.helix_step_axis_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            nonpair_repulsion_loss = (
                reference_nonpair_repulsion_loss(
                    torch,
                    active["sample"],
                    pred_positions,
                    active["reference_pairs"],
                    margin=args.nonpair_repulsion_margin,
                )
                if _legacy_duplex_losses_enabled(args) and args.nonpair_repulsion_loss_weight != 0.0
                else _zero_like_loss(torch, pred_positions)
            )
            oxdna_energy = (
                _compute_oxdna_energy_loss(torch, args, active, pred_positions, pred_a1, pred_a3)
                if args._active_oxdna_energy_loss_weight != 0.0
                else None
            )
            oxdna_energy_loss_value = oxdna_energy.total if oxdna_energy is not None else _zero_like_loss(torch, pred_positions)
            oxdna_energy_backbone = oxdna_energy.backbone if oxdna_energy is not None else _zero_like_loss(torch, pred_positions)
            oxdna_energy_stacking = oxdna_energy.stacking if oxdna_energy is not None else _zero_like_loss(torch, pred_positions)
            oxdna_energy_hbond = oxdna_energy.hbond if oxdna_energy is not None else _zero_like_loss(torch, pred_positions)
            oxdna_energy_cross_stack = oxdna_energy.cross_stack if oxdna_energy is not None else _zero_like_loss(torch, pred_positions)
            oxdna_energy_excluded_volume = oxdna_energy.excluded_volume if oxdna_energy is not None else _zero_like_loss(torch, pred_positions)
            if debug_first_train_sample:
                _debug_phase_log(timing_enabled, epoch, sample_id, "loss", time.perf_counter() - sample_t0)
            conflict_rate = _training_conflict_rate(torch, active, pred_positions, args)
            train_conflict_rate = torch.tensor(
                float(conflict_rate),
                dtype=pred_positions.dtype,
                device=pred_positions.device,
            )
            backward_t0 = time.perf_counter()
            sample_loss = (
                position_loss
                + args._active_orientation_loss_weight * orientation_loss
                + args._active_electrostatic_loss_weight * electrostatic_energy
                + (args.pair_distance_loss_weight * pair_distance_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_assignment_margin_loss_weight * pair_assignment_margin_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_center_loss_weight * pair_center_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_axis_loss_weight * pair_axis_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_frame_loss_weight * pair_frame_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_classification_loss_weight * pair_classification_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_logit_exclusivity_loss_weight * pair_logit_exclusivity_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_logit_symmetry_loss_weight * pair_logit_symmetry_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_logit_sinkhorn_loss_weight * pair_logit_sinkhorn_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_partner_selection_loss_weight * pair_partner_selection_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.pair_conflict_loss_weight * pair_conflict_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.soft_partner_exclusivity_loss_weight * soft_partner_exclusivity if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.helix_step_loss_weight * helix_step_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.helix_step_axis_loss_weight * helix_step_axis_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + (args.nonpair_repulsion_loss_weight * nonpair_repulsion_loss if _legacy_duplex_losses_enabled(args) else 0.0)
                + args._active_oxdna_energy_loss_weight * oxdna_energy_loss_value
            )
            (sample_loss / float(len(train_ids))).backward()
            if debug_first_train_sample:
                _debug_phase_log(timing_enabled, epoch, sample_id, "backward", time.perf_counter() - backward_t0)
            total_loss_value += float(sample_loss.detach().cpu()) / float(len(train_ids))
            epoch_parts.append(_epoch_part_values((position_loss, train_rmsd, orientation_loss, electrostatic_energy, os_score, train_conflict_rate, pair_distance_loss, pair_assignment_margin_loss, pair_center_loss, pair_axis_loss, pair_frame_loss, pair_classification_loss, pair_logit_exclusivity_loss, pair_logit_symmetry_loss, pair_logit_sinkhorn_loss, pair_partner_selection_loss, pair_conflict_loss, soft_partner_exclusivity, helix_step_loss, helix_step_axis_loss, nonpair_repulsion_loss, oxdna_energy_loss_value, oxdna_energy_backbone, oxdna_energy_stacking, oxdna_energy_hbond, oxdna_energy_cross_stack, oxdna_energy_excluded_volume)))
            if debug_first_train_sample:
                _debug_phase_log(timing_enabled, epoch, sample_id, "total", time.perf_counter() - sample_t0)
            elif timing_enabled:
                print(
                    "timing phase=train_sample epoch={} id={} seconds={:.6f}".format(
                        epoch,
                        sample_id,
                        time.perf_counter() - sample_t0,
                    ),
                    flush=True,
                )
        if args.grad_clip > 0:
            clip_t0 = time.perf_counter()
            torch.nn.utils.clip_grad_norm_(list(model.parameters()), args.grad_clip)
            if timing_enabled and epoch == 1:
                _debug_phase_log(timing_enabled, epoch, "all", "clip", time.perf_counter() - clip_t0)
        optimizer.step()
        if timing_enabled and epoch == 1:
            _debug_phase_log(timing_enabled, epoch, "all", "step", 0.0)
        if scheduler is not None:
            scheduler.step()

        if epoch == 1 or epoch == args.epochs or (args.log_every and epoch % args.log_every == 0):
            avg_position = sum(part[0] for part in epoch_parts) / len(epoch_parts)
            avg_rmsd = sum(part[1] for part in epoch_parts) / len(epoch_parts)
            avg_orientation = sum(part[2] for part in epoch_parts) / len(epoch_parts)
            avg_os = sum(part[4] for part in epoch_parts) / len(epoch_parts)
            avg_conflict_rate = sum(part[5] for part in epoch_parts) / len(epoch_parts)
            avg_pair_distance = sum(part[6] for part in epoch_parts) / len(epoch_parts)
            avg_pair_assignment_margin = sum(part[7] for part in epoch_parts) / len(epoch_parts)
            avg_pair_center = sum(part[8] for part in epoch_parts) / len(epoch_parts)
            avg_pair_axis = sum(part[9] for part in epoch_parts) / len(epoch_parts)
            avg_pair_frame = sum(part[10] for part in epoch_parts) / len(epoch_parts)
            avg_pair_classification = sum(part[11] for part in epoch_parts) / len(epoch_parts)
            avg_pair_logit_exclusivity = sum(part[12] for part in epoch_parts) / len(epoch_parts)
            avg_pair_logit_symmetry = sum(part[13] for part in epoch_parts) / len(epoch_parts)
            avg_pair_logit_sinkhorn = sum(part[14] for part in epoch_parts) / len(epoch_parts)
            avg_pair_partner_selection = sum(part[15] for part in epoch_parts) / len(epoch_parts)
            avg_pair_conflict = sum(part[16] for part in epoch_parts) / len(epoch_parts)
            avg_soft_partner_exclusivity = sum(part[17] for part in epoch_parts) / len(epoch_parts)
            avg_helix_step = sum(part[18] for part in epoch_parts) / len(epoch_parts)
            avg_helix_step_axis = sum(part[19] for part in epoch_parts) / len(epoch_parts)
            avg_nonpair_repulsion = sum(part[20] for part in epoch_parts) / len(epoch_parts)
            avg_oxdna_energy = sum(part[21] for part in epoch_parts) / len(epoch_parts)
            avg_oxdna_energy_backbone = sum(part[22] for part in epoch_parts) / len(epoch_parts)
            avg_oxdna_energy_stacking = sum(part[23] for part in epoch_parts) / len(epoch_parts)
            avg_oxdna_energy_hbond = sum(part[24] for part in epoch_parts) / len(epoch_parts)
            avg_oxdna_energy_cross_stack = sum(part[25] for part in epoch_parts) / len(epoch_parts)
            avg_oxdna_energy_excluded_volume = sum(part[26] for part in epoch_parts) / len(epoch_parts)
            record = {
                "epoch": epoch,
                "loss": total_loss_value,
                "position_loss": avg_position,
                "rmsd": avg_rmsd,
                "orientation_loss": avg_orientation,
                "os": avg_os,
                "conflict_rate": avg_conflict_rate,
                "pair_distance_loss": avg_pair_distance,
                "pair_assignment_margin_loss": avg_pair_assignment_margin,
                "pair_center_loss": avg_pair_center,
                "pair_axis_loss": avg_pair_axis,
                "pair_frame_loss": avg_pair_frame,
                "pair_classification_loss": avg_pair_classification,
                "pair_logit_exclusivity_loss": avg_pair_logit_exclusivity,
                "pair_logit_symmetry_loss": avg_pair_logit_symmetry,
                "pair_logit_sinkhorn_loss": avg_pair_logit_sinkhorn,
                "pair_partner_selection_loss": avg_pair_partner_selection,
                "pair_conflict_loss": avg_pair_conflict,
                "soft_partner_exclusivity_loss": avg_soft_partner_exclusivity,
                "helix_step_loss": avg_helix_step,
                "helix_step_axis_loss": avg_helix_step_axis,
                "nonpair_repulsion_loss": avg_nonpair_repulsion,
                "oxdna_energy_loss": avg_oxdna_energy,
                "oxdna_energy_backbone": avg_oxdna_energy_backbone,
                "oxdna_energy_stacking": avg_oxdna_energy_stacking,
                "oxdna_energy_hbond": avg_oxdna_energy_hbond,
                "oxdna_energy_cross_stack": avg_oxdna_energy_cross_stack,
                "oxdna_energy_excluded_volume": avg_oxdna_energy_excluded_volume,
            }
            history.append(record)
            print(
                "epoch={} loss={:.12g} position_loss={:.12g} rmsd={:.12g} orientation_loss={:.12g} os={:.12g} oxdna_energy_loss={:.12g} oxdna_energy_backbone={:.12g} oxdna_energy_stacking={:.12g} oxdna_energy_hbond={:.12g} oxdna_energy_cross_stack={:.12g} oxdna_energy_excluded_volume={:.12g}".format(
                    epoch,
                    record["loss"],
                    record["position_loss"],
                    record["rmsd"],
                    record["orientation_loss"],
                    record["os"],
                    record["oxdna_energy_loss"],
                    record["oxdna_energy_backbone"],
                    record["oxdna_energy_stacking"],
                    record["oxdna_energy_hbond"],
                    record["oxdna_energy_cross_stack"],
                    record["oxdna_energy_excluded_volume"],
                ),
                flush=True,
            )
            val_t0 = time.perf_counter()
            val_record = _evaluate_validation_metrics(
                torch,
                model,
                prepared_samples,
                train_id_set,
                args,
                evaluation_id_set=val_id_set,
            )
            validation_total_seconds += time.perf_counter() - val_t0
            _log_wandb_epoch(wandb_run, epoch, record, optimizer.param_groups[0]["lr"], val_record=val_record)
            candidate = _best_monitor_candidate(best_metric_name, record, val_record)
            if candidate is not None and _best_monitor_is_better(best_metric_name, candidate, best_metric_value):
                best_metric_value = candidate
                best_state_dict = _clone_state_dict(model.state_dict())
                best_state = {
                    "epoch": epoch,
                    "metric_name": best_metric_name,
                    "metric_value": candidate,
                    "state_dict": best_state_dict,
                }
                _save_model_state_dict(
                    torch,
                    args.save_best_model_state,
                    best_state_dict,
                    checkpoint_metadata=checkpoint_metadata,
                )
    _timing_log(timing_enabled, "train_epochs_total", time.perf_counter() - train_phase_t0)
    _timing_log(timing_enabled, "validation_total", validation_total_seconds)

    final_phase_t0 = time.perf_counter()
    os.makedirs(args.output_dir, exist_ok=True)
    if os.path.dirname(os.path.abspath(args.summary_json)):
        os.makedirs(os.path.dirname(os.path.abspath(args.summary_json)), exist_ok=True)
    if args.save_model_state:
        _save_model_state_dict(
            torch,
            args.save_model_state,
            model.state_dict(),
            checkpoint_metadata=checkpoint_metadata,
        )
    if args.save_best_model_state and best_state is not None:
        _save_model_state_dict(
            torch,
            args.save_best_model_state,
            best_state["state_dict"],
            checkpoint_metadata=checkpoint_metadata,
        )
    final_evaluation_model = "final"
    if best_state is not None:
        model.load_state_dict(best_state["state_dict"])
        final_evaluation_model = "best"

    sample_summaries = []
    model.eval()
    final_forward_seconds = 0.0
    final_metric_seconds = 0.0
    final_export_seconds = 0.0
    final_realized_seconds = 0.0
    inference_context = getattr(torch, "inference_mode", torch.no_grad)
    with inference_context():
        for prepared in prepared_samples:
            active = _prepared_on_device(torch, prepared, args.device) if args.stage_samples_on_cpu else prepared
            sample = prepared["sample"]
            inputs = active["inputs"]
            sample_id = prepared["entry"]["id"]
            sample_phase_t0 = time.perf_counter()
            pred_positions, pred_a1, pred_a3, aux_outputs = _forward_with_residual_gate(
                torch,
                model,
                args,
                active["features"],
                inputs,
                active,
            )
            final_forward_seconds += time.perf_counter() - sample_phase_t0
            sample_phase_t0 = time.perf_counter()
            raw_rmsd, raw_os_score, raw_electrostatic = _sample_metrics(torch, active, pred_positions, pred_a1, pred_a3, args)
            if args.refine_steps > 0:
                grad_context = torch.inference_mode(False) if hasattr(torch, "inference_mode") else torch.enable_grad()
                with grad_context:
                    pred_positions, pred_a1, pred_a3, refine_record = _refine_prediction(
                        torch,
                        active,
                        pred_positions.detach(),
                        pred_a1.detach(),
                        pred_a3.detach(),
                        args,
                    )
            else:
                pred_positions, pred_a1, pred_a3, refine_record = _refine_prediction(
                    torch,
                    active,
                    pred_positions,
                    pred_a1,
                    pred_a3,
                    args,
                )
            rmsd, os_score, electrostatic = _sample_metrics(torch, active, pred_positions, pred_a1, pred_a3, args)
            if _final_physical_metrics_enabled(args):
                physical_metrics, physical_metrics_proxy = _sample_physical_metrics(
                    torch,
                    active,
                    pred_positions,
                    pred_a1,
                    pred_a3,
                    args,
                )
            else:
                physical_metrics, physical_metrics_proxy = None, None
            if _legacy_duplex_losses_enabled(args) or args.write_assignment_realized_conf:
                decoded_pair_assignment = _decode_pair_logits_one_to_one(
                    torch,
                    active,
                    aux_outputs.get("pair_logits"),
                )
                pair_logit_assignment_metrics = _pair_assignment_metrics(active, decoded_pair_assignment)
            else:
                decoded_pair_assignment = []
                pair_logit_assignment_metrics = {}
            assignment_realized = (
                _assignment_realized_summary(
                    torch,
                    active,
                    decoded_pair_assignment,
                    pred_positions,
                    pred_a1,
                    pred_a3,
                    args,
                )
                if args.write_assignment_realized_conf
                else None
            )
            final_metric_seconds += time.perf_counter() - sample_phase_t0
            sample_phase_t0 = time.perf_counter()
            node_train_mask = active["node_train_mask"]
            node_val_mask = active["node_val_mask"]
            node_train_count = int(node_train_mask.sum().detach().cpu())
            node_val_count = int(node_val_mask.sum().detach().cpu())
            node_train_final_rmsd = _masked_rmsd(torch, pred_positions, inputs["target_x_a"], node_train_mask)
            node_train_final_os = _masked_orientation_score(
                torch,
                pred_a1,
                pred_a3,
                inputs["target_a1"],
                inputs["target_a3"],
                node_train_mask,
            )
            node_val_final_rmsd = _masked_rmsd(torch, pred_positions, inputs["target_x_a"], node_val_mask)
            node_val_final_os = _masked_orientation_score(
                torch,
                pred_a1,
                pred_a3,
                inputs["target_a1"],
                inputs["target_a3"],
                node_val_mask,
            )
            output_path = os.path.abspath(os.path.join(args.output_dir, "{}.conf".format(sample_id)))
            frame = decode_to_oxdna_frame(
                sample,
                _positions_from_tensor(pred_positions),
                _positions_from_tensor(pred_a1),
                _positions_from_tensor(pred_a3),
                time=str(args.epochs),
                box=sample.target_frame.box if sample.target_frame is not None else sample.start_frame.box,
                energy=sample.target_frame.energy if sample.target_frame is not None else sample.start_frame.energy,
            )
            report = validate_frame(sample.topology, frame)
            if not report.ok:
                raise RuntimeError("validation failed for {}: {}".format(sample_id, report.errors))
            write_config(frame, output_path)
            final_export_seconds += time.perf_counter() - sample_phase_t0
            sample_phase_t0 = time.perf_counter()
            assignment_realized_output_path = None
            assignment_realized_warnings = None
            assignment_realized_variant_records = []
            reference_pair_frame = None
            reference_pair_frame_output_path = None
            reference_pair_frame_warnings = None
            if assignment_realized is not None:
                assignment_realized_output_path = os.path.abspath(
                    os.path.join(args.output_dir, "{}_assignment_realized.conf".format(sample_id))
                )
                assignment_realized_warnings = _write_assignment_realized_conf(
                    sample,
                    pred_a1,
                    pred_a3,
                    assignment_realized,
                    assignment_realized_output_path,
                    str(args.epochs),
                )
                for variant in assignment_realized_variants:
                    variant_realized = _assignment_realized_summary(
                        torch,
                        active,
                        decoded_pair_assignment,
                        pred_positions,
                        pred_a1,
                        pred_a3,
                        args,
                        repulsion_margin=variant["repulsion_margin"],
                        repulsion_steps=variant["repulsion_steps"],
                    )
                    variant_output_path = os.path.abspath(
                        os.path.join(
                            args.output_dir,
                            "{}_assignment_realized_{}.conf".format(sample_id, variant["name"]),
                        )
                    )
                    variant_warnings = _write_assignment_realized_conf(
                        sample,
                        pred_a1,
                        pred_a3,
                        variant_realized,
                        variant_output_path,
                        str(args.epochs),
                    )
                    assignment_realized_variant_records.append({
                        "name": variant["name"],
                        "output": variant_output_path,
                        "repulsion_margin": variant_realized["repulsion_margin"],
                        "repulsion_steps": variant_realized["repulsion_steps"],
                        "rmsd": variant_realized["rmsd"],
                        "os": variant_realized["os"],
                        "electrostatic_energy": variant_realized["electrostatic_energy"],
                        "physical_rule_metrics": variant_realized["physical_rule_metrics"],
                        "physical_rule_metrics_geometric_proxy": variant_realized[
                            "physical_rule_metrics_geometric_proxy"
                        ],
                        "validation_warnings": variant_warnings,
                    })
            if args.write_reference_pair_frame_conf:
                reference_pair_frame = _reference_pair_frame_summary(
                    torch,
                    active,
                    pred_positions,
                    pred_a1,
                    pred_a3,
                    args,
                )
                reference_pair_frame_output_path = os.path.abspath(
                    os.path.join(args.output_dir, "{}_reference_pair_frame.conf".format(sample_id))
                )
                reference_pair_frame_warnings = _write_assignment_realized_conf(
                    sample,
                    pred_a1,
                    pred_a3,
                    reference_pair_frame,
                    reference_pair_frame_output_path,
                    str(args.epochs),
                )
            final_realized_seconds += time.perf_counter() - sample_phase_t0
            metrics = start_metrics[sample_id]
            crossover_edges = active.get("design_crossover_edges", [])
            crossover_distance_rms_error = _edge_distance_rms_error(
                torch,
                crossover_edges,
                inputs["target_x_a"],
                pred_positions,
            )
            sample_split = (
                "train"
                if sample_id in train_id_set
                else ("val" if sample_id in val_id_set else "test")
            )
            sample_record = {
                "id": sample_id,
                "split": sample_split,
                "top": os.path.abspath(prepared["entry"]["top"]),
                "start": os.path.abspath(prepared["entry"]["start"]),
                "target": os.path.abspath(prepared["entry"]["target"]),
                "output": output_path,
                "num_atoms": sample.num_nucleotides,
                "num_frags": int(inputs["num_frags"][0].detach().cpu()),
                "start_rmsd": metrics["start_rmsd"],
                "raw_final_rmsd": float(raw_rmsd.detach().cpu()),
                "final_rmsd": float(rmsd.detach().cpu()),
                "start_os": metrics["start_os"],
                "raw_final_os": float(raw_os_score.detach().cpu()),
                "final_os": float(os_score.detach().cpu()),
                "start_electrostatic_energy": metrics["start_electrostatic_energy"],
                "target_electrostatic_energy": metrics["target_electrostatic_energy"],
                "raw_final_electrostatic_energy": float(raw_electrostatic.detach().cpu()),
                "final_electrostatic_energy": float(electrostatic.detach().cpu()),
                "residual_gate_scale": (
                    float(aux_outputs["residual_gate_scale"].detach().cpu())
                    if "residual_gate_scale" in aux_outputs
                    else 1.0
                ),
                "refine_record": refine_record,
                "node_train_count": node_train_count,
                "node_val_count": node_val_count,
                "node_train_final_rmsd": (
                    float(node_train_final_rmsd.detach().cpu()) if node_train_count else None
                ),
                "node_val_final_rmsd": (
                    float(node_val_final_rmsd.detach().cpu()) if node_val_count else None
                ),
                "node_train_final_os": (
                    float(node_train_final_os.detach().cpu()) if node_train_count else None
                ),
                "node_val_final_os": (
                    float(node_val_final_os.detach().cpu()) if node_val_count else None
                ),
                "graph_edge_count": int(active["graph_edges"].shape[1]),
                "graph_edge_feature_dim": int(active["graph_edge_features"].shape[1]),
                "electrostatic_edge_count": int(active["electrostatic_edges"].shape[1]),
                "pair_state_source": active["pair_state_source"],
                "start_pair_count": len(active["start_pairs"]),
                "final_pair_count": len(active["final_pairs"]),
                "reference_pair_source": active["reference_pair_source"],
                "crossover_count": len(crossover_edges),
                "crossover_distance_rms_error": (
                    float(crossover_distance_rms_error.detach().cpu())
                    if crossover_distance_rms_error is not None
                    else None
                ),
                "physical_rule_metrics": physical_metrics.to_dict() if physical_metrics is not None else None,
                "physical_rule_metrics_geometric_proxy": (
                    physical_metrics_proxy.to_dict() if physical_metrics_proxy is not None else None
                ),
                "pair_logit_assignment_metrics": pair_logit_assignment_metrics,
                "validation_warnings": report.warnings,
            }
            if args.write_assignment_realized_conf:
                sample_record.update({
                    "assignment_realized_output": assignment_realized_output_path,
                    "assignment_realized_rmsd": (
                        assignment_realized["rmsd"] if assignment_realized is not None else None
                    ),
                    "assignment_realized_os": (
                        assignment_realized["os"] if assignment_realized is not None else None
                    ),
                    "assignment_realized_electrostatic_energy": (
                        assignment_realized["electrostatic_energy"] if assignment_realized is not None else None
                    ),
                    "assignment_realized_physical_rule_metrics": (
                        assignment_realized["physical_rule_metrics"] if assignment_realized is not None else None
                    ),
                    "assignment_realized_physical_rule_metrics_geometric_proxy": (
                        assignment_realized["physical_rule_metrics_geometric_proxy"]
                        if assignment_realized is not None
                        else None
                    ),
                    "assignment_realized_validation_warnings": assignment_realized_warnings,
                    "assignment_realized_variants": assignment_realized_variant_records,
                })
            if args.write_reference_pair_frame_conf:
                sample_record.update({
                    "reference_pair_frame_output": reference_pair_frame_output_path,
                    "reference_pair_frame_rmsd": reference_pair_frame["rmsd"],
                    "reference_pair_frame_os": reference_pair_frame["os"],
                    "reference_pair_frame_electrostatic_energy": reference_pair_frame[
                        "electrostatic_energy"
                    ],
                    "reference_pair_frame_physical_rule_metrics": reference_pair_frame[
                        "physical_rule_metrics"
                    ],
                    "reference_pair_frame_physical_rule_metrics_geometric_proxy": reference_pair_frame[
                        "physical_rule_metrics_geometric_proxy"
                    ],
                    "reference_pair_frame_validation_warnings": reference_pair_frame_warnings,
                })
            sample_summaries.append(sample_record)

    summary = {
        "model": "shared_rigid_mlp_joint",
        "manifest": manifest_path,
        "manifest_sha256": manifest_sha256,
        "manifest_entry_count": manifest_entry_count,
        "max_samples": args.max_samples,
        "manifest_snapshot": manifest_snapshot_path,
        "manifest_snapshot_sha256": manifest_snapshot_sha256,
        "output_dir": os.path.abspath(args.output_dir),
        "save_model_state": os.path.abspath(args.save_model_state) if args.save_model_state else None,
        "save_best_model_state": os.path.abspath(args.save_best_model_state) if args.save_best_model_state else None,
        "best_model_monitor": args.best_model_monitor,
        "num_samples": len(prepared_samples),
        "num_train_samples": len(train_ids),
        "num_val_samples": len(val_ids),
        "num_test_samples": len(test_ids),
        "splits": {
            "train": train_ids,
            "val": val_ids,
            "test": test_ids,
        },
        "split_groups": split_groups,
        "split_audit": split_audit,
        "split_audit_hash": split_audit["sha256"],
        "split_mode": args.split_mode,
        "split_strategy": args.split_strategy,
        "epochs_requested": args.epochs,
        "epochs_ran": args.epochs,
        "final_evaluation_model": final_evaluation_model,
        "optimizer": args.optimizer,
        "learning_rate": args.learning_rate,
        "weight_decay": args.weight_decay,
        "scheduler": args.scheduler,
        "warmup_epochs": args.warmup_epochs,
        "min_lr_scale": args.min_lr_scale,
        "model_kind": args.model_kind,
        "shared_hidden_dim": args.shared_hidden_dim,
        "edge_feature_dim": int(edge_feature_dim),
        "node_feature_dim": int(input_dim),
        "physical_graph": bool(args.physical_graph or args.model_kind == "dgnn-physic"),
        "node_feature_names": prepared_samples[0].get("node_feature_names", []),
        "legacy_feature_dimension": args.legacy_feature_dimension,
        "defect_feature_schema": checkpoint_feature_schema,
        "checkpoint_metadata": checkpoint_metadata,
        "target_schema": TARGET_SCHEMA,
        "edge_feature_names": prepared_samples[0].get("edge_feature_names", []),
        "edge_relation_names": prepared_samples[0].get("edge_relation_names", ["default"]),
        "fourier_features": args.fourier_features,
        "dropout": args.dropout,
        "feature_noise_std": args.feature_noise_std,
        "design_features": args.design_features,
        "scale_normalized_residuals": args.scale_normalized_residuals,
        "message_passing_steps": args.message_passing_steps,
        "graph_mode": args.graph_mode,
        "graph_cutoff": args.graph_cutoff,
        "max_graph_neighbors": args.max_graph_neighbors,
        "include_candidate_wc_edges": args.include_candidate_wc_edges,
        "wc_edge_mode": args.wc_edge_mode,
        "candidate_wc_top_k": args.candidate_wc_top_k,
        "candidate_wc_cutoff": args.candidate_wc_cutoff,
        "restrict_pair_losses_to_candidate_wc_edges": args.restrict_pair_losses_to_candidate_wc_edges,
        "design_edge_sidecars": (
            os.path.abspath(args.design_edge_sidecars)
            if args.design_edge_sidecars
            else None
        ),
        "design_edge_sidecars_sha256": (
            design_edge_index["index_sha256"] if design_edge_index else None
        ),
        "require_explicit_design_edges": args.require_explicit_design_edges,
        "edge_family_pair": args.edge_family_pair,
        "edge_family_crossover": args.edge_family_crossover,
        "edge_family_duplex_step": args.edge_family_duplex_step,
        "edge_family_start_spatial": args.edge_family_start_spatial,
        "design_edge_source_counts": {
            "explicit_design": sum(
                1
                for prepared in prepared_samples
                if prepared.get("design_edge_fingerprint") is not None
            )
        },
        "design_edge_relation_counts": {
            name: sum(
                int((prepared.get("design_edge_relation_counts") or {}).get(name, 0))
                for prepared in prepared_samples
            )
            for name in prepared_samples[0].get("edge_relation_names", [])
        },
        "design_edge_fingerprints": {
            prepared["entry"]["id"]: prepared.get("design_edge_fingerprint")
            for prepared in prepared_samples
            if prepared.get("design_edge_fingerprint") is not None
        },
        "uses_explicit_pair_state_labels": any(
            prepared.get("pair_state_source") is not None for prepared in prepared_samples
        ),
        "stage_samples_on_cpu": args.stage_samples_on_cpu,
        "orientation_loss_weight": args.orientation_loss_weight,
        "electrostatic_loss_weight": args.electrostatic_loss_weight,
        "loss_weight_schedule": args.loss_weight_schedule,
        "loss_weight_ramp_epochs": args.loss_weight_ramp_epochs,
        "electrostatic_cutoff": args.electrostatic_cutoff,
        "electrostatic_debye_length": args.electrostatic_debye_length,
        "electrostatic_coefficient": args.electrostatic_coefficient,
        "wc_pair_cutoff": args.wc_pair_cutoff,
        "pair_distance_loss_weight": args.pair_distance_loss_weight,
        "pair_assignment_margin_loss_weight": args.pair_assignment_margin_loss_weight,
        "pair_assignment_margin": args.pair_assignment_margin,
        "pair_center_loss_weight": args.pair_center_loss_weight,
        "pair_axis_loss_weight": args.pair_axis_loss_weight,
        "pair_frame_loss_weight": args.pair_frame_loss_weight,
        "pair_classification_loss_weight": args.pair_classification_loss_weight,
        "pair_logit_exclusivity_loss_weight": args.pair_logit_exclusivity_loss_weight,
        "pair_logit_symmetry_loss_weight": args.pair_logit_symmetry_loss_weight,
        "pair_logit_sinkhorn_loss_weight": args.pair_logit_sinkhorn_loss_weight,
        "pair_partner_selection_loss_weight": args.pair_partner_selection_loss_weight,
        "pair_conflict_loss_weight": args.pair_conflict_loss_weight,
        "soft_partner_exclusivity_loss_weight": args.soft_partner_exclusivity_loss_weight,
        "helix_step_loss_weight": args.helix_step_loss_weight,
        "helix_step_axis_loss_weight": args.helix_step_axis_loss_weight,
        "nonpair_repulsion_loss_weight": args.nonpair_repulsion_loss_weight,
        "nonpair_repulsion_margin": args.nonpair_repulsion_margin,
        "enable_legacy_duplex_losses": args.enable_legacy_duplex_losses,
        "compute_final_physical_metrics": args.compute_final_physical_metrics,
        "oxdna_energy_loss_weight": args.oxdna_energy_loss_weight,
        "oxdna_energy_ramp_epochs": args.oxdna_energy_ramp_epochs,
        "oxdna_energy_backbone_weight": args.oxdna_energy_backbone_weight,
        "oxdna_energy_stacking_weight": args.oxdna_energy_stacking_weight,
        "oxdna_energy_hbond_weight": args.oxdna_energy_hbond_weight,
        "oxdna_energy_cross_stack_weight": args.oxdna_energy_cross_stack_weight,
        "oxdna_energy_excluded_volume_weight": args.oxdna_energy_excluded_volume_weight,
        "oxdna_energy_excluded_volume_cutoff": args.oxdna_energy_excluded_volume_cutoff,
        "oxdna_energy_excluded_volume_softness": args.oxdna_energy_excluded_volume_softness,
        "oxdna_energy_excluded_volume_max_pairs": args.oxdna_energy_excluded_volume_max_pairs,
        "start_rmsd_residual_gate_threshold": args.start_rmsd_residual_gate_threshold,
        "start_rmsd_residual_gate_sharpness": args.start_rmsd_residual_gate_sharpness,
        "start_rmsd_residual_min_scale": args.start_rmsd_residual_min_scale,
        "write_assignment_realized_conf": args.write_assignment_realized_conf,
        "write_reference_pair_frame_conf": args.write_reference_pair_frame_conf,
        "assignment_realized_repulsion_margin": args.assignment_realized_repulsion_margin,
        "assignment_realized_repulsion_steps": args.assignment_realized_repulsion_steps,
        "assignment_realized_repulsion_variants": assignment_realized_variants,
        "refine_steps": args.refine_steps,
        "refine_learning_rate": args.refine_learning_rate,
        "refine_orientation_loss_weight": args.refine_orientation_loss_weight,
        "refine_electrostatic_loss_weight": args.refine_electrostatic_loss_weight,
        "refine_drift_loss_weight": args.refine_drift_loss_weight,
        "refine_grad_clip": args.refine_grad_clip,
        "best_metric_name": best_state["metric_name"] if best_state is not None else None,
        "best_metric_value": best_state["metric_value"] if best_state is not None else None,
        "best_metric_epoch": best_state["epoch"] if best_state is not None else None,
        "history": history,
        "samples": sample_summaries,
        "elapsed_seconds": time.time() - start_time,
    }
    inference_bundle_path = os.path.abspath(
        args.save_inference_bundle
        or os.path.join(args.output_dir, "inference_bundle.json")
    )
    inference_bundle = build_inference_bundle(
        summary,
        checkpoint_paths={
            "final": args.save_model_state,
            "best": args.save_best_model_state if best_state is not None else None,
        },
    )
    write_inference_bundle(inference_bundle, inference_bundle_path)
    summary["inference_bundle"] = inference_bundle_path
    _timing_log(timing_enabled, "final_forward_total", final_forward_seconds)
    _timing_log(timing_enabled, "final_metric_total", final_metric_seconds)
    _timing_log(timing_enabled, "final_export_total", final_export_seconds)
    _timing_log(timing_enabled, "final_realized_total", final_realized_seconds)
    _timing_log(timing_enabled, "final_block_total", time.perf_counter() - final_phase_t0)
    summary.update(_torch_memory_summary(torch, args.device))
    with open(args.summary_json, "w") as handle:
        json.dump(summary, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
    _log_wandb_summary(wandb_run, summary, sample_summaries)
    wandb_run.finish()
    print("model=shared_rigid_mlp_joint")
    print("num_samples={}".format(summary["num_samples"]))
    print("summary_json={}".format(args.summary_json))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
