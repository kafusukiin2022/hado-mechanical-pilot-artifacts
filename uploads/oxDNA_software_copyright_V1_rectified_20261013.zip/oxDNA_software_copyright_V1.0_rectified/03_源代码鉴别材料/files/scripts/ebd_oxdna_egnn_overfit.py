#!/usr/bin/env python3
import argparse
import importlib.util
import json
import math
import os
import sys
import time
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EBD_ROOT = os.path.join(ROOT, "EBD")
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
if EBD_ROOT not in sys.path:
    sys.path.insert(0, EBD_ROOT)

from ebd_oxdna.adapter import load_oxdna_sample
from ebd_oxdna.decoder import decode_to_oxdna_frame
from ebd_oxdna.ebd_mapping import build_egnn_forward_inputs
from oxdna_export.io import write_config
from oxdna_export.validate import validate_frame


def _load_egnn_class():
    if "utils.atom_utils" not in sys.modules:
        utils_module = sys.modules.get("utils")
        if utils_module is None:
            utils_module = types.ModuleType("utils")
            sys.modules["utils"] = utils_module
        atom_utils_module = types.ModuleType("utils.atom_utils")

        def _unused_backmapping_matrix(*_args, **_kwargs):
            raise RuntimeError("backmapping_matrix is not used by the EGNN overfit path")

        atom_utils_module.backmapping_matrix = _unused_backmapping_matrix
        sys.modules["utils.atom_utils"] = atom_utils_module

    module_path = os.path.join(EBD_ROOT, "models", "egnn.py")
    spec = importlib.util.spec_from_file_location("ebd_models_egnn_direct", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.EGNN


def _rmsd_tensor(pred, target):
    import torch

    return torch.sqrt(torch.mean(torch.sum((pred - target) ** 2, dim=1)))


def _torch_memory_summary(torch, device):
    torch_device = torch.device(device)
    if torch_device.type != "cuda" or not torch.cuda.is_available():
        return {}
    index = torch_device.index if torch_device.index is not None else torch.cuda.current_device()
    return {
        "cuda_max_allocated_mib": torch.cuda.max_memory_allocated(index) / (1024.0 * 1024.0),
        "cuda_max_reserved_mib": torch.cuda.max_memory_reserved(index) / (1024.0 * 1024.0),
    }


def _positions_from_tensor(tensor):
    return [tuple(float(value) for value in row) for row in tensor.detach().cpu().tolist()]


class NodeDeltaResidualAdapter:
    def __init__(self, torch, num_nodes, device):
        self.module = torch.nn.Embedding(num_nodes, 3).to(device)
        torch.nn.init.zeros_(self.module.weight)
        self.node_ids = torch.arange(num_nodes, dtype=torch.long, device=device)

    def parameters(self):
        return self.module.parameters()

    def state_dict(self):
        return self.module.state_dict()

    def load_state_dict(self, state_dict):
        self.module.load_state_dict(state_dict)

    def __call__(self, positions):
        return positions + self.module(self.node_ids)


class NodeRigidResidualAdapter:
    def __init__(self, torch, num_nodes, start_a1, start_a3, device):
        self.torch = torch
        self.position_delta = torch.nn.Embedding(num_nodes, 3).to(device)
        self.a1_delta = torch.nn.Embedding(num_nodes, 3).to(device)
        self.a3_delta = torch.nn.Embedding(num_nodes, 3).to(device)
        torch.nn.init.zeros_(self.position_delta.weight)
        torch.nn.init.zeros_(self.a1_delta.weight)
        torch.nn.init.zeros_(self.a3_delta.weight)
        self.node_ids = torch.arange(num_nodes, dtype=torch.long, device=device)
        self.start_a1 = torch.tensor([list(row) for row in start_a1], dtype=torch.float32, device=device)
        self.start_a3 = torch.tensor([list(row) for row in start_a3], dtype=torch.float32, device=device)

    def parameters(self):
        return list(self.position_delta.parameters()) + list(self.a1_delta.parameters()) + list(self.a3_delta.parameters())

    def state_dict(self):
        return {
            "position_delta": self.position_delta.state_dict(),
            "a1_delta": self.a1_delta.state_dict(),
            "a3_delta": self.a3_delta.state_dict(),
        }

    def load_state_dict(self, state_dict):
        self.position_delta.load_state_dict(state_dict["position_delta"])
        self.a1_delta.load_state_dict(state_dict["a1_delta"])
        self.a3_delta.load_state_dict(state_dict["a3_delta"])

    def __call__(self, positions):
        node_ids = self.node_ids
        pred_positions = positions + self.position_delta(node_ids)
        raw_a1 = self.start_a1 + self.a1_delta(node_ids)
        raw_a3 = self.start_a3 + self.a3_delta(node_ids)
        pred_a1, pred_a3 = _orthonormalize_frame(self.torch, raw_a1, raw_a3)
        return pred_positions, pred_a1, pred_a3


class SharedRigidMLPAdapter:
    def __init__(self, torch, sample, hidden_dim, device):
        self.torch = torch
        self.features, self.start_a1, self.start_a3 = _build_shared_rigid_features(torch, sample, device)
        in_dim = self.features.shape[1]
        self.module = torch.nn.Sequential(
            torch.nn.Linear(in_dim, hidden_dim),
            torch.nn.SiLU(),
            torch.nn.Linear(hidden_dim, hidden_dim),
            torch.nn.SiLU(),
            torch.nn.Linear(hidden_dim, 9),
        ).to(device)
        for layer in self.module:
            if isinstance(layer, torch.nn.Linear):
                torch.nn.init.xavier_uniform_(layer.weight)
                torch.nn.init.zeros_(layer.bias)

    def parameters(self):
        return self.module.parameters()

    def state_dict(self):
        return self.module.state_dict()

    def load_state_dict(self, state_dict):
        self.module.load_state_dict(state_dict)

    def __call__(self, positions):
        residual = self.module(self.features)
        pred_positions = positions + residual[:, 0:3]
        raw_a1 = self.start_a1 + residual[:, 3:6]
        raw_a3 = self.start_a3 + residual[:, 6:9]
        pred_a1, pred_a3 = _orthonormalize_frame(self.torch, raw_a1, raw_a3)
        return pred_positions, pred_a1, pred_a3


def _build_shared_rigid_features(torch, sample, device):
    positions = torch.tensor([list(row) for row in sample.positions], dtype=torch.float32, device=device)
    center = torch.mean(positions, dim=0, keepdim=True)
    scale = torch.std(positions - center).clamp(min=1.0)
    norm_positions = (positions - center) / scale
    a1 = torch.tensor([list(row) for row in sample.a1], dtype=torch.float32, device=device)
    a3 = torch.tensor([list(row) for row in sample.a3], dtype=torch.float32, device=device)
    base_to_idx = {"A": 0, "C": 1, "G": 2, "T": 3, "U": 3}
    base_features = torch.zeros((sample.num_nucleotides, 4), dtype=torch.float32, device=device)
    for idx, row in enumerate(sample.topology.rows):
        base_features[idx, base_to_idx.get(row.base.upper(), 0)] = 1.0
    strand_ids = []
    strand_to_idx = {}
    strand_counts = {}
    for row in sample.topology.rows:
        if row.strand_id not in strand_to_idx:
            strand_to_idx[row.strand_id] = len(strand_ids)
            strand_ids.append(row.strand_id)
        strand_counts[row.strand_id] = strand_counts.get(row.strand_id, 0) + 1
    local_seen = {}
    strand_feature_rows = []
    denom_strand = float(max(1, len(strand_ids) - 1))
    denom_node = float(max(1, sample.num_nucleotides - 1))
    for idx, row in enumerate(sample.topology.rows):
        local_idx = local_seen.get(row.strand_id, 0)
        local_seen[row.strand_id] = local_idx + 1
        local_denom = float(max(1, strand_counts[row.strand_id] - 1))
        strand_feature_rows.append([
            strand_to_idx[row.strand_id] / denom_strand,
            local_idx / local_denom,
            idx / denom_node,
            strand_counts[row.strand_id] / float(max(1, sample.num_nucleotides)),
        ])
    strand_features = torch.tensor(strand_feature_rows, dtype=torch.float32, device=device)
    features = torch.cat([norm_positions, a1, a3, base_features, strand_features], dim=1)
    return features, a1, a3


def _orthonormalize_frame(torch, a1, a3, eps=1e-8):
    unit_a1 = a1 / torch.norm(a1, dim=1, keepdim=True).clamp(min=eps)
    projection = torch.sum(a3 * unit_a1, dim=1, keepdim=True)
    orthogonal_a3 = a3 - projection * unit_a1
    unit_a3 = orthogonal_a3 / torch.norm(orthogonal_a3, dim=1, keepdim=True).clamp(min=eps)
    return unit_a1, unit_a3


def _build_identity_inputs(torch, sample, device):
    kwargs = {}
    if device is not None:
        kwargs["device"] = device
    x_a = torch.tensor([list(row) for row in sample.positions], dtype=torch.float32, **kwargs)
    target_x_a = None
    if sample.target_positions is not None:
        target_x_a = torch.tensor([list(row) for row in sample.target_positions], dtype=torch.float32, **kwargs)
    a1 = torch.tensor([list(row) for row in sample.a1], dtype=torch.float32, **kwargs)
    a3 = torch.tensor([list(row) for row in sample.a3], dtype=torch.float32, **kwargs)
    target_a1 = None
    target_a3 = None
    if sample.target_a1 is not None:
        target_a1 = torch.tensor([list(row) for row in sample.target_a1], dtype=torch.float32, **kwargs)
    if sample.target_a3 is not None:
        target_a3 = torch.tensor([list(row) for row in sample.target_a3], dtype=torch.float32, **kwargs)
    strand_ids = []
    seen = set()
    for row in sample.topology.rows:
        if row.strand_id not in seen:
            strand_ids.append(row.strand_id)
            seen.add(row.strand_id)
    return {
        "x_a": x_a,
        "target_x_a": target_x_a,
        "a1": a1,
        "a3": a3,
        "target_a1": target_a1,
        "target_a3": target_a3,
        "num_atoms": torch.tensor([sample.num_nucleotides], dtype=torch.long, **kwargs),
        "num_frags": torch.tensor([len(strand_ids)], dtype=torch.long, **kwargs),
    }


def _add_frame_inputs(torch, inputs, sample, device):
    kwargs = {}
    if device is not None:
        kwargs["device"] = device
    inputs["a1"] = torch.tensor([list(row) for row in sample.a1], dtype=torch.float32, **kwargs)
    inputs["a3"] = torch.tensor([list(row) for row in sample.a3], dtype=torch.float32, **kwargs)
    inputs["target_a1"] = None
    inputs["target_a3"] = None
    if sample.target_a1 is not None:
        inputs["target_a1"] = torch.tensor([list(row) for row in sample.target_a1], dtype=torch.float32, **kwargs)
    if sample.target_a3 is not None:
        inputs["target_a3"] = torch.tensor([list(row) for row in sample.target_a3], dtype=torch.float32, **kwargs)
    return inputs


def _orientation_score(torch, pred_a1, pred_a3, target_a1, target_a3):
    pred_a1, pred_a3 = _orthonormalize_frame(torch, pred_a1, pred_a3)
    target_a1, target_a3 = _orthonormalize_frame(torch, target_a1, target_a3)
    per_node = 0.5 * (
        torch.sum(pred_a1 * target_a1, dim=1).clamp(min=-1.0, max=1.0)
        + torch.sum(pred_a3 * target_a3, dim=1).clamp(min=-1.0, max=1.0)
    )
    return torch.mean(per_node)


def _build_electrostatic_edges(torch, sample, positions, cutoff, device):
    if cutoff <= 0:
        return torch.empty((2, 0), dtype=torch.long, device=device)
    strand_ids = [row.strand_id for row in sample.topology.rows]
    pairs = []
    try:
        from scipy.spatial import cKDTree
    except ImportError:
        cKDTree = None
    coords = [list(row) for row in positions]
    if cKDTree is not None:
        tree = cKDTree(coords)
        for src, neighbors in enumerate(tree.query_ball_point(coords, r=cutoff)):
            for dst in neighbors:
                if dst <= src:
                    continue
                if strand_ids[src] == strand_ids[dst]:
                    continue
                pairs.append((src, dst))
    else:
        cutoff_sq = cutoff * cutoff
        for src in range(len(coords)):
            for dst in range(src + 1, len(coords)):
                if strand_ids[src] == strand_ids[dst]:
                    continue
                if sum((coords[src][axis] - coords[dst][axis]) ** 2 for axis in range(3)) <= cutoff_sq:
                    pairs.append((src, dst))
    if not pairs:
        return torch.empty((2, 0), dtype=torch.long, device=device)
    return torch.tensor([[src for src, _dst in pairs], [dst for _src, dst in pairs]], dtype=torch.long, device=device)


def _electrostatic_energy(torch, positions, edge_index, debye_length=1.2576, coefficient=1.4131):
    if edge_index.numel() == 0:
        return torch.tensor(0.0, dtype=positions.dtype, device=positions.device)
    row, col = edge_index
    dist = torch.norm(positions[col] - positions[row], p=2, dim=1).clamp(min=1e-8)
    return torch.sum(coefficient * torch.exp(-dist / debye_length) / dist)


def get_wandb_api_key_for_login():
    api_key = os.environ.get("WANDB_API_KEY", "").strip()
    if len(api_key) == 40:
        return api_key
    if api_key:
        print(
            "Skipping explicit wandb.login because WANDB_API_KEY length is {}, expected 40.".format(len(api_key)),
            flush=True,
        )
    return None


class WandbRun:
    def __init__(self, wandb_module=None):
        self._wandb = wandb_module

    @classmethod
    def create(cls, enabled, config, mode=None):
        if not enabled:
            return cls()
        try:
            import wandb
        except ImportError as exc:
            raise RuntimeError("wandb logging was requested, but wandb is not installed") from exc

        api_key = get_wandb_api_key_for_login()
        if api_key:
            wandb.login(key=api_key)

        tags = [tag for tag in os.environ.get("WANDB_TAGS", "").split(",") if tag]
        wandb.init(
            entity=os.environ.get("WANDB_ENTITY"),
            project=os.environ.get("WANDB_PROJECT", "deeporigami"),
            name=os.environ.get("WANDB_NAME"),
            group=os.environ.get("WANDB_RUN_GROUP"),
            tags=tags,
            config=config,
            mode=mode or os.environ.get("WANDB_MODE", "online"),
            settings=wandb.Settings(_disable_stats=True),
        )
        return cls(wandb)

    def log_epoch(
        self,
        epoch,
        loss,
        rmsd,
        best_rmsd,
        learning_rate,
        os_score=None,
        orientation_loss=None,
        electrostatic_energy=None,
    ):
        if self._wandb is None:
            return
        payload = {
            "train/loss": loss,
            "train/rmsd": rmsd,
            "train/best_rmsd": best_rmsd,
            "train/lr": learning_rate,
        }
        if os_score is not None:
            payload["train/os"] = os_score
        if orientation_loss is not None:
            payload["train/orientation_loss"] = orientation_loss
        if electrostatic_energy is not None:
            payload["train/electrostatic_energy"] = electrostatic_energy
        self._wandb.log(payload, step=epoch)

    def log_summary(self, summary):
        if self._wandb is None:
            return
        self._wandb.log(
            {
                "summary/final_rmsd": summary["final_rmsd"],
                "summary/best_epoch": summary["best_epoch"],
            }
        )

    def finish(self):
        if self._wandb is not None:
            self._wandb.finish()


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Overfit upstream EBD EGNN coordinates from oxDNA .top + start.conf to target .conf."
    )
    parser.add_argument("--top", required=True, help="Input oxDNA topology file.")
    parser.add_argument("--start", required=True, help="Input oxDNA start configuration.")
    parser.add_argument("--target", required=True, help="Target oxDNA configuration, usually md_last.conf.")
    parser.add_argument("--output", required=True, help="Output predicted oxDNA .conf path.")
    parser.add_argument("--summary-json", required=True, help="Output JSON summary path.")
    parser.add_argument("--init-model-state", default=None, help="Optional path to a saved EGNN state_dict to load before training.")
    parser.add_argument("--save-model-state", default=None, help="Optional path to save the final EGNN state_dict after training.")
    parser.add_argument("--device", default="cuda:0", help="Torch device, for example cuda:0 or cpu.")
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument(
        "--backbone",
        choices=["egnn", "identity"],
        default="egnn",
        help="Train the upstream EGNN backbone, or bypass it and train only a residual adapter from start coordinates.",
    )
    parser.add_argument(
        "--lr-scheduler",
        choices=["none", "plateau"],
        default="none",
        help="Optional learning-rate scheduler for longer unstable overfit runs.",
    )
    parser.add_argument("--lr-scheduler-factor", type=float, default=0.5)
    parser.add_argument("--lr-scheduler-patience", type=int, default=100)
    parser.add_argument("--min-learning-rate", type=float, default=1e-5)
    parser.add_argument("--hidden-nf", type=int, default=64)
    parser.add_argument("--n-layers", type=int, default=2)
    parser.add_argument("--inv-sublayers", type=int, default=1)
    parser.add_argument("--atom-cutoff", type=float, default=6.0)
    parser.add_argument("--max-spatial-neighbors", type=int, default=48)
    parser.add_argument("--orientation-cutoff", type=float, default=8.0)
    parser.add_argument("--max-orientation-neighbors", type=int, default=8)
    parser.add_argument("--fragment-graph-mode", choices=["complete", "distance"], default="distance")
    parser.add_argument("--log-every", type=int, default=10)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--patience", type=int, default=0, help="Stop after this many non-improving epochs; 0 disables.")
    parser.add_argument(
        "--residual-adapter",
        choices=["none", "node-delta", "node-rigid", "shared-rigid-mlp"],
        default="none",
        help="Optional trainable residual head after EGNN. node-delta/node-rigid are per-node; shared-rigid-mlp is a shared feature model.",
    )
    parser.add_argument("--shared-hidden-dim", type=int, default=128)
    parser.add_argument("--orientation-loss-weight", type=float, default=0.0)
    parser.add_argument("--electrostatic-loss-weight", type=float, default=0.0)
    parser.add_argument("--electrostatic-cutoff", type=float, default=0.0)
    parser.add_argument("--electrostatic-debye-length", type=float, default=1.2576)
    parser.add_argument("--electrostatic-coefficient", type=float, default=1.4131)
    parser.add_argument(
        "--freeze-egnn",
        action="store_true",
        help="Freeze EGNN parameters and train only the residual adapter. Requires a residual adapter.",
    )
    parser.add_argument(
        "--edge-chunk-size",
        type=int,
        default=131072,
        help="Process atom-edge message tensors in chunks to reduce peak GPU memory; 0 disables chunking.",
    )
    parser.add_argument("--wandb", action="store_true", help="Log training metrics to Weights & Biases.")
    parser.add_argument("--wandb-mode", default=None, help="W&B mode override, for example online or offline.")
    args = parser.parse_args(argv)

    import torch

    torch.manual_seed(args.seed)
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("requested CUDA device but torch.cuda.is_available() is false")

    start_time = time.time()
    torch_device = torch.device(args.device)
    if torch_device.type == "cuda":
        torch.cuda.set_device(torch_device)
        torch.cuda.reset_peak_memory_stats(torch_device.index if torch_device.index is not None else None)

    sample = load_oxdna_sample(args.top, args.start, args.target)
    if args.backbone == "identity":
        inputs = _build_identity_inputs(torch, sample, args.device)
    else:
        inputs = build_egnn_forward_inputs(
            sample,
            device=args.device,
            atom_cutoff=args.atom_cutoff,
            max_spatial_neighbors=args.max_spatial_neighbors,
            orientation_cutoff=args.orientation_cutoff,
            max_orientation_neighbors=args.max_orientation_neighbors,
            fragment_graph_mode=args.fragment_graph_mode,
        )
        inputs = _add_frame_inputs(torch, inputs, sample, args.device)
    if inputs["target_x_a"] is None:
        raise ValueError("--target is required for EGNN overfit")

    model = None
    if args.backbone == "egnn":
        EGNN = _load_egnn_class()
        model = EGNN(
            hidden_nf=args.hidden_nf,
            device=args.device,
            n_layers=args.n_layers,
            attention=False,
            tanh=False,
            norm_constant=1,
            inv_sublayers=args.inv_sublayers,
            sin_embedding=False,
            normalization_factor=100,
            aggregation_method="sum",
            edge_chunk_size=args.edge_chunk_size if args.edge_chunk_size and args.edge_chunk_size > 0 else None,
        ).to(args.device)
    adapter = None
    if args.residual_adapter == "node-delta":
        adapter = NodeDeltaResidualAdapter(torch, sample.num_nucleotides, args.device)
    elif args.residual_adapter == "node-rigid":
        adapter = NodeRigidResidualAdapter(torch, sample.num_nucleotides, sample.a1, sample.a3, args.device)
    elif args.residual_adapter == "shared-rigid-mlp":
        adapter = SharedRigidMLPAdapter(torch, sample, args.shared_hidden_dim, args.device)
    if args.freeze_egnn and adapter is None:
        raise ValueError("--freeze-egnn requires a residual adapter")
    if args.backbone == "identity" and adapter is None:
        raise ValueError("--backbone identity requires a residual adapter")
    if args.init_model_state:
        state_dict = torch.load(args.init_model_state, map_location=args.device)
        if isinstance(state_dict, dict) and "egnn" in state_dict:
            if model is not None:
                model.load_state_dict(state_dict["egnn"])
            if adapter is not None and "residual_adapter" in state_dict:
                adapter.load_state_dict(state_dict["residual_adapter"])
        else:
            if model is None:
                raise ValueError("legacy EGNN-only state cannot be loaded with --backbone identity")
            model.load_state_dict(state_dict)
    if args.freeze_egnn and model is not None:
        for parameter in model.parameters():
            parameter.requires_grad_(False)
    trainable_parameters = []
    if model is not None and not args.freeze_egnn:
        trainable_parameters.extend(model.parameters())
    if adapter is not None:
        trainable_parameters.extend(adapter.parameters())
    optimizer = torch.optim.Adam(trainable_parameters, lr=args.learning_rate)
    scheduler = None
    if args.lr_scheduler == "plateau":
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode="min",
            factor=args.lr_scheduler_factor,
            patience=args.lr_scheduler_patience,
            min_lr=args.min_learning_rate,
        )
    target = inputs["target_x_a"]
    start_rmsd = float(_rmsd_tensor(inputs["x_a"], target).detach().cpu())
    start_os = None
    if inputs["target_a1"] is not None and inputs["target_a3"] is not None:
        start_os = float(
            _orientation_score(torch, inputs["a1"], inputs["a3"], inputs["target_a1"], inputs["target_a3"]).detach().cpu()
        )
    electrostatic_edges = _build_electrostatic_edges(
        torch,
        sample,
        sample.positions,
        args.electrostatic_cutoff,
        args.device,
    )
    start_electrostatic_energy = float(
        _electrostatic_energy(
            torch,
            inputs["x_a"],
            electrostatic_edges,
            args.electrostatic_debye_length,
            args.electrostatic_coefficient,
        ).detach().cpu()
    )
    target_electrostatic_energy = None
    if target is not None:
        target_electrostatic_energy = float(
            _electrostatic_energy(
                torch,
                target,
                electrostatic_edges,
                args.electrostatic_debye_length,
                args.electrostatic_coefficient,
            ).detach().cpu()
        )
    wandb_run = WandbRun.create(
        enabled=args.wandb,
        mode=args.wandb_mode,
        config={
            "model": "egnn_overfit",
            "backbone": args.backbone,
            "top": os.path.abspath(args.top),
            "start": os.path.abspath(args.start),
            "target": os.path.abspath(args.target),
            "init_model_state": os.path.abspath(args.init_model_state) if args.init_model_state else None,
            "save_model_state": os.path.abspath(args.save_model_state) if args.save_model_state else None,
            "num_atoms": sample.num_nucleotides,
            "num_frags": int(inputs["num_frags"][0].detach().cpu()),
            "epochs": args.epochs,
            "learning_rate": args.learning_rate,
            "lr_scheduler": args.lr_scheduler,
            "lr_scheduler_factor": args.lr_scheduler_factor,
            "lr_scheduler_patience": args.lr_scheduler_patience,
            "min_learning_rate": args.min_learning_rate,
            "hidden_nf": args.hidden_nf,
            "n_layers": args.n_layers,
            "inv_sublayers": args.inv_sublayers,
            "atom_cutoff": args.atom_cutoff,
            "max_spatial_neighbors": args.max_spatial_neighbors,
            "orientation_cutoff": args.orientation_cutoff,
            "max_orientation_neighbors": args.max_orientation_neighbors,
            "fragment_graph_mode": args.fragment_graph_mode,
            "seed": args.seed,
            "edge_chunk_size": args.edge_chunk_size,
            "residual_adapter": args.residual_adapter,
            "freeze_egnn": args.freeze_egnn,
            "orientation_loss_weight": args.orientation_loss_weight,
            "shared_hidden_dim": args.shared_hidden_dim,
            "electrostatic_loss_weight": args.electrostatic_loss_weight,
            "electrostatic_cutoff": args.electrostatic_cutoff,
            "electrostatic_debye_length": args.electrostatic_debye_length,
            "electrostatic_coefficient": args.electrostatic_coefficient,
        },
    )

    best = {
        "epoch": 0,
        "loss": math.inf,
        "rmsd": start_rmsd,
        "position_loss": None,
        "orientation_loss": None,
        "electrostatic_energy": start_electrostatic_energy,
        "os": start_os,
        "positions": inputs["x_a"].detach().clone(),
        "a1": inputs["a1"].detach().clone(),
        "a3": inputs["a3"].detach().clone(),
    }
    non_improving = 0
    history = []

    for epoch in range(1, args.epochs + 1):
        if model is not None:
            model.train()
        optimizer.zero_grad()
        if model is None:
            pred = inputs["x_a"]
        else:
            pred = model(
                inputs["t"],
                inputs["a_type"],
                inputs["x_a"],
                inputs["e_a_idx"],
                inputs["e_a_type"],
                inputs["x_f"],
                inputs["h_f"],
                inputs["e_f_idx"],
                inputs["m_mat"],
                inputs["bm_mat"],
                inputs["num_atoms"],
                inputs["num_frags"],
            )
        pred_a1 = inputs["a1"]
        pred_a3 = inputs["a3"]
        if adapter is not None:
            adapted = adapter(pred)
            if isinstance(adapted, tuple):
                pred, pred_a1, pred_a3 = adapted
            else:
                pred = adapted
        position_loss = torch.mean((pred - target) ** 2)
        orientation_loss = torch.tensor(0.0, dtype=position_loss.dtype, device=position_loss.device)
        os_score = None
        if inputs["target_a1"] is not None and inputs["target_a3"] is not None:
            os_score = _orientation_score(torch, pred_a1, pred_a3, inputs["target_a1"], inputs["target_a3"])
            orientation_loss = 1.0 - os_score
        electrostatic_energy = _electrostatic_energy(
            torch,
            pred,
            electrostatic_edges,
            args.electrostatic_debye_length,
            args.electrostatic_coefficient,
        )
        loss = (
            position_loss
            + args.orientation_loss_weight * orientation_loss
            + args.electrostatic_loss_weight * electrostatic_energy
        )
        rmsd = _rmsd_tensor(pred, target)
        loss.backward()
        if args.grad_clip > 0:
            torch.nn.utils.clip_grad_norm_(trainable_parameters, args.grad_clip)
        optimizer.step()
        if scheduler is not None:
            scheduler.step(rmsd.detach())

        loss_value = float(loss.detach().cpu())
        position_loss_value = float(position_loss.detach().cpu())
        orientation_loss_value = float(orientation_loss.detach().cpu())
        electrostatic_energy_value = float(electrostatic_energy.detach().cpu())
        os_value = float(os_score.detach().cpu()) if os_score is not None else None
        rmsd_value = float(rmsd.detach().cpu())
        improved = loss_value < best["loss"] if args.orientation_loss_weight > 0 else rmsd_value < best["rmsd"]
        if improved:
            best = {
                "epoch": epoch,
                "loss": loss_value,
                "position_loss": position_loss_value,
                "orientation_loss": orientation_loss_value,
                "electrostatic_energy": electrostatic_energy_value,
                "os": os_value,
                "rmsd": rmsd_value,
                "positions": pred.detach().clone(),
                "a1": pred_a1.detach().clone(),
                "a3": pred_a3.detach().clone(),
            }
            non_improving = 0
        else:
            non_improving += 1

        if epoch == 1 or epoch == args.epochs or (args.log_every and epoch % args.log_every == 0):
            history.append({
                "epoch": epoch,
                "loss": loss_value,
                "position_loss": position_loss_value,
                "orientation_loss": orientation_loss_value,
                "electrostatic_energy": electrostatic_energy_value,
                "os": os_value,
                "rmsd": rmsd_value,
            })
            if os_value is None:
                print("epoch={} loss={:.12g} rmsd={:.12g}".format(epoch, loss_value, rmsd_value), flush=True)
            else:
                print(
                    "epoch={} loss={:.12g} rmsd={:.12g} os={:.12g} elec={:.12g}".format(
                        epoch, loss_value, rmsd_value, os_value, electrostatic_energy_value
                    ),
                    flush=True,
                )
            wandb_run.log_epoch(
                epoch=epoch,
                loss=loss_value,
                rmsd=rmsd_value,
                best_rmsd=best["rmsd"],
                learning_rate=optimizer.param_groups[0]["lr"],
                os_score=os_value,
                orientation_loss=orientation_loss_value,
                electrostatic_energy=electrostatic_energy_value,
            )

        if args.patience and non_improving >= args.patience:
            break

    pred_positions = _positions_from_tensor(best["positions"])
    pred_a1 = _positions_from_tensor(best["a1"])
    pred_a3 = _positions_from_tensor(best["a3"])
    frame = decode_to_oxdna_frame(
        sample,
        pred_positions,
        pred_a1,
        pred_a3,
        time="egnn_overfit_epoch_{}".format(best["epoch"]),
        box=sample.target_frame.box if sample.target_frame is not None else sample.start_frame.box,
        energy=sample.target_frame.energy if sample.target_frame is not None else sample.start_frame.energy,
    )
    report = validate_frame(sample.topology, frame)
    if not report.ok:
        for error in report.errors:
            sys.stderr.write("validation_error={}\n".format(error))
        return 1

    output_dir = os.path.dirname(os.path.abspath(args.output))
    summary_dir = os.path.dirname(os.path.abspath(args.summary_json))
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    if summary_dir:
        os.makedirs(summary_dir, exist_ok=True)
    write_config(frame, args.output)
    if args.save_model_state:
        if adapter is not None:
            state = {"residual_adapter": adapter.state_dict()}
            if model is not None:
                state["egnn"] = model.state_dict()
            torch.save(state, args.save_model_state)
        else:
            torch.save(model.state_dict(), args.save_model_state)

    summary = {
        "model": "egnn_overfit",
        "backbone": args.backbone,
        "top": os.path.abspath(args.top),
        "start": os.path.abspath(args.start),
        "target": os.path.abspath(args.target),
        "output": os.path.abspath(args.output),
        "init_model_state": os.path.abspath(args.init_model_state) if args.init_model_state else None,
        "save_model_state": os.path.abspath(args.save_model_state) if args.save_model_state else None,
        "num_atoms": sample.num_nucleotides,
        "num_frags": int(inputs["num_frags"][0].detach().cpu()),
        "epochs_requested": args.epochs,
        "epochs_ran": history[-1]["epoch"] if history else 0,
        "best_epoch": best["epoch"],
        "start_rmsd": start_rmsd,
        "start_os": start_os,
        "final_rmsd": best["rmsd"],
        "final_loss": best["loss"],
        "final_position_loss": best.get("position_loss"),
        "final_orientation_loss": best.get("orientation_loss"),
        "start_electrostatic_energy": start_electrostatic_energy,
        "target_electrostatic_energy": target_electrostatic_energy,
        "final_electrostatic_energy": best.get("electrostatic_energy"),
        "final_os": best.get("os"),
        "hidden_nf": args.hidden_nf,
        "n_layers": args.n_layers,
        "inv_sublayers": args.inv_sublayers,
        "learning_rate": args.learning_rate,
        "final_learning_rate": optimizer.param_groups[0]["lr"],
        "lr_scheduler": args.lr_scheduler,
        "lr_scheduler_factor": args.lr_scheduler_factor,
        "lr_scheduler_patience": args.lr_scheduler_patience,
        "min_learning_rate": args.min_learning_rate,
        "edge_chunk_size": args.edge_chunk_size,
        "atom_cutoff": args.atom_cutoff,
        "max_spatial_neighbors": args.max_spatial_neighbors,
        "orientation_cutoff": args.orientation_cutoff,
        "max_orientation_neighbors": args.max_orientation_neighbors,
        "fragment_graph_mode": args.fragment_graph_mode,
        "residual_adapter": args.residual_adapter,
        "freeze_egnn": args.freeze_egnn,
        "orientation_loss_weight": args.orientation_loss_weight,
        "shared_hidden_dim": args.shared_hidden_dim,
        "electrostatic_loss_weight": args.electrostatic_loss_weight,
        "electrostatic_cutoff": args.electrostatic_cutoff,
        "electrostatic_debye_length": args.electrostatic_debye_length,
        "electrostatic_coefficient": args.electrostatic_coefficient,
        "electrostatic_edge_count": int(electrostatic_edges.shape[1]),
        "validation_warnings": report.warnings,
        "history": history,
        "elapsed_seconds": time.time() - start_time,
    }
    summary.update(_torch_memory_summary(torch, args.device))
    with open(args.summary_json, "w") as handle:
        json.dump(summary, handle, indent=2, sort_keys=True)
        handle.write("\n")
    wandb_run.log_summary(summary)
    wandb_run.finish()

    print("model=egnn_overfit")
    print("num_atoms={}".format(summary["num_atoms"]))
    print("num_frags={}".format(summary["num_frags"]))
    print("start_rmsd={:.12g}".format(summary["start_rmsd"]))
    print("final_rmsd={:.12g}".format(summary["final_rmsd"]))
    print("best_epoch={}".format(summary["best_epoch"]))
    print("output={}".format(args.output))
    print("summary_json={}".format(args.summary_json))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
