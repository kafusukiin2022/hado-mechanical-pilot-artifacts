#!/usr/bin/env python3
import argparse
import hashlib
import inspect
import json
import math
import os
import sys
import time
import warnings

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from ebd_oxdna.adapter import load_oxdna_sample
from ebd_oxdna.decoder import decode_to_oxdna_frame
from ebd_oxdna.design_edges import build_typed_graph
from ebd_oxdna.design_edges import load_design_edge_sidecar
from ebd_oxdna.shared_rigid_bundle import load_inference_bundle
from ebd_oxdna.shared_rigid_bundle import require_target_free_compatible
from oxdna_export.io import write_config
from oxdna_export.validate import validate_frame
from scripts.ebd_oxdna_egnn_overfit import _build_identity_inputs
from scripts.ebd_oxdna_egnn_overfit import _build_shared_rigid_features
from scripts.ebd_oxdna_egnn_overfit import _positions_from_tensor
from scripts.ebd_oxdna_shared_rigid_train import DgnnLiteRigidModel
from scripts.ebd_oxdna_shared_rigid_train import GraphSharedRigidModel
from scripts.ebd_oxdna_shared_rigid_train import SharedRigidMLP
from scripts.ebd_oxdna_shared_rigid_train import _append_design_features
from scripts.ebd_oxdna_shared_rigid_train import _append_fourier_features
from scripts.ebd_oxdna_shared_rigid_train import _build_graph_edge_features
from scripts.ebd_oxdna_shared_rigid_train import _build_graph_edges
from scripts.ebd_oxdna_shared_rigid_train import _position_scale


def _discover_bundle_path(checkpoint_path, explicit_path=None):
    if explicit_path:
        path = os.path.abspath(explicit_path)
        if not os.path.isfile(path):
            raise ValueError("inference bundle does not exist: {}".format(path))
        return path

    checkpoint_dir = os.path.dirname(os.path.abspath(checkpoint_path))
    checkpoint_stem = os.path.splitext(os.path.basename(checkpoint_path))[0]
    candidates = [
        os.path.join(checkpoint_dir, "{}.bundle.json".format(checkpoint_stem)),
        os.path.join(checkpoint_dir, "inference_bundle.json"),
        os.path.join(checkpoint_dir, "summary.json"),
    ]
    for candidate in candidates:
        if os.path.isfile(candidate):
            return os.path.abspath(candidate)
    raise ValueError(
        "no inference bundle found beside checkpoint; pass --bundle explicitly"
    )


def _prepare_inference_sample(
    torch,
    top_path,
    start_path,
    device,
    bundle,
    design_edge_sidecar_path=None,
):
    preprocessing = bundle["preprocessing"]
    if preprocessing["graph_mode"] == "cutoff" and preprocessing["graph_cutoff"] > 0.0:
        try:
            from scipy.spatial import cKDTree  # noqa: F401
        except ImportError as exc:
            raise RuntimeError(
                "cutoff graph inference requires scipy.spatial.cKDTree"
            ) from exc
    sample = load_oxdna_sample(top_path, start_path)
    inputs = _build_identity_inputs(torch, sample, device)
    features, start_a1, start_a3 = _build_shared_rigid_features(
        torch,
        sample,
        device,
    )
    features = _append_fourier_features(
        torch,
        features,
        preprocessing["fourier_features"],
    )
    features = _append_design_features(
        torch,
        features,
        sample,
        preprocessing["design_features"],
    )
    position_scale = _position_scale(torch, sample, device)
    design_sidecar = None
    typed_graph = None
    if preprocessing.get("uses_design_edges", False):
        if not design_edge_sidecar_path:
            raise ValueError("a design-edge sidecar is required by this inference bundle")
        try:
            with open(design_edge_sidecar_path, "r") as handle:
                raw_sidecar = json.load(handle)
        except Exception as exc:
            raise ValueError(
                "invalid design-edge sidecar {}: {}".format(
                    design_edge_sidecar_path, exc
                )
            )
        sources = raw_sidecar.get("sources") if isinstance(raw_sidecar, dict) else None
        if not isinstance(sources, dict):
            raise ValueError("design-edge sidecar has no sources")
        entry = {
            "id": raw_sidecar.get("sample_id"),
            "top": top_path,
            "start": start_path,
            "cadnano_json": (sources.get("cadnano_json") or {}).get("path"),
            "virt2nuc": (sources.get("virt2nuc") or {}).get("path"),
        }
        design_sidecar = load_design_edge_sidecar(
            design_edge_sidecar_path,
            entry,
            required=True,
        )
        typed_graph = build_typed_graph(
            sample,
            design_sidecar,
            pair=preprocessing["edge_family_pair"],
            crossover=preprocessing["edge_family_crossover"],
            duplex_step=preprocessing["edge_family_duplex_step"],
            start_spatial=preprocessing["edge_family_start_spatial"],
        )
        graph_edges = (
            torch.tensor(typed_graph["edges"], dtype=torch.long, device=device)
            .t()
            .contiguous()
            if typed_graph["edges"]
            else torch.empty((2, 0), dtype=torch.long, device=device)
        )
        base_edge_features = _build_graph_edge_features(
            torch,
            sample,
            graph_edges,
            position_scale,
        )
        relation_features = torch.tensor(
            typed_graph["relations"], dtype=torch.float32, device=device
        )
        graph_edge_features = torch.cat(
            [base_edge_features, relation_features], dim=1
        )
    else:
        if design_edge_sidecar_path:
            raise ValueError("bundle does not use design edges but a sidecar was supplied")
        graph_edges = _build_graph_edges(
            torch,
            sample,
            preprocessing["graph_mode"],
            preprocessing["graph_cutoff"],
            preprocessing["max_graph_neighbors"],
            device,
            include_candidate_wc_edges=False,
            candidate_wc_top_k=0,
            candidate_wc_cutoff=0.0,
        )
        graph_edge_features = _build_graph_edge_features(
            torch,
            sample,
            graph_edges,
            position_scale,
        )
    candidate_wc_edge_mask = torch.zeros(
        graph_edges.shape[1],
        dtype=torch.bool,
        device=device,
    )
    expected_input_dim = bundle["model"]["input_dim"]
    expected_edge_dim = bundle["model"]["edge_feature_dim"]
    if features.shape[1] != expected_input_dim:
        raise ValueError(
            "preprocessed node feature dimension {} does not match bundle {}".format(
                features.shape[1],
                expected_input_dim,
            )
        )
    if graph_edge_features.shape[1] != expected_edge_dim:
        raise ValueError(
            "preprocessed edge feature dimension {} does not match bundle {}".format(
                graph_edge_features.shape[1],
                expected_edge_dim,
            )
        )
    return {
        "sample": sample,
        "inputs": inputs,
        "features": features,
        "start_a1": start_a1,
        "start_a3": start_a3,
        "position_scale": position_scale,
        "graph_edges": graph_edges,
        "graph_edge_features": graph_edge_features,
        "candidate_wc_edge_mask": candidate_wc_edge_mask,
        "design_edge_fingerprint": (
            design_sidecar.get("fingerprint") if design_sidecar is not None else None
        ),
        "design_edge_relation_counts": (
            typed_graph.get("relation_counts") if typed_graph is not None else None
        ),
    }


def _prepared_to_device(torch, prepared, device):
    moved_inputs = {
        key: value.to(device) if hasattr(value, "to") else value
        for key, value in prepared["inputs"].items()
    }
    return {
        "sample": prepared["sample"],
        "inputs": moved_inputs,
        "features": prepared["features"].to(device),
        "start_a1": prepared["start_a1"].to(device),
        "start_a3": prepared["start_a3"].to(device),
        "position_scale": prepared["position_scale"].to(device),
        "graph_edges": prepared["graph_edges"].to(device),
        "graph_edge_features": prepared["graph_edge_features"].to(device),
        "candidate_wc_edge_mask": prepared["candidate_wc_edge_mask"].to(device),
        "design_edge_fingerprint": prepared.get("design_edge_fingerprint"),
        "design_edge_relation_counts": prepared.get("design_edge_relation_counts"),
    }


def _build_model(torch, bundle, device):
    config = bundle["model"]
    common = {
        "torch": torch,
        "input_dim": config["input_dim"],
        "hidden_dim": config["hidden_dim"],
        "device": device,
        "scale_normalized_residuals": config["scale_normalized_residuals"],
        "dropout": config["dropout"],
    }
    if config["kind"] == "dgnn-lite":
        return DgnnLiteRigidModel(
            edge_dim=config["edge_feature_dim"],
            message_passing_steps=config["message_passing_steps"],
            wc_edge_mode=config["wc_edge_mode"],
            **common
        )
    if config["kind"] == "graph-shared":
        return GraphSharedRigidModel(
            message_passing_steps=config["message_passing_steps"],
            **common
        )
    if config["kind"] == "shared-mlp":
        return SharedRigidMLP(**common)
    raise ValueError("unsupported target-free model kind {!r}".format(config["kind"]))


def _extract_state_dict(checkpoint):
    if not isinstance(checkpoint, dict):
        raise ValueError("checkpoint must contain a state dictionary")
    for key in ("model_state_dict", "state_dict", "model"):
        value = checkpoint.get(key)
        if isinstance(value, dict):
            return value
    return checkpoint


def _forward(model, prepared, model_kind):
    if model_kind == "dgnn-lite":
        output = model(
            prepared["features"],
            prepared["inputs"]["x_a"],
            prepared["start_a1"],
            prepared["start_a3"],
            prepared["position_scale"],
            prepared["graph_edges"],
            prepared["graph_edge_features"],
            prepared["candidate_wc_edge_mask"],
        )
    else:
        output = model(
            prepared["features"],
            prepared["inputs"]["x_a"],
            prepared["start_a1"],
            prepared["start_a3"],
            prepared["position_scale"],
            prepared["graph_edges"] if model_kind == "graph-shared" else None,
        )
    return output[:3]


def _verify_checkpoint_hash(checkpoint_file, bundle):
    allowed = set(bundle.get("checkpoint_sha256", {}).values())
    if not allowed:
        raise ValueError("inference bundle has no checkpoint SHA-256 metadata")
    if not hasattr(checkpoint_file, "read") or not hasattr(checkpoint_file, "seek"):
        raise TypeError("checkpoint verification requires an open binary file")
    digest = hashlib.sha256()
    checkpoint_file.seek(0)
    while True:
        chunk = checkpoint_file.read(1024 * 1024)
        if not chunk:
            break
        digest.update(chunk)
    actual = digest.hexdigest()
    checkpoint_file.seek(0)
    if actual not in allowed:
        raise ValueError(
            "checkpoint SHA-256 does not match the inference bundle: {}".format(
                actual
            )
        )
    return actual


def _load_checkpoint(torch, checkpoint_path, map_location):
    if "weights_only" in inspect.signature(torch.load).parameters:
        return torch.load(
            checkpoint_path,
            map_location=map_location,
            weights_only=True,
        )
    warnings.warn(
        "This Torch version cannot load weights-only; use only the locally trusted, hash-verified checkpoint.",
        RuntimeWarning,
    )
    return torch.load(checkpoint_path, map_location=map_location)


def _load_verified_checkpoint(torch, checkpoint_path, bundle, map_location):
    with open(checkpoint_path, "rb") as checkpoint_file:
        checkpoint_sha256 = _verify_checkpoint_hash(checkpoint_file, bundle)
        checkpoint = _load_checkpoint(torch, checkpoint_file, map_location)
    return checkpoint, checkpoint_sha256


def _paths_alias(left, right):
    left_real = os.path.normcase(os.path.realpath(os.path.abspath(left)))
    right_real = os.path.normcase(os.path.realpath(os.path.abspath(right)))
    if left_real == right_real:
        return True
    try:
        return os.path.samefile(left, right)
    except OSError:
        return False


def _validate_destination_paths(output_path, summary_path, protected_paths):
    if _paths_alias(output_path, summary_path):
        raise ValueError("--output aliases --summary-json")
    for destination_name, destination_path in (
        ("--output", output_path),
        ("--summary-json", summary_path),
    ):
        for protected_name, protected_path in protected_paths.items():
            if _paths_alias(destination_path, protected_path):
                raise ValueError(
                    "{} aliases {}; refusing to overwrite an inference input".format(
                        destination_name,
                        protected_name,
                    )
                )


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Run target-free shared-rigid checkpoint inference on oxDNA top/start files."
    )
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument(
        "--checkpoint-sha256",
        default=None,
        help="independent expected SHA-256 required for a legacy schema-less summary",
    )
    parser.add_argument("--bundle", default=None)
    parser.add_argument("--top", required=True)
    parser.add_argument("--start", required=True)
    parser.add_argument(
        "--design-edge-sidecar",
        default=None,
        help="Checksum-bound sidecar required by typed design-edge bundles.",
    )
    parser.add_argument("--output", required=True)
    parser.add_argument("--summary-json", default=None)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--time", type=float, default=0.0)
    args = parser.parse_args(argv)

    import torch

    if not math.isfinite(args.time):
        raise ValueError("--time must be finite")
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("requested CUDA device but torch.cuda.is_available() is false")

    started_at = time.time()
    checkpoint_path = os.path.abspath(args.checkpoint)
    top_path = os.path.abspath(args.top)
    start_path = os.path.abspath(args.start)
    design_edge_sidecar_path = (
        os.path.abspath(args.design_edge_sidecar)
        if args.design_edge_sidecar
        else None
    )
    output_path = os.path.abspath(args.output)
    summary_path = os.path.abspath(args.summary_json or "{}.json".format(output_path))
    bundle_path = _discover_bundle_path(checkpoint_path, args.bundle)
    _validate_destination_paths(
        output_path,
        summary_path,
        dict({
            "--checkpoint": checkpoint_path,
            "--bundle": bundle_path,
            "--top": top_path,
            "--start": start_path,
        }, **(
            {"--design-edge-sidecar": design_edge_sidecar_path}
            if design_edge_sidecar_path
            else {}
        )),
    )
    bundle = load_inference_bundle(
        bundle_path,
        legacy_checkpoint_path=checkpoint_path,
        expected_checkpoint_sha256=args.checkpoint_sha256,
    )
    require_target_free_compatible(bundle)
    checkpoint, checkpoint_sha256 = _load_verified_checkpoint(
        torch,
        checkpoint_path,
        bundle,
        args.device,
    )

    preprocessing_device = (
        "cpu"
        if bundle["preprocessing"]["stage_samples_on_cpu"]
        else args.device
    )
    prepared = _prepare_inference_sample(
        torch,
        top_path,
        start_path,
        preprocessing_device,
        bundle,
        design_edge_sidecar_path=design_edge_sidecar_path,
    )
    if preprocessing_device != args.device:
        prepared = _prepared_to_device(torch, prepared, args.device)
    model = _build_model(torch, bundle, args.device)
    model.load_state_dict(_extract_state_dict(checkpoint))
    model.eval()
    inference_context = getattr(torch, "inference_mode", torch.no_grad)
    with inference_context():
        pred_positions, pred_a1, pred_a3 = _forward(
            model,
            prepared,
            bundle["model"]["kind"],
        )

    sample = prepared["sample"]
    numeric_time = "{:.12g}".format(args.time)
    frame = decode_to_oxdna_frame(
        sample,
        _positions_from_tensor(pred_positions),
        _positions_from_tensor(pred_a1),
        _positions_from_tensor(pred_a3),
        time=numeric_time,
        box=sample.start_frame.box,
        energy=sample.start_frame.energy,
    )
    report = validate_frame(sample.topology, frame)
    if not report.ok:
        raise RuntimeError("prediction validation failed: {}".format(report.errors))
    output_parent = os.path.dirname(output_path)
    if output_parent:
        os.makedirs(output_parent, exist_ok=True)
    write_config(frame, output_path)

    summary = {
        "model": "shared_rigid_mlp_joint",
        "model_kind": bundle["model"]["kind"],
        "target_free": True,
        "checkpoint": checkpoint_path,
        "checkpoint_sha256": checkpoint_sha256,
        "bundle_source": bundle_path,
        "top": top_path,
        "start": start_path,
        "output": output_path,
        "output_time": args.time,
        "device": args.device,
        "preprocessing_device": preprocessing_device,
        "num_nucleotides": sample.num_nucleotides,
        "node_feature_dim": int(prepared["features"].shape[1]),
        "edge_feature_dim": int(prepared["graph_edge_features"].shape[1]),
        "graph_edge_count": int(prepared["graph_edges"].shape[1]),
        "design_edge_sidecar": design_edge_sidecar_path,
        "design_edge_fingerprint": prepared.get("design_edge_fingerprint"),
        "design_edge_relation_counts": prepared.get("design_edge_relation_counts"),
        "validation_warnings": report.warnings,
        "elapsed_seconds": time.time() - started_at,
    }
    summary_parent = os.path.dirname(summary_path)
    if summary_parent:
        os.makedirs(summary_parent, exist_ok=True)
    with open(summary_path, "w") as handle:
        json.dump(summary, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print("model=shared_rigid_mlp_joint")
    print("target_free=true")
    print("output={}".format(output_path))
    print("summary_json={}".format(summary_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
