from dataclasses import dataclass


@dataclass(frozen=True)
class OxDNAEnergyConfig:
    backbone_weight: float = 1.0
    stacking_weight: float = 0.25
    hbond_weight: float = 1.0
    cross_stack_weight: float = 0.25
    excluded_volume_weight: float = 0.1
    excluded_volume_cutoff: float = 1.2
    excluded_volume_softness: float = 0.2
    excluded_volume_max_pairs: int = 200000
    eps: float = 1e-8


@dataclass(frozen=True)
class OxDNAEnergyBreakdown:
    total: object
    backbone: object
    stacking: object
    hbond: object
    cross_stack: object
    excluded_volume: object


def oxdna_energy_loss(
    torch,
    pred_positions,
    pred_a1,
    pred_a3,
    target_positions,
    target_a1,
    target_a3,
    backbone_edges,
    reference_pairs,
    helix_steps,
    config=None,
):
    config = config or OxDNAEnergyConfig()
    zero = pred_positions.sum() * 0.0
    backbone_index = _edge_index_tensor(torch, backbone_edges, pred_positions.device)
    pair_index = _edge_index_tensor(torch, reference_pairs, pred_positions.device)
    step_index = _step_index_tensor(torch, helix_steps, pred_positions.device)

    backbone = _bond_distance_energy(
        torch,
        pred_positions,
        target_positions,
        backbone_index,
        config.eps,
        zero,
    )
    stacking = _stacking_energy(
        torch,
        pred_positions,
        pred_a1,
        pred_a3,
        target_positions,
        target_a1,
        target_a3,
        backbone_index,
        config.eps,
        zero,
    )
    hbond = _hbond_energy(
        torch,
        pred_positions,
        pred_a1,
        pred_a3,
        target_positions,
        target_a1,
        target_a3,
        pair_index,
        config.eps,
        zero,
    )
    cross_stack = _cross_stack_energy(
        torch,
        pred_positions,
        target_positions,
        step_index,
        config.eps,
        zero,
    )
    excluded = _excluded_volume_energy(
        torch,
        pred_positions,
        backbone_index,
        pair_index,
        config.excluded_volume_cutoff,
        config.excluded_volume_softness,
        config.excluded_volume_max_pairs,
        zero,
    )
    total = (
        config.backbone_weight * backbone
        + config.stacking_weight * stacking
        + config.hbond_weight * hbond
        + config.cross_stack_weight * cross_stack
        + config.excluded_volume_weight * excluded
    )
    return OxDNAEnergyBreakdown(
        total=total,
        backbone=backbone,
        stacking=stacking,
        hbond=hbond,
        cross_stack=cross_stack,
        excluded_volume=excluded,
    )


def _edge_index_tensor(torch, edges, device):
    if edges is None:
        return None
    if torch.is_tensor(edges):
        if edges.numel() == 0:
            return None
        edge_index = edges.to(device=device, dtype=torch.long)
        if edge_index.dim() == 2 and edge_index.shape[0] == 2:
            edge_index = edge_index.t()
        return edge_index.reshape(-1, 2)
    if not edges:
        return None
    return torch.tensor(edges, dtype=torch.long, device=device).reshape(-1, 2)


def _step_index_tensor(torch, steps, device):
    if steps is None:
        return None
    if torch.is_tensor(steps):
        if steps.numel() == 0:
            return None
        return steps.to(device=device, dtype=torch.long).reshape(-1, 2, 2)
    if not steps:
        return None
    return torch.tensor(steps, dtype=torch.long, device=device).reshape(-1, 2, 2)


def _normalize(torch, values, eps):
    return values / torch.norm(values, p=2, dim=-1, keepdim=True).clamp(min=eps)


def _bond_distance_energy(torch, pred_positions, target_positions, edge_index, eps, zero):
    if edge_index is None:
        return zero
    pred_delta = pred_positions[edge_index[:, 1]] - pred_positions[edge_index[:, 0]]
    target_delta = target_positions[edge_index[:, 1]] - target_positions[edge_index[:, 0]]
    pred_distance = torch.norm(pred_delta, p=2, dim=1).clamp(min=eps)
    target_distance = torch.norm(target_delta, p=2, dim=1).clamp(min=eps)
    return torch.mean((pred_distance - target_distance) ** 2)


def _stacking_energy(
    torch,
    pred_positions,
    pred_a1,
    pred_a3,
    target_positions,
    target_a1,
    target_a3,
    edge_index,
    eps,
    zero,
):
    if edge_index is None:
        return zero
    pred_axis = _normalize(torch, pred_positions[edge_index[:, 1]] - pred_positions[edge_index[:, 0]], eps)
    target_axis = _normalize(torch, target_positions[edge_index[:, 1]] - target_positions[edge_index[:, 0]], eps)
    axis_loss = 1.0 - torch.sum(pred_axis * target_axis, dim=1)
    a3_loss = 1.0 - torch.sum(
        _normalize(torch, pred_a3[edge_index[:, 0]], eps)
        * _normalize(torch, pred_a3[edge_index[:, 1]], eps),
        dim=1,
    )
    target_a3_loss = 1.0 - torch.sum(
        _normalize(torch, target_a3[edge_index[:, 0]], eps)
        * _normalize(torch, target_a3[edge_index[:, 1]], eps),
        dim=1,
    )
    a1_target_loss = 1.0 - torch.sum(
        _normalize(torch, pred_a1[edge_index[:, 0]], eps)
        * _normalize(torch, target_a1[edge_index[:, 0]], eps),
        dim=1,
    )
    return torch.mean(axis_loss + (a3_loss - target_a3_loss) ** 2 + 0.25 * a1_target_loss)


def _hbond_energy(
    torch,
    pred_positions,
    pred_a1,
    pred_a3,
    target_positions,
    target_a1,
    target_a3,
    pair_index,
    eps,
    zero,
):
    if pair_index is None:
        return zero
    pred_delta = pred_positions[pair_index[:, 1]] - pred_positions[pair_index[:, 0]]
    target_delta = target_positions[pair_index[:, 1]] - target_positions[pair_index[:, 0]]
    pred_distance = torch.norm(pred_delta, p=2, dim=1).clamp(min=eps)
    target_distance = torch.norm(target_delta, p=2, dim=1).clamp(min=eps)
    distance_loss = (pred_distance - target_distance) ** 2
    pred_axis = _normalize(torch, pred_delta, eps)
    target_axis = _normalize(torch, target_delta, eps)
    axis_loss = 1.0 - torch.sum(pred_axis * target_axis, dim=1)
    a1_loss = 1.0 - torch.sum(
        _normalize(torch, pred_a1[pair_index[:, 0]], eps)
        * _normalize(torch, target_a1[pair_index[:, 0]], eps),
        dim=1,
    )
    a3_parallel = torch.sum(
        _normalize(torch, pred_a3[pair_index[:, 0]], eps)
        * _normalize(torch, pred_a3[pair_index[:, 1]], eps),
        dim=1,
    )
    target_a3_parallel = torch.sum(
        _normalize(torch, target_a3[pair_index[:, 0]], eps)
        * _normalize(torch, target_a3[pair_index[:, 1]], eps),
        dim=1,
    )
    return torch.mean(distance_loss + axis_loss + 0.25 * a1_loss + 0.25 * (a3_parallel - target_a3_parallel) ** 2)


def _pair_centers(torch, positions, pairs):
    return 0.5 * (positions[pairs[:, 0]] + positions[pairs[:, 1]])


def _cross_stack_energy(torch, pred_positions, target_positions, step_index, eps, zero):
    if step_index is None:
        return zero
    pred_first = _pair_centers(torch, pred_positions, step_index[:, 0, :])
    pred_second = _pair_centers(torch, pred_positions, step_index[:, 1, :])
    target_first = _pair_centers(torch, target_positions, step_index[:, 0, :])
    target_second = _pair_centers(torch, target_positions, step_index[:, 1, :])
    pred_delta = pred_second - pred_first
    target_delta = target_second - target_first
    distance_loss = (
        torch.norm(pred_delta, p=2, dim=1).clamp(min=eps)
        - torch.norm(target_delta, p=2, dim=1).clamp(min=eps)
    ) ** 2
    axis_loss = 1.0 - torch.sum(_normalize(torch, pred_delta, eps) * _normalize(torch, target_delta, eps), dim=1)
    return torch.mean(distance_loss + axis_loss)


def _canonical_pair_keys(torch, pairs, num_nodes, device):
    if pairs is None or pairs.numel() == 0:
        return torch.empty((0,), dtype=torch.long, device=device)
    pairs = pairs.to(device=device, dtype=torch.long).reshape(-1, 2)
    low = torch.minimum(pairs[:, 0], pairs[:, 1])
    high = torch.maximum(pairs[:, 0], pairs[:, 1])
    nonself = low < high
    return low[nonself] * int(num_nodes) + high[nonself]


def _allowed_pair_keys(torch, num_nodes, backbone_index, pair_index, device):
    keys = [
        _canonical_pair_keys(torch, index, num_nodes, device)
        for index in (backbone_index, pair_index)
        if index is not None and index.numel() > 0
    ]
    if not keys:
        return torch.empty((0,), dtype=torch.long, device=device)
    return torch.unique_consecutive(torch.sort(torch.cat(keys)).values)


def _remove_allowed_pairs(torch, row, col, num_nodes, allowed_keys):
    if row.numel() == 0 or allowed_keys.numel() == 0:
        return row, col
    candidate_keys = row.to(dtype=torch.long) * int(num_nodes) + col.to(dtype=torch.long)
    positions = torch.searchsorted(allowed_keys, candidate_keys)
    is_allowed = torch.zeros_like(candidate_keys, dtype=torch.bool)
    valid = positions < allowed_keys.numel()
    is_allowed[valid] = allowed_keys[positions[valid]] == candidate_keys[valid]
    keep = ~is_allowed
    return row[keep], col[keep]


def _excluded_volume_energy(torch, pred_positions, backbone_index, pair_index, cutoff, softness, max_pairs, zero):
    num_nodes = int(pred_positions.shape[0])
    if num_nodes < 2 or cutoff <= 0.0:
        return zero
    total_pairs = num_nodes * (num_nodes - 1) // 2
    if max_pairs and total_pairs > int(max_pairs):
        row, col = _sample_nonself_pairs(torch, num_nodes, int(max_pairs), pred_positions.device)
    else:
        row, col = torch.triu_indices(num_nodes, num_nodes, offset=1, device=pred_positions.device)
    with torch.no_grad():
        allowed_keys = _allowed_pair_keys(
            torch,
            num_nodes,
            backbone_index,
            pair_index,
            pred_positions.device,
        )
        row, col = _remove_allowed_pairs(torch, row, col, num_nodes, allowed_keys)
    if row.numel() == 0:
        return zero
    if max_pairs and int(row.numel()) > int(max_pairs):
        sample_index = torch.linspace(
            0,
            row.numel() - 1,
            steps=int(max_pairs),
            device=pred_positions.device,
        ).to(dtype=torch.long)
        row = row[sample_index]
        col = col[sample_index]
    distances = torch.norm(pred_positions[row] - pred_positions[col], p=2, dim=1)
    penalty = torch.nn.functional.softplus((cutoff - distances) / max(float(softness), 1e-6))
    return torch.mean(penalty ** 2)


def _sample_nonself_pairs(torch, num_nodes, max_pairs, device):
    count = max(1, int(max_pairs))
    row = torch.arange(count, device=device, dtype=torch.long) % int(num_nodes)
    stride = max(1, int(num_nodes) // 2 - 1)
    offset = (torch.arange(count, device=device, dtype=torch.long) * stride) % (int(num_nodes) - 1)
    col = (row + 1 + offset) % int(num_nodes)
    return torch.minimum(row, col), torch.maximum(row, col)
