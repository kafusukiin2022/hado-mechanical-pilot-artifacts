from dataclasses import dataclass
from typing import List, Optional, Tuple

from oxdna_export.io import OxDNAFrame, OxDNATopology, Vector3, read_config, read_topology


@dataclass(frozen=True)
class OxDNASample:
    topology: OxDNATopology
    start_frame: OxDNAFrame
    target_frame: Optional[OxDNAFrame]
    positions: List[Vector3]
    a1: List[Vector3]
    a3: List[Vector3]
    target_positions: Optional[List[Vector3]]
    target_a1: Optional[List[Vector3]]
    target_a3: Optional[List[Vector3]]
    backbone_edges: List[Tuple[int, int]]

    @property
    def num_nucleotides(self) -> int:
        return self.topology.num_nucleotides


def load_oxdna_sample(
    top_path: str,
    start_path: str,
    target_path: Optional[str] = None,
) -> OxDNASample:
    topology = read_topology(top_path)
    start_frame = read_config(start_path, expected_rows=topology.num_nucleotides)
    target_frame = None
    if target_path is not None:
        target_frame = read_config(target_path, expected_rows=topology.num_nucleotides)

    return OxDNASample(
        topology=topology,
        start_frame=start_frame,
        target_frame=target_frame,
        positions=[row.position for row in start_frame.rows],
        a1=[row.a1 for row in start_frame.rows],
        a3=[row.a3 for row in start_frame.rows],
        target_positions=_frame_positions(target_frame),
        target_a1=_frame_a1(target_frame),
        target_a3=_frame_a3(target_frame),
        backbone_edges=_build_backbone_edges(topology),
    )


def _frame_positions(frame: Optional[OxDNAFrame]) -> Optional[List[Vector3]]:
    if frame is None:
        return None
    return [row.position for row in frame.rows]


def _frame_a1(frame: Optional[OxDNAFrame]) -> Optional[List[Vector3]]:
    if frame is None:
        return None
    return [row.a1 for row in frame.rows]


def _frame_a3(frame: Optional[OxDNAFrame]) -> Optional[List[Vector3]]:
    if frame is None:
        return None
    return [row.a3 for row in frame.rows]


def _build_backbone_edges(topology: OxDNATopology) -> List[Tuple[int, int]]:
    edges = []
    seen = set()
    for idx, row in enumerate(topology.rows):
        for neighbor in (row.prev_idx, row.next_idx):
            if neighbor == -1:
                continue
            edge = (idx, neighbor)
            if edge not in seen:
                edges.append(edge)
                seen.add(edge)
    return edges
