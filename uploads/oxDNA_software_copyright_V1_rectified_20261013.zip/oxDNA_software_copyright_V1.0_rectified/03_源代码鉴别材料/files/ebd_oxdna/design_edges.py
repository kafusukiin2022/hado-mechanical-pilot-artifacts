"""Target-free design-edge sidecars in oxDNA topology-row space."""

from __future__ import annotations

import hashlib
import json
import math
import os
import pickle
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from oxdna_export.io import read_config, read_topology


SCHEMA = "ebd_oxdna.design_edges"
SCHEMA_VERSION = 1
RELATION_NAMES = (
    "backbone_forward",
    "backbone_reverse",
    "crossover",
    "base_pair",
    "duplex_step",
    "start_spatial",
)
INDEX_SCHEMA = "ebd_oxdna.design_edge_sidecar_index"
INDEX_SCHEMA_VERSION = 1

Edge = Tuple[int, int]


def sha256_file(path):
    digest = hashlib.sha256()
    with open(str(path), "rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_edge(left, right):
    left = int(left)
    right = int(right)
    if left == right:
        raise ValueError("design edges cannot contain self-edges")
    return (left, right) if left < right else (right, left)


def _require_file(entry, key):
    value = entry.get(key)
    path = Path(str(value or "")).absolute()
    if not value or not path.is_file() or path.stat().st_size <= 0:
        raise ValueError("{}: missing {} source: {}".format(entry.get("id"), key, path))
    return path


def _source_record(entry, key):
    path = _require_file(entry, key)
    actual = sha256_file(path)
    expected_hashes = entry.get("artifact_sha256")
    expected = expected_hashes.get(key) if isinstance(expected_hashes, dict) else None
    if expected is not None and str(expected).lower() != actual:
        raise ValueError(
            "{}: {} sha256 mismatch with manifest".format(entry.get("id"), key)
        )
    return {"path": str(path), "sha256": actual}


def _compat_unpickle_virt2nuc(path):
    class _CompatVirt2NucPlaceholder(object):
        def __setstate__(self, state):
            self.state = state

    class _CompatUnpickler(pickle.Unpickler):
        def find_class(self, module, name):
            if module == "libs.cadnano_utils" and name == "vhelix_vbase_to_nucleotide":
                return _CompatVirt2NucPlaceholder
            return super(_CompatUnpickler, self).find_class(module, name)

    with open(str(path), "rb") as handle:
        loaded = _CompatUnpickler(handle).load()
    if isinstance(loaded, tuple) and loaded:
        loaded = loaded[0]
    if isinstance(loaded, dict):
        state = loaded
    else:
        state = getattr(loaded, "state", None)
        if not isinstance(state, dict):
            state = getattr(loaded, "__dict__", None)
    if not isinstance(state, dict):
        raise ValueError("unsupported virt2nuc pickle structure: {}".format(path))
    scaffold = state.get("_scaf")
    staple = state.get("_stap")
    if not isinstance(scaffold, dict) or not isinstance(staple, dict):
        raise ValueError("virt2nuc has no scaffold/staple maps: {}".format(path))
    return state


def _mapped_ids(value):
    if isinstance(value, (tuple, list)) and len(value) == 2:
        candidate = value[1]
    else:
        candidate = value
    if isinstance(candidate, int):
        return [int(candidate)]
    if isinstance(candidate, (tuple, list)):
        try:
            return [int(item) for item in candidate]
        except (TypeError, ValueError):
            pass
    raise ValueError("unsupported virt2nuc mapping value {!r}".format(value))


def _row_present(row):
    if not isinstance(row, (tuple, list)) or len(row) < 4:
        raise ValueError("malformed caDNAno connectivity row {!r}".format(row))
    try:
        return any(int(value) != -1 for value in row[:4])
    except (TypeError, ValueError) as exc:
        raise ValueError("malformed caDNAno connectivity row {!r}".format(row)) from exc


def _singleton_node(mapping, key, kind, num_nodes):
    if key not in mapping:
        raise ValueError("missing virt2nuc mapping for {} {}".format(kind, key))
    node_ids = _mapped_ids(mapping[key])
    if len(node_ids) != 1:
        raise ValueError("ambiguous virt2nuc mapping for {} {}".format(kind, key))
    node = node_ids[0]
    if node < 0 or node >= num_nodes:
        raise ValueError(
            "virt2nuc node {} for {} {} is out of range [0, {})".format(
                node, kind, key, num_nodes
            )
        )
    return node


def _caDNAno_rows(cadnano):
    vstrands = cadnano.get("vstrands") if isinstance(cadnano, dict) else None
    if not isinstance(vstrands, list) or not vstrands:
        raise ValueError("caDNAno source has no vstrands")
    indexed = {}
    for vstrand in vstrands:
        if not isinstance(vstrand, dict) or vstrand.get("num") is None:
            raise ValueError("malformed caDNAno vstrand")
        helix = int(vstrand["num"])
        if helix in indexed:
            raise ValueError("duplicate caDNAno virtual helix {}".format(helix))
        indexed[helix] = vstrand
    return indexed


def _backbone_edges(topology):
    edges = set()
    for node, row in enumerate(topology.rows):
        for neighbor in (row.prev_idx, row.next_idx):
            if neighbor >= 0:
                edges.add(_canonical_edge(node, neighbor))
    return edges


def _extract_design_relations(cadnano, state, topology):
    num_nodes = topology.num_nucleotides
    scaffold = state["_scaf"]
    staple = state["_stap"]
    declared_count = state.get("nuc_count")
    if (
        declared_count is not None
        and int(declared_count) > 0
        and int(declared_count) != num_nodes
    ):
        raise ValueError(
            "virt2nuc nuc_count {} does not match topology {}".format(
                declared_count, num_nodes
            )
        )
    vstrands = _caDNAno_rows(cadnano)
    occupied = {"scaf": set(), "stap": set()}
    maps = {"scaf": scaffold, "stap": staple}
    mapped_nodes = {"scaf": {}, "stap": {}}

    for helix, vstrand in vstrands.items():
        for kind in ("scaf", "stap"):
            rows = vstrand.get(kind)
            if not isinstance(rows, list):
                raise ValueError("virtual helix {} has no {} rows".format(helix, kind))
            for base, row in enumerate(rows):
                if not _row_present(row):
                    continue
                key = (helix, base)
                occupied[kind].add(key)
                mapped_nodes[kind][key] = _singleton_node(
                    maps[kind], key, kind, num_nodes
                )

    pairs = []
    partner = {}
    shared = sorted(occupied["scaf"].intersection(occupied["stap"]))
    for key in shared:
        left = mapped_nodes["scaf"][key]
        right = mapped_nodes["stap"][key]
        edge = _canonical_edge(left, right)
        for node, other in ((edge[0], edge[1]), (edge[1], edge[0])):
            existing = partner.get(node)
            if existing is not None and existing != other:
                raise ValueError(
                    "nucleotide {} has more than one partner ({}, {})".format(
                        node, existing, other
                    )
                )
            partner[node] = other
        pairs.append(edge)
    pairs = sorted(set(pairs))
    if not pairs:
        raise ValueError("no explicit caDNAno design pairs were recovered")

    backbone = _backbone_edges(topology)
    crossovers = set()
    for helix, vstrand in vstrands.items():
        for kind in ("scaf", "stap"):
            rows = vstrand[kind]
            for base, row in enumerate(rows):
                if not _row_present(row):
                    continue
                current_key = (helix, base)
                current = mapped_nodes[kind][current_key]
                for neighbor_helix, neighbor_base in ((row[0], row[1]), (row[2], row[3])):
                    neighbor_helix = int(neighbor_helix)
                    neighbor_base = int(neighbor_base)
                    if neighbor_helix < 0 or neighbor_helix == helix:
                        continue
                    neighbor_vstrand = vstrands.get(neighbor_helix)
                    if neighbor_vstrand is None:
                        raise ValueError(
                            "crossover references missing virtual helix {}".format(
                                neighbor_helix
                            )
                        )
                    neighbor_rows = neighbor_vstrand.get(kind)
                    if (
                        not isinstance(neighbor_rows, list)
                        or neighbor_base < 0
                        or neighbor_base >= len(neighbor_rows)
                        or not _row_present(neighbor_rows[neighbor_base])
                    ):
                        raise ValueError(
                            "crossover references missing {} virtual base ({}, {})".format(
                                kind, neighbor_helix, neighbor_base
                            )
                        )
                    neighbor_key = (neighbor_helix, neighbor_base)
                    neighbor = mapped_nodes[kind].get(neighbor_key)
                    if neighbor is None:
                        neighbor = _singleton_node(
                            maps[kind], neighbor_key, kind, num_nodes
                        )
                    edge = _canonical_edge(current, neighbor)
                    if edge not in backbone:
                        raise ValueError(
                            "crossover {} is not a backbone link in topology".format(edge)
                        )
                    crossovers.add(edge)

    duplex_steps = set()
    for left, right in backbone:
        left_partner = partner.get(left)
        right_partner = partner.get(right)
        if left_partner is None or right_partner is None:
            continue
        partner_edge = _canonical_edge(left_partner, right_partner)
        if partner_edge in backbone:
            duplex_steps.add((left, right))
            duplex_steps.add(partner_edge)

    # tacoxDNA leaves nuc_count/strand_count at zero in these production
    # pickles. The actual maps are authoritative only when their singleton
    # nucleotide IDs exactly cover topology-row space.
    all_mapped_nodes = []
    for kind, mapping in (("scaf", scaffold), ("stap", staple)):
        for key, value in mapping.items():
            node_ids = _mapped_ids(value)
            if len(node_ids) != 1:
                raise ValueError(
                    "ambiguous virt2nuc mapping for {} {}".format(kind, key)
                )
            node = node_ids[0]
            if node < 0 or node >= num_nodes:
                raise ValueError(
                    "virt2nuc node {} for {} {} is out of range [0, {})".format(
                        node, kind, key, num_nodes
                    )
                )
            all_mapped_nodes.append(node)
    expected_nodes = set(range(num_nodes))
    if len(all_mapped_nodes) != num_nodes or set(all_mapped_nodes) != expected_nodes:
        raise ValueError(
            "virt2nuc singleton mapping does not exactly cover topology-row space"
        )

    return pairs, sorted(crossovers), sorted(duplex_steps), backbone


def _spatial_edges(start_path, num_nodes, cutoff, max_neighbors):
    if cutoff <= 0.0:
        raise ValueError("spatial_cutoff must be positive")
    if int(max_neighbors) <= 0:
        raise ValueError("max_spatial_neighbors must be positive")
    try:
        import numpy as np
        from scipy.spatial import cKDTree
    except ImportError as exc:
        raise RuntimeError("start-spatial sidecars require numpy and scipy") from exc

    frame = read_config(str(start_path), expected_rows=num_nodes)
    coordinates = np.asarray([row.position for row in frame.rows], dtype=float)
    if coordinates.shape != (num_nodes, 3) or not np.isfinite(coordinates).all():
        raise ValueError("start configuration has non-finite positions")
    if num_nodes < 2:
        return []
    query_count = min(num_nodes, int(max_neighbors) + 1)
    tree = cKDTree(coordinates)
    try:
        distances, neighbors = tree.query(
            coordinates,
            k=query_count,
            distance_upper_bound=float(cutoff),
            workers=1,
        )
    except TypeError:
        distances, neighbors = tree.query(
            coordinates,
            k=query_count,
            distance_upper_bound=float(cutoff),
        )
    if query_count == 1:
        distances = distances.reshape((num_nodes, 1))
        neighbors = neighbors.reshape((num_nodes, 1))
    edges = set()
    for source in range(num_nodes):
        candidates = []
        for distance, destination in zip(distances[source], neighbors[source]):
            destination = int(destination)
            distance = float(distance)
            if destination == source or destination >= num_nodes or not math.isfinite(distance):
                continue
            candidates.append((distance, destination))
        for _distance, destination in sorted(candidates)[: int(max_neighbors)]:
            edges.add(_canonical_edge(source, destination))
    return sorted(edges)


def _fingerprint_payload(sidecar):
    payload = dict(sidecar)
    payload.pop("fingerprint", None)
    encoded = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("ascii")
    return hashlib.sha256(encoded).hexdigest()


def _edge_lists(edges):
    return [[int(left), int(right)] for left, right in edges]


def build_design_edge_sidecar(
    entry,
    include_start_spatial=False,
    spatial_cutoff=8.0,
    max_spatial_neighbors=12,
):
    """Build a schema-v1 target-free edge sidecar in topology-row space."""
    sample_id = str(entry.get("id") or "")
    if not sample_id:
        raise ValueError("manifest entry has no id")
    sources = {
        "top": _source_record(entry, "top"),
        "cadnano_json": _source_record(entry, "cadnano_json"),
        "virt2nuc": _source_record(entry, "virt2nuc"),
    }
    topology = read_topology(sources["top"]["path"])
    try:
        with open(sources["cadnano_json"]["path"], "r") as handle:
            cadnano = json.load(handle)
    except Exception as exc:
        raise ValueError("{}: invalid caDNAno JSON: {}".format(sample_id, exc)) from exc
    state = _compat_unpickle_virt2nuc(sources["virt2nuc"]["path"])
    pairs, crossovers, duplex_steps, _backbone = _extract_design_relations(
        cadnano, state, topology
    )
    spatial = []
    spatial_parameters = None
    if include_start_spatial:
        sources["start"] = _source_record(entry, "start")
        spatial = _spatial_edges(
            sources["start"]["path"],
            topology.num_nucleotides,
            float(spatial_cutoff),
            int(max_spatial_neighbors),
        )
        spatial_parameters = {
            "cutoff": float(spatial_cutoff),
            "max_neighbors": int(max_spatial_neighbors),
        }

    edge_sets = {
        "base_pair": _edge_lists(pairs),
        "crossover": _edge_lists(crossovers),
        "duplex_step": _edge_lists(duplex_steps),
        "start_spatial": _edge_lists(spatial),
    }
    sidecar = {
        "schema": SCHEMA,
        "schema_version": SCHEMA_VERSION,
        "sample_id": sample_id,
        "num_nodes": topology.num_nucleotides,
        "relation_names": list(RELATION_NAMES),
        "source_kind": "explicit_design",
        "target_dependencies": [],
        "sources": sources,
        "spatial_parameters": spatial_parameters,
        "edges": edge_sets,
        "counts": {name: len(edges) for name, edges in edge_sets.items()},
    }
    _validate_sidecar_structure(sidecar, topology=topology)
    sidecar["fingerprint"] = _fingerprint_payload(sidecar)
    return sidecar


def build_typed_graph(
    sample,
    sidecar,
    pair=False,
    crossover=False,
    duplex_step=False,
    start_spatial=False,
):
    """Return deterministic directed edges with fixed six-way multi-hot types."""
    _validate_sidecar_structure(sidecar, topology=sample.topology)
    relation_by_edge = {}

    def ensure(edge):
        if edge not in relation_by_edge:
            relation_by_edge[edge] = [0] * len(RELATION_NAMES)
        return relation_by_edge[edge]

    for source, row in enumerate(sample.topology.rows):
        destination = row.next_idx
        if destination < 0:
            continue
        ensure((source, destination))[0] = 1
        ensure((destination, source))[1] = 1

    represented_backbone = {
        _canonical_edge(source, destination) for source, destination in relation_by_edge
    }
    expected_backbone = _backbone_edges(sample.topology)
    if represented_backbone != expected_backbone:
        raise ValueError("topology prev/next links are not reciprocal")

    def add_undirected(edge_values, relation_index):
        for left, right in edge_values:
            ensure((left, right))[relation_index] = 1
            ensure((right, left))[relation_index] = 1

    if pair:
        add_undirected(sidecar["edges"]["base_pair"], 3)
    if crossover:
        add_undirected(sidecar["edges"]["crossover"], 2)
    if duplex_step:
        add_undirected(sidecar["edges"]["duplex_step"], 4)
    if start_spatial:
        if "start" not in sidecar["sources"]:
            raise ValueError("start-spatial relation requested from a sidecar without start")
        add_undirected(sidecar["edges"]["start_spatial"], 5)

    ordered_edges = sorted(relation_by_edge)
    relations = [relation_by_edge[edge] for edge in ordered_edges]
    relation_counts = {
        name: sum(row[index] for row in relations)
        for index, name in enumerate(RELATION_NAMES)
    }
    return {
        "edges": _edge_lists(ordered_edges),
        "relations": relations,
        "relation_names": list(RELATION_NAMES),
        "relation_counts": relation_counts,
        "enabled_families": {
            "pair": bool(pair),
            "crossover": bool(crossover),
            "duplex_step": bool(duplex_step),
            "start_spatial": bool(start_spatial),
        },
        "sidecar_fingerprint": sidecar.get("fingerprint"),
    }


def _validated_edge_set(sidecar, name, num_nodes):
    values = sidecar["edges"].get(name)
    if not isinstance(values, list):
        raise ValueError("sidecar is missing edge set {}".format(name))
    result = []
    for raw in values:
        if not isinstance(raw, list) or len(raw) != 2:
            raise ValueError("malformed {} edge {!r}".format(name, raw))
        left, right = raw
        if type(left) is not int or type(right) is not int:
            raise ValueError("non-integer {} edge {!r}".format(name, raw))
        if left < 0 or right < 0 or left >= num_nodes or right >= num_nodes:
            raise ValueError("{} edge {!r} is out of range".format(name, raw))
        if left >= right:
            raise ValueError("{} edge {!r} is not canonical".format(name, raw))
        result.append((left, right))
    if result != sorted(set(result)):
        raise ValueError("{} edges are not sorted and unique".format(name))
    return set(result)


def _validate_sidecar_structure(sidecar, topology=None):
    if not isinstance(sidecar, dict) or sidecar.get("schema") != SCHEMA:
        raise ValueError("unsupported design-edge sidecar schema")
    if sidecar.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unsupported design-edge sidecar version")
    num_nodes = sidecar.get("num_nodes")
    if type(num_nodes) is not int or num_nodes <= 0:
        raise ValueError("sidecar num_nodes must be positive")
    if topology is not None and topology.num_nucleotides != num_nodes:
        raise ValueError("sidecar node count does not match topology")
    if sidecar.get("relation_names") != list(RELATION_NAMES):
        raise ValueError("sidecar relation vocabulary is not fixed schema-v1")
    if sidecar.get("source_kind") != "explicit_design":
        raise ValueError("sidecar source_kind must be explicit_design")
    if sidecar.get("target_dependencies") != []:
        raise ValueError("design-edge sidecar must not contain target dependencies")
    sources = sidecar.get("sources")
    if not isinstance(sources, dict) or "target" in sources:
        raise ValueError("invalid target-free sidecar sources")
    edges = sidecar.get("edges")
    if not isinstance(edges, dict):
        raise ValueError("sidecar has no edge sets")
    validated = {
        name: _validated_edge_set(sidecar, name, num_nodes)
        for name in ("base_pair", "crossover", "duplex_step", "start_spatial")
    }
    counts = sidecar.get("counts")
    if not isinstance(counts, dict):
        raise ValueError("sidecar has no edge counts")
    for name, values in validated.items():
        if counts.get(name) != len(values):
            raise ValueError("sidecar {} count does not match edges".format(name))

    partners = defaultdict(set)
    for left, right in validated["base_pair"]:
        partners[left].add(right)
        partners[right].add(left)
    if any(len(values) != 1 for values in partners.values()):
        raise ValueError("sidecar base pairs are not one-to-one")
    if topology is not None:
        backbone = _backbone_edges(topology)
        for name in ("crossover", "duplex_step"):
            if not validated[name].issubset(backbone):
                raise ValueError("{} contains a non-backbone edge".format(name))


def load_design_edge_sidecar(path, entry, required=True):
    """Load and checksum-validate one sidecar, failing closed when required."""
    path = Path(str(path)).absolute()
    if not path.is_file():
        if not required:
            return None
        raise ValueError("missing design-edge sidecar: {}".format(path))
    try:
        sidecar = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError("invalid design-edge sidecar {}: {}".format(path, exc)) from exc
    fingerprint = sidecar.get("fingerprint") if isinstance(sidecar, dict) else None
    if fingerprint != _fingerprint_payload(sidecar):
        raise ValueError("design-edge sidecar fingerprint mismatch: {}".format(path))
    _validate_sidecar_structure(sidecar)
    sample_id = str(entry.get("id") or "")
    if sidecar.get("sample_id") != sample_id:
        raise ValueError("sidecar sample_id does not match manifest entry")
    if "target" in sidecar["sources"]:
        raise ValueError("sidecar contains a target dependency")

    expected_keys = ["top", "cadnano_json", "virt2nuc"]
    if "start" in sidecar["sources"]:
        expected_keys.append("start")
    if set(sidecar["sources"]) != set(expected_keys):
        raise ValueError("sidecar source set is invalid")
    for key in expected_keys:
        expected = _source_record(entry, key)
        actual = sidecar["sources"].get(key)
        if not isinstance(actual, dict):
            raise ValueError("sidecar is missing {} source".format(key))
        if actual.get("sha256") != expected["sha256"]:
            raise ValueError("{} sha256 mismatch in design-edge sidecar".format(key))
    topology = read_topology(sidecar["sources"]["top"]["path"])
    _validate_sidecar_structure(sidecar, topology=topology)
    return sidecar


def load_design_edge_sidecar_index(path, manifest_sha256, entries, required=True):
    """Validate an index and return checksum-bound sidecar paths by sample ID."""
    path = Path(str(path)).absolute()
    if not path.is_file():
        if not required:
            return None
        raise ValueError("missing design-edge sidecar index: {}".format(path))
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError("invalid design-edge sidecar index {}: {}".format(path, exc)) from exc
    if not isinstance(payload, dict) or payload.get("schema") != INDEX_SCHEMA:
        raise ValueError("unsupported design-edge sidecar index schema")
    if payload.get("schema_version") != INDEX_SCHEMA_VERSION:
        raise ValueError("unsupported design-edge sidecar index version")
    if payload.get("manifest_sha256") != manifest_sha256:
        raise ValueError("design-edge index manifest SHA-256 does not match training manifest")
    records = payload.get("sidecars")
    if not isinstance(records, dict) or payload.get("sidecar_count") != len(records):
        raise ValueError("design-edge index sidecar count is invalid")

    entry_ids = []
    for entry in entries:
        sample_id = str(entry.get("id") or "") if isinstance(entry, dict) else ""
        if not sample_id:
            raise ValueError("training entry has no ID for design-edge index")
        entry_ids.append(sample_id)
    missing = sorted(set(entry_ids) - set(records))
    if missing:
        raise ValueError(
            "design-edge index is missing samples: {}".format(", ".join(missing[:5]))
        )

    sidecars = {}
    fingerprints = {}
    hashes = {}
    for sample_id in entry_ids:
        record = records[sample_id]
        if not isinstance(record, dict):
            raise ValueError("invalid design-edge index record for {}".format(sample_id))
        sidecar_value = record.get("path")
        sidecar_path = Path(str(sidecar_value or ""))
        if not sidecar_path.is_absolute():
            sidecar_path = path.parent / sidecar_path
        sidecar_path = sidecar_path.absolute()
        if not sidecar_path.is_file():
            raise ValueError("missing indexed design-edge sidecar: {}".format(sidecar_path))
        actual_hash = sha256_file(sidecar_path)
        if record.get("sha256") != actual_hash:
            raise ValueError("sidecar SHA-256 mismatch for {}".format(sample_id))
        sidecars[sample_id] = str(sidecar_path)
        hashes[sample_id] = actual_hash
        fingerprints[sample_id] = record.get("fingerprint")
    return {
        "path": str(path),
        "index_sha256": sha256_file(path),
        "manifest_sha256": manifest_sha256,
        "sidecars": sidecars,
        "sidecar_sha256": hashes,
        "fingerprints": fingerprints,
    }
