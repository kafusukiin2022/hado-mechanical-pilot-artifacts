"""Target-free defect annotations for surviving oxDNA nucleotide nodes."""

import hashlib
import json
import math
import re


DEFECT_SIDECAR_SCHEMA = "defect6hb.gnn_sidecar"
DEFECT_CHANNELS = (
    "has_defect",
    "is_missing_staple",
    "is_backbone_nick",
    "nick_boundary",
    "lost_designed_partner",
    "graph_distance_norm",
    "graph_distance_known",
    "euclidean_distance_norm",
    "removed_parent_nt_norm",
)
DEFECT_NORMALIZATION = {
    "graph_distance_norm": "capped_parent_graph_distance",
    "euclidean_distance_norm": "parent_bounding_box_diagonal",
    "removed_parent_nt_norm": "parent_num_nodes",
    "unknown_graph_distance": -1.0,
    "unknown_graph_distance_known": 0.0,
}
DEFECT_FEATURE_SCHEMA = {
    "name": "defect_features_v1",
    "version": 1,
    "channels": list(DEFECT_CHANNELS),
    "normalization": dict(DEFECT_NORMALIZATION),
}

_DEFECT_TYPES = ("none", "missing_staple", "backbone_nick")
_REQUIRED_SOURCE_HASHES = (
    "topology_sha256",
    "initial_configuration_sha256",
    "canonical_map_sha256",
)
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def canonical_sha256(value):
    """Return the repository-independent canonical hash used by sidecars."""

    try:
        payload = json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("ascii")
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise ValueError("plan payload is not canonical JSON: {}".format(exc))
    return hashlib.sha256(payload).hexdigest()


def validate_defect_sidecar(sample, sidecar):
    """Validate a v1 sidecar against one materialized variant sample."""

    if not isinstance(sidecar, dict) or sidecar.get("schema") != DEFECT_SIDECAR_SCHEMA:
        raise ValueError("unsupported defect sidecar schema")
    if sidecar.get("schema_version") != 1:
        raise ValueError("unsupported defect sidecar schema version")
    if sidecar.get("feature_schema") != DEFECT_FEATURE_SCHEMA:
        raise ValueError("defect feature schema does not match defect_features_v1")
    if sidecar.get("target_dependencies") != []:
        raise ValueError("defect sidecar provenance must be target-free")
    for forbidden in ("target", "targets", "trajectory", "analysis"):
        if forbidden in sidecar:
            raise ValueError("defect sidecar provenance must be target-free")

    parent_id = sidecar.get("parent_id")
    variant_id = sidecar.get("variant_id")
    if not isinstance(parent_id, str) or not parent_id:
        raise ValueError("defect sidecar has no parent_id")
    if not isinstance(variant_id, str) or not variant_id:
        raise ValueError("defect sidecar has no variant_id")

    plan = sidecar.get("plan")
    if not isinstance(plan, dict) or not isinstance(plan.get("payload"), dict):
        raise ValueError("defect sidecar has no canonical plan payload")
    plan_id = plan.get("plan_id")
    if not isinstance(plan_id, str) or not plan_id:
        raise ValueError("defect sidecar has no plan_id")
    if plan["payload"].get("plan_id") != plan_id:
        raise ValueError("plan hash provenance has inconsistent plan_id")
    plan_hash = plan.get("sha256")
    if not _is_sha256(plan_hash) or canonical_sha256(plan["payload"]) != plan_hash:
        raise ValueError("plan hash does not match canonical plan payload")

    defect_type = sidecar.get("defect_type")
    if defect_type not in _DEFECT_TYPES:
        raise ValueError("unsupported defect type {!r}".format(defect_type))
    if plan["payload"].get("defect_type") != defect_type:
        raise ValueError("plan hash payload defect type does not match sidecar")
    if plan["payload"].get("parent_id") != parent_id:
        raise ValueError("plan hash payload parent_id does not match sidecar")

    source_hashes = sidecar.get("source_hashes")
    if not isinstance(source_hashes, dict):
        raise ValueError("defect sidecar has no source hash provenance")
    for key in _REQUIRED_SOURCE_HASHES:
        if not _is_sha256(source_hashes.get(key)):
            raise ValueError("invalid source hash {}".format(key))
    if any(
        marker in key.lower()
        for key in source_hashes
        for marker in ("target", "final", "trajectory", "analysis")
    ):
        raise ValueError("source hash provenance must be target-free")

    num_nodes = sidecar.get("num_nodes")
    sample_nodes = _sample_num_nodes(sample)
    if type(num_nodes) is not int or num_nodes != sample_nodes:
        raise ValueError(
            "defect sidecar node count {} does not match sample {}".format(
                num_nodes, sample_nodes
            )
        )
    parent_num_nodes = sidecar.get("parent_num_nodes")
    if type(parent_num_nodes) is not int or parent_num_nodes < num_nodes:
        raise ValueError("invalid parent node count")
    removed_parent_nt = sidecar.get("removed_parent_nt")
    if type(removed_parent_nt) is not int or removed_parent_nt < 0:
        raise ValueError("removed_parent_nt must be a non-negative integer")

    canonical_ids = _canonical_id_list(
        sidecar.get("variant_row_to_parent_node_id"),
        "variant canonical IDs",
    )
    if len(canonical_ids) != num_nodes:
        raise ValueError("variant canonical ID count does not match node count")
    sample_canonical_ids = getattr(sample, "canonical_ids", None)
    if sample_canonical_ids is not None and list(sample_canonical_ids) != canonical_ids:
        raise ValueError("variant canonical IDs do not match sample row order")

    removed_ids = _canonical_id_list(
        sidecar.get("removed_parent_node_ids"),
        "removed canonical IDs",
        allow_empty=True,
    )
    if set(canonical_ids).intersection(removed_ids):
        raise ValueError("surviving and removed canonical IDs overlap")
    if removed_parent_nt != len(removed_ids):
        raise ValueError("removed_parent_nt does not match removed canonical IDs")
    if parent_num_nodes != num_nodes + len(removed_ids):
        raise ValueError("parent node count does not match surviving and removed nodes")
    if defect_type in ("none", "backbone_nick") and removed_ids:
        raise ValueError("non-omission sidecar cannot remove canonical IDs")

    annotations = sidecar.get("node_annotations")
    if not isinstance(annotations, list) or len(annotations) != num_nodes:
        raise ValueError("node annotation count does not match node count")
    annotation_ids = []
    for row, annotation in enumerate(annotations):
        if not isinstance(annotation, dict):
            raise ValueError("node annotation {} is not an object".format(row))
        annotation_ids.append(annotation.get("parent_node_id"))
        _require_bool(annotation, "nick_boundary", row)
        _require_bool(annotation, "lost_designed_partner", row)
        known = _require_bool(annotation, "graph_distance_known", row)
        graph_distance = _finite_number(
            annotation.get("graph_distance_norm"),
            "node {} graph_distance_norm".format(row),
        )
        if known:
            if graph_distance < 0.0 or graph_distance > 1.0:
                raise ValueError("known graph distance must be in [0, 1]")
        elif defect_type == "none":
            if graph_distance != 0.0:
                raise ValueError("intact graph distance must be zero")
        elif graph_distance != DEFECT_NORMALIZATION["unknown_graph_distance"]:
            raise ValueError("unknown graph distance must use -1")
        euclidean_distance = _finite_number(
            annotation.get("euclidean_distance_norm"),
            "node {} euclidean_distance_norm".format(row),
        )
        if euclidean_distance < 0.0 or euclidean_distance > 1.0:
            raise ValueError("normalized Euclidean distance must be in [0, 1]")
    if annotation_ids != canonical_ids:
        raise ValueError("node annotation canonical IDs do not match row mapping")

    parent_id_universe = set(canonical_ids).union(removed_ids)
    removed_pairs = _canonical_pairs(
        sidecar.get("removed_parent_pair_ids"),
        "removed parent pair IDs",
        parent_id_universe,
    )
    if defect_type != "missing_staple" and removed_pairs:
        raise ValueError("non-omission sidecar cannot remove designed pairs")
    removed_set = set(removed_ids)
    expected_lost_partners = set()
    for left, right in removed_pairs:
        if (left in removed_set) == (right in removed_set):
            raise ValueError("removed parent pair must connect one survivor and one removal")
        expected_lost_partners.add(right if left in removed_set else left)
    observed_lost_partners = {
        canonical_ids[row]
        for row, annotation in enumerate(annotations)
        if annotation["lost_designed_partner"]
    }
    if observed_lost_partners != expected_lost_partners:
        raise ValueError("lost_designed_partner does not match removed parent pair IDs")

    cut_pairs = _canonical_pairs(
        sidecar.get("cut_backbone_parent_ids"),
        "cut backbone parent IDs",
        set(canonical_ids),
    )
    if defect_type == "backbone_nick" and not cut_pairs:
        raise ValueError("backbone nick sidecar has no cut backbone relation")
    if defect_type != "backbone_nick" and cut_pairs:
        raise ValueError("only backbone nick sidecars may contain cut backbone relations")
    expected_boundaries = {node_id for pair in cut_pairs for node_id in pair}
    observed_boundaries = {
        canonical_ids[row]
        for row, annotation in enumerate(annotations)
        if annotation["nick_boundary"]
    }
    if observed_boundaries != expected_boundaries:
        raise ValueError("nick_boundary does not match cut backbone endpoints")

    if defect_type == "none":
        if plan["payload"].get("selected_site_ids") not in ([], None):
            raise ValueError("none sidecar cannot select defect sites")
        if removed_parent_nt != 0:
            raise ValueError("none sidecar cannot remove parent nucleotides")

    return sidecar


def build_defect_node_features(sample, sidecar, device=None, dtype=None):
    """Build the fixed nine-channel tensor in variant topology-row order."""

    import torch

    validate_defect_sidecar(sample, sidecar)
    if dtype is None:
        dtype = torch.float32
    defect_type = sidecar["defect_type"]
    has_defect = float(defect_type != "none")
    missing_staple = float(defect_type == "missing_staple")
    backbone_nick = float(defect_type == "backbone_nick")
    removed_parent_nt_norm = float(sidecar["removed_parent_nt"]) / float(
        max(1, sidecar["parent_num_nodes"])
    )
    rows = []
    for annotation in sidecar["node_annotations"]:
        rows.append(
            [
                has_defect,
                missing_staple,
                backbone_nick,
                float(annotation["nick_boundary"]),
                float(annotation["lost_designed_partner"]),
                float(annotation["graph_distance_norm"]),
                float(annotation["graph_distance_known"]),
                float(annotation["euclidean_distance_norm"]),
                removed_parent_nt_norm,
            ]
        )
    return torch.tensor(rows, dtype=dtype, device=device)


def build_cut_backbone_relation(sample, sidecar):
    """Return directed, non-physical edges for severed parent backbone links."""

    validate_defect_sidecar(sample, sidecar)
    canonical_to_row = {
        node_id: row
        for row, node_id in enumerate(sidecar["variant_row_to_parent_node_id"])
    }
    physical_edges = {tuple(edge) for edge in getattr(sample, "backbone_edges", [])}
    directed = []
    for left_id, right_id in sidecar["cut_backbone_parent_ids"]:
        left = canonical_to_row[left_id]
        right = canonical_to_row[right_id]
        if (left, right) in physical_edges or (right, left) in physical_edges:
            raise ValueError("cut_backbone endpoint remains an intact physical backbone edge")
        directed.extend(((left, right), (right, left)))
    edges = [list(edge) for edge in sorted(directed)]
    return {
        "relation_name": "cut_backbone",
        "edges": edges,
        "physical_loss_mask": [0 for _edge in edges],
    }


def empty_cut_backbone_relation():
    return {
        "relation_name": "cut_backbone",
        "edges": [],
        "physical_loss_mask": [],
    }


def _sample_num_nodes(sample):
    value = getattr(sample, "num_nucleotides", None)
    if value is None:
        value = getattr(sample, "num_nodes", None)
    if type(value) is not int or value <= 0:
        raise ValueError("sample has no positive node count")
    return value


def _canonical_id_list(value, label, allow_empty=False):
    if not isinstance(value, list) or (not value and not allow_empty):
        raise ValueError("{} must be a list of canonical IDs".format(label))
    if any(not isinstance(item, str) or not item for item in value):
        raise ValueError("{} contain an invalid canonical ID".format(label))
    if len(value) != len(set(value)):
        raise ValueError("{} are not unique canonical IDs".format(label))
    return list(value)


def _canonical_pairs(value, label, allowed_ids):
    if not isinstance(value, list):
        raise ValueError("{} must be a list".format(label))
    result = []
    seen = set()
    for raw_pair in value:
        if not isinstance(raw_pair, list) or len(raw_pair) != 2:
            raise ValueError("{} contain a malformed pair".format(label))
        left, right = raw_pair
        if (
            not isinstance(left, str)
            or not isinstance(right, str)
            or not left
            or not right
            or left == right
            or left not in allowed_ids
            or right not in allowed_ids
        ):
            raise ValueError("{} contain invalid canonical IDs".format(label))
        canonical = tuple(sorted((left, right)))
        if canonical in seen:
            raise ValueError("{} are not unique".format(label))
        seen.add(canonical)
        result.append((left, right))
    return result


def _require_bool(mapping, key, row):
    value = mapping.get(key)
    if type(value) is not bool:
        raise ValueError("node {} {} must be boolean".format(row, key))
    return value


def _finite_number(value, label):
    if type(value) not in (int, float) or not math.isfinite(float(value)):
        raise ValueError("{} must be finite".format(label))
    return float(value)


def _is_sha256(value):
    return isinstance(value, str) and _SHA256_RE.match(value) is not None
