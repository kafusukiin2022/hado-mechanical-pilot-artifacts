import math
from typing import Optional, Sequence

from oxdna_export.io import OxDNAConfigRow, OxDNAFrame, Vector3

from .adapter import OxDNASample


def decode_to_oxdna_frame(
    sample: OxDNASample,
    positions: Sequence[Vector3],
    a1: Sequence[Vector3],
    a3: Sequence[Vector3],
    time: Optional[str] = None,
    box: Optional[Vector3] = None,
    energy: Optional[str] = None,
) -> OxDNAFrame:
    _validate_count("positions", positions, sample.num_nucleotides)
    _validate_count("a1", a1, sample.num_nucleotides)
    _validate_count("a3", a3, sample.num_nucleotides)

    rows = []
    for idx in range(sample.num_nucleotides):
        unit_a1, unit_a3 = _orthonormalize(a1[idx], a3[idx])
        rows.append(
            OxDNAConfigRow(
                position=tuple(positions[idx]),
                a1=unit_a1,
                a3=unit_a3,
                velocity=(0.0, 0.0, 0.0),
                angular_velocity=(0.0, 0.0, 0.0),
            )
        )

    return OxDNAFrame(
        time=time if time is not None else sample.start_frame.time,
        box=box if box is not None else sample.start_frame.box,
        energy=energy if energy is not None else sample.start_frame.energy,
        rows=rows,
    )


def _validate_count(label: str, values: Sequence[Vector3], expected: int) -> None:
    if len(values) != expected:
        raise ValueError("{} has {} rows, expected {}".format(label, len(values), expected))


def _orthonormalize(a1: Vector3, a3: Vector3) -> Sequence[Vector3]:
    unit_a1 = _normalize(a1, "a1")
    projection = _dot(a3, unit_a1)
    orthogonal_a3 = tuple(value - projection * basis for value, basis in zip(a3, unit_a1))
    unit_a3 = _normalize(orthogonal_a3, "a3")
    return unit_a1, unit_a3


def _normalize(vector: Vector3, label: str) -> Vector3:
    norm = math.sqrt(_dot(vector, vector))
    if not math.isfinite(norm) or norm == 0.0:
        raise ValueError("{} must be finite and non-zero".format(label))
    return tuple(value / norm for value in vector)


def _dot(left: Vector3, right: Vector3) -> float:
    return sum(a * b for a, b in zip(left, right))
