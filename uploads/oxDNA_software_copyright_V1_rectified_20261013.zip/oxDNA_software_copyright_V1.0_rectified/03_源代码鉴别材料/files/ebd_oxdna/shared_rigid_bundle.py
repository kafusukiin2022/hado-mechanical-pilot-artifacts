import hashlib
import json
import math
import os
import copy


SCHEMA = "ebd_oxdna.shared_rigid_inference_bundle"
SCHEMA_VERSION = 3
PREPROCESSING_SCHEMA_VERSION = 2

_REQUIRED_TRAINING_FIELDS = (
    "model",
    "model_kind",
    "node_feature_dim",
    "edge_feature_dim",
    "shared_hidden_dim",
    "message_passing_steps",
    "scale_normalized_residuals",
    "dropout",
    "wc_edge_mode",
    "fourier_features",
    "design_features",
    "graph_mode",
    "graph_cutoff",
    "max_graph_neighbors",
    "include_candidate_wc_edges",
    "candidate_wc_top_k",
    "candidate_wc_cutoff",
    "physical_graph",
    "stage_samples_on_cpu",
    "start_rmsd_residual_gate_threshold",
    "start_rmsd_residual_gate_sharpness",
    "start_rmsd_residual_min_scale",
)


def build_inference_bundle(training_config, checkpoint_paths=None):
    _require_training_fields(training_config)
    if training_config["model"] != "shared_rigid_mlp_joint":
        raise ValueError("training config is not a shared_rigid_mlp_joint model")

    model_kind = training_config["model_kind"]
    model = {
        "name": "shared_rigid_mlp_joint",
        "kind": model_kind,
        "input_dim": _positive_int(training_config, "node_feature_dim"),
        "edge_feature_dim": _nonnegative_int(training_config, "edge_feature_dim"),
        "hidden_dim": _positive_int(training_config, "shared_hidden_dim"),
        "message_passing_steps": _nonnegative_int(
            training_config,
            "message_passing_steps",
        ),
        "scale_normalized_residuals": _bool_value(
            training_config,
            "scale_normalized_residuals",
        ),
        "dropout": _finite_float(training_config, "dropout"),
        "wc_edge_mode": training_config["wc_edge_mode"],
    }
    design_edge_index = training_config.get("design_edge_sidecars")
    uses_design_edges = bool(design_edge_index)
    require_explicit_design_edges = _optional_bool_value(
        training_config, "require_explicit_design_edges", False
    )
    edge_family_pair = _optional_bool_value(
        training_config, "edge_family_pair", False
    )
    edge_family_crossover = _optional_bool_value(
        training_config, "edge_family_crossover", False
    )
    edge_family_duplex_step = _optional_bool_value(
        training_config, "edge_family_duplex_step", False
    )
    edge_family_start_spatial = _optional_bool_value(
        training_config, "edge_family_start_spatial", False
    )
    if (
        require_explicit_design_edges
        or edge_family_pair
        or edge_family_crossover
        or edge_family_duplex_step
        or edge_family_start_spatial
    ) and not uses_design_edges:
        raise ValueError("design-edge flags require design_edge_sidecars provenance")
    sidecar_index_sha256 = training_config.get("design_edge_sidecars_sha256")
    if uses_design_edges:
        _validate_sha256(sidecar_index_sha256, "design-edge sidecar index")
    elif sidecar_index_sha256 is not None:
        raise ValueError("design_edge_sidecars_sha256 requires design_edge_sidecars")

    preprocessing = {
        "schema_version": PREPROCESSING_SCHEMA_VERSION,
        "fourier_features": _nonnegative_int(training_config, "fourier_features"),
        "design_features": training_config["design_features"],
        "graph_mode": training_config["graph_mode"],
        "graph_cutoff": _finite_float(training_config, "graph_cutoff"),
        "max_graph_neighbors": _positive_int(
            training_config,
            "max_graph_neighbors",
        ),
        "include_candidate_wc_edges": _bool_value(
            training_config,
            "include_candidate_wc_edges",
        ),
        "candidate_wc_top_k": _nonnegative_int(
            training_config,
            "candidate_wc_top_k",
        ),
        "candidate_wc_cutoff": _finite_float(
            training_config,
            "candidate_wc_cutoff",
        ),
        "physical_graph": _bool_value(training_config, "physical_graph"),
        "stage_samples_on_cpu": _bool_value(
            training_config,
            "stage_samples_on_cpu",
        ),
        "uses_design_edges": uses_design_edges,
        "require_explicit_design_edges": require_explicit_design_edges,
        "edge_family_pair": edge_family_pair,
        "edge_family_crossover": edge_family_crossover,
        "edge_family_duplex_step": edge_family_duplex_step,
        "edge_family_start_spatial": edge_family_start_spatial,
        "design_edge_schema_version": 1 if uses_design_edges else None,
        "training_sidecar_index": (
            os.path.abspath(design_edge_index) if uses_design_edges else None
        ),
        "training_sidecar_index_sha256": (
            sidecar_index_sha256 if uses_design_edges else None
        ),
    }
    residual_gate = {
        "threshold": _finite_float(
            training_config,
            "start_rmsd_residual_gate_threshold",
        ),
        "sharpness": _finite_float(
            training_config,
            "start_rmsd_residual_gate_sharpness",
        ),
        "min_scale": _finite_float(
            training_config,
            "start_rmsd_residual_min_scale",
        ),
    }
    incompatibilities = _target_free_incompatibilities(
        model_kind,
        preprocessing,
        residual_gate,
    )

    if checkpoint_paths is None:
        checkpoint_paths = {
            "final": training_config.get("save_model_state"),
            "best": training_config.get("save_best_model_state"),
        }
    checkpoints = {}
    checkpoint_hashes = {}
    for key, value in checkpoint_paths.items():
        if not value:
            continue
        absolute_path = os.path.abspath(value)
        if not os.path.isfile(absolute_path):
            raise ValueError("checkpoint does not exist: {}".format(absolute_path))
        checkpoints[key] = absolute_path
        checkpoint_hashes[key] = sha256_file(absolute_path)

    bundle = {
        "schema": SCHEMA,
        "schema_version": SCHEMA_VERSION,
        "model": model,
        "preprocessing": preprocessing,
        "residual_gate": residual_gate,
        "feature_schema": {
            "node_feature_names": list(
                training_config.get("node_feature_names") or []
            ),
            "edge_feature_names": list(
                training_config.get("edge_feature_names") or []
            ),
            "edge_relation_names": list(
                training_config.get("edge_relation_names") or ["default"]
            ),
        },
        "checkpoint_paths": checkpoints,
        "checkpoint_sha256": checkpoint_hashes,
        "target_free": {
            "compatible": not incompatibilities,
            "incompatibilities": incompatibilities,
        },
    }
    _validate_bundle(bundle)
    return bundle


def load_inference_bundle(
    path,
    legacy_checkpoint_path=None,
    expected_checkpoint_sha256=None,
):
    with open(path) as handle:
        payload = json.load(handle)
    if payload.get("schema") == SCHEMA:
        if payload.get("schema_version") == 2:
            payload = _migrate_schema_v2_bundle(payload)
        _validate_bundle(payload)
        return payload

    _require_training_fields(payload)
    if expected_checkpoint_sha256 is None:
        raise ValueError(
            "legacy schema-less summary requires an independently supplied "
            "expected checkpoint SHA-256; pass --checkpoint-sha256"
        )
    if legacy_checkpoint_path is None:
        raise ValueError("legacy schema-less summary requires a checkpoint path")
    _validate_sha256(expected_checkpoint_sha256, "legacy checkpoint")

    bundle = build_inference_bundle(payload, checkpoint_paths={})
    bundle["checkpoint_paths"] = {
        "legacy": os.path.abspath(legacy_checkpoint_path),
    }
    bundle["checkpoint_sha256"] = {
        "legacy": expected_checkpoint_sha256,
    }
    _validate_bundle(bundle)
    return bundle


def write_inference_bundle(bundle, path):
    _validate_bundle(bundle)
    absolute_path = os.path.abspath(path)
    parent = os.path.dirname(absolute_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(absolute_path, "w") as handle:
        json.dump(bundle, handle, indent=2, sort_keys=True)
        handle.write("\n")
    return absolute_path


def require_target_free_compatible(bundle):
    if bundle.get("schema") == SCHEMA and bundle.get("schema_version") == 2:
        bundle = _migrate_schema_v2_bundle(bundle)
    _validate_bundle(bundle)
    incompatibilities = _target_free_incompatibilities(
        bundle["model"]["kind"],
        bundle["preprocessing"],
        bundle["residual_gate"],
    )
    if incompatibilities:
        raise ValueError(
            "checkpoint configuration is not target-free compatible: {}".format(
                "; ".join(incompatibilities)
            )
        )


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _target_free_incompatibilities(model_kind, preprocessing, residual_gate):
    reasons = []
    if preprocessing["include_candidate_wc_edges"]:
        reasons.append("candidate WC edges are target-derived in the training preprocessor")
    if preprocessing["physical_graph"] or model_kind == "dgnn-physic":
        reasons.append("physical graph construction uses target or final pair geometry")
    if residual_gate["threshold"] > 0.0:
        reasons.append("start-RMSD residual gate requires target coordinates")
    return reasons


def _migrate_schema_v2_bundle(bundle):
    migrated = copy.deepcopy(bundle)
    migrated["schema_version"] = SCHEMA_VERSION
    preprocessing = migrated.get("preprocessing")
    if not isinstance(preprocessing, dict):
        raise ValueError("inference bundle is missing preprocessing")
    preprocessing["schema_version"] = PREPROCESSING_SCHEMA_VERSION
    preprocessing.update(
        {
            "uses_design_edges": False,
            "require_explicit_design_edges": False,
            "edge_family_pair": False,
            "edge_family_crossover": False,
            "edge_family_duplex_step": False,
            "edge_family_start_spatial": False,
            "design_edge_schema_version": None,
            "training_sidecar_index": None,
            "training_sidecar_index_sha256": None,
        }
    )
    return migrated


def _validate_bundle(bundle):
    if bundle.get("schema") != SCHEMA:
        raise ValueError("unsupported inference bundle schema")
    schema_version = bundle.get("schema_version")
    if type(schema_version) is not int or schema_version != SCHEMA_VERSION:
        raise ValueError(
            "unsupported inference bundle version {!r}".format(
                schema_version
            )
        )
    for key in (
        "model",
        "preprocessing",
        "residual_gate",
        "target_free",
        "checkpoint_paths",
        "checkpoint_sha256",
    ):
        if not isinstance(bundle.get(key), dict):
            raise ValueError("inference bundle is missing {}".format(key))

    model = bundle["model"]
    preprocessing = bundle["preprocessing"]
    residual_gate = bundle["residual_gate"]
    if model.get("name") != "shared_rigid_mlp_joint":
        raise ValueError("model name must be shared_rigid_mlp_joint")
    if model.get("kind") not in (
        "shared-mlp",
        "graph-shared",
        "dgnn-lite",
        "dgnn-physic",
    ):
        raise ValueError("unsupported model kind {!r}".format(model.get("kind")))
    _positive_int(model, "input_dim")
    _nonnegative_int(model, "edge_feature_dim")
    _positive_int(model, "hidden_dim")
    _nonnegative_int(model, "message_passing_steps")
    _bool_value(model, "scale_normalized_residuals")
    dropout = _finite_float(model, "dropout")
    if dropout < 0.0 or dropout >= 1.0:
        raise ValueError("dropout must be in [0, 1)")
    if model.get("wc_edge_mode") not in (
        "message_all",
        "readout_only",
        "last_layer",
    ):
        raise ValueError("unsupported wc_edge_mode {!r}".format(model.get("wc_edge_mode")))

    preprocessing_schema_version = preprocessing.get("schema_version")
    if (
        type(preprocessing_schema_version) is not int
        or preprocessing_schema_version != PREPROCESSING_SCHEMA_VERSION
    ):
        raise ValueError("unsupported preprocessing schema_version")
    _nonnegative_int(preprocessing, "fourier_features")
    if preprocessing.get("design_features") not in ("none", "stats"):
        raise ValueError("unsupported design_features")
    if preprocessing.get("graph_mode") not in ("backbone", "cutoff"):
        raise ValueError("unsupported graph_mode")
    if _finite_float(preprocessing, "graph_cutoff") < 0.0:
        raise ValueError("graph_cutoff must be non-negative")
    _positive_int(preprocessing, "max_graph_neighbors")
    _bool_value(preprocessing, "include_candidate_wc_edges")
    _nonnegative_int(preprocessing, "candidate_wc_top_k")
    if _finite_float(preprocessing, "candidate_wc_cutoff") < 0.0:
        raise ValueError("candidate_wc_cutoff must be non-negative")
    _bool_value(preprocessing, "physical_graph")
    _bool_value(preprocessing, "stage_samples_on_cpu")
    uses_design_edges = _bool_value(preprocessing, "uses_design_edges")
    require_explicit_design_edges = _bool_value(
        preprocessing, "require_explicit_design_edges"
    )
    edge_flags = [
        _bool_value(preprocessing, "edge_family_pair"),
        _bool_value(preprocessing, "edge_family_crossover"),
        _bool_value(preprocessing, "edge_family_duplex_step"),
        _bool_value(preprocessing, "edge_family_start_spatial"),
    ]
    if uses_design_edges:
        if preprocessing.get("design_edge_schema_version") != 1:
            raise ValueError("unsupported design_edge_schema_version")
        if not isinstance(preprocessing.get("training_sidecar_index"), str):
            raise ValueError("training_sidecar_index must be a path string")
        _validate_sha256(
            preprocessing.get("training_sidecar_index_sha256"),
            "design-edge sidecar index",
        )
        if preprocessing.get("graph_mode") != "backbone" or preprocessing.get("graph_cutoff") != 0.0:
            raise ValueError("typed design edges require a backbone-only legacy graph")
        if preprocessing.get("include_candidate_wc_edges") or preprocessing.get("candidate_wc_top_k") != 0:
            raise ValueError("typed design edges cannot use target-derived candidate WC edges")
        if preprocessing.get("physical_graph"):
            raise ValueError("typed design edges cannot use the legacy physical graph")
    else:
        if require_explicit_design_edges or any(edge_flags):
            raise ValueError("design-edge flags require uses_design_edges")
        for key in (
            "design_edge_schema_version",
            "training_sidecar_index",
            "training_sidecar_index_sha256",
        ):
            if preprocessing.get(key) is not None:
                raise ValueError("{} must be null without design edges".format(key))

    threshold = _finite_float(residual_gate, "threshold")
    sharpness = _finite_float(residual_gate, "sharpness")
    min_scale = _finite_float(residual_gate, "min_scale")
    if threshold < 0.0:
        raise ValueError("residual gate threshold must be non-negative")
    if sharpness <= 0.0:
        raise ValueError("residual gate sharpness must be positive")
    if min_scale < 0.0 or min_scale > 1.0:
        raise ValueError("residual gate min_scale must be in [0, 1]")

    computed = _target_free_incompatibilities(
        model["kind"],
        preprocessing,
        residual_gate,
    )
    target_free = bundle["target_free"]
    if type(target_free.get("compatible")) is not bool:
        raise ValueError("target_free compatible must be boolean")
    stored = target_free.get("incompatibilities")
    if not isinstance(stored, list) or stored != computed or target_free["compatible"] != (not computed):
        raise ValueError("target_free metadata does not match bundle settings")

    paths = bundle["checkpoint_paths"]
    hashes = bundle["checkpoint_sha256"]
    if set(paths) != set(hashes):
        raise ValueError("checkpoint paths and SHA-256 metadata do not match")
    for key, digest in hashes.items():
        if not isinstance(paths[key], str) or not isinstance(digest, str):
            raise ValueError("checkpoint metadata must contain strings")
        _validate_sha256(digest, key)


def _require_training_fields(mapping):
    missing = [key for key in _REQUIRED_TRAINING_FIELDS if key not in mapping]
    if missing:
        raise ValueError(
            "training summary is missing inference settings: {}".format(
                ", ".join(missing)
            )
        )


def _positive_int(mapping, key):
    value = _integer_value(mapping, key)
    if value <= 0:
        raise ValueError("{} must be a positive integer".format(key))
    return value


def _nonnegative_int(mapping, key):
    value = _integer_value(mapping, key)
    if value < 0:
        raise ValueError("{} must be a non-negative integer".format(key))
    return value


def _integer_value(mapping, key):
    if key not in mapping or type(mapping[key]) is not int:
        raise ValueError("{} must be an integer".format(key))
    return mapping[key]


def _finite_float(mapping, key):
    if key not in mapping or type(mapping[key]) is not float:
        raise ValueError("{} must be a finite float".format(key))
    value = mapping[key]
    if not math.isfinite(value):
        raise ValueError("{} must be a finite float".format(key))
    return value


def _bool_value(mapping, key):
    if key not in mapping or type(mapping[key]) is not bool:
        raise ValueError("{} must be boolean".format(key))
    return mapping[key]


def _optional_bool_value(mapping, key, default):
    if key not in mapping:
        return bool(default)
    return _bool_value(mapping, key)


def _validate_sha256(value, label):
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(ch not in "0123456789abcdef" for ch in value)
    ):
        raise ValueError("invalid checkpoint SHA-256 for {}".format(label))
