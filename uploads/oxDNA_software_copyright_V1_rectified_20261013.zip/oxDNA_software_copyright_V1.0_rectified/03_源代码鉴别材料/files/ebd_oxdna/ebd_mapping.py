from __future__ import division

import math

from .adapter import OxDNASample


BASE_TO_ATOM_TYPE = {
    "A": 1,
    "C": 2,
    "G": 3,
    "T": 4,
    "U": 4,
}

BACKBONE_EDGE_TYPE = 1
SAME_STRAND_SPATIAL_EDGE_TYPE = 2
CROSS_STRAND_SPATIAL_EDGE_TYPE = 3
ORIENTATION_EDGE_TYPE = 4
FRAGMENT_EDGE_TYPE = 1


def build_egnn_forward_inputs(
    sample: OxDNASample,
    device=None,
    atom_cutoff=6.0,
    max_spatial_neighbors=48,
    orientation_cutoff=8.0,
    max_orientation_neighbors=8,
    fragment_graph_mode="complete",
):
    try:
        import torch
    except ImportError:
        raise ImportError("build_egnn_forward_inputs requires torch")
    try:
        from scipy.spatial import cKDTree
    except ImportError:
        cKDTree = None

    kwargs = {}
    if device is not None:
        kwargs["device"] = device

    x_a = torch.tensor(_rows(sample.positions), dtype=torch.float32, **kwargs)
    target_x_a = None
    if sample.target_positions is not None:
        target_x_a = torch.tensor(_rows(sample.target_positions), dtype=torch.float32, **kwargs)
    a_type = torch.tensor(
        [BASE_TO_ATOM_TYPE.get(row.base.upper(), 0) for row in sample.topology.rows],
        dtype=torch.long,
        **kwargs
    )
    atom_edges = _build_atom_edges(
        sample,
        atom_cutoff=atom_cutoff,
        max_spatial_neighbors=max_spatial_neighbors,
        orientation_cutoff=orientation_cutoff,
        max_orientation_neighbors=max_orientation_neighbors,
        cKDTree=cKDTree,
    )
    e_a_idx = torch.tensor(_edge_index([(src, dst) for src, dst, _edge_type in atom_edges]), dtype=torch.long, **kwargs)
    e_a_type = torch.tensor([edge_type for _src, _dst, edge_type in atom_edges], dtype=torch.long, **kwargs)

    strand_ids = _ordered_strand_ids(sample)
    strand_to_frag = {strand_id: idx for idx, strand_id in enumerate(strand_ids)}
    num_frags = len(strand_ids)
    m_mat_dense = torch.zeros((num_frags, sample.num_nucleotides), dtype=torch.float32, **kwargs)
    for nucleotide_idx, row in enumerate(sample.topology.rows):
        m_mat_dense[strand_to_frag[row.strand_id], nucleotide_idx] = 1.0
    bm_mat_dense = m_mat_dense.t().contiguous()

    counts = m_mat_dense.sum(dim=1).clamp(min=1.0).view(-1, 1)
    x_f = (m_mat_dense @ x_a) / counts
    h_f = _fragment_features(torch, sample, strand_ids, m_mat_dense, **kwargs)
    e_f_idx = torch.tensor(
        _build_fragment_edges(sample, strand_ids, x_f, fragment_graph_mode),
        dtype=torch.long,
        **kwargs
    )
    m_mat = m_mat_dense.to_sparse()
    bm_mat = bm_mat_dense.to_sparse()

    return {
        "t": torch.tensor([0.0], dtype=torch.float32, **kwargs),
        "a_type": a_type,
        "x_a": x_a,
        "target_x_a": target_x_a,
        "e_a_idx": e_a_idx,
        "e_a_type": e_a_type,
        "x_f": x_f,
        "h_f": h_f,
        "e_f_idx": e_f_idx,
        "m_mat": m_mat,
        "bm_mat": bm_mat,
        "m_mat_dense": m_mat_dense,
        "bm_mat_dense": bm_mat_dense,
        "num_atoms": torch.tensor([sample.num_nucleotides], dtype=torch.long, **kwargs),
        "num_frags": torch.tensor([num_frags], dtype=torch.long, **kwargs),
        "edge_type_histogram": _edge_type_histogram(torch, atom_edges),
    }


def _rows(rows):
    return [list(row) for row in rows]


def _edge_index(edges):
    if not edges:
        return [[], []]
    return [[edge[0] for edge in edges], [edge[1] for edge in edges]]


def _ordered_strand_ids(sample):
    strand_ids = []
    seen = set()
    for row in sample.topology.rows:
        if row.strand_id not in seen:
            strand_ids.append(row.strand_id)
            seen.add(row.strand_id)
    return strand_ids


def _fragment_features(torch, sample, strand_ids, m_mat, **kwargs):
    features = torch.zeros((len(strand_ids), 3), dtype=torch.float32, **kwargs)
    for frag_idx, strand_id in enumerate(strand_ids):
        strand_rows = [row for row in sample.topology.rows if row.strand_id == strand_id]
        bases = [row.base.upper() for row in strand_rows]
        count = float(len(bases)) or 1.0
        gc_count = sum(1 for base in bases if base in ("G", "C"))
        positions = [sample.positions[idx] for idx, row in enumerate(sample.topology.rows) if row.strand_id == strand_id]
        span = _strand_span(positions)
        features[frag_idx, 0] = count
        features[frag_idx, 1] = gc_count / count
        features[frag_idx, 2] = span
    return features


def _fully_connected_edges(num_nodes):
    rows = []
    cols = []
    for src in range(num_nodes):
        for dst in range(num_nodes):
            if src == dst:
                continue
            rows.append(src)
            cols.append(dst)
    return [rows, cols]


def _build_fragment_edges(sample, strand_ids, x_f, fragment_graph_mode):
    num_frags = len(strand_ids)
    if fragment_graph_mode == "complete":
        return _fully_connected_edges(num_frags)
    if fragment_graph_mode != "distance":
        raise ValueError("Unsupported fragment_graph_mode: {}".format(fragment_graph_mode))

    rows = []
    cols = []
    centers = x_f.detach().cpu().tolist()
    for src in range(num_frags):
        distances = []
        for dst in range(num_frags):
            if src == dst:
                continue
            distances.append((_squared_distance(centers[src], centers[dst]), dst))
        distances.sort(key=lambda item: item[0])
        for _distance, dst in distances[: min(16, len(distances))]:
            rows.append(src)
            cols.append(dst)
    return [rows, cols]


def _build_atom_edges(
    sample,
    atom_cutoff,
    max_spatial_neighbors,
    orientation_cutoff,
    max_orientation_neighbors,
    cKDTree,
):
    edges = []
    seen = set()
    strand_ids = [row.strand_id for row in sample.topology.rows]
    positions = _rows(sample.positions)
    a1_vectors = _rows(sample.a1)
    a3_vectors = _rows(sample.a3)

    for src, dst in sample.backbone_edges:
        _append_edge(edges, seen, src, dst, BACKBONE_EDGE_TYPE)

    if cKDTree is not None and atom_cutoff is not None and atom_cutoff > 0:
        tree = cKDTree(positions)
        for src, neighbors in enumerate(tree.query_ball_point(positions, r=atom_cutoff)):
            ranked = []
            for dst in neighbors:
                if dst == src:
                    continue
                ranked.append((_squared_distance(positions[src], positions[dst]), dst))
            ranked.sort(key=lambda item: item[0])
            for _distance, dst in ranked[: max_spatial_neighbors]:
                if (src, dst) in seen:
                    continue
                if strand_ids[src] == strand_ids[dst]:
                    edge_type = SAME_STRAND_SPATIAL_EDGE_TYPE
                else:
                    edge_type = CROSS_STRAND_SPATIAL_EDGE_TYPE
                _append_edge(edges, seen, src, dst, edge_type)

    if cKDTree is not None and orientation_cutoff is not None and orientation_cutoff > 0:
        tree = cKDTree(positions)
        for src, neighbors in enumerate(tree.query_ball_point(positions, r=orientation_cutoff)):
            ranked = []
            for dst in neighbors:
                if dst == src:
                    continue
                if strand_ids[src] == strand_ids[dst]:
                    continue
                alignment = _orientation_alignment(a1_vectors[src], a3_vectors[src], a1_vectors[dst], a3_vectors[dst])
                ranked.append((-alignment, _squared_distance(positions[src], positions[dst]), dst))
            ranked.sort(key=lambda item: (item[0], item[1]))
            for _neg_alignment, _distance, dst in ranked[: max_orientation_neighbors]:
                if (src, dst) in seen:
                    continue
                _append_edge(edges, seen, src, dst, ORIENTATION_EDGE_TYPE)

    return edges


def _append_edge(edges, seen, src, dst, edge_type):
    key = (src, dst)
    if key in seen:
        return
    seen.add(key)
    edges.append((src, dst, edge_type))


def _edge_type_histogram(torch, atom_edges):
    counts = {}
    for _src, _dst, edge_type in atom_edges:
        counts[edge_type] = counts.get(edge_type, 0) + 1
    keys = sorted(counts)
    values = [counts[key] for key in keys]
    return {
        "edge_types": torch.tensor(keys, dtype=torch.long),
        "counts": torch.tensor(values, dtype=torch.long),
    }


def _squared_distance(lhs, rhs):
    return sum((lhs[i] - rhs[i]) * (lhs[i] - rhs[i]) for i in range(3))


def _orientation_alignment(a1_src, a3_src, a1_dst, a3_dst):
    return abs(_dot(a1_src, a1_dst)) + abs(_dot(a3_src, a3_dst))


def _dot(lhs, rhs):
    return lhs[0] * rhs[0] + lhs[1] * rhs[1] + lhs[2] * rhs[2]


def _strand_span(positions):
    if len(positions) < 2:
        return 0.0
    max_distance = 0.0
    for i in range(len(positions)):
        for j in range(i + 1, len(positions)):
            max_distance = max(max_distance, _squared_distance(positions[i], positions[j]))
    return math.sqrt(max_distance)
