"""Manifest-facing loader for optional target-free defect sidecars."""

import hashlib
import json
import os

from ebd_oxdna.defect_features import build_cut_backbone_relation
from ebd_oxdna.defect_features import build_defect_node_features
from ebd_oxdna.defect_features import empty_cut_backbone_relation
from ebd_oxdna.defect_features import validate_defect_sidecar


_STATIC_SOURCE_KEYS = (
    "topology_sha256",
    "initial_configuration_sha256",
    "canonical_map_sha256",
)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_optional_defect_features(sample, manifest_entry, device=None, dtype=None):
    """Load a validated defect block or return the exact legacy zero block."""

    import torch

    sidecar = _load_optional_sidecar(sample, manifest_entry)
    if sidecar is None:
        num_nodes = getattr(sample, "num_nucleotides", None)
        if num_nodes is None:
            num_nodes = getattr(sample, "num_nodes", None)
        return torch.zeros((num_nodes, 9), dtype=dtype or torch.float32, device=device)
    return build_defect_node_features(sample, sidecar, device=device, dtype=dtype)


def load_optional_cut_backbone_relation(sample, manifest_entry):
    sidecar = _load_optional_sidecar(sample, manifest_entry)
    if sidecar is None:
        return empty_cut_backbone_relation()
    return build_cut_backbone_relation(sample, sidecar)


def load_optional_defect_contract(sample, manifest_entry, device=None, dtype=None):
    """Load node features and cut relation from one checksum-bound sidecar."""

    import torch

    sidecar = _load_optional_sidecar(sample, manifest_entry)
    if sidecar is None:
        num_nodes = getattr(sample, "num_nucleotides", None)
        if num_nodes is None:
            num_nodes = getattr(sample, "num_nodes", None)
        return {
            "features": torch.zeros(
                (num_nodes, 9), dtype=dtype or torch.float32, device=device
            ),
            "cut_backbone": empty_cut_backbone_relation(),
            "sidecar": None,
        }
    return {
        "features": build_defect_node_features(
            sample, sidecar, device=device, dtype=dtype
        ),
        "cut_backbone": build_cut_backbone_relation(sample, sidecar),
        "sidecar": sidecar,
    }


def _load_optional_sidecar(sample, manifest_entry):
    if not isinstance(manifest_entry, dict):
        raise ValueError("manifest entry must be an object")
    sidecar_reference = manifest_entry.get("defect_sidecar")
    if not sidecar_reference:
        return None
    if isinstance(sidecar_reference, dict):
        sidecar = sidecar_reference
        actual_hash = _canonical_object_sha256(sidecar)
    elif isinstance(sidecar_reference, str):
        path = os.path.abspath(sidecar_reference)
        try:
            with open(path, "r") as handle:
                sidecar = json.load(handle)
        except (OSError, ValueError) as exc:
            raise ValueError("cannot load defect sidecar {}: {}".format(path, exc))
        actual_hash = file_sha256(path)
    else:
        raise ValueError("defect_sidecar must be a path or object")

    expected_hash = manifest_entry.get("defect_sidecar_sha256")
    if not isinstance(expected_hash, str) or actual_hash != expected_hash:
        raise ValueError("defect sidecar hash does not match manifest provenance")
    validate_defect_sidecar(sample, sidecar)

    if manifest_entry.get("parent_id") != sidecar["parent_id"]:
        raise ValueError("defect sidecar parent_id does not match manifest")
    if manifest_entry.get("plan_sha256") != sidecar["plan"]["sha256"]:
        raise ValueError("defect sidecar plan hash does not match manifest")
    static_inputs = manifest_entry.get("static_graph_inputs")
    if not isinstance(static_inputs, dict):
        raise ValueError("manifest has no static source hash provenance")
    for key in _STATIC_SOURCE_KEYS:
        if static_inputs.get(key) != sidecar["source_hashes"].get(key):
            raise ValueError("defect sidecar source hash {} does not match manifest".format(key))

    _validate_file_source_hash(
        manifest_entry.get("top"),
        sidecar["source_hashes"]["topology_sha256"],
        "topology",
    )
    _validate_file_source_hash(
        manifest_entry.get("start"),
        sidecar["source_hashes"]["initial_configuration_sha256"],
        "initial configuration",
    )
    _validate_file_source_hash(
        manifest_entry.get("canonical_map"),
        sidecar["source_hashes"]["canonical_map_sha256"],
        "canonical map",
    )
    return sidecar


def _validate_file_source_hash(path, expected_hash, label):
    if not path:
        return
    if file_sha256(path) != expected_hash:
        raise ValueError("{} source hash does not match defect sidecar".format(label))


def _canonical_object_sha256(value):
    try:
        payload = json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("ascii")
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise ValueError("defect sidecar is not canonical JSON: {}".format(exc))
    return hashlib.sha256(payload).hexdigest()
