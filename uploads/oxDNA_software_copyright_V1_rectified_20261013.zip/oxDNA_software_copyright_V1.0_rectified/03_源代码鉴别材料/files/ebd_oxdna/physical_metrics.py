from dataclasses import asdict, dataclass
from typing import Dict, List, Optional, Sequence, Tuple


Pair = Tuple[int, int]
Step = Tuple[Pair, Pair]


_COMPLEMENT = {
    "A": "T",
    "T": "A",
    "C": "G",
    "G": "C",
}


@dataclass(frozen=True)
class WCPhysicalMetrics:
    reference_pair_count: int
    predicted_geometric_pair_count: int
    predicted_wc_pair_count: int
    predicted_wc_complementarity: float
    predicted_wc_occupancy: float
    predicted_wc_conflict_rate: float
    predicted_wc_precision: float
    predicted_wc_recall: float
    predicted_wc_f1: float
    reference_pair_distance_mean: Optional[float]
    predicted_reference_pair_distance_mean: Optional[float]
    reference_pair_distance_rms_error: Optional[float]
    helix_step_count: int
    helix_step_distance_mean: Optional[float]
    predicted_helix_step_distance_mean: Optional[float]
    helix_step_distance_mae: Optional[float]
    helix_step_axis_score: Optional[float]
    duplex_step_retention: Optional[float]
    wc_helix_rule_score: Optional[float]

    def to_dict(self) -> Dict[str, Optional[float]]:
        return asdict(self)


def compute_wc_helix_metrics(
    torch,
    sample,
    pred_positions,
    pred_a1,
    pred_a3,
    target_positions=None,
    pair_cutoff=4.0,
    reference_pairs=None,
    helix_steps=None,
):
    del pred_a1, pred_a3
    reference_positions = target_positions if target_positions is not None else pred_positions
    if reference_pairs is None:
        reference_pairs = _greedy_pair_matching(torch, sample, reference_positions, pair_cutoff, complementary_only=True)
    predicted_pairs_all = _greedy_pair_matching(torch, sample, pred_positions, pair_cutoff, complementary_only=False)
    predicted_pairs_wc = [pair for pair in predicted_pairs_all if _is_complementary(sample, pair)]

    reference_pair_set = set(reference_pairs)
    predicted_wc_set = set(predicted_pairs_wc)
    matched_pairs = reference_pair_set & predicted_wc_set

    candidate_partners = _candidate_partner_lists(torch, sample, pred_positions, pair_cutoff)
    total_reference_nucleotides = max(1, 2 * len(reference_pairs))
    conflicting_nodes = sum(1 for partners in candidate_partners.values() if len(partners) > 1)
    predicted_geometric_pair_count = len(predicted_pairs_all)
    predicted_wc_pair_count = len(predicted_pairs_wc)
    complementarity = (
        float(predicted_wc_pair_count) / float(predicted_geometric_pair_count)
        if predicted_geometric_pair_count > 0
        else 0.0
    )
    occupancy = min(1.0, float(2 * predicted_wc_pair_count) / float(total_reference_nucleotides))
    conflict_rate = float(conflicting_nodes) / float(max(1, sample.num_nucleotides))
    precision = (
        float(len(matched_pairs)) / float(predicted_wc_pair_count)
        if predicted_wc_pair_count > 0
        else 0.0
    )
    recall = (
        float(len(matched_pairs)) / float(len(reference_pairs))
        if reference_pairs
        else 0.0
    )
    f1 = (
        2.0 * precision * recall / (precision + recall)
        if (precision + recall) > 0
        else 0.0
    )

    reference_pair_distance_mean = _pair_distance_mean(torch, reference_pairs, reference_positions)
    predicted_reference_pair_distance_mean = _pair_distance_mean(torch, reference_pairs, pred_positions)
    reference_pair_distance_rms_error = _pair_distance_rms_error(
        torch,
        reference_pairs,
        reference_positions,
        pred_positions,
    )

    if helix_steps is None:
        helix_steps = _build_duplex_steps(sample, reference_pairs)
    helix_step_distance_mean = _step_distance_mean(torch, helix_steps, reference_positions)
    predicted_helix_step_distance_mean = _step_distance_mean(torch, helix_steps, pred_positions)
    helix_step_distance_mae = _step_distance_mae(torch, helix_steps, reference_positions, pred_positions)
    helix_step_axis_score = _step_axis_score(torch, helix_steps, reference_positions, pred_positions)
    duplex_step_retention = _duplex_step_retention(
        torch,
        helix_steps,
        reference_positions,
        pred_positions,
    )
    rule_score = _rule_score(
        precision=precision,
        recall=recall,
        complementarity=complementarity,
        occupancy=occupancy,
        pair_distance_rms_error=reference_pair_distance_rms_error,
        reference_pair_distance_mean=reference_pair_distance_mean,
        helix_step_distance_mae=helix_step_distance_mae,
        helix_step_distance_mean=helix_step_distance_mean,
        helix_step_axis_score=helix_step_axis_score,
    )

    return WCPhysicalMetrics(
        reference_pair_count=len(reference_pairs),
        predicted_geometric_pair_count=predicted_geometric_pair_count,
        predicted_wc_pair_count=predicted_wc_pair_count,
        predicted_wc_complementarity=complementarity,
        predicted_wc_occupancy=occupancy,
        predicted_wc_conflict_rate=conflict_rate,
        predicted_wc_precision=precision,
        predicted_wc_recall=recall,
        predicted_wc_f1=f1,
        reference_pair_distance_mean=reference_pair_distance_mean,
        predicted_reference_pair_distance_mean=predicted_reference_pair_distance_mean,
        reference_pair_distance_rms_error=reference_pair_distance_rms_error,
        helix_step_count=len(helix_steps),
        helix_step_distance_mean=helix_step_distance_mean,
        predicted_helix_step_distance_mean=predicted_helix_step_distance_mean,
        helix_step_distance_mae=helix_step_distance_mae,
        helix_step_axis_score=helix_step_axis_score,
        duplex_step_retention=duplex_step_retention,
        wc_helix_rule_score=rule_score,
    )


def build_reference_duplex_geometry(torch, sample, target_positions, pair_cutoff=4.0):
    reference_pairs = _greedy_pair_matching(torch, sample, target_positions, pair_cutoff, complementary_only=True)
    helix_steps = _build_duplex_steps(sample, reference_pairs)
    return {
        "reference_pairs": reference_pairs,
        "helix_steps": helix_steps,
    }


def reference_pair_distance_loss(torch, pred_positions, target_positions, reference_pairs):
    pair_index = _pair_index_tensor(torch, reference_pairs, pred_positions.device)
    if pair_index is None:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    pred_delta = pred_positions[pair_index[:, 0]] - pred_positions[pair_index[:, 1]]
    target_delta = target_positions[pair_index[:, 0]] - target_positions[pair_index[:, 1]]
    pred_distance = torch.norm(pred_delta, p=2, dim=1)
    target_distance = torch.norm(target_delta, p=2, dim=1)
    return torch.mean((pred_distance - target_distance) ** 2)


def reference_pair_center_loss(torch, pred_positions, target_positions, reference_pairs):
    pair_index = _pair_index_tensor(torch, reference_pairs, pred_positions.device)
    if pair_index is None:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    pred_center = 0.5 * (pred_positions[pair_index[:, 0]] + pred_positions[pair_index[:, 1]])
    target_center = 0.5 * (target_positions[pair_index[:, 0]] + target_positions[pair_index[:, 1]])
    return torch.mean(torch.sum((pred_center - target_center) ** 2, dim=1))


def reference_pair_axis_loss(torch, pred_positions, target_positions, reference_pairs, eps=1e-8):
    pair_index = _pair_index_tensor(torch, reference_pairs, pred_positions.device)
    if pair_index is None:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    pred_axis = pred_positions[pair_index[:, 1]] - pred_positions[pair_index[:, 0]]
    target_axis = target_positions[pair_index[:, 1]] - target_positions[pair_index[:, 0]]
    pred_axis = pred_axis / torch.norm(pred_axis, p=2, dim=1, keepdim=True).clamp(min=eps)
    target_axis = target_axis / torch.norm(target_axis, p=2, dim=1, keepdim=True).clamp(min=eps)
    return torch.mean(1.0 - torch.sum(pred_axis * target_axis, dim=1))


def reference_pair_frame_loss(
    torch,
    pred_positions,
    pred_a1,
    pred_a3,
    target_positions,
    target_a1,
    target_a3,
    reference_pairs,
    eps=1e-8,
):
    if not reference_pairs:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    losses = []
    for src, dst in reference_pairs:
        pred_center = _pair_center_tensor((src, dst), pred_positions)
        target_center = _pair_center_tensor((src, dst), target_positions)
        center_loss = torch.sum((pred_center - target_center) ** 2)

        pred_axis = _normalize(torch, pred_positions[dst] - pred_positions[src], eps=eps)
        target_axis = _normalize(torch, target_positions[dst] - target_positions[src], eps=eps)
        axis_loss = 1.0 - torch.sum(pred_axis * target_axis)

        frame_loss = torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
        for node in (src, dst):
            pred_node_a1 = _normalize(torch, pred_a1[node], eps=eps)
            pred_node_a3 = _normalize(torch, pred_a3[node], eps=eps)
            target_node_a1 = _normalize(torch, target_a1[node], eps=eps)
            target_node_a3 = _normalize(torch, target_a3[node], eps=eps)
            frame_loss = frame_loss + 1.0 - torch.sum(pred_node_a1 * target_node_a1)
            frame_loss = frame_loss + 1.0 - torch.sum(pred_node_a3 * target_node_a3)
        losses.append(center_loss + axis_loss + 0.25 * frame_loss)
    return torch.mean(torch.stack(losses))


def reference_helix_step_distance_loss(torch, pred_positions, target_positions, helix_steps):
    step_index = _step_index_tensor(torch, helix_steps, pred_positions.device)
    if step_index is None:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    pred_first = _batched_pair_centers(torch, step_index[:, 0, :], pred_positions)
    pred_second = _batched_pair_centers(torch, step_index[:, 1, :], pred_positions)
    target_first = _batched_pair_centers(torch, step_index[:, 0, :], target_positions)
    target_second = _batched_pair_centers(torch, step_index[:, 1, :], target_positions)
    pred_distance = torch.norm(pred_second - pred_first, p=2, dim=1)
    target_distance = torch.norm(target_second - target_first, p=2, dim=1)
    return torch.mean((pred_distance - target_distance) ** 2)


def reference_helix_step_axis_loss(torch, pred_positions, target_positions, helix_steps, eps=1e-8):
    step_index = _step_index_tensor(torch, helix_steps, pred_positions.device)
    if step_index is None:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    pred_vector = (
        _batched_pair_centers(torch, step_index[:, 1, :], pred_positions)
        - _batched_pair_centers(torch, step_index[:, 0, :], pred_positions)
    )
    target_vector = (
        _batched_pair_centers(torch, step_index[:, 1, :], target_positions)
        - _batched_pair_centers(torch, step_index[:, 0, :], target_positions)
    )
    pred_axis = pred_vector / torch.norm(pred_vector, p=2, dim=1, keepdim=True).clamp(min=eps)
    target_axis = target_vector / torch.norm(target_vector, p=2, dim=1, keepdim=True).clamp(min=eps)
    return torch.mean(1.0 - torch.sum(pred_axis * target_axis, dim=1))


def _pair_index_tensor(torch, pairs, device):
    if pairs is None:
        return None
    if torch.is_tensor(pairs):
        if pairs.numel() == 0:
            return None
        pair_index = pairs.to(device=device, dtype=torch.long)
    else:
        if not pairs:
            return None
        pair_index = torch.tensor(pairs, dtype=torch.long, device=device)
    return pair_index.view(-1, 2)


def _step_index_tensor(torch, steps, device):
    if steps is None:
        return None
    if torch.is_tensor(steps):
        if steps.numel() == 0:
            return None
        step_index = steps.to(device=device, dtype=torch.long)
    else:
        if not steps:
            return None
        step_index = torch.tensor(steps, dtype=torch.long, device=device)
    return step_index.view(-1, 2, 2)


def _batched_pair_centers(torch, pair_index, positions):
    del torch
    return 0.5 * (positions[pair_index[:, 0]] + positions[pair_index[:, 1]])


def reference_pair_conflict_loss(torch, sample, pred_positions, pair_cutoff=4.0):
    candidate_partners = _candidate_partner_lists(torch, sample, pred_positions, pair_cutoff)
    losses = []
    for partners in candidate_partners.values():
        if len(partners) <= 1:
            losses.append(
                torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
            )
        else:
            losses.append(
                torch.tensor(float(len(partners) - 1), dtype=pred_positions.dtype, device=pred_positions.device)
            )
    if not losses:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    return torch.mean(torch.stack(losses))


def reference_nonpair_repulsion_loss(torch, sample, pred_positions, reference_pairs, margin=4.0, chunk_size=128):
    rows = sample.topology.rows
    num_nodes = int(sample.num_nucleotides)
    if num_nodes <= 1:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)

    device = pred_positions.device
    strand_ids = torch.tensor(
        [int(row.strand_id) for row in rows],
        dtype=torch.long,
        device=device,
    )
    node_ids = torch.arange(num_nodes, dtype=torch.long, device=device)
    reference_key = _canonical_pair_key_tensor(torch, reference_pairs, num_nodes, device)
    if reference_key is not None:
        reference_key = torch.sort(reference_key).values

    total = torch.tensor(0.0, dtype=pred_positions.dtype, device=device)
    count = torch.tensor(0.0, dtype=pred_positions.dtype, device=device)
    for start in range(0, num_nodes, int(chunk_size)):
        end = min(start + int(chunk_size), num_nodes)
        src = node_ids[start:end].view(-1, 1)
        dst = node_ids.view(1, -1)
        valid = (dst > src) & (strand_ids[src] != strand_ids[dst])
        if reference_key is not None and int(reference_key.numel()) > 0:
            pair_key = src * num_nodes + dst
            insert_at = torch.searchsorted(reference_key, pair_key.clamp(min=0))
            in_bounds = insert_at < reference_key.numel()
            matched = torch.zeros_like(valid)
            matched[in_bounds] = reference_key[insert_at[in_bounds]] == pair_key[in_bounds]
            valid = valid & (~matched)
        if int(valid.sum().detach().cpu()) == 0:
            continue
        distances = torch.norm(pred_positions[src] - pred_positions[dst], p=2, dim=2)
        penalties = torch.clamp(margin - distances, min=0.0) ** 2
        total = total + penalties[valid].sum()
        count = count + valid.sum().to(dtype=pred_positions.dtype)
    if float(count.detach().cpu()) == 0.0:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=device)
    return total / count


def _canonical_pair_key_tensor(torch, pairs, num_nodes, device):
    if pairs is None:
        return None
    if torch.is_tensor(pairs):
        if pairs.numel() == 0:
            return None
        pair_tensor = pairs.to(device=device, dtype=torch.long).view(-1, 2)
    else:
        if not pairs:
            return None
        pair_tensor = torch.tensor(list(pairs), dtype=torch.long, device=device).view(-1, 2)
    low = torch.minimum(pair_tensor[:, 0], pair_tensor[:, 1])
    high = torch.maximum(pair_tensor[:, 0], pair_tensor[:, 1])
    return low * int(num_nodes) + high


def reference_pair_assignment_margin_loss(
    torch,
    sample,
    pred_positions,
    target_positions,
    reference_pairs,
    candidate_pairs,
    margin=4.0,
):
    if not reference_pairs and not candidate_pairs:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    reference_pair_set = set(_canonical_pair(src, dst) for src, dst in reference_pairs)
    rows = sample.topology.rows
    losses = []
    for src, dst in reference_pair_set:
        pred_distance = torch.norm(pred_positions[src] - pred_positions[dst], p=2)
        target_distance = torch.norm(target_positions[src] - target_positions[dst], p=2)
        losses.append((pred_distance - target_distance) ** 2)
    for src, dst in set(_canonical_pair(src, dst) for src, dst in candidate_pairs):
        if _canonical_pair(src, dst) in reference_pair_set:
            continue
        if rows[src].strand_id == rows[dst].strand_id:
            continue
        if not _is_complementary(sample, (src, dst)):
            continue
        distance = torch.norm(pred_positions[src] - pred_positions[dst], p=2)
        losses.append(torch.clamp(margin - distance, min=0.0) ** 2)
    if not losses:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    return torch.mean(torch.stack(losses))


def soft_partner_exclusivity_loss(torch, sample, pred_positions, pair_cutoff=4.0, temperature=1.0):
    rows = sample.topology.rows
    losses = []
    for src in range(sample.num_nucleotides):
        logits = []
        for dst in range(sample.num_nucleotides):
            if src == dst:
                continue
            if rows[src].strand_id == rows[dst].strand_id:
                continue
            if not _is_complementary(sample, (src, dst)):
                continue
            distance = torch.norm(pred_positions[src] - pred_positions[dst], p=2)
            if pair_cutoff > 0 and float(distance.detach().cpu()) > pair_cutoff:
                continue
            logits.append(-distance / max(temperature, 1e-6))
        if len(logits) <= 1:
            losses.append(torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device))
            continue
        stacked = torch.stack(logits)
        probs = torch.softmax(stacked, dim=0)
        losses.append(torch.sum(probs * (1.0 - probs)))
    if not losses:
        return torch.tensor(0.0, dtype=pred_positions.dtype, device=pred_positions.device)
    return torch.mean(torch.stack(losses))


def _greedy_pair_matching(torch, sample, positions, pair_cutoff, complementary_only):
    candidates = _candidate_pairs(torch, sample, positions, pair_cutoff, complementary_only)
    selected = []
    used = set()
    for src, dst, _dist in candidates:
        if src in used or dst in used:
            continue
        used.add(src)
        used.add(dst)
        selected.append((src, dst))
    return selected


def _candidate_pairs(torch, sample, positions, pair_cutoff, complementary_only):
    try:
        from scipy.spatial import cKDTree
    except Exception:
        return _candidate_pairs_bruteforce(torch, sample, positions, pair_cutoff, complementary_only)

    if pair_cutoff <= 0:
        return []
    rows = sample.topology.rows
    coords = positions.detach().cpu().numpy()
    tree = cKDTree(coords)
    candidates = []
    for src, dst in tree.query_pairs(r=pair_cutoff, output_type="set"):
        src = int(src)
        dst = int(dst)
        if rows[src].strand_id == rows[dst].strand_id:
            continue
        if complementary_only and not _is_complementary(sample, (src, dst)):
            continue
        distance = _distance(torch, positions[src], positions[dst])
        if distance > pair_cutoff:
            continue
        candidates.append((src, dst, distance))
    candidates.sort(key=lambda item: (item[2], item[0], item[1]))
    return candidates


def _candidate_pairs_bruteforce(torch, sample, positions, pair_cutoff, complementary_only):
    rows = sample.topology.rows
    candidates = []
    for src in range(sample.num_nucleotides):
        for dst in range(src + 1, sample.num_nucleotides):
            if rows[src].strand_id == rows[dst].strand_id:
                continue
            if complementary_only and not _is_complementary(sample, (src, dst)):
                continue
            distance = _distance(torch, positions[src], positions[dst])
            if distance > pair_cutoff:
                continue
            candidates.append((src, dst, distance))
    candidates.sort(key=lambda item: (item[2], item[0], item[1]))
    return candidates


def _candidate_partner_lists(torch, sample, positions, pair_cutoff):
    partner_lists = {index: [] for index in range(sample.num_nucleotides)}
    for src, dst, _dist in _candidate_pairs(torch, sample, positions, pair_cutoff, complementary_only=False):
        partner_lists[src].append(dst)
        partner_lists[dst].append(src)
    return partner_lists


def _is_complementary(sample, pair):
    src, dst = pair
    src_base = sample.topology.rows[src].base
    dst_base = sample.topology.rows[dst].base
    return _COMPLEMENT.get(src_base) == dst_base


def _canonical_pair(src, dst):
    return (src, dst) if src < dst else (dst, src)


def _build_duplex_steps(sample, pairs: Sequence[Pair]) -> List[Step]:
    pair_map = {}
    for src, dst in pairs:
        pair_map[src] = dst
        pair_map[dst] = src
    steps = []
    seen = set()
    for src, dst in pairs:
        src_next = sample.topology.rows[src].next_idx
        dst_prev = sample.topology.rows[dst].prev_idx
        if src_next >= 0 and dst_prev >= 0 and pair_map.get(src_next) == dst_prev:
            first = _canonical_pair(src, dst)
            second = _canonical_pair(src_next, dst_prev)
            edge = (first, second)
            if edge not in seen:
                seen.add(edge)
                steps.append(edge)
        src_prev = sample.topology.rows[src].prev_idx
        dst_next = sample.topology.rows[dst].next_idx
        if src_prev >= 0 and dst_next >= 0 and pair_map.get(src_prev) == dst_next:
            first = _canonical_pair(src_prev, dst_next)
            second = _canonical_pair(src, dst)
            edge = (first, second)
            if edge not in seen:
                seen.add(edge)
                steps.append(edge)
    return steps


def _pair_distance_mean(torch, pairs, positions):
    if not pairs:
        return None
    distances = [_distance(torch, positions[src], positions[dst]) for src, dst in pairs]
    return float(sum(distances) / float(len(distances)))


def _pair_distance_rms_error(torch, pairs, reference_positions, pred_positions):
    if not pairs:
        return None
    errors = []
    for src, dst in pairs:
        ref_distance = _distance(torch, reference_positions[src], reference_positions[dst])
        pred_distance = _distance(torch, pred_positions[src], pred_positions[dst])
        errors.append((pred_distance - ref_distance) ** 2)
    return float((sum(errors) / float(len(errors))) ** 0.5)


def _step_distance_mean(torch, steps, positions):
    if not steps:
        return None
    distances = []
    for first, second in steps:
        first_center = _pair_center(torch, first, positions)
        second_center = _pair_center(torch, second, positions)
        distances.append(_distance(torch, first_center, second_center))
    return float(sum(distances) / float(len(distances)))


def _step_distance_mae(torch, steps, reference_positions, pred_positions):
    if not steps:
        return None
    errors = []
    for first, second in steps:
        ref_distance = _distance(
            torch,
            _pair_center(torch, first, reference_positions),
            _pair_center(torch, second, reference_positions),
        )
        pred_distance = _distance(
            torch,
            _pair_center(torch, first, pred_positions),
            _pair_center(torch, second, pred_positions),
        )
        errors.append(abs(pred_distance - ref_distance))
    return float(sum(errors) / float(len(errors)))


def _step_axis_score(torch, steps, reference_positions, pred_positions):
    if not steps:
        return None
    scores = []
    for first, second in steps:
        ref_vector = _pair_center(torch, second, reference_positions) - _pair_center(torch, first, reference_positions)
        pred_vector = _pair_center(torch, second, pred_positions) - _pair_center(torch, first, pred_positions)
        ref_unit = _normalize(torch, ref_vector)
        pred_unit = _normalize(torch, pred_vector)
        scores.append(float(torch.sum(ref_unit * pred_unit).detach().cpu()))
    return float(sum(scores) / float(len(scores)))


def _duplex_step_retention(
    torch,
    steps,
    reference_positions,
    pred_positions,
    pair_distance_relative_tolerance=0.25,
    step_distance_relative_tolerance=0.25,
    axis_cosine_threshold=0.85,
):
    if not steps:
        return None
    retained = 0
    for first, second in steps:
        pair_distances_ok = True
        for pair in (first, second):
            ref_pair_distance = _distance(torch, reference_positions[pair[0]], reference_positions[pair[1]])
            pred_pair_distance = _distance(torch, pred_positions[pair[0]], pred_positions[pair[1]])
            pair_tolerance = max(ref_pair_distance * pair_distance_relative_tolerance, 1e-6)
            if abs(pred_pair_distance - ref_pair_distance) > pair_tolerance:
                pair_distances_ok = False
                break
        if not pair_distances_ok:
            continue

        ref_step = _pair_center(torch, second, reference_positions) - _pair_center(torch, first, reference_positions)
        pred_step = _pair_center(torch, second, pred_positions) - _pair_center(torch, first, pred_positions)
        ref_step_distance = _distance(torch, _pair_center(torch, second, reference_positions), _pair_center(torch, first, reference_positions))
        pred_step_distance = _distance(torch, _pair_center(torch, second, pred_positions), _pair_center(torch, first, pred_positions))
        step_tolerance = max(ref_step_distance * step_distance_relative_tolerance, 1e-6)
        if abs(pred_step_distance - ref_step_distance) > step_tolerance:
            continue
        axis_score = float(torch.sum(_normalize(torch, ref_step) * _normalize(torch, pred_step)).detach().cpu())
        if axis_score < axis_cosine_threshold:
            continue
        retained += 1
    return float(retained) / float(len(steps))


def _pair_center(torch, pair, positions):
    src, dst = pair
    return 0.5 * (positions[src] + positions[dst])


def _pair_center_tensor(pair, positions):
    src, dst = pair
    return 0.5 * (positions[src] + positions[dst])


def _distance(torch, lhs, rhs):
    return float(torch.norm(lhs - rhs, p=2).detach().cpu())


def _normalize(torch, vector, eps=1e-8):
    return vector / torch.norm(vector, p=2).clamp(min=eps)


def _rule_score(
    precision,
    recall,
    complementarity,
    occupancy,
    pair_distance_rms_error,
    reference_pair_distance_mean,
    helix_step_distance_mae,
    helix_step_distance_mean,
    helix_step_axis_score,
):
    if reference_pair_distance_mean is None or pair_distance_rms_error is None:
        return None
    pair_scale = max(reference_pair_distance_mean, 1e-6)
    step_scale = max(helix_step_distance_mean or 1.0, 1e-6)
    pair_distance_score = 1.0 / (1.0 + (pair_distance_rms_error / pair_scale))
    step_distance_score = 1.0
    axis_score = 0.5
    if helix_step_distance_mae is not None:
        step_distance_score = 1.0 / (1.0 + (helix_step_distance_mae / step_scale))
    if helix_step_axis_score is not None:
        axis_score = max(0.0, min(1.0, 0.5 * (helix_step_axis_score + 1.0)))
    components = [
        precision,
        recall,
        complementarity,
        occupancy,
        pair_distance_score,
        step_distance_score,
        axis_score,
    ]
    return float(sum(components) / float(len(components)))
