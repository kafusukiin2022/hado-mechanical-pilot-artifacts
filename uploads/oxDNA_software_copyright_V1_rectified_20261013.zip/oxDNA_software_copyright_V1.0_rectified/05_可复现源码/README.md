# 固定 V1.0 的独立复现包

目录中含推理与训练入口、直接导入的自有模块、推理接口测试、固定权重、输入样例。历史 EGNN 适配脚本保留原样；仅在调用其 `_load_egnn_class` 分支时才需要外部 `EBD/models/egnn.py`。固定 dgnn-lite 推理和本包内 25 项测试不加载该第三方实现。

在已配置 PyTorch 1.8.1、NumPy 1.21.6、SciPy 1.7.3 的 Python 3.7 环境中：

```bash
PYTHON_BIN=/path/to/python ./run_tests.sh
PYTHON_BIN=/path/to/python ./run_demo.sh
```

所有命令从本目录使用相对数据路径。`results/` 保存新的输出。源文件、模型和样例散列分别见上层清单和 `sample/provenance.json`。训练全量重跑需原 77 个样本及其授权数据，不由这个单样本复现包提供。
