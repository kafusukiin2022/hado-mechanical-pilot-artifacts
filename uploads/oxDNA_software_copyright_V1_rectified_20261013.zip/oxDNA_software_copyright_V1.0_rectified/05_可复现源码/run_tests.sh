#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN=${PYTHON_BIN:-python}
PYTHONNOUSERSITE=1 "$PYTHON_BIN" -m unittest tests.test_ebd_oxdna_shared_rigid_predict -v
