#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN=${PYTHON_BIN:-python}
mkdir -p results
PYTHONNOUSERSITE=1 "$PYTHON_BIN" scripts/ebd_oxdna_shared_rigid_predict.py \
  --checkpoint model/model_best.pt --bundle model/inference_bundle.json \
  --top sample/sample.top --start sample/start.conf \
  --output results/prediction.conf --summary-json results/prediction.json --device cpu
