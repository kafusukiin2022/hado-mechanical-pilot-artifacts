"""DNA origami adapters for EBD-compatible oxDNA model outputs."""
