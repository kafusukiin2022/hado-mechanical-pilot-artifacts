import json
import os
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

from tests.test_ebd_oxdna_egnn_overfit_cli import (
    START_CONF,
    TARGET_CONF,
    TOPOLOGY_TEXT,
)


def _training_summary(**overrides):
    summary = {
        "model": "shared_rigid_mlp_joint",
        "model_kind": "dgnn-lite",
        "node_feature_dim": 17,
        "edge_feature_dim": 10,
        "shared_hidden_dim": 8,
        "message_passing_steps": 1,
        "scale_normalized_residuals": False,
        "dropout": 0.0,
        "wc_edge_mode": "message_all",
        "fourier_features": 0,
        "design_features": "none",
        "graph_mode": "backbone",
        "graph_cutoff": 0.0,
        "max_graph_neighbors": 16,
        "include_candidate_wc_edges": False,
        "candidate_wc_top_k": 0,
        "candidate_wc_cutoff": 0.0,
        "physical_graph": False,
        "stage_samples_on_cpu": True,
        "design_edge_sidecars": None,
        "design_edge_sidecars_sha256": None,
        "require_explicit_design_edges": False,
        "edge_family_pair": False,
        "edge_family_crossover": False,
        "edge_family_duplex_step": False,
        "edge_family_start_spatial": False,
        "start_rmsd_residual_gate_threshold": 0.0,
        "start_rmsd_residual_gate_sharpness": 1.0,
        "start_rmsd_residual_min_scale": 0.0,
    }
    summary.update(overrides)
    return summary


class SharedRigidInferenceBundleTest(unittest.TestCase):
    def test_training_summary_becomes_versioned_target_free_bundle(self):
        from ebd_oxdna.shared_rigid_bundle import build_inference_bundle

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            with open(checkpoint_path, "wb") as handle:
                handle.write(b"trusted checkpoint")
            bundle = build_inference_bundle(
                _training_summary(),
                checkpoint_paths={"best": checkpoint_path},
            )

        self.assertEqual(bundle["schema"], "ebd_oxdna.shared_rigid_inference_bundle")
        self.assertEqual(bundle["schema_version"], 3)
        self.assertEqual(bundle["preprocessing"]["schema_version"], 2)
        self.assertEqual(bundle["model"]["kind"], "dgnn-lite")
        self.assertEqual(bundle["model"]["input_dim"], 17)
        self.assertEqual(bundle["preprocessing"]["graph_mode"], "backbone")
        self.assertTrue(bundle["target_free"]["compatible"])
        self.assertEqual(bundle["checkpoint_paths"]["best"], checkpoint_path)
        self.assertEqual(len(bundle["checkpoint_sha256"]["best"]), 64)
        self.assertNotIn("samples", bundle)

    def test_bundle_persists_target_free_typed_design_edge_contract(self):
        from ebd_oxdna.shared_rigid_bundle import build_inference_bundle

        bundle = build_inference_bundle(
            _training_summary(
                edge_feature_dim=16,
                design_edge_sidecars="/tmp/design_edge_sidecars.json",
                design_edge_sidecars_sha256="a" * 64,
                require_explicit_design_edges=True,
                edge_family_pair=True,
                edge_family_crossover=True,
                edge_family_duplex_step=True,
                edge_family_start_spatial=False,
                edge_relation_names=[
                    "backbone_forward",
                    "backbone_reverse",
                    "crossover",
                    "base_pair",
                    "duplex_step",
                    "start_spatial",
                ],
            )
        )

        preprocessing = bundle["preprocessing"]
        self.assertTrue(preprocessing["uses_design_edges"])
        self.assertTrue(preprocessing["require_explicit_design_edges"])
        self.assertTrue(preprocessing["edge_family_pair"])
        self.assertTrue(preprocessing["edge_family_crossover"])
        self.assertTrue(preprocessing["edge_family_duplex_step"])
        self.assertFalse(preprocessing["edge_family_start_spatial"])
        self.assertEqual(preprocessing["design_edge_schema_version"], 1)
        self.assertEqual(preprocessing["training_sidecar_index_sha256"], "a" * 64)
        self.assertTrue(bundle["target_free"]["compatible"])

    def test_target_derived_training_options_are_rejected_for_inference(self):
        from ebd_oxdna.shared_rigid_bundle import (
            build_inference_bundle,
            require_target_free_compatible,
        )

        bundle = build_inference_bundle(
            _training_summary(
                include_candidate_wc_edges=True,
                start_rmsd_residual_gate_threshold=5.0,
            )
        )

        self.assertFalse(bundle["target_free"]["compatible"])
        with self.assertRaisesRegex(ValueError, "candidate WC edges.*start-RMSD"):
            require_target_free_compatible(bundle)

    def test_tampered_target_free_claim_is_rejected(self):
        from ebd_oxdna.shared_rigid_bundle import (
            build_inference_bundle,
            require_target_free_compatible,
        )

        bundle = build_inference_bundle(
            _training_summary(include_candidate_wc_edges=True)
        )
        bundle["target_free"] = {"compatible": True, "incompatibilities": []}

        with self.assertRaisesRegex(ValueError, "target_free metadata"):
            require_target_free_compatible(bundle)

    def test_legacy_summary_migration_requires_every_inference_setting(self):
        from ebd_oxdna.shared_rigid_bundle import load_inference_bundle

        with tempfile.TemporaryDirectory() as tmpdir:
            summary_path = os.path.join(tmpdir, "summary.json")
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            with open(checkpoint_path, "wb") as handle:
                handle.write(b"independently identified checkpoint")
            incomplete = _training_summary()
            incomplete.pop("message_passing_steps")
            with open(summary_path, "w") as handle:
                json.dump(incomplete, handle)

            with self.assertRaisesRegex(ValueError, "message_passing_steps"):
                load_inference_bundle(
                    summary_path,
                    legacy_checkpoint_path=checkpoint_path,
                    expected_checkpoint_sha256="a" * 64,
                )

    def test_legacy_summary_requires_independent_checkpoint_sha256(self):
        from ebd_oxdna.shared_rigid_bundle import load_inference_bundle

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            summary_path = os.path.join(tmpdir, "summary.json")
            with open(checkpoint_path, "wb") as handle:
                handle.write(b"checkpoint selected by an untrusted summary")
            with open(summary_path, "w") as handle:
                json.dump(
                    _training_summary(save_best_model_state=checkpoint_path),
                    handle,
                )

            with self.assertRaisesRegex(ValueError, "independently supplied.*SHA-256"):
                load_inference_bundle(
                    summary_path,
                    legacy_checkpoint_path=checkpoint_path,
                )

    def test_legacy_summary_uses_independently_supplied_checkpoint_sha256(self):
        from ebd_oxdna.shared_rigid_bundle import load_inference_bundle

        expected_sha256 = "a" * 64
        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            summary_path = os.path.join(tmpdir, "summary.json")
            with open(checkpoint_path, "wb") as handle:
                handle.write(b"digest intentionally differs from expected")
            with open(summary_path, "w") as handle:
                json.dump(_training_summary(), handle)

            bundle = load_inference_bundle(
                summary_path,
                legacy_checkpoint_path=checkpoint_path,
                expected_checkpoint_sha256=expected_sha256,
            )

        self.assertEqual(
            bundle["checkpoint_paths"],
            {"legacy": os.path.abspath(checkpoint_path)},
        )
        self.assertEqual(bundle["checkpoint_sha256"], {"legacy": expected_sha256})

    def test_numeric_bundle_fields_require_exact_json_scalar_types(self):
        from ebd_oxdna.shared_rigid_bundle import (
            build_inference_bundle,
            require_target_free_compatible,
        )

        with self.assertRaisesRegex(ValueError, "shared_hidden_dim.*integer"):
            build_inference_bundle(_training_summary(shared_hidden_dim=8.0))
        with self.assertRaisesRegex(ValueError, "dropout.*float"):
            build_inference_bundle(_training_summary(dropout="0.0"))

        bundle = build_inference_bundle(_training_summary())
        bundle["model"]["input_dim"] = 17.0
        with self.assertRaisesRegex(ValueError, "input_dim.*integer"):
            require_target_free_compatible(bundle)

        bundle = build_inference_bundle(_training_summary())
        bundle["model"]["dropout"] = "0.0"
        with self.assertRaisesRegex(ValueError, "dropout.*float"):
            require_target_free_compatible(bundle)

    def test_schema_version_one_is_explicitly_rejected(self):
        from ebd_oxdna.shared_rigid_bundle import (
            build_inference_bundle,
            require_target_free_compatible,
        )

        bundle = build_inference_bundle(_training_summary())
        bundle["schema_version"] = 1

        with self.assertRaisesRegex(ValueError, "version 1"):
            require_target_free_compatible(bundle)

    def test_schema_versions_require_integer_json_scalars(self):
        from ebd_oxdna.shared_rigid_bundle import (
            PREPROCESSING_SCHEMA_VERSION,
            SCHEMA_VERSION,
            build_inference_bundle,
            require_target_free_compatible,
        )

        bundle = build_inference_bundle(_training_summary())
        bundle["schema_version"] = float(SCHEMA_VERSION)
        with self.assertRaisesRegex(ValueError, "inference bundle version"):
            require_target_free_compatible(bundle)

        bundle = build_inference_bundle(_training_summary())
        bundle["preprocessing"]["schema_version"] = float(
            PREPROCESSING_SCHEMA_VERSION
        )
        with self.assertRaisesRegex(ValueError, "preprocessing schema_version"):
            require_target_free_compatible(bundle)

    def test_invalid_or_nonfinite_bundle_values_are_rejected(self):
        from ebd_oxdna.shared_rigid_bundle import (
            build_inference_bundle,
            require_target_free_compatible,
        )

        invalid_enum = build_inference_bundle(_training_summary())
        invalid_enum["preprocessing"]["graph_mode"] = "typo"
        with self.assertRaisesRegex(ValueError, "graph_mode"):
            require_target_free_compatible(invalid_enum)

        invalid_gate = build_inference_bundle(_training_summary())
        invalid_gate["residual_gate"]["threshold"] = float("nan")
        with self.assertRaisesRegex(ValueError, "threshold"):
            require_target_free_compatible(invalid_gate)


class SharedRigidPredictCLITest(unittest.TestCase):
    def test_training_and_inference_share_identical_typed_design_graph(self):
        try:
            import torch
        except ImportError:
            self.skipTest("torch is required for typed graph inference")

        from ebd_oxdna.design_edges import build_design_edge_sidecar
        from ebd_oxdna.shared_rigid_bundle import build_inference_bundle
        from scripts import ebd_oxdna_shared_rigid_predict as predictor
        from scripts import ebd_oxdna_shared_rigid_train as trainer
        from tests.test_design_edges import _write_fixture

        with tempfile.TemporaryDirectory() as tmpdir:
            entry = _write_fixture(tmpdir)
            sidecar = build_design_edge_sidecar(
                entry,
                include_start_spatial=True,
                spatial_cutoff=3.1,
                max_spatial_neighbors=2,
            )
            sidecar_path = os.path.join(tmpdir, "toy.design_edges.json")
            with open(sidecar_path, "w") as handle:
                json.dump(sidecar, handle, indent=2, sort_keys=True)
            training = trainer._prepare_sample(
                torch,
                entry,
                "cpu",
                electrostatic_cutoff=0.0,
                fourier_features=0,
                design_features="none",
                graph_mode="backbone",
                graph_cutoff=0.0,
                max_graph_neighbors=16,
                include_candidate_wc_edges=False,
                candidate_wc_top_k=0,
                candidate_wc_cutoff=0.0,
                design_edge_sidecar_path=sidecar_path,
                require_explicit_design_edges=True,
                edge_family_pair=True,
                edge_family_crossover=True,
                edge_family_duplex_step=True,
                edge_family_start_spatial=True,
            )
            bundle = build_inference_bundle(
                _training_summary(
                    edge_feature_dim=16,
                    design_edge_sidecars="/tmp/design_edge_sidecars.json",
                    design_edge_sidecars_sha256="a" * 64,
                    require_explicit_design_edges=True,
                    edge_family_pair=True,
                    edge_family_crossover=True,
                    edge_family_duplex_step=True,
                    edge_family_start_spatial=True,
                )
            )
            inference = predictor._prepare_inference_sample(
                torch,
                entry["top"],
                entry["start"],
                "cpu",
                bundle,
                design_edge_sidecar_path=sidecar_path,
            )

        self.assertTrue(torch.equal(training["graph_edges"], inference["graph_edges"]))
        self.assertTrue(
            torch.equal(
                training["graph_edge_features"], inference["graph_edge_features"]
            )
        )
        self.assertEqual(
            inference["design_edge_fingerprint"], sidecar["fingerprint"]
        )
        self.assertFalse(bool(inference["candidate_wc_edge_mask"].any()))

    def test_typed_design_bundle_requires_sidecar_at_inference(self):
        try:
            import torch
        except ImportError:
            self.skipTest("torch is required for typed graph inference")

        from ebd_oxdna.shared_rigid_bundle import build_inference_bundle
        from scripts import ebd_oxdna_shared_rigid_predict as predictor
        from tests.test_design_edges import _write_fixture

        with tempfile.TemporaryDirectory() as tmpdir:
            entry = _write_fixture(tmpdir)
            bundle = build_inference_bundle(
                _training_summary(
                    edge_feature_dim=16,
                    design_edge_sidecars="/tmp/design_edge_sidecars.json",
                    design_edge_sidecars_sha256="a" * 64,
                    require_explicit_design_edges=True,
                    edge_family_pair=True,
                )
            )
            with self.assertRaisesRegex(ValueError, "design-edge sidecar is required"):
                predictor._prepare_inference_sample(
                    torch,
                    entry["top"],
                    entry["start"],
                    "cpu",
                    bundle,
                )

    def test_predict_cli_exposes_design_edge_sidecar(self):
        result = subprocess.run(
            [sys.executable, "scripts/ebd_oxdna_shared_rigid_predict.py", "--help"],
            cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--design-edge-sidecar", result.stdout)

    def test_checkpoint_top_start_writes_target_free_conf_with_numeric_time(self):
        try:
            import torch
        except ImportError:
            self.skipTest("torch is required for checkpoint inference")

        from ebd_oxdna.shared_rigid_bundle import build_inference_bundle
        from oxdna_export.io import read_config
        from scripts import ebd_oxdna_shared_rigid_predict
        from scripts.ebd_oxdna_shared_rigid_train import DgnnLiteRigidModel

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            bundle_path = os.path.join(tmpdir, "inference_bundle.json")
            output_path = os.path.join(tmpdir, "predicted.conf")
            summary_path = os.path.join(tmpdir, "prediction.json")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)

            model = DgnnLiteRigidModel(
                torch,
                input_dim=17,
                edge_dim=10,
                hidden_dim=8,
                device="cpu",
                message_passing_steps=1,
            )
            for parameter in model.parameters():
                parameter.data.zero_()
            torch.save(model.state_dict(), checkpoint_path)
            with open(bundle_path, "w") as handle:
                json.dump(
                    build_inference_bundle(
                        _training_summary(),
                        checkpoint_paths={"best": checkpoint_path},
                    ),
                    handle,
                )

            exit_code = ebd_oxdna_shared_rigid_predict.main(
                [
                    "--checkpoint",
                    checkpoint_path,
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--output",
                    output_path,
                    "--summary-json",
                    summary_path,
                    "--device",
                    "cpu",
                    "--time",
                    "123",
                ]
            )

            predicted = read_config(output_path, expected_rows=4)
            start = read_config(start_path, expected_rows=4)
            with open(summary_path) as handle:
                prediction_summary = json.load(handle)

        self.assertEqual(exit_code, 0)
        self.assertEqual(float(predicted.time), 123.0)
        self.assertEqual(
            [row.position for row in predicted.rows],
            [row.position for row in start.rows],
        )
        self.assertTrue(prediction_summary["target_free"])
        self.assertEqual(prediction_summary["num_nucleotides"], 4)
        self.assertEqual(prediction_summary["bundle_source"], os.path.abspath(bundle_path))
        self.assertNotIn("target", prediction_summary)

    def test_training_summary_is_auto_discovered_when_bundle_is_absent(self):
        from scripts import ebd_oxdna_shared_rigid_predict

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            summary_path = os.path.join(tmpdir, "summary.json")
            open(checkpoint_path, "wb").close()
            with open(summary_path, "w") as handle:
                json.dump(_training_summary(), handle)

            discovered = ebd_oxdna_shared_rigid_predict._discover_bundle_path(
                checkpoint_path,
                explicit_path=None,
            )

        self.assertEqual(discovered, os.path.abspath(summary_path))

    def test_checkpoint_specific_bundle_precedes_generic_bundle(self):
        from scripts import ebd_oxdna_shared_rigid_predict

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            stem_bundle = os.path.join(tmpdir, "model_best.bundle.json")
            generic_bundle = os.path.join(tmpdir, "inference_bundle.json")
            open(checkpoint_path, "wb").close()
            open(stem_bundle, "w").close()
            open(generic_bundle, "w").close()

            discovered = ebd_oxdna_shared_rigid_predict._discover_bundle_path(
                checkpoint_path,
                explicit_path=None,
            )

        self.assertEqual(discovered, os.path.abspath(stem_bundle))

    def test_checkpoint_hash_mismatch_is_rejected_before_loading(self):
        from ebd_oxdna.shared_rigid_bundle import build_inference_bundle
        from scripts import ebd_oxdna_shared_rigid_predict

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            with open(checkpoint_path, "wb") as handle:
                handle.write(b"original")
            bundle = build_inference_bundle(
                _training_summary(),
                checkpoint_paths={"best": checkpoint_path},
            )
            with open(checkpoint_path, "wb") as handle:
                handle.write(b"replacement")

            with self.assertRaisesRegex(ValueError, "SHA-256"):
                with open(checkpoint_path, "rb") as checkpoint_file:
                    ebd_oxdna_shared_rigid_predict._verify_checkpoint_hash(
                        checkpoint_file,
                        bundle,
                    )

    def test_legacy_summary_cli_requires_checkpoint_sha256(self):
        from scripts import ebd_oxdna_shared_rigid_predict

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            summary_path = os.path.join(tmpdir, "summary.json")
            top_path = os.path.join(tmpdir, "design.top")
            start_path = os.path.join(tmpdir, "start.conf")
            output_path = os.path.join(tmpdir, "prediction.conf")
            for path in (checkpoint_path, top_path, start_path):
                open(path, "wb").close()
            with open(summary_path, "w") as handle:
                json.dump(_training_summary(), handle)

            with self.assertRaisesRegex(ValueError, "--checkpoint-sha256"):
                ebd_oxdna_shared_rigid_predict.main(
                    [
                        "--checkpoint",
                        checkpoint_path,
                        "--bundle",
                        summary_path,
                        "--top",
                        top_path,
                        "--start",
                        start_path,
                        "--output",
                        output_path,
                    ]
                )

    def test_verified_loader_deserializes_the_same_checkpoint_file_it_hashed(self):
        try:
            import torch
        except ImportError:
            self.skipTest("torch is required for checkpoint loading")

        from ebd_oxdna.shared_rigid_bundle import build_inference_bundle
        from scripts import ebd_oxdna_shared_rigid_predict

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            replacement_path = os.path.join(tmpdir, "replacement.pt")
            torch.save({"value": torch.tensor([1.0])}, checkpoint_path)
            torch.save({"value": torch.tensor([2.0])}, replacement_path)
            bundle = build_inference_bundle(
                _training_summary(),
                checkpoint_paths={"best": checkpoint_path},
            )
            original_verify = ebd_oxdna_shared_rigid_predict._verify_checkpoint_hash

            def verify_then_replace(checkpoint_file, inference_bundle):
                digest = original_verify(checkpoint_file, inference_bundle)
                os.replace(replacement_path, checkpoint_path)
                return digest

            with mock.patch.object(
                ebd_oxdna_shared_rigid_predict,
                "_verify_checkpoint_hash",
                side_effect=verify_then_replace,
            ):
                checkpoint, digest = (
                    ebd_oxdna_shared_rigid_predict._load_verified_checkpoint(
                        torch,
                        checkpoint_path,
                        bundle,
                        "cpu",
                    )
                )

        self.assertEqual(checkpoint["value"].item(), 1.0)
        self.assertEqual(digest, bundle["checkpoint_sha256"]["best"])

    def test_verified_loader_uses_weights_only_with_modern_torch(self):
        from ebd_oxdna.shared_rigid_bundle import build_inference_bundle
        from scripts import ebd_oxdna_shared_rigid_predict

        class ModernTorch:
            def __init__(self):
                self.source = None
                self.weights_only = None

            def load(self, source, map_location=None, weights_only=False):
                self.source = source
                self.weights_only = weights_only
                return source.read()

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            with open(checkpoint_path, "wb") as handle:
                handle.write(b"modern checkpoint bytes")
            bundle = build_inference_bundle(
                _training_summary(),
                checkpoint_paths={"best": checkpoint_path},
            )
            fake_torch = ModernTorch()

            checkpoint, _ = ebd_oxdna_shared_rigid_predict._load_verified_checkpoint(
                fake_torch,
                checkpoint_path,
                bundle,
                "cpu",
            )

        self.assertEqual(checkpoint, b"modern checkpoint bytes")
        self.assertFalse(isinstance(fake_torch.source, (str, bytes, os.PathLike)))
        self.assertTrue(fake_torch.weights_only)

    def test_verified_loader_warns_for_hash_bound_legacy_torch(self):
        from ebd_oxdna.shared_rigid_bundle import build_inference_bundle
        from scripts import ebd_oxdna_shared_rigid_predict

        class LegacyTorch:
            def load(self, source, map_location=None):
                return source.read()

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model_best.pt")
            with open(checkpoint_path, "wb") as handle:
                handle.write(b"legacy checkpoint bytes")
            bundle = build_inference_bundle(
                _training_summary(),
                checkpoint_paths={"best": checkpoint_path},
            )

            with self.assertWarnsRegex(RuntimeWarning, "hash-verified"):
                checkpoint, _ = (
                    ebd_oxdna_shared_rigid_predict._load_verified_checkpoint(
                        LegacyTorch(),
                        checkpoint_path,
                        bundle,
                        "cpu",
                    )
                )

        self.assertEqual(checkpoint, b"legacy checkpoint bytes")

    def test_write_destinations_must_not_alias_inputs_or_each_other(self):
        from scripts import ebd_oxdna_shared_rigid_predict

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model.pt")
            bundle_path = os.path.join(tmpdir, "bundle.json")
            top_path = os.path.join(tmpdir, "design.top")
            start_path = os.path.join(tmpdir, "start.conf")
            output_path = os.path.join(tmpdir, "prediction.conf")
            summary_path = os.path.join(tmpdir, "prediction.json")
            for path in (checkpoint_path, bundle_path, top_path, start_path):
                with open(path, "w") as handle:
                    handle.write(path)
            checkpoint_alias = os.path.join(tmpdir, "checkpoint-hardlink")
            os.link(checkpoint_path, checkpoint_alias)
            start_alias = os.path.join(tmpdir, "start-symlink")
            os.symlink(start_path, start_alias)
            protected = {
                "--checkpoint": checkpoint_path,
                "--bundle": bundle_path,
                "--top": top_path,
                "--start": start_path,
            }

            with self.assertRaisesRegex(ValueError, "--output.*--summary-json"):
                ebd_oxdna_shared_rigid_predict._validate_destination_paths(
                    output_path,
                    output_path,
                    protected,
                )
            with self.assertRaisesRegex(ValueError, "--output.*--checkpoint"):
                ebd_oxdna_shared_rigid_predict._validate_destination_paths(
                    checkpoint_alias,
                    summary_path,
                    protected,
                )
            with self.assertRaisesRegex(ValueError, "--summary-json.*--start"):
                ebd_oxdna_shared_rigid_predict._validate_destination_paths(
                    output_path,
                    start_alias,
                    protected,
                )

    def test_main_rejects_destination_alias_before_loading_bundle(self):
        from scripts import ebd_oxdna_shared_rigid_predict

        with tempfile.TemporaryDirectory() as tmpdir:
            checkpoint_path = os.path.join(tmpdir, "model.pt")
            bundle_path = os.path.join(tmpdir, "invalid-bundle.json")
            top_path = os.path.join(tmpdir, "design.top")
            start_path = os.path.join(tmpdir, "start.conf")
            summary_path = os.path.join(tmpdir, "prediction.json")
            for path in (checkpoint_path, top_path, start_path):
                with open(path, "w") as handle:
                    handle.write(path)
            with open(bundle_path, "w") as handle:
                handle.write("not valid JSON")
            output_alias = os.path.join(tmpdir, "checkpoint-hardlink")
            os.link(checkpoint_path, output_alias)

            with self.assertRaisesRegex(ValueError, "--output.*--checkpoint"):
                ebd_oxdna_shared_rigid_predict.main(
                    [
                        "--checkpoint",
                        checkpoint_path,
                        "--bundle",
                        bundle_path,
                        "--top",
                        top_path,
                        "--start",
                        start_path,
                        "--output",
                        output_alias,
                        "--summary-json",
                        summary_path,
                    ]
                )

    def test_training_cli_writes_inference_bundle_and_numeric_conf_time(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch is required for shared-rigid training")

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            target_path = os.path.join(tmpdir, "target.conf")
            manifest_path = os.path.join(tmpdir, "manifest.json")
            output_dir = os.path.join(tmpdir, "outputs")
            summary_path = os.path.join(tmpdir, "summary.json")
            checkpoint_path = os.path.join(tmpdir, "model_final.pt")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)
            with open(target_path, "w") as handle:
                handle.write(TARGET_CONF)
            with open(manifest_path, "w") as handle:
                json.dump(
                    [
                        {
                            "id": "tiny",
                            "top": top_path,
                            "start": start_path,
                            "target": target_path,
                        }
                    ],
                    handle,
                )

            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_shared_rigid_train.py",
                    "--manifest",
                    manifest_path,
                    "--output-dir",
                    output_dir,
                    "--summary-json",
                    summary_path,
                    "--save-model-state",
                    checkpoint_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "1",
                    "--model-kind",
                    "dgnn-lite",
                    "--shared-hidden-dim",
                    "8",
                    "--message-passing-steps",
                    "1",
                    "--graph-mode",
                    "backbone",
                    "--electrostatic-cutoff",
                    "0",
                    "--log-every",
                    "1",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            bundle_path = os.path.join(output_dir, "inference_bundle.json")
            predicted_path = os.path.join(output_dir, "tiny.conf")
            self.assertTrue(os.path.isfile(bundle_path))
            with open(bundle_path) as handle:
                bundle = json.load(handle)
            with open(summary_path) as handle:
                training_summary = json.load(handle)
            with open(predicted_path) as handle:
                time_line = handle.readline().strip()

        self.assertEqual(bundle["schema_version"], 3)
        self.assertTrue(bundle["target_free"]["compatible"])
        self.assertEqual(
            bundle["checkpoint_paths"]["final"],
            os.path.abspath(checkpoint_path),
        )
        self.assertEqual(
            training_summary["inference_bundle"],
            os.path.abspath(bundle_path),
        )
        self.assertEqual(float(time_line.split("=", 1)[1]), 1.0)


if __name__ == "__main__":
    unittest.main()
