import json
import os
import subprocess
import sys
import tempfile
import types
import unittest
from unittest import mock


TOPOLOGY_TEXT = """4 2
1 A -1 1
1 T 0 -1
2 C -1 3
2 G 2 -1
"""

START_CONF = """t = 0
b = 20 20 20
E = 0 0 0
1 1 1 1 0 0 0 0 1 0 0 0 0 0 0
3 1 1 1 0 0 0 0 1 0 0 0 0 0 0
1 5 1 1 0 0 0 0 1 0 0 0 0 0 0
3 5 1 1 0 0 0 0 1 0 0 0 0 0 0
"""

TARGET_CONF = """t = 2000000
b = 20 20 20
E = 0 0 0
2 2 1 0 1 0 0 0 1 0 0 0 0 0 0
4 2 1 0 1 0 0 0 1 0 0 0 0 0 0
2 6 1 0 1 0 0 0 1 0 0 0 0 0 0
4 6 1 0 1 0 0 0 1 0 0 0 0 0 0
"""


class EBDOxDNAEGNNOverfitCLITest(unittest.TestCase):
    def test_overfit_cli_writes_summary_and_prediction_with_lower_rmsd(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch is required for the EGNN overfit CLI")

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            target_path = os.path.join(tmpdir, "md_last.conf")
            output_path = os.path.join(tmpdir, "predicted.conf")
            summary_path = os.path.join(tmpdir, "summary.json")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)
            with open(target_path, "w") as handle:
                handle.write(TARGET_CONF)

            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_egnn_overfit.py",
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--target",
                    target_path,
                    "--output",
                    output_path,
                    "--summary-json",
                    summary_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "2",
                    "--hidden-nf",
                    "8",
                    "--n-layers",
                    "1",
                    "--inv-sublayers",
                    "1",
                    "--atom-cutoff",
                    "0",
                    "--orientation-cutoff",
                    "0",
                    "--fragment-graph-mode",
                    "distance",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(os.path.exists(output_path))
            self.assertTrue(os.path.exists(summary_path))
            with open(summary_path, "r") as handle:
                summary = json.load(handle)

        self.assertEqual(summary["model"], "egnn_overfit")
        self.assertEqual(summary["num_atoms"], 4)
        self.assertLess(summary["final_rmsd"], summary["start_rmsd"])
        self.assertIn("validation_warnings", summary)

    def test_overfit_cli_accepts_plateau_scheduler_args_and_records_them(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch is required for the EGNN overfit CLI")

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            target_path = os.path.join(tmpdir, "md_last.conf")
            output_path = os.path.join(tmpdir, "predicted.conf")
            summary_path = os.path.join(tmpdir, "summary.json")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)
            with open(target_path, "w") as handle:
                handle.write(TARGET_CONF)

            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_egnn_overfit.py",
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--target",
                    target_path,
                    "--output",
                    output_path,
                    "--summary-json",
                    summary_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "3",
                    "--hidden-nf",
                    "8",
                    "--n-layers",
                    "1",
                    "--inv-sublayers",
                    "1",
                    "--atom-cutoff",
                    "0",
                    "--orientation-cutoff",
                    "0",
                    "--fragment-graph-mode",
                    "distance",
                    "--lr-scheduler",
                    "plateau",
                    "--lr-scheduler-factor",
                    "0.5",
                    "--lr-scheduler-patience",
                    "1",
                    "--min-learning-rate",
                    "1e-5",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            with open(summary_path, "r") as handle:
                summary = json.load(handle)

        self.assertEqual(summary["lr_scheduler"], "plateau")
        self.assertEqual(summary["lr_scheduler_factor"], 0.5)
        self.assertEqual(summary["lr_scheduler_patience"], 1)
        self.assertEqual(summary["min_learning_rate"], 1e-5)
        self.assertIn("final_learning_rate", summary)

    def test_overfit_cli_can_save_and_reload_model_state(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch is required for the EGNN overfit CLI")

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            target_path = os.path.join(tmpdir, "md_last.conf")
            output_path = os.path.join(tmpdir, "predicted.conf")
            summary_path = os.path.join(tmpdir, "summary.json")
            state_path = os.path.join(tmpdir, "model_state.pt")
            resumed_output_path = os.path.join(tmpdir, "predicted_resumed.conf")
            resumed_summary_path = os.path.join(tmpdir, "summary_resumed.json")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)
            with open(target_path, "w") as handle:
                handle.write(TARGET_CONF)

            first = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_egnn_overfit.py",
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--target",
                    target_path,
                    "--output",
                    output_path,
                    "--summary-json",
                    summary_path,
                    "--save-model-state",
                    state_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "2",
                    "--hidden-nf",
                    "8",
                    "--n-layers",
                    "1",
                    "--inv-sublayers",
                    "1",
                    "--atom-cutoff",
                    "0",
                    "--orientation-cutoff",
                    "0",
                    "--fragment-graph-mode",
                    "distance",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )
            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertTrue(os.path.exists(state_path))

            second = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_egnn_overfit.py",
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--target",
                    target_path,
                    "--output",
                    resumed_output_path,
                    "--summary-json",
                    resumed_summary_path,
                    "--init-model-state",
                    state_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "1",
                    "--hidden-nf",
                    "8",
                    "--n-layers",
                    "1",
                    "--inv-sublayers",
                    "1",
                    "--atom-cutoff",
                    "0",
                    "--orientation-cutoff",
                    "0",
                    "--fragment-graph-mode",
                    "distance",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )
            self.assertEqual(second.returncode, 0, second.stderr)
            with open(resumed_summary_path, "r") as handle:
                summary = json.load(handle)

        self.assertEqual(summary["init_model_state"], os.path.abspath(state_path))
        self.assertIsNone(summary["save_model_state"])

    def test_overfit_cli_node_delta_residual_adapter_can_memorize_tiny_target(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch is required for the EGNN overfit CLI")

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            target_path = os.path.join(tmpdir, "md_last.conf")
            output_path = os.path.join(tmpdir, "predicted.conf")
            summary_path = os.path.join(tmpdir, "summary.json")
            state_path = os.path.join(tmpdir, "adapter_state.pt")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)
            with open(target_path, "w") as handle:
                handle.write(TARGET_CONF)

            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_egnn_overfit.py",
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--target",
                    target_path,
                    "--output",
                    output_path,
                    "--summary-json",
                    summary_path,
                    "--save-model-state",
                    state_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "80",
                    "--hidden-nf",
                    "8",
                    "--n-layers",
                    "1",
                    "--inv-sublayers",
                    "1",
                    "--atom-cutoff",
                    "0",
                    "--orientation-cutoff",
                    "0",
                    "--fragment-graph-mode",
                    "distance",
                    "--residual-adapter",
                    "node-delta",
                    "--freeze-egnn",
                    "--learning-rate",
                    "0.1",
                    "--grad-clip",
                    "0",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(os.path.exists(state_path))
            with open(summary_path, "r") as handle:
                summary = json.load(handle)

        self.assertEqual(summary["residual_adapter"], "node-delta")
        self.assertTrue(summary["freeze_egnn"])
        self.assertLess(summary["final_rmsd"], 0.05)

    def test_overfit_cli_identity_backbone_trains_only_node_delta_adapter(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch is required for the EGNN overfit CLI")

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            target_path = os.path.join(tmpdir, "md_last.conf")
            output_path = os.path.join(tmpdir, "predicted.conf")
            summary_path = os.path.join(tmpdir, "summary.json")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)
            with open(target_path, "w") as handle:
                handle.write(TARGET_CONF)

            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_egnn_overfit.py",
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--target",
                    target_path,
                    "--output",
                    output_path,
                    "--summary-json",
                    summary_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "80",
                    "--backbone",
                    "identity",
                    "--residual-adapter",
                    "node-delta",
                    "--learning-rate",
                    "0.1",
                    "--grad-clip",
                    "0",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            with open(summary_path, "r") as handle:
                summary = json.load(handle)

        self.assertEqual(summary["backbone"], "identity")
        self.assertEqual(summary["residual_adapter"], "node-delta")
        self.assertLess(summary["final_rmsd"], 0.05)
        self.assertLess(summary["final_os"], 0.9)

    def test_overfit_cli_node_rigid_adapter_memorizes_coordinates_and_orientation(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch is required for the EGNN overfit CLI")

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            target_path = os.path.join(tmpdir, "md_last.conf")
            output_path = os.path.join(tmpdir, "predicted.conf")
            summary_path = os.path.join(tmpdir, "summary.json")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)
            with open(target_path, "w") as handle:
                handle.write(TARGET_CONF)

            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_egnn_overfit.py",
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--target",
                    target_path,
                    "--output",
                    output_path,
                    "--summary-json",
                    summary_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "120",
                    "--backbone",
                    "identity",
                    "--residual-adapter",
                    "node-rigid",
                    "--learning-rate",
                    "0.1",
                    "--orientation-loss-weight",
                    "1.0",
                    "--grad-clip",
                    "0",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            with open(summary_path, "r") as handle:
                summary = json.load(handle)

        self.assertEqual(summary["residual_adapter"], "node-rigid")
        self.assertLess(summary["final_rmsd"], 0.05)
        self.assertGreater(summary["final_os"], 0.99)
        self.assertLess(summary["final_orientation_loss"], 0.01)

    def test_overfit_cli_shared_rigid_mlp_adapter_can_fit_tiny_target(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch is required for the EGNN overfit CLI")

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            target_path = os.path.join(tmpdir, "md_last.conf")
            output_path = os.path.join(tmpdir, "predicted.conf")
            summary_path = os.path.join(tmpdir, "summary.json")
            state_path = os.path.join(tmpdir, "shared_state.pt")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)
            with open(target_path, "w") as handle:
                handle.write(TARGET_CONF)

            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_egnn_overfit.py",
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--target",
                    target_path,
                    "--output",
                    output_path,
                    "--summary-json",
                    summary_path,
                    "--save-model-state",
                    state_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "300",
                    "--backbone",
                    "identity",
                    "--residual-adapter",
                    "shared-rigid-mlp",
                    "--shared-hidden-dim",
                    "64",
                    "--learning-rate",
                    "0.01",
                    "--orientation-loss-weight",
                    "1.0",
                    "--grad-clip",
                    "0",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(os.path.exists(state_path))
            with open(summary_path, "r") as handle:
                summary = json.load(handle)

        self.assertEqual(summary["residual_adapter"], "shared-rigid-mlp")
        self.assertEqual(summary["shared_hidden_dim"], 64)
        self.assertLess(summary["final_rmsd"], 0.2)
        self.assertGreater(summary["final_os"], 0.95)

    def test_overfit_cli_records_deepsnupi_style_electrostatic_energy(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch is required for the EGNN overfit CLI")

        with tempfile.TemporaryDirectory() as tmpdir:
            top_path = os.path.join(tmpdir, "tiny.top")
            start_path = os.path.join(tmpdir, "start.conf")
            target_path = os.path.join(tmpdir, "md_last.conf")
            output_path = os.path.join(tmpdir, "predicted.conf")
            summary_path = os.path.join(tmpdir, "summary.json")
            with open(top_path, "w") as handle:
                handle.write(TOPOLOGY_TEXT)
            with open(start_path, "w") as handle:
                handle.write(START_CONF)
            with open(target_path, "w") as handle:
                handle.write(TARGET_CONF)

            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ebd_oxdna_egnn_overfit.py",
                    "--top",
                    top_path,
                    "--start",
                    start_path,
                    "--target",
                    target_path,
                    "--output",
                    output_path,
                    "--summary-json",
                    summary_path,
                    "--device",
                    "cpu",
                    "--epochs",
                    "20",
                    "--backbone",
                    "identity",
                    "--residual-adapter",
                    "node-rigid",
                    "--learning-rate",
                    "0.1",
                    "--orientation-loss-weight",
                    "1.0",
                    "--electrostatic-loss-weight",
                    "0.01",
                    "--electrostatic-cutoff",
                    "5.0",
                    "--grad-clip",
                    "0",
                ],
                cwd=os.getcwd(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            with open(summary_path, "r") as handle:
                summary = json.load(handle)

        self.assertEqual(summary["electrostatic_loss_weight"], 0.01)
        self.assertEqual(summary["electrostatic_cutoff"], 5.0)
        self.assertGreater(summary["electrostatic_edge_count"], 0)
        self.assertIsNotNone(summary["start_electrostatic_energy"])
        self.assertIsNotNone(summary["final_electrostatic_energy"])

    def test_overfit_cli_logs_to_wandb_when_enabled(self):
        import scripts.ebd_oxdna_egnn_overfit as overfit

        calls = []

        fake_wandb = types.SimpleNamespace()
        fake_wandb.Settings = lambda **kwargs: ("settings", kwargs)
        fake_wandb.login = lambda key=None: calls.append(("login", key))
        fake_wandb.init = lambda **kwargs: calls.append(("init", kwargs))
        fake_wandb.log = lambda payload, step=None: calls.append(("log", payload, step))
        fake_wandb.finish = lambda: calls.append(("finish",))

        with mock.patch.dict(sys.modules, {"wandb": fake_wandb}):
            with mock.patch.dict(
                os.environ,
                {
                    "WANDB_API_KEY": "a" * 40,
                    "WANDB_PROJECT": "deeporigami",
                    "WANDB_ENTITY": "hbjzhxlxx-",
                    "WANDB_NAME": "unit-run",
                    "WANDB_RUN_GROUP": "unit-group",
                    "WANDB_TAGS": "geodiff,unit",
                },
                clear=False,
            ):
                run = overfit.WandbRun.create(
                    enabled=True,
                    config={"epochs": 2},
                    mode="online",
                )
                run.log_epoch(epoch=1, loss=2.0, rmsd=3.0, best_rmsd=3.0, learning_rate=0.001)
                run.log_summary({"final_rmsd": 1.5, "best_epoch": 1})
                run.finish()

        self.assertEqual(calls[0], ("login", "a" * 40))
        self.assertEqual(calls[1][0], "init")
        self.assertEqual(calls[1][1]["project"], "deeporigami")
        self.assertEqual(calls[1][1]["name"], "unit-run")
        self.assertEqual(calls[1][1]["group"], "unit-group")
        self.assertEqual(calls[1][1]["tags"], ["geodiff", "unit"])
        self.assertEqual(calls[2], ("log", {"train/loss": 2.0, "train/rmsd": 3.0, "train/best_rmsd": 3.0, "train/lr": 0.001}, 1))
        self.assertEqual(calls[3], ("log", {"summary/final_rmsd": 1.5, "summary/best_epoch": 1}, None))
        self.assertEqual(calls[4], ("finish",))

    def test_overfit_cli_accepts_non_40_char_wandb_key(self):
        import scripts.ebd_oxdna_egnn_overfit as overfit

        calls = []

        fake_wandb = types.SimpleNamespace()
        fake_wandb.Settings = lambda **kwargs: ("settings", kwargs)
        fake_wandb.login = lambda key=None: calls.append(("login", key))
        fake_wandb.init = lambda **kwargs: calls.append(("init", kwargs))
        fake_wandb.log = lambda payload, step=None: calls.append(("log", payload, step))
        fake_wandb.finish = lambda: calls.append(("finish",))

        with mock.patch.dict(sys.modules, {"wandb": fake_wandb}):
            with mock.patch.dict(
                os.environ,
                {
                    "WANDB_API_KEY": "export WANDB_API_KEY=" + ("b" * 64),
                    "WANDB_PROJECT": "deeporigami",
                },
                clear=False,
            ):
                run = overfit.WandbRun.create(
                    enabled=True,
                    config={"epochs": 2},
                    mode="online",
                )
                run.finish()

        self.assertEqual(calls[0][0], "init")
        self.assertEqual(calls[0][1]["project"], "deeporigami")
        self.assertEqual(calls[1], ("finish",))


if __name__ == "__main__":
    unittest.main()
