import copy
import hashlib
import json
import os
import pickle
import tempfile
import unittest
from pathlib import Path

from ebd_oxdna.design_edges import build_design_edge_sidecar
from ebd_oxdna.design_edges import build_typed_graph
from ebd_oxdna.design_edges import load_design_edge_sidecar
from ebd_oxdna.design_edges import load_design_edge_sidecar_index
from ebd_oxdna.adapter import load_oxdna_sample
from scripts import build_talos240_design_edge_sidecars as sidecar_cli


TOPOLOGY = """8 2
1 A -1 1
1 C 0 2
1 G 1 3
1 T 2 -1
2 A -1 5
2 C 4 6
2 G 5 7
2 T 6 -1
"""


def _sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _write_config(path, positions, time_value=50):
    lines = ["t = {}".format(time_value), "b = 20 20 20", "E = 0 0 0"]
    for x, y, z in positions:
        lines.append(
            "{} {} {} 1 0 0 0 0 1 0 0 0 0 0 0".format(x, y, z)
        )
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def _cadnano_payload():
    empty = [-1, -1, -1, -1]
    return {
        "name": "toy",
        "vstrands": [
            {
                "num": 7,
                "row": 0,
                "col": 0,
                "scaf": [
                    [-1, -1, 7, 1],
                    [7, 0, 8, 0],
                ],
                "stap": [
                    [7, 1, -1, -1],
                    [8, 0, 7, 0],
                ],
                "loop": [0, 0],
                "skip": [0, 0],
                "scafLoop": [0, 0],
                "stapLoop": [0, 0],
                "stap_colors": [],
            },
            {
                "num": 8,
                "row": 0,
                "col": 1,
                "scaf": [
                    [7, 1, 8, 1],
                    [8, 0, -1, -1],
                ],
                "stap": [
                    [8, 1, 7, 1],
                    [-1, -1, 8, 0],
                ],
                "loop": [0, 0],
                "skip": [0, 0],
                "scafLoop": [0, 0],
                "stapLoop": [0, 0],
                "stap_colors": [],
            },
        ],
    }


def _virt2nuc_payload(override=None):
    payload = {
        "_scaf": {
            (7, 0): (0, [0]),
            (7, 1): (0, [1]),
            (8, 0): (0, [2]),
            (8, 1): (0, [3]),
        },
        "_stap": {
            (7, 0): (1, [7]),
            (7, 1): (1, [6]),
            (8, 0): (1, [5]),
            (8, 1): (1, [4]),
        },
        "nuc_count": 8,
        "strand_count": 2,
    }
    if override:
        override(payload)
    return (payload, {1: (0, 0)})


def _write_fixture(root, sample_id="toy", virt_override=None):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    top = root / "toy.top"
    start = root / "start.conf"
    target = root / "target.conf"
    cadnano = root / "design.json"
    virt2nuc = root / "virt2nuc"
    top.write_text(TOPOLOGY, encoding="utf-8")
    positions = [(float(index), 0.0, 0.0) for index in range(4)] + [
        (float(index), 3.0, 0.0) for index in range(4)
    ]
    _write_config(start, positions, 50)
    _write_config(target, [(x + 10.0, y, z) for x, y, z in positions], 2_000_000)
    cadnano.write_text(
        json.dumps(_cadnano_payload(), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    with virt2nuc.open("wb") as handle:
        pickle.dump(_virt2nuc_payload(virt_override), handle, protocol=4)
    return {
        "id": sample_id,
        "top": str(top),
        "start": str(start),
        "target": str(target),
        "cadnano_json": str(cadnano),
        "virt2nuc": str(virt2nuc),
        "artifact_sha256": {
            "top": _sha256(top),
            "start": _sha256(start),
            "target": _sha256(target),
            "cadnano_json": _sha256(cadnano),
            "virt2nuc": _sha256(virt2nuc),
        },
    }


class DesignEdgeSidecarTests(unittest.TestCase):
    def test_builds_complete_pairs_crossovers_and_duplex_annotations(self):
        with tempfile.TemporaryDirectory() as tmp:
            entry = _write_fixture(tmp)

            sidecar = build_design_edge_sidecar(entry)

        self.assertEqual(sidecar["schema_version"], 1)
        self.assertEqual(sidecar["sample_id"], "toy")
        self.assertEqual(sidecar["num_nodes"], 8)
        self.assertEqual(
            sidecar["edges"]["base_pair"],
            [[0, 7], [1, 6], [2, 5], [3, 4]],
        )
        self.assertEqual(sidecar["edges"]["crossover"], [[1, 2], [5, 6]])
        self.assertEqual(
            sidecar["edges"]["duplex_step"],
            [[0, 1], [1, 2], [2, 3], [4, 5], [5, 6], [6, 7]],
        )
        # (7, 0) scaffold and (8, 1) staple are strand starts with occupancy
        # only in caDNAno columns 2:4. The old loader incorrectly dropped them.
        self.assertIn([0, 7], sidecar["edges"]["base_pair"])
        self.assertIn([3, 4], sidecar["edges"]["base_pair"])
        self.assertEqual(sidecar["counts"]["base_pair"], 4)

    def test_target_geometry_cannot_change_sidecar_or_fingerprint(self):
        with tempfile.TemporaryDirectory() as tmp:
            entry = _write_fixture(tmp)
            before = build_design_edge_sidecar(entry)
            _write_config(
                entry["target"],
                [(float(index) * 100.0, 80.0, -40.0) for index in range(8)],
                2_000_000,
            )
            entry["artifact_sha256"]["target"] = _sha256(entry["target"])

            after = build_design_edge_sidecar(entry)

        self.assertEqual(before, after)
        self.assertNotIn("target", before["sources"])

    def test_start_spatial_edges_are_optional_and_bound_only_to_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            entry = _write_fixture(tmp)
            without_spatial = build_design_edge_sidecar(entry)
            with_spatial = build_design_edge_sidecar(
                entry,
                include_start_spatial=True,
                spatial_cutoff=1.1,
                max_spatial_neighbors=1,
            )
            expected_start_sha256 = _sha256(entry["start"])

        self.assertEqual(without_spatial["edges"]["start_spatial"], [])
        self.assertNotIn("start", without_spatial["sources"])
        self.assertTrue(with_spatial["edges"]["start_spatial"])
        self.assertEqual(with_spatial["sources"]["start"]["sha256"], expected_start_sha256)
        self.assertEqual(with_spatial["spatial_parameters"]["cutoff"], 1.1)
        self.assertEqual(with_spatial["spatial_parameters"]["max_neighbors"], 1)

    def test_load_validates_source_hashes_and_sidecar_fingerprint(self):
        with tempfile.TemporaryDirectory() as tmp:
            entry = _write_fixture(tmp)
            sidecar = build_design_edge_sidecar(entry)
            path = Path(tmp) / "toy.design_edges.json"
            path.write_text(
                json.dumps(sidecar, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )

            loaded = load_design_edge_sidecar(path, entry)
            self.assertEqual(loaded, sidecar)

            cadnano = Path(entry["cadnano_json"])
            cadnano.write_text(cadnano.read_text() + " ", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "sha256 mismatch"):
                load_design_edge_sidecar(path, entry)

            tampered = copy.deepcopy(sidecar)
            tampered["edges"]["base_pair"][0] = [0, 6]
            path.write_text(json.dumps(tampered), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "fingerprint mismatch"):
                load_design_edge_sidecar(path, entry)

    def test_missing_sidecar_or_required_source_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            entry = _write_fixture(tmp)
            missing = Path(tmp) / "missing.json"
            self.assertIsNone(load_design_edge_sidecar(missing, entry, required=False))
            with self.assertRaisesRegex(ValueError, "missing design-edge sidecar"):
                load_design_edge_sidecar(missing, entry, required=True)

            Path(entry["virt2nuc"]).unlink()
            with self.assertRaisesRegex(ValueError, "missing virt2nuc"):
                build_design_edge_sidecar(entry)

    def test_ambiguous_conflicting_and_out_of_range_maps_are_rejected(self):
        cases = {
            "ambiguous": (
                lambda payload: payload["_scaf"].__setitem__((7, 0), (0, [0, 1])),
                "ambiguous",
            ),
            "conflicting": (
                lambda payload: payload["_stap"].__setitem__((7, 1), (1, [7])),
                "more than one partner",
            ),
            "out_of_range": (
                lambda payload: payload["_stap"].__setitem__((7, 0), (1, [99])),
                "out of range",
            ),
        }
        for name, (override, message) in cases.items():
            with self.subTest(name=name), tempfile.TemporaryDirectory() as tmp:
                entry = _write_fixture(tmp, virt_override=override)
                with self.assertRaisesRegex(ValueError, message):
                    build_design_edge_sidecar(entry)

    def test_zero_converter_counts_are_ignored_only_when_mapping_is_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            entry = _write_fixture(
                Path(tmp) / "complete",
                virt_override=lambda payload: payload.update(
                    {"nuc_count": 0, "strand_count": 0}
                ),
            )
            sidecar = build_design_edge_sidecar(entry)
            self.assertEqual(sidecar["num_nodes"], 8)

            mismatched = _write_fixture(
                Path(tmp) / "mismatched",
                virt_override=lambda payload: payload.update({"nuc_count": 7}),
            )
            with self.assertRaisesRegex(ValueError, "nuc_count 7"):
                build_design_edge_sidecar(mismatched)

    def test_crossover_must_be_a_real_topology_backbone_link(self):
        with tempfile.TemporaryDirectory() as tmp:
            entry = _write_fixture(tmp)
            top = Path(entry["top"])
            top.write_text(
                TOPOLOGY.replace("1 C 0 2", "1 C 0 3").replace(
                    "1 G 1 3", "1 G 0 3"
                ),
                encoding="utf-8",
            )
            entry["artifact_sha256"]["top"] = _sha256(top)
            with self.assertRaisesRegex(ValueError, "crossover.*not a backbone"):
                build_design_edge_sidecar(entry)

    def test_batch_cli_writes_checksum_bound_index_and_loadable_sidecars(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            first = _write_fixture(root / "first", sample_id="first")
            second = _write_fixture(root / "second", sample_id="second")
            manifest = root / "manifest.json"
            manifest.write_text(
                json.dumps([second, first], indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            output = root / "sidecars"

            exit_code = sidecar_cli.main(
                [
                    "--manifest",
                    str(manifest),
                    "--output-dir",
                    str(output),
                    "--include-start-spatial",
                    "--spatial-cutoff",
                    "1.1",
                    "--max-spatial-neighbors",
                    "1",
                ]
            )

            self.assertEqual(exit_code, 0)
            index = json.loads(
                (output / "design_edge_sidecars.json").read_text(encoding="utf-8")
            )
            self.assertEqual(list(index["sidecars"]), ["first", "second"])
            self.assertEqual(index["manifest_sha256"], _sha256(manifest))
            for entry in (first, second):
                record = index["sidecars"][entry["id"]]
                path = Path(record["path"])
                self.assertEqual(record["sha256"], _sha256(path))
                load_design_edge_sidecar(path, entry)
            check = os.system(
                "cd '{}' && sha256sum -c ARTIFACT_SHA256SUMS >/dev/null".format(
                    output
                )
            )
            self.assertEqual(check, 0)

    def test_typed_graph_has_fixed_multihot_relations_across_ablation_arms(self):
        with tempfile.TemporaryDirectory() as tmp:
            entry = _write_fixture(tmp)
            sidecar = build_design_edge_sidecar(
                entry,
                include_start_spatial=True,
                spatial_cutoff=1.1,
                max_spatial_neighbors=1,
            )
            sidecar["edges"]["start_spatial"] = [[0, 4]]
            sidecar["counts"]["start_spatial"] = 1
            sample = load_oxdna_sample(entry["top"], entry["start"])

            arms = {
                "B0": {},
                "B1": {"pair": True},
                "B2": {"crossover": True},
                "B3": {"duplex_step": True},
                "B4": {"pair": True, "crossover": True, "duplex_step": True},
                "B5": {
                    "pair": True,
                    "crossover": True,
                    "duplex_step": True,
                    "start_spatial": True,
                },
            }
            graphs = {
                name: build_typed_graph(sample, sidecar, **enabled)
                for name, enabled in arms.items()
            }

        for graph in graphs.values():
            self.assertEqual(graph["relation_names"], [
                "backbone_forward",
                "backbone_reverse",
                "crossover",
                "base_pair",
                "duplex_step",
                "start_spatial",
            ])
            self.assertTrue(all(len(row) == 6 for row in graph["relations"]))
        self.assertEqual(len(graphs["B0"]["edges"]), 12)
        self.assertEqual(len(graphs["B1"]["edges"]), 20)
        self.assertEqual(len(graphs["B2"]["edges"]), 12)
        self.assertEqual(len(graphs["B3"]["edges"]), 12)
        self.assertEqual(len(graphs["B4"]["edges"]), 20)
        self.assertEqual(len(graphs["B5"]["edges"]), 22)

        b4 = dict(zip(map(tuple, graphs["B4"]["edges"]), graphs["B4"]["relations"]))
        self.assertEqual(b4[(0, 7)], [0, 0, 0, 1, 0, 0])
        self.assertEqual(b4[(7, 0)], [0, 0, 0, 1, 0, 0])
        self.assertEqual(b4[(1, 2)], [1, 0, 1, 0, 1, 0])
        self.assertEqual(b4[(2, 1)], [0, 1, 1, 0, 1, 0])
        self.assertEqual(graphs["B0"]["relation_counts"]["base_pair"], 0)
        self.assertEqual(graphs["B4"]["relation_counts"]["base_pair"], 8)
        self.assertEqual(graphs["B5"]["relation_counts"]["start_spatial"], 2)

    def test_sidecar_index_binds_manifest_membership_and_sidecar_bytes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            entry = _write_fixture(root / "sample")
            manifest = root / "manifest.json"
            manifest.write_text(
                json.dumps([entry], indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            output = root / "sidecars"
            sidecar_cli.build_sidecars(manifest, output)
            index_path = output / "design_edge_sidecars.json"

            loaded = load_design_edge_sidecar_index(
                index_path,
                manifest_sha256=_sha256(manifest),
                entries=[entry],
            )
            self.assertEqual(set(loaded["sidecars"]), {"toy"})
            self.assertEqual(loaded["index_sha256"], _sha256(index_path))

            with self.assertRaisesRegex(ValueError, "manifest SHA-256"):
                load_design_edge_sidecar_index(
                    index_path,
                    manifest_sha256="0" * 64,
                    entries=[entry],
                )

            sidecar_path = Path(loaded["sidecars"]["toy"])
            sidecar_path.write_text(sidecar_path.read_text() + " ", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "sidecar SHA-256"):
                load_design_edge_sidecar_index(
                    index_path,
                    manifest_sha256=_sha256(manifest),
                    entries=[entry],
                )


if __name__ == "__main__":
    unittest.main()
