# HADO oxDNA model-repair reproducibility bundle

This bundle contains the smallest verified H101-H103 development set for reproducing the FENE-safe kinematic-GNN experiment and testing revised model architectures against oxDNA.

## Contents

- `data/H101`--`H103`: Initial and Prepared oxDNA configurations and matching topologies.
- `code/`: kinematic decoder, physical/FENE helpers, baseline model, and training helpers.
- `scripts/`: static acceptance, native 100-step oxDNA execution, and kinematic micro-training.
- `models/onepass_A_20261007.pt`: baseline checkpoint used for the comparison.
- `bin/oxDNA_cpu`: the tested CPU oxDNA executable; rebuild from the official oxDNA source if the target platform is incompatible.
- `results/`: prior kinematic result and control log.
- `docs/`: Harness 08 and progress records.

## Environment

The original run used Python 3.10, PyTorch 2.6 CUDA environment, NumPy, SciPy and the repository's `geometry_io`, `pipeline`, and `transfer_operator` helper modules. Those helper modules are not bundled as independent upstream packages; adapt the three scripts' imports or install the corresponding project modules in the target environment.

## Reproduction order

1. Verify the executable: `bin/oxDNA_cpu --help` (or run it from a work directory containing `system.top`, `start.dat`, and `input`).
2. Run the Prepared control first; it should complete 100 steps with stable energy.
3. Run the Initial control; it is intentionally an invalid source control and aborts on H101-H103.
4. Run `scripts/train_kinematic_micro.py` only after adapting the helper-module import paths.
5. Use `scripts/run_hidden256_physical_acceptance.py` or `scripts/run_ai_geometry_projection_experiment.py` for the fixed acceptance audit.

The key scientific acceptance criterion is native oxDNA completion plus the post-run geometry/energy audit. Static FENE legality alone is insufficient: the earlier kinematic model had zero initial FENE outliers but lost almost all pairing/crossover geometry and became dynamically unstable.
