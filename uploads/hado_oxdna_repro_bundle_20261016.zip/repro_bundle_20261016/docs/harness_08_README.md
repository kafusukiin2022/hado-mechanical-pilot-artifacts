# FENE-aware graph features and constrained output layer

Status: **in progress; FENE edge and kinematic prototypes tested; no physical pass** (2026-10-16).

## Question

Can the oxDNA2 backbone FENE condition be represented directly in the graph and enforced after coordinate prediction, improving real oxDNA restart acceptance?

## Hypothesis

Per-edge FENE metadata can help a graph predictor learn which backbone bonds are strained. A differentiable interval projection on the actual DNA2 backbone interaction sites can reduce hard FENE violations more directly than a weighted penalty. Neither is expected to guarantee global packing, orientation, or dynamical stability, so oxDNA remains the primary acceptance oracle.

## Methods under comparison

- **A — baseline:** frozen existing one-pass model, no FENE edge channels and no output projection.
- **B — edge features:** train a fresh matched model with six invariant FENE channels on directed backbone graph edges; no output projection.
- **C — edge features + projection:** same initialization, split, optimizer, step budget, and loss as B, with a differentiable interval projection applied to the predicted coordinates before supervised and physical losses.

The new edge channels are intended to encode backbone-edge identity, rest length, safe lower/upper thresholds, current signed length strain, and normalized margin to the nearest safe boundary. The projection must compute the oxDNA2 backbone interaction site from position and orientation; nucleotide-center distance is not the constraint. The soft training interval uses a safety margin inside the hard oxDNA interval. A finite number of projection iterations is not a proof of feasibility for a coupled graph and must be measured after projection.

## Current evidence

1. The earlier weighted-loss experiment reduced its typed-site overlap proxy by about two orders of magnitude but increased FENE violations; all H101–H103 restart attempts failed. See `../../analysis/oxdna_restart_guided_20261016/README.md`.
2. The first staged FENE-first experiment projected H101–H103 to zero static FENE outliers (minimum-to-maximum backbone distances approximately 0.526–0.985 oxDNA units). Its excluded-volume phase accepted only 2–3 updates before the FENE-preserving line search stalled. All three oxDNA 100-step runs became unstable, with energies around 10^12 and maximum recorded backbone distances around 196–291 oxDNA units. Thus static FENE repair alone is insufficient.
3. A differentiable edge-feature encoder and interval projection primitive have been added to `ml_pilot/restart_guided_loss.py`. The CUDA component smoke test passed: two six-channel edge features were finite, deliberately strained distances 1.300/1.154 were projected to 0.988/0.987, surrogate loss fell from 0.0699 to 0.00268, and gradients remained finite. Receipt: `receipts/component_smoke.json`.

## First matched B/C micro-pilot

The fresh 26-channel models were trained for 40 epochs on H101–H103 with the same seed and optimizer schedule. A is the existing 20-channel checkpoint. B adds the six FENE edge channels; C adds a three-iteration backbone-site projection. Results are in `analysis/oxdna_restart_guided_20261016/fene_graph_ablation/results_A_B_C_3iters.json`.

| route | H101 FENE outliers | H102 | H103 | H101/H102/H103 nonbonded clash counts | native oxDNA 100-step |
|---|---:|---:|---:|---:|---|
| A baseline | 3,678 | 3,419 | 3,351 | 13,887 / 13,602 / 14,857 | startup fail |
| B edge features | 1,014 | 776 | 555 | 12,213 / 11,209 / 9,643 | startup fail |
| C + 3 projections | 392 | 652 | 301 | 12,427 / 12,783 / 10,561 | startup fail |

The edge-aware model reduced both FENE violations and the broad clash screen, but none passed oxDNA. A second C20 run with 20 projection iterations reduced FENE outliers to 11/50/45 and clashes to 8,077/8,947/8,363, yet still failed immediately at a remaining bond distance of 1.0077–1.0189. Receipt: `analysis/oxdna_restart_guided_20261016/fene_graph_ablation/results_C20.json`.

This is evidence that graph edge semantics and projection are useful intermediate signals, not physical acceptance. The residual violations are coupled-edge conflicts: local projection of one bond can push another outside the interval. The next implementation should use colored constraint sweeps or a convergent feasibility layer, then add typed site repulsion and orientation terms. It is premature to start full 400-design training.

## Kinematic decoder prototype

The proposed larger redesign is now prototyped in
`ml_pilot/kinematic_dna_decoder.py`. It uses a separate ordered recursion for
each strand, predicts bounded relative lengths and local directions, updates
frames through SO(3) exponentials, and derives nucleotide centres from the
oxDNA2 fixed backbone-site offset. A QR re-orthogonalization keeps long-chain
frame drift below the format tolerance. A real H101 topology smoke test
reconstructed 110 strands, 8,810 backbone edges and 8,920 nucleotides. The
resulting backbone-site distances were 0.756225–0.756490, versus the safe
interval 0.5264–0.9864; FENE outliers were 0, rotation orthogonality error was
3.6e-7, and gradients were finite. Receipt:
`receipts/kinematic_model_smoke.json`.

This is a structural guarantee of the decoder, not a trained model result:
the randomly initialized decoder had coordinate loss 491.86. It also does not
handle crossovers, base-pair closure, dynamic contacts, chain crossing, or
oxDNA dynamics yet. Those must be added as separate factors after the strand
decoder is trained against the endpoint data.

### Three-design kinematic model fit

A fresh `KinematicSE3Predictor(hidden=64, depth=2)` was trained for 40 epochs
on H101–H103 using endpoint coordinate loss. The decoder kept **zero static
FENE violations** on all three designs, but the fit was poor and the physical
test failed:

| design | baseline coordinate RMSE | kinematic RMSE | base-pair mean distance | 100-step oxDNA |
|---|---:|---:|---:|---|
| H101 | 6.95 | 39.90 | 87.63 | unstable; max backbone distance 157.25, energy max 1.09e10 |
| H102 | 9.13 | 50.42 | 110.34 | unstable; max backbone distance 243.00, energy max 8.52e9 |
| H103 | 8.46 | 49.80 | 84.87 | unstable; max backbone distance 144.63, energy max 1.42e10 |

Full receipt and checkpoint: `analysis/oxdna_restart_guided_20261016/kinematic_micro/results.json` and `kinematic_micro.pt`. The model demonstrates hard local FENE feasibility, but a long autoregressive strand accumulates relative-pose error and independently anchored strands lose pairing/crossover closure. This directly motivates the pose-graph/factor-graph part of the proposal: cross-strand pairing, crossovers and segment anchors must constrain the global reconstruction. A backbone-only kinematic decoder is therefore insufficient and should not be scaled as-is.

### Clarification: engine completion versus acceptance

For these three kinematic runs, oxDNA itself did **not** abort at startup:
each `run.log` ends with `END OF THE SIMULATION, everything went OK!`. The
project acceptance wrapper nevertheless records `completed=false` because it
requires the post-run geometry and energy audit to pass. At step 0, the
written configurations had zero static FENE outliers, but the native-pair
distance medians were 92.39, 109.62 and 88.65 oxDNA units for H101–H103;
4,296/4,298, 4,043/4,045 and 3,723/3,723 pairs were farther than 2 units.
The initial potential energies were 8.42e4, 5.04e6 and 2.81e6, then rose to
1.09e10, 8.52e9 and 1.42e10 by step 100. The last frames had 97, 71 and 109
FENE outliers. Thus the failure is a **dynamic stability/closure failure**,
not a startup FENE rejection and not simply a coordinate-RMSE threshold.

The project's differentiable DNA2 energy evaluator decomposes the step-0
structures and identifies the likely immediate numerical source (this is a
surrogate decomposition; native oxDNA logs only the aggregate energy here).
Its FENE terms were only 25.4, 26.0 and 21.8, while bonded
excluded-volume terms were 1.02e8, 4.17e10 and 1.76e7, and nonbonded
excluded-volume terms were 6.49e8, 3.28e8 and 2.15e10 for H101–H103.
Hydrogen-bonding was effectively zero because the paired strands were far
apart. The native aggregate energies independently confirm severe initial
energy (8.42e4, 5.04e6, 2.81e6). Thus FENE legality removes the backbone spring singularity but does not
prevent other oxDNA interaction sites from overlapping. Those enormous
repulsive forces drive the later energy and FENE blow-up.

## Frozen pilot protocol

### 2026-10-16 control and refinement follow-up

The same 100-step acceptance protocol was run on source Initial and
corresponding Prepared files for H101--H103. All Initial files abort before a
trajectory because oxDNA reports bonded-neighbor distances 1.950, 4.135, and
3.535; all Prepared controls complete with zero final FENE outliers and energy
jumps below 0.005. The protocol and binary are therefore functional, while
the source Initial files are not dynamically valid controls.

For H101, 128 iterations of the existing dynamic interaction-site projection
kept static FENE valid but changed the broad clash screen only 84 -> 78;
4,296/4,298 native pairs remained farther than 2 and every restart reached
about 5e9--1.1e10 energy with post-run FENE failures. Pose blending toward
Prepared was unstable at intermediate weights and passed only at the Prepared
endpoint. Local projection/interpolation cannot replace globally constrained
pairing and crossover closure.

Receipts: `analysis/oxdna_restart_guided_20261016/initial_control/`,
`prepared_control/`, `contact_refinement/H101/results.json`, and
`pose_blend/H101/results.json`.

- Development designs: H101–H103 only; they are method-development samples, not a generalization set.
- Keep checkpoint/data split and oxDNA executable/protocol fixed across A/B/C.
- B and C must be trained from the same initialization with matched steps and optimizer; no test-set model selection.
- Record endpoint coordinate error, FENE distance quantiles and violation count, typed-site overlaps, initial energy, projection displacement, and standard oxDNA 100-step acceptance/error.
- A candidate is physically accepted only if native oxDNA completes and its output geometry/energy audit passes. Static surrogate improvement is not acceptance.
- Do not begin full 400-design training until B/C smoke and a predeclared small validation gate pass.

## Current interpretation and next steps

An explicit graph edge feature is a **learned hint**, not a hard constraint. The output projection is the mechanism that directly repairs backbone-site distances, while FENE and repulsion losses teach the predictor to need less repair. The projection must be periodic-boundary aware, differentiable, and evaluated after orientation updates. Because the previous structures retained thousands of nonbonded overlaps and diverged dynamically, the next acceptance work must retain typed repulsion and add orientation/packing diagnostics rather than optimize FENE alone.

Next: replace the current Jacobi-style simultaneous corrections with colored sequential constraint sweeps or a feasibility solver; include periodic boundary handling; combine the constraint with typed-site repulsion and orientation-aware terms; then rerun the same native acceptance protocol. Keep the three-design result as method development only.

## Artifacts

- Feature/projection primitives: `ml_pilot/restart_guided_loss.py`
- Previous staged projection script and receipts: `scripts/run_fene_first_refinement.py`, `analysis/oxdna_restart_guided_20261016/fene_first/results.json`
- Earlier differentiable weighted loss: `ml_pilot/restart_guided_loss.py`
