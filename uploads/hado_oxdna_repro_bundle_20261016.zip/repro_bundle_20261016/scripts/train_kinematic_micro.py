#!/usr/bin/env python3
"""Tiny training-capacity check for the FENE-safe kinematic GNN head."""
import json,sys,random,time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'ml_pilot'),str(ROOT/'scripts'),str(ROOT.parent/'flowmatching')]
from train_onepass_ablation import load_cache,model_input
from onepass_model import OnePassSE3Predictor
from kinematic_dna_decoder import KinematicSE3Predictor,backbone_site_from_center,FENE_R0,FENE_DELTA
from run_hidden256_physical_acceptance import restart_text,static_metrics
from run_ai_geometry_projection_experiment import run_md
from geometry_io import read_top

IDS=('H101','H102','H103');CACHE=ROOT/'ml_pilot/cache_onepass_20261007';CKPT=ROOT/'ml_pilot/results/onepass_ablation_20261007/onepass_A_20261007.pt';MANIFEST=ROOT/'ml_pilot/results/onepass_family_split_20261007.json';OUT=ROOT/'analysis/oxdna_restart_guided_20261016/kinematic_micro'

def ordered_strands(top):
 out=[]
 for sid in sorted(np.unique(top['strand'])):
  ids=np.flatnonzero(top['strand']==sid); ends=[i for i in ids if top['n3'][i]<0];cur=int(ends[0] if ends else ids.min());order=[];seen=set()
  while cur>=0 and cur not in seen:order.append(cur);seen.add(cur);cur=int(top['n5'][cur])
  if len(order)!=len(ids):raise RuntimeError('invalid backbone strand topology')
  out.append(order)
 return out

def main():
 torch.manual_seed(20261016);np.random.seed(20261016);random.seed(20261016)
 dev=torch.device('cuda:0' if torch.cuda.is_available() else 'cpu');torch.cuda.set_device(dev) if dev.type=='cuda' else None
 ck=torch.load(CKPT,map_location='cpu',weights_only=False);scale=float(ck['config']['scale'])
 manifest={r['design_id']:r for r in json.loads(MANIFEST.read_text())['rows']};data={};orders={}
 for ident in IDS:
  d=load_cache(CACHE/(ident+'.npz'),dev);top=read_top(ROOT/manifest[ident]['initial_top']);data[ident]=d;orders[ident]=ordered_strands(top)
 m=KinematicSE3Predictor(6,64,2,20,margin=.02).to(dev);opt=torch.optim.AdamW(m.parameters(),lr=1e-4,weight_decay=1e-6);history=[];start=time.time()
 def pred(ident):
  d=data[ident];kw=model_input(d,dev,scale);kw.pop('energy_pair_index',None);kw.pop('energy_pair_features',None)
  source=torch.as_tensor(d['pos0']+d['source_center'],device=dev)
  return m(**kw,strand_orders=orders[ident],anchor_position=source,reference_position=source)
 with torch.no_grad():
  baseline={}
  base=OnePassSE3Predictor(6,256,3,20,False,False).to(dev);base.load_state_dict(ck['model']);base.eval()
  for ident,d in data.items():
   o=base(**model_input(d,dev,scale));p=o['position']*scale+torch.as_tensor(d['source_center'],device=dev);t=torch.as_tensor(d['pos1']+d['source_center'],device=dev);baseline[ident]=float(torch.sqrt(torch.mean((p-t)**2)))
 for epoch in range(1,41):
  m.train();losses=[]
  for ident in IDS:
   opt.zero_grad(set_to_none=True);out=pred(ident);target=torch.as_tensor(data[ident]['pos1']+data[ident]['source_center'],device=dev)
   loss=F.smooth_l1_loss((out['position']-target)/scale,torch.zeros_like(target));loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.0);opt.step();losses.append(float(loss.detach()))
  if epoch in (1,5,10,20,30,40):history.append({'epoch':epoch,'mean_smooth_l1':float(np.mean(losses))});print(json.dumps(history[-1]),flush=True)
 m.eval();records=[]
 with torch.no_grad():
  for ident,d in data.items():
   out=pred(ident);p=out['position'].cpu().numpy();r=out['rotation'].cpu().numpy();target=d['pos1']+d['source_center'];edges=d['backbone_edges'];dist=np.linalg.norm((p[edges[1]]-.34*r[edges[1],:,0]+.3408*np.cross(r[edges[1],:,2],r[edges[1],:,0]))-(p[edges[0]]-.34*r[edges[0],:,0]+.3408*np.cross(r[edges[0],:,2],r[edges[0],:,0])),axis=-1)
   sm=static_metrics(p,r,d['box'],edges.T,d['base_pairs'].T);top=ROOT/manifest[ident]['initial_top'];ddir=OUT/ident;ddir.mkdir(parents=True,exist_ok=True);dat=ddir/'structure.dat';dat.write_text(restart_text(ROOT/manifest[ident]['initial_dat'],p,r[...,0],r[...,2]));md=run_md(ddir/'md100',top,dat,100,timeout=120)
   rec={'design_id':ident,'baseline_coordinate_rmse':baseline[ident],'kinematic_coordinate_rmse':float(np.sqrt(np.mean((p-target)**2))),'static':sm,'md100':md,'dat':str(dat.relative_to(ROOT))};records.append(rec);print(json.dumps(rec),flush=True)
 result={'seed':20261016,'epochs':40,'training_designs':list(IDS),'model':'KinematicSE3Predictor(hidden=64,depth=2,margin=.02)','seconds':time.time()-start,'history':history,'records':records}
 OUT.mkdir(parents=True,exist_ok=True);(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 torch.save({'model':m.state_dict(),'seed':20261016,'epochs':40},OUT/'kinematic_micro.pt')
if __name__=='__main__':main()
