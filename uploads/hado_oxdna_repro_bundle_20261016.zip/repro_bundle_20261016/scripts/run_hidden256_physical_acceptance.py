#!/usr/bin/env python3
"""Freeze and audit Initial/hidden256/Prepared on the hidden256 test split.

This script performs inference only, writes prediction restarts from the
Initial momentum template, and records static geometry, pair, clash, and DNA2
energy diagnostics for all three objects. Native MD launch checks are kept as
a separate explicit phase so a failed static structure cannot be mistaken for
a successful physical acceptance.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "ml_pilot"))
from train_onepass_ablation import frame_rotation, get_tensor, load_cache, model_input, physical_eval  # noqa: E402
from onepass_model import OnePassSE3Predictor  # noqa: E402
from dgnn_lite_model import DgnnLiteRigidPredictor  # noqa: E402
from transfer_operator.oxdna_io import iter_frames  # noqa: E402


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def restart_text(template: Path, position: np.ndarray, a1: np.ndarray,
                 a3: np.ndarray) -> str:
    lines = template.read_text().splitlines()
    n = len(position)
    if len(lines) < n + 3:
        raise ValueError(f"incomplete template {template}")
    out = lines[:3]
    # Preserve Initial velocities and angular velocities for a legal restart.
    for i in range(n):
        old = np.asarray(lines[i + 3].split(), dtype=float)
        if old.size != 15:
            raise ValueError(f"Initial frame has no momenta: {template}")
        vals = np.concatenate((position[i], a1[i], a3[i], old[9:15]))
        if not np.isfinite(vals).all():
            raise ValueError("nonfinite restart value")
        out.append(" ".join(f"{float(v):.9g}" for v in vals))
    return "\n".join(out) + "\n"


def static_metrics(pos: np.ndarray, rot: np.ndarray, box: np.ndarray,
                   backbone: np.ndarray, pairs: np.ndarray) -> dict:
    a1, a3 = rot[..., 0], rot[..., 2]
    norm_err = max(float(np.max(np.abs(np.linalg.norm(a1, axis=1) - 1))),
                   float(np.max(np.abs(np.linalg.norm(a3, axis=1) - 1))))
    dot_err = float(np.max(np.abs(np.sum(a1 * a3, axis=1))))
    bb = pos - 0.34 * a1 + 0.3408 * np.cross(a3, a1)
    d = bb[backbone[:, 1]] - bb[backbone[:, 0]]
    d -= box * np.rint(d / box)
    lengths = np.linalg.norm(d, axis=1)
    fene_bad = np.abs(lengths - 0.7564) >= 0.25
    if len(pairs):
        pd = pos[pairs[:, 1]] - pos[pairs[:, 0]]
        pd -= box * np.rint(pd / box)
        pair_dist = np.linalg.norm(pd, axis=1)
    else:
        pair_dist = np.empty(0, dtype=float)
    # A deterministic broad-phase clash count. Exclude bonded and designed
    # pair contacts; 0.8 is a conservative oxDNA center-distance screen.
    wrapped = np.mod(pos, box)
    wrapped = np.minimum(wrapped, np.nextafter(box, 0.0))
    close = cKDTree(wrapped, boxsize=box).query_pairs(0.8)
    excluded = {tuple(sorted((int(a), int(b)))) for a, b in
                np.concatenate((backbone, pairs), axis=0)}
    return {
        "format_orientation_passed": bool(norm_err < 1e-5 and dot_err < 1e-5),
        "max_axis_norm_error": norm_err,
        "max_axis_dot_error": dot_err,
        "standard_fene_outliers": int(fene_bad.sum()),
        "standard_fene_geometry_passed": bool(not fene_bad.any()),
        "backbone_length_mean": float(lengths.mean()),
        "backbone_length_max": float(lengths.max()),
        "base_pair_count": int(len(pair_dist)),
        "base_pair_distance_mean": float(pair_dist.mean()) if len(pair_dist) else None,
        "base_pair_distance_max": float(pair_dist.max()) if len(pair_dist) else None,
        "base_pair_over_2": int((pair_dist > 2.0).sum()) if len(pair_dist) else 0,
        "nonbonded_clash_cutoff": 0.8,
        "nonbonded_clashes": len(close - excluded),
        "finite_coordinates": bool(np.isfinite(pos).all()),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--output", default="analysis/harness_hidden256_mp3/physical_acceptance_20261015")
    ap.add_argument("--checkpoint", default="ml_pilot/results/onepass_ablation_20261007/onepass_A_20261007.pt")
    ap.add_argument("--model-kind", choices=["onepass", "dgnn_energy"], default="onepass")
    args = ap.parse_args()
    device = torch.device(args.device)
    if device.type == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but unavailable")
        torch.cuda.set_device(device)
    out_dir = ROOT / args.output
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = ROOT / "ml_pilot/results/onepass_family_split_20261007.json"
    manifest = json.loads(manifest_path.read_text())
    rows = [r for r in manifest["rows"] if r["split"] == "test"]
    ckpt = ROOT / args.checkpoint
    state = torch.load(ckpt, map_location=device, weights_only=False)
    if args.model_kind == "dgnn_energy":
        model = DgnnLiteRigidPredictor(input_dim=6, edge_dim=20, hidden_dim=256,
                                       message_passing_steps=3, residual_scale=3.0).to(device)
    else:
        model = OnePassSE3Predictor(6, 256, 3, 20, False, False).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    scale = float(state["config"]["scale"])
    records = []
    started = time.perf_counter()
    with torch.no_grad():
        for index, row in enumerate(rows, 1):
            ident = row["design_id"]
            cache = load_cache(ROOT / "ml_pilot/cache_onepass_20261007" / f"{ident}.npz", device)
            initial_frame = next(iter_frames(ROOT / row["initial_dat"], len(cache["pos0"])))
            prepared_frame = next(iter_frames(ROOT / row["prepared_dat"], len(cache["pos0"])))
            initial_pos = initial_frame.position
            prepared_pos = prepared_frame.position
            initial_rot = frame_rotation(initial_frame.a1, initial_frame.a3)
            prepared_rot = frame_rotation(prepared_frame.a1, prepared_frame.a3)
            if args.model_kind == "dgnn_energy":
                pred = model(
                    get_tensor(cache, "pos0", device, torch.float32) / scale,
                    get_tensor(cache, "rot0", device, torch.float32),
                    get_tensor(cache, "node_features", device, torch.float32),
                    get_tensor(cache, "gnn_edge_index", device, torch.long),
                    get_tensor(cache, "gnn_edge_features", device, torch.float32),
                    position_scale=scale,
                )
            else:
                pred = model(**model_input(cache, device, scale))
            predicted_pos = pred["position"].cpu().numpy() * scale + cache["source_center"]
            predicted_rot = pred["rotation"].cpu().numpy()
            objects = {
                "initial": (initial_pos, initial_rot),
                "prediction": (predicted_pos, predicted_rot),
                "prepared": (prepared_pos, prepared_rot),
            }
            design_dir = out_dir / ident
            design_dir.mkdir(exist_ok=True)
            template = ROOT / row["initial_dat"]
            object_records = {}
            for name, (pos, rot) in objects.items():
                metrics = static_metrics(pos, rot, cache["box"],
                                         cache["backbone_edges"].T,
                                         cache["base_pairs"].T)
                # Evaluate the same DNA2 energy implementation used by the
                # training harness, with the same physical parameters.
                bases = torch.as_tensor(cache["base_types"], device=device, dtype=torch.long)
                terminal = torch.as_tensor(cache["terminal"], device=device, dtype=torch.bool)
                bonds = cache["backbone_edges"].T
                energy = physical_eval(pos, rot, cache["box"], bonds, bases, terminal, device)
                metrics["energy_per_nucleotide"] = {
                    term: float(energy.terms[term].detach().cpu()) / len(pos)
                    for term in energy.terms
                }
                metrics["energy_total_per_nucleotide"] = float(sum(energy.terms.values()).detach().cpu()) / len(pos)
                metrics["restart_template"] = row["initial_dat"]
                restart = design_dir / f"{name}.dat"
                restart.write_text(restart_text(template, pos, rot[..., 0], rot[..., 2]))
                metrics["restart_path"] = str(restart.relative_to(ROOT))
                metrics["restart_sha256"] = sha256(restart)
                object_records[name] = metrics
            records.append({"design_id": ident, "family": row["family"],
                            "nucleotides": int(len(initial_pos)), "objects": object_records})
            if index % 10 == 0:
                print(json.dumps({"stage": "inference_static", "done": index, "total": len(rows)}), flush=True)
    payload = {
        "schema": "hidden256_physical_acceptance_v1",
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "split": "family-held-out test",
        "design_count": len(records),
        "checkpoint": str(ckpt.relative_to(ROOT)),
        "checkpoint_sha256": sha256(ckpt),
        "manifest": str(manifest_path.relative_to(ROOT)),
        "manifest_sha256": sha256(manifest_path),
        "model_hidden": 256, "model_depth": 3, "scale": scale,
        "static_wall_seconds": time.perf_counter() - started,
        "objects": ["initial", "prediction", "prepared"],
        "clash_definition": "nonbonded center-distance < 0.8 oxDNA units after excluding backbone and native pair edges",
        "records": records,
    }
    (out_dir / "static_acceptance.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"status": "completed", "design_count": len(records),
                      "static_wall_seconds": payload["static_wall_seconds"],
                      "output": str((out_dir / "static_acceptance.json").relative_to(ROOT))}), flush=True)


if __name__ == "__main__":
    main()
