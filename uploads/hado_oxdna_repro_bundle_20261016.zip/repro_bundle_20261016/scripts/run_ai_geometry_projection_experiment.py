#!/usr/bin/env python3
"""Frozen Initial/AI/short-projection experiment for HADO test designs.

The projection is deliberately small and deterministic: it adjusts nucleotide
centres to satisfy backbone-site distances and applies a site-level soft-core
repulsion. It never calls Preparation or a long MD repair stage.
"""
from __future__ import annotations

import argparse, csv, hashlib, json, os, platform, subprocess, time
from pathlib import Path
import numpy as np
import torch
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT / "ml_pilot"))
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT.parent / "flowmatching"))
from transfer_operator.oxdna_io import iter_frames
from train_onepass_ablation import frame_rotation, load_cache, model_input
from onepass_model import OnePassSE3Predictor
from dgnn_lite_model import DgnnLiteRigidPredictor
from run_hidden256_physical_acceptance import static_metrics, restart_text
from geometry_io import read_top, read_conf, audit_conf
from pipeline import input_text

OUT = ROOT / "analysis/ai_geometry_projection_20261015"
MANIFEST = ROOT / "ml_pilot/results/onepass_family_split_20261007.json"
HIDDEN = ROOT / "ml_pilot/results/onepass_ablation_20261007/onepass_A_20261007.pt"
DGNN = ROOT / "ml_pilot/results/dgnn_lite_energy_20261015/model.pt"
CACHE = ROOT / "ml_pilot/cache_onepass_20261007"
BOX_EPS = 1e-6


def sha256(p):
    h = hashlib.sha256(); f = Path(p).open("rb")
    for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()


def sites(x, rot):
    a1, a3 = rot[..., 0], rot[..., 2]
    back = x - 0.34 * a1 + 0.3408 * np.cross(a3, a1)
    base = x + 0.4 * a1
    return np.stack((back, base), axis=1)


def project(x0, rot, box, backbone, pairs, iterations):
    """Return fixed-budget snapshots and cumulative projection time."""
    x = x0.astype(np.float64, copy=True); box = np.asarray(box, float)
    target = 0.7564
    excluded = {tuple(sorted((int(i), int(j)))) for i, j in backbone}
    bi, bj = backbone.T
    snapshots = {0: (x.copy().astype(np.float32), 0.0)}
    started = time.perf_counter()
    for iteration in range(1, int(iterations)+1):
        s = sites(x, rot)
        # Backbone FENE-site distance projection.
        d = s[bj, 0] - s[bi, 0]; d -= box * np.rint(d / box)
        r = np.linalg.norm(d, axis=1)
        corr = np.clip(target-r, -0.20, 0.20)[:, None] * d / np.maximum(r[:, None], 1e-9)
        change = np.zeros_like(x)
        np.add.at(change, bi, -0.5*corr)
        np.add.at(change, bj, 0.5*corr)
        x += change
        # Native pairs are nonbonded in oxDNA and must retain their repulsion.
        s = sites(x, rot); wrapped = np.mod(s.reshape(-1, 3), box)
        wrapped = np.minimum(wrapped, np.nextafter(box, 0.0))
        near = cKDTree(wrapped, boxsize=box).query_pairs(0.712, output_type="ndarray")
        if len(near):
            i, si = np.divmod(near[:, 0], 2)
            j, sj = np.divmod(near[:, 1], 2)
            keep = i != j
            keep &= np.array([tuple(sorted((int(a), int(b)))) not in excluded for a, b in zip(i, j)])
            i, j, si, sj = i[keep], j[keep], si[keep], sj[keep]
            d = s[j, sj] - s[i, si]; d -= box * np.rint(d / box)
            r = np.linalg.norm(d, axis=1)
            cutoff = np.where((si == 0) & (sj == 0), 0.711879,
                              np.where((si == 1) & (sj == 1), 0.335388, 0.523299))
            corr = np.minimum(0.12, 0.5 * np.maximum(cutoff-r, 0))[:, None] * d / np.maximum(r[:, None], 1e-9)
            change = np.zeros_like(x)
            np.add.at(change, i, -corr)
            np.add.at(change, j, corr)
            x += change
        if iteration in (16, 32, 64, 128):
            snapshots[iteration] = (x.copy().astype(np.float32), time.perf_counter()-started)
    return snapshots


def model_prediction(kind, cache, device, scale, state):
    if kind == "hidden256":
        model = state[0]; out = model(**model_input(cache, device, scale))
    else:
        model = state[0]
        out = model(torch.as_tensor(cache["pos0"], device=device) / scale,
                    torch.as_tensor(cache["rot0"], device=device),
                    torch.as_tensor(cache["node_features"], device=device),
                    torch.as_tensor(cache["gnn_edge_index"], device=device, dtype=torch.long),
                    torch.as_tensor(cache["gnn_edge_features"], device=device), position_scale=scale)
    return out["position"].detach().cpu().numpy() * scale + cache["source_center"], out["rotation"].detach().cpu().numpy()


def load_model(kind, device):
    if kind == "hidden256":
        ck = torch.load(HIDDEN, map_location=device, weights_only=False)
        m = OnePassSE3Predictor(6, 256, 3, 20, False, False).to(device); m.load_state_dict(ck["model"]); m.eval()
        return m, float(ck["config"]["scale"]), HIDDEN
    ck = torch.load(DGNN, map_location=device, weights_only=False)
    m = DgnnLiteRigidPredictor(input_dim=6, edge_dim=20, hidden_dim=256, message_passing_steps=3, residual_scale=3.0).to(device)
    m.load_state_dict(ck["model"]); m.eval()
    return m, float(ck["config"]["scale"]), DGNN


def run_md(work, top, dat, steps, timeout=120):
    work.mkdir(parents=True, exist_ok=True)
    if not (work / "system.top").exists(): (work / "system.top").symlink_to(top.resolve())
    if not (work / "start.dat").exists(): (work / "start.dat").symlink_to(dat.resolve())
    config = json.loads((ROOT / "config/simulation.json").read_text())
    inp = input_text(config, "check", "CUDA", steps, steps, 20261015, True, True, False)
    (work / "input").write_text(inp); log = work / "run.log"; started = time.perf_counter()
    try:
        p = subprocess.run([str(ROOT / "build/cuda/bin/oxDNA"), "input"], cwd=work, stdout=log.open("w"), stderr=subprocess.STDOUT, timeout=timeout)
        code = p.returncode
    except subprocess.TimeoutExpired: code = None
    text = log.read_text(errors="replace") if log.exists() else ""
    top_obj = read_top(top)
    try:
        last = read_conf(work / "last.dat", top_obj["n"])
        audit = audit_conf(top_obj, last)
        thermo = np.atleast_2d(np.loadtxt(work / "thermo.dat"))
        energy = thermo[:, 1]
        energy_jump = float(abs(energy[-1]-energy[0])) if len(energy) >= 2 else float("inf")
        # A restart that technically exits but immediately creates an enormous
        # energy spike is an instability, not physical acceptance.
        valid = bool(last["step"] == steps and last["has_momenta"] and
                     audit["format_orientation_passed"] and audit["standard_fene_geometry_passed"] and
                     thermo.shape[1] == 3 and np.isfinite(thermo).all() and
                     np.max(np.abs(energy)) < 1e6 and energy_jump < 1e5)
        audit["energy_initial"] = float(energy[0]) if len(energy) else None
        audit["energy_final"] = float(energy[-1]) if len(energy) else None
        audit["energy_abs_max"] = float(np.max(np.abs(energy))) if len(energy) else None
        audit["energy_jump"] = energy_jump
    except (OSError, ValueError, StopIteration, IndexError) as exc:
        valid = False; audit = {"validation_error": str(exc)}
    return {"returncode": code, "seconds": time.perf_counter() - started,
            "completed": bool(code == 0 and "everything went OK" in text and valid),
            "errors": [x for x in text.splitlines() if "ERROR:" in x][:5], "output_audit": audit}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--mode", choices=["pilot", "full"], default="pilot"); ap.add_argument("--device", default="cuda:0"); ap.add_argument("--dynamic", action="store_true"); ap.add_argument("--design"); ap.add_argument("--max-budget", type=int, default=128); args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True); device = torch.device(args.device); torch.cuda.set_device(device)
    manifest = json.loads(MANIFEST.read_text()); rows = [r for r in manifest["rows"] if r["split"] in (("train", "validation") if args.mode == "pilot" else ("test",))]
    if args.mode == "pilot":
        # Fixed representative 16-design pilot: four from each split family band,
        # selected before looking at projection outputs or test labels.
        rows = [r for r in rows if r["design_id"] in {"H101","H102","H103","H104","H159","H183","H241","H242","H243","H244","H301","H302","H303","H304","H305","H306"}]
    if args.design: rows = [r for r in rows if r["design_id"] == args.design]
    budgets = [b for b in (0, 16, 32, 64, 128) if b <= args.max_budget]; routes = ["B_initial", "C_hidden256", "D_dgnn_energy"]
    protocol = {"schema":"ai_geometry_projection_v1", "mode":args.mode, "design_count":len(rows), "budgets":budgets, "routes":routes, "projection":"position-only fixed-iteration backbone-site PBD plus site-level soft-core repulsion", "backbone_target":0.7564, "site_cutoff":0.52, "dynamic_steps":[100,1000], "manifest_sha256":sha256(MANIFEST), "git_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(), "hardware":subprocess.check_output(["nvidia-smi","--query-gpu=name,driver_version","--format=csv,noheader"],text=True).strip(), "python":platform.python_version(), "random_seed":20261015}
    (OUT / f"experiment_protocol_{args.mode}.json").write_text(json.dumps(protocol, indent=2)+"\n")
    states = {k: load_model(k, device) for k in ("hidden256", "dgnn_energy")}; records=[]; timing=[]
    for row in rows:
        ident=row["design_id"]; cache=load_cache(CACHE/(ident+".npz"), device); top=ROOT/row["initial_top"]; n=len(cache["pos0"])
        init=next(iter_frames(ROOT/row["initial_dat"], n)); rot=frame_rotation(init.a1, init.a3); x_init=init.position; backbone=cache["backbone_edges"].T; pairs=cache["base_pairs"].T; template=ROOT/row["initial_dat"]
        with torch.inference_mode():
            candidates={"B_initial":(x_init,rot), "C_hidden256":model_prediction("hidden256",cache,device,states["hidden256"][1],states["hidden256"]), "D_dgnn_energy":model_prediction("dgnn_energy",cache,device,states["dgnn_energy"][1],states["dgnn_energy"])}
        for route in routes:
            snapshots = project(candidates[route][0], candidates[route][1], init.box,
                                backbone, pairs, max(budgets))
            for budget in budgets:
                x, projection_seconds = snapshots[budget]; r = candidates[route][1]
                ddir=OUT/args.mode/ident/route/f"budget_{budget}"; ddir.mkdir(parents=True,exist_ok=True); dat=ddir/"structure.dat"; dat.write_text(restart_text(template,x,r[...,0],r[...,2]))
                t0=time.perf_counter(); sm=static_metrics(x,r,init.box,backbone,pairs); static_seconds=time.perf_counter()-t0
                rec={"design_id":ident,"route":route,"budget":budget,"projection_seconds":projection_seconds,"static_seconds":static_seconds,**sm,"dat":str(dat.relative_to(ROOT))}
                if args.dynamic:
                    rec["md_100"] = run_md(ddir/"md_100",top,dat,100)
                    if rec["md_100"]["completed"]: rec["md_1000"] = run_md(ddir/"md_1000",top,dat,1000)
                records.append(rec)
    fields=sorted({k for r in records for k in r});
    with (OUT/f"design_level_results_{args.mode}.csv").open("w",newline="") as f: w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(records)
    (OUT/f"physical_acceptance_{args.mode}.json").write_text(json.dumps(records,indent=2)+"\n")
    print(json.dumps({"mode":args.mode,"designs":len(rows),"records":len(records),"output":str(OUT)},indent=2))

if __name__ == "__main__": main()
