"""Masked energy, orientation, topology-spatial, and physical losses."""
from __future__ import annotations
import torch
import torch.nn.functional as F


def mean_group(values,mask):
    if not bool(mask.any()): return values.sum()*0
    return values[mask].mean()


def supervised_losses(out,target,struct_edges,struct_kinds,scale,energy_mask=None,
                      energy_scale=None,variant='A'):
    lp=F.smooth_l1_loss((out['position']-target['position'])/scale,
                        torch.zeros_like(out['position']))
    a1=1-(F.normalize(out['a1'],dim=-1)*F.normalize(target['a1'],dim=-1)).sum(-1).clamp(-1,1)
    a3=1-(F.normalize(out['a3'],dim=-1)*F.normalize(target['a3'],dim=-1)).sum(-1).clamp(-1,1)
    lo=(a1+a3).mean()
    i,j=struct_edges
    pv=(out['position'][j]-out['position'][i])/scale
    tv=(target['position'][j]-target['position'][i])/scale
    pe=F.smooth_l1_loss(pv,tv,reduction='none').sum(-1)
    # Average relation classes separately; large backbones do not overwhelm pairs.
    group=[]
    for kind in (1,2,3):
        m=struct_kinds==kind
        if bool(m.any()): group.append(pe[m].mean())
    ls=torch.stack(group).mean() if group else pe.mean()
    le=out['position'].sum()*0
    if out['edge_energy'] is not None:
        residual=torch.asinh(out['edge_energy']/energy_scale)-target['energy_asinh']
        per=F.smooth_l1_loss(residual,torch.zeros_like(residual),reduction='none')
        if energy_mask is None: le=per.mean()
        else:
            terms=[]
            for k in range(per.shape[-1]):
                if bool(energy_mask[:,k].any()): terms.append(per[energy_mask[:,k],k].mean())
            le=torch.stack(terms).mean() if terms else per.sum()*0
    # A/B are baseline and direct-physics variants; C auxiliary energy; D also conditions geometry.
    total=lp+lo+ls
    if variant in ('C','D'): total=total+0.1*le
    return total,{'position':lp,'orientation':lo,'spatial':ls,'energy_aux':le}


def physical_energy_loss(pred_eval,target_terms,physical_scale,n_nodes):
    terms=pred_eval.terms
    vals=[]
    for name,scale in zip(terms,physical_scale):
        pred=terms[name]/n_nodes
        target=target_terms[name]
        # Energy tails can be enormous in deliberately stressed initial
        # structures; asinh keeps gradients useful without letting one term
        # swamp coordinate and orientation supervision.
        vals.append(F.smooth_l1_loss(torch.asinh(pred/scale),torch.asinh(target/scale)))
    energy=torch.stack(vals).mean()
    barriers=torch.log1p(pred_eval.barriers['fene_domain'].clamp_min(0))+torch.log1p(pred_eval.barriers['excluded_volume'].clamp_min(0))
    return energy+barriers,{'physics_energy':energy,'physics_barrier':barriers}
