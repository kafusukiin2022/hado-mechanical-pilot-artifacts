from __future__ import annotations

import math
import torch
from torch import nn
from torch.utils.checkpoint import checkpoint


def center_batch(x: torch.Tensor) -> torch.Tensor:
    return x - x.mean(dim=-2, keepdim=True)


def batched_kabsch_align(base: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """Align `[B,N,3]` centered base samples onto fixed-topology targets."""
    squeeze = base.ndim == 2
    if squeeze:
        base, target = base[None], target[None]
    covariance = base.transpose(-1, -2) @ target
    u, _, vh = torch.linalg.svd(covariance)
    correction = torch.eye(3, dtype=base.dtype, device=base.device).repeat(len(base), 1, 1)
    correction[:, -1, -1] = torch.where(torch.det(vh.transpose(-1, -2) @ u.transpose(-1, -2)) < 0, -1.0, 1.0)
    rotation = vh.transpose(-1, -2) @ correction @ u.transpose(-1, -2)
    aligned = base @ rotation
    return aligned[0] if squeeze else aligned


class RadialBasis(nn.Module):
    def __init__(self, count: int, cutoff: float):
        super().__init__(); self.count=count; self.cutoff=cutoff
        self.register_buffer('centers', torch.linspace(0.0, cutoff, count)); self.gamma=count/(cutoff*cutoff)
    def forward(self, distance: torch.Tensor) -> torch.Tensor:
        rbf=torch.exp(-self.gamma*(distance-self.centers)**2)
        envelope=0.5*(torch.cos(math.pi*distance.clamp_max(self.cutoff)/self.cutoff)+1.0)
        envelope=envelope*(distance < self.cutoff)
        return rbf*envelope


class PaiNNInteraction(nn.Module):
    def __init__(self, hidden: int, rbf: int, edge_types: int, edge_chunk_size: int | None = None, edge_feature_dim: int = 0):
        super().__init__(); self.edge_embedding=nn.Embedding(edge_types, hidden); self.edge_feature_dim=int(edge_feature_dim); self.filter=nn.Sequential(nn.Linear(rbf+hidden+self.edge_feature_dim,hidden),nn.SiLU(),nn.Linear(hidden,3*hidden)); self.scalar=nn.Linear(hidden,hidden); self.vector=nn.Linear(hidden,hidden,bias=False); self.edge_chunk_size=edge_chunk_size
        self.update=nn.Sequential(nn.Linear(2*hidden,hidden),nn.SiLU(),nn.Linear(hidden,3*hidden)); self.u=nn.Linear(hidden,hidden,bias=False); self.v=nn.Linear(hidden,hidden,bias=False)
    def forward(self,s:torch.Tensor,v:torch.Tensor,edge_index:torch.Tensor,unit:torch.Tensor,rbf:torch.Tensor,edge_type:torch.Tensor,edge_features:torch.Tensor|None=None):
        sender,receiver=edge_index
        if self.edge_feature_dim:
            if edge_features is None or edge_features.shape != (len(sender), self.edge_feature_dim):
                raise ValueError("edge_features has incompatible shape")
            filter_input=torch.cat((rbf,self.edge_embedding(edge_type.long()),edge_features),dim=-1)
        else:
            filter_input=torch.cat((rbf,self.edge_embedding(edge_type.long())),dim=-1)
        filt=self.filter(filter_input); active=(edge_type[:,None] != 0) | (rbf.sum(dim=-1,keepdim=True) > 0); filt=filt*active; fs,fv,fd=filt.chunk(3,-1)
        agg_s=torch.zeros_like(s); agg_v=torch.zeros_like(v)
        chunk = self.edge_chunk_size or len(sender)
        for start in range(0, len(sender), chunk):
            stop = min(start + chunk, len(sender))
            senders, receivers = sender[start:stop], receiver[start:stop]
            ms=fs[start:stop]*self.scalar(s[senders]); mv=fv[start:stop, ..., None]*self.vector(v[senders].transpose(1,2)).transpose(1,2)+fd[start:stop, ..., None]*unit[start:stop, None, :]
            agg_s.index_add_(0,receivers,ms); agg_v.index_add_(0,receivers,mv)
        s=s+agg_s; v=v+agg_v
        uv=self.u(v.transpose(1,2)).transpose(1,2); vv=self.v(v.transpose(1,2)).transpose(1,2); invariant=torch.sqrt(torch.sum(vv*vv,dim=-1)+1e-8); ds,gate,cross=self.update(torch.cat((s,invariant),dim=-1)).chunk(3,-1)
        s=s+ds+cross*torch.sum(uv*vv,dim=-1); v=v+gate[...,None]*uv
        return s,v


class PaiNNPositionFlow(nn.Module):
    """PaiNN-style SE(3)-equivariant conditional velocity field."""
    def __init__(
        self,
        node_features: int = 6,
        hidden: int = 64,
        depth: int = 3,
        rbf: int = 16,
        cutoff: float = 4.0,
        edge_types: int = 2,
        spatial_layers: int | None = None,
        condition_vector_channels: int = 0,
        phase_space_channels: int = 0,
        phase_output_scale: float | None = 0.25,
        edge_feature_dim: int = 0,
        edge_energy_output_dim: int = 0,
        energy_output_dim: int = 0,
        energy_condition_dim: int | None = None,
        edge_chunk_size: int | None = None,
    ):
        super().__init__()
        if depth < 1:
            raise ValueError("depth must be positive")
        self.rbf = RadialBasis(rbf, cutoff)
        self.spatial_layers = depth if spatial_layers is None else max(1, min(int(spatial_layers), depth))
        self.condition_vector_channels = int(condition_vector_channels)
        self.phase_space_channels = int(phase_space_channels)
        if phase_output_scale is not None and phase_output_scale <= 0:
            raise ValueError("phase_output_scale must be positive")
        self.phase_output_scale = None if phase_output_scale is None else float(phase_output_scale)
        self.edge_feature_dim = int(edge_feature_dim)
        if self.edge_feature_dim < 0:
            raise ValueError("edge_feature_dim must be non-negative")
        self.edge_energy_output_dim = int(edge_energy_output_dim)
        if self.edge_energy_output_dim < 0:
            raise ValueError("edge_energy_output_dim must be non-negative")
        self.energy_output_dim = int(energy_output_dim)
        if self.energy_output_dim < 0:
            raise ValueError("energy_output_dim must be non-negative")
        self.energy_condition_dim = (
            self.energy_output_dim if energy_condition_dim is None else int(energy_condition_dim)
        )
        if self.energy_condition_dim < 0:
            raise ValueError("energy_condition_dim must be non-negative")
        self.scalar_in = nn.Sequential(
            nn.Linear(node_features + 11, hidden), nn.SiLU(), nn.Linear(hidden, hidden)
        )
        self.vector_in = nn.Linear(3 + self.condition_vector_channels, hidden, bias=False)
        self.phase_vector_in = nn.Linear(3 + self.condition_vector_channels + 3, hidden, bias=False)
        if edge_chunk_size is not None and int(edge_chunk_size) <= 0:
            raise ValueError("edge_chunk_size must be positive")
        self.edge_chunk_size = None if edge_chunk_size is None else int(edge_chunk_size)
        self.layers = nn.ModuleList(PaiNNInteraction(hidden, rbf, edge_types, self.edge_chunk_size, self.edge_feature_dim) for _ in range(depth))
        self.out = nn.Linear(hidden, 1, bias=False)
        self.phase_out = nn.ModuleList(nn.Linear(hidden, 1, bias=False) for _ in range(4))
        self.edge_energy_head = (
            nn.Sequential(
                nn.Linear(2 * hidden + rbf + self.edge_feature_dim, hidden),
                nn.SiLU(), nn.Linear(hidden, self.edge_energy_output_dim),
            ) if self.edge_energy_output_dim else None
        )
        self.energy_head = (
            nn.Sequential(nn.Linear(hidden + self.energy_condition_dim, hidden), nn.SiLU(), nn.Linear(hidden, self.energy_output_dim))
            if self.energy_output_dim
            else None
        )
    @staticmethod
    def embed(value:torch.Tensor)->torch.Tensor:
        freq=torch.tensor([1.,2.,4.,8.],device=value.device); phase=value.reshape(1)*freq*math.pi; return torch.cat((phase.sin(),phase.cos()))
    def _encode(self, z, condition, flow_time, lag, edge_index, edge_vectors, edge_types, node_features, condition_vectors=None, edge_features=None):
        q=z-condition; times=torch.cat((self.embed(flow_time)[:4],self.embed(torch.log1p(lag))[:4])).expand(len(z),-1); scalar=torch.cat((node_features,z.norm(dim=-1,keepdim=True),condition.norm(dim=-1,keepdim=True),q.norm(dim=-1,keepdim=True),times),dim=-1); s=self.scalar_in(scalar)
        bases=torch.stack((z,condition,q),dim=1)
        if self.condition_vector_channels:
            if condition_vectors is None or condition_vectors.shape != (len(z), self.condition_vector_channels, 3):
                raise ValueError("condition_vectors has incompatible shape")
            bases=torch.cat((bases,condition_vectors),dim=1)
        v=self.vector_in(bases.transpose(1,2)).transpose(1,2)
        distance=edge_vectors.norm(dim=-1).clamp_min(1e-6); unit=edge_vectors/distance[:,None]; radial=self.rbf(distance[:,None])
        for index,layer in enumerate(self.layers):
            if index >= self.spatial_layers:
                keep = edge_types != 0
                edge_index_layer = edge_index[:, keep]
                unit_layer, radial_layer, types_layer = unit[keep], radial[keep], edge_types[keep]
            else:
                edge_index_layer, unit_layer, radial_layer, types_layer = edge_index, unit, radial, edge_types
            features_layer = edge_features if index < self.spatial_layers else (edge_features[keep] if edge_features is not None else None)
            s,v=layer(s,v,edge_index_layer,unit_layer,radial_layer,types_layer,features_layer)
        return s, v

    def forward(
        self,
        z,
        condition,
        flow_time,
        lag,
        edge_index,
        edge_vectors,
        edge_types,
        node_features,
        condition_vectors=None,
        *,
        edge_features=None,
        return_edge_energy: bool = False,
        source_energy=None,
        return_energy: bool = False,
    ):
        s, v = self._encode(
            z, condition, flow_time, lag, edge_index, edge_vectors, edge_types, node_features, condition_vectors, edge_features
        )
        velocity = self.out(v.transpose(1, 2)).squeeze(-1)
        velocity = velocity - velocity.mean(0, keepdim=True)
        edge_energy = None
        if return_edge_energy:
            if self.edge_energy_head is None:
                raise ValueError("return_edge_energy=True requires edge_energy_output_dim > 0")
            if edge_features is None or edge_features.shape[0] != edge_index.shape[1]:
                raise ValueError("edge_features are required for edge-energy prediction")
            distance = edge_vectors.norm(dim=-1).clamp_min(1e-6)
            radial = self.rbf(distance[:, None])
            sender, receiver = edge_index
            edge_energy = self.edge_energy_head(torch.cat((s[sender], s[receiver], radial, edge_features), dim=-1))
        if not return_energy and not return_edge_energy:
            return velocity
        if not return_energy and return_edge_energy:
            return velocity, edge_energy
        if self.energy_head is None:
            raise ValueError("return_energy=True requires energy_output_dim > 0")
        if source_energy is None:
            source_energy = torch.zeros(self.energy_condition_dim, dtype=s.dtype, device=s.device)
        source_energy = source_energy.to(device=s.device, dtype=s.dtype).reshape(-1)
        if source_energy.numel() != self.energy_condition_dim:
            raise ValueError("source_energy has incompatible shape")
        energy = self.energy_head(torch.cat((s.mean(dim=0), source_energy), dim=0))
        if return_edge_energy:
            return velocity, energy, edge_energy
        return velocity, energy

    def forward_phase_space(
        self, z, condition, flow_time, lag, edge_index, edge_vectors, edge_types,
        node_features, condition_vectors, source_velocity, current_velocity,
        source_angular_velocity, current_angular_velocity, edge_features=None,
    ):
        """Return position, velocity, angular-velocity and orientation fields."""
        if self.phase_space_channels != 3:
            raise ValueError("phase_space_channels must be 3 for phase-space mode")
        q = current_velocity - source_velocity
        w = current_angular_velocity - source_angular_velocity
        extra = torch.stack((q, w, source_velocity), dim=1)
        s, v = self._encode_phase(
            z, condition, flow_time, lag, edge_index, edge_vectors, edge_types,
            node_features, condition_vectors, extra, edge_features,
        )
        fields = []
        for head in self.phase_out:
            raw = head(v.transpose(1, 2)).squeeze(-1)
            fields.append(raw if self.phase_output_scale is None else self.phase_output_scale * torch.tanh(raw - raw.mean(0, keepdim=True)))
        return tuple(fields)

    def _encode_phase(self, z, condition, flow_time, lag, edge_index, edge_vectors,
                      edge_types, node_features, condition_vectors, extra, edge_features=None):
        q = z - condition
        times = torch.cat((self.embed(flow_time)[:4], self.embed(torch.log1p(lag))[:4])).expand(len(z), -1)
        scalar = torch.cat((node_features, z.norm(dim=-1, keepdim=True), condition.norm(dim=-1, keepdim=True), q.norm(dim=-1, keepdim=True), times), dim=-1)
        s = self.scalar_in(scalar)
        bases = torch.stack((z, condition, q), dim=1)
        if condition_vectors is not None:
            bases = torch.cat((bases, condition_vectors), dim=1)
        bases = torch.cat((bases, extra), dim=1)
        v = self.phase_vector_in(bases.transpose(1, 2)).transpose(1, 2)
        distance = edge_vectors.norm(dim=-1).clamp_min(1e-6)
        unit = edge_vectors / distance[:, None]
        radial = self.rbf(distance[:, None])
        for index, layer in enumerate(self.layers):
            keep = edge_types != 0 if index >= self.spatial_layers else slice(None)
            ei = edge_index[:, keep]; uu, rr, tt = unit[keep], radial[keep], edge_types[keep]
            features_layer = edge_features if index < self.spatial_layers else (edge_features[keep] if edge_features is not None else None)
            s, v = layer(s, v, ei, uu, rr, tt, features_layer)
        return s, v


def dynamic_edge_vectors(
    positions: torch.Tensor,
    edge_index: torch.Tensor,
    box: torch.Tensor | None = None,
) -> torch.Tensor:
    sender, receiver = edge_index
    vectors = positions[sender] - positions[receiver]
    if box is not None:
        vectors = vectors - box * torch.round(vectors / box)
    return vectors


def _integrate_painn_flow_impl(
    model, base, condition, lag, nfe, *, graph_builder=None,
    graph_refresh_interval=1, graph_refresh_skin=None, box=None, method="heun",
    velocity_clip=None, return_diagnostics=False, activation_checkpoint=False, **context,
):
    if nfe < 1:
        raise ValueError("nfe must be positive")
    if graph_refresh_interval <= 0:
        raise ValueError("graph_refresh_interval must be positive")
    if method not in {"euler", "midpoint", "heun"}:
        raise ValueError("method must be one of 'euler', 'midpoint', or 'heun'")
    if velocity_clip is not None and velocity_clip <= 0:
        raise ValueError("velocity_clip must be positive")
    z = base
    step = 1.0 / nfe
    context = dict(context)
    last_graph_position = None
    raw_velocity_max = 0.0
    velocity_max = 0.0
    position_norm_max = 0.0
    clipped_count = 0
    graph_refreshes = 0

    def refresh_graph(state: torch.Tensor, index: int) -> None:
        nonlocal last_graph_position, graph_refreshes
        if graph_builder is None:
            return
        refresh = index == 0 or index % graph_refresh_interval == 0
        if graph_refresh_skin is not None and last_graph_position is not None:
            displacement = state - last_graph_position
            if box is not None:
                displacement = displacement - box * torch.round(displacement / box)
            refresh = refresh or bool(torch.linalg.vector_norm(displacement, dim=-1).max() > graph_refresh_skin)
        if refresh:
            values = graph_builder(state)
            if not isinstance(values, dict):
                raise TypeError("graph_builder must return a dictionary of model context")
            context.update(values)
            last_graph_position = state.detach().clone()
            graph_refreshes += 1

    def evaluate(state: torch.Tensor, flow_time: torch.Tensor) -> torch.Tensor:
        nonlocal raw_velocity_max, velocity_max, clipped_count
        if "edge_index" in context:
            context["edge_vectors"] = dynamic_edge_vectors(state, context["edge_index"], box)
        edge_vectors = context.get("edge_vectors")
        if activation_checkpoint and torch.is_grad_enabled():
            if edge_vectors is None:
                raise ValueError("activation checkpointing requires edge_vectors in the integration context")
            static_context = {key: value for key, value in context.items() if key != "edge_vectors"}

            def checkpointed_model(
                checkpoint_state: torch.Tensor,
                checkpoint_condition: torch.Tensor,
                checkpoint_time: torch.Tensor,
                checkpoint_edge_vectors: torch.Tensor,
                checkpoint_lag: torch.Tensor,
            ) -> torch.Tensor:
                local_context = dict(static_context)
                local_context["edge_vectors"] = checkpoint_edge_vectors
                output = model(
                    checkpoint_state,
                    checkpoint_condition,
                    checkpoint_time,
                    checkpoint_lag,
                    **local_context,
                )
                return output[0] if isinstance(output, tuple) else output

            velocity = checkpoint(
                checkpointed_model,
                state,
                condition,
                flow_time,
                edge_vectors,
                lag,
                use_reentrant=False,
                preserve_rng_state=False,
            )
        else:
            velocity = model(state, condition, flow_time, lag, **context)
        if isinstance(velocity, tuple):
            velocity = velocity[0]
        if not torch.isfinite(velocity).all():
            raise FloatingPointError("non-finite PaiNN velocity during rollout")
        raw_norm = torch.linalg.vector_norm(velocity, dim=-1)
        raw_max = float(raw_norm.max().detach()) if raw_norm.numel() else 0.0
        raw_velocity_max = max(raw_velocity_max, raw_max)
        if velocity_clip is not None:
            norm = raw_norm.clamp_min(1e-12)
            clipped = norm > velocity_clip
            if bool(clipped.any()):
                clipped_count += int(clipped.sum().detach())
                velocity = velocity * (velocity_clip / norm).clamp_max(1.0).unsqueeze(-1)
        current_max = float(torch.linalg.vector_norm(velocity, dim=-1).max().detach()) if velocity.numel() else 0.0
        velocity_max = max(velocity_max, current_max)
        return velocity

    for i in range(nfe):
        refresh_graph(z, i)
        t0 = torch.tensor(i * step, device=z.device, dtype=z.dtype)
        t1 = torch.tensor((i + 1) * step, device=z.device, dtype=z.dtype)
        if method == "heun":
            first = evaluate(z, t0)
            predictor = center_batch(z + step * first)
            second = evaluate(predictor, t1)
            z = center_batch(z + 0.5 * step * (first + second))
        elif method == "euler":
            z = center_batch(z + step * evaluate(z, t0))
        else:
            midpoint = evaluate(z, torch.tensor((i + 0.5) * step, device=z.device, dtype=z.dtype))
            z = center_batch(z + step * midpoint)
        if not torch.isfinite(z).all():
            raise FloatingPointError("non-finite PaiNN state during rollout")
        position_norm_max = max(position_norm_max, float(torch.linalg.vector_norm(z, dim=-1).max().detach()))
    if not return_diagnostics:
        return z
    return z, {
        "finite": bool(torch.isfinite(z).all()),
        "steps": int(nfe),
        "method": method,
        "velocity_max": velocity_max,
        "raw_velocity_max": raw_velocity_max,
        "position_norm_max": position_norm_max,
        "clipped_velocity_count": clipped_count,
        "graph_refreshes": graph_refreshes,
    }


def integrate_painn_flow(
    model,
    base,
    condition,
    lag,
    nfe,
    *,
    track_grad: bool = False,
    **kwargs,
):
    """Integrate the flow with optional autograd for consistency losses.

    Rollout/evaluation defaults to track_grad=False to keep memory bounded.
    Training-time Chapman--Kolmogorov branches can opt into differentiability.
    """
    if track_grad:
        return _integrate_painn_flow_impl(model, base, condition, lag, nfe, **kwargs)
    with torch.no_grad():
        return _integrate_painn_flow_impl(model, base, condition, lag, nfe, **kwargs)
