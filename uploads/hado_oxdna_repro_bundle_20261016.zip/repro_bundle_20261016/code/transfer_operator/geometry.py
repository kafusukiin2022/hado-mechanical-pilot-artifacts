from __future__ import annotations

import numpy as np


def rotation_exp(vector: np.ndarray) -> np.ndarray:
    angle = np.linalg.norm(vector, axis=-1)
    axis = vector / np.maximum(angle[..., None], 1e-12)
    x, y, z = np.moveaxis(axis, -1, 0)
    zero = np.zeros_like(x)
    skew = np.stack((zero, -z, y, z, zero, -x, -y, x, zero), axis=-1).reshape(vector.shape[:-1] + (3, 3))
    identity = np.broadcast_to(np.eye(3), skew.shape)
    sine = np.sin(angle)[..., None, None]
    cosine = np.cos(angle)[..., None, None]
    result = identity + sine * skew + (1.0 - cosine) * (skew @ skew)
    return np.where((angle < 1e-12)[..., None, None], identity, result)


def axes_to_rotation(a1: np.ndarray, a3: np.ndarray) -> np.ndarray:
    a1 = a1 / np.linalg.norm(a1, axis=-1, keepdims=True)
    a3 = a3 - np.sum(a3 * a1, axis=-1, keepdims=True) * a1
    a3 = a3 / np.linalg.norm(a3, axis=-1, keepdims=True)
    a2 = np.cross(a3, a1)
    return np.stack((a1, a2, a3), axis=-1)


def rotation_log(rotation: np.ndarray) -> np.ndarray:
    trace = np.trace(rotation, axis1=-2, axis2=-1)
    angle = np.arccos(np.clip((trace - 1.0) * 0.5, -1.0, 1.0))
    skew = np.stack(
        (
            rotation[..., 2, 1] - rotation[..., 1, 2],
            rotation[..., 0, 2] - rotation[..., 2, 0],
            rotation[..., 1, 0] - rotation[..., 0, 1],
        ),
        axis=-1,
    )
    sine = np.sin(angle)
    scale = np.where(angle < 1e-7, 0.5, angle / (2.0 * sine + 1e-12))
    result = skew * scale[..., None]
    near_pi = (np.abs(sine) < 1e-3) | (angle > np.pi - 1e-3)
    for index in np.argwhere(near_pi):
        key = tuple(index)
        if angle[key] < 1e-7:
            result[key] = 0.5 * skew[key]
            continue
        matrix = rotation[key]
        diagonal = np.maximum((np.diag(matrix) + 1.0) * 0.5, 0.0)
        axis = np.sqrt(diagonal)
        largest = int(np.argmax(axis))
        if axis[largest] > 1e-8:
            others = [value for value in range(3) if value != largest]
            axis[others[0]] = (matrix[largest, others[0]] + matrix[others[0], largest]) / (4.0 * axis[largest])
            axis[others[1]] = (matrix[largest, others[1]] + matrix[others[1], largest]) / (4.0 * axis[largest])
        axis /= np.linalg.norm(axis) + 1e-12
        result[key] = angle[key] * axis
    return result
