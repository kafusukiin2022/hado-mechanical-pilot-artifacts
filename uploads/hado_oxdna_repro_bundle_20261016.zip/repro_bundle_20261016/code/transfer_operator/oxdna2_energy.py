"""Differentiable oxDNA2-like energies for graph-latent training.

The formulas mirror the DNA2 interaction decomposition in the vendored oxDNA
source (commit 4241fc3). They operate on oxDNA reduced coordinates and rigid
orientation frames. Candidate pairs are transient neighbour-list entries and
must never be passed to a message-passing network.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Mapping

import torch

from .gpu_graph import PhysicsCandidatePairs, minimum_image_torch


ENERGY_TERMS = (
    "fene",
    "bonded_excluded_volume",
    "stacking",
    "nonbonded_excluded_volume",
    "hydrogen_bonding",
    "cross_stacking",
    "coaxial_stacking",
    "debye_huckel",
)


@dataclass(frozen=True)
class DNA2Sites:
    back: torch.Tensor
    stack: torch.Tensor
    base: torch.Tensor
    back_offset: torch.Tensor
    stack_offset: torch.Tensor
    base_offset: torch.Tensor


@dataclass(frozen=True)
class DNA2EnergyEvaluation:
    terms: Mapping[str, torch.Tensor]
    per_node: Mapping[str, torch.Tensor]
    barriers: Mapping[str, torch.Tensor]
    diagnostics: Mapping[str, torch.Tensor]
    candidate_count: int
    nonbonded_count: int
    overflow_nodes: int


@dataclass(frozen=True)
class DNA2Parameters:
    temperature: float = 0.1
    salt_concentration: float = 0.5
    fene_epsilon: float = 2.0
    fene_r0: float = 0.7564
    fene_delta: float = 0.25
    max_backbone_force: float = 5.0
    max_backbone_force_far: float = 1.0
    hydrogen_epsilon: float = 1.0678
    debye_prefactor: float = 0.0543
    debye_lambda_factor: float = 0.3616455
    half_charged_ends: bool = True

    @property
    def stacking_epsilon(self) -> float:
        return 1.3523 + 2.6717 * self.temperature

    @property
    def debye_lambda(self) -> float:
        return self.debye_lambda_factor * math.sqrt(self.temperature / 0.1) / math.sqrt(self.salt_concentration)

    @property
    def debye_rhigh(self) -> float:
        return 3.0 * self.debye_lambda

    @property
    def debye_rc(self) -> float:
        # This is the simplified form of the source expression after the
        # common prefactor cancels.
        x = self.debye_rhigh
        return x * (x + 3.0 * self.debye_lambda) / (x + self.debye_lambda)

    @property
    def debye_b(self) -> float:
        x = self.debye_rhigh
        q = self.debye_prefactor
        length = self.debye_lambda
        return math.exp(-x / length) * q * (x + length) ** 2 / (4.0 * x**3 * length**2)


DEFAULT_DNA2_PARAMETERS = DNA2Parameters()


def dna2_sites(positions: torch.Tensor, rotations: torch.Tensor) -> DNA2Sites:
    """Construct DNA2 BACK/STACK/BASE interaction sites.

    Rotation columns are ``a1, a2, a3``, matching ``axes_to_rotation`` and the
    oxDNA particle orientation convention.
    """
    if positions.ndim != 2 or positions.shape[-1] != 3:
        raise ValueError("positions must have shape [N,3]")
    if rotations.shape != (len(positions), 3, 3):
        raise ValueError("rotations must have shape [N,3,3]")
    if positions.device != rotations.device:
        raise ValueError("positions and rotations must share a device")
    a1 = rotations[..., :, 0]
    a2 = rotations[..., :, 1]
    back_offset = -0.3400 * a1 + 0.3408 * a2
    stack_offset = 0.3400 * a1
    base_offset = 0.4000 * a1
    return DNA2Sites(
        back=positions + back_offset,
        stack=positions + stack_offset,
        base=positions + base_offset,
        back_offset=back_offset,
        stack_offset=stack_offset,
        base_offset=base_offset,
    )


def rotation_frame_error(rotations: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Return orthogonality and proper-rotation errors for diagnostics."""
    identity = torch.eye(3, dtype=rotations.dtype, device=rotations.device)
    gram = rotations.transpose(-1, -2) @ rotations
    orthogonality = torch.mean((gram - identity) ** 2)
    determinant = torch.mean((torch.linalg.det(rotations) - 1.0) ** 2)
    return orthogonality, determinant


def f1_radial(
    distance: torch.Tensor,
    *,
    epsilon: float,
    a: float,
    rc: float,
    r0: float,
    blow: float,
    bhigh: float,
    rlow: float,
    rhigh: float,
    rclow: float,
    rchigh: float,
) -> torch.Tensor:
    """oxDNA ``_f1`` Morse well with quadratic smoothing tails."""
    shift = epsilon * (1.0 - math.exp(-(rc - r0) * a)) ** 2
    middle = epsilon * (1.0 - torch.exp(-(distance - r0) * a)) ** 2 - shift
    low = epsilon * blow * (distance - rclow) ** 2
    high = epsilon * bhigh * (distance - rchigh) ** 2
    zero = torch.zeros_like(distance)
    return torch.where(
        (distance > rclow) & (distance <= rlow),
        low,
        torch.where(
            (distance > rlow) & (distance <= rhigh),
            middle,
            torch.where((distance > rhigh) & (distance < rchigh), high, zero),
        ),
    )


def f2_radial(
    distance: torch.Tensor,
    *,
    k: float,
    rc: float,
    r0: float,
    blow: float,
    bhigh: float,
    rlow: float,
    rhigh: float,
    rclow: float,
    rchigh: float,
) -> torch.Tensor:
    """oxDNA ``_f2`` harmonic well with quadratic smoothing tails."""
    middle = 0.5 * k * ((distance - r0) ** 2 - (rc - r0) ** 2)
    low = k * blow * (distance - rclow) ** 2
    high = k * bhigh * (distance - rchigh) ** 2
    zero = torch.zeros_like(distance)
    return torch.where(
        (distance > rclow) & (distance <= rlow),
        low,
        torch.where(
            (distance > rlow) & (distance <= rhigh),
            middle,
            torch.where((distance > rhigh) & (distance < rchigh), high, zero),
        ),
    )


def f4_angle(angle: torch.Tensor, *, a: float, b: float, t0: float, ts: float, tc: float) -> torch.Tensor:
    """oxDNA ``_f4`` compact angular window."""
    delta = torch.abs(angle - t0)
    core = 1.0 - a * delta.square()
    smooth = b * (tc - delta).square()
    return torch.where(delta <= ts, core, torch.where(delta < tc, smooth, torch.zeros_like(delta)))


def f4_cos(cosine: torch.Tensor, **parameters: float) -> torch.Tensor:
    # Avoid the singular derivative of acos at exactly +/-1. The underlying
    # angular window has a finite limiting derivative, but the naive composed
    # autograd expression can otherwise produce 0 * inf = NaN.
    epsilon = 1e-6 if cosine.dtype in (torch.float16, torch.bfloat16, torch.float32) else 1e-12
    return f4_angle(torch.acos(cosine.clamp(-1.0 + epsilon, 1.0 - epsilon)), **parameters)


def f5_azimuth(cosine: torch.Tensor, *, a: float = 2.0, b: float = 10.9032, xc: float = -0.769231, xs: float = -0.65) -> torch.Tensor:
    """oxDNA ``_f5`` azimuthal window."""
    smooth = b * (xc - cosine).square()
    core = 1.0 - a * cosine.square()
    one = torch.ones_like(cosine)
    return torch.where(
        cosine <= xc,
        torch.zeros_like(cosine),
        torch.where(cosine < xs, smooth, torch.where(cosine < 0.0, core, one)),
    )


def repulsive_lj(
    distance: torch.Tensor,
    *,
    sigma: float,
    rstar: float,
    b: float,
    rc: float,
    epsilon: float = 2.0,
) -> torch.Tensor:
    """oxDNA shifted repulsive LJ with its quadratic cutoff branch.

    The native potential diverges at exact overlap. A small dtype-aware floor
    keeps malformed neural predictions finite while retaining a very large
    repulsive penalty and usable gradients above the floor.
    """
    floor = 5e-2 if distance.dtype in (torch.float16, torch.bfloat16, torch.float32) else 1e-3
    safe = distance.clamp_min(floor)
    ratio6 = (sigma / safe) ** 6
    lj = 4.0 * epsilon * (ratio6.square() - ratio6)
    tail = epsilon * b * (safe - rc).square()
    return torch.where(safe < rstar, lj, torch.where(safe < rc, tail, torch.zeros_like(safe)))


def fene_energy(distance: torch.Tensor, parameters: DNA2Parameters = DEFAULT_DNA2_PARAMETERS) -> torch.Tensor:
    """FAM024 capped-force FENE branch, including the source log/linear tail."""
    displacement = distance - parameters.fene_r0
    absolute = torch.abs(displacement)
    fmax = parameters.max_backbone_force
    finf = parameters.max_backbone_force_far
    delta2 = parameters.fene_delta**2
    xmax = (-parameters.fene_epsilon + math.sqrt(parameters.fene_epsilon**2 + 4.0 * fmax**2 * delta2)) / (2.0 * fmax)
    inner_argument = (1.0 - displacement.square() / delta2).clamp_min(torch.finfo(distance.dtype).eps)
    regular = -0.5 * parameters.fene_epsilon * torch.log(inner_argument)
    fene_xmax = -0.5 * parameters.fene_epsilon * math.log(1.0 - xmax**2 / delta2)
    long_xmax = (fmax - finf) * xmax * math.log(xmax) + finf * xmax
    tail = (fmax - finf) * xmax * torch.log(absolute.clamp_min(xmax)) + finf * absolute - long_xmax + fene_xmax
    return torch.where(absolute > xmax, tail, regular)


def _norm(vector: torch.Tensor) -> torch.Tensor:
    return torch.linalg.vector_norm(vector, dim=-1).clamp_min(1e-8)


def _dot(left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
    return torch.sum(left * right, dim=-1)


def _site_delta(
    center_delta: torch.Tensor,
    left_offset: torch.Tensor,
    right_offset: torch.Tensor,
) -> torch.Tensor:
    return center_delta + right_offset - left_offset


def _bonded_mask(candidate_index: torch.Tensor, bonded_index: torch.Tensor, node_count: int) -> torch.Tensor:
    if candidate_index.numel() == 0 or bonded_index.numel() == 0:
        return torch.zeros(candidate_index.shape[1], dtype=torch.bool, device=candidate_index.device)
    c0 = torch.minimum(candidate_index[0], candidate_index[1])
    c1 = torch.maximum(candidate_index[0], candidate_index[1])
    b0 = torch.minimum(bonded_index[0], bonded_index[1])
    b1 = torch.maximum(bonded_index[0], bonded_index[1])
    candidate_key = c0 * node_count + c1
    bonded_key = torch.unique(b0 * node_count + b1, sorted=True)
    location = torch.searchsorted(bonded_key, candidate_key)
    safe = location.clamp_max(max(0, len(bonded_key) - 1))
    return (location < len(bonded_key)) & (bonded_key[safe] == candidate_key)


def _bonded_terms(
    positions: torch.Tensor,
    rotations: torch.Tensor,
    sites: DNA2Sites,
    box: torch.Tensor,
    bonded_index: torch.Tensor,
    parameters: DNA2Parameters,
) -> tuple[dict[str, torch.Tensor], dict[str, torch.Tensor], dict[str, torch.Tensor]]:
    zero = positions.new_zeros(())
    if bonded_index.numel() == 0:
        return (
            {"fene": zero, "bonded_excluded_volume": zero, "stacking": zero},
            {"fene_domain": zero, "excluded_volume": zero},
            {"fene_domain_violations": zero, "bonded_excluded_contacts": zero},
        )
    p, q = bonded_index
    center = minimum_image_torch(positions[q] - positions[p], box)
    back_delta = _site_delta(center, sites.back_offset[p], sites.back_offset[q])
    back_distance = _norm(back_delta)
    fene = fene_energy(back_distance, parameters).sum()

    base_base = _norm(_site_delta(center, sites.base_offset[p], sites.base_offset[q]))
    base_back = _norm(_site_delta(center, sites.base_offset[p], sites.back_offset[q]))
    back_base = _norm(_site_delta(center, sites.back_offset[p], sites.base_offset[q]))
    bonded_excluded = (
        repulsive_lj(base_base, sigma=0.33, rstar=0.32, b=4119.70450017, rc=0.335388426126)
        + repulsive_lj(base_back, sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
        + repulsive_lj(back_base, sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
    ).sum()

    a1, a2, a3 = rotations[p, :, 0], rotations[p, :, 1], rotations[p, :, 2]
    b1, b2, b3 = rotations[q, :, 0], rotations[q, :, 1], rotations[q, :, 2]
    stack_delta = _site_delta(center, sites.stack_offset[p], sites.stack_offset[q])
    stack_distance = _norm(stack_delta)
    stack_direction = stack_delta / stack_distance[:, None]
    # Source uses the equal-groove backbone reference for stacking angles.
    back_reference = center - 0.4 * b1 + 0.4 * a1
    back_reference_direction = back_reference / _norm(back_reference)[:, None]
    radial = f1_radial(
        stack_distance, epsilon=parameters.stacking_epsilon, a=6.0, rc=0.9, r0=0.4,
        blow=-68.1857, bhigh=-3.12992, rlow=0.32, rhigh=0.75,
        rclow=0.23239, rchigh=0.956,
    )
    stacking = radial
    stacking = stacking * f4_cos(_dot(a3, b3), a=1.3, b=6.4381, t0=0.0, ts=0.8, tc=0.961538)
    stacking = stacking * f4_cos(-_dot(a3, stack_direction), a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959)
    stacking = stacking * f4_cos(-_dot(b3, stack_direction), a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959)
    stacking = stacking * f5_azimuth(_dot(a2, back_reference_direction))
    stacking = stacking * f5_azimuth(_dot(b2, back_reference_direction))

    fene_domain = torch.mean(torch.relu(torch.abs(back_distance - parameters.fene_r0) - parameters.fene_delta).square())
    excluded_barrier = torch.mean(
        torch.relu(0.32 - base_base).square()
        + torch.relu(0.50 - base_back).square()
        + torch.relu(0.50 - back_base).square()
    )
    return (
        {"fene": fene, "bonded_excluded_volume": bonded_excluded, "stacking": stacking.sum()},
        {"fene_domain": fene_domain, "excluded_volume": excluded_barrier},
        {
            "fene_domain_violations": torch.count_nonzero(
                torch.abs(back_distance - parameters.fene_r0) > parameters.fene_delta
            ),
            "bonded_excluded_contacts": (
                torch.count_nonzero(base_base < 0.32)
                + torch.count_nonzero(base_back < 0.50)
                + torch.count_nonzero(back_base < 0.50)
            ),
        },
    )


def _nonbonded_terms(
    positions: torch.Tensor,
    rotations: torch.Tensor,
    sites: DNA2Sites,
    center: torch.Tensor,
    pair_index: torch.Tensor,
    base_types: torch.Tensor,
    terminal_mask: torch.Tensor,
    parameters: DNA2Parameters,
) -> tuple[dict[str, torch.Tensor], torch.Tensor, dict[str, torch.Tensor]]:
    zero = positions.new_zeros(())
    if pair_index.numel() == 0:
        return (
            {name: zero for name in ENERGY_TERMS[3:]},
            zero,
            {"hydrogen_bonds": zero, "nonbonded_excluded_contacts": zero},
        )
    p, q = pair_index
    a1, a3 = rotations[p, :, 0], rotations[p, :, 2]
    b1, b3 = rotations[q, :, 0], rotations[q, :, 2]

    base_delta = _site_delta(center, sites.base_offset[p], sites.base_offset[q])
    base_distance = _norm(base_delta)
    base_direction = base_delta / base_distance[:, None]
    pbase_qback = _norm(_site_delta(center, sites.base_offset[p], sites.back_offset[q]))
    pback_qbase = _norm(_site_delta(center, sites.back_offset[p], sites.base_offset[q]))
    back_delta = _site_delta(center, sites.back_offset[p], sites.back_offset[q])
    back_distance = _norm(back_delta)

    nonbonded_excluded = (
        repulsive_lj(base_distance, sigma=0.33, rstar=0.32, b=4119.70450017, rc=0.335388426126)
        + repulsive_lj(pback_qbase, sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
        + repulsive_lj(pbase_qback, sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
        + repulsive_lj(back_distance, sigma=0.70, rstar=0.675, b=892.016223343, rc=0.711879214356)
    )

    common1 = -_dot(a1, b1)
    common2 = -_dot(b1, base_direction)
    common3 = _dot(a1, base_direction)
    common4 = _dot(a3, b3)
    common7 = -_dot(b3, base_direction)
    common8 = _dot(a3, base_direction)

    hb_radial = f1_radial(
        base_distance, epsilon=parameters.hydrogen_epsilon, a=8.0, rc=0.75, r0=0.4,
        blow=-126.243, bhigh=-7.87708, rlow=0.34, rhigh=0.7,
        rclow=0.276908, rchigh=0.783775,
    )
    complementary = (base_types[p] < 4) & (base_types[q] < 4) & ((base_types[p] + base_types[q]) == 3)
    hydrogen = hb_radial
    hydrogen = hydrogen * f4_cos(common1, a=1.5, b=4.16038, t0=0.0, ts=0.7, tc=0.952381)
    hydrogen = hydrogen * f4_cos(common2, a=1.5, b=4.16038, t0=0.0, ts=0.7, tc=0.952381)
    hydrogen = hydrogen * f4_cos(common3, a=1.5, b=4.16038, t0=0.0, ts=0.7, tc=0.952381)
    hydrogen = hydrogen * f4_cos(common4, a=0.46, b=0.133855, t0=math.pi, ts=0.7, tc=3.10559)
    hydrogen = hydrogen * f4_cos(common7, a=4.0, b=17.0526, t0=math.pi / 2, ts=0.45, tc=0.555556)
    hydrogen = hydrogen * f4_cos(common8, a=4.0, b=17.0526, t0=math.pi / 2, ts=0.45, tc=0.555556)
    hydrogen = torch.where(complementary, hydrogen, torch.zeros_like(hydrogen))

    cross = f2_radial(
        base_distance, k=47.5, rc=0.675, r0=0.575, blow=-0.888889,
        bhigh=-0.888889, rlow=0.495, rhigh=0.655, rclow=0.45, rchigh=0.7,
    )
    cross = cross * f4_cos(common1, a=2.25, b=7.00545, t0=math.pi - 2.35, ts=0.58, tc=0.766284)
    cross = cross * f4_cos(common2, a=1.70, b=6.2469, t0=1.0, ts=0.68, tc=0.865052)
    cross = cross * f4_cos(common3, a=1.70, b=6.2469, t0=1.0, ts=0.68, tc=0.865052)
    cross = cross * (
        f4_cos(common4, a=1.5, b=2.59556, t0=0.0, ts=0.65, tc=1.02564)
        + f4_cos(-common4, a=1.5, b=2.59556, t0=0.0, ts=0.65, tc=1.02564)
    )
    cross = cross * (
        f4_cos(common7, a=1.70, b=6.2469, t0=0.875, ts=0.68, tc=0.865052)
        + f4_cos(-common7, a=1.70, b=6.2469, t0=0.875, ts=0.68, tc=0.865052)
    )
    cross = cross * (
        f4_cos(common8, a=1.70, b=6.2469, t0=0.875, ts=0.68, tc=0.865052)
        + f4_cos(-common8, a=1.70, b=6.2469, t0=0.875, ts=0.68, tc=0.865052)
    )

    stack_delta = _site_delta(center, sites.stack_offset[p], sites.stack_offset[q])
    stack_distance = _norm(stack_delta)
    stack_direction = stack_delta / stack_distance[:, None]
    cost1 = -_dot(a1, b1)
    cost4 = _dot(a3, b3)
    cost5 = _dot(a3, stack_direction)
    cost6 = -_dot(b3, stack_direction)
    coax = f2_radial(
        stack_distance, k=58.5, rc=0.6, r0=0.4, blow=-2.13158,
        bhigh=-2.13158, rlow=0.22, rhigh=0.58, rclow=0.177778, rchigh=0.6222222,
    )
    acos_epsilon = 1e-6 if cost1.dtype in (torch.float16, torch.bfloat16, torch.float32) else 1e-12
    theta1 = torch.acos(cost1.clamp(-1.0 + acos_epsilon, 1.0 - acos_epsilon))
    coax_t1 = f4_angle(theta1, a=2.0, b=10.9032, t0=math.pi - 0.25, ts=0.65, tc=0.769231)
    coax_t1 = coax_t1 + torch.where(theta1 > math.pi - 0.1 * 0.25, 20.0 * (theta1 - (math.pi - 0.025)).square(), torch.zeros_like(theta1))
    coax = coax * coax_t1
    coax = coax * f4_cos(cost4, a=1.3, b=6.4381, t0=0.0, ts=0.8, tc=0.961538)
    coax = coax * (
        f4_cos(cost5, a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959)
        + f4_cos(-cost5, a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959)
    )
    coax = coax * (
        f4_cos(cost6, a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959)
        + f4_cos(-cost6, a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959)
    )

    length = parameters.debye_lambda
    rhigh = parameters.debye_rhigh
    rc = parameters.debye_rc
    debye = torch.where(
        back_distance < rhigh,
        torch.exp(-back_distance / length) * parameters.debye_prefactor / back_distance,
        torch.where(back_distance < rc, parameters.debye_b * (back_distance - rc).square(), torch.zeros_like(back_distance)),
    )
    if parameters.half_charged_ends:
        charge = torch.where(terminal_mask, positions.new_tensor(0.5), positions.new_tensor(1.0))
        debye = debye * charge[p] * charge[q]

    excluded_barrier = torch.mean(
        torch.relu(0.32 - base_distance).square()
        + torch.relu(0.50 - pback_qbase).square()
        + torch.relu(0.50 - pbase_qback).square()
        + torch.relu(0.675 - back_distance).square()
    )
    return (
        {
            "nonbonded_excluded_volume": nonbonded_excluded.sum(),
            "hydrogen_bonding": hydrogen.sum(),
            "cross_stacking": cross.sum(),
            "coaxial_stacking": coax.sum(),
            "debye_huckel": debye.sum(),
        },
        excluded_barrier,
        {
            "hydrogen_bonds": torch.count_nonzero(hydrogen < -0.1),
            "nonbonded_excluded_contacts": (
                torch.count_nonzero(base_distance < 0.32)
                + torch.count_nonzero(pback_qbase < 0.50)
                + torch.count_nonzero(pbase_qback < 0.50)
                + torch.count_nonzero(back_distance < 0.675)
            ),
        },
    )


def evaluate_dna2_energy(
    positions: torch.Tensor,
    rotations: torch.Tensor,
    box: torch.Tensor,
    bonded_edge_index: torch.Tensor,
    candidate_pairs: PhysicsCandidatePairs,
    base_types: torch.Tensor,
    terminal_mask: torch.Tensor,
    parameters: DNA2Parameters = DEFAULT_DNA2_PARAMETERS,
) -> DNA2EnergyEvaluation:
    """Evaluate all DNA2 terms without adding candidate pairs to the GNN."""
    node_count = len(positions)
    if rotations.shape != (node_count, 3, 3):
        raise ValueError("rotations must have shape [N,3,3]")
    if base_types.shape != (node_count,) or terminal_mask.shape != (node_count,):
        raise ValueError("base_types and terminal_mask must have shape [N]")
    if bonded_edge_index.ndim != 2 or bonded_edge_index.shape[0] != 2:
        raise ValueError("bonded_edge_index must have shape [2,B]")
    if candidate_pairs.pair_index.device != positions.device:
        raise ValueError("candidate pairs and positions must share a device")

    sites = dna2_sites(positions, rotations)
    bonded, barriers, bonded_diagnostics = _bonded_terms(
        positions, rotations, sites, box, bonded_edge_index, parameters
    )
    candidate_index = candidate_pairs.pair_index
    is_bonded = _bonded_mask(candidate_index, bonded_edge_index, node_count)
    nonbonded_index = candidate_index[:, ~is_bonded]
    nonbonded_displacement = candidate_pairs.displacement[~is_bonded]
    nonbonded, excluded_barrier, nonbonded_diagnostics = _nonbonded_terms(
        positions, rotations, sites, nonbonded_displacement, nonbonded_index,
        base_types, terminal_mask, parameters,
    )
    terms = {**bonded, **nonbonded}
    per_node = {name: value / max(1, node_count) for name, value in terms.items()}
    barriers = {**barriers, "excluded_volume": barriers["excluded_volume"] + excluded_barrier}
    orthogonality, determinant = rotation_frame_error(rotations)
    barriers = {**barriers, "rotation_orthogonality": orthogonality, "rotation_determinant": determinant}
    return DNA2EnergyEvaluation(
        terms=terms,
        per_node=per_node,
        barriers=barriers,
        diagnostics={**bonded_diagnostics, **nonbonded_diagnostics},
        candidate_count=candidate_pairs.pair_count,
        nonbonded_count=int(nonbonded_index.shape[1]),
        overflow_nodes=candidate_pairs.overflow_nodes,
    )


def _native_base_pair_index(edge_index: torch.Tensor, edge_types: torch.Tensor, kind: int) -> torch.Tensor:
    """Return unique undirected topology pairs of one typed edge class."""
    selected = edge_index[:, edge_types == int(kind)]
    if selected.numel() == 0:
        return selected.reshape(2, 0)
    left = torch.minimum(selected[0], selected[1])
    right = torch.maximum(selected[0], selected[1])
    n = int(edge_index.max().item()) + 1
    keys = torch.unique(left * n + right, sorted=True)
    return torch.stack((torch.div(keys, n, rounding_mode="floor"), torch.remainder(keys, n)), dim=0)


def evaluate_hydrogen_bonding(
    positions: torch.Tensor,
    rotations: torch.Tensor,
    box: torch.Tensor,
    pair_index: torch.Tensor,
    base_types: torch.Tensor,
    *,
    parameters: DNA2Parameters = DEFAULT_DNA2_PARAMETERS,
) -> torch.Tensor:
    """Evaluate only the oxDNA2 hydrogen-bond term on supplied native pairs.

    The pair list is normally the fixed base-pair topology, so no spatial
    candidate construction is required.  This deliberately omits all other
    nonbonded terms.
    """
    if pair_index.numel() == 0:
        return positions.new_zeros(())
    p, q = pair_index
    sites = dna2_sites(positions, rotations)
    center = minimum_image_torch(positions[q] - positions[p], box)
    a1, a3 = rotations[p, :, 0], rotations[p, :, 2]
    b1, b3 = rotations[q, :, 0], rotations[q, :, 2]
    base_delta = _site_delta(center, sites.base_offset[p], sites.base_offset[q])
    base_distance = _norm(base_delta)
    base_direction = base_delta / base_distance[:, None]
    hydrogen = f1_radial(
        base_distance, epsilon=parameters.hydrogen_epsilon, a=8.0, rc=0.75, r0=0.4,
        blow=-126.243, bhigh=-7.87708, rlow=0.34, rhigh=0.7,
        rclow=0.276908, rchigh=0.783775,
    )
    hydrogen = hydrogen * f4_cos(-_dot(a1, b1), a=1.5, b=4.16038, t0=0.0, ts=0.7, tc=0.952381)
    hydrogen = hydrogen * f4_cos(-_dot(b1, base_direction), a=1.5, b=4.16038, t0=0.0, ts=0.7, tc=0.952381)
    hydrogen = hydrogen * f4_cos(_dot(a1, base_direction), a=1.5, b=4.16038, t0=0.0, ts=0.7, tc=0.952381)
    hydrogen = hydrogen * f4_cos(_dot(a3, b3), a=0.46, b=0.133855, t0=math.pi, ts=0.7, tc=3.10559)
    hydrogen = hydrogen * f4_cos(-_dot(b3, base_direction), a=4.0, b=17.0526, t0=math.pi / 2, ts=0.45, tc=0.555556)
    hydrogen = hydrogen * f4_cos(_dot(a3, base_direction), a=4.0, b=17.0526, t0=math.pi / 2, ts=0.45, tc=0.555556)
    complementary = (base_types[p] < 4) & (base_types[q] < 4) & ((base_types[p] + base_types[q]) == 3)
    return torch.where(complementary, hydrogen, torch.zeros_like(hydrogen)).sum()


def evaluate_edge_energy_labels(
    positions: torch.Tensor,
    rotations: torch.Tensor,
    box: torch.Tensor,
    edge_index: torch.Tensor,
    edge_kind: torch.Tensor,
    base_types: torch.Tensor,
    terminal_mask: torch.Tensor,
    *,
    bonded_mask: torch.Tensor | None = None,
    parameters: DNA2Parameters = DEFAULT_DNA2_PARAMETERS,
) -> torch.Tensor:
    """Return source-matched DNA2 energy labels for directed graph edges.

    The output has shape ``[E, len(ENERGY_TERMS)]`` and uses the exact
    differentiable DNA2 terms implemented in this module.  It is intended as
    a supervised edge feature target for a graph encoder.  Values are genuine
    reduced-unit energy evaluations from the oxDNA2 interaction equations;
    relation flags or distances are never substituted for them.  Directed
    duplicate edges each receive the pair value, so summing an undirected pair
    requires de-duplication (or division by two).

    ``bonded_mask`` must identify `.top` backbone pairs.  A crossover annotation
    alone is not a separate oxDNA interaction and is therefore treated as a
    nonbonded candidate unless it is also marked bonded.
    """
    if edge_index.ndim != 2 or edge_index.shape[0] != 2:
        raise ValueError("edge_index must have shape [2,E]")
    if edge_kind.shape != (edge_index.shape[1],):
        raise ValueError("edge_kind must have shape [E]")
    if bonded_mask is None:
        bonded_mask = edge_kind == 1
    if bonded_mask.shape != edge_kind.shape:
        raise ValueError("bonded_mask must have shape [E]")
    if len(base_types) != len(positions) or len(terminal_mask) != len(positions):
        raise ValueError("base_types and terminal_mask must match positions")
    p, q = edge_index
    if edge_index.numel() == 0:
        return positions.new_zeros((0, len(ENERGY_TERMS)))
    sites = dna2_sites(positions, rotations)
    center = minimum_image_torch(positions[q] - positions[p], box)
    a1, a2, a3 = rotations[p, :, 0], rotations[p, :, 1], rotations[p, :, 2]
    b1, b2, b3 = rotations[q, :, 0], rotations[q, :, 1], rotations[q, :, 2]
    values = positions.new_zeros((len(p), len(ENERGY_TERMS)))

    # Bonded terms use the same capped FENE, excluded-volume, and stacking
    # equations as `_bonded_terms`, but retain one value per graph edge.
    back_delta = _site_delta(center, sites.back_offset[p], sites.back_offset[q])
    back_distance = _norm(back_delta)
    fene = fene_energy(back_distance, parameters)
    base_base = _norm(_site_delta(center, sites.base_offset[p], sites.base_offset[q]))
    base_back = _norm(_site_delta(center, sites.base_offset[p], sites.back_offset[q]))
    back_base = _norm(_site_delta(center, sites.back_offset[p], sites.base_offset[q]))
    bonded_excluded = (
        repulsive_lj(base_base, sigma=0.33, rstar=0.32, b=4119.70450017, rc=0.335388426126)
        + repulsive_lj(base_back, sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
        + repulsive_lj(back_base, sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
    )
    stack_delta = _site_delta(center, sites.stack_offset[p], sites.stack_offset[q])
    stack_distance = _norm(stack_delta)
    stack_direction = stack_delta / stack_distance[:, None]
    back_reference = center - 0.4 * b1 + 0.4 * a1
    back_reference_direction = back_reference / _norm(back_reference)[:, None]
    stacking = f1_radial(
        stack_distance, epsilon=parameters.stacking_epsilon, a=6.0, rc=0.9, r0=0.4,
        blow=-68.1857, bhigh=-3.12992, rlow=0.32, rhigh=0.75,
        rclow=0.23239, rchigh=0.956,
    )
    stacking = stacking * f4_cos(_dot(a3, b3), a=1.3, b=6.4381, t0=0.0, ts=0.8, tc=0.961538)
    stacking = stacking * f4_cos(-_dot(a3, stack_direction), a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959)
    stacking = stacking * f4_cos(-_dot(b3, stack_direction), a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959)
    stacking = stacking * f5_azimuth(_dot(a2, back_reference_direction))
    stacking = stacking * f5_azimuth(_dot(b2, back_reference_direction))
    values[:, 0] = torch.where(bonded_mask, fene, values[:, 0])
    values[:, 1] = torch.where(bonded_mask, bonded_excluded, values[:, 1])
    values[:, 2] = torch.where(bonded_mask, stacking, values[:, 2])

    # Nonbonded terms are evaluated on the same candidate pair, but omitted for
    # `.top` bonded edges. This mirrors the source interaction dispatch.
    nonbonded_excluded = (
        repulsive_lj(_norm(_site_delta(center, sites.base_offset[p], sites.base_offset[q])), sigma=0.33, rstar=0.32, b=4119.70450017, rc=0.335388426126)
        + repulsive_lj(_norm(_site_delta(center, sites.back_offset[p], sites.base_offset[q])), sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
        + repulsive_lj(_norm(_site_delta(center, sites.base_offset[p], sites.back_offset[q])), sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
        + repulsive_lj(_norm(_site_delta(center, sites.back_offset[p], sites.back_offset[q])), sigma=0.70, rstar=0.675, b=892.016223343, rc=0.711879214356)
    )
    base_delta = _site_delta(center, sites.base_offset[p], sites.base_offset[q])
    base_distance = _norm(base_delta)
    base_direction = base_delta / base_distance[:, None]
    common1, common2, common3 = -_dot(a1, b1), -_dot(b1, base_direction), _dot(a1, base_direction)
    common4, common7, common8 = _dot(a3, b3), -_dot(b3, base_direction), _dot(a3, base_direction)
    hydrogen = f1_radial(base_distance, epsilon=parameters.hydrogen_epsilon, a=8.0, rc=0.75, r0=0.4, blow=-126.243, bhigh=-7.87708, rlow=0.34, rhigh=0.7, rclow=0.276908, rchigh=0.783775)
    hydrogen = hydrogen * f4_cos(common1, a=1.5, b=4.16038, t0=0.0, ts=0.7, tc=0.952381) * f4_cos(common2, a=1.5, b=4.16038, t0=0.0, ts=0.7, tc=0.952381) * f4_cos(common3, a=1.5, b=4.16038, t0=0.0, ts=0.7, tc=0.952381) * f4_cos(common4, a=0.46, b=0.133855, t0=math.pi, ts=0.7, tc=3.10559) * f4_cos(common7, a=4.0, b=17.0526, t0=math.pi / 2, ts=0.45, tc=0.555556) * f4_cos(common8, a=4.0, b=17.0526, t0=math.pi / 2, ts=0.45, tc=0.555556)
    complementary = (base_types[p] < 4) & (base_types[q] < 4) & ((base_types[p] + base_types[q]) == 3)
    hydrogen = torch.where(complementary, hydrogen, torch.zeros_like(hydrogen))
    # Cross-stacking and coaxial stacking use the exact source windows.
    cross = f2_radial(base_distance, k=47.5, rc=0.675, r0=0.575, blow=-0.888889, bhigh=-0.888889, rlow=0.495, rhigh=0.655, rclow=0.45, rchigh=0.7)
    cross = cross * f4_cos(common1, a=2.25, b=7.00545, t0=math.pi - 2.35, ts=0.58, tc=0.766284) * f4_cos(common2, a=1.70, b=6.2469, t0=1.0, ts=0.68, tc=0.865052) * f4_cos(common3, a=1.70, b=6.2469, t0=1.0, ts=0.68, tc=0.865052)
    cross = cross * (f4_cos(common4, a=1.5, b=2.59556, t0=0.0, ts=0.65, tc=1.02564) + f4_cos(-common4, a=1.5, b=2.59556, t0=0.0, ts=0.65, tc=1.02564)) * (f4_cos(common7, a=1.70, b=6.2469, t0=0.875, ts=0.68, tc=0.865052) + f4_cos(-common7, a=1.70, b=6.2469, t0=0.875, ts=0.68, tc=0.865052)) * (f4_cos(common8, a=1.70, b=6.2469, t0=0.875, ts=0.68, tc=0.865052) + f4_cos(-common8, a=1.70, b=6.2469, t0=0.875, ts=0.68, tc=0.865052))
    stack_distance = _norm(stack_delta)
    cost1, cost4 = -_dot(a1, b1), _dot(a3, b3)
    cost5, cost6 = _dot(a3, stack_direction), -_dot(b3, stack_direction)
    coax = f2_radial(stack_distance, k=58.5, rc=0.6, r0=0.4, blow=-2.13158, bhigh=-2.13158, rlow=0.22, rhigh=0.58, rclow=0.177778, rchigh=0.6222222)
    theta1 = torch.acos(cost1.clamp(-1.0 + 1e-6, 1.0 - 1e-6))
    coax = coax * (f4_angle(theta1, a=2.0, b=10.9032, t0=math.pi - 0.25, ts=0.65, tc=0.769231) + torch.where(theta1 > math.pi - 0.025, 20.0 * (theta1 - (math.pi - 0.025)).square(), torch.zeros_like(theta1)))
    coax = coax * f4_cos(cost4, a=1.3, b=6.4381, t0=0.0, ts=0.8, tc=0.961538) * (f4_cos(cost5, a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959) + f4_cos(-cost5, a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959)) * (f4_cos(cost6, a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959) + f4_cos(-cost6, a=0.9, b=3.89361, t0=0.0, ts=0.95, tc=1.16959))
    back_distance_nonbonded = _norm(_site_delta(center, sites.back_offset[p], sites.back_offset[q]))
    debye = torch.where(back_distance_nonbonded < parameters.debye_rhigh, torch.exp(-back_distance_nonbonded / parameters.debye_lambda) * parameters.debye_prefactor / back_distance_nonbonded, torch.where(back_distance_nonbonded < parameters.debye_rc, parameters.debye_b * (back_distance_nonbonded - parameters.debye_rc).square(), torch.zeros_like(back_distance_nonbonded)))
    charge = torch.where(terminal_mask, positions.new_tensor(0.5), positions.new_tensor(1.0))
    if parameters.half_charged_ends:
        debye = debye * charge[p] * charge[q]
    mask = ~bonded_mask
    values[:, 3] = torch.where(mask, nonbonded_excluded, values[:, 3])
    values[:, 4] = torch.where(mask, hydrogen, values[:, 4])
    values[:, 5] = torch.where(mask, cross, values[:, 5])
    values[:, 6] = torch.where(mask, coax, values[:, 6])
    values[:, 7] = torch.where(mask, debye, values[:, 7])
    return values


def evaluate_nonbonded_excluded_volume(
    positions: torch.Tensor,
    rotations: torch.Tensor,
    pair_index: torch.Tensor,
    displacement: torch.Tensor,
) -> torch.Tensor:
    """Evaluate only nonbonded excluded-volume energy on candidate pairs."""
    if pair_index.numel() == 0:
        return positions.new_zeros(())
    sites = dna2_sites(positions, rotations)
    p, q = pair_index
    base_base = _norm(_site_delta(displacement, sites.base_offset[p], sites.base_offset[q]))
    pback_qbase = _norm(_site_delta(displacement, sites.back_offset[p], sites.base_offset[q]))
    pbase_qback = _norm(_site_delta(displacement, sites.base_offset[p], sites.back_offset[q]))
    back_back = _norm(_site_delta(displacement, sites.back_offset[p], sites.back_offset[q]))
    return (
        repulsive_lj(base_base, sigma=0.33, rstar=0.32, b=4119.70450017, rc=0.335388426126)
        + repulsive_lj(pback_qbase, sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
        + repulsive_lj(pbase_qback, sigma=0.515, rstar=0.50, b=1707.30627298, rc=0.52329943261)
        + repulsive_lj(back_back, sigma=0.70, rstar=0.675, b=892.016223343, rc=0.711879214356)
    ).sum()


def evaluate_reduced_physics(
    positions: torch.Tensor,
    rotations: torch.Tensor,
    box: torch.Tensor,
    bonded_edge_index: torch.Tensor,
    candidate_pairs: PhysicsCandidatePairs,
    native_base_pairs: torch.Tensor,
    base_types: torch.Tensor,
) -> DNA2EnergyEvaluation:
    """Evaluate only nonbonded excluded volume and native-pair H-bonding."""
    candidate_index = candidate_pairs.pair_index
    if candidate_index.numel() and bonded_edge_index.numel():
        is_bonded = _bonded_mask(candidate_index, bonded_edge_index, int(positions.shape[0]))
        candidate_index = candidate_index[:, ~is_bonded]
        displacement = candidate_pairs.displacement[~is_bonded]
    else:
        displacement = candidate_pairs.displacement
    excluded = evaluate_nonbonded_excluded_volume(positions, rotations, candidate_index, displacement)
    hbond = evaluate_hydrogen_bonding(positions, rotations, box, native_base_pairs, base_types)
    zero = positions.new_zeros(())
    terms = {
        "fene": zero, "bonded_excluded_volume": zero, "stacking": zero,
        "nonbonded_excluded_volume": excluded, "hydrogen_bonding": hbond,
        "cross_stacking": zero, "coaxial_stacking": zero, "debye_huckel": zero,
    }
    per_node = {name: value / max(1, int(positions.shape[0])) for name, value in terms.items()}
    return DNA2EnergyEvaluation(
        terms=terms, per_node=per_node,
        barriers={"fene_domain": zero, "excluded_volume": zero,
                  "rotation_orthogonality": zero, "rotation_determinant": zero},
        diagnostics={}, candidate_count=candidate_pairs.pair_count,
        nonbonded_count=int(candidate_index.shape[1]), overflow_nodes=candidate_pairs.overflow_nodes,
    )


def standardized_energy_loss(
    predicted: DNA2EnergyEvaluation,
    target: DNA2EnergyEvaluation | Mapping[str, torch.Tensor],
    weights: Mapping[str, float],
    scales: Mapping[str, float],
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    """Data-anchored term-wise energy error normalized per nucleotide."""
    if set(weights) - set(ENERGY_TERMS):
        raise ValueError("unknown DNA2 energy weight")
    losses: dict[str, torch.Tensor] = {}
    total = next(iter(predicted.terms.values())).new_zeros(())
    target_values = target.per_node if isinstance(target, DNA2EnergyEvaluation) else target
    for name in ENERGY_TERMS:
        scale = max(float(scales.get(name, 1.0)), 1e-8)
        standardized_error = (
            predicted.per_node[name] - target_values[name].detach()
        ) / scale
        # Fresh decoders can contain severe overlaps, for which the native LJ
        # energy is many orders of magnitude above the training ensemble.
        # asinh is quadratic near the target and logarithmic in that far tail,
        # preserving a corrective gradient without overwhelming coordinate and
        # orientation learning during the curriculum.
        losses[name] = torch.asinh(standardized_error).square()
        total = total + float(weights.get(name, 0.0)) * losses[name]
    return total, losses
