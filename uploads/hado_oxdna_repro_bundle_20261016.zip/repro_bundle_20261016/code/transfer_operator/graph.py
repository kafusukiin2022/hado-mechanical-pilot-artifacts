from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.spatial import cKDTree

from .geometry import rotation_log
from .oxdna_io import Topology

EDGE_SPATIAL = 0
EDGE_BACKBONE = 1
EDGE_BASE_PAIR = 2
EDGE_CROSSOVER = 3
EDGE_STACKING = 4
EDGE_TYPE_COUNT = 5


@dataclass(frozen=True)
class NeighborGraph:
    edge_index: np.ndarray
    displacement: np.ndarray
    edge_kind: np.ndarray


def topology_node_features(topology: Topology, *, include_design: bool = False) -> np.ndarray:
    base_order = {base: index for index, base in enumerate("ACGT")}
    features = np.zeros((topology.nucleotide_count, 6), dtype=np.float32)
    for node, base in enumerate(topology.base):
        if base in base_order:
            features[node, base_order[str(base)]] = 1.0
    degree = np.zeros(topology.nucleotide_count, dtype=np.float32)
    for left, right in topology.backbone_edges:
        degree[left] += 1.0
        degree[right] += 1.0
    features[:, 4] = degree < 2
    features[:, 5] = degree / 2.0
    if not include_design:
        return features
    # Optional design metadata is static and therefore safe to use as node
    # conditioning.  Continuous identifiers are normalized only for scale;
    # they do not replace explicit relation edge types.
    extra = np.zeros((topology.nucleotide_count, 4), dtype=np.float32)
    extra[:, 0] = topology.node_scaffold.astype(np.float32) if len(topology.node_scaffold) else 0.0
    if len(topology.strand):
        extra[:, 1] = topology.strand.astype(np.float32) / max(float(np.max(topology.strand)), 1.0)
    if len(topology.virtual_helix):
        valid = topology.virtual_helix >= 0
        extra[valid, 2] = topology.virtual_helix[valid].astype(np.float32) / max(float(np.max(topology.virtual_helix[valid])), 1.0)
    if len(topology.design_offset):
        valid = topology.design_offset >= 0
        extra[valid, 3] = topology.design_offset[valid].astype(np.float32) / max(float(np.max(topology.design_offset[valid])), 1.0)
    return np.concatenate((features, extra), axis=-1)


def dilated_backbone_edges(topology: Topology, hops: tuple[int, ...] = (1,)) -> tuple[np.ndarray, np.ndarray]:
    """Build directed fixed-topology edges at selected same-strand hops.

    Unlike a spatial radius graph, these edges are known before sampling and
    therefore provide cheap medium-range communication without future leakage.
    """
    hops = tuple(sorted({int(hop) for hop in hops}))
    if not hops or any(hop <= 0 for hop in hops):
        raise ValueError("hops must contain positive integers")
    edges: list[tuple[int, int, int]] = []
    for strand in np.unique(topology.strand):
        nodes = np.flatnonzero(topology.strand == strand)
        for hop in hops:
            if hop >= len(nodes):
                continue
            for left, right in zip(nodes[:-hop], nodes[hop:]):
                edges.extend(((int(left), int(right), hop), (int(right), int(left), hop)))
    if not edges:
        return np.empty((2, 0), dtype=np.int64), np.empty(0, dtype=np.int64)
    values = np.asarray(edges, dtype=np.int64)
    return values[:, :2].T, values[:, 2]


def minimum_image_displacement(delta: np.ndarray, box: np.ndarray) -> np.ndarray:
    box = np.asarray(box)
    if box.shape != (3,) or np.any(box <= 0):
        raise ValueError("orthogonal box must contain three positive lengths")
    return delta - box * np.rint(delta / box)


def invariant_edge_features(
    displacement: np.ndarray,
    receiver_rotation: np.ndarray,
    sender_rotation: np.ndarray,
    edge_kind: np.ndarray,
) -> np.ndarray:
    body_displacement = np.einsum("ni,nij->nj", displacement, receiver_rotation)
    relative_rotation = np.swapaxes(receiver_rotation, -1, -2) @ sender_rotation
    distance = np.linalg.norm(displacement, axis=-1, keepdims=True)
    kind = np.eye(EDGE_TYPE_COUNT, dtype=np.float32)[np.asarray(edge_kind, dtype=np.int64)]
    return np.concatenate((body_displacement, distance, rotation_log(relative_rotation), kind), axis=-1).astype(np.float32)


def se3_edge_features(
    displacement: np.ndarray,
    receiver_rotation: np.ndarray,
    sender_rotation: np.ndarray,
    edge_kind: np.ndarray,
    energy_labels: np.ndarray | None = None,
) -> np.ndarray:
    """Return invariant edge channels for an SE(3)-equivariant message pass.

    The first channels are the receiver-body displacement and distance, followed
    by the relative SO(3) logarithm and explicit relation flags.  The unit
    displacement and a signed triple product expose local handedness: the
    triple product is invariant under proper rotations and changes sign under a
    reflection.  These are geometric/type proxies, not decomposed oxDNA
    hydrogen-bond or stacking energies; true interaction energies require force
    decomposition labels and must be supplied separately.
    """
    displacement = np.asarray(displacement, dtype=np.float32)
    receiver_rotation = np.asarray(receiver_rotation, dtype=np.float32)
    sender_rotation = np.asarray(sender_rotation, dtype=np.float32)
    edge_kind = np.asarray(edge_kind, dtype=np.int64).reshape(-1)
    if displacement.ndim != 2 or displacement.shape[1] != 3:
        raise ValueError("displacement must have shape [edges, 3]")
    if receiver_rotation.shape != (len(displacement), 3, 3) or sender_rotation.shape != receiver_rotation.shape:
        raise ValueError("edge rotations must have shape [edges, 3, 3]")
    if len(edge_kind) != len(displacement):
        raise ValueError("edge_kind must match displacement length")
    body = np.einsum("ni,nij->nj", displacement, receiver_rotation)
    distance = np.linalg.norm(displacement, axis=-1, keepdims=True)
    unit_body = body / np.maximum(np.linalg.norm(body, axis=-1, keepdims=True), 1e-8)
    relative = np.swapaxes(receiver_rotation, -1, -2) @ sender_rotation
    relative_log = rotation_log(relative)
    kind = np.eye(EDGE_TYPE_COUNT, dtype=np.float32)[np.clip(edge_kind, 0, EDGE_TYPE_COUNT - 1)]
    # The first body axis of each nucleotide and the edge displacement form a
    # handed local triad.  Proper rotations preserve this scalar; reflections
    # reverse it, so a model can distinguish chiral environments.
    receiver_axis = receiver_rotation[..., :, 0]
    sender_axis = sender_rotation[..., :, 0]
    # Use the unit edge direction for the handedness scalar.  A previous
    # distance-normalized triple product amplified coincident/near-coincident
    # candidate edges (which can occur in dense oxDNA graphs) by 1/r^2 and
    # destabilized rollout inference.  This form is dimensionless and bounded
    # for orthonormal frames while retaining the reflection sign flip.
    chirality = np.sum(np.cross(receiver_axis, sender_axis) * unit_body, axis=-1, keepdims=True)
    relation_flags = np.stack(
        (
            edge_kind == EDGE_BASE_PAIR,
            edge_kind == EDGE_STACKING,
            edge_kind == EDGE_CROSSOVER,
            np.zeros_like(edge_kind, dtype=bool),  # coaxial relation is not in Topology yet
        ), axis=-1,
    ).astype(np.float32)
    values = np.concatenate(
        (body, distance, unit_body, relative_log, kind, chirality, relation_flags), axis=-1,
    )
    if energy_labels is not None:
        labels = np.asarray(energy_labels, dtype=np.float32)
        if labels.ndim != 2 or labels.shape[0] != len(displacement):
            raise ValueError("energy_labels must have shape [edges, channels]")
        values = np.concatenate((values, labels), axis=-1)
    return values.astype(np.float32)


def build_neighbor_graph(
    position: np.ndarray,
    box: np.ndarray,
    backbone_edges: np.ndarray,
    cutoff: float,
    max_spatial_neighbors: int | None = None,
    *,
    base_pair_edges: np.ndarray | None = None,
    crossover_edges: np.ndarray | None = None,
    stacking_edges: np.ndarray | None = None,
) -> NeighborGraph:
    position = np.asarray(position)
    box = np.asarray(box)
    backbone_edges = np.asarray(backbone_edges, dtype=np.int64).reshape(-1, 2)
    if position.ndim != 2 or position.shape[1] != 3:
        raise ValueError("position must have shape [nodes, 3]")
    if cutoff <= 0:
        raise ValueError("cutoff must be positive")
    if max_spatial_neighbors is not None and max_spatial_neighbors <= 0:
        raise ValueError("max_spatial_neighbors must be positive")
    if box.shape != (3,) or np.any(box <= 0):
        raise ValueError("orthogonal box must contain three positive lengths")

    if not np.isfinite(position).all():
        raise ValueError("position contains non-finite coordinates")
    # cKDTree requires 0 <= coordinate < boxsize; nextafter handles exact-box
    # values that can arise from floating-point periodic wrapping.
    wrapped = np.mod(position, box)
    wrapped = np.minimum(wrapped, np.nextafter(box, 0.0))
    edge_kind: dict[tuple[int, int], int] = {}
    spatial_pairs = cKDTree(wrapped, boxsize=box).query_pairs(cutoff, output_type="ndarray")
    if len(spatial_pairs):
        sender = np.concatenate((spatial_pairs[:, 0], spatial_pairs[:, 1]))
        receiver = np.concatenate((spatial_pairs[:, 1], spatial_pairs[:, 0]))
        if max_spatial_neighbors is not None:
            delta = minimum_image_displacement(position[sender] - position[receiver], box)
            distance_squared = np.einsum("ij,ij->i", delta, delta)
            order = np.lexsort((sender, distance_squared, receiver))
            sorted_receiver = receiver[order]
            starts = np.r_[0, np.flatnonzero(np.diff(sorted_receiver)) + 1]
            counts = np.diff(np.r_[starts, len(order)])
            rank = np.arange(len(order)) - np.repeat(starts, counts)
            keep = order[rank < max_spatial_neighbors]
            sender, receiver = sender[keep], receiver[keep]
        for left, right in zip(sender, receiver):
            edge_kind[(int(left), int(right))] = EDGE_SPATIAL

    for left, right in backbone_edges:
        if left == right or not (0 <= left < len(position) and 0 <= right < len(position)):
            raise ValueError("backbone edge contains an invalid node index")
        edge_kind[(int(left), int(right))] = EDGE_BACKBONE
        edge_kind[(int(right), int(left))] = EDGE_BACKBONE
    design_edges: list[tuple[int, int, int]] = []
    for edges, kind in ((base_pair_edges, EDGE_BASE_PAIR), (crossover_edges, EDGE_CROSSOVER), (stacking_edges, EDGE_STACKING)):
        if edges is None:
            continue
        for left, right in np.asarray(edges, dtype=np.int64).reshape(-1, 2):
            if left == right or not (0 <= left < len(position) and 0 <= right < len(position)):
                raise ValueError("design edge contains an invalid node index")
            # Keep design relations as separate typed edges even when they
            # coincide geometrically with a backbone edge (multi-relational
            # message passing must see both semantics).
            for a, b in ((int(left), int(right)), (int(right), int(left))):
                if edge_kind.get((a, b)) != kind:
                    design_edges.append((a, b, kind))

    ordered = sorted(edge_kind)
    if design_edges:
        ordered.extend((a, b) for a, b, _ in design_edges)
    edge_index = np.asarray(ordered, dtype=np.int64).T if ordered else np.empty((2, 0), dtype=np.int64)
    displacement = (
        minimum_image_displacement(position[edge_index[0]] - position[edge_index[1]], box)
        if ordered
        else np.empty((0, 3), dtype=position.dtype)
    )
    kinds = np.asarray([edge_kind[edge] for edge in ordered[:len(edge_kind)]] + [kind for _, _, kind in design_edges], dtype=np.int8)
    return NeighborGraph(edge_index=edge_index, displacement=displacement, edge_kind=kinds)


def build_topology_graph(
    position: np.ndarray,
    box: np.ndarray,
    backbone_edges: np.ndarray,
    *,
    base_pair_edges: np.ndarray | None = None,
    crossover_edges: np.ndarray | None = None,
    stacking_edges: np.ndarray | None = None,
) -> NeighborGraph:
    """Build the fixed typed topology graph without spatial-radius edges.

    Backbone and design relations are known from the topology/design files and
    remain present even when no spatial cutoff is requested.  Design relations
    are kept as separate typed directed edges so the network can distinguish
    their semantics, including when two relations share a nucleotide pair.
    """
    position = np.asarray(position)
    box = np.asarray(box)
    if position.ndim != 2 or position.shape[1] != 3:
        raise ValueError("position must have shape [nodes, 3]")
    if box.shape != (3,) or np.any(box <= 0):
        raise ValueError("orthogonal box must contain three positive lengths")
    n_nodes = len(position)
    edge_kind: dict[tuple[int, int], int] = {}
    for left, right in np.asarray(backbone_edges, dtype=np.int64).reshape(-1, 2):
        if left == right or not (0 <= left < n_nodes and 0 <= right < n_nodes):
            raise ValueError("backbone edge contains an invalid node index")
        edge_kind[(int(left), int(right))] = EDGE_BACKBONE
        edge_kind[(int(right), int(left))] = EDGE_BACKBONE
    design_edges: list[tuple[int, int, int]] = []
    for edges, kind in ((base_pair_edges, EDGE_BASE_PAIR), (crossover_edges, EDGE_CROSSOVER), (stacking_edges, EDGE_STACKING)):
        if edges is None:
            continue
        for left, right in np.asarray(edges, dtype=np.int64).reshape(-1, 2):
            if left == right or not (0 <= left < n_nodes and 0 <= right < n_nodes):
                raise ValueError("design edge contains an invalid node index")
            for a, b in ((int(left), int(right)), (int(right), int(left))):
                if edge_kind.get((a, b)) != kind:
                    design_edges.append((a, b, kind))
    ordered = sorted(edge_kind)
    ordered.extend((a, b) for a, b, _ in design_edges)
    edge_index = np.asarray(ordered, dtype=np.int64).T if ordered else np.empty((2, 0), dtype=np.int64)
    displacement = (
        minimum_image_displacement(position[edge_index[0]] - position[edge_index[1]], box)
        if ordered else np.empty((0, 3), dtype=position.dtype)
    )
    kinds = np.asarray(
        [edge_kind[edge] for edge in ordered[:len(edge_kind)]]
        + [kind for _, _, kind in design_edges], dtype=np.int8,
    )
    return NeighborGraph(edge_index=edge_index, displacement=displacement, edge_kind=kinds)


def build_backbone_graph(position: np.ndarray, box: np.ndarray, backbone_edges: np.ndarray) -> NeighborGraph:
    """Build only the fixed bidirectional backbone graph."""
    position = np.asarray(position); box = np.asarray(box)
    edges = np.asarray(backbone_edges, dtype=np.int64).reshape(-1, 2)
    if position.ndim != 2 or position.shape[1] != 3 or box.shape != (3,) or np.any(box <= 0):
        raise ValueError("invalid position or box")
    ordered = sorted({(int(a), int(b)) for a, b in edges} | {(int(b), int(a)) for a, b in edges})
    edge_index = np.asarray(ordered, dtype=np.int64).T if ordered else np.empty((2, 0), dtype=np.int64)
    displacement = (
        minimum_image_displacement(position[edge_index[0]] - position[edge_index[1]], box)
        if ordered
        else np.empty((0, 3), dtype=position.dtype)
    )
    return NeighborGraph(edge_index=edge_index, displacement=displacement, edge_kind=np.ones(len(ordered), dtype=np.int8))
