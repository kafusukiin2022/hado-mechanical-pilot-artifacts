"""GPU cell lists for transient spatial-neighbour calculations.

The pairs produced here are an acceleration structure for nonbonded physics.
They are deliberately separate from the fixed graph used by the GNN.
"""
from __future__ import annotations

from dataclasses import dataclass
import itertools

import torch


@dataclass(frozen=True)
class PhysicsCandidatePairs:
    """Unique unordered particle pairs within ``cutoff + skin``.

    ``pair_index[0] < pair_index[1]`` for every column, so pair energies are
    counted exactly once. ``displacement`` is the periodic vector from the
    first particle to the second and remains differentiable with respect to
    ``positions``; cell assignment and pair membership are discrete.
    """

    pair_index: torch.Tensor
    displacement: torch.Tensor
    physical_cutoff: float
    skin: float
    overflow_nodes: int = 0

    @property
    def candidate_cutoff(self) -> float:
        return self.physical_cutoff + self.skin

    @property
    def pair_count(self) -> int:
        return int(self.pair_index.shape[1])


def _validate_inputs(
    positions: torch.Tensor,
    box: torch.Tensor,
    cutoff: float,
    skin: float = 0.0,
) -> None:
    if positions.ndim != 2 or positions.shape[-1] != 3:
        raise ValueError("positions must have shape [N,3]")
    if box.shape != (3,) or not bool(torch.all(box > 0)):
        raise ValueError("box must contain three positive lengths")
    if cutoff <= 0 or skin < 0:
        raise ValueError("cutoff must be positive and skin non-negative")
    if positions.device != box.device:
        raise ValueError("positions and box must share a device")
    if not bool(torch.isfinite(positions).all()) or not bool(torch.isfinite(box).all()):
        raise ValueError("positions and box must be finite")


def minimum_image_torch(delta: torch.Tensor, box: torch.Tensor) -> torch.Tensor:
    """Apply the orthorhombic periodic minimum-image convention."""
    if delta.shape[-1] != 3 or box.shape != (3,):
        raise ValueError("delta must end in 3 and box must have shape [3]")
    return delta - box * torch.round(delta / box)


def build_gpu_candidate_pairs(
    positions: torch.Tensor,
    box: torch.Tensor,
    physical_cutoff: float,
    *,
    skin: float = 0.0,
    max_neighbors: int | None = None,
    error_on_overflow: bool = True,
) -> PhysicsCandidatePairs:
    """Build unique unordered physics candidates with a GPU cell list.

    Pair membership is computed from detached coordinates, as neighbour-list
    membership is not differentiable. Pair displacements are then recomputed
    from the original tensor so energy gradients reach predicted positions.

    ``max_neighbors`` is an overflow guard rather than a truncation setting.
    Silently dropping physical interactions would change the energy. Set
    ``error_on_overflow=False`` only to collect overflow diagnostics; all pairs
    are still returned.
    """
    _validate_inputs(positions, box, physical_cutoff, skin)
    if max_neighbors is not None and max_neighbors <= 0:
        raise ValueError("max_neighbors must be positive")
    n = int(positions.shape[0])
    empty_index = torch.empty((2, 0), dtype=torch.long, device=positions.device)
    empty_delta = positions.new_empty((0, 3))
    if n < 2:
        return PhysicsCandidatePairs(empty_index, empty_delta, float(physical_cutoff), float(skin))

    candidate_cutoff = float(physical_cutoff + skin)
    detached = positions.detach()
    wrapped = torch.remainder(detached, box)
    ncell = torch.floor(box / candidate_cutoff).long().clamp_min(1)
    cell = torch.floor(wrapped / candidate_cutoff).long() % ncell
    cell_id = cell[:, 0] + ncell[0] * (cell[:, 1] + ncell[1] * cell[:, 2])
    order = torch.argsort(cell_id)
    sorted_ids = cell_id[order]
    unique, counts = torch.unique_consecutive(sorted_ids, return_counts=True)
    starts = torch.cumsum(counts, 0) - counts
    rank = torch.arange(n, device=positions.device) - torch.repeat_interleave(starts, counts)
    max_occupancy = int(counts.max().item())
    members = torch.full(
        (len(unique), max_occupancy), -1, dtype=torch.long, device=positions.device
    )
    group = torch.repeat_interleave(torch.arange(len(unique), device=positions.device), counts)
    members[group, rank] = order

    left_chunks: list[torch.Tensor] = []
    right_chunks: list[torch.Tensor] = []
    node_ids = torch.arange(n, device=positions.device)
    # A half shell (the home cell plus 13 forward neighbours) visits every
    # unordered cell pair once when each periodic axis has at least 3 cells.
    # Small boxes are canonicalized with ``unique`` below.
    offsets = [
        offset for offset in itertools.product((-1, 0, 1), repeat=3)
        if offset == (0, 0, 0) or offset > (0, 0, 0)
    ]
    for offset in offsets:
        shift = torch.tensor(offset, dtype=torch.long, device=positions.device)
        query_cell = (cell + shift) % ncell
        query_id = query_cell[:, 0] + ncell[0] * (query_cell[:, 1] + ncell[1] * query_cell[:, 2])
        row = torch.searchsorted(unique, query_id)
        safe_row = row.clamp_max(len(unique) - 1)
        found = (row < len(unique)) & (unique[safe_row] == query_id)
        candidate = members[safe_row]
        valid = found[:, None] & (candidate >= 0)
        safe_candidate = candidate.clamp_min(0)
        delta = minimum_image_torch(detached[safe_candidate] - detached[:, None, :], box)
        valid &= torch.sum(delta.square(), dim=-1) < candidate_cutoff * candidate_cutoff
        if offset == (0, 0, 0):
            valid &= safe_candidate > node_ids[:, None]
        else:
            valid &= safe_candidate != node_ids[:, None]
        first = node_ids[:, None].expand_as(safe_candidate)[valid]
        second = safe_candidate[valid]
        left_chunks.append(torch.minimum(first, second))
        right_chunks.append(torch.maximum(first, second))

    if not left_chunks:
        return PhysicsCandidatePairs(empty_index, empty_delta, float(physical_cutoff), float(skin))
    left = torch.cat(left_chunks)
    right = torch.cat(right_chunks)
    keys = left * n + right
    if bool(torch.any(ncell < 3)):
        keys = torch.unique(keys, sorted=True)
    else:
        keys = torch.sort(keys).values
    left = torch.div(keys, n, rounding_mode="floor")
    right = torch.remainder(keys, n)
    pair_index = torch.stack((left, right), dim=0)

    degree = torch.bincount(torch.cat((left, right)), minlength=n)
    overflow_nodes = 0
    if max_neighbors is not None:
        overflow_nodes = int(torch.count_nonzero(degree > max_neighbors).item())
        if overflow_nodes and error_on_overflow:
            maximum = int(degree.max().item())
            raise RuntimeError(
                f"physics candidate overflow: {overflow_nodes} nodes exceed "
                f"max_neighbors={max_neighbors} (maximum={maximum}); no pairs were truncated"
            )

    displacement = minimum_image_torch(positions[right] - positions[left], box)
    return PhysicsCandidatePairs(
        pair_index=pair_index,
        displacement=displacement,
        physical_cutoff=float(physical_cutoff),
        skin=float(skin),
        overflow_nodes=overflow_nodes,
    )


def build_gpu_spatial_graph(
    positions: torch.Tensor,
    box: torch.Tensor,
    cutoff: float,
    max_neighbors: int,
) -> torch.Tensor:
    """Compatibility wrapper returning directed pairs.

    New graph-latent code must use :func:`build_gpu_candidate_pairs` only for
    physics. This wrapper remains for older local-frame models.
    """
    candidates = build_gpu_candidate_pairs(
        positions,
        box,
        cutoff,
    )
    pairs = candidates.pair_index
    directed = torch.cat((pairs, pairs.flip(0)), dim=1)
    if directed.shape[1] == 0:
        return directed
    displacement = minimum_image_torch(
        positions[directed[0]] - positions[directed[1]], box
    )
    distance_squared = torch.sum(displacement.square(), dim=-1)
    # Stable two-stage ordering groups by receiver while retaining increasing
    # distance inside each group.
    by_distance = torch.argsort(distance_squared, stable=True)
    order = by_distance[torch.argsort(directed[1, by_distance], stable=True)]
    sorted_receiver = directed[1, order]
    counts = torch.bincount(sorted_receiver, minlength=len(positions))
    starts = torch.cumsum(counts, 0) - counts
    rank = torch.arange(len(order), device=positions.device) - torch.repeat_interleave(starts, counts)
    return directed[:, order[rank < max_neighbors]]
