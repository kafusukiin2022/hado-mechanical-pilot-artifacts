from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

import numpy as np


@dataclass(frozen=True)
class Frame:
    time: int
    box: np.ndarray
    energy: np.ndarray
    position: np.ndarray
    a1: np.ndarray
    a3: np.ndarray
    velocity: np.ndarray
    angular_velocity: np.ndarray


@dataclass(frozen=True)
class Topology:
    nucleotide_count: int
    strand_count: int
    strand: np.ndarray
    base: np.ndarray
    backbone_edges: np.ndarray
    # Optional design-level relations.  They are empty for a plain .top file.
    base_pair_edges: np.ndarray = field(default_factory=lambda: np.empty((0, 2), dtype=np.int64))
    crossover_edges: np.ndarray = field(default_factory=lambda: np.empty((0, 2), dtype=np.int64))
    stacking_edges: np.ndarray = field(default_factory=lambda: np.empty((0, 2), dtype=np.int64))
    node_scaffold: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=bool))
    virtual_helix: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=np.int32))
    design_offset: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=np.int32))
    # Directed p -> p.n3 relations from columns three/four of the oxDNA .top
    # file.  Physical stacking is directional and must use this ordering;
    # ``backbone_edges`` remains the canonical unordered topology relation.
    backbone_n3_edges: np.ndarray = field(default_factory=lambda: np.empty((0, 2), dtype=np.int64))

    def with_design(
        self,
        *,
        base_pair_edges: np.ndarray,
        crossover_edges: np.ndarray,
        stacking_edges: np.ndarray,
        node_scaffold: np.ndarray,
        virtual_helix: np.ndarray,
        design_offset: np.ndarray,
    ) -> "Topology":
        """Return this topology with validated cadnano design relations."""
        n = self.nucleotide_count
        def edges(value: np.ndarray) -> np.ndarray:
            result = np.asarray(value, dtype=np.int64).reshape(-1, 2)
            if result.size and (result.min() < 0 or result.max() >= n):
                raise ValueError("design edge contains an invalid nucleotide index")
            return result
        scaffold = np.asarray(node_scaffold, dtype=bool).reshape(-1)
        vh = np.asarray(virtual_helix, dtype=np.int32).reshape(-1)
        offset = np.asarray(design_offset, dtype=np.int32).reshape(-1)
        if len(scaffold) != n or len(vh) != n or len(offset) != n:
            raise ValueError("design node arrays must match nucleotide_count")
        return Topology(
            self.nucleotide_count, self.strand_count, self.strand, self.base,
            self.backbone_edges, edges(base_pair_edges), edges(crossover_edges),
            edges(stacking_edges), scaffold, vh, offset, self.backbone_n3_edges,
        )


def _header_values(line: str, name: str) -> list[float]:
    prefix, separator, values = line.partition("=")
    if not separator or prefix.strip() != name:
        raise ValueError(f"expected '{name} =' header, got {line.strip()!r}")
    return [float(value) for value in values.split()]


def iter_frames(path: Path, nucleotide_count: int) -> Iterator[Frame]:
    with path.open() as handle:
        while time_line := handle.readline():
            box_line = handle.readline()
            energy_line = handle.readline()
            if not box_line or not energy_line:
                raise ValueError(f"incomplete frame header in {path}")
            time_values = _header_values(time_line, "t")
            box_values = _header_values(box_line, "b")
            energy_values = _header_values(energy_line, "E")
            if len(time_values) != 1 or len(box_values) != 3 or len(energy_values) != 3:
                raise ValueError(f"invalid frame header in {path}")
            rows = np.empty((nucleotide_count, 15), dtype=np.float32)
            for index in range(nucleotide_count):
                row = handle.readline()
                if not row:
                    raise ValueError(f"incomplete frame {time_values[0]:g} in {path}")
                values = row.split()
                if len(values) != 15:
                    raise ValueError(f"expected 15 values at nucleotide {index}, got {len(values)}")
                rows[index] = values
            yield Frame(
                time=int(time_values[0]),
                box=np.asarray(box_values, dtype=np.float32),
                energy=np.asarray(energy_values, dtype=np.float32),
                position=rows[:, 0:3],
                a1=rows[:, 3:6],
                a3=rows[:, 6:9],
                velocity=rows[:, 9:12],
                angular_velocity=rows[:, 12:15],
            )


def topology_size(path: Path) -> tuple[int, int]:
    header = path.read_text().splitlines()[0].split()
    if len(header) != 2:
        raise ValueError(f"invalid topology header in {path}")
    return int(header[0]), int(header[1])


def read_topology(path: Path) -> Topology:
    with path.open() as handle:
        header = handle.readline().split()
        if len(header) != 2:
            raise ValueError(f"invalid topology header in {path}")
        nucleotide_count, strand_count = map(int, header)
        rows = [line.split() for line in handle if line.strip()]
    if len(rows) != nucleotide_count or any(len(row) != 4 for row in rows):
        raise ValueError(f"expected {nucleotide_count} four-column topology rows in {path}")
    strand = np.asarray([int(row[0]) for row in rows], dtype=np.int32)
    base = np.asarray([row[1] for row in rows], dtype="U1")
    edge_set: set[tuple[int, int]] = set()
    n3_edges: list[tuple[int, int]] = []
    for index, row in enumerate(rows):
        for column, neighbor_text in enumerate(row[2:4]):
            neighbor = int(neighbor_text)
            if neighbor == -1:
                continue
            if not 0 <= neighbor < nucleotide_count:
                raise ValueError(f"invalid backbone index {neighbor} in {path}")
            edge_set.add(tuple(sorted((index, neighbor))))
            if column == 0:
                n3_edges.append((index, neighbor))
    edges = np.asarray(sorted(edge_set), dtype=np.int64).reshape(-1, 2)
    directed_n3 = np.asarray(n3_edges, dtype=np.int64).reshape(-1, 2)
    return Topology(
        nucleotide_count, strand_count, strand, base, edges,
        backbone_n3_edges=directed_n3,
    )


class _CadnanoMappingUnpickler:
    """Load the legacy tacoxdna mapping without importing its ``libs`` package."""

    @staticmethod
    def load(path: Path):
        import pickle
        import sys
        import types

        module = types.ModuleType("libs.cadnano_utils")
        cls = type("vhelix_vbase_to_nucleotide", (), {})
        cls.__module__ = "libs.cadnano_utils"
        module.vhelix_vbase_to_nucleotide = cls
        package = types.ModuleType("libs")
        package.cadnano_utils = module
        sys.modules.setdefault("libs", package)
        sys.modules.setdefault("libs.cadnano_utils", module)
        with path.open("rb") as handle:
            return pickle.load(handle)


def read_cadnano_design(
    topology_path: Path,
    design_path: Path,
    mapping_path: Path,
) -> Topology:
    """Merge cadnano scaffold/staple relations into an oxDNA topology.

    ``mapping_path`` is the tacoxdna ``virt2nuc`` pickle.  No spatial cutoff is
    used: all relations come from explicit design pointers.  Missing design
    slots (loops/skips) are recorded as unavailable rather than guessed.
    """
    import json

    topology = read_topology(topology_path)
    design = json.loads(Path(design_path).read_text())
    mapped = _CadnanoMappingUnpickler.load(Path(mapping_path))
    if not isinstance(mapped, tuple) or len(mapped) < 1:
        raise ValueError("invalid virt2nuc mapping")
    converter = mapped[0]
    scaf_map = dict(getattr(converter, "_scaf", {}))
    stap_map = dict(getattr(converter, "_stap", {}))

    def node(mapping, vh: int, offset: int) -> int | None:
        value = mapping.get((int(vh), int(offset)))
        if value is None or len(value) < 2 or not value[1]:
            return None
        return int(value[1][0])

    n = topology.nucleotide_count
    scaffold = np.zeros(n, dtype=bool)
    virtual_helix = np.full(n, -1, dtype=np.int32)
    design_offset = np.full(n, -1, dtype=np.int32)
    base_pairs: set[tuple[int, int]] = set()
    crossovers: set[tuple[int, int]] = set()
    stacking: set[tuple[int, int]] = set()
    for vh_data in design.get("vstrands", []):
        vh = int(vh_data["num"])
        for is_scaffold, key, mapping in ((True, "scaf", scaf_map), (False, "stap", stap_map)):
            for offset, pointer in enumerate(vh_data.get(key, [])):
                current = node(mapping, vh, offset)
                if current is None or not 0 <= current < n:
                    continue
                scaffold[current] = is_scaffold
                virtual_helix[current] = vh
                design_offset[current] = offset
                if pointer[2] >= 0:
                    nxt = node(mapping, int(pointer[2]), int(pointer[3]))
                    if nxt is not None and nxt != current:
                        edge = tuple(sorted((current, nxt)))
                        (crossovers if int(pointer[2]) != vh else stacking).add(edge)
    # A scaffold and staple occupying the same design slot are complementary.
    for slot in set(scaf_map).intersection(stap_map):
        left, right = node(scaf_map, *slot), node(stap_map, *slot)
        if left is not None and right is not None and left != right:
            base_pairs.add(tuple(sorted((left, right))))
    # Design pointers can include edges already present in .top; retain unique
    # typed relations and let graph construction merge duplicates deterministically.
    return topology.with_design(
        base_pair_edges=np.asarray(sorted(base_pairs), dtype=np.int64).reshape(-1, 2),
        crossover_edges=np.asarray(sorted(crossovers), dtype=np.int64).reshape(-1, 2),
        stacking_edges=np.asarray(sorted(stacking), dtype=np.int64).reshape(-1, 2),
        node_scaffold=scaffold,
        virtual_helix=virtual_helix,
        design_offset=design_offset,
    )


def extract_frame(trajectory: Path, nucleotide_count: int, frame_index: int, output: Path) -> None:
    if frame_index < 0:
        raise ValueError("frame_index must be non-negative")
    lines_per_frame = nucleotide_count + 3
    with trajectory.open() as handle:
        for current in range(frame_index + 1):
            lines = [handle.readline() for _ in range(lines_per_frame)]
            if any(not line for line in lines):
                raise IndexError(f"frame {frame_index} not found in {trajectory}")
            if current == frame_index:
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text("".join(lines))
                return


def write_restart(
    template: Path,
    output: Path,
    position: np.ndarray,
    a1: np.ndarray,
    a3: np.ndarray,
    velocity: np.ndarray,
    angular_velocity: np.ndarray,
) -> None:
    """Write a complete oxDNA restart, preserving headers from a valid template."""
    arrays = [np.asarray(value, dtype=np.float32) for value in (position, a1, a3, velocity, angular_velocity)]
    if any(not np.isfinite(value).all() for value in arrays):
        raise ValueError("restart fields must contain only finite values")
    if any(value.ndim != 2 or value.shape[1] != 3 for value in arrays):
        raise ValueError("restart fields must have shape [nucleotides,3]")
    count = arrays[0].shape[0]
    if any(value.shape[0] != count for value in arrays):
        raise ValueError("restart fields must share nucleotide count")
    lines = template.read_text().splitlines()
    if len(lines) < count + 3:
        raise ValueError("template restart is incomplete")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w") as handle:
        handle.write("\n".join(lines[:3]) + "\n")
        for index in range(count):
            values = np.concatenate([value[index] for value in arrays])
            handle.write(" ".join(f"{float(value):.9g}" for value in values) + "\n")
