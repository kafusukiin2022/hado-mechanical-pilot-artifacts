#!/usr/bin/env python3
"""Train/evaluate one-pass initial->prepared SE(3) ablations A-D on local GPU."""
from __future__ import annotations
import argparse,hashlib,json,math,os,random,sys,time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
ROOT=Path(__file__).resolve().parents[1]
FLOW=Path('/home/lijingjing/lijj/users/lht2/deeporigami/agent/flowmatching')
sys.path.insert(0,str(FLOW));sys.path.insert(0,str(ROOT/'ml_pilot'))
from transfer_operator.oxdna_io import iter_frames,read_topology
from transfer_operator.graph import se3_edge_features,topology_node_features
from transfer_operator.gpu_graph import build_gpu_candidate_pairs
from transfer_operator.oxdna2_energy import (DNA2Parameters,ENERGY_TERMS,
  evaluate_edge_energy_labels,evaluate_dna2_energy)
from onepass_model import OnePassSE3Predictor
from onepass_losses import supervised_losses,physical_energy_loss

CAMPAIGN=ROOT/'runs/prep_H101_H500_20261007'
PKG=ROOT/'HADO_H101-H500_20261007/designs'
MANIFEST=ROOT/'ml_pilot/results/onepass_family_split_20261007.json'
CACHE=ROOT/'ml_pilot/cache_onepass_20261007'
RESULTS=ROOT/'ml_pilot/results/onepass_ablation_20261007'
PHYS_PARAMS=DNA2Parameters(temperature=0.1,salt_concentration=0.5,max_backbone_force=5.0,max_backbone_force_far=10.0)
MODEL_CUTOFF=1.2
ENERGY_CUTOFF=2.0
PHYS_CUTOFF=1.6
FEATURE_SCALE=32.0


def frame_rotation(a1,a3):
 a1=a1/np.maximum(np.linalg.norm(a1,axis=-1,keepdims=True),1e-9)
 a3=a3-(a3*a1).sum(-1,keepdims=True)*a1
 a3=a3/np.maximum(np.linalg.norm(a3,axis=-1,keepdims=True),1e-9)
 return np.stack((a1,np.cross(a3,a1),a3),axis=-1).astype(np.float32)

def unpack_positions(raw,box,edges):
 n=len(raw); adj=[[] for _ in range(n)]
 for a,b in edges:
  adj[int(a)].append(int(b));adj[int(b)].append(int(a))
 out=np.zeros_like(raw,dtype=np.float32); seen=np.zeros(n,dtype=bool); components=[]; max_res=0.0
 for root in range(n):
  if seen[root]:continue
  seen[root]=True;out[root]=raw[root];stack=[root];component=[]
  while stack:
   i=stack.pop();component.append(i)
   for j in adj[i]:
    d=raw[j]-raw[i];d-=box*np.rint(d/box);candidate=out[i]+d
    if not seen[j]:seen[j]=True;out[j]=candidate;stack.append(j)
    else:
     err=candidate-out[j];err-=box*np.rint(err/box);max_res=max(max_res,float(np.linalg.norm(err)))
  components.append(component)
 # Disconnected molecular pieces retain their input cell placement.
 for component in components[1:]:
  ids=np.asarray(component);shift=raw[ids].mean(0)-out[ids].mean(0);out[ids]+=shift
 return out,max_res,len(components)

def proper_kabsch(src,tgt):
 """Row-vector map src @ Q + t -> tgt; proper rotation only."""
 cs=src.mean(0);ct=tgt.mean(0);x=src-cs;y=tgt-ct
 u,_,vh=np.linalg.svd(x.T@y)
 d=np.eye(3,dtype=np.float32);d[2,2]=1.0 if np.linalg.det(u@vh)>=0 else -1.0
 q=(u@d@vh).astype(np.float32);return q,(ct-cs@q).astype(np.float32)

def kabsch_self_check():
 rng=np.random.default_rng(211);x=rng.normal(size=(128,3)).astype(np.float32)
 q,_=np.linalg.qr(rng.normal(size=(3,3)))
 if np.linalg.det(q)<0:q[:,-1]*=-1
 y=x@q+np.asarray([2.0,-1.5,0.7],dtype=np.float32)
 fitted_q,t=proper_kabsch(x,y)
 residual=np.sqrt(np.mean(np.sum((x@fitted_q+t-y)**2,axis=-1)))
 if residual>1e-5:raise AssertionError(f'row Kabsch convention failed: {residual}')
 return float(residual)

def undirected(e):return tuple(sorted((int(e[0]),int(e[1]))))

def relation_and_energy_edges(top,design_dir,pos0,box,device):
 backbone=np.asarray(top.backbone_edges,dtype=np.int64).reshape(-1,2)
 bp_path=design_dir/'native_pairs.json'
 pairs=np.asarray(json.loads(bp_path.read_text()),dtype=np.int64).reshape(-1,2)
 bkeys={undirected(e) for e in backbone}
 rel={k:1 for k in bkeys}
 map_path=design_dir/'nucleotide_map.json';cross=set()
 if map_path.exists():
  mp=json.loads(map_path.read_text());helices=np.asarray(mp['positions'],dtype=np.int64)[:,0]
  if len(helices)==top.nucleotide_count:
   cross={undirected(e) for e in backbone if helices[int(e[0])]!=helices[int(e[1])]}
   for k in cross:rel[k]=3
 for e in pairs:
  k=undirected(e)
  if k not in rel:rel[k]=2
 source_tensor=torch.as_tensor(pos0,device=device);box_tensor=torch.as_tensor(box,device=device)
 spatial=build_gpu_candidate_pairs(source_tensor,box_tensor,ENERGY_CUTOFF)
 for a,b in spatial.pair_index.T.detach().cpu().numpy():
  k=(int(a),int(b))
  if k not in rel:rel[k]=0
 keys=sorted(rel); ep=np.asarray(keys,dtype=np.int64).reshape(-1,2)
 ek=np.asarray([rel[k] for k in keys],dtype=np.int64)
 bonded=np.asarray([k in bkeys for k in keys],dtype=bool)
 # GNN topology+short-range source spatial pairs; energy candidates are broader.
 g_rel={k:v for k,v in rel.items() if v>0}
 local_pairs=build_gpu_candidate_pairs(source_tensor,box_tensor,MODEL_CUTOFF)
 for a,b in local_pairs.pair_index.T.detach().cpu().numpy():
  g_rel.setdefault((int(a),int(b)),0)
 # Add long-range strand skip links as a separate semantic message-passing edge.
 directed_n3=np.asarray(top.backbone_n3_edges,dtype=np.int64).reshape(-1,2)
 succ={int(a):int(b) for a,b in directed_n3}
 for hop in (4,16):
  for start in range(top.nucleotide_count):
   cur=start;ok=True
   for _ in range(hop):
    if cur not in succ:ok=False;break
    cur=succ[cur]
   if ok and cur!=start:
    k=undirected((start,cur))
    if k not in g_rel:g_rel[k]=4
 gkeys=sorted(g_rel);ge=np.asarray(gkeys,dtype=np.int64).reshape(-1,2)
 gd=np.concatenate((ge,ge[:,::-1]),axis=0)
 gkind0=np.asarray([g_rel[k] for k in gkeys],dtype=np.int64)
 gkind=np.concatenate((gkind0,gkind0))
 return ep,ek,bonded,ge,gkind,backbone,pairs,cross

def energy_params():return PHYS_PARAMS

def physical_eval(pos,rot,box,bonds,bases,terminal,device):
 pos=torch.as_tensor(pos,dtype=torch.float32,device=device);rot=torch.as_tensor(rot,dtype=torch.float32,device=device)
 box=torch.as_tensor(box,dtype=torch.float32,device=device)
 bonds=torch.as_tensor(bonds,dtype=torch.long,device=device).T.contiguous()
 candidates=build_gpu_candidate_pairs(pos,box,PHYS_CUTOFF,skin=0.2,error_on_overflow=True)
 return evaluate_dna2_energy(pos,rot,box,bonds,candidates,torch.as_tensor(bases,device=device),torch.as_tensor(terminal,device=device),parameters=energy_params())

def make_cache(row,device,force=False):
 CACHE.mkdir(parents=True,exist_ok=True);dest=CACHE/(row['design_id']+'.npz')
 if dest.exists() and not force:return dest
 ident=row['design_id'];inp=ROOT/row['initial_top'];conf=ROOT/row['initial_dat'];prep=ROOT/row['prepared_dat']
 if hashlib.sha256(prep.read_bytes()).hexdigest()!=row['prepared_sha256']:raise RuntimeError(f'prepared SHA mismatch: {ident}')
 top=read_topology(inp);x=next(iter_frames(conf,top.nucleotide_count));y=next(iter_frames(prep,top.nucleotide_count))
 package=PKG/('HADO_200_v1' if int(ident[1:])<=300 else 'HADO_200_extension')/'designs'/ident
 backbone=np.asarray(top.backbone_edges,dtype=np.int64).reshape(-1,2)
 bp=np.asarray(json.loads((package/'native_pairs.json').read_text()),dtype=np.int64).reshape(-1,2)
 unwrap_edges=np.unique(np.vstack((backbone,bp)),axis=0)
 xraw,xres,xcomp=unpack_positions(x.position,x.box,unwrap_edges)
 yraw,yres,ycomp=unpack_positions(y.position,y.box,unwrap_edges)
 r0=frame_rotation(x.a1,x.a3);r1=frame_rotation(y.a1,y.a3)
 q,t=proper_kabsch(yraw,xraw);yraw=yraw@q+t;r1=np.einsum('ij,njk->nik',q.T,r1)
 center=xraw.mean(0);p0=xraw-center;p1=yraw-center
 ep,ek,bonded,ge,gkind,bonds,pairs,cross=relation_and_energy_edges(top,package,p0,x.box,device)
 nfeat=topology_node_features(top).astype(np.float32)
 # Directed source graph edge feature, geometry invariant under global rotation.
 gd=np.concatenate((ge,ge[:,::-1]),axis=0);gt=gkind
 sender,receiver=gd[:,0],gd[:,1];disp=p0[sender]-p0[receiver]
 fwd=se3_edge_features(disp/FEATURE_SCALE,r0[receiver],r0[sender],gt)
 gnn_ei=torch.as_tensor(gd.T.copy(),dtype=torch.long,device=device)
 # Energy pairs have symmetric endpoint features: average both directed invariants.
 ei=np.concatenate((ep,ep[:,::-1]),axis=0);kind0=ek;kind=np.concatenate((kind0,kind0))
 edisp=p0[ei[:,0]]-p0[ei[:,1]]
 ef=se3_edge_features(edisp/FEATURE_SCALE,r0[ei[:,1]],r0[ei[:,0]],kind)
 ef_sym=(ef[:len(ep)]+ef[len(ep):])*0.5
 energy_target=evaluate_edge_energy_labels(
  torch.as_tensor(p1,dtype=torch.float32,device=device),torch.as_tensor(r1,dtype=torch.float32,device=device),
  torch.as_tensor(x.box,dtype=torch.float32,device=device),torch.as_tensor(ep.T.copy(),dtype=torch.long,device=device),
  torch.as_tensor(ek,dtype=torch.long,device=device),
  torch.as_tensor([('A','C','G','T').index(str(b)) if str(b) in 'ACGT' else 4 for b in top.base],device=device),
  torch.as_tensor(np.bincount(backbone.reshape(-1),minlength=top.nucleotide_count)<2,device=device),
  bonded_mask=torch.as_tensor(bonded,device=device),parameters=energy_params()).detach().cpu().numpy()
 bases=np.asarray([('A','C','G','T').index(str(b)) if str(b) in 'ACGT' else 4 for b in top.base],dtype=np.int64)
 terminal=np.bincount(backbone.reshape(-1),minlength=top.nucleotide_count)<2
 p_eval=physical_eval(p1+center,r1,y.box,backbone,bases,terminal,device)
 phys=np.asarray([float(p_eval.terms[name].detach().cpu())/top.nucleotide_count for name in ENERGY_TERMS],dtype=np.float32)
 # Masks retain zero-valued labels only where the interaction is geometrically
 # applicable in the prepared target; far-away cutoff zeros do not dominate.
 qedge=ep[:,0];redge=ep[:,1]
 pd=x.box*np.rint((p1[redge]-p1[qedge])/x.box)
 delta=p1[redge]-p1[qedge]-pd;dist=np.linalg.norm(delta,axis=-1)
 mask=np.zeros_like(energy_target,dtype=bool);mask[:,0:3]=bonded[:,None]
 cutoffs=np.asarray([1.2,1.8,1.8,1.6,2.5],dtype=np.float32)
 for col,cutoff in zip(range(3,8),cutoffs):mask[:,col]=(~bonded)&(dist<cutoff)
 # Struct loss only physical relation edges; each unique pair appears once.
 smask=ek>0;struct=ep[smask];sk=ek[smask]
 if not np.isfinite(energy_target).all() or not np.isfinite(phys).all():raise FloatingPointError(f'nonfinite labels {ident}')
 np.savez_compressed(dest,pos0=p0.astype(np.float32),pos1=p1.astype(np.float32),rot0=r0,rot1=r1,
  node_features=nfeat,gnn_edge_index=gd.T.astype(np.int64),gnn_edge_types=gt,gnn_edge_features=fwd,
  energy_pair_index=ep.T.astype(np.int64),energy_pair_features=ef_sym,energy_edge_kind=ek,bonded_mask=bonded,
  energy_target=energy_target.astype(np.float32),energy_mask=mask,struct_edge_index=struct.T.astype(np.int64),struct_edge_kind=sk,
  backbone_edges=backbone.T.astype(np.int64),base_pairs=pairs.T.astype(np.int64),base_types=bases,terminal=terminal,
  box=x.box.astype(np.float32),source_center=center.astype(np.float32),target_physics=phys,
  unwrap_max_residual=np.asarray([max(xres,yres)],dtype=np.float32),unwrap_components=np.asarray([xcomp,ycomp],dtype=np.int32),
  family=np.asarray(row['family']),design_id=np.asarray(ident))
 return dest

def load_cache(path,device):
 with np.load(path,allow_pickle=False) as z:d={k:z[k] for k in z.files}
 # Keep arrays on CPU until a design is sampled.
 return d

def get_tensor(d,key,device,dtype=None):return torch.as_tensor(d[key],device=device,dtype=dtype)

def pair_energy_scales(train_data):
 vals=[d['energy_target'] for d in train_data]
 masks=[d['energy_mask'] for d in train_data]
 scale=[]
 for k in range(8):
  a=np.concatenate([v[m[:,k],k] for v,m in zip(vals,masks)])
  nz=np.abs(a[np.abs(a)>1e-8]);scale.append(float(np.median(nz)) if len(nz) else 1.0)
 return np.maximum(np.asarray(scale,dtype=np.float32),1e-3)

def phys_scales(train_data):
 a=np.stack([d['target_physics'] for d in train_data]);
 return np.maximum(np.median(np.abs(a),axis=0).astype(np.float32),1e-2)

def pair_consistency(pred,d,scale,device):
 pos=pred['position']*scale+get_tensor(d,'source_center',device,torch.float32)
 rot=pred['rotation']
 ep=get_tensor(d,'energy_pair_index',device,torch.long)
 kind=get_tensor(d,'energy_edge_kind',device,torch.long)
 bonded=get_tensor(d,'bonded_mask',device,torch.bool)
 bases=get_tensor(d,'base_types',device,torch.long);term=get_tensor(d,'terminal',device,torch.bool)
 labels=evaluate_edge_energy_labels(pos,rot,get_tensor(d,'box',device,torch.float32),ep,kind,bases,term,
                                   bonded_mask=bonded,parameters=energy_params())
 return labels

def model_input(d,device,scale):
 pos=get_tensor(d,'pos0',device,torch.float32)/scale; rot=get_tensor(d,'rot0',device,torch.float32)
 kwargs={'pos':pos,'rotation':rot,'node_features':get_tensor(d,'node_features',device,torch.float32),
  'edge_index':get_tensor(d,'gnn_edge_index',device,torch.long),
  'edge_vectors':None}
 # PaiNN uses vector displacements separately from invariant edge features.
 ei=kwargs['edge_index'];praw=get_tensor(d,'pos0',device,torch.float32)/scale
 kwargs['edge_vectors']=praw[ei[0]]-praw[ei[1]]
 kwargs['edge_types']=get_tensor(d,'gnn_edge_types',device,torch.long)
 kwargs['edge_features']=get_tensor(d,'gnn_edge_features',device,torch.float32)
 kwargs['energy_pair_index']=get_tensor(d,'energy_pair_index',device,torch.long)
 kwargs['energy_pair_features']=get_tensor(d,'energy_pair_features',device,torch.float32)
 return kwargs

def calc_losses(model,d,device,scale,energy_sc,physics_sc,variant,train=True):
 kw=model_input(d,device,scale);out=model(**kw)
 target={'position':get_tensor(d,'pos1',device,torch.float32)/scale,
         'a1':get_tensor(d,'rot1',device,torch.float32)[...,:,0],
         'a3':get_tensor(d,'rot1',device,torch.float32)[...,:,2]}
 target['energy_asinh']=torch.asinh(get_tensor(d,'energy_target',device,torch.float32)/torch.as_tensor(energy_sc,device=device))
 total,pieces=supervised_losses(out,target,get_tensor(d,'struct_edge_index',device,torch.long),
   get_tensor(d,'struct_edge_kind',device,torch.long),1.0,
   get_tensor(d,'energy_mask',device,torch.bool),torch.as_tensor(energy_sc,device=device),variant)
 if variant in ('B','C','D'):
  predpos=out['position']*scale+get_tensor(d,'source_center',device,torch.float32)
  box=get_tensor(d,'box',device,torch.float32)
  candidates=build_gpu_candidate_pairs(predpos,box,PHYS_CUTOFF,skin=0.2,error_on_overflow=True)
  bonds=get_tensor(d,'backbone_edges',device,torch.long)
  ev=evaluate_dna2_energy(predpos,out['rotation'],box,bonds,candidates,
    get_tensor(d,'base_types',device,torch.long),get_tensor(d,'terminal',device,torch.bool),parameters=energy_params())
  targetphys={name:torch.as_tensor(d['target_physics'][idx],device=device) for idx,name in enumerate(ENERGY_TERMS)}
  lp,pp=physical_energy_loss(ev,targetphys,torch.as_tensor(physics_sc,device=device),len(predpos))
  total=total+0.05*lp;pieces.update(pp)
  pieces['physical_total']=lp
 if variant=='D':
  pred_edge=pair_consistency(out,d,scale,device)
  cons=F.smooth_l1_loss(torch.asinh(pred_edge/torch.as_tensor(energy_sc,device=device)),target['energy_asinh'])
  total=total+0.05*cons;pieces['energy_structure_consistency']=cons
 pieces['total']=total
 return out,total,pieces

def eval_model(model,ids,data,device,scale,energy_sc,physics_sc,variant):
 model.eval();metrics=[]
 with torch.no_grad():
  for ident in ids:
   d=data[ident];out,total,pieces=calc_losses(model,d,device,scale,energy_sc,physics_sc,variant,False)
   pos=out['position'].cpu().numpy()*scale;tar=d['pos1'];src=d['pos0']
   r0=out['rotation'];trot=torch.as_tensor(d['rot1'],device=device)
   a1err=torch.rad2deg(torch.acos((F.normalize(out['a1'],dim=-1)*trot[..., :,0]).sum(-1).clamp(-1+1e-6,1-1e-6))).mean().item()
   a3err=torch.rad2deg(torch.acos((F.normalize(out['a3'],dim=-1)*trot[..., :,2]).sum(-1).clamp(-1+1e-6,1-1e-6))).mean().item()
   diff=pos-tar;baseline=src-tar
   ei=d['struct_edge_index'];i,j=ei
   pd=np.linalg.norm(pos[j]-pos[i],axis=-1);td=np.linalg.norm(tar[j]-tar[i],axis=-1)
   dmetrics={'design_id':ident,'position_rmse_nm':float(np.sqrt(np.mean(diff**2))*0.8518),
      'position_rmse_oxdna':float(np.sqrt(np.mean(diff**2))),
      'identity_baseline_rmse_oxdna':float(np.sqrt(np.mean(baseline**2))),
      'a1_angle_deg':a1err,'a3_angle_deg':a3err,
      'topology_edge_length_mae_oxdna':float(np.mean(np.abs(pd-td))),
      'validation_loss':float(total.detach().cpu())}
   for k,v in pieces.items():dmetrics['loss_'+k]=float(v.detach().cpu())
   # Actual predicted-structure clash and oxDNA term diagnostics are measured for B-D.
   if variant in ('B','C','D'):
    predpos=out['position']*scale+get_tensor(d,'source_center',device,torch.float32)
    cand=build_gpu_candidate_pairs(predpos,get_tensor(d,'box',device,torch.float32),PHYS_CUTOFF,skin=0.2)
    ev=evaluate_dna2_energy(predpos,out['rotation'],get_tensor(d,'box',device,torch.float32),
      get_tensor(d,'backbone_edges',device,torch.long),cand,get_tensor(d,'base_types',device,torch.long),
      get_tensor(d,'terminal',device,torch.bool),parameters=energy_params())
    dmetrics['predicted_nonbonded_contacts']=int(ev.diagnostics.get('nonbonded_excluded_contacts',torch.tensor(0)).item())
    dmetrics['predicted_nonbonded_pairs']=int(ev.nonbonded_count)
   metrics.append(dmetrics)
 return metrics

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,default=MANIFEST);p.add_argument('--variants',default='A,B,C,D');p.add_argument('--epochs',type=int,default=100);p.add_argument('--patience',type=int,default=10);p.add_argument('--min-delta',type=float,default=1e-3);p.add_argument('--hidden',type=int,default=48);p.add_argument('--depth',type=int,default=4);p.add_argument('--device',default='cuda:0');p.add_argument('--seed',type=int,default=20261007);p.add_argument('--force-cache',action='store_true');p.add_argument('--smoke-only',action='store_true');a=p.parse_args()
 device=torch.device(a.device)
 if device.type=='cuda':
  if not torch.cuda.is_available():raise RuntimeError('CUDA requested but unavailable')
  torch.cuda.set_device(device)
 manifest=json.loads(a.manifest.read_text());rows={r['design_id']:r for r in manifest['rows']}
 ids=list(rows)
 if a.smoke_only:
  chosen=[]
  for s in ('train','validation','test'):
   chosen.append(next(r['design_id'] for r in manifest['rows'] if r['split']==s))
  ids=chosen
 for n,ident in enumerate(ids,1):
  make_cache(rows[ident],device,a.force_cache)
  if n%25==0:print(json.dumps({'stage':'cache','done':n,'total':len(ids)}),flush=True)
 data={i:load_cache(CACHE/(i+'.npz'),device) for i in ids}
 split={s:[i for i in ids if rows[i]['split']==s] for s in ('train','validation','test')}
 scale=float(np.median([np.sqrt(np.mean(d['pos0']**2)) for i,d in data.items() if rows[i]['split']=='train']))
 esc=pair_energy_scales([data[i] for i in split['train']]);psc=phys_scales([data[i] for i in split['train']])
 print(json.dumps({'scale':scale,'split_counts':{k:len(v) for k,v in split.items()},'energy_scale':esc.tolist(),'physical_scale':psc.tolist(),'params':PHYS_PARAMS.__dict__,'kabsch_self_check_rmse':kabsch_self_check()}),flush=True)
 if a.smoke_only:
  for variant in ('A','B','C','D'):
   m=OnePassSE3Predictor(6,a.hidden,a.depth,20,variant in ('C','D'),variant=='D').to(device)
   ident=split['train'][0];out,loss,parts=calc_losses(m,data[ident],device,scale,esc,psc,variant)
   loss.backward()
   grad=float(torch.nn.utils.clip_grad_norm_(m.parameters(),1e4))
   print(json.dumps({'smoke_variant':variant,'n':len(data[ident]['pos0']),'loss':float(loss.detach()),'grad_norm':grad,'finite':bool(torch.isfinite(loss))}),flush=True)
  return
 RESULTS.mkdir(parents=True,exist_ok=True);all_results={}
 for variant in a.variants.split(','):
  random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed)
  model=OnePassSE3Predictor(6,a.hidden,a.depth,20,variant in ('C','D'),variant=='D').to(device)
  opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-5);history=[];best=float('inf');best_state=None;best_epoch=0;start_epoch=0;stale=0
  ckpt=RESULTS/f'onepass_{variant}_{a.seed}.checkpoint.pt'
  if ckpt.exists():
   state=torch.load(ckpt,map_location=device,weights_only=False)
   if state.get('manifest_sha256')==hashlib.sha256(a.manifest.read_bytes()).hexdigest():
    model.load_state_dict(state['model']);opt.load_state_dict(state['optimizer']);history=state['history'];best=state['best_rmse'];best_state=state['best_model'];best_epoch=state['best_epoch'];start_epoch=state['epoch'];stale=state['stale']
    print(json.dumps({'variant':variant,'resume_epoch':start_epoch,'best_validation_rmse':best,'stale_epochs':stale}),flush=True)
  start=time.perf_counter()
  for epoch in range(start_epoch,a.epochs):
   model.train();order=split['train'].copy();random.Random(a.seed+epoch).shuffle(order);sums={}
   for k,ident in enumerate(order,1):
    opt.zero_grad(set_to_none=True)
    out,loss,pieces=calc_losses(model,data[ident],device,scale,esc,psc,variant)
    if not torch.isfinite(loss):raise FloatingPointError(f'nonfinite {variant} {ident}')
    loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.0);opt.step()
    for name,value in pieces.items():sums[name]=sums.get(name,0.0)+float(value.detach())
    if k%50==0:print(json.dumps({'variant':variant,'epoch':epoch+1,'train_done':k,'train_total':len(order)}),flush=True)
   valid=eval_model(model,split['validation'],data,device,scale,esc,psc,variant)
   vloss=float(np.mean([r['validation_loss'] for r in valid]));vrmse=float(np.mean([r['position_rmse_oxdna'] for r in valid]))
   history.append({'epoch':epoch+1,'train_losses':{n:v/len(order) for n,v in sums.items()},'validation_loss_mean_per_design':vloss,
      'validation_position_rmse_oxdna':float(np.mean([r['position_rmse_oxdna'] for r in valid])),'validation_a1_angle_deg':float(np.mean([r['a1_angle_deg'] for r in valid])),'validation_a3_angle_deg':float(np.mean([r['a3_angle_deg'] for r in valid])),'validation_edge_length_mae_oxdna':float(np.mean([r['topology_edge_length_mae_oxdna'] for r in valid]))})
   print(json.dumps({'variant':variant,**history[-1]}),flush=True)
   if vrmse < best-a.min_delta:
    best=vrmse;best_epoch=epoch+1;best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()};stale=0
   else: stale+=1
   torch.save({'epoch':epoch+1,'model':model.state_dict(),'optimizer':opt.state_dict(),'history':history,'best_rmse':best,'best_epoch':best_epoch,'best_model':best_state,'stale':stale,'manifest_sha256':hashlib.sha256(a.manifest.read_bytes()).hexdigest()},ckpt)
   if stale>=a.patience:
    print(json.dumps({'variant':variant,'early_stop_epoch':epoch+1,'best_epoch':best_epoch,'best_validation_rmse':best,'patience':a.patience}),flush=True);break
  if best_state is None:raise RuntimeError(f'{variant}: no training epochs completed')
  model.load_state_dict(best_state)
  val=eval_model(model,split['validation'],data,device,scale,esc,psc,variant)
  test=eval_model(model,split['test'],data,device,scale,esc,psc,variant)
  payload={'status':'completed','variant':variant,'architecture':'single_forward_SE3_equivariant_initial_to_prepared','task':'initial input -> one-shot prepared position and a1/a3','max_epochs':a.epochs,'epochs_completed':len(history),'best_validation_rmse_oxdna':best,'best_validation_epoch':best_epoch,'early_stopping_metric':'mean per-design validation position RMSE in oxDNA units','patience':a.patience,'min_delta':a.min_delta,'family_split_manifest':str(a.manifest),'family_split_sha256':hashlib.sha256(a.manifest.read_bytes()).hexdigest(),'split_counts':{k:len(v) for k,v in split.items()},'split_families':{k:sorted(set(rows[i]['family'] for i in v)) for k,v in split.items()},'scale':scale,'energy_scales':esc.tolist(),'physical_energy_scales_per_nt':psc.tolist(),'physics_parameters':PHYS_PARAMS.__dict__,'physical_candidate_cutoff':PHYS_CUTOFF,'input_candidate_cutoff':ENERGY_CUTOFF,'history':history,'validation_per_design':val,'test_per_design':test,'wall_seconds':time.perf_counter()-start,'repeat_preparations_per_design':1,'equilibrium_training_eligible':False}
  output=RESULTS/f'onepass_{variant}_{a.seed}.json';output.write_text(json.dumps(payload,indent=2)+'\n');torch.save({'model':best_state,'config':payload},output.with_suffix('.pt'))
  all_results[variant]={'json':str(output),'best_validation_loss':best,'validation_rmse':float(np.mean([r['position_rmse_oxdna'] for r in val])),'test_rmse':float(np.mean([r['position_rmse_oxdna'] for r in test]))}
  print(json.dumps({'variant_complete':variant,**all_results[variant]}),flush=True)
 (RESULTS/'ablation_summary.json').write_text(json.dumps({'variants':all_results,'selection_rule':'select by validation loss and geometry/usable-structure gates; test results are final reporting only'},indent=2)+'\n')
if __name__=='__main__':main()
