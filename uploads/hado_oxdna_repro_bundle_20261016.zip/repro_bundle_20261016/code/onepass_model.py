"""Single-forward SE(3)-equivariant position + nucleotide-frame predictor."""
from __future__ import annotations
import torch
from torch import nn
from transfer_operator.painn_flow import PaiNNPositionFlow


def skew(v):
    x, y, z = v.unbind(-1); o = torch.zeros_like(x)
    return torch.stack((o,-z,y,z,o,-x,-y,x,o),-1).reshape(-1,3,3)


def so3_exp(w):
    theta = torch.linalg.vector_norm(w,dim=-1,keepdim=True)
    k = skew(w); eye = torch.eye(3,dtype=w.dtype,device=w.device).expand(len(w),3,3)
    t2 = theta.square().clamp_min(1e-12)
    a = torch.where(theta > 1e-5, torch.sin(theta)/theta.clamp_min(1e-12), 1-t2/6)
    b = torch.where(theta > 1e-5, (1-torch.cos(theta))/t2, 0.5-t2/24)
    return eye + a[...,None]*k + b[...,None]*(k@k)


class OnePassSE3Predictor(nn.Module):
    """Energy-conditioned variant preserves equivariance in vector outputs.

    Node coefficients are invariant scalars; displacement and angular
    increments are weighted sums of PaiNN vector channels. The optional edge
    energy head is symmetric in endpoints and is aggregated to both endpoints.
    """
    def __init__(self,node_features=6,hidden=64,depth=4,edge_feature_dim=20,
                 energy_head=False,energy_condition=False,num_designs=0):
        super().__init__()
        self.energy_head_enabled=energy_head
        self.energy_condition=energy_condition
        self.num_designs=num_designs
        self.design_embedding=nn.Embedding(num_designs,hidden) if num_designs else None
        self.backbone=PaiNNPositionFlow(
            node_features=node_features,hidden=hidden,depth=depth,rbf=16,
            cutoff=0.08,edge_types=5,spatial_layers=depth,
            condition_vector_channels=2,edge_feature_dim=edge_feature_dim,
            edge_chunk_size=8192,
        )
        if energy_head:
            self.energy_mlp=nn.Sequential(nn.Linear(2*hidden+edge_feature_dim,hidden),nn.SiLU(),
                                          nn.Linear(hidden,hidden),nn.SiLU(),nn.Linear(hidden,8))
        if energy_condition:
            self.energy_encoder=nn.Sequential(nn.Linear(8,hidden),nn.SiLU(),nn.Linear(hidden,hidden))
        # A local PaiNN state alone cannot communicate design-scale bending
        # across distant helices.  Add pooled graph context (mean and max)
        # to the equivariant invariant readout, analogous to global tokens in
        # graph transformers and virtual-node molecular GNNs.
        self.coeff_head=nn.Sequential(nn.Linear(3*hidden+(hidden if energy_condition else 0)+(hidden if num_designs else 0),hidden),nn.SiLU(),
                                      nn.Linear(hidden,hidden),nn.SiLU(),nn.Linear(hidden,2*hidden))
        # Start from the identity map: initial coordinates and orientations.
        nn.init.zeros_(self.coeff_head[-1].weight)
        nn.init.zeros_(self.coeff_head[-1].bias)

    def forward(self,pos,rotation,node_features,edge_index,edge_vectors,edge_types,
                edge_features,energy_pair_index=None,energy_pair_features=None,design_index=None):
        cond=torch.stack((rotation[..., :,0],rotation[..., :,2]),dim=1)
        s,v=self.backbone._encode(pos,pos,torch.tensor(0.5,device=pos.device,dtype=pos.dtype),
            torch.tensor(1.0,device=pos.device,dtype=pos.dtype),edge_index,edge_vectors,
            edge_types,node_features,cond,edge_features=edge_features)
        energy=None; energy_node=None
        if self.energy_head_enabled:
            if energy_pair_index is None or energy_pair_features is None:
                raise ValueError('energy pair graph required for energy model')
            i,j=energy_pair_index
            sym=torch.cat((s[i]+s[j],torch.abs(s[i]-s[j]),energy_pair_features),dim=-1)
            energy=self.energy_mlp(sym)
            if self.energy_condition:
                sums=s.new_zeros((len(s),8)); degree=s.new_zeros((len(s),1))
                sums.index_add_(0,i,energy); sums.index_add_(0,j,energy)
                ones=s.new_ones((len(i),1)); degree.index_add_(0,i,ones); degree.index_add_(0,j,ones)
                energy_node=self.energy_encoder(sums/degree.clamp_min(1))
        global_ctx=torch.cat((s.mean(0),s.amax(0)),dim=-1).expand(len(s),-1)
        head_input=torch.cat((s,global_ctx,energy_node),dim=-1) if energy_node is not None else torch.cat((s,global_ctx),dim=-1)
        if self.design_embedding is not None:
            if design_index is None: raise ValueError('design_index required when num_designs > 0')
            z=self.design_embedding(design_index.reshape(1)).expand(len(s),-1)
            head_input=torch.cat((head_input,z),dim=-1)
        # Normalize vector channels before the scalar gated readout.  Without
        # this, increasing PaiNN depth/width makes coeff*v explode and the
        # first optimizer step can produce Inf gradients.  RMS normalization
        # is channel-wise and therefore preserves SO(3) equivariance.
        v_rms=torch.sqrt(v.square().mean(dim=-1,keepdim=True)+1e-6)
        v_read=v/v_rms
        coeff_raw=self.coeff_head(head_input).reshape(len(s),2,-1)
        # Bound scalar gates while retaining a zero initialized identity map.
        # The sqrt(hidden) factor keeps the sum of vector channels width stable.
        # The previous 0.25 bound capped a normalized displacement at roughly
        # 6.9 oxDNA units and made the full design set underfit even on the
        # training split.  Keep gradients bounded but provide a learnable,
        # data-compatible range for larger preparation deformations.
        coeff=0.9*torch.tanh(coeff_raw)/max(float(v.shape[1])**0.5,1.0)
        delta=torch.einsum('nch,nhr->ncr',coeff,v_read)
        delta_pos=delta[:,0] - delta[:,0].mean(0,keepdim=True)
        delta_omega=delta[:,1] - delta[:,1].mean(0,keepdim=True)
        rot_pred=so3_exp(delta_omega) @ rotation
        return {'position':pos+delta_pos,'rotation':rot_pred,
                'a1':rot_pred[..., :,0],'a3':rot_pred[..., :,2],
                'delta_position':delta_pos,'delta_omega':delta_omega,
                'edge_energy':energy}
