"""Portable oxDNA preparation/sampling runner; native files are never overwritten.

MD continuation retains coordinates, orientations, velocities, angular momenta
and the step counter. Thermostat RNG is reseeded with a logged seed after each
restart: continuation is statistical, not bitwise reproducible across restarts.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from contextlib import contextmanager
from datetime import datetime, timezone

import numpy as np

from geometry_io import read_top, read_conf, audit_conf

ROOT = Path(__file__).resolve().parents[1]


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n")
    os.replace(temporary, path)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


@contextmanager
def lock(path, nonblocking=True):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with Path(path).open("a+") as f:
        try:
            fcntl.flock(f, fcntl.LOCK_EX | (fcntl.LOCK_NB if nonblocking else 0))
        except BlockingIOError:
            raise RuntimeError(f"Another process owns this job: {path}") from None
        try:
            yield
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)


def config_path(value):
    path = Path(value)
    return path if path.is_absolute() else ROOT/path


def register_campaign(name, config, backend):
    if not name or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in name):
        raise ValueError("Campaign name may only contain letters, digits, _, -")
    directory = ROOT/"runs"/name
    payload = dict(config=config, effective_md_backend=backend,
                   source_versions=json.loads((ROOT/"SOURCE_VERSIONS.json").read_text())["commits"])
    signature = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    with lock(directory/"registration.lock", nonblocking=False):
        path = directory/"campaign.json"
        if path.exists():
            old = json.loads(path.read_text())
            if old["protocol_sha256"] != signature:
                raise ValueError("Campaign physics/backend changed. Use a new campaign name; never mix protocols.")
        else:
            write_json(path, dict(created_utc=timestamp(), protocol_sha256=signature, **payload))
    return directory, signature


def binary_path(value, default):
    path = Path(value or os.environ.get(default, ""))
    if not value and not os.environ.get(default):
        path = ROOT/("build/cpu/bin/oxDNA" if default == "OXDNA_CPU" else "build/cuda/bin/oxDNA")
    path = path.resolve()
    if not path.is_file() or not os.access(path, os.X_OK):
        raise FileNotFoundError(f"Missing executable {path}. Run setup_server.sh or set {default}.")
    return path


def input_text(c, kind, backend, steps, interval, seed, refresh, reset, capped):
    p = c["preparation"] if kind in ["min", "MC", "relax"] else c["standard_md"]
    lines = [
        f"backend = {backend}", f"backend_precision = {'mixed' if backend == 'CUDA' else 'double'}",
        f"sim_type = {'MD' if kind in ['relax', 'equilibration_candidate', 'production_candidate', 'check'] else kind}",
        f"interaction_type = {c['model']}", f"T = {c['temperature_K']}k",
        f"salt_concentration = {c['salt_concentration_M']}",
        f"use_average_seq = {str(c['use_average_seq']).lower()}",
        "topology = system.top", "conf_file = start.dat", f"steps = {steps}",
        f"seed = {seed}", f"refresh_vel = {str(refresh).lower()}",
        f"restart_step_counter = {str(reset).lower()}", "equilibration_steps = 0",
        "external_forces = false", "fix_diffusion = false", "list_type = verlet", "verlet_skin = 0.3",
        "time_scale = linear", f"print_conf_interval = {interval}",
        f"trajectory_print_momenta = {'true' if kind == 'MC' else 'false'}",
        "trajectory_file = trajectory.dat", "lastconf_file = last.dat",
        "energy_file = engine_energy.dat", f"print_energy_every = {interval}",
        "no_stdout_energy = true", "max_io = 100",
    ]
    if kind == "MC":
        lines.extend(["ensemble = NVT", f"delta_translation = {p['mc_translation']}",
                      f"delta_rotation = {p['mc_rotation']}"])
    else:
        lines.append(f"dt = {p['dt'] if kind in ['min', 'relax'] else c['standard_md']['dt']}")
        if kind == "min":
            lines.extend(["thermostat = no", f"minimization_max_step = {p['minimization_max_step']}"])
        else:
            lines.extend(["thermostat = bussi", f"bussi_tau = {p['bussi_tau']}",
                          f"newtonian_steps = {p['newtonian_steps']}"])
    if backend == "CUDA":
        cuda_device = os.environ.get("HADO_CUDA_DEVICE", "0")
        if not cuda_device.isdigit():
            raise ValueError("HADO_CUDA_DEVICE must be a nonnegative integer")
        lines.extend([f"CUDA_device = {cuda_device}", "CUDA_list = verlet", "use_edge = true",
                      "CUDA_print_energy = false", "CUDA_avoid_cpu_calculations = false"])
    if capped:
        lines.extend([f"max_backbone_force = {c['preparation']['max_backbone_force']}",
                      f"max_backbone_force_far = {c['preparation']['max_backbone_force_far']}"])
    lines.extend(["data_output_1 = {", " name = thermo.dat", f" print_every = {interval}",
                  " col_1 = { type = step; units = steps }",
                  " col_2 = { type = potential_energy; precision = 15 }",
                  " col_3 = { type = kinetic_energy; precision = 15 }", "}"])
    if kind in ["equilibration_candidate", "production_candidate"]:
        lines.extend(["data_output_2 = {", " name = hydrogen_bonds.dat", f" print_every = {interval}",
                      " col_1 = { type = hb_list }", "}"])
    if kind not in ["min", "MC", "check"]:
        lines.extend(["data_output_3 = {", " name = checkpoint.dat",
                      f" print_every = {c['checkpoint_interval']}", " only_last = true",
                      " col_1 = { type = configuration; print_momenta = true }", "}"])
    return "\n".join(lines)+"\n"


class IncompleteStage(RuntimeError):
    pass


def valid_checkpoint(path, top, capped):
    try:
        frame = read_conf(path, top["n"])
        audit = audit_conf(top, frame)
        if not frame["has_momenta"] or not audit["format_orientation_passed"] or (not capped and not audit["standard_fene_geometry_passed"]):
            return None
        return frame
    except (OSError, ValueError, StopIteration):
        return None


def run_stage(directory, binary, topology, source, config, kind, backend, steps,
              interval, seed, refresh, reset, capped, protocol_sha):
    """One logical chunk can consist of several preserved native attempts."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    top = read_top(topology)
    base = read_conf(source, top["n"])
    base_step = 0 if reset else int(base["step"])
    target_step = base_step+steps
    identity = dict(protocol_sha256=protocol_sha, kind=kind, backend=backend,
                    topology_sha256=digest(topology), original_start_sha256=digest(source),
                    steps=steps, interval=interval, base_seed=seed,
                    refresh_vel=refresh, restart_counter=reset, capped_backbone=capped)
    spec = directory/"stage.json"
    if spec.exists():
        old = json.loads(spec.read_text())
        if old["identity"] != identity:
            raise ValueError(f"Existing stage has different parameters/source: {directory}")
    else:
        write_json(spec, dict(identity=identity, start_step=base_step, target_step=target_step,
                             created_utc=timestamp()))
    marker = directory/"complete.json"
    if marker.exists():
        result = json.loads(marker.read_text())
        path = directory/result["final_conf"]
        if digest(path) != result["final_conf_sha256"]:
            raise ValueError("Completed native output changed")
        return path
    attempts = sorted(p for p in directory.glob("attempt_*") if p.is_dir())
    current_source, current_step, resumed = Path(source), base_step, False
    # CPU MC/minimization attempts restart their optimization/sweeps rather than
    # pretending they carry physical MD time. MD resumes the best valid snapshot.
    if kind not in ["MC", "min"]:
        for attempt in attempts:
            log = (attempt/"run.log").read_text(errors="replace") if (attempt/"run.log").exists() else ""
            if "ERROR:" in log and "The selected device is not available for computation" not in log:
                raise IncompleteStage(f"Native instability in {attempt}; inspect log and use a new protocol if changing physics")
            for name in ["checkpoint.dat", "last.dat"]:
                candidate = attempt/name
                frame = valid_checkpoint(candidate, top, capped)
                if frame is not None and current_step < frame["step"] <= target_step:
                    current_source, current_step, resumed = candidate, int(frame["step"]), True
    if current_step == target_step and steps > 0:
        write_json(marker, dict(completed_utc=timestamp(), recovered_after_interruption=True,
                   final_conf=str(current_source.relative_to(directory)), final_conf_sha256=digest(current_source),
                   start_step=base_step, end_step=target_step, requested_steps=steps))
        return current_source
    attempt = directory/f"attempt_{len(attempts)+1:03d}"
    attempt.mkdir()
    os.symlink(Path(topology).resolve(), attempt/"system.top")
    os.symlink(current_source.resolve(), attempt/"start.dat")
    remaining = target_step-current_step if kind not in ["MC", "min"] else steps
    actual_seed = (seed+1000003*len(attempts)) % 2147483647
    text = input_text(config, kind, backend, remaining, interval, actual_seed,
                      refresh and not resumed, reset and not resumed, capped)
    (attempt/"input").write_text(text)
    result = dict(started_utc=timestamp(), binary_sha256=digest(binary), kind=kind,
                  start_step=current_step,
                  requested_steps=remaining, expected_end_step=target_step,
                  input_sha256=hashlib.sha256(text.encode()).hexdigest(),
                  source_conf_sha256=digest(current_source), stochastic_seed=actual_seed,
                  resumed_from_checkpoint=resumed, bitwise_rng_continuation=False)
    write_json(attempt/"result.json", dict(status="running", **result))
    interrupted = []
    previous_handlers = {}
    process = None

    def forward(sig, _frame):
        interrupted.append(sig)
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)

    for sig in [signal.SIGTERM, signal.SIGINT, signal.SIGUSR1]:
        previous_handlers[sig] = signal.signal(sig, forward)
    started = time.monotonic()
    try:
        with (attempt/"run.log").open("w") as log:
            process = subprocess.Popen([str(binary), "input"], cwd=attempt, stdout=log,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            code = process.wait()
    finally:
        for sig, old_handler in previous_handlers.items():
            signal.signal(sig, old_handler)
    log = (attempt/"run.log").read_text(errors="replace")
    last = valid_checkpoint(attempt/"last.dat", top, capped)
    thermo_finite = False
    try:
        thermo = np.atleast_2d(np.loadtxt(attempt/"thermo.dat"))
        thermo_finite = thermo.shape[1] == 3 and bool(np.isfinite(thermo).all())
    except (OSError, ValueError, IndexError):
        pass
    completed = code == 0 and "everything went OK" in log and last is not None and int(last["step"]) == target_step and thermo_finite
    result.update(returncode=code, finished_utc=timestamp(), seconds=round(time.monotonic()-started, 6),
                  signals_received=interrupted, actual_end_step=None if last is None else last["step"],
                  status="completed" if completed else "paused" if interrupted else "failed",
                  thermo_output_finite=thermo_finite,
                  native_errors=[line for line in log.splitlines() if line.startswith("ERROR:")][:20])
    write_json(attempt/"result.json", result)
    print(json.dumps(dict(stage=str(directory.relative_to(ROOT)), status=result["status"], seconds=result["seconds"])), flush=True)
    if not completed:
        raise IncompleteStage(f"Stage did not reach its target: {attempt}. Rerun same command after interruptions; inspect errors before changing protocol.")
    write_json(marker, dict(completed_utc=timestamp(), final_conf=str((attempt/"last.dat").relative_to(directory)),
               final_conf_sha256=digest(attempt/"last.dat"), start_step=base_step, end_step=target_step,
               requested_steps=steps, capped_backbone=capped))
    return attempt/"last.dat"


def record_for(did):
    manifest = Path(os.environ.get("HADO_MANIFEST_PATH", ROOT/"manifest.json"))
    records = json.loads(manifest.read_text())
    try:
        return next(r for r in records if r["design_id"] == did)
    except StopIteration:
        raise ValueError(f"Unknown structure version: {did}") from None


def prepare(args, config, campaign, protocol_sha, backend):
    r = record_for(args.id)
    top_path, source = ROOT/r["topology"], ROOT/r["starting_conf"]
    top = read_top(top_path)
    directory = campaign/"prep"/args.id
    cpu = binary_path(args.cpu_binary, "OXDNA_CPU")
    md = cpu if backend == "CPU" else binary_path(args.gpu_binary, "OXDNA_GPU")
    with lock(directory/"job.lock"):
        ready = directory/"ready.json"
        if ready.exists():
            saved = json.loads(ready.read_text())
            if saved["protocol_sha256"] != protocol_sha or digest(directory/"prepared.dat") != saved["prepared_sha256"]:
                raise ValueError("Prepared structure or protocol changed")
            return

        def check(conf, index):
            audit = audit_conf(top, read_conf(conf, top["n"]))
            write_json(directory/f"geometry_check_{index}.json", audit)
            if not audit["format_orientation_passed"] or not audit["standard_fene_geometry_passed"]:
                return False
            try:
                run_stage(directory/f"standard_check_{index}", cpu, top_path, conf, config,
                          "check", "CPU", 0, 1, 8, True, True, False, protocol_sha)
            except IncompleteStage:
                return False
            return True

        def finish(conf, stage):
            shutil.copy2(conf, directory/"prepared.dat")
            write_json(ready, dict(design_id=args.id, prepared_utc=timestamp(),
                protocol_sha256=protocol_sha, prepared_sha256=digest(directory/"prepared.dat"),
                preparation_stage=stage, standard_potential_initialization_passed=True,
                equilibrium_proven=False, thermal_training_eligible=False))

        if check(source, "original"):
            finish(source, "provided_starting_configuration")
            return
        p = config["preparation"]
        seed_offset = int(p.get("seed_offset", 0))
        if seed_offset < 0:
            raise ValueError("preparation.seed_offset must be nonnegative")
        if r["source_preparation"] == "native_export_only" and p["minimization_steps"] > 0:
            source = run_stage(directory/"minimization", cpu, top_path, source, config,
                    "min", "CPU", p["minimization_steps"], min(p["minimization_steps"], 100),
                    8 + seed_offset, True, True, True, protocol_sha)
            if check(source, "post_min"):
                finish(source, "new_capped_minimization")
                return
        if p["mc_steps"] > 0:
            source = run_stage(directory/"mc", cpu, top_path, source, config, "MC", "CPU",
                    p["mc_steps"], max(1, p["mc_steps"]), 8 + seed_offset, False, True, True, protocol_sha)
            if check(source, "post_mc"):
                finish(source, "capped_MC")
                return
        limit = args.max_relax_chunks or p["max_relax_chunks"]
        for chunk in range(1, limit+1):
            source = run_stage(directory/f"relax_{chunk:04d}", md, top_path, source, config,
                    "relax", backend, p["relax_chunk_steps"], config["trajectory_interval"],
                    8+1009*chunk+seed_offset, chunk == 1, chunk == 1, True, protocol_sha)
            if check(source, f"relax_{chunk:04d}"):
                finish(source, f"capped_MD_{chunk:04d}")
                return
        write_json(directory/"blocked.json", dict(design_id=args.id, failed_utc=timestamp(),
                   reason="preparation_limit_reached_with_invalid_standard_backbone_geometry",
                   completed_relax_chunks=limit, latest_conf=str(source.relative_to(ROOT)),
                   thermal_training_eligible=False))
        raise IncompleteStage("Preparation reached its limit. Extend limit or revise the starting geometry; standard MD was not started.")


def sample(args, config, campaign, protocol_sha, backend):
    r = record_for(args.id)
    if args.seed not in config["seeds"]:
        raise ValueError("Seed must be listed in simulation config")
    prep = campaign/"prep"/args.id
    if not (prep/"ready.json").exists():
        raise IncompleteStage(f"{args.id} is not prepared. Run prepare first.")
    ready = json.loads((prep/"ready.json").read_text())
    if ready["protocol_sha256"] != protocol_sha or digest(prep/"prepared.dat") != ready["prepared_sha256"]:
        raise ValueError("Prepared input/protocol identity mismatch")
    binary = binary_path(args.cpu_binary, "OXDNA_CPU") if backend == "CPU" else binary_path(args.gpu_binary, "OXDNA_GPU")
    directory = campaign/"samples"/args.id/f"seed_{args.seed}"
    with lock(directory/"job.lock"):
        source = prep/"prepared.dat"
        s = config["sampling_schedule"]
        phases = [("equilibration_candidate", s["equilibration_chunks"]),
                  ("production_candidate", args.production_chunks or s["production_chunks"])]
        count = 0
        for kind, limit in phases:
            for chunk in range(1, limit+1):
                count += 1
                source = run_stage(directory/f"{kind}_{chunk:04d}", binary, ROOT/r["topology"], source,
                        config, kind, backend, s["chunk_steps"], config["trajectory_interval"],
                        args.seed+1009*(count-1), count == 1, count == 1, False, protocol_sha)
        write_json(directory/"sampling_complete.json", dict(design_id=args.id, seed=args.seed,
            completed_utc=timestamp(), protocol_sha256=protocol_sha,
            production_chunks=phases[-1][1], last_conf=str(source.relative_to(ROOT)),
            qualified_equilibrium_not_assumed=True, thermal_training_eligible=False))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=["prepare", "sample"])
    p.add_argument("--id", required=True)
    p.add_argument("--seed", type=int)
    p.add_argument("--config", default="config/simulation.json")
    p.add_argument("--campaign", default="server_v2")
    p.add_argument("--backend", choices=["CPU", "CUDA"])
    p.add_argument("--cpu-binary"); p.add_argument("--gpu-binary")
    p.add_argument("--production-chunks", type=int)
    p.add_argument("--max-relax-chunks", type=int)
    args = p.parse_args()
    c = json.loads(config_path(args.config).read_text())
    backend = args.backend or c["md_backend"]
    if backend not in ["CPU", "CUDA"]:
        raise ValueError("MD backend must be CPU or CUDA")
    if not c["seeds"] or len(c["seeds"]) != len(set(c["seeds"])) or any(type(s) is not int or not 0 <= s < 2147483647 for s in c["seeds"]):
        raise ValueError("Replica seeds must be distinct nonnegative 32-bit integers")
    if c["sampling_schedule"]["chunk_steps"] <= 0 or c["sampling_schedule"]["equilibration_chunks"] < 0 or c["sampling_schedule"]["production_chunks"] <= 0:
        raise ValueError("Sampling chunk length/counts are invalid")
    if c["model"] != "DNA2" or not c["use_average_seq"]:
        raise ValueError("This validated handoff supports DNA2 average-sequence only; other models need a new validated protocol.")
    for key in ["trajectory_interval", "checkpoint_interval"]:
        if c[key] <= 0:
            raise ValueError("Output intervals must be positive")
    for value in [args.production_chunks, args.max_relax_chunks]:
        if value is not None and value <= 0:
            raise ValueError("Chunk count must be positive")
    campaign, signature = register_campaign(args.campaign, c, backend)
    if args.action == "sample" and args.seed is None:
        p.error("sample requires --seed")
    try:
        (prepare if args.action == "prepare" else sample)(args, c, campaign, signature, backend)
    except IncompleteStage as exc:
        print(str(exc), file=sys.stderr)
        return 4
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
