"""Classic oxDNA IO and design-local measurements (DNA2, nm).

Design-pair edges are used only for reconstructing periodic images. They are
annotations, never forces. Reference and sampled measurements use identical
terminal windows. A static configuration cannot supply thermal fluctuations.
"""
from __future__ import annotations

import csv
import json
from collections import deque
from pathlib import Path

import numpy as np

NM = 0.8518


def read_top(path):
    with Path(path).open() as f:
        header = f.readline().split()
        if len(header) != 2:
            raise ValueError("Only classic topology is supported")
        n, strands = map(int, header)
        rows = [line.split() for line in f if line.strip()]
    if len(rows) != n or any(len(r) != 4 for r in rows):
        raise ValueError("Topology particle count/columns do not match")
    sid = np.array([int(r[0]) for r in rows], dtype=np.int32)
    bases = np.array([r[1] for r in rows], dtype="U1")
    n3 = np.array([int(r[2]) for r in rows], dtype=np.int32)
    n5 = np.array([int(r[3]) for r in rows], dtype=np.int32)
    if len(np.unique(sid)) != strands or not np.isin(bases, list("ACGT")).all():
        raise ValueError("Invalid strand count or base identities")
    for pointer, reverse in [(n3, n5), (n5, n3)]:
        present = np.flatnonzero(pointer >= 0)
        if np.any(pointer < -1) or np.any(pointer >= n) or np.any(reverse[pointer[present]] != present):
            raise ValueError("Backbone pointers must be reciprocal")
        if np.any(sid[pointer[present]] != sid[present]):
            raise ValueError("Backbone connects different strands")
    return dict(n=n, strands=strands, strand=sid, bases=bases, n3=n3, n5=n5)


def frames(path, n):
    with Path(path).open() as f:
        while True:
            line = f.readline()
            if not line:
                return
            if not line.strip():
                continue
            if not line.startswith("t ="):
                raise ValueError(f"Invalid frame header in {path}: {line[:60]}")
            step = float(line.split("=", 1)[1])
            box_line, energy_line = f.readline(), f.readline()
            if not box_line.startswith("b =") or not energy_line.startswith("E ="):
                raise ValueError("Missing configuration box/energy header")
            box = np.fromstring(box_line.split("=", 1)[1], sep=" ")
            rows = [f.readline() for _ in range(n)]
            if not rows[-1]:
                raise ValueError("Truncated configuration: last particle missing")
            values = np.fromstring("".join(rows), sep=" ")
            if values.size not in [9*n, 15*n]:
                raise ValueError("Expected 9 geometry values or 15 geometry/momentum values per particle")
            has_momenta = values.size == 15*n
            columns = 15 if has_momenta else 9
            data = values.reshape(n, columns)
            if not has_momenta:
                # Padding supports shared measurement code; it must never be
                # mistaken for real zero velocities in a restart checkpoint.
                data = np.column_stack([data, np.zeros((n, 6))])
            if box.shape != (3,) or not np.all(box > 0) or not np.isfinite(data).all():
                raise ValueError("Non-finite configuration or invalid box")
            yield dict(step=step, box=box, data=data, has_momenta=has_momenta)


def read_conf(path, n):
    stream = frames(path, n)
    first = next(stream)
    if next(stream, None) is not None:
        raise ValueError("Expected one configuration, not a trajectory")
    return first


def audit_conf(top, frame):
    data, box = frame["data"], frame["box"]
    a1, a3 = data[:, 3:6], data[:, 6:9]
    norm = float(max(np.max(abs(np.linalg.norm(a1, axis=1)-1)), np.max(abs(np.linalg.norm(a3, axis=1)-1))))
    dot = float(np.max(abs(np.sum(a1*a3, axis=1))))
    backbone = data[:, :3] - 0.34*a1 + 0.3408*np.cross(a3, a1)
    bonded = np.flatnonzero(top["n3"] >= 0)
    delta = backbone[top["n3"][bonded]] - backbone[bonded]
    delta -= box*np.round(delta/box)
    lengths = np.linalg.norm(delta, axis=1)
    bad = abs(lengths-0.7564) >= 0.25
    return dict(format_orientation_passed=bool(norm < 1e-5 and dot < 1e-5),
                max_axis_norm_error=norm, max_axis_dot_error=dot,
                standard_fene_outliers=int(bad.sum()),
                standard_fene_geometry_passed=bool(not bad.any()),
                min_backbone_length_ox=float(lengths.min()),
                max_backbone_length_ox=float(lengths.max()))


def load_mapping_csv(path, n):
    with Path(path).open(newline="") as f:
        rows = list(csv.DictReader(f))
    rows.sort(key=lambda r: int(r["oxdna_id"]))
    if [int(r["oxdna_id"]) for r in rows] != list(range(n)):
        raise ValueError("Nucleotide mapping must cover all particle IDs once")
    return {key: np.array([int(r[key]) for r in rows], dtype=np.int32)
            for key in ["hado_helix", "helix_offset", "bundle_id", "designed_pair_id"]}


def spanning_forest(top, pair):
    n = top["n"]
    neighbours = [[] for _ in range(n)]
    for pointer in [top["n3"], top["n5"], pair]:
        for i in np.flatnonzero(pointer >= 0):
            neighbours[int(i)].append(int(pointer[i]))
    parent = np.full(n, -1, dtype=np.int32)
    depth = np.zeros(n, dtype=np.int32)
    seen = np.zeros(n, dtype=bool)
    roots = []
    for start in range(n):
        if seen[start]:
            continue
        roots.append(start)
        seen[start] = True
        q = deque([start])
        while q:
            i = q.popleft()
            for j in neighbours[i]:
                if not seen[j]:
                    seen[j] = True
                    parent[j] = i
                    depth[j] = depth[i]+1
                    q.append(j)
    edges = set()
    for i, ns in enumerate(neighbours):
        for j in ns:
            edges.add(tuple(sorted((i, j))))
    return parent, depth, np.array(roots, dtype=np.int32), np.array(sorted(edges), dtype=np.int32)


def unwrap(pos, box, mapping):
    bonds = mapping["unwrap_edges"]
    delta = pos[bonds[:, 1]] - pos[bonds[:, 0]]
    if not np.any(abs(delta) > box/2):
        return pos.copy(), 0.0
    parent, depth = mapping["unwrap_parent"], mapping["unwrap_depth"]
    result = np.empty_like(pos)
    result[mapping["unwrap_roots"]] = pos[mapping["unwrap_roots"]]
    for level in range(1, int(depth.max())+1):
        ids = np.flatnonzero(depth == level)
        p = parent[ids]
        d = pos[ids]-pos[p]
        d -= box*np.round(d/box)
        result[ids] = result[p]+d
    raw = pos[bonds[:, 1]]-pos[bonds[:, 0]]
    raw -= box*np.round(raw/box)
    residual = np.linalg.norm(result[bonds[:, 1]]-result[bonds[:, 0]]-raw, axis=1)
    return result, float(residual.max())


def align_points(points, reference):
    x = points-points.mean(axis=0)
    y = reference-reference.mean(axis=0)
    u, _, vt = np.linalg.svd(x.T@y)
    d = np.eye(3)
    d[-1, -1] = np.sign(np.linalg.det(u@vt))
    return x@(u@d@vt)+reference.mean(axis=0)


def create_mapping(design_dir, top_path, initial_path, model_path):
    design_dir = Path(design_dir)
    top = read_top(top_path)
    nt = load_mapping_csv(design_dir/"nucleotide_mapping.csv", top["n"])
    raw = json.loads(Path(model_path).read_text())["nucleotide_level_model"]
    geometry = json.loads((design_dir/"geometry.json").read_text())
    vertices = np.array(geometry["vertices"], dtype=float)
    edges = np.array(geometry["edges"], dtype=np.int32)
    by_edge = {tuple(sorted(e)): i for i, e in enumerate(edges.tolist())}
    bundle_edge = np.array([by_edge[tuple(sorted(e))] for e in raw["_idx_edge_map"]], dtype=np.int32)
    helix_bundle = np.array(raw["_helix_to_bundle"], dtype=np.int32)
    if not np.array_equal(helix_bundle[nt["hado_helix"]], nt["bundle_id"]):
        raise ValueError("Native model and exported bundle IDs disagree")
    pair = nt["designed_pair_id"]
    paired = np.flatnonzero(pair >= 0)
    if np.any(pair >= top["n"]) or not np.array_equal(pair[pair[paired]], paired):
        raise ValueError("Designed pairs must be reciprocal")
    comp = {"A": "T", "C": "G", "G": "C", "T": "A"}
    if any(top["bases"][pair[i]] != comp[top["bases"][i]] for i in paired):
        raise ValueError("Designed paired bases are not complementary")
    nt_edge = bundle_edge[nt["bundle_id"]]
    frame = read_conf(initial_path, top["n"])
    if not audit_conf(top, frame)["format_orientation_passed"]:
        raise ValueError("Invalid initial orientations")
    parent, depth, roots, bonds = spanning_forest(top, pair)
    m = dict(vertices_nm=vertices, edges=edges, nt_edge=nt_edge,
             nt_helix=nt["hado_helix"], nt_offset=nt["helix_offset"], pair=pair,
             helix_edge=bundle_edge[helix_bundle], unwrap_parent=parent,
             unwrap_depth=depth, unwrap_roots=roots, unwrap_edges=bonds,
             strand=top["strand"], bases=top["bases"], n3=top["n3"], n5=top["n5"])
    initial, residual = unwrap(frame["data"][:, :3], frame["box"], m)
    if len(roots) != 1 or residual > 1e-5:
        raise ValueError("Designed complex must have one consistent periodic image")
    m["initial_positions_nm"] = initial*NM
    pair_ids = np.flatnonzero((pair >= 0) & (np.arange(top["n"]) < pair))
    helix_groups, all_groups, offsets = [], [], [0]
    for h, e in enumerate(m["helix_edge"]):
        ids = pair_ids[nt["hado_helix"][pair_ids] == h]
        ids = ids[np.argsort(nt["helix_offset"][ids])]
        if len(ids) < 10:
            raise ValueError(f"Helix {h} has too few designed base pairs")
        mid = (initial[ids]+initial[pair[ids]])/2
        u, v = edges[e]
        if np.dot(mid[-1]-mid[0], vertices[v]-vertices[u]) < 0:
            ids = ids[::-1]
        groups = list(np.array_split(ids, 11))
        groups[0], groups[-1] = ids[:5], ids[-5:]
        groups = [g if len(g) else ids[[min(len(ids)-1, int((b/10)*(len(ids)-1)))]] for b, g in enumerate(groups)]
        for g in groups:
            all_groups.extend(g.tolist())
            offsets.append(len(all_groups))
        helix_groups.append(h)
    m["centerline_group_ids"] = np.array(all_groups, dtype=np.int32)
    m["centerline_group_offsets"] = np.array(offsets, dtype=np.int32)
    pairs = []
    for node in range(len(vertices)):
        incident = np.flatnonzero(np.any(edges == node, axis=1))
        for i, a in enumerate(incident):
            for b in incident[i+1:]:
                va = vertices[edges[a, 1] if edges[a, 0] == node else edges[a, 0]]-vertices[node]
                vb = vertices[edges[b, 1] if edges[b, 0] == node else edges[b, 0]]-vertices[node]
                angle = np.degrees(np.arccos(np.clip(np.dot(va, vb)/np.linalg.norm(va)/np.linalg.norm(vb), -1, 1)))
                pairs.append((node, a, b, angle))
    m["junction_pairs"] = np.array(pairs, dtype=float).reshape(-1, 4)
    hline, eline = centerlines(m["initial_positions_nm"], m)
    mid_design = vertices[edges].mean(axis=1)
    mid_initial = eline.mean(axis=1)
    # Transform the design graph into the initial coordinate frame. This is
    # calibration only; later measurements must transform equivariantly.
    x, y = mid_design-mid_design.mean(0), mid_initial-mid_initial.mean(0)
    u, _, vt = np.linalg.svd(x.T@y)
    d = np.eye(3); d[-1, -1] = np.sign(np.linalg.det(u@vt))
    target = (vertices-mid_design.mean(0))@(u@d@vt)+mid_initial.mean(0)
    m["vertex_axial_offsets_nm"] = np.zeros((len(edges), 2))
    for e, (a, b) in enumerate(edges):
        for end, node in enumerate([a, b]):
            p = eline[e, 0 if end == 0 else -1]
            axis = eline[e, 2]-p if end == 0 else eline[e, -3]-p
            axis /= np.linalg.norm(axis)
            m["vertex_axial_offsets_nm"][e, end] = np.dot(target[node]-p, axis)
    m["initial_helix_span_nm"], m["initial_helix_deflection_nm"] = shape(hline)
    m["initial_edge_span_nm"], m["initial_edge_deflection_nm"] = shape(eline)
    return m


def centerlines(pos_nm, m):
    pair_mid = (pos_nm+pos_nm[np.maximum(m["pair"], 0)])/2
    ids, offsets = m["centerline_group_ids"], m["centerline_group_offsets"]
    reduced = np.add.reduceat(pair_mid[ids], offsets[:-1], axis=0)
    reduced /= np.diff(offsets)[:, None]
    helices = reduced.reshape(-1, 11, 3)
    edges = np.zeros((len(m["edges"]), 11, 3))
    np.add.at(edges, m["helix_edge"], helices)
    edges /= np.bincount(m["helix_edge"], minlength=len(edges))[:, None, None]
    return helices, edges


def shape(lines):
    chord = lines[:, -1]-lines[:, 0]
    span = np.linalg.norm(chord, axis=1)
    if np.any(span < 1e-8):
        raise ValueError("Degenerate edge/helix span")
    relative = lines-lines[:, :1]
    projection = np.sum(relative*chord[:, None], axis=2)/(span**2)[:, None]
    closest = lines[:, :1]+np.clip(projection, 0, 1)[:, :, None]*chord[:, None]
    deflection = np.linalg.norm(lines-closest, axis=2).max(axis=1)
    return span, deflection


def fitted_vertices(lines, m):
    edges = m["edges"]
    positions, residuals = [], []
    axes = {}
    for e, (u, v) in enumerate(edges):
        for end, node in enumerate([u, v]):
            p = lines[e, 0 if end == 0 else -1]
            a = lines[e, 2]-p if end == 0 else lines[e, -3]-p
            a /= np.linalg.norm(a)
            axes[int(node), e] = (p, a, end)
    for node in range(len(m["vertices_nm"])):
        incident = np.flatnonzero(np.any(edges == node, axis=1))
        lines_at = [axes[node, int(e)] for e in incident]
        projectors = [np.eye(3)-np.outer(a, a) for _, a, _ in lines_at]
        matrix = np.sum(projectors, axis=0)
        if len(incident) == 1 or np.linalg.cond(matrix) > 1e6:
            estimates = [p+a*m["vertex_axial_offsets_nm"][e, end] for e, (p, a, end) in zip(incident, lines_at)]
            point = np.mean(estimates, axis=0)
        else:
            point = np.linalg.solve(matrix, np.sum([mat@p for mat, (p, _, _) in zip(projectors, lines_at)], axis=0))
        positions.append(point)
        residuals.append(np.sqrt(np.mean([np.sum((mat@(point-p))**2) for mat, (p, _, _) in zip(projectors, lines_at)])))
    return np.array(positions), np.array(residuals), axes


def measure(frame, m, anchors):
    pos, periodic_error = unwrap(frame["data"][:, :3], frame["box"], m)
    pos *= NM
    hl, el = centerlines(pos, m)
    hs, hd = shape(hl); es, ed = shape(el)
    vertices, vertex_residual, axes = fitted_vertices(el, m)
    angle = []
    for node, a, b, _ in m["junction_pairs"]:
        aa, bb = axes[int(node), int(a)][1], axes[int(node), int(b)][1]
        angle.append(np.degrees(np.arccos(np.clip(np.dot(aa, bb), -1, 1))))
    anchor_values = []
    for entry in anchors:
        if entry["kind"] == "nucleotide_groups":
            pa = pos[entry["group_a"]].mean(0)
            pb = pos[entry["group_b"]].mean(0)
        elif entry["kind"] == "geometric_vertices":
            pa, pb = vertices[entry["vertex_a"]], vertices[entry["vertex_b"]]
        else:
            raise ValueError("Unknown anchor kind")
        anchor_values.append(np.linalg.norm(pa-pb))
    aligned = align_points(vertices, m["vertices_nm"])
    vertex_rmsd = np.sqrt(np.mean(np.sum((aligned-m["vertices_nm"])**2, axis=1)))
    aligned_nt = align_points(pos, m["initial_positions_nm"])
    nt_rmsd = np.sqrt(np.mean(np.sum((aligned_nt-m["initial_positions_nm"])**2, axis=1)))
    return dict(edge_span_nm=es, edge_deflection_nm=ed, helix_span_nm=hs,
                helix_deflection_nm=hd, junction_angle_deg=np.array(angle),
                anchor_distance_nm=np.array(anchor_values),
                vertex_positions_nm=aligned, vertex_intersection_residual_nm=vertex_residual,
                design_vertex_rmsd_nm=np.array([vertex_rmsd]),
                initial_nucleotide_rmsd_nm=np.array([nt_rmsd]),
                periodic_image_residual_ox=np.array([periodic_error]))


def validate_anchors(entries, n, nv):
    names = set()
    for entry in entries:
        if not entry.get("name") or entry["name"] in names:
            raise ValueError("Anchor names must be unique and nonempty")
        names.add(entry["name"])
        if entry["kind"] == "nucleotide_groups":
            a, b = entry["group_a"], entry["group_b"]
            if not a or not b or len(set(a)) != len(a) or len(set(b)) != len(b) or set(a)&set(b):
                raise ValueError("Anchor groups must be nonempty, unique, disjoint")
            if any(not isinstance(i, int) or i < 0 or i >= n for i in a+b):
                raise ValueError("Anchor nucleotide IDs must be zero-based topology IDs")
            if not entry.get("experimental_site_description"):
                raise ValueError("Actual anchors need an experimental-site description")
        elif entry["kind"] == "geometric_vertices":
            a, b = entry["vertex_a"], entry["vertex_b"]
            if not (0 <= a < nv and 0 <= b < nv and a != b):
                raise ValueError("Invalid geometric vertex anchor")
        else:
            raise ValueError("Invalid anchor kind")
        if not np.isfinite(entry["target_distance_nm"]) or entry["target_distance_nm"] <= 0:
            raise ValueError("Target anchor distance must be positive and finite")
    return entries
