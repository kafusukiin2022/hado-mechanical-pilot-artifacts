"""FENE-safe kinematic decoder primitives for oxDNA-like nucleotide chains.

The decoder works in an unwrapped coordinate chart.  Each strand is rebuilt
from an anchor backbone site and an anchor frame.  Backbone lengths are
bounded by construction; periodic wrapping is deliberately left to the I/O
layer so a bond crossing a box boundary is not mistaken for a long bond.
"""
from __future__ import annotations
from typing import Sequence
import torch
from torch import nn

from onepass_model import so3_exp
from restart_guided_loss import FENE_R0, FENE_DELTA, POS_MM_BACK1, POS_MM_BACK2


def bounded_backbone_length(raw: torch.Tensor, margin: float = 0.02) -> torch.Tensor:
    """Map arbitrary scalars into the strict interior of the oxDNA FENE range."""
    radius = float(FENE_DELTA) - float(margin)
    if radius <= 0:
        raise ValueError("margin must be smaller than FENE_DELTA")
    return float(FENE_R0) + radius * torch.tanh(raw)


def normalize_local_direction(raw: torch.Tensor) -> torch.Tensor:
    return raw / torch.linalg.vector_norm(raw, dim=-1, keepdim=True).clamp_min(1e-8)


def backbone_site_from_center(center: torch.Tensor, rotation: torch.Tensor) -> torch.Tensor:
    a1, a3 = rotation[..., :, 0], rotation[..., :, 2]
    return center + POS_MM_BACK1 * a1 + POS_MM_BACK2 * torch.cross(a3, a1, dim=-1)


def center_from_backbone_site(backbone: torch.Tensor, rotation: torch.Tensor) -> torch.Tensor:
    a1, a3 = rotation[..., :, 0], rotation[..., :, 2]
    offset = POS_MM_BACK1 * a1 + POS_MM_BACK2 * torch.cross(a3, a1, dim=-1)
    return backbone - offset


def decode_strand(anchor_backbone: torch.Tensor, anchor_rotation: torch.Tensor,
                  raw_length: torch.Tensor, raw_direction: torch.Tensor,
                  raw_rotation: torch.Tensor, margin: float = 0.02):
    """Reconstruct one ordered strand from relative SE(3) predictions.

    ``raw_length[k]`` and ``raw_direction[k]`` describe the edge from node k
    to k+1. ``raw_rotation[k]`` is a local rotation vector applied after node
    k.  The output is unwrapped and has shape ``(N, 3)`` and ``(N, 3, 3)``.
    """
    n_edges = raw_length.shape[0]
    if raw_direction.shape[0] != n_edges or raw_rotation.shape[0] != n_edges:
        raise ValueError("relative edge tensors must have the same length")
    if anchor_backbone.shape != (3,) or anchor_rotation.shape != (3, 3):
        raise ValueError("anchor shapes must be [3] and [3,3]")
    lengths = bounded_backbone_length(raw_length, margin)
    directions = normalize_local_direction(raw_direction)
    if n_edges:
        delta_r = so3_exp(raw_rotation)
        # Differentiable doubling scan for left cumulative matrix products:
        # P[k] = D[k] ... D[0]. This reduces serial chain decoding from O(N)
        # Python/GPU launches to O(log N) batched tensor operations.
        prefix = delta_r
        offset = 1
        while offset < n_edges:
            prefix = torch.cat((prefix[:offset],
                                prefix[offset:] @ prefix[:-offset]), dim=0)
            offset *= 2
        tail_r = prefix @ anchor_rotation
        r = torch.cat((anchor_rotation.unsqueeze(0), tail_r), dim=0)
        # One batched QR correction prevents accumulated numerical drift on
        # long scaffolds while keeping gradients through the decoder.
        q, u = torch.linalg.qr(r)
        diag = torch.diagonal(u, dim1=-2, dim2=-1)
        sign = torch.where(diag < 0, -torch.ones_like(diag), torch.ones_like(diag))
        r = q @ torch.diag_embed(sign)
        det = torch.linalg.det(r)
        fix = torch.ones_like(sign); fix[:, -1] = torch.where(det < 0, -1.0, 1.0)
        r = q @ torch.diag_embed(sign * fix)
        steps = lengths[:, None] * torch.matmul(r[:-1], directions.unsqueeze(-1)).squeeze(-1)
        b = torch.cat((anchor_backbone.unsqueeze(0),
                       anchor_backbone.unsqueeze(0) + torch.cumsum(steps, dim=0)), dim=0)
    else:
        b = anchor_backbone.unsqueeze(0)
        r = anchor_rotation.unsqueeze(0)
    return center_from_backbone_site(b, r), r, b, lengths


def decode_strands(anchors_backbone: torch.Tensor, anchors_rotation: torch.Tensor,
                   strand_orders: Sequence[Sequence[int]], raw_length: torch.Tensor,
                   raw_direction: torch.Tensor, raw_rotation: torch.Tensor,
                   margin: float = 0.02):
    """Decode disjoint strands while preserving their original node indices."""
    if len(strand_orders) != len(anchors_backbone):
        raise ValueError("one anchor is required per strand")
    n_nodes = sum(len(order) for order in strand_orders)
    device, dtype = anchors_backbone.device, anchors_backbone.dtype
    centers = torch.zeros((n_nodes, 3), device=device, dtype=dtype)
    rotations = torch.zeros((n_nodes, 3, 3), device=device, dtype=dtype)
    lengths = []
    cursor = 0
    for sid, order in enumerate(strand_orders):
        order = list(map(int, order))
        m = len(order)
        c, r, _, ell = decode_strand(anchors_backbone[sid], anchors_rotation[sid],
                                     raw_length[cursor:cursor+m-1],
                                     raw_direction[cursor:cursor+m-1],
                                     raw_rotation[cursor:cursor+m-1], margin)
        centers[torch.as_tensor(order, device=device)] = c
        rotations[torch.as_tensor(order, device=device)] = r
        lengths.append(ell); cursor += m-1
    if cursor != len(raw_length):
        raise ValueError("relative edge count does not match strand orders")
    return centers, rotations, torch.cat(lengths) if lengths else raw_length.new_empty((0,))


class KinematicSE3Predictor(nn.Module):
    """PaiNN encoder with relative-edge and per-strand anchor heads.

    The encoder consumes the existing multirelation graph. Its output is not a
    set of independent nucleotide coordinates: it predicts bounded backbone
    lengths, local unit directions, relative rotations, and one equivariant
    anchor pose update per strand; ``decode_strands`` constructs the structure.
    """
    def __init__(self, node_features=6, hidden=128, depth=3, edge_feature_dim=20,
                 margin=0.02):
        super().__init__()
        from transfer_operator.painn_flow import PaiNNPositionFlow
        self.hidden = int(hidden); self.margin = float(margin)
        self.encoder = PaiNNPositionFlow(
            node_features=node_features, hidden=hidden, depth=depth, rbf=16,
            cutoff=0.08, edge_types=5, spatial_layers=depth,
            condition_vector_channels=2, edge_feature_dim=edge_feature_dim,
            edge_chunk_size=8192,
        )
        self.relative_head = nn.Sequential(nn.Linear(2*hidden,hidden),nn.SiLU(),
                                           nn.Linear(hidden,hidden),nn.SiLU(),nn.Linear(hidden,7))
        self.anchor_head = nn.Sequential(nn.Linear(hidden,hidden),nn.SiLU(),nn.Linear(hidden,2*hidden))
        nn.init.zeros_(self.relative_head[-1].weight); nn.init.zeros_(self.relative_head[-1].bias)
        nn.init.zeros_(self.anchor_head[-1].weight); nn.init.zeros_(self.anchor_head[-1].bias)

    def forward(self, pos, rotation, node_features, edge_index, edge_vectors,
                edge_types, edge_features, strand_orders, anchor_position,
                reference_position):
        cond=torch.stack((rotation[..., :,0],rotation[..., :,2]),dim=1)
        s,v=self.encoder._encode(pos,pos,torch.tensor(.5,device=pos.device,dtype=pos.dtype),
            torch.tensor(1.,device=pos.device,dtype=pos.dtype),edge_index,edge_vectors,
            edge_types,node_features,cond,edge_features=edge_features)
        parent=[]; child=[]; anchors=[]
        for order in strand_orders:
            order=list(map(int,order)); anchors.append(order[0])
            parent.extend(order[:-1]); child.extend(order[1:])
        parent=torch.as_tensor(parent,device=pos.device,dtype=torch.long)
        child=torch.as_tensor(child,device=pos.device,dtype=torch.long)
        raw=self.relative_head(torch.cat((s[parent],s[child]),dim=-1))
        raw_length,raw_direction,raw_rotation=raw[:,0],raw[:,1:4],raw[:,4:7]
        # Residualize directions around the source local geometry. With a
        # zero-initialized head this starts as a valid source-like chain.
        ref_back=backbone_site_from_center(reference_position,rotation)
        ref_delta=ref_back[child]-ref_back[parent]
        ref_local=torch.einsum('nij,nj->ni',rotation[parent].transpose(-1,-2),ref_delta)
        raw_direction=raw_direction+normalize_local_direction(ref_local)
        anchors=torch.as_tensor(anchors,device=pos.device,dtype=torch.long)
        coeff=self.anchor_head(s[anchors]).reshape(len(anchors),2,self.hidden)
        coeff=.5*torch.tanh(coeff)/max(self.hidden**.5,1.)
        vv=v[anchors]
        vrms=torch.sqrt(vv.square().mean(-1,keepdim=True)+1e-6); vv=vv/vrms
        anchor_delta=torch.einsum('sch,shd->scd',coeff,vv)
        anchor_pos=anchor_position[anchors]+anchor_delta[:,0]
        anchor_rot=so3_exp(anchor_delta[:,1])@rotation[anchors]
        anchor_back=backbone_site_from_center(anchor_pos,anchor_rot)
        out_pos,out_rot,lengths=decode_strands(anchor_back,anchor_rot,strand_orders,
            raw_length,raw_direction,raw_rotation,self.margin)
        return {'position':out_pos,'rotation':out_rot,'a1':out_rot[..., :,0],
                'a3':out_rot[..., :,2],'backbone_length':lengths,
                'relative_edge_index':torch.stack((parent,child)),
                'raw_relative':raw,'anchor_position':anchor_pos}
