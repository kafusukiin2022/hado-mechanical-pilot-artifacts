#!/usr/bin/env bash
set -euo pipefail
for id in H101 H102 H103; do
  mkdir -p "runs/${id}_prepared_100"
  cp "data/${id}/initial.top" "runs/${id}_prepared_100/system.top"
  cp "data/${id}/prepared.dat" "runs/${id}_prepared_100/start.dat"
  cp config/oxdna_100_steps.input "runs/${id}_prepared_100/input"
  (cd "runs/${id}_prepared_100" && ../../bin/oxDNA_cpu input)
done
