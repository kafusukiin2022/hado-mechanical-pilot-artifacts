# 问题样本：H281 DeepSNUPI 节点到 oxDNA 碱基对的身份映射

请帮我解决 H281 从 DeepSNUPI 预测结果到 oxDNA 核苷酸配置的**节点身份映射**问题。预测已完成，但不能安全地按数组行号把预测坐标套到 oxDNA 拓扑上。

## 已知数据

- HADO 设计有 N=11,864 个核苷酸、P=5,746 对目标碱基对。
- HADO 配对表为
  \[
  \mathcal P=\{(a_j,b_j)\}_{j=1}^{P},\qquad a_j,b_j\in\{0,\ldots,N-1\}.
  \]
  数据在 `data/hado/native_pairs.json`。
- oxDNA 拓扑及初始构型分别在 `data/hado/design.top` 和 `data/hado/initial_design.dat`。
- SNUPI 生成的 DeepSNUPI MAT 在 `data/snupi/H281_DGNN_INIT.mat`。
- DeepSNUPI 输出在 `results/deepsnupi_prediction.npy`，形状为 `5746 x 6`。第 i 行包含节点 i 的位置和朝向参数：
  \[
  \hat y_i=(\hat p_i,\hat\omega_i)\in\mathbb R^3\times\mathbb R^3.
  \]
- MAT 中有 `init_coord`（`5746 x 8`）、`elem_conn`（`2 x 12080`）、`prop`（`12080 x 36`），但没有节点到 HADO 配对 ID 的显式映射。

## 请求

需要一个映射
\[
\pi:\{0,\ldots,5745\}\rightarrow\{0,\ldots,5745\},
\]
其中 π(i)=j 表示 DeepSNUPI 节点 i 对应 HADO 配对 ((a_j,b_j))。理想情况下，π 是双射。请说明如何从现有文件恢复或验证 π，并给出可执行算法及严格验证准则。

可能可利用的信息包括：

1. SNUPI MAT 中的节点坐标、朝向、helix 标签和边连接/边属性；
2. `data/hado/cadnano.json` 中每个 helix 的 `num`、`row`、`col`、`scaf`、`stap` 路由；
3. `data/hado/nucleotide_map.json`、链路由、配对表及 oxDNA 构型；
4. SNUPI 导出 MAT 的源代码或中间变量（如果能恢复每个节点对应的 caDNAno helix/offset 或两枚 nt ID）。

如果只能通过图同构、坐标匹配或其他间接方法推断，请给出足够严格的唯一性/误差检查；如果现有资料不足以唯一恢复，也请明确指出缺少哪个身份字段或导出步骤。

映射获得后，还需将预测的位置与朝向一致写回对应的两枚配对核苷酸，保留原 oxDNA 拓扑和非配对核苷酸路由。请说明如何处理单位、局部坐标轴、互补链朝向、刚体对齐及 ssDNA 几何，以及哪些检查通过后才允许启动标准力场最小化与 equilibrium。

## 当前已知审计结果

- 按行号直接映射不可信；节点数量相同不等于节点顺序相同。
- 一次试探性坐标审计把 MAT 坐标乘以未经证实的 0.1，最近 HADO 配对中心的距离中位数为 9.90 nm，5,746 个点只命中 105 个不同目标。该缩放和最近邻结果都不能作为映射依据。
- 细节见 `results/mapping_audit.json`。请勿假设 0.1 是正确单位换算。
- 在获得并验证节点身份映射前，不应将坐标写入 oxDNA 或启动 equilibrium/production。
