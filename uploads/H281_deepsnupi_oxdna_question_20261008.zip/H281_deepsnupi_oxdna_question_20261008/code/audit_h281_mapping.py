import json
import numpy as np
from scipy.io import loadmat
from scipy.spatial import cKDTree
from pathlib import Path
run=Path(__file__).resolve().parents[1]
mat=run/'data/snupi/H281_DGNN_INIT.mat'
d=loadmat(mat); x=d["init_coord"][:,:3]*0.1
pairs=np.array(json.loads(run/'data/hado/native_pairs.json'.read_text()),dtype=int)
dat=run/'data/hado/initial_design.dat'
lines=dat.read_text().splitlines(); arr=np.array([[float(v) for v in l.split()] for l in lines[3:]],dtype=float)[:,:9]
r=arr[:,:3]*0.8518
box=np.array([float(v) for v in lines[1].split('=')[1].split()])*0.8518
delta=r[pairs[:,1]]-r[pairs[:,0]]; delta-=box*np.round(delta/box); centers=r[pairs[:,0]]+delta/2
# Compare order-matched clouds under proper rigid transform: SNUPI nm -> HADO oxDNA nm
xc=x-x.mean(0); yc=centers-centers.mean(0); u,s,vt=np.linalg.svd(xc.T@yc); fix=np.eye(3); fix[-1,-1]=np.linalg.det(u@vt); rot=u@fix@vt; xa=xc@rot+centers.mean(0)
orderr=np.linalg.norm(xa-centers,axis=1)
# Unordered nearest distance after centering/rigid alignment
nearest,idx=cKDTree(centers).query(xa,k=1)
unique=len(np.unique(idx))
print('x range',x.min(0),x.max(0),'centers range',centers.min(0),centers.max(0),'box nm',box)
print('ordered RMSE/max',np.sqrt(np.mean(orderr**2)),orderr.max(),'direct index fraction <0.05nm',np.mean(orderr<.05))
print('unordered nn median/p95/max',np.median(nearest),np.percentile(nearest,95),nearest.max(),'unique targets',unique,'of',len(pairs),'close <.05',np.mean(nearest<.05))
print('det',np.linalg.det(rot))
summary={
 'candidate_input_coordinate_scale':0.1,
 'coordinate_units_unverified':True,
 'ordered_after_rigid_alignment_rmse':float(np.sqrt(np.mean(orderr**2))),
 'ordered_after_rigid_alignment_max':float(orderr.max()),
 'ordered_fraction_within_0_05_nm':float(np.mean(orderr<0.05)),
 'unordered_nearest_median':float(np.median(nearest)),
 'unordered_nearest_p95':float(np.percentile(nearest,95)),
 'unordered_unique_hado_pair_targets':int(unique),
 'total_hado_pairs':int(len(pairs)),
 'mapping_verified':False,
 'decision':'do_not_transfer_prediction_to_oxdna_without_identity mapping'
}
(run/'results/mapping_audit.json').write_text(json.dumps(summary,indent=2)+'\n')
