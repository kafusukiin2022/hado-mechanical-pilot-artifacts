import sys, types, json, time
from pathlib import Path
import numpy as np, torch
package=Path(__file__).resolve().parents[1]
root=Path(__file__).resolve().parent/'DeepSNUPI'
run=package
mat=run/'data/snupi/H281_DGNN_INIT.mat'
pkg=types.ModuleType('src'); pkg.__path__=[str(root/'src')]; sys.modules['src']=pkg
from src import model as model_module, utils as utils_module
from src.utils import get_input
from src.predict import get_model_prediction
from torch_cluster import radius_graph
model_module.radius_graph=radius_graph
utils_module.radius_graph=radius_graph
torch.set_num_threads(4)
device='cuda' if torch.cuda.is_available() else 'cpu'
g=get_input(str(mat))
assert g.x.shape==(5746,8) and g.edge_attr.shape==(12080,36)
start=time.perf_counter()
y,_,best,reported=get_model_prediction(g,user_input=True,device=device)
elapsed=time.perf_counter()-start
arr=y.detach().cpu().numpy()
np.save(run/'results/deepsnupi_prediction.npy',arr)
meta={'sample':'H281','input_mat':str(mat.relative_to(run)),'model':'official DeepSNUPI seven-weight selection','selected_model':best,'device':device,'nodes':int(g.num_nodes),'directed_edges':int(g.edge_index.shape[1]),'node_features':int(g.x.shape[1]),'edge_features':int(g.edge_attr.shape[1]),'elapsed_seconds':elapsed,'reported_seconds':float(reported),'prediction_shape':list(arr.shape),'finite':bool(np.isfinite(arr).all()),'source_mat_sha256':__import__('hashlib').sha256(mat.read_bytes()).hexdigest()}
(run/'results/prediction_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
