# H281 DeepSNUPI → oxDNA 复现记录

状态：DeepSNUPI 预测已完成；预测节点到 HADO 核苷酸配对的映射尚未验证，因此尚未把预测写入 oxDNA，也没有启动 equilibrium 或 production。

## 已完成

- 设计来源：`HADO_H101-H500_20261007/designs/HADO_200_v1/designs/H281/`，H281，双层片状空间框，5,746 个目标碱基对、11,864 nt。
- 在本目录复制了 caDNAno JSON，并将 HADO 的 staples CSV 转成 SNUPI 3.10 所需的 `Start,End,Sequence,Length,Color` 列；仅放入 141 条 staple，不包含 scaffold 行。序列总长 5,932 nt，与 scaffold 的 5,932 nt 相符。
- SNUPI 使用本地 MATLAB Runtime R2022b，在 `DO_STT=0`、`DO_DYN=0`、`GEN_INIT_DGNN=1` 下生成 `OUTPUT/H281_[261008_184749]/H281_DGNN_INIT.mat`。之前的序列格式校验失败日志也保留在 `logs/snupi_preprocess.log` 和 `OUTPUT/` 中。
- MAT 输入经 DeepSNUPI 官方 `get_input()` 读取：`init_coord=(5746,8)`、`elem_conn=(2,12080)`、`prop=(12080,36)`，数值有限、边索引范围有效、正反向边成对。
- 使用本地 DeepSNUPI 官方环境（Python 3.9.22、PyTorch 2.0.0+cu117、PyG 2.3.1、torch-cluster 1.6.3+pt20cu117）及七组官方权重执行 `get_model_prediction(..., user_input=True, device="cuda")`。选择结果为 `pre_train`，输出 `(5746,6)` 且全为有限值，耗时 20.29 s。文件：`deepsnupi_prediction.npy`、`prediction_metadata.json`。

## oxDNA 前置阻塞

DeepSNUPI 预测是 5,746 个配对节点的六自由度几何；oxDNA 拓扑则是 11,864 个核苷酸。SNUPI 的 DGNN MAT 没有导出节点到原始核苷酸配对的索引表。虽然节点数恰好与 `native_pairs.json` 条目数相同，**不能因此假定行序相同**。

一次探索性坐标审计（暂按 MAT 坐标乘 0.1 作为候选长度换算，单位仍未确认）没有得到可用映射：按序号刚体对齐 RMS 误差为 34.47 nm；最近 HADO 配对中心的距离中位数为 9.90 nm，且 5,746 个点仅命中 105 个唯一目标。该审计并不意味着换算因子 0.1 正确，只用于证明当前不能据此建立身份映射。数值见 `mapping_audit.json`。未经验证地按行号覆盖 HADO 坐标会把预测施加到错误的碱基对，故没有生成预测版 `.dat`、没有运行预测结构的最小化/平衡，更没有 production。

下一步需从 SNUPI 导出环节恢复节点身份（例如每个节点对应的 caDNAno helix/offset 或两枚 nt ID），再和 HADO 的 `nucleotide_map.json`/`native_pairs.json` 做逐节点拓扑核对。映射通过后，保留 HADO `.top`，按配对节点位置与朝向更新核苷酸几何，并先检查方向、碱基对、骨架连接和标准 FENE 定义域；只有标准力场几何检查通过后才可继续 equilibrium。

## equilibrium 与 production 计划

项目已有 `config/simulation.json` 和 `scripts/adaptive_equilibration.py`。其当前 equilibrium 操作筛查要求每块 10 个等步长能量窗口的 CV、极差和前后四分位漂移都低于 1%，连续 3 块通过；它只是势能稳定性筛查，不证明全局热力学平衡。已有配置为 CUDA、DNA2、300 K、0.5 M、每 chunk 1,000,000 步，standard MD 使用未封顶势能。H281 现有 HADO 初始化准备记录属于另一次非 DeepSNUPI 流程，不能冒充预测结构的 equilibration。

只有预测结构使用标准 oxDNA2 势能连续通过稳定性筛查后，才启动独立标记的 production chunks，并沿用项目的 checkpoint、thermo、氢键及轨迹审计。production 起点和 equilibrium 末帧哈希应记录在结果元数据中。

## 复现命令

在 DeepSNUPI 仓库运行官方推理脚本：

```bash
cd ../DeepSNUPI
.venv/bin/python ../hado_mechanical_pilot/runs/deepsnupi_H281_reproduction_20261008/run_h281_deepsnupi.py
```

脚本路径按当前同级目录布局书写；若目录布局变化，调整脚本顶部的绝对路径。SNUPI 独立预处理命令见项目 `../snupi/scripts/run-snupi.sh`，本次配置和日志保存在本目录。
