# H281 DeepSNUPI→oxDNA 映射问题包

本包包含一个可独立转交的问题样本：H281 的原始设计、HADO/oxDNA 拓扑及映射数据、SNUPI 产生的 DeepSNUPI MAT 输入、官方 DeepSNUPI 预测输出、实际使用的模型权重、必要模型源码、运行日志、复现脚本和形式化问题说明。

## 目录

- `QUESTION_mapping_zh.md`：可直接发给其他研究者/模型的问题陈述。
- `data/hado/`：HADO 设计、caDNAno 输入、序列、配对表、核苷酸映射、oxDNA `.top` 与初始 `.dat`。
- `data/snupi/`：SNUPI 输入 JSON/CSV/SNP 和生成的 DGNN MAT。
- `code/DeepSNUPI/`：官方预测所需源码及本次所选 `pre_train` 权重。
- `code/run_h281_deepsnupi.py`：可重放预测的脚本。
- `code/audit_h281_mapping.py`、`results/mapping_audit.json`：当前失败的候选几何审计；不代表映射结果。
- `results/deepsnupi_prediction.npy`：实际预测的 5746×6 数组。
- `REPRODUCTION_STATUS_zh.md`：本次流程和阻塞状态记录。
- `logs/`：SNUPI 运行日志。

## 已完成与未完成

SNUPI 3.10 生成 MAT 输入；DeepSNUPI 官方七权重选择流程使用本包 `pre_train` 权重完成预测，选择 `pre_train` 模型。节点身份映射尚未恢复，因此尚未把预测写回 oxDNA，也没有用预测结构运行 equilibrium 或 production。完整说明见 `REPRODUCTION_STATUS_zh.md`。

## 复现 DeepSNUPI 推理

环境：Python 3.9、PyTorch 2.0.0+cu117、PyG 2.3.1、torch-cluster 1.6.3+pt20cu117、roma 1.3.2、SciPy、mat73。进入 `code/DeepSNUPI`，安装项目相应依赖，然后运行：

```bash
python ../run_h281_deepsnupi.py
```

推理脚本读取 `data/snupi/H281_DGNN_INIT.mat`，并将预测写入 `results/`。SNUPI 的 MATLAB Runtime 和可执行文件没有包含在包中；已经生成的 `.mat` 输入已包含，故重放 DeepSNUPI 推理不需要再次执行 SNUPI。
