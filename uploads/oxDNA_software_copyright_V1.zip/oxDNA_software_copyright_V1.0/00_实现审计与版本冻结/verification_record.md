# 验证记录

- 记录日期：2026-10-12
- CodeGraph：425 files、6,685 nodes、15,597 edges，索引 up to date。
- `scripts/ebd_oxdna_shared_rigid_predict.py --help`：通过。
- `scripts/ebd_oxdna_shared_rigid_train.py --help`：通过。
- `python -m unittest tests.test_ebd_oxdna_shared_rigid_predict -v`：25 tests，全部 OK。
- 实际推理：固定 `model_best.pt` + `inference_bundle.json` + manifest 第一个样本，CPU 完成，输出 5,944 个核苷酸记录；详情见 `04_运行证据/prediction.json`。
- 实际输出：`prediction.conf`，格式为 3 行头部 + 5,944 行、每行 15 个数值列。
- 结果限制：记录中有 4 条 box 越界 warning；它们没有被隐藏，不能把样例写成无警告的物理有效性证明。
- 验证未覆盖：官方软著系统上传、申请人/著作权人身份、oxView 特定版本兼容性、独立测试集泛化。
