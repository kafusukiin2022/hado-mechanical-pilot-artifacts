#!/usr/bin/env python3
"""Independent, limited checks for this caDNAno honeycomb candidate.

This is not SNUPI and does not implement or reproduce SNUPI's internal
validation, initialization, partition/relocation, or mechanical analysis.
It uses Python's standard library only.
"""
import collections
import hashlib
import json
from pathlib import Path
import sys

PATH = Path(__file__).parent / "Icosahedron_Candidate" / "Icosahedron.json"
EXPECTED_SHA256 = "84c6a8da9c2b1e5e29898abf2929a107af9ba88e016f514ee3fdc50756229992"
EMPTY = [-1, -1, -1, -1]
# Union of the published caDNAno2 low/high positions, indexed by the three
# honeycomb neighbor directions. These are only checks on paired, same-index
# crossovers, not a test of every feature SNUPI might support.
PERMITTED = {
    "scaf": [{1, 2, 11, 12}, {8, 9, 18, 19}, {4, 5, 15, 16}],
    "stap": [{6, 7}, {13, 14}, {0, 20}],
}


def fail(message):
    raise ValueError(message)


def main():
    blob = PATH.read_bytes()
    digest = hashlib.sha256(blob).hexdigest()
    if digest != EXPECTED_SHA256:
        fail(f"unexpected SHA-256: {digest}")
    design = json.loads(blob)
    helices = design["vstrands"]
    by_num = {v["num"]: v for v in helices}
    if len(by_num) != len(helices):
        fail("duplicate helix numbers")
    coords = [(v["row"], v["col"]) for v in helices]
    if len(coords) != len(set(coords)):
        fail("duplicate helix coordinates")
    for v in helices:
        if (v["num"] - v["row"] - v["col"]) % 2:
            fail(f"helix number/coordinate parity mismatch: {v['num']}")
        lengths = {len(v[k]) for k in ("scaf", "stap", "skip", "loop")}
        if lengths != {168} or next(iter(lengths)) % 21:
            fail(f"unexpected honeycomb array lengths: {v['num']}: {lengths}")
        if any(v["skip"]) or any(v["loop"]):
            fail("unexpected insertion or deletion in this particular source")

    components = {}
    transition_counts = {}
    for kind in ("scaf", "stap"):
        nodes = {(n, i) for n, v in by_num.items()
                 for i, cell in enumerate(v[kind]) if cell != EMPTY}
        counts = collections.Counter()
        for n, i in nodes:
            v = by_num[n]
            cell = v[kind][i]
            if len(cell) != 4 or not all(isinstance(x, int) for x in cell):
                fail(f"invalid cell at {kind} {n}[{i}]")
            for offset, inverse in ((0, 2), (2, 0)):
                dest, index = cell[offset:offset + 2]
                if (dest == -1) != (index == -1):
                    fail(f"half-null link at {kind} {n}[{i}]")
                if dest == -1:
                    continue
                if dest not in by_num or not (0 <= index < 168):
                    fail(f"out-of-range link at {kind} {n}[{i}]")
                if by_num[dest][kind][index][inverse:inverse + 2] != [n, i]:
                    fail(f"non-reciprocal link at {kind} {n}[{i}]")

            dest, index = cell[2:4]
            if dest < 0 or dest == n:
                continue
            w = by_num[dest]
            r, c = v["row"], v["col"]
            if (r + c) % 2 == 0:
                neighbors = [(r, c + 1), (r - 1, c), (r, c - 1)]
            else:
                neighbors = [(r, c - 1), (r + 1, c), (r, c + 1)]
            target = (w["row"], w["col"])
            paired = all(x != EMPTY for x in (
                v["scaf"][i], v["stap"][i],
                w["scaf"][index], w["stap"][index]))
            if paired:
                counts["paired_transitions"] += 1
                if index != i or target not in neighbors:
                    fail(f"paired transition is not a same-index honeycomb neighbor: {kind} {n}[{i}]")
                direction = neighbors.index(target)
                if i % 21 not in PERMITTED[kind][direction]:
                    fail(f"paired crossover outside caDNAno2 position sets: {kind} {n}[{i}]")
            elif target in neighbors:
                counts["other_neighbor_transitions"] += 1
            else:
                counts["other_non_neighbor_transitions"] += 1

        remaining = set(nodes)
        result = []
        while remaining:
            todo = [next(iter(remaining))]
            found = set()
            while todo:
                key = todo.pop()
                if key in found:
                    continue
                found.add(key)
                remaining.discard(key)
                h, index = key
                cell = by_num[h][kind][index]
                for off in (0, 2):
                    nxt = tuple(cell[off:off + 2])
                    if nxt[0] >= 0:
                        todo.append(nxt)
            starts = sum(by_num[h][kind][index][0] == -1 for h, index in found)
            ends = sum(by_num[h][kind][index][2] == -1 for h, index in found)
            result.append((len(found), starts, ends))
        components[kind] = result
        transition_counts[kind] = counts

    print("Independent caDNAno honeycomb / crossover checks: PASS")
    print("Scope: source identity, JSON fields, unique coordinates/IDs, helix parity,")
    print("21-base period, references/reciprocity, and paired crossover positions.")
    print("This is NOT a SNUPI acceptance or convergence test.\n")
    print(f"SHA-256: {digest}")
    print(f"Helices: {len(helices)}; lattice: honeycomb; array length: 168")
    for kind in ("scaf", "stap"):
        sizes = collections.Counter(length for length, _, _ in components[kind])
        endpoints = collections.Counter((s, e) for _, s, e in components[kind])
        print(f"{kind}: {len(components[kind])} components; lengths: {dict(sorted(sizes.items()))}")
        print(f"{kind}: (5-prime, 3-prime) end counts per component: {dict(endpoints)}")
        print(f"{kind}: directed inter-helix links: {dict(transition_counts[kind])}")
    print("\nOther transitions have at least one unpaired endpoint; they are retained.")
    print("Their acceptability to SNUPI and physical interpretation are not proven here.")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, IndexError, OSError, json.JSONDecodeError) as exc:
        print(f"CHECK FAILED: {exc}", file=sys.stderr)
        sys.exit(1)
