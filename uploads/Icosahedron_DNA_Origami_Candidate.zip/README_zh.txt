正二十面体 DNA 折纸设计：研究候选包
==================================

重要：这是经过独立格式和局部交叉点检查的候选文件，不是已经通过 SNUPI
自身 lattice/crossover 检查的证明。没有安装或运行 SNUPI，也没有完成
SNUPI 初始构型生成、分区重定位或力学收敛计算。

文件
----
Icosahedron_Candidate/Icosahedron.json
    Douglas 实验室发布的 2009 年正二十面体原始设计，未改动任何字节。
    这是 caDNAno 传统 JSON 拓扑格式；以蜂窝晶格 H 读取。
Input_Template.txt
    根据 SNUPI v3.10 官方示例格式编写的输入行模板。
verify_design.py
    使用 Python 3 标准库运行的独立静态检查；不需要 SNUPI。
Validation_Report.txt
    上述静态检查的实际输出。

设计与论文证据
--------------
原始设计：
https://github.com/douglaslab/cadnano-designs/blob/main/2009nature/7_icosahedron.json
原始文件也由 caDNAno 官方画廊的 Nature 2009 源文件包提供：
https://cadnano.org/gallery/

Douglas 等，Nature 459, 414–418 (2009)，doi:10.1038/nature08016：
https://www.nature.com/articles/nature08016
论文报道由三种双三角形单元组装出约 100 nm 的线框正二十面体，并用
TEM 观察。论文也指出，多数 TEM 观察到的颗粒有缺失支柱，这可能与
折叠不完整或染色导致的塌陷有关，不能表述为所有实验颗粒均完美闭合。

Poppleton 等，Nucleic Acids Research 48, e72 (2020)，
doi:10.1093/nar/gkaa417：
https://doi.org/10.1093/nar/gkaa417
oxView 的公开示例明确指向该 2009 设计，并演示其从 caDNAno 平行螺旋
蓝图出发，经刚体重定位得到二十面体构型：
https://github.com/sulcgroup/oxdna-viewer/tree/master/examples/icosahedron

目前确认的是：上述原始设计有一篇明确的实验报道，以及后续对该设计的
模拟演示；不能因此声称同一个具体文件已被大量独立实验重复验证。

SNUPI 文献与官方输入说明
-----------------------
https://github.com/SSDL-SNU/SNUPI
https://doi.org/10.1021/acsnano.1c10347
SNUPI v3.10 的官方包提供蜂窝 H 与方格 S 的输入示例。静力示例 Ex1
只有 JSON 而没有同名 CSV；PDB 示例 Ex3 配有 CSV。官方默认选项中
DO_PAR_REL 为 1，用于线框或自由形状的分区和重定位。

2022 年 SNUPI 论文对 TALOS 产生的另一批线框设计（含二十面体）使用了
分区重定位并与 oxDNA 比较。这支持 SNUPI 处理同类结构的能力，但不证明
这里的 Douglas 2009 文件曾被 SNUPI 接受，也不证明本次运行会收敛。

已完成的检查
------------
1. 原始文件与 Douglas 实验室和 oxView 示例副本的 SHA-256 一致：
   84c6a8da9c2b1e5e29898abf2929a107af9ba88e016f514ee3fdc50756229992
2. scadnano 0.21.1 的 caDNAno v2 兼容导入器成功读入该原件：
   蜂窝晶格、180 条虚拟螺旋、3 条支架、576 条辅助链。
   这里验证的是兼容导入，不等于已用 caDNAno 桌面程序实测。
3. 独立脚本检查了每个拓扑引用的范围与前后双向一致性、螺旋编号与
   位置奇偶性、21 位蜂窝周期、螺旋坐标不重叠；这些限定检查通过。
4. 其中 162 个 scaffold 和 1080 个 staple 的双链端点连接，均符合
   caDNAno2 蜂窝邻格及对应方向的候选交叉位置集合。
5. 还有 234 个非邻格连接和 90 个邻格连接涉及至少一个未配对端点。
   它们保留在原始文件中；本检查不能认定这些连接在 SNUPI 中是否全部
   被接受，也不能证明最终三维形状或模拟会收敛。

转换注意事项
------------
原始文件已能由 caDNAno v2 兼容导入器读取，无须为了本包再导出。实测
scadnano 0.21.1 从该结构导出 caDNAno v2 时，分别改变了 48 个 scaffold
单元和 48 个 staple 单元，并造成重新导入错误；该导出结果没有收入本包。
请优先使用保持原始拓扑的 Icosahedron.json。

序列和使用方法
--------------
本包没有经过核实、逐条映射到该 JSON 的序列 CSV，因此没有编造 CSV。
JSON 可以作为依据官方静力示例尝试的候选拓扑，但是否适用于用户的 SNUPI
版本及三支架结构仍需实际检查；需要真实碱基序列的 PDB/序列相关分析
需另行提供正确匹配的 caDNAno 序列 CSV。

若已有 SNUPI，将 Icosahedron_Candidate 文件夹放到与 EXAMPLE 同一级，
再把 Input_Template.txt 中的 H 开头行添加到 SNUPI 自己的 Input.txt。
保留其官方默认的 DO_PAR_REL=1，并注意这是约 4.8 万核苷酸的较大结构。
这只是按官方样例准备的输入方式，不保证通过 SNUPI 或收敛。

运行本包自己的静态检查：
    python verify_design.py

以上文件名均为英文；说明采用 UTF-8 编码。
