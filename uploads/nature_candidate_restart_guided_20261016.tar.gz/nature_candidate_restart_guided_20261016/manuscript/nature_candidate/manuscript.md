# A physical-validity gap limits AI surrogates for DNA-origami preparation

## Summary

Predicting a prepared DNA-origami structure directly from a design would be valuable because conventional preparation uses molecular simulation to repair strained geometries and explore thermally accessible conformations. Here we show that a commonly used success criterion—coordinate error to one selected prepared endpoint—can be systematically separated from physical validity. Across a frozen family-held-out test set of 92 HADO designs, a hidden-state equivariant predictor reduced the mean aligned coordinate error from 8.566 to 7.491 oxDNA length units (a 12.54% reduction in the ratio of means; 89 of 92 designs improved). However, the preparation target was not unique: a bounded receipt audit found 105 qualified endpoints across 24 designs, with 22 designs producing at least two qualified endpoints and 19 producing five. The empirical centroid error across the latter was 7.540 oxDNA units, showing that endpoint variability is comparable to the residual error of the predictor. Most importantly, a predeclared physical-validation pilot tested 240 Initial/AI-projected structures from three routes and five projection budgets. None passed a 100-step standard DNA2 restart, whereas all 16 historical Prepared controls passed both 100- and 1,000-step checks. These results define a reproducible coordinate-to-physics validation gap and motivate a different objective: predicting a protocol-conditioned distribution of physically admissible states, with physical acceptance as a primary endpoint rather than a post hoc diagnostic.

## Main text

### A surrogate for preparation must predict a physical state, not only a coordinate label

DNA origami converts a prescribed sequence and scaffold–staple routing pattern into a three-dimensional object whose geometry is constrained by covalent connectivity, base pairing, excluded volume and thermal fluctuations. Molecular simulation packages such as oxDNA are therefore used to relax imported structures before downstream analysis or design iteration [1–3]. A direct predictor could reduce this cost, but only if its output can enter the same physical workflow as a prepared structure.

The distinction is consequential. A training set commonly stores one endpoint from a preparation campaign for each design. The resulting supervised problem is then written as a deterministic map from an Initial structure, x, to one Prepared target, y*. That representation silently assumes that y* is unique, that the stopping rule samples a reproducible state, and that a low coordinate loss implies a physically admissible configuration. We tested these assumptions using a locked HADO dataset of 400 designs, a family split of 228 training, 80 validation and 92 held-out test designs, and independent oxDNA receipts. We preregistered the decisive validation question as: can a model both improve the unchanged Initial baseline on the held-out designs and pass an independent DNA2 restart and geometry gate?

### The coordinate benchmark shows a real but limited improvement

The strongest coordinate result came from a hidden-state model evaluated on the unchanged 92-design test split. The aligned three-dimensional RMSD of the Initial structures was 8.5656 oxDNA units, compared with 7.4911 for the model outputs. The ratio of means corresponds to a 12.54% reduction; the mean paired reduction was 1.0745 units (10,000-resample bootstrap 95% confidence interval, 0.9560–1.1929). Eighty-nine of 92 designs improved (Fig. 1a,b). This is a reproducible prediction result under the specified alignment and split.

It does not establish physical validity. The test set is family-held out rather than fully shape-disjoint: the normalized-shape audit identified 100 shape classes among 400 designs, and one normalized class crossed the train/test boundary. The 92 test designs represented only three normalized shape classes, two of which were test-only. Thus the coordinate result supports improvement on the frozen benchmark, while broader claims about generalization to unseen shape families remain unproven.

### The target endpoint is a distribution under the preparation protocol

We next examined whether the stored Prepared target could be treated as a unique label. The original 400-design dataset retains one first-qualified endpoint per Initial. A bounded reconciliation of saved receipts expanded 24 designs across five planned seed offsets. Of 120 candidate design–offset combinations, 105 had qualified receipts. Twenty-two designs had at least two qualified endpoints, and 19 had all five. The endpoints were heterogeneous in both stopping stage and seed: 89 came from the first capped-MD stage, 10 from the second, one from the third and five from a capped-MC stage. None was certified as equilibrium or thermally eligible.

For the 19 designs with five qualified endpoints, we calculated two descriptive quantities in a common Initial frame. The half mean pairwise RMSD was 5.883 units (bootstrap 95% interval, 4.881–6.794). The empirical centroid—the optimal constant predictor for these finite aligned samples under squared coordinate loss—had a three-dimensional RMSD of 7.540 units (95% interval, 6.246–8.715) (Fig. 1c). This is not an irreducible population error and does not bound every learned conditional predictor. It does, however, establish that endpoint variability is large relative to the 1.075-unit mean improvement reported by the coordinate benchmark. A deterministic model trained against one selected endpoint is therefore being evaluated against one draw from a protocol-conditioned distribution.

### A geometry projection can reduce local strain without producing an admissible oxDNA state

To test whether a lightweight physical correction closes the gap, we ran a predeclared pilot on 16 train/validation designs that were not used for parameter selection. We compared unchanged Initial coordinates, hidden256 predictions and DGNN-lite predictions with an energy term. Each route was followed by a deterministic position-only projection with budgets of 0, 16, 32, 64 and 128 iterations. The projection adjusted backbone-site distances and applied a soft site-level repulsion; it did not run a long Preparation stage. Static checks and standard DNA2 restarts were recorded separately.

At the largest budget, static backbone geometry passed for four of 16 Initial projections, two of 16 hidden256 projections and four of 16 DGNN-lite projections. Static screening was not sufficient: none of the 240 AI/Initial structures passed the 100-step DNA2 restart, and therefore none entered the 1,000-step stage. The historical Prepared controls passed both stages for all 16 designs. The static center-clash screen was also route-dependent: at budget 128 the mean counts were 598 for Initial, 9,551 for hidden256 and 1,147 for DGNN-lite. These are diagnostic counts rather than complete oxDNA energies, but they expose why local bond repair cannot substitute for a physical restart.

The pilot provides the decisive separation between geometric and physical criteria. It does not prove that every possible architecture, force-based projection or generative model must fail. It does show that the tested deterministic endpoint-plus-projection strategy cannot be considered a drop-in replacement for Preparation, even when its coordinate benchmark improves.

### The proper target is protocol-conditioned physical uncertainty

Taken together, the evidence supports a change in problem formulation. A Prepared structure should be represented as a protocol-conditioned distribution, p(y | x, protocol), or as a set of candidate states accompanied by calibrated physical-acceptance probabilities. The training target must retain seed, stopping stage, protocol hash and qualification status. Evaluation should be hierarchical: first coordinate fidelity on an untouched test split, then independent checks of backbone, base-pair and crossover geometry, non-bonded clashes, energy stability and restart success. Claims of speedup should be made only after a non-zero fraction of outputs passes the same physical gate as the reference workflow.

This framing also clarifies what the present experiments do and do not establish. They disprove the sufficiency of a single coordinate RMSE as a deployment criterion for the tested route. They do not disprove learned sampling, conditional diffusion, force-matching or active correction methods that explicitly model multiple physical states. Such methods are the appropriate next test, and their first endpoint should be physical acceptance on a shape-disjoint evaluation set rather than a lower training loss.

## Discussion

Our results identify a failure mode that is easy to miss in structure-prediction benchmarks: the reference itself may be a selected transient endpoint, while the evaluator treats it as a unique physical truth. In this setting, improving the distance to that endpoint can coexist with worse local geometry and complete failure under the simulator that defines the scientific task. The effect is not a matter of statistical significance alone. It is a mismatch between the prediction target and the operational meaning of the object being predicted.

Several limitations define the scope of the conclusions. The endpoint-variation audit covers 24 designs selected by a saved manifest rather than a random sample of all 400 designs. The physical pilot covers 16 train/validation designs and was stopped under a predeclared rule; it is not an estimate of the 92-design test success rate. The short projection omits connected-image unwrapping and explicit base-pair orientation constraints, so its failure cannot be generalized to every conceivable geometry repair. Conversely, the historical Prepared controls are protocol-generated endpoints rather than a proof of global equilibrium. An independent ten-design thermodynamic audit found operational stationarity but strict equilibrium evidence for 0 of 10 designs: each had one trajectory, no independent replicas and no kinetic-temperature series.

These limitations strengthen rather than weaken the methodological conclusion. They make clear which claims are supported now and which experiment would change the decision. A successful successor would need multiple qualified endpoints per design, independent replicas, a shape-disjoint test split, physical acceptance as a primary endpoint, and an apples-to-apples wall-clock comparison. Until then, a coordinate-only surrogate should be treated as a proposal generator, not as a Prepared-structure replacement.

## Methods

### Dataset and split

We used the HADO H101–H500 design collection and the frozen family split recorded in the project manifest: 228 train, 80 validation and 92 test designs. Coordinate metrics use the project’s established rigid-alignment convention and oxDNA simulation length units. The unchanged Initial structure is the baseline for every paired comparison.

### Paired coordinate analysis

For each test design, we read the saved Initial and hidden256 endpoint metrics. The paired reduction was defined as RMSDInitial − RMSDmodel. The percentage reported in the abstract is 100 × (mean RMSDInitial − mean RMSDmodel) / mean RMSDInitial; the bootstrap interval is for the mean paired reduction and uses 10,000 resamples with replacement and seed 20261016. The per-design percentage distribution is reported separately in the machine-readable results file.

### Endpoint reconciliation

We used the saved audit manifest and read-only receipt reconciliation. A receipt qualified only when design identity, Initial hash, Prepared hash, campaign protocol hash, seed offset, standard-potential initialization, connected unwrap and residual checks passed. No new molecular dynamics was launched for this analysis. The centroid RMSD is computed from the five aligned endpoints for each complete design; it is a finite-sample descriptive statistic, not a population lower bound.

### Physical-validation pilot

The pilot used 16 fixed train/validation designs and three routes: unchanged Initial, hidden256 and DGNN-lite with an energy term. Five deterministic projection budgets were evaluated. A standard DNA2 restart was accepted only when the process completed at the requested step, orientation and FENE geometry remained valid, thermodynamic values were finite, and energy limits were respected. The AI/Initial structures were tested for 100 steps; only accepted structures would continue to 1,000 steps. Historical Prepared controls were evaluated using the same restart checks.

### Statistical reporting

All primary sample sizes refer to designs or saved receipts as stated, not to nucleotide-level observations. Confidence intervals are deterministic non-parametric bootstrap intervals over the design unit. No multiple-comparison claim is made, because the analyses were intended as a validation audit rather than a confirmatory treatment comparison. Source data, exact protocols, hashes, failure classes and three-dimensional viewers are archived with the manuscript package.

## Data availability

All quantitative source tables, receipt ledgers, protocol files, failure records and interactive structure/trajectory viewers are included in the accompanying project archive. The manuscript package links each claim to its source artifact and preserves the distinction between tracked evidence, untracked checkpoints and incomplete runs.

## Code availability

Analysis scripts for the paired bootstrap synthesis and Figure 1 are included in `analysis/nature_direction_20261016/`. The oxDNA binary, model checkpoints and cached design inputs are identified by SHA-256 in the experiment protocols; large checkpoints and trajectories are retained in their original locations and are not silently regenerated.

## Reporting summary

Further information on research design is available in the linked protocol and evidence index. The study is computational. No biological specimens or human participants were used.

## Main figure legend

**Figure 1 | Coordinate accuracy and physical acceptability separate in Initial-to-Prepared prediction.** a, Matched 92-design family-held-out test comparison between unchanged Initial and hidden256 outputs. Each point is one design; the dashed line is equality. b, Per-design paired RMSD reductions, ordered by reduction. The black point and interval show the mean and a deterministic 10,000-resample bootstrap 95% interval. c, Endpoint ambiguity across 19 designs with five qualified Prepared receipts. Each point is one design; centroid RMSD is the finite-sample error of the best constant predictor in the common-Initial frame. d, At projection budget 128, static backbone FENE acceptance and standard 100-step oxDNA2 restart acceptance for 16-design pilot routes. Prepared denotes historical endpoints, not a model output. Error intervals in b are bootstrap intervals over designs; no interval is implied for the descriptive structural counts. Source data: `analysis/nature_direction_20261016/figure_data.csv` and `results.json`.

## References

1. Rothemund, P. W. K. Folding DNA to create nanoscale shapes and patterns. *Nature* **440**, 297–302 (2006). https://doi.org/10.1038/nature04586
2. Douglas, S. M. et al. Rapid prototyping of 3D DNA-origami structures for molecular biology. *Nature* **459**, 414–418 (2009). https://doi.org/10.1038/nature08016
3. Ouldridge, T. E., Louis, A. A. & Doye, J. P. K. Structural, mechanical, and thermodynamic properties of a coarse-grained DNA model. *J. Chem. Phys.* **139**, 124905 (2013). https://doi.org/10.1063/1.3552946
4. Doye, J. P. K. et al. Coarse-grained modelling of DNA origami structures. *arXiv* 2004.05052 (2020). https://arxiv.org/abs/2004.05052
5. Fu, D. et al. Automated design of 3D DNA origami with non-rasterized 2D curvature. *Sci. Adv.* **8**, eade4455 (2022). https://doi.org/10.1126/sciadv.ade4455
