# Nature candidate manuscript package

Title: **A physical-validity gap limits AI surrogates for DNA-origami preparation**

This package contains the manuscript in Markdown and LaTeX, a compiled PDF, the main figure in PDF/SVG/TIFF form, the plotting source, and the locked analysis outputs. The paper is deliberately framed as a methodological and reproducibility result: it demonstrates that endpoint coordinate accuracy is insufficient to establish physical acceptability for the tested Initial-to-Prepared surrogate.

## Files

- `manuscript.md`: source manuscript with full Methods, limitations, data/code statements and references.
- `manuscript.tex`: compile-ready LaTeX source.
- `build/manuscript.pdf`: compiled manuscript.
- `figure1_coordinate_physics.pdf`: editable-vector main figure used in the manuscript.
- `analysis/nature_direction_20261016/figure_main.py`: reproducible Python plotting source.
- `analysis/nature_direction_20261016/results.json`: exact statistical synthesis and bootstrap settings.
- `analysis/nature_direction_20261016/experiment_protocol.json`: analysis protocol, decision rule and source hashes.
- `analysis/nature_direction_20261016/figure_data.csv`: panel-level source data.
- `harness/07_final_report/evidence_index.html`: linked evidence index for the complete experiment inventory.

## Scientific status

The paper is a candidate manuscript, not a claim of guaranteed acceptance by Nature. The strongest supported result is a validation principle: on the locked benchmark, a 12.54% ratio-of-means coordinate improvement coexists with 0/240 AI/Initial structures passing the independent 100-step DNA2 restart, while 16/16 Prepared controls pass. Endpoint uniqueness and strict equilibrium are not assumed; the manuscript reports their measured limits.

## Reproducibility

The statistical synthesis reads only saved receipts and tables. It launches no new MD, no new training and no GPU job. The paired bootstrap uses 10,000 resamples with seed 20261016. Figure source validation and PDF glyph audit pass with no FAIL findings; the compiled PDF was produced with Tectonic.
