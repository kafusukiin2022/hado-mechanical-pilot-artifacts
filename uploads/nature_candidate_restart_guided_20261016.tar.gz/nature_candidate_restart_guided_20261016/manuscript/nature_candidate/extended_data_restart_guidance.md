# Extended Data note: restart-guided learning does not reduce the gate automatically

The oxDNA2 source audit identified the strict initial failure gate as the DNA2
backbone-site FENE interval: `r0 = 0.7564` and `|r-r0| < 0.25`. The relevant
implementation is `vendor/oxDNA/src/Interactions/DNAInteraction.cpp`, where
`check_input_sanity()` rejects an invalid bonded distance before dynamics and
`_backbone()` throws the same error during force evaluation. The same source
implements bonded and non-bonded typed excluded-volume interactions at the
backbone and base sites.

We reproduced these site positions and cutoffs in a finite PyTorch surrogate.
On three existing hidden256 predictions, 1,000 steps of output refinement
reduced total typed site overlap from 5,932.5 to 48.6, but increased FENE
outliers from 10,448 to 11,619; all six standard 100-step DNA2 restarts failed.
The result demonstrates that a differentiable physical penalty supplies a
useful signal but does not make a weighted-sum objective equivalent to the
simulator's ordered constrained acceptance problem.

A three-epoch parameter fine-tuning micro-pilot reduced mean coordinate loss
from 5.945 to 5.776 while changing the per-design FENE outlier counts from
3,678/3,419/3,351 to 3,503/3,903/3,331 (H101/H102/H103). This exploratory
result is reported as a method-development negative result and is excluded
from the primary benchmark.

The appropriate successor is a curriculum with differentiable FENE projection,
dynamic typed neighbor lists, orientation/stacking terms and a real oxDNA
restart as the independent primary endpoint.
