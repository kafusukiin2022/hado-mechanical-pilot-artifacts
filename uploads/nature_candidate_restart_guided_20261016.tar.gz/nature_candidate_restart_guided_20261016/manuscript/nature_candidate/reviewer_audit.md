# Independent reviewer audit

Date: 2026-10-16

## Numerical and traceability checks

- The 92-design coordinate means (8.5656146796 and 7.4910855837), paired reduction (1.0745290958), 89/92 improved count, and endpoint statistics match `analysis/nature_direction_20261016/results.json` and the locked CSV receipts.
- The reported 12.54% value is explicitly the ratio-of-means improvement: `(8.5656146796 - 7.4910855837) / 8.5656146796`. The machine-readable results also retain the distinct mean paired percentage (12.2658%).
- Figure 1 and the results file use the same deterministic 10,000-resample bootstrap convention and seed 20261016.
- The endpoint audit reports 105 qualified receipts, 22 designs with at least two endpoints, 19 designs with five endpoints, centroid RMSD 7.5397, and half mean pairwise RMSD 5.8829.
- The physical pilot reports 240 AI/Initial records, 0/240 100-step DNA2 passes, and 16/16 Prepared-control passes at both 100 and 1,000 steps.
- Reference 3 DOI was corrected to `10.1063/1.3552946`; Crossref resolves the title and publication metadata. References 1, 2 and 5 resolve through DOI/Crossref; reference 4 is linked to its arXiv record.

## Major concerns and disposition

1. **Generalisation.** The split is family-held-out, not fully shape-disjoint. The manuscript states this limitation and avoids universal claims.
2. **Endpoint sampling.** The 24-design receipt audit is manifest-selected. This is reported explicitly and the centroid statistic is labelled descriptive rather than irreducible error.
3. **Physical pilot scope.** The pilot has 16 designs and is not used to estimate the 92-design test success rate. This limitation is stated.
4. **Prepared controls.** Passing restart checks is not treated as proof of equilibrium. The independent ten-design audit and its zero strict-equilibrium result are reported.
5. **Method coverage.** Failure of the tested deterministic endpoint-plus-projection route is not generalized to diffusion, force-matching or other learned samplers. The conclusion is scoped accordingly.
6. **Causal or speed claims.** No speedup or causal biological claim is made; an apples-to-apples timing study is identified as future work.

## Minor concerns

- The current manuscript is a Nature-style research article candidate, not a guarantee of editorial acceptance.
- The oxDNA units are project simulation length units; they are not presented as nanometres.
- The manuscript package contains the principal figure and machine-readable source data; large checkpoints and trajectories remain in the project archive referenced by the protocol files.

## Final audit decision

No unresolved numerical contradiction or unsupported universal claim was found after the corrections above. The central conclusion is appropriately limited to the tested deterministic endpoint-prediction and projection workflow.
