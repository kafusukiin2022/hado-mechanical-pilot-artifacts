# Cover letter (draft)

Dear Editors,

We submit “A physical-validity gap limits AI surrogates for DNA-origami preparation” for consideration as a Research Article. The work addresses a practical problem in computational nanotechnology: whether a model that improves coordinate RMSD to a stored prepared structure can replace the physical preparation workflow used to generate that structure.

Across a frozen 92-design test set, a hidden-state predictor reduced aligned RMSD by 12.54% in the ratio of means, with 89 of 92 designs improving. Independent receipt reconciliation then showed that the preparation endpoint is protocol-conditioned and variable: 105 qualified endpoints were recovered across 24 designs, and 19 designs had five qualified endpoints. In a predeclared physical pilot, none of 240 Initial/AI-projected structures passed a 100-step standard DNA2 restart, whereas all 16 historical Prepared controls passed both 100- and 1,000-step checks. The result is a reproducible separation between coordinate accuracy and physical acceptability.

The manuscript does not claim that learned physical sampling is impossible. It establishes a validation requirement: AI surrogates for preparation should be evaluated against a protocol-conditioned distribution and an independent physical acceptance endpoint, rather than a single deterministic coordinate label. The source data, protocols, failure records and analysis code are archived with the manuscript package.

This is a computational study with no human or animal subjects and no competing biological intervention. We believe the methodological issue is relevant to DNA nanotechnology, molecular simulation and machine-learning-assisted scientific inference.

Sincerely,

The authors
