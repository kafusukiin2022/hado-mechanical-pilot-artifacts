# Nature candidate plus oxDNA restart-guided learning package

This archive contains the manuscript candidate, source data, evidence reports,
oxDNA source audit, differentiable DNA2 restart surrogate loss, refinement pilot,
and parameter fine-tuning micro-pilot.

The full trajectory viewer is excluded because it is approximately 705 MB and
exceeds GitHub's single-file limit. It remains in the project workspace.
