# oxDNA restart-guided learning pilot

## Question

Can the yes/no restart result be converted into a gradient that teaches the
predictor to produce structures accepted by standard oxDNA2?

## Source reconstruction

The relevant oxDNA2 code was inspected in the vendored source tree.

- `vendor/oxDNA/src/Interactions/DNAInteraction.cpp:415-462` computes the
  backbone interaction and throws when `abs(r-r0) >= FENE_DELTA`.
- `vendor/oxDNA/src/Interactions/DNAInteraction.cpp:1471-1490` performs the
  initial strict bonded-neighbour sanity check before dynamics.
- `vendor/oxDNA/src/Interactions/DNAInteraction.cpp:468-525` applies bonded
  base/base, base/back and back/base excluded volume.
- `vendor/oxDNA/src/Interactions/DNAInteraction.cpp:707-770` applies the
  non-bonded base/base, mixed and back/back terms.
- `vendor/oxDNA/src/Interactions/DNAInteraction.cpp:1182-1204` defines the
  piecewise repulsive potential.
- `vendor/oxDNA/src/model.h:15-19,47-81` defines the DNA2 interaction-center
  constants, FENE range and site cutoffs.

The differentiable reconstruction is in
`ml_pilot/restart_guided_loss.py`. It uses the exact DNA2 backbone site

`back = x - 0.3400 a1 + 0.3408 (a3 × a1)`

and the DNA2 base site `base = x + 0.4 a1`, then supplies a finite soft barrier
for the strict FENE interval and typed site-overlap penalties. The C++ oxDNA
binary remains the acceptance oracle; the surrogate is not claimed to be an
exact differentiable simulator.

## Pilot design

Three existing hidden256 predictions (H101–H103) were used. For each, the
coordinates were optimized for 1,000 Adam steps with a trust-region term,
FENE admissibility penalty and typed site-overlap penalty. The original model
prediction was tested as the baseline. Both were written as legal oxDNA restart
files and run for 100 standard DNA2 steps with the same executable and protocol
as the earlier physical pilot.

## Observed result

| design | route | FENE outliers | site-overlap total | 100-step DNA2 |
|---|---:|---:|---:|---|
| H101 | baseline | 3,678 | 1,870.13 | fail, bonded 3–4, d=1.158695 |
| H101 | guided | 3,959 | 15.11 | fail, bonded 2–3, d=0.499761 |
| H102 | baseline | 3,419 | 1,940.66 | fail, bonded 1–2, d=0.405391 |
| H102 | guided | 3,872 | 14.73 | fail, bonded 3–4, d=1.570832 |
| H103 | baseline | 3,351 | 2,121.73 | fail, bonded 1–2, d=0.090050 |
| H103 | guided | 3,788 | 18.72 | fail, bonded 8–9, d=1.221272 |

The loss successfully reduced the typed site-overlap diagnostic by roughly two
orders of magnitude, but the simultaneous unconstrained optimization increased
FENE failures and produced zero physical passes. This is a useful negative
result: a scalar differentiable penalty is not automatically equivalent to the
ordered, constrained restart problem.

## Training integration

`ml_pilot/train_dgnn_lite_energy.py` now accepts
`--restart-guided-weight`. With `--restart-guided-weight 0.05`, the CUDA smoke
test completed with finite loss and gradients:

```text
smoke: passed
loss: 28.51738166809082
oxdna_energy: 375.2727355957031
restart_guided: 180.3502960205078
```

No full retraining was launched in this pilot. The implementation is ready for
a predeclared training comparison after the loss schedule is corrected.

## Parameter fine-tuning micro-pilot

To distinguish output optimization from learning, the existing hidden256
checkpoint was fine-tuned for three epochs on H101–H103 with coordinate loss
plus `0.02 × restart_guided_loss`. The mean coordinate loss decreased from
5.945 to 5.776, but the restart surrogate did not improve monotonically. The
per-design soft FENE outlier counts changed as follows:

| design | before | after |
|---|---:|---:|
| H101 | 3,678 | 3,503 |
| H102 | 3,419 | 3,903 |
| H103 | 3,351 | 3,331 |

This micro-pilot is not a success claim and was not used in the Nature main
benchmark. It shows that parameter gradients exist, but a naive global weight
does not reliably optimize the hard restart gate across designs. The complete
machine-readable record is `micro_finetune.json`.

## Interpretation and next experiment

The correct next method is a constrained curriculum, not a single weighted
sum: (i) differentiable FENE projection until every backbone edge is inside an
interior interval, (ii) typed bonded and non-bonded site repulsion with a
dynamic candidate list, (iii) orientation and stacking terms, and (iv) the
real oxDNA restart as an independent primary endpoint. The current pilot does
not justify claiming improved physical acceptance.
