"""Nature-style Figure 1 for the coordinate/physics consistency direction.
Data are locked project receipts; no simulated values are generated here.
"""
from pathlib import Path
import csv, json, math, random
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parent
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],'svg.fonttype':'none','pdf.fonttype':42,'font.size':7,'axes.spines.right':False,'axes.spines.top':False,'axes.linewidth':0.7,'xtick.major.width':0.7,'ytick.major.width':0.7})
def read(p): return list(csv.DictReader((ROOT/p).open()))
def mean(x): return sum(x)/len(x)
def boot(v,B=10000,seed=20261016):
 r=random.Random(seed); n=len(v); z=sorted(mean([v[r.randrange(n)] for _ in range(n)]) for _ in range(B)); return mean(v),z[int(.025*B)],z[int(.975*B)]
paired=read('harness/02_hidden256_initial_baseline/paired_test_metrics.csv')
init=[float(x['initial_3d_rmsd']) for x in paired]; model=[float(x['model_3d_rmsd']) for x in paired]; dif=[a-b for a,b in zip(init,model)]
amb=read('harness/05_prepared_seed_variance/p6_receipt_expansion_designs.csv'); amb=[x for x in amb if int(x['qualified_receipts'])==5]; cen=[float(x['empirical_centroid_3d_rmse']) for x in amb]; pair=[float(x['half_mean_pair_distance']) for x in amb]
pilot=read('analysis/ai_geometry_projection_20261015/design_level_results.csv'); routes=['B_initial','C_hidden256','D_dgnn_energy']; labels=['Initial + projection','hidden256 + projection','DGNN-lite + projection']; cols=['#4477AA','#CC6677','#117733']
fig=plt.figure(figsize=(7.2,5.5)); gs=fig.add_gridspec(2,2,wspace=.36,hspace=.42)
# a paired scatter
ax=fig.add_subplot(gs[0,0]); ax.scatter(init,model,s=12,c='#4477AA',alpha=.65,edgecolors='none'); lo=0; hi=max(init+model)*1.03; ax.plot([lo,hi],[lo,hi],color='#888888',lw=.8,ls='--'); ax.set(xlabel='Initial RMSD (oxDNA units)',ylabel='hidden256 RMSD (oxDNA units)',xlim=(0,hi),ylim=(0,hi)); ax.text(.04,.94,'89/92 improved',transform=ax.transAxes,fontweight='bold',color='#117733'); ax.text(-.17,1.04,'a',transform=ax.transAxes,fontweight='bold',fontsize=9)
# b paired reductions with CI
ax=fig.add_subplot(gs[0,1]); order=sorted(range(len(dif)),key=lambda i:dif[i]); vals=[dif[i] for i in order]; y=list(range(len(vals))); ax.axvline(0,color='#888',lw=.7); ax.scatter(vals,y,s=7,c=['#117733' if x>0 else '#CC6677' for x in vals]); ax.set(xlabel='Paired reduction in RMSD (oxDNA units)',ylabel='92 held-out designs',yticks=[]); ax.set_ylim(-2,len(vals)+1); m,lo,hi=boot(dif); ax.errorbar(m,-1.2,xerr=[[m-lo],[hi-m]],fmt='o',color='#222222',capsize=2,ms=3); ax.text(.04,.94,f'mean {m:.2f} [{lo:.2f}, {hi:.2f}]',transform=ax.transAxes,fontweight='bold'); ax.text(-.17,1.04,'b',transform=ax.transAxes,fontweight='bold',fontsize=9)
# c endpoint ambiguity
ax=fig.add_subplot(gs[1,0]); ax.scatter(pair,cen,s=16,c='#AA4499',alpha=.8,edgecolors='white',linewidth=.3); ax.axhline(mean(cen),color='#AA4499',lw=.8,ls='--'); ax.axvline(mean(pair),color='#AA4499',lw=.8,ls=':'); ax.set(xlabel='Half mean pairwise RMSD',ylabel='Centroid RMSD\n(oxDNA units)'); ax.text(.04,.94,'19 designs with 5 qualified endpoints',transform=ax.transAxes,fontweight='bold',fontsize=6.5); ax.text(-.17,1.04,'c',transform=ax.transAxes,fontweight='bold',fontsize=9)
# d physical acceptance
ax=fig.add_subplot(gs[1,1]); x=list(range(4)); static=[]; md=[]
for route in routes:
 rr=[r for r in pilot if r['route']==route and int(r['budget'])==128]; static.append(100*sum(r['standard_fene_geometry_passed'].lower()=='true' for r in rr)/len(rr)); md.append(100*sum(r.get('md_100_pass','').lower()=='true' for r in rr)/len(rr))
static.append(100); md.append(100); names=['Initial','hidden256','DGNN','Prepared']; xx=[i-.18 for i in x]; ax.bar(xx,static,.36,color='#BBD7C5',label='Static FENE gate'); ax.bar([i+.18 for i in x],md,.36,color='#117733',label='100-step DNA2 MD'); ax.set_xticks(x,names,rotation=25,rotation_mode='anchor',ha='right'); ax.set_ylabel('Accepted structures (%)'); ax.set_ylim(0,110); ax.legend(frameon=False,fontsize=6,loc='upper left'); ax.text(-.17,1.04,'d',transform=ax.transAxes,fontweight='bold',fontsize=9); ax.text(.05,.91,'0/48 AI routes pass MD',transform=ax.transAxes,fontweight='bold',fontsize=6.5)
fig.savefig(OUT/'figure1_coordinate_physics.svg',bbox_inches='tight'); fig.savefig(OUT/'figure1_coordinate_physics.pdf',bbox_inches='tight'); fig.savefig(OUT/'figure1_coordinate_physics.tiff',dpi=600,bbox_inches='tight'); plt.close(fig)
(OUT/'figure1_legend.txt').write_text('''Figure 1 | Coordinate accuracy and physical acceptability separate in Initial-to-Prepared prediction. a, Matched 92-design family-held-out test comparison between unchanged Initial and hidden256 outputs. Each point is one design; the dashed line is equality. b, Per-design paired RMSD reductions; points are ordered by reduction. The black point and interval show the mean and a deterministic 10,000-resample bootstrap 95% interval. c, Endpoint ambiguity across 19 designs with five qualified Prepared receipts. Each point is one design; centroid RMSD is the finite-sample error of the best constant predictor in the common-Initial frame. d, At projection budget 128, static backbone FENE acceptance and standard 100-step oxDNA2 restart acceptance for 16-design pilot routes. Prepared denotes historical endpoints, not a model output. Error intervals in b are bootstrap intervals over designs; no interval is implied for the descriptive structural counts. Source data: figure_data.csv and results.json.\n''')
