# HADO 实验、证据、数据与数据集总目录

更新时间：2026-10-14。范围是本仓库 `hado_mechanical_pilot` 中实际发现的 HADO 材料；大型轨迹、checkpoint 和缓存不复制到 Harness，只记录原路径、可读报告和状态。`已量化` 表示有可复核的指标文件；`只有过程证据` 表示找到代码、日志或配置，但没有足够的结果表；`未完成/无效` 不得当作正向结果。

## A. 共同数据、来源和切分

| 数据/证据 | 路径 | 内容与规模 |
|---|---|---|
| HADO 设计包 | `HADO_H101-H500_20261007/designs/` | H101–H500 共 400 个设计；每个设计的 `design.top`/`design.dat`、`prepared.dat`、`scaffold_route.json`、`native_pairs.json`，部分有 `nucleotide_map.json`、`geometry.json`。 |
| 400 设计端点清单 | `ml_pilot/results/initial_prepared_dataset_20261007.json` | Initial→Prepared 路径、SHA、设计元数据；每个设计一条 prepared endpoint。 |
| 家族切分 | `ml_pilot/results/onepass_family_split_20261007.json` | 228 train / 80 validation / 92 family-held-out test。所有同一测试比较应使用这个清单。 |
| one-pass cache | `ml_pilot/cache_onepass_20261007/` | 400 个 Hxxx NPZ；Initial/Prepared 坐标、旋转、节点特征、五类图边、显式 backbone/pair、标签。 |
| Preparation predictor 数据 | `HADO_prep_predictor/data/` | `prep_manifest.csv` 400 行；`prep_targets_features.csv` 400×47；baseline、family-holdout、GNN 消融和逐核苷酸位移表。 |
| 重复 preparation 证据 | `analysis/initial_prepared_suitability_20261008/results/`；`harness/05_prepared_seed_variance/p6_receipt_expansion_*` | 原六设计 pilot 18 行保留；新增按 audit manifest 24设计×5 offsets 核验，105/120 合格、15缺失；22设计有重复、19设计完整5次；197组配对距离。 |
| 400 设计身份/重建审计 | `analysis/initial_prepared_suitability_20261008/results/identity_audit.csv`, `audit_summary.json` | 400/400 identity 通过；source/target reconstruction error 为 0；400 个共同 receipt protocol hash；各 preparation stage 数量已记录。 |

## B. 六项高优先级问题的 Harness 结论

### B1. 一个 Initial 是否只有一个 Prepared？

- Harness：`harness/01_prepared_cardinality/README.md`。
- 结果：400-design 训练数据每个 Initial 只选一个 first-qualified Prepared；这不是物理唯一性证明。按 audit manifest 核验24设计×5 seed offsets，105/120收据合格、15缺失；22设计至少两个端点、19设计完整五个，否定这22设计的“唯一观测结果”。
- 数据：Harness05 的 `receipt_expansion_audit.py` 和 `p6_receipt_expansion_{endpoints,pairwise,designs}.csv`、`p6_receipt_expansion_summary.json`；原六设计18端点 pilot 保留。
- 边界：按实际文件/哈希/协议/标准势初始化/PBC展开核验，不按任务状态计数；15个候选仅缺少合格端点文件；105端点阶段89 MD1、10 MD2、1 MD3、5 MC，均未证明平衡或热标签准入。这是清单选择的24设计，不能外推400设计总体。

### B2. hidden256 比不改 Initial 好多少？

- Harness：`harness/02_hidden256_initial_baseline/README.md`。
- 数据/证据：`results/harness_hidden256_mp3/onepass_A_20261007_summary.json` 的同一 92 个 test design、`metrics.json`、`README.md`。
- 结果：Initial mean 8.56561；hidden256 7.49109；下降 1.07453，12.54%；89/92 个设计优于各自 Initial。该结果是配对坐标误差，不是物理有效性。后续形状核验发现 SHAPE031 跨 train/test，因此这是 family-held-out、但不是 fully shape-held-out 的结果。
- 相关一次前向消融：`ml_pilot/results/onepass_ablation_20261007/README.md`：A/B/C/D test RMSE 7.516/8.369/8.395/8.343，identity test 8.566；B–D 的物理项不等于无碰撞或可模拟证明。
- 形状分层：`shape_stratified_audit.py`、`shape_stratified_test_metrics.csv`、`shape_stratified_test_summary.json`。16个train共享形状设计改善12.02%；其余76个设计Initial 8.93951→model 7.81059，改善12.63%，73/76改善。但这76个设计只有2类测试专有顶点形状，属于事后描述性子集，不能当作76个独立新形状泛化样本。

### B3. 400 个设计是否为 400 种真实路由？

- Harness：`harness/03_routing_identity/README.md`。
- 数据/脚本：`canonical_routing_audit.py` 与 `connectivity_audit.py`；两组 400 行签名 CSV 和 JSON 汇总。后者使用冻结 `design.top` 与 `native_pairs.json`，不依赖缺失的 nucleotide maps。
- 结果：规范化 scaffold-route 400/400 唯一；基于有向 backbone 和 scaffold-to-staple native pairs 的完整拓扑 connectivity 也为 400/400 唯一，控制测试通过。仍不能排除共享生成模板或证明新设计泛化。
- 来源复核：`lineage_audit.py`、`generation_lineage.csv`、`generation_pairs.csv`、`generation_lineage_summary.json`。导出几何骨架图精确同构比较400/400不同，但只有124组保存的顶点坐标；337设计在61个重复坐标组中。extension的200设计是100组共享坐标、改变边连接的A/B干预对。配对及精确坐标组均不跨固定切分；不同拓扑不等于400个独立形状模板，也不能证明跨生成程序泛化。
- 旁证：200 个 geometry topology WL 字段中 194 个唯一，仍有重复组；不能把简化 core signature 当完整路由等价。
- 进一步形状复用审计：`shape_reuse_audit.py`、400行 `shape_reuse.csv` 与 `shape_reuse_summary.json`。按归一化完整距离图同构（允许刚体变换、镜像、统一缩放、顶点重编号，在所述数值容差内）得到100类形状；51个重复组包含351设计，最大46设计。2类跨切分：SHAPE056跨train/validation，SHAPE031跨train/test。因此测试集不能称为完全形状隔离；该比较忽略origami连接边，也不识别近似或非均匀模板变形。

### B4. 图边类型错误影响哪些历史结果？

- Harness：`harness/04_edge_type_blast_radius/README.md`。
- 已确认：旧 rigid Graph-Gaussian 的 32/64/128 scaling 和 32-design extension 受错误 adapter 影响，结果作废；修复提交 `410f2e3`。
- 新审计：`audit_cached_edges.py` 逐一读取 400 cache。显式 backbone=3,498,651（其中 crossover=50,150），native pair=1,711,339；每个设计的 code 1∪3、code 3、code 2 与显式数组完全匹配，缺失/额外/冲突均为 0。
- 尚存问题：`train_graph_flow_400.py` 的三类压缩实际为 0 spatial、1 backbone、2 native pair+crossover+skip；50,150 crossover 和 6,221,954 strand-skip 被合并到 2。它不是已确认的 rigid 错误，但语义压缩未被重新训练验证，历史 checkpoint 的 cache/adapter hash 也不全。
- 当前分支分类：one-pass/DGNN/global flow 使用五类或显式物理数组，未发现调用旧 rigid adapter；shared Fourier 不把 edge type 输入模型。由于旧 checkpoint 没有全部 provenance，不能声称所有历史结果已清除。

### B5. 不同随机种子的 Prepared 差异多大？

- Harness：`harness/05_prepared_seed_variance/README.md`。
- 数据：Harness05新增105合格端点、197组配对距离、24设计聚合和可复现审计脚本；原18端点pilot保留。`analysis/seed_variance/` 是独立的thermal RMSF任务。
- 结果：19个完整五端点设计的半平均pair distance均值5.883、median6.309，仅为描述性距离，**不是平方误差下界**。同一Initial对齐框架下，有限样本平方坐标误差最优常数预测是端点质心；逐设计3D RMSE均值7.540、median8.013，component RMSE均值4.353、median4.627。使用oxDNA长度单位，MSE为平方单位；质心与pairwise平方距离恒等式校验通过。
- 边界：有限样本质心误差不是模型的普适或总体不可约误差；停止阶段/步数不一致，stage和seed影响未分离。

### B6. 是否有模型既优于 Initial 又通过物理检查？

- Harness：`harness/06_physical_validation/README.md`。
- 结论：当前没有完整证据链。hidden256 有 12.54% 坐标改善但没有物理检查；corrected rigid H125 是训练内拟合；DGNN V2/V3 是 smoke 且仍有结构/clash问题；V4 没有 validation/test。
- 关闭条件：未改变 Initial baseline 的同一测试集、同一对齐，并将测试形状按规范化几何隔离；另报 backbone/base-pair/crossover、clash、energy 和 oxDNA restart/relaxation provenance。现有记录未同时满足。

## C. Initial→Prepared 模型实验清单

| 实验/目录 | 证据与数据 | 目前可下的结论 | Git 记录 |
|---|---|---|---|
| one-pass A–D | `ml_pilot/results/onepass_ablation_20261007/`、`README.md`、`ablation_summary.json` | 2026-10-07 A/B/C/D test RMSE=7.516/8.369/8.395/8.343；当前 `ablation_summary.json` 已只包含A，test=7.49108558、validation=7.04813988，与hidden256摘要一致。README历史A–D摘要与当前覆盖的JSON应分开看；撤回未核实的“7.48 rerun”数字，没有物理通过结论。 | `194f346` 后的 run artifacts |
| hidden256/mp3 + train-OS | `results/harness_hidden256_mp3/` | 92-test=7.49109，配对 Initial=8.56561 | `194f346`, `2eeb8b5` |
| DGNN-lite V0 / position-weighted / LR variants | `ml_pilot/results/dgnn_lite_full_20261009/summary.json`, `dgnn_lite_position_*/*summary.json` | 相同 228/80/92 split；测试 RMSE：baseline 7.601、lr3e-3/ori0.1 7.707、lr5e-4/ori0.1 7.531、position-weighted 7.738。均弱于 hidden256 7.491；后三者分别 31、76、1 epochs。 | `1fdda8a`, `04b546c`, `03604a2`, `c64588a` |
| DGNN-lite V1 delta+geometry | `ml_pilot/results/dgnn_lite_delta_supervised_20261009/`、实现 | 用户在 epoch 58 停止；delta 与 endpoint residual 代数等价，未形成新增信息 | `4b65e85` |
| DGNN force V2 | `ml_pilot/results/dgnn_force_v2_smoke_20261009/summary.json` | 16-design smoke endpoint 9.369→8.056；backbone MAE 0.222 vs Initial 0.081 oxDNA units，结构 gate 失败 | `2ddde45`, `e532389`, `4a1908d` |
| DGNN force V3 + XPBD | `ml_pilot/results/dgnn_force_v3_smoke_20261009/summary.json` | 16-design train smoke RMSE 8.047；backbone 0.106、pair 0.055 oxDNA units、mean clash 8,750；相对 V2 通过，绝对物理门未通过 | `4a1908d` |
| V4 segment/colored XPBD | `results/harness_dgnn_force_physics_20261009/README.md`、配置和 smoke 结果 | 早期 rigid_only 错误结果不可作严格结论；修正版只有 train-internal，未评 test | `06098be`, `410f2e3` |
| coarse-to-fine / segment probes | `ml_pilot/results/onepass_ablation_20261007/coarse_to_fine_*`, `v4_*_validation_80.json`, `segment_oracle_validation_20261008.json` | 单设计 fit：H101 3D RMSD 1.466、4-design fit 1.526；228-design graph2-equivalent validation 3D RMSD 13.357（fit 11.321）；16-design V4 rigid-fix fit 10.007，但 80-design validation 18.050 vs Initial 7.890，且 mean clash 44.84，故过拟合/结构门失败。segment oracle 仅为上限参照，不是可部署模型。 | 记录集中在 `194f346` 后的工作区产物；未单独形成完整 tracked commit |
| initial-only GraphFlow | `ml_pilot/results/initial_only_*`、`initial_only_summary.md` | H125/2/8/32 fixed RMSD 0.353/1.044/2.657/11.030；228 run 因约31.6GB预处理停止 | `63ff629`, `0814812` |
| 400-design GraphFlow hidden64x3 | `graph_flow_400_full_hidden64x3/endpoint_eval.json` | 400-design pooled mean RMSD 13.384；不是物理验证 | `98df1c8`, `1df0bb4` |
| 400-design GraphFlow hidden128/256、smoke/capacity | `graph_flow_400_*` | 训练/暂停日志和配置存在；本次没有统一可比 blind 指标 | `98df1c8` |
| global-conditioned flow | `global_flow_400/` | 有 partial/full rollout 和 strain 字段；未形成统一 test 物理结论 | `f44089a` |
| shared Fourier flow | `shared_fourier_400_cuda/` | test mean RMSD 13.1997；模型不接 edge type | `4c2c460`, `f44089a` |
| rigid corrected Graph-Gaussian | `results/rigid_corrected/`、H125 metrics、64 atlas | 旧结果作废；修正版 H125/64 仅 train/overfit，不可作泛化 | `410f2e3`, `5e0af8a`, `d052efe` |
| direction surrogate / iterative policy | `ml_pilot/*direction*`, `iterative_*` | 代码、训练/评估产物存在；当前没有纳入六项结论的统一盲测指标 | `5eb424c`, `e40ff2e` |
| PaiNN source-conditioned direct/energy/complete-graph | `painn_initial_to_prepared_retrained_direct(_rollout).json`, `painn_full_energy_*`, `painn_full_complete_graph_*` | 三个不同 validation 口径的 endpoint rollout 都优于各自 Initial baseline：5.75%（7.482 oxDNA units）、8.13%（7.308）、6.56%（7.210）；没有 backbone/clash/oxDNA restart 的独立物理验收，不能回答 B6 | 工作区产物；本次无对应 tracked commit |
| Iterative origami teacher/policy | `ml_pilot/results/iterative_origami_full_v1/teacher_report.json`, `best.json` | 228 train designs 的 mean RMSD 12.366→12.134（2.01%），teacher_success 187/228；平均 approximate nonbonded conflicts 53.3，碰撞定义不完整，不能作物理通过 | 工作区产物；本次无对应 tracked commit |
| DeepSNUPI scratch / GraphFlow SNUPI-258 | `deepsnupi_scratch_258_20261011/metrics.json`, `graphflow_snupi258_20261012/metrics.json` | 180/39/39 split；test mean 16.838 vs 16.133 nm。属于 H001–H258 的独立探索口径，不能与 HADO 400 的 92-test oxDNA-unit RMSE 直接比较 | 工作区产物；本次无对应 tracked commit |
| Local SE(3) pilot with/without energy edges | `initial_to_prepared_pilot.json`, `initial_to_prepared_energy_edge_pilot.json`, `initial_to_prepared_no_energy_matched_pilot.json` | 20/10/5 design pilots；最终 validation vectors记录在 JSON；文件自己标注 pilot endpoint regression、not validated generative model | 工作区产物；本次无对应 tracked commit |

## D. Preparation predictor 实验（400 设计）

- 入口：`HADO_prep_predictor/REPORT.md`、`ALL_OUTPUTS.md`、`REPRESENTATIVE_ANALYSIS.md`。
- 输入：17 个 Initial 设计级特征；目标 30 个 minimization/MC/capped-MD response；400 个完成 preparation 设计；5-fold GroupKFold，另做 family holdout。
- 设计级 baseline：min/relax 能量 R² 约 0.91；post-MC FENE 0.89；relax energy drop 0.87；MC repair 0.85；post-min FENE 0.84；RMSD_end 约 0.43；post-relax FENE 85%为0，几乎不可学习。
- GNN：392 个完整标签设计、12目标；Full R²：post-MC FENE .802、MC repair .775、post-min FENE .739、relax energy drop .791、RMSD_end .428、dRg .448；topology-only 明显较弱；min energy drop .016 为负结果。
- 逐核苷酸：878,006 条 relax 位移记录，R²=-.142、Spearman=.335。
- 边界：这些是固定 preparation 协议的响应预测，不是平衡自由能、PMF、RMSF 真值或自动修复。
- Git：`9592bc8`, `f8b3671`, `5e451d7`, `34325cb`, `b313d56`。

## E. 热/动力学与标签资格相关数据（不是六项端点模型结果）

| 实验 | 路径 | 证据状态 |
|---|---|---|
| 4 design × 3 seed RMSF | `analysis/seed_variance/`, `cross_seed_rmsf_distribution/`, `rmsf_distribution_convergence/`, `nucleotide_flexibility_difference/` | PASS_DESCRIPTIVE_ONLY；局部 RMSF 排名部分稳定，但 `thermal_training_eligible=false`、`train_mask=false`，不产生训练标签。 |
| Phase 0–2 staged validation | `analysis/staged_validation/`, `exploratory_dynamics_atlas_v2/` | 60 段文件/协议一致性证据；Phase 2 repair；Phase 3–6 stop，未证明平衡。 |
| Dataset feasibility A0–A4/B1–B4 | `analysis/dataset_feasibility/20261005_a0_a4_existing_data/` | 典型 P90−P10 约0.865 nm；只有22.8%位置达精度门；未完成家族留出预测，训练准入暂缓。 |
| 20×3 batch | `analysis/batch_20x3/20261005_20x3/` | blocked；生产完成0，new MD steps/frames=0；smoke 不计入训练数据。 |
| DNAXiS ripple chimney | `analysis/dnaxis_ripple_chimney_anchor_distance_20261012/` | 1000帧经验距离分布，均值59.540 nm；ESS约10，不能当平衡分布。 |


## G. 其余 HADO 文件夹与执行状态盘点

以下是 `analysis/`、`ml_pilot/results/`、`results/` 的一级实验目录清点；同一实验的图、日志与表留在各自目录，没有搬动大型数据。

| 目录/实验组 | 可核验产物 | 结论/当前状态 |
|---|---|---|
| `analysis/prep_100_20261006/` | 100 个设计 initial/prepared PCA 图、source CSV 和哈希 | 可视化证据；H014 周期重建残差警告；prepared 是短 preparation endpoint，不是平衡构象。 |
| `analysis/initial_prepared_suitability_20261008/` | 400 identity/reconstruction 审计；原18端点pilot；Harness05的105合格端点扩展 | 400端点身份通过；按清单24×5核验105合格、15缺失，22设计有重复、19完整五次。25条completed任务均对应合格收据；不能仅凭快照推导数据规模。 |
| `analysis/server_gpu_smoke/`, `server_gpu_smoke_pilot/`, `server_v2_pilot/`, `batch_20x3_smoke_nativeio/` | 各自 `summary.json` 与 dataset status | 分别为 1/1、1/1、4/4、1/1 provisional；qualified=0。smoke 不等同长时采样或训练标签。 |
| `analysis/exploratory_dynamics_atlas/` | integrity/provenance、per-nucleotide RMSF、seed diagnostics | 已有动力学描述性分析；详尽审计转由 v2 atlas 与 staged-validation 报告。 |
| `analysis/exploratory_dynamics_atlas_v2/`、`analysis/staged_validation/` | Phase 0–2 数据/QC/receipt/报告 | 60 production segments 文件和协议一致性检查、12 seeds/4 designs 指标；Phase 2 repair、Phase 3–6 未执行；thermal mask false。 |
| `analysis/seed_variance/`、`cross_seed_rmsf_distribution/`、`rmsf_distribution_convergence/`、`nucleotide_flexibility_difference/` | 多 seed RMSF/分布/空间排名 CSV、completion receipts | 4 个不同设计 ×3 seeds 的 thermal RMSF 描述结果；不是 HADO Initial→Prepared endpoint 重复，不作平衡或训练准入声明。 |
| `analysis/label_qualification/`、`dataset_feasibility/20261005_a0_a4_existing_data/` | QC、逐位置统计、报告和 receipt | `descriptive_only_provisional`；训练 mask 和 thermal eligibility 均 false；部分采样/精度/泛化门未完成。 |
| `analysis/batch_20x3/20261005_20x3/`、`batch_20x3_smoke_nativeio/` | batch report/manifest；smoke summary | 20×3 批次被阻断，生产完成 0；smoke 1 个 provisional，不计作生产结果。 |
| `analysis/dnaxis_ripple_chimney_anchor_distance_20261012/` | 1,000-frame distance CSV/summary | 该单条轨迹 30.1M–130.1M steps，距离均值 59.54 nm，ESS≈10.16；不是 HADO 400 endpoint 数据，也不证明 equilibrium。 |
| `analysis/dgnn_lite_full_20261009/figures/`, `painn_complete_graph_20261007/figures/` | validation prediction atlases/source JSON | 仅为上述 DGNN/PaiNN 指标的图像导出，不是额外训练实验。 |
| `analysis/mechanical_labels_v1/`, `multitask_pred_v1/` | server_v2 comparison、dataset builder | 机械标签准入状态见 label qualification；多任务目录目前只有数据集构建脚本，没有完成结果报告。 |
| `ml_pilot/results/dgnn_lite_delta_supervised_20261009/` | 训练日志 | epoch 58 停止；未形成 summary。 |
| `ml_pilot/results/graph_flow_400_{smoke,capacity_smoke,full_hidden64x3,hidden128x4,full_hidden128x4,hidden256x6}/` | 配置、训练历史/日志、部分 endpoint eval | hidden64x3 有 400-design pooled endpoint eval；几类更大模型只有配置、partial/stopped logs 或 capacity smoke，不能写成相同口径完整对比。 |
| `ml_pilot/results/shared_fourier_400*`, `global_flow_400/` | 分支配置、部分 checkpoint/history、rollout/eval | CUDA shared Fourier 有 400-design evaluation；其他 aggressive 分支不少只有 checkpoint 或训练日志，需按结果文件区分完整度。 |
| `ml_pilot/results/initial_only_{H125,2,8,32}/`, `graph_flow_H125_overfit/` | 训练配置/曲线和端点 eval | 单设计/小子集过拟合及规模诊断，不代表 family-held-out 泛化。 |
| `ml_pilot/results/iterative_{direction,origami}_v1/`, `iterative_origami_full_v1/` | policy 训练、228 teacher JSON、teacher report | teacher 平均 RMSD改善很小且近似碰撞计数高；direction v1 只有两个家族且没有 held-out split。 |
| `ml_pilot/results/{painn*,deepsnupi*,graphflow_snupi258*,snupi258_model_showcase}/` | JSON metrics、预测和比较展示 | PaiNN有各自 validation improvement；DeepSNUPI/GraphFlow为 258-design 不同数据/单位口径；不能混入 HADO 400 的测试排名。 |
| `results/rigid_corrected/` | corrected rigid README、metrics、64-design atlas | 旧 edge mapping 结果作废；纠正后仍然是 train subset/H125 fit，不是 blind validation。 |
| `results/harness_hidden256_mp3/`, `results/harness_dgnn_force_physics_20261009/` | summary、metrics、force harness | 主端点模型与物理门控摘要，见 B2/B6。 |

未追踪 checkpoint 和缓存体积大，Git 只保存选定 summary/代码；各目录不是完整的 checkpoint archive。任何基于提交标题、PID 文件或训练日志推导的未落盘结果均不列作正式测量值。

## F. 读取边界

1. 目录和 Git 记录已按实验路径交叉核对；大文件/被忽略 checkpoint 没有复制进 Harness。
2. “有目录、有日志”不等于“结果已证明”；表中明确区分量化、过程证据、未完成和作废。
3. 需要将所有历史 checkpoint 追溯到 cache SHA、生成器提交和 adapter 提交，才能把边类型问题从“当前缓存已核验”升级为“历史结果全部闭合”。
4. 本目录不把随机 seed thermal RMSF 与 Initial→Prepared endpoint seed variability 混为一谈。

## G1. 覆盖审计中发现的工作区目录（逐项补记）

以下目录在工作区存在，但此前只被通配符或运行日志间接覆盖。它们现在单独列出；除明确写有独立 summary/验收结果的目录外，均只能作为过程证据，不能当作新的成功实验。

| 目录 | 当前可核验文件 | 证据等级与结论 |
|---|---|---|
| `analysis/ai_geometry_projection_20261015/` | `summary.md`、`design_level_results.csv`、`physical_acceptance.json`、`experiment_protocol.json`、`failures.md` | 最新 16-design pilot；240 个 AI/Initial 投影构象均未通过 100-step MD，16/16 Prepared 对照通过；已纳入最终报告。 |
| `analysis/dgnn_lite_energy_20261015/` | `physical_acceptance/` receipts | 仅有小规模物理验收收据；需结合 `ml_pilot/results/dgnn_lite_energy_20261015/summary.json`，不能替代 92-design 独立物理验收。 |
| `ml_pilot/results/dgnn_lite_energy_20261015/` | `summary.json` | 完整 228/80/92 split；test RMSE 7.63690，弱于 hidden256 7.49109；无完整物理门闭合。 |
| `ml_pilot/results/dgnn_lite_position_lr3e3_ori01_20261009/` | `summary.json` | 92-test RMSE 7.70730；模型分支结果，弱于 hidden256。 |
| `ml_pilot/results/dgnn_lite_position_lr5e4_ori01_20261009/` | `summary.json` | 92-test RMSE 7.53119；仍弱于 hidden256，且没有独立物理验收。 |
| `ml_pilot/results/dgnn_lite_position_weighted_20261009/` | `summary.json` | 仅完成 1 epoch；92-test RMSE 7.73819；不能作为成熟模型比较。 |
| `analysis/prepared_oxdna_standard_20261015/` | `prepared_manifest.json`、H001 smoke `status.json` | 500 个 Prepared 输入清单；H001 smoke 明确 `MAX_STEPS_NOT_SCREENED`，且记录声明不是 equilibrium proof。 |
| `analysis/prepared_oxdna_equilibration_20261015/` | `first_250/batch_status.json`、protocol/input/log | 只记录 19 个已启动条目：6 个 `SCREEN_PASS_NEEDS_STRUCTURAL_VALIDATION`、11 个失败、1 个运行中、1 个未筛完；不能称为 250/500 个设计已平衡。 |
| `analysis/prepared_oxdna_equilibration_20261015/first_250/structural_validation_10.json` | 10 个筛选设计的结构验证收据 | 结构文件/坐标层面的验证记录；属于筛选证据，不等于平衡证明。 |
| `analysis/prepared_oxdna_equilibration_20261015/first_250/thermodynamic_equilibrium_audit_10.md` | 能量分块、漂移、Rg、ESS 和轨迹完整性审计 | 10 个设计均通过 operational stability screen，但严格 thermodynamic equilibrium 为 0/10；单轨迹、缺少独立 replica 和 kinetic-temperature series。 |
| `ml_pilot/results/graph_flow_400_{smoke,capacity_smoke}/` | `run_config.json`、`history.csv` | smoke/capacity 过程记录；没有统一 blind test 和物理验收。 |
| `ml_pilot/results/graph_flow_400_{hidden128x4,full_hidden128x4,hidden256x6}/` | run config、PID/训练记录 | 训练或暂停过程证据；未形成统一可比 endpoint 指标，不得写成成功泛化实验。 |
| `ml_pilot/results/shared_fourier_400_{aggressive,aggressive512,big_smoke}/` | 部分 history/config（目录内容不完整） | 分支过程/容量探索；不能与已量化的 `shared_fourier_400_cuda` test 结果混用。 |
| `ml_pilot/results/initial_only_{H125,2,8,32}/` | checkpoint、曲线或 endpoint eval | 单设计/小规模容量与过拟合诊断；不代表 family-held-out 泛化。 |
| `ml_pilot/results/iterative_direction_v1/`、`iterative_origami_v1/` | policy 训练与评估产物 | 探索性策略分支；没有统一独立 test 物理验收。 |

## H. 本次审计提交

六项Harness `c00910c`；路由规范化 `7af048b`；400缓存边语义和目录 `dbefcd1`、`5b060b4`、`bc1d508`、`df38914`；PaiNN物理边界 `7ac2f7c`；14分支历史边溯源矩阵 `1142d5b`、CSV修复 `5ad63d6`。新增重复端点审计提交可用 `git log -- harness/05_prepared_seed_variance` 查询。
