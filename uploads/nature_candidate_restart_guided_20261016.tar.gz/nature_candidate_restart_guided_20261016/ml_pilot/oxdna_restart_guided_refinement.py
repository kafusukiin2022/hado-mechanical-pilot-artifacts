#!/usr/bin/env python3
"""Small differentiable DNA2 restart-guided refinement pilot.

Reproduces oxDNA2 backbone-site geometry and excluded-volume site cutoffs from
vendor/oxDNA/src/Interactions/DNAInteraction.cpp and model.h. This is a
surrogate loss, not a differentiable oxDNA integrator. It refines fixed model
predictions and then validates the result with the real oxDNA executable.
"""
from __future__ import annotations
import csv, json, sys, time
from pathlib import Path
import numpy as np
import torch
from scipy.spatial import cKDTree

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'ml_pilot'),str(ROOT.parent/'flowmatching'),str(ROOT/'scripts')]
from train_onepass_ablation import frame_rotation, load_cache, model_input
from onepass_model import OnePassSE3Predictor
from transfer_operator.oxdna_io import iter_frames
from geometry_io import read_top
from run_ai_geometry_projection_experiment import run_md
from run_hidden256_physical_acceptance import restart_text

DEVICE='cuda:0'; PILOT=ROOT/'analysis/oxdna_restart_guided_20261016'
CKPT=ROOT/'ml_pilot/results/onepass_ablation_20261007/onepass_A_20261007.pt'
CACHE=ROOT/'ml_pilot/cache_onepass_20261007'
MANIFEST=ROOT/'ml_pilot/results/onepass_family_split_20261007.json'
DESIGNS=['H101','H102','H103']
R0=0.7564; DELTA=0.25

def model(device,scale):
    state=torch.load(CKPT,map_location=device,weights_only=False)
    m=OnePassSE3Predictor(6,256,3,20,False,False).to(device)
    m.load_state_dict(state['model']); m.eval()
    return m

def make_repulsion_pairs(pos,rot,box,backbone):
    a1,a3=rot[...,0],rot[...,2]
    sites=np.stack((pos-.34*a1+.3408*np.cross(a3,a1),pos+.4*a1),axis=1)
    wrapped=np.mod(sites.reshape(-1,3),box)
    wrapped=np.minimum(wrapped,np.nextafter(box,0.0))
    near=cKDTree(wrapped,boxsize=box).query_pairs(.90,output_type='ndarray')
    if not len(near): return np.empty((2,0),np.int64),np.empty(0,np.float32)
    i,si=np.divmod(near[:,0],2); j,sj=np.divmod(near[:,1],2)
    keep=i!=j
    bonded={tuple(sorted(map(int,e))) for e in backbone}
    keep &= np.fromiter((tuple(sorted((int(a),int(b)))) not in bonded for a,b in zip(i,j)),bool,len(i))
    i,j,si,sj=i[keep],j[keep],si[keep],sj[keep]
    cutoff=np.where((si==0)&(sj==0),.711879214356,np.where((si==1)&(sj==1),.335388426126,.52329943261))
    return np.stack((i,j,si,sj)),cutoff.astype(np.float32)

def metrics(x,rot,edges,box,pairmeta,cutoffs):
    a1,a3=rot[...,0],rot[...,2]
    back=x-.34*a1+.3408*np.cross(a3,a1)
    d=back[edges[:,1]]-back[edges[:,0]]
    d-=box*np.rint(d/box)
    length=np.linalg.norm(d,axis=-1)
    i,j,si,sj=pairmeta
    sites=np.stack((back,x+.4*a1),axis=1)
    v=sites[j,sj]-sites[i,si]; v-=box*np.rint(v/box)
    r=np.linalg.norm(v,axis=-1)
    return {'fene_outliers':int(np.sum(np.abs(length-R0)>=DELTA)),
            'fene_max_violation':float(max(np.max(length-(R0+DELTA)),np.max((R0-DELTA)-length))),
            'fene_mean_abs_strain':float(np.mean(np.abs(length-R0))),
            'site_overlap_pairs':int(np.sum(r<cutoffs)),
            'site_overlap_total':float(np.maximum(cutoffs-r,0).sum()),
            'site_overlap_max':float(np.maximum(cutoffs-r,0).max(initial=0))}

def main():
    device=torch.device(DEVICE); torch.cuda.set_device(device)
    scale=float(torch.load(CKPT,map_location='cpu',weights_only=False)['config']['scale'])
    net=model(device,scale)
    manifest={r['design_id']:r for r in json.loads(MANIFEST.read_text())['rows']}
    outrows=[]
    for ident in DESIGNS:
        row=manifest[ident]; cache=load_cache(CACHE/(ident+'.npz'),device)
        with torch.no_grad(): out=net(**model_input(cache,device,scale))
        x0=out['position'].detach()*scale+torch.as_tensor(cache['source_center'],device=device)
        rot=out['rotation'].detach()
        edge=torch.as_tensor(cache['backbone_edges'].T,device=device,dtype=torch.long)
        box=np.asarray(cache['box'],dtype=np.float32)
        # Candidate pairs from current predicted state, equivalent typed sites.
        pair_np,cut_np=make_repulsion_pairs(x0.cpu().numpy(),rot.cpu().numpy(),box,cache['backbone_edges'].T)
        pair=torch.as_tensor(pair_np,device=device,dtype=torch.long)
        cut=torch.as_tensor(cut_np,device=device,dtype=x0.dtype)
        i,j,si,sj=pair
        # Only learn positions here; output axes remain those predicted by model.
        x=torch.nn.Parameter(x0.clone()); opt=torch.optim.Adam([x],lr=.001)
        for step in range(1001):
            opt.zero_grad(set_to_none=True)
            a1,a3=rot[...,0],rot[...,2]
            b=x-.34*a1+.3408*torch.cross(a3,a1,dim=-1)
            dv=b[edge[1]]-b[edge[0]]; dv-=torch.as_tensor(box,device=device)*torch.round(dv/torch.as_tensor(box,device=device))
            rr=torch.linalg.vector_norm(dv,dim=-1).clamp_min(1e-8)
            # Exact oxDNA2 FENE admissible interval plus central spring prior.
            violation=torch.relu(torch.abs(rr-R0)-(DELTA-.015))
            loss_fene=500.0*violation.square().mean()+15.0*(rr-R0).square().mean()
            sites=torch.stack((b,x+.4*a1),dim=1)
            sv=sites[j,sj]-sites[i,si]; sv-=torch.as_tensor(box,device=device)*torch.round(sv/torch.as_tensor(box,device=device))
            sr=torch.linalg.vector_norm(sv,dim=-1).clamp_min(.03)
            overlap=torch.relu(cut-sr)
            loss_ev=(0.2 if step < 500 else 2.0)*overlap.square().mean()
            # Trust region keeps the physical repair near the learned prediction.
            loss_move=0.01*(x-x0).square().mean()
            loss=loss_fene+loss_ev+loss_move
            loss.backward(); torch.nn.utils.clip_grad_norm_([x],10.0); opt.step()
        xref=x.detach().cpu().numpy(); rref=rot.cpu().numpy(); xraw=x0.cpu().numpy()
        before=metrics(xraw,rref,cache['backbone_edges'].T,box,pair_np,cut_np)
        after=metrics(xref,rref,cache['backbone_edges'].T,box,pair_np,cut_np)
        template=ROOT/row['initial_dat']; top=ROOT/row['initial_top']
        for label,pos in [('baseline',xraw),('guided',xref)]:
            target=PILOT/ident/label; target.mkdir(parents=True,exist_ok=True)
            dat=target/'structure.dat'; dat.write_text(restart_text(template,pos,rref[...,0],rref[...,2]))
            md=run_md(target/'md100',top,dat,100,timeout=60)
            rec={'design_id':ident,'route':label,'md100_pass':bool(md.get('completed',False)),
                 'md100_error':'; '.join(md.get('errors',[])),'fene':before if label=='baseline' else after,
                 'loss_steps':1000 if label=='guided' else 0,
                 'rms_shift_from_prediction':float(np.sqrt(np.mean((pos-xraw)**2))),
                 'dat':str(dat.relative_to(ROOT))}
            outrows.append(rec); print(json.dumps(rec),flush=True)
    (PILOT/'results.json').write_text(json.dumps(outrows,indent=2)+'\n')

if __name__=='__main__': main()
