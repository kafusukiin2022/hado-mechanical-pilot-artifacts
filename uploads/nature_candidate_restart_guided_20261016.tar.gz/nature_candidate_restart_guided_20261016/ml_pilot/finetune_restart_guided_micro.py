#!/usr/bin/env python3
"""Three-design parameter fine-tuning pilot for the restart-guided loss."""
from pathlib import Path
import json, sys, torch
import torch.nn.functional as F
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'ml_pilot'),str(ROOT.parent/'flowmatching')]
from train_onepass_ablation import load_cache, model_input
from onepass_model import OnePassSE3Predictor
from restart_guided_loss import restart_guided_loss

DEVICE='cuda:0'; IDS=['H101','H102','H103']; CACHE=ROOT/'ml_pilot/cache_onepass_20261007'; CKPT=ROOT/'ml_pilot/results/onepass_ablation_20261007/onepass_A_20261007.pt'; OUT=ROOT/'analysis/oxdna_restart_guided_20261016/micro_finetune.json'

def main():
    dev=torch.device(DEVICE); torch.cuda.set_device(dev)
    ck=torch.load(CKPT,map_location=dev,weights_only=False); scale=float(ck['config']['scale'])
    m=OnePassSE3Predictor(6,256,3,20,False,False).to(dev); m.load_state_dict(ck['model']); m.train()
    data={i:load_cache(CACHE/(i+'.npz'),dev) for i in IDS}
    opt=torch.optim.AdamW(m.parameters(),lr=2e-5)
    history=[]
    def one(d):
        out=m(**model_input(d,dev,scale)); pred=out['position']*scale
        target=torch.as_tensor(d['pos1'],device=dev)
        coord=F.smooth_l1_loss(pred,target)
        rg,parts=restart_guided_loss(pred,out['a1'],out['a3'],torch.as_tensor(d['backbone_edges'],device=dev),torch.as_tensor(d['energy_pair_index'],device=dev),fene_weight=1.,excluded_weight=.1)
        return out,coord,rg,parts
    with torch.no_grad():
        before=[]
        for ident,d in data.items():
            out,c,rg,p=one(d); before.append({'design_id':ident,'coordinate_loss':float(c),'restart_loss':float(rg),'fene_soft_outliers':int(p['fene_outliers_soft'])})
    for epoch in range(1,4):
        m.train(); sums={'coord':0.,'restart':0.}
        for d in data.values():
            opt.zero_grad(set_to_none=True); out,c,rg,p=one(d); loss=c+0.02*rg; loss.backward(); torch.nn.utils.clip_grad_norm_(m.parameters(),1.); opt.step(); sums['coord']+=float(c.detach()); sums['restart']+=float(rg.detach())
        history.append({'epoch':epoch,**{k:v/len(data) for k,v in sums.items()}})
    m.eval(); after=[]
    with torch.no_grad():
        for ident,d in data.items():
            out,c,rg,p=one(d); after.append({'design_id':ident,'coordinate_loss':float(c),'restart_loss':float(rg),'fene_soft_outliers':int(p['fene_outliers_soft'])})
    OUT.parent.mkdir(parents=True,exist_ok=True); OUT.write_text(json.dumps({'ids':IDS,'epochs':history,'before':before,'after':after,'restart_weight':.02},indent=2)+'\n'); print(json.dumps({'history':history,'before':before,'after':after}))
if __name__=='__main__': main()
