#!/usr/bin/env python3
"""Train HADO DGNN-lite with Geodiff's differentiable oxDNA geometry loss."""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
GEODIFF = ROOT.parent / "Geodiff_fam"
sys.path.insert(0, str(ROOT / "ml_pilot"))
sys.path.insert(0, str(GEODIFF))

from dgnn_lite_model import DgnnLiteRigidPredictor  # noqa: E402
from train_onepass_ablation import (CACHE, MANIFEST, get_tensor, load_cache,
                                    make_cache)  # noqa: E402
from ebd_oxdna.oxdna_energy_loss import OxDNAEnergyConfig, oxdna_energy_loss  # noqa: E402
from restart_guided_loss import restart_guided_loss  # noqa: E402

OUT = ROOT / "ml_pilot/results/dgnn_lite_energy_20261015"


def energy_terms(model_out, d, device, scale):
    pred_pos = model_out["position"] * scale
    target_pos = get_tensor(d, "pos1", device, torch.float32)
    pred_a1 = model_out["a1"]
    pred_a3 = model_out["a3"]
    target_rot = get_tensor(d, "rot1", device, torch.float32)
    backbone = get_tensor(d, "backbone_edges", device, torch.long)
    pairs = get_tensor(d, "base_pairs", device, torch.long)
    config = OxDNAEnergyConfig(
        backbone_weight=1.0,
        stacking_weight=0.25,
        hbond_weight=1.0,
        cross_stack_weight=0.0,
        excluded_volume_weight=0.1,
        excluded_volume_cutoff=1.2,
        excluded_volume_softness=0.2,
        excluded_volume_max_pairs=200000,
    )
    breakdown = oxdna_energy_loss(
        torch,
        pred_positions=pred_pos,
        pred_a1=pred_a1,
        pred_a3=pred_a3,
        target_positions=target_pos,
        target_a1=target_rot[..., :, 0],
        target_a3=target_rot[..., :, 2],
        backbone_edges=backbone,
        reference_pairs=pairs,
        helix_steps=None,
        config=config,
    )
    return breakdown


def loss_and_parts(model, d, device, scale, energy_weight, energy_ramp,
                   restart_guided_weight=0.0):
    pos = get_tensor(d, "pos0", device, torch.float32) / scale
    rot0 = get_tensor(d, "rot0", device, torch.float32)
    nf = get_tensor(d, "node_features", device, torch.float32)
    ei = get_tensor(d, "gnn_edge_index", device, torch.long)
    ef = get_tensor(d, "gnn_edge_features", device, torch.float32)
    out = model(pos, rot0, nf, ei, ef, position_scale=scale)
    target_pos = get_tensor(d, "pos1", device, torch.float32) / scale
    target_rot = get_tensor(d, "rot1", device, torch.float32)
    lp = F.smooth_l1_loss(out["position"], target_pos)
    lo = (1 - (F.normalize(out["a1"], dim=-1) * target_rot[..., :, 0]).sum(-1).clamp(-1, 1)).mean()
    lo = lo + (1 - (F.normalize(out["a3"], dim=-1) * target_rot[..., :, 2]).sum(-1).clamp(-1, 1)).mean()
    se = get_tensor(d, "struct_edge_index", device, torch.long)
    i, j = se
    pe = F.smooth_l1_loss(out["position"][j] - out["position"][i],
                          target_pos[j] - target_pos[i], reduction="none").sum(-1)
    kinds = get_tensor(d, "struct_edge_kind", device, torch.long)
    groups = [pe[kinds == k].mean() for k in (1, 2, 3) if bool((kinds == k).any())]
    ls = torch.stack(groups).mean() if groups else pe.mean()
    breakdown = energy_terms(out, d, device, scale)
    e = breakdown.total
    total = 3.0 * lp + 0.1 * lo + 3.0 * ls + energy_weight * energy_ramp * e
    if restart_guided_weight:
        rg, rg_parts = restart_guided_loss(
            out["position"] * scale, out["a1"], out["a3"],
            get_tensor(d, "backbone_edges", device, torch.long),
            get_tensor(d, "energy_pair_index", device, torch.long),
            fene_weight=1.0, excluded_weight=0.1,
        )
        total = total + float(restart_guided_weight) * rg
    else:
        rg, rg_parts = e.new_zeros(()), {}
    return out, total, {
        "position": lp, "orientation": lo, "spatial": ls,
        "oxdna_energy": e, "oxdna_backbone": breakdown.backbone,
        "oxdna_stacking": breakdown.stacking, "oxdna_hbond": breakdown.hbond,
        "oxdna_excluded_volume": breakdown.excluded_volume,
        "restart_guided": rg,
        "restart_fene_outliers_soft": rg_parts.get("fene_outliers_soft", e.new_zeros(())),
        "restart_site_overlap_total": rg_parts.get("site_overlap_total", e.new_zeros(())),
    }


def evaluate(model, ids, data, device, scale, energy_weight, energy_ramp,
             restart_guided_weight=0.0):
    model.eval(); rows = []
    with torch.no_grad():
        for ident in ids:
            d = data[ident]
            out, total, parts = loss_and_parts(model, d, device, scale, energy_weight, energy_ramp, restart_guided_weight)
            pos = out["position"].cpu().numpy() * scale
            target = d["pos1"]
            source = d["pos0"]
            rows.append({
                "design_id": ident,
                "position_rmse_oxdna": float(np.sqrt(np.mean((pos - target) ** 2))),
                "identity_baseline_rmse_oxdna": float(np.sqrt(np.mean((source - target) ** 2))),
                "loss": float(total.cpu()),
                **{"loss_" + k: float(v.detach().cpu()) for k, v in parts.items()},
            })
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--patience", type=int, default=10)
    ap.add_argument("--energy-weight", type=float, default=0.05)
    ap.add_argument("--energy-ramp-epochs", type=int, default=10)
    ap.add_argument("--learning-rate", type=float, default=5e-4)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--seed", type=int, default=20261015)
    ap.add_argument("--smoke-only", action="store_true")
    ap.add_argument("--restart-guided-weight", type=float, default=0.0,
                    help="weight of exact DNA2 site/FENE restart surrogate loss")
    args = ap.parse_args()
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)
    device = torch.device(args.device)
    if device.type == "cuda": torch.cuda.set_device(device)
    manifest = json.loads(Path(MANIFEST).read_text())
    rows = {r["design_id"]: r for r in manifest["rows"]}
    ids = list(rows)
    if args.smoke_only:
        ids = [next(r["design_id"] for r in manifest["rows"] if r["split"] == s)
               for s in ("train", "validation", "test")]
    for ident in ids: make_cache(rows[ident], device)
    data = {i: load_cache(CACHE / (i + ".npz"), device) for i in ids}
    split = {s: [i for i in ids if rows[i]["split"] == s] for s in ("train", "validation", "test")}
    scale = float(np.median([np.sqrt(np.mean(data[i]["pos0"] ** 2)) for i in split["train"]]))
    model = DgnnLiteRigidPredictor(input_dim=6, edge_dim=20, hidden_dim=256,
                                   message_passing_steps=3, residual_scale=3.0).to(device)
    # The smoke path verifies finite energy values and gradients without saving a checkpoint.
    ramp = 1.0 if args.smoke_only else min(1.0, 1.0 / max(args.energy_ramp_epochs, 1))
    _, total, parts = loss_and_parts(model, data[ids[0]], device, scale, args.energy_weight, ramp, args.restart_guided_weight)
    total.backward()
    if not torch.isfinite(total) or not all(torch.isfinite(p).all() for p in model.parameters() if p.grad is not None):
        raise FloatingPointError("nonfinite DGNN-lite energy smoke")
    if args.smoke_only:
        print(json.dumps({"smoke": "passed", "loss": float(total),
                          "oxdna_energy": float(parts["oxdna_energy"]),
                          "restart_guided": float(parts["restart_guided"]), "scale": scale}), flush=True)
        return
    opt = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=1e-6)
    OUT.mkdir(parents=True, exist_ok=True)
    best = float("inf"); best_state = None; best_epoch = 0; stale = 0; history = []
    started = time.perf_counter()
    for epoch in range(1, args.epochs + 1):
        model.train(); order = split["train"].copy(); random.Random(args.seed + epoch).shuffle(order); sums = {}
        ramp = min(1.0, epoch / max(args.energy_ramp_epochs, 1))
        for ident in order:
            opt.zero_grad(set_to_none=True)
            _, total, parts = loss_and_parts(model, data[ident], device, scale, args.energy_weight, ramp, args.restart_guided_weight)
            total.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); opt.step()
            for k, v in parts.items(): sums[k] = sums.get(k, 0.0) + float(v.detach())
        val = evaluate(model, split["validation"], data, device, scale, args.energy_weight, ramp, args.restart_guided_weight)
        vr = float(np.mean([x["position_rmse_oxdna"] for x in val]))
        rec = {"epoch": epoch, "energy_ramp": ramp,
               "train_losses": {k: v / len(order) for k, v in sums.items()},
               "validation_position_rmse_oxdna": vr,
               "validation_energy_loss": float(np.mean([x["loss_oxdna_energy"] for x in val]))}
        history.append(rec); print(json.dumps(rec), flush=True)
        if vr < best - 1e-3:
            best, best_epoch, stale = vr, epoch, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else: stale += 1
        if stale >= args.patience: break
    model.load_state_dict(best_state)
    val = evaluate(model, split["validation"], data, device, scale, args.energy_weight, 1.0, args.restart_guided_weight)
    test = evaluate(model, split["test"], data, device, scale, args.energy_weight, 1.0, args.restart_guided_weight)
    payload = {
        "status": "completed", "architecture": "Geodiff DgnnLiteRigidModel + HADO 20D edges + Geodiff oxDNA energy loss",
        "hidden_dim": 256, "message_passing_steps": 3, "edge_feature_dim": 20,
        "energy_loss": "backbone + stacking + hbond + excluded_volume; cross_stack disabled because helix_steps are not present in HADO cache",
        "energy_weight": args.energy_weight, "energy_ramp_epochs": args.energy_ramp_epochs,
        "restart_guided_weight": args.restart_guided_weight,
        "best_model_monitor": "validation_position_rmse_oxdna", "best_epoch": best,
        "best_validation_rmse_oxdna": best, "test_rmse_oxdna": float(np.mean([x["position_rmse_oxdna"] for x in test])),
        "split_counts": {k: len(v) for k, v in split.items()}, "scale": scale,
        "seed": args.seed, "history": history, "validation_per_design": val, "test_per_design": test,
        "wall_seconds": time.perf_counter() - started,
        "manifest_sha256": hashlib.sha256(Path(MANIFEST).read_bytes()).hexdigest(),
    }
    (OUT / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    torch.save({"model": best_state, "config": payload}, OUT / "model.pt")
    print(json.dumps({"complete": True, "best_validation_rmse": best,
                      "test_rmse": payload["test_rmse_oxdna"], "best_epoch": best_epoch}), flush=True)


if __name__ == "__main__": main()
