"""PyTorch recreation of the oxDNA2 restart gates used in this project.

The constants and site construction mirror ``vendor/oxDNA/src/model.h`` and
``Interactions/DNAInteraction.cpp``.  The functions are finite everywhere so
they can provide gradients to a predictor.  They are deliberately called a
surrogate loss: the C++ simulator remains the acceptance oracle.
"""
from __future__ import annotations
from typing import Optional
import torch

FENE_R0 = 0.7564
FENE_DELTA = 0.25
FENE_EPS = 2.0
POS_BACK = -0.4
POS_MM_BACK1 = -0.3400
POS_MM_BACK2 = 0.3408
POS_BASE = 0.4
EXCL_RC_BACK_BACK = 0.711879214356
EXCL_RC_BASE_BASE = 0.335388426126
EXCL_RC_MIXED = 0.52329943261


def dna2_sites(position: torch.Tensor, a1: torch.Tensor, a3: torch.Tensor):
    """Return the oxDNA2 backbone and base interaction centers."""
    back = position + POS_MM_BACK1 * a1 + POS_MM_BACK2 * torch.cross(a3, a1, dim=-1)
    base = position + POS_BASE * a1
    return torch.stack((back, base), dim=-2)


def fene_restart_loss(
    position: torch.Tensor,
    a1: torch.Tensor,
    a3: torch.Tensor,
    backbone_edges: torch.Tensor,
    margin: float = 0.01,
    temperature: float = 0.01,
):
    """Differentiable FENE admissibility loss on DNA2 backbone sites.

    oxDNA throws when ``abs(r-r0) >= delta``.  The soft barrier starts at a
    configurable interior margin and is paired with a weak central preference.
    Diagnostics are returned for direct comparison with the C++ gate.
    """
    sites = dna2_sites(position, a1, a3)
    i, j = backbone_edges
    d = sites[j, 0] - sites[i, 0]
    r = torch.linalg.vector_norm(d, dim=-1).clamp_min(1e-8)
    deviation = torch.abs(r - FENE_R0)
    excess = deviation - (FENE_DELTA - float(margin))
    barrier = torch.nn.functional.softplus(excess / float(temperature)) * float(temperature)
    loss = (barrier.square().mean() + 0.05 * (r - FENE_R0).square().mean())
    return loss, {
        "backbone_distance": r,
        "fene_outliers_soft": (deviation >= FENE_DELTA).sum(),
        "fene_max_excess": torch.relu(deviation - FENE_DELTA).max(),
        "fene_mean_abs_strain": deviation.mean(),
    }


def excluded_volume_restart_loss(
    position: torch.Tensor,
    a1: torch.Tensor,
    a3: torch.Tensor,
    pair_index: torch.Tensor,
    backbone_edges: Optional[torch.Tensor] = None,
    strength: float = 1.0,
):
    """Typed site-overlap surrogate for oxDNA's repulsive LJ terms.

    ``pair_index`` is a precomputed candidate nucleotide graph.  This avoids
    nondifferentiable neighbor-list construction during training while using
    the same three site cutoffs as ``_repulsive_lj`` in oxDNA.
    """
    sites = dna2_sites(position, a1, a3)
    i, j = pair_index
    si = torch.tensor([0, 0, 1, 1], device=position.device)
    sj = torch.tensor([0, 1, 0, 1], device=position.device)
    # Evaluate all four typed site interactions for each candidate nucleotide pair.
    delta = sites[j[:, None], sj[None, :]] - sites[i[:, None], si[None, :]]
    distance = torch.linalg.vector_norm(delta, dim=-1).clamp_min(1e-6)
    cutoff = torch.tensor(
        [EXCL_RC_BACK_BACK, EXCL_RC_MIXED, EXCL_RC_MIXED, EXCL_RC_BASE_BASE],
        dtype=position.dtype, device=position.device,
    )
    overlap = torch.relu(cutoff[None, :] - distance)
    # Existing bonded edges are retained: oxDNA has a separate bonded excluded
    # volume interaction, so dropping them would hide a real restart failure.
    loss = float(strength) * overlap.square().mean()
    return loss, {"site_overlap": overlap, "site_overlap_total": overlap.sum()}


def restart_guided_loss(
    position, a1, a3, backbone_edges, pair_index,
    fene_weight: float = 1.0, excluded_weight: float = 0.1,
):
    lf, df = fene_restart_loss(position, a1, a3, backbone_edges)
    le, de = excluded_volume_restart_loss(position, a1, a3, pair_index)
    return fene_weight * lf + excluded_weight * le, {**df, **de,
        "fene_loss": lf, "excluded_volume_loss": le}
