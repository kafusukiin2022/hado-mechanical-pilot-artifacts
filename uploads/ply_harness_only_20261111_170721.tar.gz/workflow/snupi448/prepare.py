from pathlib import Path
import json,shutil,hashlib,re
B=Path(__file__).resolve().parent; ROOT=B.parents[3];SOURCE=B.parent/'batch1000'
# Resolve project root explicitly, independent of directory nesting.
ROOT=Path('/home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base=ROOT.parent/'snupi/work/talos97-all-rmsf/runs/6hb_097/Default.snp'
s=base.read_text()
for k,v in [('STT_GPU','1'),('DO_STT','1'),('DO_NMA','1'),('DO_NMA_RMSF','1'),('NMA_MODE_NUM','200'),('DO_DYN','0')]:
 s,n=re.subn(r'(?m)^(\s*'+k+r'\s+)[^\r\n]+',lambda m:m.group(1)+v,s);assert n==1
rows=[]
for r in json.loads((SOURCE/'final_audit.json').read_text())['rows']:
 if r['status']!='routing_accepted':continue
 a=r['selected'];src=SOURCE/a['folder'];ident=r['id'];d=B/'runs'/ident;d.mkdir(parents=True,exist_ok=False)
 for source,dest in [(src/a['cadnano'],d/(ident+'.json')),(src/'validated_staple_endpoints.csv',d/(ident+'.csv'))]:
  key=str(source.relative_to(src));assert sha(source)==a['output_hashes'][key];shutil.copy2(source,dest)
 j=json.loads((d/(ident+'.json')).read_text());nodes=sum(x!=[-1]*4 and y!=[-1]*4 for v in j['vstrands'] for x,y in zip(v['scaf'],v['stap']))
 assert nodes==a['cndo']['base_pairs']
 (d/'Input.txt').write_text('H  '+ident+'\n');(d/'Default.snp').write_text(s)
 row=dict(design=ident,dir=str(d),nodes=nodes,vertex=a['vertex'],total_nt=a['total_nt'],source=str(src),input_sha256={p.name:sha(p) for p in d.iterdir()})
 (d/'status.json').write_text(json.dumps(dict(**row,status='queued'),indent=2));rows.append(row)
rows.sort(key=lambda r:r['nodes']);assert len(rows)==448 and len({r['design'] for r in rows})==448
(B/'manifest.json').write_text(json.dumps(dict(job='25570',workers=18,cpus_per_worker=4,total_RSS_guard_GiB=72,per_design_guard_GiB=13,gpu_concurrency=[9,9],designs=rows),indent=2)+'\n')
print('PASS 448 input hashes/pair counts; static+200mode NMA RMSF; 18 slots')
