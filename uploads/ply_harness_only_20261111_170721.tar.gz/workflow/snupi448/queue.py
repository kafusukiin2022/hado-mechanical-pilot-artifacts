import os,json,time,signal,subprocess,shutil,hashlib,fcntl,socket,re
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import psutil,numpy as np,h5py
B=Path(__file__).resolve().parent;ROOT=Path('/home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam');OLD=ROOT/'outputs/talos97_topology_exploration_20261109/new_batch_20261109'
LAUNCHER=ROOT.parent/'snupi/scripts/run-snupi.sh';G=1024**3
DEADLINE=datetime.fromisoformat('2026-11-11T22:11:52+08:00').timestamp()
def now():return datetime.now(timezone.utc).isoformat()
def save(p,d):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(d,indent=2)+'\n');t.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stop(p):
 try:os.killpg(p.pid,signal.SIGTERM)
 except ProcessLookupError:return
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:
  try:os.killpg(p.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  p.wait()

def finish(r,reason=None):
 p=r.pop('_process');f=r.pop('_file');p.wait();f.close();r.pop('_sample',None)
 d=Path(r['dir']);t=(d/'run.log').read_text(errors='replace');r.update(returncode=p.returncode,finished=now(),wall_s=round(time.time()-r.pop('_start'),3),converged='SOLUTION CONVERGED' in t,end_seen='%---------------------------------- END' in t,rmsf_seen='RMSF CALCULATION (NMA)' in t)
 r['status']='deferred' if reason else 'failed';r['reason']=reason or 'missing_verified_output'
 if not reason and ('CUBLAS' in t or 'parallel:gpu:' in t or 'CUDA_ERROR' in t):r['status']='runtime_error';r['reason']='gpu_runtime_error'
 elif not reason and 'NOT CONVERGED' in t:r['reason']='static_not_converged'
 elif not reason and p.returncode==0 and all(r[k] for k in ['converged','end_seen','rmsf_seen']):
  try:
   mats=list((d/'OUTPUT').glob('*/*_STT.mat'));assert len(mats)==1
   with h5py.File(mats[0]) as h:
    rmsf=np.asarray(h['NMA_RMSF']).reshape(-1);eig=np.asarray(h['NMA_EIG_VAL']).reshape(-1)
   assert len(rmsf)==r['nodes'] and np.isfinite(rmsf).all() and (rmsf>=0).all()
   assert len(eig)==200 and np.isfinite(eig).all() and (eig>0).all()
   np.savetxt(d/'rmsf_nm.csv',np.column_stack([np.arange(len(rmsf)),rmsf]),delimiter=',',header='node_index,rmsf_nm',comments='')
   r.update(status='success',reason=None,mat=str(mats[0]),mat_sha256=sha(mats[0]),rmsf_n=len(rmsf),rmsf_min_nm=float(rmsf.min()),rmsf_max_nm=float(rmsf.max()),positive_eigenvalues=200)
  except Exception as e:r.update(status='audit_failed',reason=repr(e))
 save(d/'status.json',r);return r

def public(r):return {k:v for k,v in r.items() if not k.startswith('_')}
def main():
 assert os.environ.get('SLURM_JOB_ID')=='25570'
 lock=(B/'runner.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 m=json.loads((B/'manifest.json').read_text()); cpus=sorted(os.sched_getaffinity(0));assert len(cpus)>=72
 assert not (B/'summary.json').exists(), 'existing campaign: inspect and recover before restart'
 pending=list(m['designs']);live={};results=[];gpu_blocked=set();start=time.time()
 while pending or live:
  deadline=time.time()>DEADLINE
  for slot in range(18):
   if not pending or deadline:break
   if slot in live or slot%2 in gpu_blocked:continue
   r=dict(pending.pop(0));d=Path(r['dir']);gpu=slot%2;chosen=cpus[slot*4:slot*4+4]
   env=os.environ.copy();env.update(SNUPI_WORKDIR=str(d),SNUPI_CLEAN_LIBS='1',SNUPI_CPP_RUNTIME_DIR=str(B/('cpp'+str(gpu))),CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MCR_CACHE_ROOT=str(B/'mcr_cache'/str(slot)))
   f=(d/'run.log').open('w');p=subprocess.Popen(['taskset','-c',','.join(map(str,chosen)),str(LAUNCHER)],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True)
   r.update(status='running',started=now(),pid=p.pid,slot=slot,gpu=gpu,cpus=chosen,peak_rss_bytes=0,_process=p,_file=f,_start=time.time());live[slot]=r;save(d/'status.json',public(r))
  total=0
  for r in live.values():
   rss=0;cpu=0
   try:
    pp=psutil.Process(r['pid'])
    for p in [pp]+pp.children(recursive=True):
     try:rss+=p.memory_info().rss;ct=p.cpu_times();cpu+=ct.user+ct.system
     except psutil.Error:pass
   except psutil.Error:pass
   t=time.time();prev=r.get('_sample',(t,cpu));r['cpu_percent']=100*(cpu-prev[1])/max(t-prev[0],.01);r['_sample']=(t,cpu)
   r.update(rss_bytes=rss,peak_rss_bytes=max(rss,r['peak_rss_bytes']));total+=rss
  pressure=max(live,key=lambda k:live[k]['rss_bytes']) if live and total>72*G else None
  # GPU memory is separate from host RSS. Defer one task on a pressured card.
  vram_victims=set()
  query=subprocess.run(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader,nounits'],capture_output=True,text=True)
  for line in query.stdout.splitlines():
   gi,mem=line.split(',');gi=int(gi);mem=int(mem)
   candidates=[slot for slot,r in live.items() if r['gpu']==gi]
   if mem>11000 and candidates:vram_victims.add(max(candidates,key=lambda k:live[k]['rss_bytes']))
  for slot,r in list(live.items()):
   p=r['_process'];reason='allocation_deadline' if deadline else 'task_timeout_7200s' if time.time()-r['_start']>7200 else ('aggregate_RSS_guard_72GiB' if slot==pressure else ('per_design_RSS_guard_13GiB' if r['rss_bytes']>13*G else None))
   if slot in vram_victims and not reason:reason='gpu_VRAM_guard_11000MiB'
   if reason:stop(p)
   if p.poll() is not None:
    done=finish(r,reason);results.append(done);del live[slot]
    if done['status']=='runtime_error':gpu_blocked.add(done['gpu'])
   else:save(Path(r['dir'])/'status.json',public(r))
  g=subprocess.run(['nvidia-smi','--query-gpu=index,memory.used,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True)
  with (B/'telemetry.jsonl').open('a') as f:f.write(json.dumps(dict(time=now(),rss_bytes=total,cpu_percent=sum(r.get('cpu_percent',0) for r in live.values()),gpus=g.stdout.strip(),active=len(live)))+'\n')
  summary=dict(status='running',pid=os.getpid(),checked=now(),job='25570',started_epoch=start,total=len(m['designs']),pending=[r['design'] for r in pending],active=[public(r) for r in live.values()],results=results,counts=dict(Counter(r['status'] for r in results)),blocked_gpus=sorted(gpu_blocked),external_job=None,external_count=0)
  if (deadline or len(gpu_blocked)==2) and not live:summary['status']='deferred';save(B/'summary.json',summary);break
  if not pending and not live:summary['status']='finished'
  save(B/'summary.json',summary)
  if live:time.sleep(3)
if __name__=='__main__':
 import sys
 main()
