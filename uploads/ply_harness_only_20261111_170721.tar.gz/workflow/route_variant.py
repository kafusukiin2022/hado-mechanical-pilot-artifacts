from pipeline import *
def route_audit(work,g,vertex="mitered"):
    assert vertex in ("mitered", "flat")
    products=list((work/'output').glob('*/*_JSON_caDNAno.json'));assert len(products)==1,'missing_or_ambiguous_cadnano'
    jp=products[0];d=json.loads(jp.read_text());vs=d['vstrands']
    assert len(vs)==6*g.number_of_edges(),'not_six_helices_per_edge'
    assert len({v['num'] for v in vs})==len(vs)
    counts={};routes={}
    for kind in ('scaf','stap'):
        nodes={(v['num'],i):a for v in vs for i,a in enumerate(v[kind]) if a!=[-1]*4}
        for key,a in nodes.items():
            for off,rev in ((0,2),(2,0)):
                target=tuple(a[off:off+2])
                assert target==(-1,-1) or (target in nodes and tuple(nodes[target][rev:rev+2])==key),'nonreciprocal_link'
        routes[kind]=adapter.paths(vs,kind);assert sum(map(len,routes[kind]))==len(nodes)
        counts[kind]=len(nodes)
    assert len(routes['scaf'])==1
    assert all(not any(v.get('loop',[])) and not any(v.get('skip',[])) for v in vs),'indels_need_explicit_accounting'
    seq=next(jp.parent.glob('*_sequence.csv'));lengths={'scaffold':0,'staple':0}
    with seq.open(encoding='latin-1') as f:
        for row in csv.reader(f,skipinitialspace=True):
            if len(row)<7 or row[1].lower() not in lengths:continue
            s=row[6].strip();assert len(s)==int(row[5]) and set(s)<=set('ACGT')
            lengths[row[1].lower()]+=len(s)
    assert lengths=={'scaffold':counts['scaf'],'staple':counts['stap']}
    scaf,staples=adapter.adapt(jp,seq,work/'validated_staple_endpoints.csv')
    assert scaf==counts['scaf']
    cp=next(jp.parent.glob('*_CNDO.cndo'));cn=cndo_audit.cndo(cp)
    assert cn['nucleotides']==sum(counts.values())
    op=next(jp.parent.glob('*_PLY.ply'));ox,of,og=readply(op)
    assert nx.is_isomorphic(g,og),'output_skeleton_changed'
    # Verify TALOS actually read the intended mesh and selected cross-section.
    log=(work/'talos.log').read_text()
    for label,value in [('faces',2*len(g)-4),('points',len(g)),('edges',g.number_of_edges()),('duplexes',6),('rows',3),('columns',2)]:
        assert re.search(r'The number of '+label+r'\s*:\s*'+str(value)+r'\b',log),('talos_read_count',label)
    assert re.search(r'The minimum edge length\s*:\s*42\b',log)
    assert re.search(r'Vertex design\s*:\s*'+vertex+r' vertex',log)
    ep=jp.parent/'TXT_Edge_Length.txt'
    table=[list(map(int,line.split())) for line in ep.read_text().splitlines()[1:1+6*g.number_of_edges()] if line.strip()]
    assert len(table)==6*g.number_of_edges()
    assert len({r[0] for r in table})==len(table)
    assert {(r[1],r[2]) for r in table}=={(i,k) for i in range(1,g.number_of_edges()+1) for k in range(6)}
    assert all(r[3]>0 for r in table)
    # Check each skeleton edge is present in the TALOS mesh. BILD route/6E
    # caDNAno helix counts supplement this; no unsupported spatial contraction.
    return dict(scaffold_nt=scaf,staple_nt=counts['stap'],total_nt=sum(counts.values()),staples=staples,helix_count=len(vs),connectivity_and_sequence_pass=True,output_skeleton_isomorphic=True,six_cross_sections_per_original_edge=True,cndo=cn,output_ply=str(op.relative_to(work)),cadnano=str(jp.relative_to(work)),output_hashes={str(p.relative_to(work)):sha(p) for p in (jp,seq,cp,op,ep,work/'validated_staple_endpoints.csv')})
