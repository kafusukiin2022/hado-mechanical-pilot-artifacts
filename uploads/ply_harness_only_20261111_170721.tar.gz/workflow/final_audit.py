import sys,json,time,collections,concurrent.futures
from pathlib import Path
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B))
import networkx as nx
import numpy as np
from pipeline import canonical,dump,sha,graph,readply
from geometry import validate
from route_variant import route_audit
OUT=B/'low_nt_v2/batch1000'
def one(row):
 w=OUT/row['id'];top=json.loads((w/'topology.json').read_text());g=nx.Graph(top['edges']);code=canonical(g);assert code==top['canonical_graph6']
 for name in ('initial','optimized'):
  p=w/(name+'.json')
  if p.exists():
   d=json.loads(p.read_text());x=np.asarray(d['coordinates_nm']);validate(x,d['faces'],list(g.edges()));assert nx.is_isomorphic(g,graph(d['faces'],len(x)))
   px,pf,pg=readply(w/(name+'.ply'));np.testing.assert_allclose(px,x,atol=1e-8);assert nx.is_isomorphic(g,pg)
 variants=[('mitered',w,row)]
 if (w/'flat/result.json').exists():variants.append(('flat',w/'flat',json.loads((w/'flat/result.json').read_text())))
 good=[]
 for vertex,folder,r in variants:
  if r['status'] not in ('routing_accepted','large_scale_group'):continue
  a=route_audit(folder,g,vertex)
  for k in ('scaffold_nt','staple_nt','total_nt','output_hashes'):assert a[k]==r[k],(row['id'],vertex,k)
  assert (r['status']=='routing_accepted')==(a['total_nt']<=30000)
  good.append(dict(vertex=vertex,folder=str(folder.relative_to(OUT)),**a))
 best=min(good,key=lambda r:r['total_nt']) if good else None
 return dict(id=row['id'],V=len(g),canonical=code,valid_routes=len(good),selected=best,status=('routing_accepted' if best['total_nt']<=30000 else 'large_scale_group') if best else 'failed')
if __name__=='__main__':
 t=time.time();m=json.loads((OUT/'manifest.json').read_text());f=json.loads((OUT/'flat_manifest.json').read_text());assert m['status']=='batch_complete' and m['processed']==1000 and f['processed']==f['target']
 with concurrent.futures.ProcessPoolExecutor(max_workers=12) as pool:rows=list(pool.map(one,m['rows']))
 assert len({r['canonical'] for r in rows})==1000
 accepted=[r for r in rows if r['status']=='routing_accepted'];byv={str(v):dict(attempted=sum(r['V']==v for r in rows),accepted=sum(r['V']==v for r in accepted)) for v in range(4,12)}
 d=dict(pass_all=True,count=1000,counts=dict(collections.Counter(r['status'] for r in rows)),by_vertices=byv,accepted_total_nt_range=[min(r['selected']['total_nt'] for r in accepted),max(r['selected']['total_nt'] for r in accepted)],accepted_scaffold_le7249=sum(r['selected']['scaffold_nt']<=7249 for r in accepted),accepted_by_vertex=dict(collections.Counter(r['selected']['vertex'] for r in accepted)),mitered_wall_s=m['wall_s'],flat_wall_s=f['wall_s'],audit_wall_s=time.time()-t,unique_within_batch=True,novel_vs_history_required=False,physical_simulation=False,rows=rows)
 dump(OUT/'final_audit.json',d);print(json.dumps({k:v for k,v in d.items() if k!='rows'},indent=2))
