# PLY + harness-only 交接包

本包只含448个最终选定PLY、harness记录和相关流程/审计脚本。

明确不含：TALOS生成的caDNAno JSON、sequence CSV、CNDO、Default.snp输入副本、TALOS/MANGO编译环境、SNUPI可执行文件、MATLAB Runtime、SNUPI OUTPUT/MAT/PSF/PDB。

因此本包不能直接在远程服务器运行SNUPI；它只能用于查看骨架、保留实验记录和重建流程。要继续SNUPI，仍需另外传输每个设计对应的caDNAno JSON、sequence CSV和配置文件。

PLY_MANIFEST.json给出448个PLY的设计ID、flat/mitered类别、核苷酸统计和SHA256。原始脚本中的绝对路径、Slurm作业号和本机环境不能原样执行。
