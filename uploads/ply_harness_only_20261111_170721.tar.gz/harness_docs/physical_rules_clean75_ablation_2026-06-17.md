# Physical Rules Clean75 Ablation - 2026-06-17

## Purpose

Run the physical-rule ablation on the full clean75 dataset using a uniform nucleotide-count train/validation split.

User requirements:

- Use the same configuration family as the small3 ablation.
- Use full clean75: 60 train / 15 validation.
- Use `nt-stratified` splitting so train/val are balanced by nucleotide count.
- Leave at least one GPU unused.
- Record this as a concrete result entity and reference it from the main harness.

## Result Entity

- Output root: `outputs/clean75_pair_rule_ablation_20260617/`
- Pair-label manifest: `outputs/manifests/nupack_2e6_2000_all_clean75_with_pair_labels.json`
- Pair-label report: `outputs/manifests/nupack_2e6_2000_all_clean75_pair_label_report_2026-06-17.json`
- Runner: `outputs/clean75_pair_rule_ablation_20260617/run_one.sh`

## Pair Labels

Generated start/final oxDNA pair-label files for all 75 clean designs.

- Entries: `75`
- Missing pair files: `0`
- Pair files written under: `outputs/pair_labels/clean75/`

## Planned First Matrix

All runs use:

- manifest `outputs/manifests/nupack_2e6_2000_all_clean75_with_pair_labels.json`
- split mode `sample`
- split strategy `nt-stratified`
- val fraction `0.2`
- 10 epochs
- seed `1`
- 428320-like DGNN-lite hyperparameters:
  - hidden `512`
  - message steps `5`
  - Fourier features `8`
  - design features `stats`
  - graph mode `backbone`
  - optimizer `adamw`
  - learning rate `0.0005`
  - weight decay `0.01`
  - orientation loss weight `5.0`

First matrix:

| Run | Purpose |
|---|---|
| `c0_baseline_no_pair_rules` | full clean75 baseline, no pair-rule switches |
| `c1_candidate_wc_edges` | isolate candidate-WC ordinary message-graph mixing |
| `c2_pair_assignment_loss` | candidate-WC edges plus pair classification and pair-logit symmetry |

GPUs used for the first matrix:

- GPU4
- GPU5
- GPU6

GPU7 is intentionally left unused.

## Status

Initialized. Runs are expected to write `summary.json` into their run directories. Main results should be summarized into `outputs/clean75_pair_rule_ablation_20260617/summary_table.csv` after completion.

