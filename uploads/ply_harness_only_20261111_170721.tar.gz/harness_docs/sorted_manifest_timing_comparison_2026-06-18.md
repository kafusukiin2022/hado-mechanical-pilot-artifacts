# Clean75 Sorted Manifest Timing Comparison

Date: 2026-06-18

## Goal

Compare early-epoch DGNN-physic training cost for the original clean75 manifest
versus a size-sorted manifest.

## Probes

- Unsorted probe:
  `outputs/local_dgnn_physic_clean75_short_probe_timing_20260618_1330_v2/`
- Sorted-manifest probe:
  `outputs/local_dgnn_physic_clean75_sorted_probe_20260618_1345/`

The sorted manifest was produced by ordering
`outputs/manifests/nupack_2e6_2000_all_clean75_with_pair_labels.json` by
`sample.num_nucleotides` using `load_oxdna_sample(...)`.

## Observations

The first training sample is similarly cheap in both runs:

- Unsorted first sample: `0.511s`
- Sorted first sample: `0.492s`

The benefit comes from avoiding heavy designs at the front of the epoch:

| Prefix | Unsorted | Sorted |
| --- | ---: | ---: |
| First 5 training samples | `105.542s` | `4.665s` |
| First 10 training samples | `161.642s` | `27.263s` |
| First 20 training samples | `337.755s` | `176.099s` |

The unsorted run starts with `105_honeycomb-74-final2`, `193_Hexagon_mesh_4HB`,
and `102_3`, which are among the slowest samples. The sorted run starts with
smaller designs such as `101_50_bp_nicked`, `11_Nanolett_Burns_Howorka_2013`,
and `12_26._Burns_Howorka_ACIE_2013`.

## Conclusion

Early-epoch wall time is strongly dominated by sample order. A size-sorted
manifest materially improves the first-epoch training profile and should be
used for the next full clean75 validation run.
