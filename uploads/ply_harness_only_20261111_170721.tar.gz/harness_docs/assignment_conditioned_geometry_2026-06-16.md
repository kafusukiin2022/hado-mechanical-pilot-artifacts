# Assignment-Conditioned Geometry Training

Date: 2026-06-16

## Goal

Achieve high pair F1 AND val RMSD/OS→0/1 on clean75 60/15 split.

## Strategy

Current status: pair assignment F1=0.898 but RMSD=34.72, OS=0.027.

**Solution:** Two-stage approach:
1. Stage 1: Train pair assignment head (already works)
2. Stage 2: Freeze pair head, train coordinate decoder conditioned on decoded pairs

## Implementation Plan

1. Add `--freeze-pair-head` flag
2. Add pair-conditioned coordinate refinement loss
3. Train stage 1: 50e pair assignment focus
4. Train stage 2: 200e coordinate realization with frozen pairs

## Budget: $70 max
- Use CodeGraph for code navigation
- Exponential backoff sleep during training wait
- No polling loops

## Execution Log

### Stage 1: Pair Assignment Training (50e)

**Started:** 2026-06-16 17:10
**PID:** 37497
**Config:**
- Data: small3, val=101_50_bp_nicked
- Model: dgnn-lite, hidden=512, steps=5, fourier=8
- Losses: pair_classification=0.05, symmetry=0.05, orientation=5.0
- LR: 5e-4, device: cuda:1

**Status:** Running, waiting with exponential backoff (10s→20s→40s...→300s max)

**Output:** outputs/stage1_pair_assignment_50e/

### Results

(Waiting for stage 1 completion)
