# Clean76 Energy Direction Summary - 2026-06-23

This note consolidates the verified directions from the recent clean74/clean75/
clean76 conversation. It is intentionally compact; detailed run logs remain in
`progress.md`, `session-handoff.md`, and each `outputs/*/run.log`.

## Current Target

- Train clean76 at nucleotide level, including `105_honeycomb-74-final2` and
  `triangle_repaired_tacoxdna_a30_3000k` in the train set.
- Keep RMSD, OS, oxDNA-inspired differentiable energy loss, best checkpointing,
  and normal deep-learning tricks such as AdamW, LR scheduling, and grad
  clipping.
- Do not reintroduce pair-node graph/metric details for the current objective.
- Do not use W&B by default. The hidden256/mp4 GPU4 run is a one-off explicit
  user-requested W&B exception.

## Verified Feasible Directions

- Nucleotide-level `dgnn-lite` graph construction is runnable on clean76 and is
  the current trusted baseline.
- The differentiable GPU oxDNA-inspired surrogate loss is runnable inside the
  training loop. It includes backbone, stacking, hbond, cross-stack, and capped
  excluded-volume terms, but remains a training surrogate rather than calibrated
  native oxDNA.
- Keeping RMSD/OS as metrics while using energy loss for double-helix pressure
  is operationally practical and cheap enough for long runs.
- `105_honeycomb-74-final2` and triangle can be included in the clean76 train
  set with the current nucleotide-level path.
- Detached local runs via `setsid ... &` are working for long A100 jobs and
  survive the interactive session boundary; current evidence includes PPID `1`
  and matching SID for launched Python processes.
- Train-OS model selection is useful for the current overfit/convergence search.
  GPU0 hidden256/mp3/orient4/train-OS and GPU7 hidden128/mp2/orient3/energy0.1
  are the main matched-epoch references.
- CodeGraph CLI is usable and should remain the first structural lookup path.
  Verified commands include `codegraph status .`, `codegraph query ...`, and
  `codegraph node ...`.

## Verified Weak Or Infeasible Directions

- Pair-node metrics and pair-node graph details are misaligned with the current
  user objective. They were removed from the default path; reference pairs are
  only retained where needed for energy interactions or opt-in diagnostics.
- Old WC/helix/pair-rule losses and slow final physical metrics are not part of
  the current default training objective. They add complexity and runtime, and
  are now opt-in only.
- The previous clean75 duplex/nonpair-repulsion path was too heavy for the
  largest sample: it OOMed around `105_honeycomb-74-final2` unless the expensive
  all-cross-strand nonpair term was disabled. This motivated the current
  cleaner energy-surrogate direction.
- W&B-by-default is explicitly disallowed by the user. Use local logs and
  harness records unless a specific request overrides this for one run.
- GPU7 `model_best.pt` should not be treated as a generalization success:
  W3 validation metrics were weak (`val/rmsd=15.637760130564372`,
  `val/os=0.4105862743531664`, `val/oxdna_energy_loss=8.68468721707662`).
- Increasing width/depth alone is unproven. Hidden256/mp3 is mixed, and
  hidden256/mp4 is currently only a depth probe until matched-epoch metrics beat
  GPU0/GPU7.

## Active Evidence Points

- GPU7 mature baseline:
  `outputs/local_clean76_energy_sweep_orient3_hidden128_mp2_energy01_10000e_20260623_gpu7_localonly/`
  reached strong train/latest energy and OS regions, but saved best val was
  poor.
- GPU0 train-OS direction:
  `outputs/local_clean76_energy_sweep_hidden256_mp3_orient4_energy01_trainos_10000e_20260623_gpu0_localonly/`
  is the strongest current train-OS comparison direction.
- GPU4 hidden256/mp4 W&B depth probe:
  `outputs/local_clean76_energy_sweep_hidden256_mp4_orient3_energy01_trainos_lr5e4_wandb_10000e_20260623_gpu4/`
  is detached as PID `23954`, W&B run `wwq211x6`, and has reached epoch
  training. It tests whether more message-passing depth helps.
- GPU7 best-checkpoint val artifact:
  `outputs/eval_gpu7_best_clean76_val_20260623/summary.json`.

## Next Decision Rules

- Compare runs at matched epochs, not just latest wall-clock state.
- Prefer configurations that improve OS/RMSD without causing energy to rise
  sharply.
- If hidden256/mp4 is slower and does not beat GPU0/GPU7 by several hundred
  epochs, mark depth-only scaling as weak and move to architectural changes
  such as LayerNorm or gated residual updates.
- Keep future runs local-only unless W&B is explicitly requested again.
