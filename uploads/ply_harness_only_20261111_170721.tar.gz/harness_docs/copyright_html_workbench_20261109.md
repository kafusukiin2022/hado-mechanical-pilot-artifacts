# 软著 HTML 工作台收尾计划（2026-11-09）

## 接续依据

现有入口：`outputs/oxDNA_software_copyright_V1.0_reviewfix_20261013/05_可复现源码/ui/index.html` 与 `app.py`（今天14:43–14:44）。已有14:45预测产物不能代替浏览器验收。
已检查顶层 feature_list/progress/handoff、软著包内 Markdown/JSON、docs计划文件及.loophaus任务状态，尚未找到本次UI的独立历史计划；此文件是本轮补建的收尾清单，不冒充原计划。

## 边界

保留现有绿白界面与固定 dgnn-lite 权重，仅完善本地UI工作流；不训练、不提交GPU任务、不修改旧软著ZIP或法律身份材料。

## 待办与验收

- [x] 校验输入、失败/重新载入时清理旧结果；禁止运行中更换输入。
- [x] 修复服务端并发启动与旧输出下载；验证错误请求。
- [x] 导航到结构检查与本次运行记录；切换输入/输出预览；即时缩放与资源释放。
- [x] 将Three.js及其许可放入UI目录，消除外部项目绝对路径依赖。
- [x] 提供启动命令和使用说明。
- [x] CPU真实模型端到端浏览器验证、文件上传/错误/下载/移动宽度截图；运行原25项测试。
- [x] 保存验证记录并更新feature/progress/handoff。

## 完成与证据

浏览器14项验收通过、0 page errors：`outputs/copyright_html_workbench_20261109/browser_verification.json`；桌面与390px截图 `loaded.png`、`complete.png`、`mobile.png`。内置示例与浏览器上传均真实CPU推理；下载逐字节相等；原25项测试PASS见`unit_tests.log`，init/py_compile通过。Three.js 108dev不具备InstancedMesh，已适配为完整节点Points+骨架LineSegments。修复了异步输入竞态、旧下载/失败输出、重复POST以及即时相机缩放。

独立可运行ZIP `outputs/copyright_html_workbench_20261109/oxDNA_V1.0_HTML_workbench_20261109.zip`：36文件，CRC通过，完整SHA清单见package_manifest.json；不含历史results与缓存。旧软著ZIP未改；正式申请材料尚需另外同步UI范围。没有找到原UI历史计划，本文件明确为本轮补建。
