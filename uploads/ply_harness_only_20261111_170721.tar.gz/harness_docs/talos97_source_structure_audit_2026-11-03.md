# TALOS97 原始输入结构审计（2026-11-03）

## 结论

对 TALOS97 的 97 个原始 `initial.dat`、`design.top`、`topology_to_cadnano.json`、`designed_pairs.txt` 和输入缓存做了只读检查；不读取标签、不训练、不使用 GPU，也没有修改结构或标签。

- **没有发现能从原始输入几何单独解释 6hb_009 极端 RMSF 标签的特异异常。** 009 的骨架长边数低于全体中位数；排除拓扑两跳邻居和设计碱基配对后，`<0.2 nm` 非局部近邻为 6 对，而全体中位数为 21 对。015 的 21 对正好处于中位数。因而此前 009/015 的强污染证据仍指向续跑轨迹/标签，不是这项初始结构筛查。
- **发现一个覆盖全部 97 个设计的系统性输入候选：** 每个设计有 22–38 条“同 virtual helix、相邻 axial index”的拓扑骨架边，最短也超过 2 nm，最大为 3.56–5.82 nm（中位数 4.60 nm）。全体共 2,964 条。它们不能按当前 mapping 直接视为损坏：所有设计都出现类似模式，可能是 virtual-helix/axial 映射、交叉连接或初始构造对位的系统现象。应优先核验映射和原始 caDNAno/oxDNA 拓扑对应关系，而不是按设计删样本。
- **筛出的非局部重合候选分散于多个设计，009 不突出。** 排除拓扑距离不超过 2 和已设计配对后，`<0.2 nm` 对数最多的是 094（63）、047（59）、063（57）、035（50）；`<0.3 nm` 最多的是 047（178）。这些只是静态筛查候选，近邻阈值不是自动剔除规则，需回到拓扑和三维构型逐对确认。
- **其余一致性检查正常。** 97 个设计的输入缓存均可还原原始坐标，最大绝对误差不超过 `1.20e-6` oxDNA 长度单位，缓存 backbone edge 集合与 `design.top` 一致。设计碱基配对距离在全部设计上均约为 0.920 nm（范围 0.91988–0.92069 nm）；`a1/a3` 向量长度接近 1，未见明显非有限值或缓存错位信号。

## 指标解释

拓扑 backbone 距离使用原始坐标与盒长做最小镜像，换算系数为 `0.8518 nm / oxDNA unit`。不同类别必须分开解释：同一 virtual helix 且 axial index 相邻的边本应优先作映射/拓扑一致性核验；跨 virtual helix 的长边大量存在，可能包含合法 crossover，不能把“>1 nm”一概当作坏键。近邻搜索排除了 backbone 图距离不超过 2 的节点对以及设计配对，仍可能包含结构设计中有意形成的密集接触。

本审计不能证明输入结构物理上完全有效，也不能用初始几何代替全轨迹物理 QC。已有 `rmse_floor_diagnosis_20261103/REPORT_ZH.md` 显示 009/015/024/047/051 的 continuation 轨迹存在大能量异常；009/015 有严重坐标/键长失稳。原始几何筛查与轨迹标签 QC 是不同证据链。尤其不能因为 047/024/051 初始几何有一些近邻候选，就推断其标签一定被污染；反之也不能仅凭 RMSF 数值正常就确认轨迹有效。

## 复算入口与产物

- 脚本：`experiments/talos97_rmsf_scalar/input_source_audit_20261103/audit.py`
- 完整逐设计 JSON（含输入文件 SHA-256、距离分布和计数）：`experiments/talos97_rmsf_scalar/input_source_audit_20261103/input_source_audit.json`
- 输入构建流程：`experiments/talos97_endpoint_v1/scripts/build_dataset.py`
- 原始数据根目录：`experiments/talos97_endpoint_v1/data/`
- 运行命令：`/home/lijingjing/lijj/.conda/envs/ebd/bin/python experiments/talos97_rmsf_scalar/input_source_audit_20261103/audit.py`

复算前应确认源文件仍与 JSON 中记录的 SHA-256 一致；阈值仅用于筛查和排序，不自动改变数据集纳入状态。下一步应检查 2,964 条系统性长边是否与 mapping/拓扑转换的边界定义有关，并对高近邻候选（尤其 047、094、063、035、024）做节点级可视化或拓扑逐对审查。若要对标签作任何清洗，需先依据预先确定的物理轨迹 QC 标准并单独记录数据负责人决策。
