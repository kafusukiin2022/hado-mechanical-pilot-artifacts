# WC Edge Mode Clean75 Ablation - 2026-06-17

## Purpose

Compare how target-geometry Watson-Crick candidate edges should interact with DGNN-lite on full clean75.

User requirement:

- Use clean75 with nucleotide-count-balanced `60` train / `15` validation split.
- Run directly on current-node A100 GPUs, no Slurm.
- Compare:
  - current/full candidate WC message-passing edges,
  - pairwise/readout-only WC edges with no coordinate message propagation,
  - final-layer-only WC edge injection,
  - baseline/current no-WC-edge run for RMSD/OS comparison.
- Evaluate whether RMSD/OS can remain lower while pair assignment/base-pair physical metrics improve.

## Code Change

- `scripts/ebd_oxdna_shared_rigid_train.py`
  - Added `--wc-edge-mode {message_all,readout_only,last_layer}`.
  - `message_all`: candidate WC edges are ordinary graph edges and also use the pair-message branch every layer.
  - `readout_only`: candidate WC edges are present for pair logits/readout and pair losses, but are excluded from coordinate/orientation message passing.
  - `last_layer`: candidate WC edges are excluded from ordinary message passing and only inject pair-message information on the final message-passing step.
  - Added separate `candidate_wc_edge_mask`; this is distinct from `pair_supervision_edge_mask`.
- Candidate WC edges are already target/last oxView-like KD-tree edges from the preceding update.

## WC Edge Source Decision

Use `.top + target/last.conf + KD-tree` to generate candidate Watson-Crick edges.

Current rule in `scripts/ebd_oxdna_shared_rigid_train.py`:

- `load_oxdna_sample(entry["top"], entry["start"], entry["target"])` loads `.top`, start, and target/last coordinates.
- `_target_wc_edges_oxview_like(sample, candidate_wc_cutoff)` uses `sample.target_positions` and `sample.target_a1`, not `start.conf`.
- nucleoside/base-search center is `center_of_mass + 0.34 * a1`.
- cutoff defaults to `0.6` when `--candidate-wc-cutoff 0.0`.
- candidates are filtered by Watson-Crick complementarity, cross-backbone-neighbor exclusion, and `a1 dot < -0.85`.
- matching is one-to-one nearest within the KD-tree neighbor lists.

Do not use the old start-position O(N^2) `_candidate_wc_edges(...)` path for new clean75 WC-edge comparisons. The active graph/readout paths call `_target_wc_edges_oxview_like(...)` through `_build_graph_edges(...)` and `_prepare_sample(...)`.

## Verification

Passed:

```bash
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli -v
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py
./init.sh
```

Key tests:

- `test_dgnn_lite_readout_only_pair_edges_do_not_change_coordinate_message_passing`
- `test_dgnn_lite_last_layer_pair_edges_change_output_only_at_readout_step`
- `test_pair_losses_can_be_restricted_to_candidate_wc_edges`
- `test_candidate_wc_edges_are_inferred_from_target_geometry`

## Output Root

- `outputs/clean75_wc_edge_mode_ablation_20260617/`
- Runner: `outputs/clean75_wc_edge_mode_ablation_20260617/run_one.sh`
- Summary helper: `scripts/summarize_wc_edge_mode_ablation.py`
- Summary CSV: `outputs/clean75_wc_edge_mode_ablation_20260617/summary_table.csv`

All new runs use:

- manifest `outputs/manifests/nupack_2e6_2000_all_clean75_with_pair_labels.json`
- `--split-mode sample`
- `--split-strategy nt-stratified`
- `--val-fraction 0.2`
- 10 epochs
- seed `1`
- DGNN-lite, hidden `512`, message steps `5`, Fourier features `8`, design features `stats`
- graph mode `backbone`
- optimizer `adamw`, learning rate `0.0005`, weight decay `0.01`
- orientation loss weight `5.0`
- candidate WC edges from `.top + target/last.conf` KD-tree geometry
- pair classification and pair-logit symmetry weights `0.02`

## Launched Runs

| Run | GPU | PID file | Meaning |
|---|---:|---|---|
| `w1_message_all` | 5 | `outputs/clean75_wc_edge_mode_ablation_20260617/w1_message_all.pid` | Full candidate WC message passing every layer |
| `w2_readout_only` | 6 | `outputs/clean75_wc_edge_mode_ablation_20260617/w2_readout_only.pid` | Pairwise readout/loss only; no WC coordinate message propagation |
| `w3_last_layer` | 7 | `outputs/clean75_wc_edge_mode_ablation_20260617/w3_last_layer.pid` | WC pair-message only on final message-passing step |

Baseline:

- The valid current comparison uses a freshly relaunched `baseline_no_wc` row under the same fixed root as the WC-edge rows.
- Do not mix in old baseline rows from `outputs/clean75_pair_rule_ablation_20260617/` or `outputs/clean75_wc_edge_mode_ablation_fast_20260617/`.

## Monitor

Check processes:

```bash
ps -p 34579,34580,34581,34582 -o pid,ppid,stat,etime,time,%cpu,%mem,cmd
```

Check logs:

```bash
tail -f outputs/clean75_wc_edge_mode_ablation_fixed_20260617/baseline_no_wc/run.log
tail -f outputs/clean75_wc_edge_mode_ablation_fixed_20260617/w1_message_all/run.log
tail -f outputs/clean75_wc_edge_mode_ablation_fixed_20260617/w2_readout_only/run.log
tail -f outputs/clean75_wc_edge_mode_ablation_fixed_20260617/w3_last_layer/run.log
```

Check GPU:

```bash
nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits
```

Generate/update summary table:

```bash
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python scripts/summarize_wc_edge_mode_ablation.py \
  --root outputs/clean75_wc_edge_mode_ablation_fixed_20260617 \
  --output-csv outputs/clean75_wc_edge_mode_ablation_fixed_20260617/summary_table.csv \
  --run baseline_no_wc:outputs/clean75_wc_edge_mode_ablation_fixed_20260617/baseline_no_wc \
  --run message_all:outputs/clean75_wc_edge_mode_ablation_fixed_20260617/w1_message_all \
  --run readout_only:outputs/clean75_wc_edge_mode_ablation_fixed_20260617/w2_readout_only \
  --run last_layer:outputs/clean75_wc_edge_mode_ablation_fixed_20260617/w3_last_layer
```

## Current Status

Last meaningful check: `2026-06-17 14:50 CST`.

- Invalid roots:
  - `outputs/clean75_wc_edge_mode_ablation_20260617/`: superseded by KD-tree/target-geometry and zero-weight-loss fixes.
  - `outputs/clean75_wc_edge_mode_ablation_fast_20260617/`: invalid because the WC rows OOMed in `_pair_logit_sinkhorn_loss` even though the sinkhorn weight was `0.0`; baseline PID `33136` was also stopped to avoid mixed-code comparisons.
- Fix added after RED/GREEN test:
  - zero-weight `_pair_logit_exclusivity_loss`, `_pair_logit_sinkhorn_loss`, and `_pair_partner_selection_loss` are no longer evaluated in train/validation when their weights are `0.0`.
  - zero-weight `_pair_classification_loss` and `_pair_logit_symmetry_loss` are also skipped. This mainly matters for `baseline_no_wc`, where both weights are `0.0`; the WC rows explicitly keep both weights at `0.02`.
  - baseline no longer falls back to dense reference-pair endpoint conflict logging when all conflict-style weights are `0.0`; this avoids O(P²) `torch.cdist` in epoch logs.
- Active comparison root:
  - `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/`
- Active PIDs:
  - `baseline_no_wc`: `37728` on GPU4
  - `message_all`: `37732` on GPU5
  - `readout_only`: `37736` on GPU6
  - `last_layer`: `37839` on GPU7
- Invalid fixed-root baseline:
  - `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/baseline_no_wc_invalid_pre_pairlogit_gating_34579`
  - Stop reason: still CPU-bound before epoch 1 because pair classification/symmetry were evaluated despite zero weights.
  - `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/baseline_no_wc_invalid_pre_conflict_gating_35594`
  - Stop reason: still CPU-bound before epoch 1 because epoch conflict logging fell back to dense reference-pair endpoint `cdist` despite zero conflict-style weights.
- Additional invalid fixed-root rows after the final-eval KD-tree fix:
  - `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/baseline_no_wc_invalid_pre_physical_metrics_kdtree_143940`
  - `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/w1_message_all_invalid_pre_physical_metrics_kdtree_143940`
  - `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/w2_readout_only_invalid_pre_physical_metrics_kdtree_143940`
  - `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/w3_last_layer_invalid_pre_physical_metrics_kdtree_143940`
  - Stop reason: these rows trained, then stalled in final physical metrics/export before `summary.json`; no model checkpoint was saved, so fixed eval could not be rerun without full training.
- All four active rows use the same clean75 nt-stratified 60/15 split and same intended 10-epoch settings. WC rows use target/last KD-tree candidate WC edges and pair classification/symmetry weights `0.02`.
- At the last check:
  - `baseline_no_wc`: epochs 1-10 printed; final eval/export active; two `.conf` files existed.
  - `message_all`: epoch 2 loss `1338481.97772`, position loss `1338208.62849`, OS `0.00842830601857`
  - `readout_only`: epoch 2 loss `363.55560112`, position loss `356.654838943`, OS `0.026903969385`
  - `last_layer`: epoch 2 loss `376.24649531`, position loss `369.616463089`, OS `0.0267602715994`
- The summary table includes the required comparison columns: RMSD/OS, decoded pair F1/conflict, raw WC F1/conflict, WC score, pair-distance RMS error, and helix-axis score.

## Next Step

After summaries are written, compare:

- validation RMSD/OS,
- raw WC F1 / conflict,
- decoded pair assignment F1 / conflict,
- pair-distance RMS error,
- helix-axis score.

The desired outcome is not merely better pair F1; it must preserve or improve RMSD/OS while improving base-pair physicality.
