# Physical Rules Harness

Date: 2026-06-16

## Relationship To 2026-06-15 Harness

This file is the direct continuation of:

- `docs/harness/physical_rules_2026-06-15.md`

Keep both files as the same dated physical-rule series. The 2026-06-15 file records the explicit-label DGNN-lite probes and the key finding that one-to-one pair-logit assignment is much better than raw geometric cutoff pairing. This 2026-06-16 file records the next structural step: converting decoded one-to-one assignments into an oxDNA-exportable coordinate diagnostic.

## Startup State

- `./init.sh` passed on 2026-06-16 and reported that this directory is not a git worktree.
- CodeGraph MCP tools were not exposed in this session, and `tool_search` found no `codegraph_*` tools. Structural exploration was done by direct source inspection plus `rg`.
- Current node exposed six NVIDIA A30 GPUs. No Slurm or A100 job was submitted.
- Required context files read:
  - `AGENTS.md`
  - `feature_list.json`
  - `progress.md`
  - `session-handoff.md`
  - `docs/OXDNA_OUTPUT_SPEC.md`
  - `docs/harness/physical_rules_2026-06-15.md`

## 2026-06-15 Carryover Interpretation

The prior blocker was not "the pair head has no Watson-Crick signal." The best prior comparable result was:

`outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_paircenter2e2_pairaxis2e2_assignmentmetrics_explicitpairs_physcmp_10e_lr1e3_w1e2/summary.json`

Held-out `101_50_bp_nicked`:

- raw geometric cutoff conflict stayed `1.0`
- decoded pair-logit assignment conflict was `0.0`
- decoded pair-logit assignment F1 was `0.7010`

Interpretation: the pair head contains useful one-to-one assignment information, but the nucleotide coordinate output does not realize that assignment physically. The next useful step is structural coordinate/export realization, not another small scalar-loss sweep.

## Code Changes

Updated `scripts/ebd_oxdna_shared_rigid_train.py`:

- Added `--write-assignment-realized-conf`.
- Added `assignment_realized_*` per-sample summary fields.
- Added `_realize_decoded_pair_geometry(...)`.
  - It takes decoded one-to-one pair-logit assignments.
  - It realizes only decoded pairs that match explicit reference pairs.
  - It uses target explicit pair center/axis geometry as a diagnostic realization, not as target-free model generalization.
- Added `_repel_nonselected_cross_pairs(...)`.
  - It treats decoded pairs as rigid two-node groups and can push non-selected cross-strand close contacts outside a margin.
  - CLI controls:
    - `--assignment-realized-repulsion-margin`
    - `--assignment-realized-repulsion-steps`
  - This path is implemented and unit-tested, but no completed A30 result exists yet.
- Fixed two bugs exposed by the new tests:
  - `_prepare_sample(...)` now carries `candidate_wc_edges` into prepared samples and `_prepared_on_device(...)`.
  - `reference_pair_assignment_margin_loss(...)` is now called with a list of edge pairs rather than a `(2, E)` tensor.

Updated `tests/test_ebd_oxdna_shared_rigid_train_cli.py`:

- Added helper-level coverage for decoded assignment geometry realization.
- Added CLI coverage that `--write-assignment-realized-conf` writes an oxDNA `.conf` and records assignment-realized metrics.
- Added helper coverage for non-selected cross-pair repulsion.

## Verification

Passed:

```bash
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest \
  tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_assignment_realized_positions_use_decoded_pair_geometry \
  tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_cli_writes_assignment_realized_summary_and_conf -v
```

Passed:

```bash
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile \
  scripts/ebd_oxdna_shared_rigid_train.py \
  ebd_oxdna/physical_metrics.py \
  tests/test_ebd_oxdna_shared_rigid_train_cli.py
```

Passed full relevant suite:

```bash
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest \
  tests.test_physical_metrics \
  tests.test_ebd_oxdna_shared_rigid_train_cli -v
```

Result: `39` tests passed.

## Completed A30 Experiment

Completed bounded A30 run:

`outputs/manual_a30_small3_dgnn_assignment_realized_explicitpairs_physcmp_10e_lr1e3_w1e2/summary.json`

Configuration matched the 2026-06-15 pair-center/axis 10e explicit-label setup and added:

- `--write-assignment-realized-conf`

Held-out `101_50_bp_nicked`:

| Metric | Raw model output | Decoded assignment | Assignment-realized output |
|---|---:|---:|---:|
| RMSD | `32.086956` | n/a | `20.221945` |
| OS | `0.062329` | n/a | `0.062329` |
| WC/helix score | `0.314469` | n/a | `0.494286` |
| WC F1 | `0.158730` | `0.632653` | `0.450000` |
| Conflict rate | `0.990196` | `0.0` | `0.970588` |
| Pair distance RMS error | not primary | n/a | `1.351146` |
| Helix axis score | not primary | n/a | `0.364910` |

Output confs:

- `outputs/manual_a30_small3_dgnn_assignment_realized_explicitpairs_physcmp_10e_lr1e3_w1e2/101_50_bp_nicked.conf`
- `outputs/manual_a30_small3_dgnn_assignment_realized_explicitpairs_physcmp_10e_lr1e3_w1e2/101_50_bp_nicked_assignment_realized.conf`

Interpretation:

- Positive: assignment-realized export improved held-out RMSD from `32.09` to `20.22` and WC/helix score from `0.314` to `0.494`.
- Negative: geometric cutoff conflict stayed very high (`0.9706`). This means simply realizing matched decoded pairs with explicit pair geometry is not enough; many non-selected cross-strand contacts remain inside the cutoff.
- This is not final success and must not be described as solving Watson-Crick physicality.

## Interrupted Experiment

Started but stopped by user request:

`outputs/tmp_assignment_realized_repulsion_smoke/`

Purpose:

- Test `--assignment-realized-repulsion-margin 4.0`
- Test `--assignment-realized-repulsion-steps 8`
- Verify whether rigid-group non-selected cross-pair repulsion can lower geometric conflict after assignment realization.

Status:

- Process PID `37518` was terminated with `kill`.
- No `summary.json` was written before termination.
- Do not treat this as evidence for or against repulsion.

## Next Recommended Step

On the next server/session:

1. Re-read this file and `docs/harness/physical_rules_2026-06-15.md`.
2. Run `./init.sh`.
3. Verify GPU visibility.
4. Run a bounded completed A30 experiment using the same 10e small3/held-out `101_50_bp_nicked` setup, adding:
   - `--write-assignment-realized-conf`
   - `--assignment-realized-repulsion-margin 4.0`
   - `--assignment-realized-repulsion-steps 8`
5. Compare explicit-label held-out metrics against:
   - 2026-06-15 assignment metrics baseline
   - 2026-06-16 assignment-realized no-repulsion result above

Completion for this substep requires:

- raw geometric cutoff metrics,
- decoded one-to-one assignment metrics,
- assignment-realized metrics,
- export `.conf` paths,
- explicit statement of negative results if conflict remains high.

Do not claim final goal completion unless RMSD/OS materially improve and geometric conflict is structurally reduced, not just decoded assignment conflict.

## Explicit-Only Reference Correction

User correction on 2026-06-16:

- All datasets currently used here have explicit reference pairs available.
- Do not use geometric greedy matching to define Watson-Crick reference pairs.
- Do not emit or rely on `physical_rule_metrics_geometric_proxy` for explicit-reference samples.

Code changes:

- `scripts/ebd_oxdna_shared_rigid_train.py` now auto-resolves missing explicit reference paths during manifest load:
  - `virt2nuc` from the design's `tacoxdna/virt2nuc` next to `oxdna_run`.
  - cadnano json by recursively resolving `<design_id>.json` under `/home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/json`, overridable with `EBD_OXDNA_CADNANO_JSON_ROOT`.
- `_prepare_sample(...)` no longer constructs greedy geometric reference pairs when explicit cadnano-derived pairs are available.
- For explicit-reference samples:
  - `reference_pair_source = explicit_design`
  - `reference_pairs_geometric_proxy = None`
  - `helix_steps_geometric_proxy = None`
  - summary `physical_rule_metrics_geometric_proxy = None`
  - assignment-realized proxy fields are also `None`
- Greedy geometric reference remains only as fallback for genuinely non-explicit legacy data, not for clean75 or current small3 explicit-pair work.

Verification:

- Full relevant suite passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_physical_metrics tests.test_ebd_oxdna_shared_rigid_train_cli -v`
  - Result: `40` tests passed.
- Compile check passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
- Clean75 explicit path audit:
  - `_load_manifest('outputs/manifests/nupack_2e6_2000_all_clean75.json')`
  - entries: `75`
  - missing cadnano json: `0`
  - missing `virt2nuc`: `0`

## A100 Explicit-Only Assignment-Realized Variants

Completed direct CUDA A100 run on `gpu03`, without Slurm:

`outputs/manual_a100_small3_dgnn_assignment_realized_variants_explicitonly_physcmp_10e_lr1e3_w1e2/summary.json`

Configuration:

- small3 manifest with held-out `101_50_bp_nicked`
- explicit cadnano-derived references only
- `--write-assignment-realized-conf`
- default assignment realization uses no repulsion
- same decoded assignment exported with variants:
  - `none:0:0`
  - `margin3:3:8`
  - `margin4:4:8`
  - `margin5:5:8`

Held-out `101_50_bp_nicked`, explicit-only:

- `reference_pair_source = explicit_design`
- `physical_rule_metrics_geometric_proxy = None`
- `assignment_realized_physical_rule_metrics_geometric_proxy = None`

Raw model output:

- RMSD/OS: `46.091362 / 0.006588`
- WC/helix score: `0.240900`
- WC F1: `0.032258`
- conflict: `0.980392`

Decoded assignment:

- decoded pair count: `49`
- F1: `0.371134`
- precision/recall: `0.367347 / 0.375`
- conflict: `0.0`

Assignment-realized variants:

| Variant | RMSD | OS | WC/helix score | WC F1 | Precision | Recall | Conflict | Pair-distance RMS error | Helix-axis |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| none | `37.093647` | `0.006588` | `0.310344` | `0.1875` | `0.3750` | `0.1250` | `0.980392` | `2.119561` | `0.220492` |
| margin3 | `37.176517` | `0.006588` | `0.485829` | `0.476190` | `0.555556` | `0.416667` | `0.970588` | `2.859538` | `0.091965` |
| margin4 | `37.306782` | `0.006588` | `0.475220` | `0.428571` | `0.5000` | `0.3750` | `0.294118` | `4.490517` | `0.098394` |
| margin5 | `37.695126` | `0.006588` | `0.478684` | `0.433735` | `0.514286` | `0.3750` | `0.0` | `6.703440` | `0.125376` |

Interpretation:

- Positive: rigid-group repulsion can structurally reduce geometric conflict under explicit labels; `margin5` reached conflict `0.0`.
- Negative: this does not solve the full goal. RMSD stayed poor (`~37`), OS stayed near zero, and pair-distance RMS error worsened as repulsion increased.
- Conclusion: hard post-hoc repulsion proves conflict can be eliminated, but it damages or fails to repair geometry/orientation. The next aligned step should be pair-frame/base-pair-first coordinate realization with explicit reference pairs, not more scalar-loss sweeps and not geometric greedy references.

## Clean75 Explicit Reference Pair Coverage Correction

Important correction from 2026-06-16:

- Do not look only under `nupack/json/q4_bottom25_0.46_to_3.43` when resolving cadnano design files.
- The correct lookup root is:
  - `/home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/json`
- Recursively matching `<design_id>.json` under that root shows that all `75/75` designs in:
  - `outputs/manifests/nupack_2e6_2000_all_clean75.json`
  have both a cadnano json and:
  - `/home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/outputs/2e6_2000_all/<design_id>/tacoxdna/virt2nuc`
- All `75/75` clean75 designs parse to positive explicit cadnano-derived `reference_pairs` with the current `_load_explicit_reference_pairs(...)` logic.
- There were no missing json files, no missing `virt2nuc` files, no parse errors, and no zero-pair designs after recursive lookup.

This supersedes the earlier narrow-path conclusion that only `20/75` clean75 designs had explicit reference pairs. That earlier result was an artifact of checking only the q4 json subset.

Implication:

- Future physical-rule training/evaluation on clean75 should use explicit cadnano-derived `reference_pairs` for every design.
- Do not allow the other 55 clean75 designs to silently fall back to `geometric_proxy` just because the manifest omits `cadnano_json` / `virt2nuc` fields.
- Either enrich the manifest with resolved `cadnano_json` and `virt2nuc` paths, or update sample preparation to recursively resolve cadnano json paths from the full nupack json root before falling back to geometric proxy.

## Clean75 Cadnano JSON Same-Directory Copy

User requested a simpler filesystem-level fix: if json files are missing from the directory that previously held the 20 available q4 jsons, copy the remaining clean75 json files there so future code and agents can resolve them in one place.

Target directory:

- `/home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/json/q4_bottom25_0.46_to_3.43`

Action completed on 2026-06-16:

- Clean75 ids in `outputs/manifests/nupack_2e6_2000_all_clean75.json`: `75`
- Already present in target directory before copy: `20`
- Copied from recursive json root into target directory: `55`
- Missing after copy: `0`
- Existing files were not overwritten.

Copy report:

- `outputs/manifests/clean75_cadnano_json_copies_2026-06-16.json`

This complements the code-level recursive resolver. Future agents can now find all clean75 cadnano jsons directly in the q4 directory, but should still treat explicit cadnano-derived pairs as the only valid Watson-Crick reference source for these datasets.

## Explicit Base-Pair Frame Main-Loss Probe

User request on 2026-06-16:

- Put explicit base-pair frame supervision into the main training loss.
- Do not add only another scalar "two bases should be close" distance loss.
- Treat every Watson-Crick reference pair as a local structural unit.

Code changes:

- Added `reference_pair_frame_loss(...)` in `ebd_oxdna/physical_metrics.py`.
  - Uses explicit `reference_pairs`.
  - Penalizes pair center error.
  - Penalizes directed pair-axis misalignment.
  - Penalizes both paired nucleotides' `a1/a3` rigid-body frame misalignment.
- Wired it into `scripts/ebd_oxdna_shared_rigid_train.py`.
  - New CLI flag: `--pair-frame-loss-weight`.
  - Main train loss includes `pair_frame_loss_weight * pair_frame_loss`.
  - Epoch history records `pair_frame_loss`.
  - Summary records `pair_frame_loss_weight`.
- Added regression tests in:
  - `tests/test_physical_metrics.py`
  - `tests/test_ebd_oxdna_shared_rigid_train_cli.py`

Verification:

- RED: physical-metrics test first failed because `reference_pair_frame_loss` did not exist.
- RED: CLI test first failed because `--pair-frame-loss-weight` was unrecognized.
- Passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_physical_metrics tests.test_ebd_oxdna_shared_rigid_train_cli -v`
  - Result: `43` tests passed.
- Passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile ebd_oxdna/physical_metrics.py scripts/ebd_oxdna_shared_rigid_train.py tests/test_physical_metrics.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`
- Passed:
  - `./init.sh`

Completed direct CUDA A100 bounded run, no Slurm:

`outputs/manual_a100_small3_dgnn_pairframe_explicitonly_physcmp_10e_lr1e3_w1e2/summary.json`

Configuration:

- small3 manifest
- held-out `101_50_bp_nicked`
- explicit cadnano-derived references only
- candidate-WC top2 + pair classification + pair-logit symmetry + pair-center/axis
- added `--pair-frame-loss-weight 0.02`
- wrote assignment-realized variants:
  - `none:0:0`
  - `margin3:3:8`
  - `margin5:5:12`

Training last epoch:

- position loss `10.4081`
- approximate train RMSE `3.226`
- OS `0.410765`
- pair-frame loss `30.6326`

Held-out `101_50_bp_nicked`, explicit-only raw output:

| Metric | Value |
|---|---:|
| RMSD | `33.550110` |
| OS | `0.118516` |
| WC/helix score | `0.396362` |
| WC F1 | `0.137931` |
| Precision | `0.400000` |
| Recall | `0.083333` |
| Conflict | `1.0` |
| Pair-distance RMS error | `0.807973` |
| Helix-axis score | `0.162044` |

Decoded assignment:

- pair count `47`
- F1 `0.252632`
- precision/recall `0.255319 / 0.25`
- conflict `0.0`

Assignment-realized variants:

| Variant | RMSD | OS | WC/helix score | WC F1 | Conflict | Pair-distance RMS error |
|---|---:|---:|---:|---:|---:|---:|
| none | `29.010574` | `0.118516` | `0.398601` | `0.260870` | `1.0` | `0.740362` |
| margin3 | `29.324858` | `0.118516` | `0.465396` | `0.276596` | `0.990196` | `4.313007` |
| margin5 | `30.111982` | `0.118516` | `0.459461` | `0.252632` | `0.0` | `8.449968` |

Interpretation:

- The requested main-loss hook is implemented and verified.
- The bounded small3 result is negative: pair-frame loss at weight `0.02` did not improve held-out explicit WC physicality. Raw F1 fell to `0.1379`, and raw conflict stayed `1.0`.
- Repulsion can force geometric conflict to `0.0`, but at the cost of very poor pair-distance geometry (`8.45`) and RMSD around `30`.
- Do not claim completion from this result. The next aligned direction is a base-pair-first coordinate/output representation or an assignment-to-frame realization that preserves local pair geometry and orientation, still using explicit cadnano-derived references only.
