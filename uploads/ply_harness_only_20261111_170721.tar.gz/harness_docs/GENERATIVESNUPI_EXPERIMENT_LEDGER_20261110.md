# GenerativeSNUPI 实验总账与恢复说明

记录时间：2026-11-10T16:48:32.973630+08:00。优先级 **P0**。本总账是当前状态的统一入口；旧日志保留为历史证据，旧“正在运行”不代表现在仍运行。

## 目标、授权与范围

用户目标：生成DNA折纸后，先确认可信静态平衡，再运行随机动力学轨迹并计算RMSF；通过低成本预筛减少昂贵模拟。用户要求所有重要结果写入harness，允许申请A100/A6000进行加速测速。当前A6000分区实际GPU为RTX6000 Ada，用户已接受该分区。不要把GPU分区名称当实体型号。

本轮链条聚焦生成Circle及作者公开Circle；原TALOS新拓扑/41构型队列不在本次改动范围，未对其进行重启或重新审计。旧机器学习分类准确率、TALOS拓扑生成等历史仍在feature_list和progress原记录中，不因本次总账而改变状态。

## 当前结论与不能声称的结果

1. 已生成Circle、构建力学图，独立修改势能下静态平衡及条件NMA均已通过数值门槛。
2. 已完成8条0.2ns随机动力学短轨迹，保存1208帧；不是只生成静态扰动。
3. 已完成保持物理公式/双精度/时间步不变的加速测试，Ada约2.51倍、CPU约2.00倍。
4. 单核CPU短测速进程实际峰值263.36MiB；不是24h长轨迹内存上限。
5. **未复现官方SNUPI图输入接口、论文静态指标或1us随机动力学RMSF。** 当前独立过阻尼无水动力耦合模型，不是官方质量矩阵+广义RPY+GJF。
6. A100作业25376已提交、最近核实PENDING(Priority)，没有A100测速结果；不要重复提交。

## 实验与发现总表

|阶段|做过的工作与结果|解释/限制|
|---|---|---|
|模型推理与routing|官方Condition.pt，Circle，500扩散步；sampling42.66s、routing21.22s；生成CNDO/oxDNA/PDB及mean/seq图|原始756点，最终图753节点785边；1517nt、22条链|
|官方SNUPI输入|已有25138尝试3.10，日志报ERROR json file|未进入静态求解；输入失败不是物理不收敛，退出码0也不能判断通过|
|公开接口审计|mech_PE别名确实存在；total_PE按[:,::2]会丢392/785边，且未正确传edge_type|使用完整类型图直接机械能入口，未改上游源码|
|初步松弛|20轮LBFGS能量33876→2302；200轮作者/新Circle仍有残差|能量下降或优化器停下不等于静态平衡|
|硬截断定位|作者264↔695、新44↔543进入2.5nm邻域，双向计数跳变0.154854；分解误差<2e-13|确认公开Python势能不连续，不代表官方二进制内部完全同样处理|
|静态参考|论文训练集30增量Newton，力1e-3/能量1e-6；协议15迭代/增量及自适应细分|归一化定义未确定；不等于Circle实际终态值，不代表绝对能量<1e-6|
|材料/单元|117组局部材料参数参考能量/梯度/刚度检查，解析拉伸/扭转通过|全位姿二阶autograd在两个合成态出现非有限值；单边squeeze错误|
|有限差分Newton|合成单梁3步收敛；逐边7/12自由度方法实现完整稀疏切线|机械FD刚度+解析静电刚度，真实构型H·v终态误差<4e-9|
|完整图平衡|force-shift独立模型，作者/新Circle收敛；内部谱全正，去除6刚体模|平滑势改变了原模型；只能证明此修改模型局部数值稳定|
|NMA RMSF|作者2.66693nm、新3.74432nm，300K，全内部模态|不是随机轨迹RMSF；单位pN·nm有源码/协议支持，未逐材料列独立标定|
|短随机轨迹|两设计×两连续势×0.1/0.05ps，每条0.2ns；全8条完成|单种子、时间短、势切换有瞬态，不能宣称时间步/热平衡收敛|
|性能|单GPU原版27.16→10.81ms/步；单核CPU17.24→8.62ms/步|751节点3次400步中位数；长跑耗时是外推|
|内存|OS getrusage高水位269684KiB=263.36MiB=0.257GiB|短测速baseline+优化全过程；Slurm采样约262.74MiB，相符|

## 静态终态、论文对照与RMSF口径

|指标|作者公开Circle|新Circle|
|---|---:|---:|
|节点数|751|753|
|修改势能总能量（内部单位）|1211.185908743|1169.313803884|
|最大节点力范数（内部单位）|7.86e-7|2.94e-6|
|最大节点力矩范数（内部单位）|2.28e-7|6.06e-7|
|最小内部刚度特征值|0.002199|0.000782|
|条件NMA平均RMSF，nm|2.66693|3.74432|
|线性残差修正最大位移，nm|1.36e-4|4.26e-6|

论文Circle为752bp，平均RMSF1.736463666nm；Flower为1966bp、2.228665352nm。仓库Circle751节点/Flower1900节点，不能确认与论文版本完全一致。已查材料没有匹配Circle的实际终态能量/残差/平衡坐标/原始轨迹；Zenodo未完成审计，不能断言所有公开材料都缺失。作者Circle重算NMA比论文约高54%，新Circle比作者重算约高40%；差距不能直接用于给新结构判好坏。

静态小残差只说明求解当前模型准确。NMA使用kBT H^-1，随机RMSF使用轨迹相对均值的位置波动；两者还受到有限采样、非线性、对齐、势能和版本差异影响。不要用优化过程当动力学轨迹。

## 随机动力学与静电对照细节

- 独立过阻尼SE(3)布朗动力学，世界坐标力矩与SO(3)左乘更新；没有向绝对rotvec简单加高斯噪声。
- 假设300K、黏度1mPa·s=1pN·ns/nm²、球半径1.1nm；平移/旋转mobility分别1/(6πηa)、1/(8πηa³)。不是作者的水动力耦合。
- force_shift：U-Uc-(r-rc)U'c；改变截断区间内的力。
- potential_shift：U-Uc；保留区间内原始力但去掉边界能量跳跃，不等价原hard势的Boltzmann分布。
- 原hard能量与梯度重建在两构型快照与公开函数完全一致；与potential_shift区间内梯度差0。原hard跨界动力学未实现；若采用Metropolis分布采样，不能直接赋予真实动力学时间。
- 两势均从force-shift平衡起步，potential_shift存在切换势瞬态。短窗RMSF约0.068–0.069nm，不是平衡值。
- 验证：自由平移MSD/理论0.999513；谐振子方差误差0.00609；自由旋转1ns取向相关偏差0.72标准误；SO(3)正交误差3.33e-16。轨迹帧数/有限性/逐bp CSV重算/SHA通过。
- 当前独立线性化模型最慢松弛作者9.50us、新26.67us；不是官方时间常数。0.2ns无法充分激发慢模式。

## 加速工作、硬件与资源记录

已验证的优化：直接SO(3)力矩换算；固定图材料参数/边类型预计算精确二次型，保留单链屏蔽与交叉几何。跨图必须重新构建系数。三种子400步位置最大差约7.11e-15nm；两图平衡/扰动态的完整机械能/梯度及切换图检查通过。原上游文件未修改。

同卡两进程旧速度约39ms/步，不等同单进程硬件速度。Ada单进程27.16ms/步，直接力矩约23.46ms，二次型+力矩10.81ms；CPU17.24→15.03→8.62ms。TorchScript中位数29.01ms，未提速，不采用。CPU侧剖析5步6889次mul及450次nonzero；CUPTI初始化失败，不能报告GPU核时间占比。

GPU不是只看显卡型号：小算子/启动与索引开销是已观察到的重要问题；A100较强FP64是否有收益需实际测速。多GPU主要增加独立轨迹吞吐，不能将同一时间轨迹任意分步并行。

资源历史：已有25138/gpu22、8CPU、约21GiB、RTX6000Ada；早期步骤24/27绑定同核争用，取消自己步骤后33/34换核续算，未碰其他作业。静态、模态、短动力学、CPU/GPU测速现已结束。A10025376：1GPU、2CPU、8GB、20min，排除gpu29；提交时清理SLURM环境变量。PENDING记录仅是本次查询快照，恢复时必须再查。排到会串行baseline/direct_torque及quadratic测试，a100*/benchmark.json和a100.log为结果，完成释放资源。

## 时间与内存预算不能混淆

1us@0.1ps=1000万步。旧双进程速度外推约108h/条；优化Ada约30h、单核CPU约24h，均不是实际跑满1us。基准仅751节点短轨迹。

计算短测速实际RSS峰值263.36MiB，不是申请内存。当前pilot每20步保存一帧到Python列表；753节点1us产生500001帧，原始float64位置约8.415GiB，np.asarray可能额外复制，尚未改成长跑流式输出。长跑前必须实现分块写盘/在线统计和恢复检查点；按物理时间每1ns存一帧只有1001帧、约17.25MiB位置数据。不能据短测速低峰值直接安排60个无限累积轨迹进程。

## 恢复顺序与未完成工作

1. 先读本总账及GENERATIVESNUPI_PRIORITY.md，再查询25376；不要重复提交A100测速。
2. 若A100完成，核对两个benchmark.json的passed、实际型号、原版/优化耗时和同种子轨迹误差，再决定设备。
3. 正式长轨迹前实现流式IO、保存RNG与积分状态的可恢复检查点；当前checkpoint只保存位姿，不能声称精确恢复随机序列。
4. potential_shift需自身平衡；确认保留哪种模型，并补充原hard跨界机制。不要把两个修改势命名成官方势。
5. 对齐质量/摩擦/RPY/积分器、步长收敛和单位，分块及独立重复验证RMSF。没有生产1us轨迹在运行。
6. 寻找论文同版本样本及官方静态/轨迹真值；没有真值不能说残差/能量与论文一致。
7. 批量预筛机器学习暂不能把本次未校准RMSF当可靠新标签。

## 权威证据入口

- [result.json](../../outputs/generative_circle_snupi_20261110/result.json)
- [README_ZH.md](../../outputs/generative_circle_snupi_20261110/README_ZH.md)
- [graph_audit/REPORT_ZH.md](../../outputs/generative_circle_snupi_20261110/graph_audit/REPORT_ZH.md)
- [graph_audit/audit_float64.json](../../outputs/generative_circle_snupi_20261110/graph_audit/audit_float64.json)
- [paper_controls/REPORT_ZH.md](../../outputs/generative_circle_snupi_20261110/paper_controls/REPORT_ZH.md)
- [paper_controls/controls.json](../../outputs/generative_circle_snupi_20261110/paper_controls/controls.json)
- [control_validation/results.json](../../outputs/generative_circle_snupi_20261110/control_validation/results.json)
- [pair_audit/pairs.json](../../outputs/generative_circle_snupi_20261110/pair_audit/pairs.json)
- [pair_audit/REPORT_ZH.md](../../outputs/generative_circle_snupi_20261110/pair_audit/REPORT_ZH.md)
- [element_audit/REPORT_ZH.md](../../outputs/generative_circle_snupi_20261110/element_audit/REPORT_ZH.md)
- [element_audit/fd_newton.json](../../outputs/generative_circle_snupi_20261110/element_audit/fd_newton.json)
- [rmsf_bridge/README_ZH.md](../../outputs/generative_circle_snupi_20261110/rmsf_bridge/README_ZH.md)
- [rmsf_bridge/new_circle/modal_report.json](../../outputs/generative_circle_snupi_20261110/rmsf_bridge/new_circle/modal_report.json)
- [rmsf_bridge/author_circle/modal_report.json](../../outputs/generative_circle_snupi_20261110/rmsf_bridge/author_circle/modal_report.json)
- [rmsf_bridge/verification.json](../../outputs/generative_circle_snupi_20261110/rmsf_bridge/verification.json)
- [stochastic_pilot/README_ZH.md](../../outputs/generative_circle_snupi_20261110/stochastic_pilot/README_ZH.md)
- [stochastic_pilot/verification.json](../../outputs/generative_circle_snupi_20261110/stochastic_pilot/verification.json)
- [stochastic_pilot/electro_audit.json](../../outputs/generative_circle_snupi_20261110/stochastic_pilot/electro_audit.json)
- [stochastic_pilot/integrator_verification.json](../../outputs/generative_circle_snupi_20261110/stochastic_pilot/integrator_verification.json)
- [stochastic_pilot/rotation_check.json](../../outputs/generative_circle_snupi_20261110/stochastic_pilot/rotation_check.json)
- [stochastic_pilot/linear_relaxation_times.json](../../outputs/generative_circle_snupi_20261110/stochastic_pilot/linear_relaxation_times.json)
- [speed_benchmark/README_ZH.md](../../outputs/generative_circle_snupi_20261110/speed_benchmark/README_ZH.md)
- [speed_benchmark/summary.json](../../outputs/generative_circle_snupi_20261110/speed_benchmark/summary.json)
- [speed_benchmark/graph_verification.json](../../outputs/generative_circle_snupi_20261110/speed_benchmark/graph_verification.json)
- [speed_benchmark/cpu_peak_memory.json](../../outputs/generative_circle_snupi_20261110/speed_benchmark/cpu_peak_memory.json)
- [speed_benchmark/submission.json](../../outputs/generative_circle_snupi_20261110/speed_benchmark/submission.json)
- [speed_benchmark/a100.sbatch](../../outputs/generative_circle_snupi_20261110/speed_benchmark/a100.sbatch)

复算/启动脚本均在对应目录，原始结果不覆盖。总账核验清单、证据SHA、作业快照见 [GENERATIVESNUPI_LEDGER_VERIFICATION_20261110.json](GENERATIVESNUPI_LEDGER_VERIFICATION_20261110.json)。
