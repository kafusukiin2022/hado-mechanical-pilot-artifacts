# DNA origami 300-family dataset: oxDNA readiness audit

Date: 2026-11-03  
Scope: read-only inventory of `../fmdata/dataset_300/dna_origami_300_families/` and its manifest. No source files were changed; no oxDNA simulation, training, GPU, remote host, or scheduler was used.

## Inventory and design families

The bundle contains 300 deduplicated representative design families, not 300 independent measured trajectories. The manifest assigns 240 train and 60 test families with family-level grouping. Provenance is 162 `public_design` and 138 `algorithm_generated`; the generated group is predominantly NanoFrame/pyDAEDALUS B-form wireframe designs based on distinct polyhedral geometries. The public set spans caDNAno origami (sheets, bundles, tubes, cages, devices, tiles and sensors), CanDo/ATHENA wireframes, MagicDNA and other software designs, and RNA/gridiron examples. These are not a single homogeneous design distribution.

Manifest file-format counts:

| Format | Families | What the file provides | oxDNA readiness |
|---|---:|---|---|
| `.cndo` | 146 | CanDo topology plus coarse structural coordinates/triads | Conversion candidates; not an oxDNA `.top` + `.dat/.conf` pair |
| caDNAno `.json` | 125 | Helix routing, scaffold/staple connectivity, loop/skip metadata | Topology/design input; nucleotide coordinates must be generated and relaxed |
| `.dna` | 15 | Application-specific binary design files | Requires the originating design software/exporter; not directly consumable |
| `.top` | 10 | OxDNA-style nucleotide connectivity | No same-stem `.dat` or `.conf` exists in the family directory, so these are incomplete simulation inputs |
| `.oxview` | 3 | Monomer connectivity and rigid-body position/orientation fields | Best conversion/inspection candidates; still need export and physical validation |
| `.ens` | 1 | Ensnano design description | Requires an Ensnano-aware conversion/export path |

The `.json` files parsed as caDNAno `vstrands`; all 125 passed basic array-shape checks. This does not test whether every crossover is physically plausible. The `.cndo` parser found finite numeric coordinate/triad records, valid nucleotide references, and matching `dNode`/`triad` record counts across the set. `dNode` counts are not a fixed 1:2 ratio to nucleotide records, so that ratio is not used as a corruption test. The three `.oxview` files contain finite `p/a1/a3` fields with unit, mutually orthogonal `a1/a3` vectors to floating-point precision; indexed neighbor references resolve. These are static format checks, not an oxDNA energy/minimization test.

## Practical classification

1. **Start with the three `.oxview` structures** (FAM124, FAM125, FAM274) for an exporter smoke test. Verify export to oxDNA topology and configuration, nucleotide count/connectivity, neighbor geometry, and a short energy/minimization check before accepting them as physical structures.
2. **Treat the 146 `.cndo` structures as conversion candidates.** Their records contain geometry, so a converter can potentially reconstruct nucleotide rigid-body states. Validate the converter and geometry per design class; do not assume CanDo coordinates are already oxDNA equilibrium coordinates.
3. **Treat the 125 caDNAno JSON structures as design/topology inputs.** Use a versioned caDNAno-to-oxDNA builder to place bases, then relax and reject structures with broken bonds, clashes, missing nucleotides, or invalid crossovers.
4. **Do not feed the 10 `.top` files alone to a simulation.** They need paired configurations. Likewise, `.dna` and `.ens` need their native software/export route before oxDNA conversion.

## Training-data conclusion

None of the 300 families is, by this inventory alone, a supervised RMSF training example: the bundle is a set of designs and does not provide matched trajectory-derived RMSF labels. They can become inputs to an oxDNA data-generation pipeline after conversion, physical QC, and consistent simulation/label extraction. Keep the 138 algorithm-generated polyhedra separate from the 162 public designs in initial evaluation or stratify by provenance/design class; otherwise a model may learn generator-specific regularities and report misleading cross-family performance. Preserve the supplied family grouping in any split.

The immediate low-cost next step is a converter/export smoke test on one `.oxview`, one `.cndo`, and one caDNAno JSON representative, followed by static geometry and short minimization checks. Only after that passes should bulk conversion or label generation be considered.

## Limits

This audit establishes file inventory and basic parseability only. It does not establish correct sequence provenance, design intent, folding yield, physical stability, or correspondence to any experimental structure. The earlier first-pass `.cndo` checker incorrectly required the wrong record-count ratio; those failures were parser assumptions, not evidence that the files were corrupt.
