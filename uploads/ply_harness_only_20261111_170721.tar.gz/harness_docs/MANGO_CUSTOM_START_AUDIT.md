# MANGO 自定义起始骨架：代码与 harness 核查

本次核查确认已有可用实现，不需要重复修改上游初始化。入口为 `experiments/plantri_mango_talos20_20261110/mango_fixed.py`，使用现有 Mango 环境。上游现有两个文件有本地修改，本轮保留。

## 源码接入点

- `Mango/mango/design_spaces/polyhedral_design_space.py:302`：`generate_start_shape` 调用 `triangulate_input_conditions`，然后构建边、MeshFace、plotting_faces 和 merge_label_graph。
- `Mango/mango/optimizers/single_objective_shape_annealing.py:524`：`begin_annealing` 无条件调用上述初始化，随后执行初始约束、随机游走温度初始化和 Metropolis 退火。因此只提前赋值 design_graph 会被重新初始化流程干扰。
- 现有 `ImportedSpace.load(g, faces, x)` 完整装配图和面状态，`generate_start_shape` 覆盖为拓扑断言。节点包含 x/y/z/terminal，必须同时提供三角面及一致的边。现有调用约定节点连续编号，与坐标行对应。
- `FixedGrammar` 仅启用 Extend Vertex；逐提案检查带标签节点/边/面不变，同步 MeshFace 坐标并清空 mesh_file。覆写 find_nonterminal_nodes 修正上游重复调用时可移动节点列表交替清空问题。
- `FixedAnneal` 使用实际节点坐标计算边长 CV，保留原生温度初始化、Metropolis、冷却；返回最佳合法几何。此目标是边长均匀度，不是物理稳定性或实际 scaffold 长度。

## 不同拓扑如何产生

现有 `plantri → Tutte 平面嵌入 + 支撑面 LP 凸提升 → ImportedSpace → Mango → TALOS` 已实现外层不同图、内层固定图几何优化。plantri 简单三连通球面三角剖分 V4…9 共73种；精确图同构去重，不能靠不同随机种子、坐标、V/E/F或哈希本身证明不同拓扑。已有优化过的几何也可作为 x 再导入，只要保留原 g/faces 并通过几何检查。

这里拓扑指骨架连接图不同；这些曲面仍均为 genus 0。当前凸验证不支持任意非平面图、开放网格或带孔曲面。对于任意非三角多面体，三角化加入的边也会改变用于路由的骨架，应显式记录。

当前适配器刻意冻结连接关系。若要求退火途中也增删顶点/边，必须另建模式，重做 Divide/Merge/Retriangulate 的历史状态和网格一致性验证；不能删除 assert_topology 就宣称支持。Box语法也非任意导入点的普遍变换：上游 update_design_space 主要处理与盒面中心匹配的 preserved vertex，preserved edge 分支仍为 WIP。

## 已有证据及后续重点

`experiments/plantri_mango_talos20_20261110/REPORT_ZH.md`：20起点均完成Mango，18路由通过，5满足scaffold≤12000、总nt≤24000；其余13超限、2失败。verification.json 记录190批内和8800历史精确同构检查通过。这是历史结果，本轮不重跑生成或物理模拟。后续40/75批次结果不能用低V试点成功率外推；75批次预算内为0。

关键瓶颈已转为凸实现细长、TALOS实际长度与失败率，而非无法接入起始骨架。应先改善初始边长比例/几何目标和实际预算筛选，再扩大拓扑库。论文7249nt不是现有试点12000nt预算；若采用7249nt须重新筛选，不能沿用5例预算通过结论。

最新预算pilot保留paused，不自动恢复。CodeGraph MCP一次120s超时后用CLI完成精确入口核查；本轮不修改源代码，因此无需源代码索引同步。启动 ./init.sh PASS；回归复跑结果见 progress.md。


## 1000-topology scalability follow-up
Read-only source and batch report audit: 20/40/75 batches yield 18/20/36 routing passes, but 5/0/0 within scaffold12000,total24000. Batch75 199.03s, Mango median15.09s and TALOS median24.58s, no sustained-queue or same-input scaling proof. 1000 distinct graph candidates is algorithmically scalable by increasing plantri V; 1000 budget-valid/physically stable designs not established. Candidate code optimizations (not benchmarked/implemented): avoid dual deepcopy in native loop; cache current/candidate objective; fixed topology arrays/adjacency and incident-face updates; reuse fast_metrics in validate; precompute clearance pairs and vectorize, preserve global convexity checks and full final audit. Current adapter bypasses native PolyhedralDefaultConstraints.update_params, so its full-trimesh rebuild is NOT current pilot hot path. Highest priority is initial geometry/route-aware length objective and TALOS failures, then paired profiling. No new runs or changes to paused task.
