# DGNN-Physic Clean75 Plan

Date: 2026-06-18

## Objective

Add a `dgnn-physic` model path that moves oxDNA/cadnano-derived information
into the graph before message passing, then train it on the reproducible
clean75 60/15 nt-stratified split.

## Design

- Node inputs include the existing rigid features plus base identity, normalized
  strand rank, normalized local strand index, strand length fraction,
  prev/next/end flags, helical phase `sin/cos(2*pi*i/10.5)`,
  box-normalized start position, start velocity, and start angular velocity.
- Edge inputs include the existing relative geometry features plus relation
  one-hot, helical phase delta, and start/final pair-state features.
- Typed edge relations are:
  `backbone_forward`, `backbone_reverse`, `pair_start`, `pair_final`,
  `pair_formed`, `pair_broken`, `duplex_step`, `candidate_wc`, and `spatial`.
- The current clean75 manifest has no explicit `cadnano_json`/`virt2nuc`
  entries, so pair and duplex-step relations come from `start_pair_file`,
  `final_pair_file`, and the same reference-pair preparation path already used
  by the trainer.
- `DgnnPhysicRigidModel` keeps the DGNN-lite residual rigid-body decoder, but
  uses typed edge-conditioned message passing with relation embeddings.

## Reproducible Split

Use:

```bash
--manifest outputs/manifests/nupack_2e6_2000_all_clean75_with_pair_labels.json
--split-mode sample
--split-strategy nt-stratified
--val-fraction 0.2
--seed 1
```

This yields 75 samples total, 60 train, 15 validation, stratified by nucleotide
count. Keep this split contract for future clean75 comparisons.

## Initial Training Recipe

The first full run should use
`jobs/run_dgnn_physic_clean75_1000e_local.sh` directly on the current GPU node.
Do not submit this goal through `sbatch`. Select the local GPU with
`CUDA_VISIBLE_DEVICES=<index>`. Enable pair and helix auxiliary losses
initially, then simplify only after full metrics show which terms help.

## Success Criteria

- Primary target remains validation `RMSD -> 0` and `OS -> 1`.
- Physical structure must improve under exported `.conf` evaluation:
  `predicted_wc_f1`, low conflict rate, helix-step distance/axis metrics, and
  oxView-loadable outputs.
- If metrics improve enough, run ablations by removing feature/edge/loss
  groups rather than adding new mechanisms.
