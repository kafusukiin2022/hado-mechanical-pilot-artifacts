# P0 当前入口：GenerativeSNUPI → 平衡 → 随机轨迹 → RMSF

**先读 [实验总账与恢复说明](GENERATIVESNUPI_EXPERIMENT_LEDGER_20261110.md)。** 总账覆盖推理、接口缺口、静态/切线验证、NMA、8条随机轨迹、静电对照、CPU/GPU加速、内存、作业与下一步。

- 已完成：修改势下作者/新Circle静态平衡和条件NMA；8/8条0.2ns独立布朗轨迹；等价加速GPU2.51倍/CPU2倍；短测速内存峰值263.36MiB。
- 未完成：官方图接口与论文同版本静态对照、原硬截断跨界动力学、RPY/GJF对齐、可信1us/充分采样RMSF。
- A100测速25376最近核实PENDING(Priority)；1GPU2CPU8GB20min，自动跑原版及优化对照。恢复先查询，勿重复提交。
- 目前没有生产长轨迹运行。CPU约24h/Ada约30h是耗时外推；263MiB是短测速RSS，不是长轨迹上限。当前帧列表累积，长跑前必须分块写盘。
- 不能把低残差当论文复现、把NMA/短轨迹值当论文RMSF、把输入失败当结构不收敛、把优化器/ARPACK失败当物理不稳定。
- 保留其他TALOS/41构型作业，不基于旧日志盲目重启。

[历史优先级记录](GENERATIVESNUPI_PRIORITY_HISTORY_20261110.md)保留全部旧内容；其中“运行中”只反映当时状态。[证据与作业快照核验](GENERATIVESNUPI_LEDGER_VERIFICATION_20261110.json)。
