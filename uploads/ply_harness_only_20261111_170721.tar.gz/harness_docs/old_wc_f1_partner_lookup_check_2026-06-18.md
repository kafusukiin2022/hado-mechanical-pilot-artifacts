# Old WC-edge F1 Partner Lookup Check, 2026-06-18

## Question

Recompute/check the four old clean75 WC-edge ablation runs with the node
partner lookup method and verify whether the results match the old
`decoded_pair_f1`.

## Important artifact limit

The four completed old run directories contain `summary.json` files but do not
contain decoded pair edge lists or model checkpoints:

- `save_model_state = None`
- `save_best_model_state = None`
- no checkpoint / state / decoded-pair files found under the four valid run
  directories

Therefore a strict edge-level rescan of the old predictions is not possible
from the saved artifacts. The check below is the partner-lookup-equivalent
reconstruction from saved per-sample aggregates:

- `decoded_pair_count`
- `decoded_pair_precision`
- `decoded_pair_recall`
- `decoded_pair_f1`
- per-sample `final_pair_count`, used as the reference pair count

For each sample:

- `matched_pair_count = decoded_pair_count * decoded_pair_precision`
- `reference_pair_count = final_pair_count`
- partner lookup precision = `matched_pair_count / decoded_pair_count`
- partner lookup reference-pair recall =
  `matched_pair_count / reference_pair_count`
- partner lookup F1 =
  `2 * precision * recall / (precision + recall)`

This is the same count algebra used by the node partner lookup method after it
has counted matched predicted partners, but it is not a fresh decode from model
logits.

## Command

```bash
PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python \
  scripts/recompute_old_wc_f1_partner_lookup.py
```

Outputs:

- `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/partner_lookup_recomputed_f1.json`
- `outputs/clean75_wc_edge_mode_ablation_fixed_20260617/partner_lookup_recomputed_f1.csv`

## Result

The partner-lookup-equivalent F1 matches the old per-sample mean
`decoded_pair_f1` exactly for all four runs. Maximum per-sample absolute F1
delta is 0 for every split.

| run | split | old mean F1 | partner lookup mean F1 | max abs delta | matched / ref / pred |
|---|---:|---:|---:|---:|---:|
| baseline_no_wc | train | 0.000000000000 | 0.000000000000 | 0 | 0 / 379497 / 359884 |
| baseline_no_wc | val | 0.000000000000 | 0.000000000000 | 0 | 0 / 98324 / 92068 |
| message_all | train | 0.914798571782 | 0.914798571782 | 0 | 359352 / 379497 / 398002 |
| message_all | val | 0.939066352110 | 0.939066352110 | 0 | 94727 / 98324 / 102246 |
| readout_only | train | 0.926481537979 | 0.926481537979 | 0 | 362638 / 379497 / 397560 |
| readout_only | val | 0.945814517443 | 0.945814517443 | 0 | 95298 / 98324 / 102151 |
| last_layer | train | 0.923418207092 | 0.923418207092 | 0 | 361108 / 379497 / 397528 |
| last_layer | val | 0.943369593663 | 0.943369593663 | 0 | 95034 / 98324 / 102136 |

Best old validation result remains:

- `readout_only`: validation mean F1 `0.945814517443`

## Runtime / complexity

For these old summaries, the script only reads four JSON files and scans 300
sample records, so runtime is dominated by Python environment startup and JSON
loading. The core computation is linear in the number of sample records.

For future runs that store/use decoded edges directly, the node partner lookup
metric is linear in pair edges:

- build `decoded_partner` once from predicted pairs: O(P_pred)
- scan each reference pair once: O(P_ref)
- optional node bookkeeping is also O(P_pred + P_ref)

Because base pairing is one-to-one, `P` is O(N), so this metric is O(N) for
normal nucleotide graphs.

## Verification

- `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python scripts/recompute_old_wc_f1_partner_lookup.py`
- `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/recompute_old_wc_f1_partner_lookup.py`
