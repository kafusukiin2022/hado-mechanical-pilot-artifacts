# Physical Rules Ablation - 2026-06-17

## Purpose

Diagnose why the 2026-06-16 physical-pairing diagnostic improved decoded Watson-Crick assignment but worsened held-out RMSD/OS.

User requirement for this ablation:

- Keep the dataset train/val split fixed.
- Use the same small3 held-out design, `101_50_bp_nicked`.
- Compare the incremental base-pairing rule changes.
- Use the 428320-era DGNN-lite configuration as the baseline reference where possible.
- Run directly on A100 GPUs, no Slurm.

## Important Baseline Caveat

Job `428320` has no `summary.json`, no exported `.conf`, and no `model_state.pt`; it timed out after logging through epoch `8050`. Therefore it cannot be loaded as a final baseline model.

The ablation uses the 428320-like training configuration instead:

- `model_kind=dgnn-lite`
- hidden `512`
- message steps `5`
- Fourier features `8`
- design features `stats`
- graph mode `backbone`
- optimizer `adamw`
- learning rate `0.0005`
- weight decay `0.01`
- orientation loss weight `5.0`

All ablation runs use:

- manifest `outputs/manifests/nupack_small3_with_pair_labels.json`
- fixed validation id `101_50_bp_nicked`
- 10 epochs
- seed `1`
- direct A100 execution

## Outputs

- Run directory: `outputs/ablations_20260617_pair_rules_unified_split/`
- Summary CSV: `outputs/ablations_20260617_pair_rules_unified_split/summary_table.csv`
- Runner script: `outputs/ablations_20260617_pair_rules_unified_split/run_one.sh`

## Unified-Split Results

Held-out `101_50_bp_nicked`:

| Run | Incremental change | RMSD | OS | decoded F1 | raw WC F1 | raw conflict | pair RMS err | helix axis |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| `u0_baseline_no_pair_rules` | 428320-like backbone, no pair rules | `32.0334` | `-0.0181` | `0.0000` | `0.1967` | `1.0000` | `0.4000` | `0.0439` |
| `u1_candidate_wc_edges` | add candidate WC edges to DGNN-lite graph | `34.2175` | `-0.0990` | `0.4536` | `0.1695` | `1.0000` | `0.3723` | `0.1120` |
| `u2a_pair_class_only` | candidate edges + pair classification loss | `34.3452` | `-0.0929` | `0.5155` | `0.2258` | `1.0000` | `0.3830` | `0.1174` |
| `u2b_pair_sym_only` | candidate edges + pair-logit symmetry loss | `34.2933` | `-0.0974` | `0.5053` | `0.1967` | `1.0000` | `0.3695` | `0.1122` |
| `u2_pair_assignment_loss` | candidate edges + classification + symmetry | `34.3742` | `-0.0955` | `0.4948` | `0.2258` | `1.0000` | `0.3830` | `0.1191` |
| `u3a_assignment_plus_center` | assignment + pair center loss | `34.3553` | `-0.0944` | `0.4948` | `0.1695` | `1.0000` | `0.3763` | `0.1195` |
| `u3b_assignment_plus_axis` | assignment + pair axis loss | `34.4118` | `-0.0368` | `0.4742` | `0.1967` | `1.0000` | `0.3835` | `0.1182` |
| `u3c_assignment_plus_frame` | assignment + pair frame loss | `34.3591` | `-0.0995` | `0.4948` | `0.1695` | `1.0000` | `0.3759` | `0.1194` |
| `u3_full_pair_frame_losses` | assignment + center + axis + frame | `34.2859` | `-0.0810` | `0.4948` | `0.1724` | `1.0000` | `0.3754` | `0.1191` |

## Interpretation

The largest RMSD/OS regression comes from adding candidate Watson-Crick edges into the DGNN-lite message graph:

- RMSD worsens from `32.0334` to `34.2175`.
- OS worsens from `-0.0181` to `-0.0990`.
- This happens before pair classification, symmetry, center, axis, or frame losses are enabled.

The later pair losses change pair-assignment and local physical diagnostics, but their additional RMSD/OS effect is smaller than the candidate-edge graph-mixing effect.

This supports the architectural conclusion:

- Do not mix candidate Watson-Crick edges into the ordinary coordinate message-passing graph early.
- Pair assignment can be trained as an auxiliary head/channel.
- Pair geometry should be used in late decoder/refinement or assignment-conditioned realization, not as early ordinary edge mixing.
- RMSD/OS coordinate training and physical pairing realization should remain staged for now.

## Two-Stage Recommendation

Current evidence supports two stages:

1. Train the coordinate/orientation model for RMSD/OS with the stable backbone graph.
2. Train or attach pair assignment and physical alignment as a late refinement/decoder stage.

Pair assignment can be trained in parallel as an auxiliary signal, but strong pair-edge mixing and frame losses should not dominate early coordinate updates.

Add weak non-reference repulsion only after pair assignment and pair-frame realization are stable.

## Verification

Passed:

```bash
./init.sh
```

Completed direct A100 ablations:

```bash
outputs/ablations_20260617_pair_rules_unified_split/run_one.sh ...
```

Parsed all produced `summary.json` files and wrote:

```bash
outputs/ablations_20260617_pair_rules_unified_split/summary_table.csv
```

