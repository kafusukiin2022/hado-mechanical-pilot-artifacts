## P0 CPU峰值内存补测（2026-11-10）

751节点单核CPU baseline+二次型优化短测速，getrusage进程高水位RSS=263.36MiB（0.257GiB），见speed_benchmark/cpu_peak_memory.json；此前Slurm步骤47采样MaxRSS269048KiB约262.74MiB。24h是1us耗时外推，非已完成24h内存测量。现pilot列表累计每20步一帧；1us@.1ps新Circle753节点产生500001帧，仅位置float64约8.415GiB，np.asarray额外复制可再翻倍。长跑必须改分块写盘/在线统计并按物理时间设置保存间隔；每1ns存一帧约1001帧、17.25MiB原始位置。不能将短测速低峰值直接承诺为长轨迹峰值。

## P0 动力学加速：保持数值结果的2.51倍GPU优化；A100已排队（2026-11-10）

speed_benchmark/README_ZH.md为最新。RTX6000Ada单进程原版27.16ms/步，预计算局部精确二次型+SO(3)直接力矩10.81ms/步，2.51倍；单核CPU17.24->8.62ms，2.00倍。同种子三组400步轨迹差7.11e-15nm，两构型完整机械能/梯度与切换图检查PASS。dtype/势能/dt不变。之前39ms为同卡双进程，不能归因GPU型号。TorchScript未提速不采用；CUPTI失败只得CPU剖析。A100作业25376已提交1GPU2CPU8GB20min，PENDING(Priority)，GPU配额已满；排到自动baseline/direct+quadratic对照，结果a100*/benchmark.json，勿重复提交。现有25138测速完成，无新长MD。1us@.1ps外推优化Ada约30h、CPU约24h，不是完成轨迹。待A100实测再确定硬件选择。

## P0 随机动力学短轨迹完成：8/8，尚非论文复现（2026-11-10）

已有25138步骤38/39完成exit0，8条0.2ns真实SO(3)布朗轨迹（作者/新×force_shift/potential_shift×0.1/0.05ps），共1208帧；逐轨迹有限性、帧数、CSV逐bp与均值重算、SHA核验PASS。自由平移/旋转扩散及谐振子测试PASS。作者/新短窗RMSF均约0.068–0.069nm，明确瞬态而非平衡；不能称与论文值更接近。独立无水动力耦合的过阻尼模型，非SNUPI质量/RPY/GJF；原hard势未进行跨界动力学，只有精确能量/梯度重建和势差对照。当前无本次轨迹任务运行。force-shift线性化最慢松弛作者9.50us/新26.67us，仅此独立模型；0.2ns无法充分采样。GPU实测38.6–39.4ms/步，CPU固定状态力梯度15.9ms/次；1us@0.1ps现GPU约108h/条，未盲目提交。后续：加速力计算/核对官方RPY-GJF，独立平衡potential-shift，验证真正长时间RMSF及原hard跨界处理。证据stochastic_pilot/README_ZH.md、verification.json、electro_audit.json。

## P0 已转向随机动力学：8条短轨迹及截断势对照（2026-11-10）

新增stochastic_pilot/run.py，已有25138步骤38/39并行作者/新Circle；两势(force_shift/potential_shift)×两步长0.1/0.05ps各0.2ns，总8条。独立过阻尼free-draining SO(3)布朗动力学，300K/1mPa·s/1.1nm假设，非官方RPY/GJF。原始硬截断能量仅记录，不伪称忽略边界跃迁的连续力积分是原势能动力学。electro_audit验证官方静电值及梯度重建、potential-shift区间内力一致；自由扩散/谐振子方差/旋转正交测试PASS。短轨迹RMSF仅瞬态，非平衡。线性化最慢模式微秒至数十微秒，当前0.2ns远不足；实际吞吐约39s/1000steps，1us约108h/条，不能直接盲目长跑。详见outputs/generative_circle_snupi_20261110/stochastic_pilot/README_ZH.md；当前运行勿重复启动。其他41队列不变。

## P0 对照边界澄清：未验证作者Circle的能量/残差与论文一致（2026-11-10）

用户追问静态指标能否对齐。当前答案：不能确认一致。已检索论文正文仅报告训练集平衡计算的内力1e-3/总能量1e-6容差，未获得当前公开Circle对应的实际终态力残差、能量或配对平衡坐标。我们的作者Circle force-shift独立模型终态E=1211.1859087429962、Fmax=7.862790785894166e-7、Tmax=2.2808178452393144e-7；最后一次Newton能量差约4.96e-8。这些不是官方归一化残差；能量容差不代表绝对总能量应低于1e-6。force-shift改变能量零点及力，数值不能直接对照官方总能量。低残差/正切线证明的是独立修改模型局部数值稳定，尚非论文静态复现。

## P0 RMSF：获得条件NMA逐bp数值（2026-11-10）

新Circle完整图阻尼Newton后残差Fmax=2.94e-6/Tmax=6.06e-7；六个刚体模投影后全内部谱为正，最小lambda=7.82e-4，方向差分切线校验误差<3.3e-9。300K、pN·nm单位假设、force-shift模型的条件NMA均值RMSF=3.744nm；逐bp CSV `outputs/generative_circle_snupi_20261110/rmsf_bridge/new_circle/conditional_harmonic_rmsf_nm.csv`。作者Circle对照2.667nm，力/力矩<8e-7、min lambda=.002199。非论文1us随机动力学，cutoff势修改，作者节点数也非论文精确752bp。分析器通过刚体消除、解析呼吸验证。逐bp条数与均值重算PASS、SHA存verification.json；init/py_compile PASS。下一步：单位/截断敏感性及校准Langevin轨迹。当前计算已结束，没有真实动力学在后台运行。不得把先前status.json中的L-BFGS终态误当最终状态，以newton_report/modal_report为准。

## P0 RMSF：全构型切线验证通过，自动衔接Newton与条件NMA（2026-11-10）

新Circle753节点/4518自由度的逐边FD机械刚度+解析force-shift静电刚度已装配，3方向×2步长全局H·v验证最大相对误差8.41e-6；见rmsf_bridge/new_circle/preliminary_tangent。ARPACK低端谱未收敛，后处理改用投影稠密谱，不据此判物理不稳定。已有25138步骤33/34松弛，36/37等待完成后自动执行30步有下降检查的Newton与6刚体模剔除的条件NMA。只在力/力矩与正定门槛通过后输出条件RMSF，非论文随机动力学。CPU绑定争用已修正，约100轮3.3秒。单位依据gen_pyg.py kB转换及2.01协议支持pN·nm，但仍标注假设。尚待最终status/newton_report/modal_report，禁止重复启动。

## P0 RMSF 推进：完整图继续松弛 + 轨迹分析入口（2026-11-10）

新增 `outputs/generative_circle_snupi_20261110/rmsf_bridge/`。已有25138/gpu22执行新/作者Circle的完整图float64 L-BFGS-B续算（最多10000迭代，100迭代落盘）。仍是force-shift修改势能，非官方SNUPI。生产RMSF尚未生成；先检查最大物理增量力/力矩<1e-3内部单位，再检验稳定刚度/零模/能量单位。RMSF轨迹分析器已通过纯刚体零波动和解析呼吸波动验证，误差<1e-12nm。详见rmsf_bridge/README_ZH.md及实时status.json。初始new进程步骤25138.23被取消且没有产物，核实无重复后已重新启动；作者步骤25138.24在运行。其他41队列不变。init/py_compile通过。

# P0 — GenerativeSNUPI 直接力学图求解复现（最高优先级）

用户2026-11-10明确要求置于最高优先级。先阅读本文件，再决定是否运行生成设计的静态或动力学验证。

## 已核验的重要结论

- 官方SNUPI v3.10输入为caDNAno JSON/CSV；本次生成CNDO/PyG在读取阶段被拒绝。不能标成静态不收敛。
- 生成的原始坐标.pt不同于_mean.pt/_seq.pt；后二者含位置/方向/螺旋编号、边、物理类型及30维材料参数。
- 当前GitHub snupi_energy.py与本地字节相同，blob cc1be7f68f8addea2c5044702b63e5defac84fc7。mech_PE在786行作为别名存在。
- 当前生成图753节点785条边，无正反重复；total_PE默认[:,::2]只用393条、丢392条，且没有正确传edge_type。不可直接用于该图的模拟。
- 全边+正确类型的机械能调用与生成日志相符。双精度局部梯度/刚体不变性检查通过。
- 独立短程L-BFGS候选松弛：能量33876→2302，梯度范数10947→267；约3.7秒。它不是作者求解器、不是官方SNUPI通过、也没有证明达到平衡。
- 静电计数/截断/邻居上限、参数单位、平衡收敛准则、随机动力学平移/旋转积分与阻尼噪声仍须对照核验。

## 证据与恢复入口

- outputs/generative_circle_snupi_20261110/graph_audit/REPORT_ZH.md
- 同目录audit_float64.json、relax_probe.json、upstream_api.json及可复运行脚本。
- outputs/generative_circle_snupi_20261110/result.json：官方程序输入拒绝证据。

## 下一步（P0）

寻找论文作者公开的成功设计及其配套平衡坐标/RMSF/轨迹，区分设计文件、实验成功和计算收敛参考。先建立对照再扩展求解器；不要直接跑百万步并声称论文复现。保留其他模拟队列，禁止盲目重启。

## P0对照检索最新结论

论文表2 #15 Circle752bp/RMSD1.7825/RMSF1.7365、#38 Flower logo1966bp/RMSD1.9425/RMSF2.2287已核对源表。但仓库Circle753原始点/751图节点，Flower1900点/图节点，非已证实同版。24例子文件与GitHub哈希一致。尚无匹配平衡坐标/轨迹；Zenodo连接失败未审计。详见 outputs/generative_circle_snupi_20261110/paper_controls/REPORT_ZH.md。

## P0 最新：静电硬截断导致求解停滞（2026-11-10）

作者Circle与新Circle各200轮对照发现：末态卡在2.5nm截断边界，负梯度微步反而触发约0.154854能量跳升；全对枚举排除邻居上限漏算。平滑截断独立诊断有改善，但改变模型，不能宣布官方静态通过。仍在第④阶段。详见 [对照报告](outputs/generative_circle_snupi_20261110/control_validation/REPORT_ZH.md)。


## P0 最新：跨界节点对和Newton容差已证实（2026-11-10）

作者Circle 264↔695、新Circle44↔543均因1e-7负梯度微步从2.5nm外跨入，新增i→j和j→i两条边，各贡献0.0774271、总跳变0.1548542；能量分解误差<2e-13，冻结邻接FD/autograd一致。GenerativeSNUPI论文明确450平衡训练构型使用SNUPI2.01、30增量Newton–Raphson、力<1e-3/能量<1e-6。SNUPI2.01 Protocol及本地3.10默认进一步对应TIME_STEP/STT_STEP30、每步15次、增量更新上限100、容差1/1e-3/1e-6；适配器仍需复现增量静电建边和自适应规则。阈值定义/归一化未知，不能直接套到PyTorch混合pose梯度。详见 outputs/generative_circle_snupi_20261110/pair_audit/REPORT_ZH.md。

## P0 最新：单元代数检查通过；三维二阶导数需替代实现（2026-11-10）

117组有效材料参数的局部参考能量/梯度近零，刚度无显著负特征值；拉伸/扭转解析对照通过。全局位姿机械能直接autograd Hessian在合成参考/扰动两态出现非有限值，单边入口还有squeeze维度错误。独立有限差分刚度+固定端单梁Newton 3次更新恢复解析平衡（最大梯度3.31e-11）。仅单梁通过，非全DNA收敛，静电边界问题仍未消除。见 [报告](outputs/generative_circle_snupi_20261110/element_audit/REPORT_ZH.md)。

