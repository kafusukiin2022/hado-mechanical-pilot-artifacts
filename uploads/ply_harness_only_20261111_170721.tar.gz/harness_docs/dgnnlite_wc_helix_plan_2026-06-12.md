# DGNN-lite Watson-Crick And Helix Plan

Date: 2026-06-12

## Current Goal-Specific Harness

For the 2026-06-15 continuation, load `docs/harness/physical_rules_2026-06-15.md` as the source of physical-rule-specific instructions, evidence, and next-step selection. This file remains historical context and should not duplicate the full 2026-06-15 physical-rule harness.

## Objective

Find how Watson-Crick pairing is handled in `GeoTDM`, compare with `DeepSNUPI` and Generative SNUPI, and define a practical way to measure whether the current `DGNN-lite` path obeys complementary pairing and helix rules while still moving toward `RMSD -> 0` and `OS -> 1`.

## Codebase Findings

### GeoTDM

- `GeoTDM/datasets/oxdna.py` parses only:
  - base one-hot identity,
  - strand id and local strand position,
  - backbone edges,
  - optional skip-2 edges.
- It does **not** build an explicit Watson-Crick pairing graph.
- It does **not** attach an explicit helix geometry loss or duplex occupancy metric.
- Therefore, in the current oxDNA branch, Watson-Crick behavior is not modeled as a first-class structural constraint.

### DeepSNUPI

- `DeepSNUPI/src/model.py` uses:
  - separate position/orientation streams,
  - iterative graph processing,
  - dynamic electrostatic interaction over radius-neighbor pairs from different helices.
- `DeepSNUPI/src/utils.py` uses:
  - mechanical potential energy,
  - electrostatic potential energy,
  - crossover triad correction,
  - RMSD and orientation-related utilities.
- It still does **not** implement explicit base-identity Watson-Crick pairing as a supervised graph edge class or pairing occupancy loss.
- The useful transferable lesson is: geometry and physics constraints can be added outside plain coordinate MSE, but they still need a DNA-specific structural target.

### Generative SNUPI

- Literature review indicates that base-pair geometry is generated first, while strict scaffold/staple routing and sequence assignment enforce final Watson-Crick complementarity downstream.
- This implies a practical split:
  - geometry model should be judged by whether it creates a duplex-compatible shape,
  - final discrete sequence complementarity can be handled by later routing/assignment.
- Public supplementary material and public code both support this interpretation more concretely than the paper abstract alone:
  - the supplementary file has a dedicated `Supplementary Note 5. Routing`;
  - its routing section explicitly stages regular base-pair-step creation, scaffold routing, loop/double-crossover generation, base-pair orientation assignment, staple crossover optimization, and staple-route partitioning;
  - the local public-code inspection shows the same ordering in `routing.py`, `automated_design/auto_design.py`, and `automated_design/coords_to_triads.py`.
- Therefore, Generative SNUPI is best read as:
  - geometry-first at the generative model level,
  - routing/triads/crossover realization downstream,
  - not as a direct nucleotide-level one-to-one WC partner classifier baked into the main generative loss.

## Design Decision

For the current `DGNN-lite` path, add a **geometry-derived Watson-Crick/helix score** rather than pretending the model already predicts true discrete sequence pairing.

This avoids a false claim of physical correctness while still making physicality measurable.

## Implemented Metrics

Added `ebd_oxdna/physical_metrics.py` and connected it to `scripts/ebd_oxdna_shared_rigid_train.py`.

The new per-sample summary field is:

- `physical_rule_metrics`

It currently contains:

- `reference_pair_count`
- `predicted_geometric_pair_count`
- `predicted_wc_pair_count`
- `predicted_wc_complementarity`
- `predicted_wc_occupancy`
- `predicted_wc_conflict_rate`
- `predicted_wc_precision`
- `predicted_wc_recall`
- `predicted_wc_f1`
- `reference_pair_distance_mean`
- `predicted_reference_pair_distance_mean`
- `reference_pair_distance_rms_error`
- `helix_step_count`
- `helix_step_distance_mean`
- `predicted_helix_step_distance_mean`
- `helix_step_distance_mae`
- `helix_step_axis_score`
- `wc_helix_rule_score`

## Metric Meaning

### Reference Pair Construction

- Reference pairs are built greedily from the target structure using:
  - cross-strand nearest-neighbor matching,
  - base complement rule `A-T` or `C-G`,
  - a configurable spatial cutoff (`--wc-pair-cutoff`, default `4.0`).

This is a geometry-derived proxy for duplex pairing in the absence of an explicit pair list.

### Predicted Watson-Crick Metrics

- `predicted_wc_complementarity`:
  fraction of predicted geometric cross-strand pairs that are valid `A-T/G-C`.

- `predicted_wc_occupancy`:
  fraction of reference-pair nucleotides that receive a predicted valid partner.

- `predicted_wc_conflict_rate`:
  fraction of nucleotides that have multiple geometric partner candidates under the cutoff.

- `predicted_wc_precision/recall/f1`:
  overlap between predicted valid pairs and reference valid pairs.

### Helix Metrics

- `reference_pair_distance_rms_error`:
  how much predicted pair separation deviates from target pair separation.

- `helix_step_distance_mae`:
  error in center-to-center distance between adjacent duplex pair centers.

- `helix_step_axis_score`:
  cosine alignment between predicted local duplex-step direction and target duplex-step direction.

### Aggregate Score

- `wc_helix_rule_score` is a simple average over:
  - WC precision,
  - WC recall,
  - complementarity,
  - occupancy,
  - pair-distance consistency score,
  - helix-step distance consistency score,
  - helix-step axis score.

This is the main one-number diagnostic for “is the DGNN-lite output physically duplex-like”.

## Interpretation For Current Work

- If `RMSD` improves but `wc_helix_rule_score` stays poor:
  the model is fitting coordinates without learning duplex structure.

- If `OS` improves but WC/helix scores stay poor:
  the model is improving local frame agreement without learning complementary cross-strand organization.

- If `wc_helix_rule_score` rises together with `RMSD` and `OS`:
  that is stronger evidence that the model is moving toward physically meaningful predictions.

## Recommended Next Steps

### Short-Term

Use the new metric only as evaluation first:

1. Run existing DGNN-lite or graph-shared checkpoints.
2. Compare `final_rmsd`, `final_os`, and `physical_rule_metrics`.
3. Identify designs where geometry is close but duplex rules still fail.

### Medium-Term

Add training signals derived from the same structure:

1. Pair-consistency loss:
   penalize deviation of predicted pair distances from target pair distances on reference pairs.

2. Helix-step loss:
   penalize predicted adjacent duplex-step spacing and axis direction error.

3. Pair-conflict penalty:
   discourage one nucleotide from geometrically matching multiple partner candidates.

### Longer-Term

Move beyond proxy geometry:

1. Derive explicit duplex pair annotations from cadnano/tacoxdna/routing data when available.
2. Add a dedicated pair-edge channel to `DGNN-lite`.
3. Separate:
   - coordinate/orientation generation,
   - duplex pairing/routing inference,
   - final sequence assignment.

This matches the direction suggested by Generative SNUPI: geometry first, exact sequence complementarity downstream.

## Limitations

- Current pair labels are inferred from geometry plus complementarity, not from ground-truth routing annotations.
- The metric is therefore a proxy for physical plausibility, not a chemically exact hydrogen-bond model.
- It is still much better than using `RMSD/OS` alone, because current predictions can have low physical meaning even when those metrics improve.

## Files Changed

- `ebd_oxdna/physical_metrics.py`
- `scripts/ebd_oxdna_shared_rigid_train.py`
- `scripts/ebd_oxdna_physical_eval.py`
- `scripts/ebd_oxdna_physical_eval_manifest.py`
- `tests/test_physical_metrics.py`
- `tests/test_ebd_oxdna_shared_rigid_train_cli.py`
- `tests/test_ebd_oxdna_physical_eval_manifest_cli.py`

## First Real-DGNN-lite Evidence

Using the direct A30 DGNN-lite output:

- prediction:
  `outputs/manual_a30_dgnn_lite_ntstrat_adamw_coswarm_200e/101_50_bp_nicked.conf`
- physical evaluation summary:
  `outputs/manual_a30_dgnn_lite_ntstrat_adamw_coswarm_200e/101_50_bp_nicked_physical_metrics.json`

Observed metrics:

- `wc_helix_rule_score = 0.4392829768216692`
- `predicted_wc_f1 = 0.25`
- `predicted_wc_precision = 0.42857142857142855`
- `predicted_wc_recall = 0.17647058823529413`
- `predicted_wc_complementarity = 0.42857142857142855`
- `predicted_wc_conflict_rate = 1.0`
- `helix_step_axis_score = 0.32088017721588796`
- `reference_pair_distance_rms_error = 0.9358440647136059`

Interpretation:

- This is explicit evidence that the current DGNN-lite prediction is still physically poor even when a full `.conf` output exists.
- The worst signals are:
  - near-total pairing ambiguity (`conflict_rate = 1.0`),
  - weak reference-pair recovery (`recall = 0.1765`),
  - poor local duplex-axis consistency (`axis_score ≈ 0.321`).
- Therefore, the next acceptable model change should not only optimize `RMSD/OS`; it must improve this physical-rule score as well.

## Batch Evaluation Capability

Added batch evaluator:

- `scripts/ebd_oxdna_physical_eval_manifest.py`

It reads an existing trainer summary with per-sample `top/start/target/output` paths and writes:

- per-sample `physical_rule_metrics`
- dataset-level means
- `worst_by_wc_helix_rule_score`
- `best_by_wc_helix_rule_score`

This is the direct path for auditing current DGNN-lite checkpoints over many designs before changing the training objective.

## Symmetry-Loss Result Update

The direct local A30 symmetry probe later completed and is now the best aggregate held-out WC/helix result in the `small3` candidate-WC series.

Output:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_physcmp_10e_lr1e3_w1e2/summary.json`

Validation design `101_50_bp_nicked`:

- `final_rmsd = 34.0812`
- `final_os = 0.05945`
- `predicted_wc_precision = 0.47826`
- `predicted_wc_recall = 0.21569`
- `predicted_wc_f1 = 0.29730`
- `predicted_wc_complementarity = 0.45098`
- `predicted_wc_occupancy = 0.45098`
- `predicted_wc_conflict_rate = 1.0`
- `reference_pair_distance_rms_error = 0.44432`
- `helix_step_distance_mae = 0.21527`
- `helix_step_axis_score = 0.39934`
- `wc_helix_rule_score = 0.52667`

Relative to the previous three settings:

- sparse candidate-WC graph only,
- candidate-WC plus pair-head BCE,
- candidate-WC plus pair-head BCE and row-wise exclusivity,

the symmetry term is the best aggregate physical setting tested so far.

Interpretation:

- Symmetry helps because true pair preference should be approximately reciprocal on the directed candidate graph.
- But symmetry alone does not solve the main failure mode, because `predicted_wc_conflict_rate` remains `1.0`.
- So the model now scores candidate pair directions more consistently, but still does not enforce one-to-one partner selection strongly enough.

Updated next-step recommendation:

1. Keep sparse candidate WC edges.
2. Keep pair classification.
3. Keep symmetry loss.
4. Replace row-only exclusivity with a stronger one-to-one relaxation:
   - row + column exclusivity, or
   - Sinkhorn / doubly-stochastic soft matching over candidate pair blocks.

## Stronger Exclusivity Approximation

The first implementation step beyond row-only exclusivity is now in place in the current repo state.

Change:

- `_pair_logit_exclusivity_loss(...)` in `scripts/ebd_oxdna_shared_rigid_train.py` no longer only scans outgoing candidate edges grouped by `src`.
- It now scans both:
  - outgoing candidate groups by `src`, and
  - incoming candidate groups by `dst`.
- For each node-group with more than one candidate edge, it penalizes excess pair-probability mass:
  - `clamp(sum(sigmoid(logits_group)) - 1, min=0)`

Interpretation:

- This is still a soft local relaxation, not a full combinatorial matching layer.
- But it is more aligned with one-to-one duplex pairing than the previous row-wise-only loss.
- The old form mainly encouraged individual logits to move away from uncertain mid-range values.
- The new form explicitly penalizes cases where one nucleotide tries to distribute more than one unit of total partner probability across multiple candidates, whether as source or destination.

Verification:

- Added a regression test showing the new exclusivity loss is higher for a many-to-one column conflict than for a comparable one-to-one assignment.
- Existing symmetry and CLI summary/history tests still pass.

Why this is the right next step:

- The best current held-out symmetry run still has `predicted_wc_conflict_rate = 1.0`.
- That means the model already benefited from candidate-WC edges, pair BCE, and reverse-edge symmetry, but still lacked enough pressure toward one-to-one partner selection.
- Row+column mass-capped exclusivity is the smallest implementation step that pushes directly on that failure mode without yet introducing a full Sinkhorn block.

## Direct A30 Row+Column Exclusivity Follow-Up Started

After implementing the stronger exclusivity loss, a new short direct local A30 probe was started to test whether the added row+column mass cap can reduce the persistent `predicted_wc_conflict_rate = 1.0` failure mode.

Output root:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairx1e2_pairsym1e2_physcmp_10e_lr1e3_w1e2_rowcol/`

Key settings:

- manifest: `outputs/manifests/nupack_small3.json`
- `model_kind=dgnn-lite`
- `epochs=10`
- `learning_rate=0.001`
- `optimizer=adamw`
- `graph_mode=backbone`
- `include_candidate_wc_edges=true`
- `candidate_wc_top_k=2`
- `candidate_wc_cutoff=5.0`
- `pair_distance_loss_weight=0.01`
- `helix_step_loss_weight=0.01`
- `pair_classification_loss_weight=0.02`
- `pair_logit_exclusivity_loss_weight=0.01`
- `pair_logit_symmetry_loss_weight=0.01`
- `orientation_loss_weight=1.0`
- `shared_hidden_dim=256`
- `message_passing_steps=3`
- `fourier_features=4`
- `design_features=stats`
- `dropout=0.1`
- `feature_noise_std=0.01`

Runtime notes:

- direct local GPU use, not Slurm
- `CUDA_VISIBLE_DEVICES=2`
- script required explicit `--device cuda:0` because `--device cuda` raises a PyTorch device-index error in the current trainer
- an attempted launch with `--split-strategy design-order` failed immediately because the current CLI only accepts `random` or `nt-stratified`
- the active probe was relaunched with `--split-strategy random`
- observed live training output:
  - `epoch=1 loss=260.59933567 position_loss=259.410337448 orientation_loss=1.04915747046 os=-0.0491574574262`

### Result

The probe completed and wrote:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairx1e2_pairsym1e2_physcmp_10e_lr1e3_w1e2_rowcol/summary.json`

Validation design `101_50_bp_nicked`:

- `final_rmsd = 8.9477`
- `final_os = 0.25864`
- `predicted_wc_precision = 0.25333`
- `predicted_wc_recall = 0.07661`
- `predicted_wc_f1 = 0.11765`
- `predicted_wc_complementarity = 0.30242`
- `predicted_wc_occupancy = 0.30242`
- `predicted_wc_conflict_rate = 1.0`
- `reference_pair_distance_rms_error = 0.66525`
- `helix_step_distance_mae = 0.28919`
- `helix_step_axis_score = 0.24364`
- `wc_helix_rule_score = 0.40054`

Compared with the prior pair-head + symmetry baseline:

- baseline symmetry:
  - `final_rmsd = 34.0812`
  - `final_os = 0.05945`
  - `predicted_wc_f1 = 0.29730`
  - `predicted_wc_conflict_rate = 1.0`
  - `wc_helix_rule_score = 0.52667`
- row+column exclusivity + symmetry:
  - `final_rmsd = 8.9477`
  - `final_os = 0.25864`
  - `predicted_wc_f1 = 0.11765`
  - `predicted_wc_conflict_rate = 1.0`
  - `wc_helix_rule_score = 0.40054`

Interpretation:

- This is a strong negative result for the current soft matching approximation.
- The stronger exclusivity term substantially improves standard fit metrics:
  - RMSD improves a lot,
  - OS improves a lot.
- But it makes the duplex-physical metrics worse across the board and still does not reduce `predicted_wc_conflict_rate` below `1.0`.

Conclusion:

- The current row+column mass-cap approximation is not yet an aligned fix for WC pairing.
- It likely pushes the model toward easier coordinate/orientation fits without actually recovering the intended complementary partner structure.
- Therefore, the next step should not be more scalar tuning of this exact loss form.
- The better next move is a structurally sharper partner-selection mechanism:
  - explicit candidate-pair normalization by pair blocks,
  - or a Sinkhorn / doubly-stochastic relaxation,
  - or direct supervision on extracted pair assignments after a separate geometric preselection stage.

## Sinkhorn-Style Pair Matching Loss

The next sharper candidate-partner mechanism is now minimally implemented in the current repo state.

Change:

- Added `_pair_logit_sinkhorn_loss(...)` to `scripts/ebd_oxdna_shared_rigid_train.py`.
- Added CLI weight:
  - `--pair-logit-sinkhorn-loss-weight`
- Added trainer logging and summary fields:
  - `pair_logit_sinkhorn_loss` in epoch history
  - `pair_logit_sinkhorn_loss_weight` in summary JSON

Current form:

- Builds a dense score matrix over the nodes that participate in candidate pair edges.
- Fills missing candidate entries with a strong negative score.
- Suppresses self-pairs with a large negative diagonal bias.
- Runs a small number of Sinkhorn-style alternating row/column normalizations over `exp(score_matrix)`.
- Penalizes disagreement between edge sigmoid probabilities and the normalized transport entries.
- Also penalizes row/column sums drifting away from `1.0`.

Interpretation:

- This is still a lightweight approximation, not a full masked optimal-transport layer.
- But it is structurally sharper than the previous mass-cap exclusivity loss because it explicitly constructs a near doubly-stochastic partner assignment.

Verification:

- Added a regression test showing the Sinkhorn-style loss is lower for a near-permutation assignment than for a conflicting assignment.
- Added a CLI regression test showing the new loss weight and history field are recorded in `summary.json`.
- Existing `py_compile` and targeted shared-trainer tests pass after the change.

Status:

- Implementation is complete and verified locally.
- The next scientific step is a short direct A30 probe against the same `small3` candidate-WC regime to see whether this sharper soft matching actually reduces `predicted_wc_conflict_rate` without repeating the failure mode of the simpler row+column mass-cap approximation.

## Direct A30 Sinkhorn-Style Probe Result

The short direct local A30 Sinkhorn-style probe completed and wrote:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_pairsink5e3_physcmp_10e_lr1e3_w1e2/summary.json`

Key settings:

- same `small3` candidate-WC + pair-classification + symmetry regime as the prior comparison
- `pair_logit_sinkhorn_loss_weight = 0.005`
- `pair_logit_exclusivity_loss_weight = 0.0`
- `pair_logit_symmetry_loss_weight = 0.01`

Validation design `101_50_bp_nicked`:

- `final_rmsd = 8.8946`
- `final_os = 0.23322`
- `predicted_wc_precision = 0.24658`
- `predicted_wc_recall = 0.07258`
- `predicted_wc_f1 = 0.11215`
- `predicted_wc_complementarity = 0.29084`
- `predicted_wc_occupancy = 0.29435`
- `predicted_wc_conflict_rate = 1.0`
- `reference_pair_distance_rms_error = 0.65335`
- `helix_step_distance_mae = 0.27957`
- `helix_step_axis_score = 0.25045`
- `wc_helix_rule_score = 0.39842`

Three-way comparison:

- symmetry baseline:
  - `final_rmsd = 34.0812`
  - `final_os = 0.05945`
  - `predicted_wc_f1 = 0.29730`
  - `predicted_wc_conflict_rate = 1.0`
  - `wc_helix_rule_score = 0.52667`
- row+column mass-cap exclusivity + symmetry:
  - `final_rmsd = 8.9477`
  - `final_os = 0.25864`
  - `predicted_wc_f1 = 0.11765`
  - `predicted_wc_conflict_rate = 1.0`
  - `wc_helix_rule_score = 0.40054`
- Sinkhorn-style + symmetry:
  - `final_rmsd = 8.8946`
  - `final_os = 0.23322`
  - `predicted_wc_f1 = 0.11215`
  - `predicted_wc_conflict_rate = 1.0`
  - `wc_helix_rule_score = 0.39842`

Interpretation:

- This is the second consecutive negative result for pair-logit-only soft matching.
- Sinkhorn-style matching does not fix the main physical failure mode:
  - `predicted_wc_conflict_rate` remains `1.0`
  - WC recovery and helix metrics remain much worse than the symmetry baseline.
- It behaves very similarly to the simpler row+column mass-cap approximation:
  - much better standard fit metrics,
  - much worse duplex-physical metrics.

Updated conclusion:

- Candidate-pair soft matching over logits alone is not sufficient in the current DGNN-lite setup.
- It seems to improve coordinate/orientation fit without causing the network to place complementary cross-strand nucleotides into the correct physically meaningful partner structure.
- Therefore, the next aligned step should move away from more pair-logit-only relaxations and instead tighten the geometry-to-pair coupling itself.

Most likely next directions:

1. derive pair supervision from sharper geometric preselection windows or explicit routing/topology annotations when available;
2. add pair-aware message passing or pair-state latent variables rather than only post-hoc edge-logit losses;
3. if staying purely geometric, supervise duplex centers / local pair frames / helix-step structure more directly so improved RMSD cannot come from physically wrong cross-strand organization.

## Direct Duplex-Coupled Supervision Added

Because two consecutive pair-logit-only soft matching experiments failed in the same way, the next aligned move in the current repo state is now a more direct geometry-to-pair coupling path.

Added to `ebd_oxdna/physical_metrics.py`:

- `reference_pair_center_loss(...)`
- `reference_pair_axis_loss(...)`

Meaning:

- `reference_pair_center_loss` supervises the midpoint of each reference WC pair, not just the inter-nucleotide distance.
- `reference_pair_axis_loss` supervises the direction of the local pair axis, i.e. the normalized vector from one nucleotide in the pair to the other.

Why this is different from previous losses:

- `reference_pair_distance_loss` can be satisfied by many geometrically wrong arrangements that preserve only pair separation.
- `pair-logit` losses can improve assignment scores without fixing the actual cross-strand geometry.
- Pair-center and pair-axis losses tie the geometry itself more tightly to the intended duplex organization.

Trainer integration:

- Added CLI weights in `scripts/ebd_oxdna_shared_rigid_train.py`:
  - `--pair-center-loss-weight`
  - `--pair-axis-loss-weight`
- Added epoch history fields:
  - `pair_center_loss`
  - `pair_axis_loss`
- Added summary fields:
  - `pair_center_loss_weight`
  - `pair_axis_loss_weight`

Verification:

- Added a physical-metrics regression test showing:
  - pair-center loss is zero on the target geometry and positive when pair midpoints are shifted;
  - pair-axis loss is zero on the target geometry and positive when pair directions are rotated.
- Added a CLI regression test showing the new weights and history fields are recorded in `summary.json`.

Status:

- This is now the first implementation in the repo that directly supervises local duplex pair geometry beyond pair distance and helix-step center spacing.
- The next scientific step is a short direct A30 probe in the `small3` regime to see whether this more direct geometric coupling improves WC/helix metrics without reproducing the negative behavior of pair-logit-only matching losses.

## Direct A30 Pair-Center / Pair-Axis Probe Result

The short direct local A30 probe with direct duplex-coupled pair geometry supervision completed and wrote:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_paircenter1e2_pairaxis1e2_physcmp_10e_lr1e3_w1e2/summary.json`

Key settings:

- same `small3` candidate-WC + pair-classification + symmetry regime
- `pair_center_loss_weight = 0.01`
- `pair_axis_loss_weight = 0.01`
- `pair_logit_exclusivity_loss_weight = 0.0`
- `pair_logit_sinkhorn_loss_weight = 0.0`

Validation design `101_50_bp_nicked`:

- `final_rmsd = 8.9398`
- `final_os = 0.21946`
- `predicted_wc_precision = 0.25`
- `predicted_wc_recall = 0.07258`
- `predicted_wc_f1 = 0.11250`
- `predicted_wc_complementarity = 0.29150`
- `predicted_wc_occupancy = 0.29032`
- `predicted_wc_conflict_rate = 1.0`
- `reference_pair_distance_rms_error = 0.66328`
- `helix_step_distance_mae = 0.28640`
- `helix_step_axis_score = 0.24589`
- `wc_helix_rule_score = 0.39679`

Comparison against the previous three best-informative probes:

- symmetry baseline:
  - `final_rmsd = 34.0812`
  - `final_os = 0.05945`
  - `predicted_wc_f1 = 0.29730`
  - `wc_helix_rule_score = 0.52667`
- row+column mass-cap exclusivity:
  - `final_rmsd = 8.9477`
  - `final_os = 0.25864`
  - `predicted_wc_f1 = 0.11765`
  - `wc_helix_rule_score = 0.40054`
- Sinkhorn-style matching:
  - `final_rmsd = 8.8946`
  - `final_os = 0.23322`
  - `predicted_wc_f1 = 0.11215`
  - `wc_helix_rule_score = 0.39842`
- pair-center + pair-axis geometry:
  - `final_rmsd = 8.9398`
  - `final_os = 0.21946`
  - `predicted_wc_f1 = 0.11250`
  - `wc_helix_rule_score = 0.39679`

Interpretation:

- This direct local duplex-geometry supervision did not materially beat the previous pair-logit-only relaxations.
- It again improved standard fit metrics relative to the old symmetry baseline.
- But it still failed to improve the physically meaningful WC/helix criteria, and `predicted_wc_conflict_rate` remained `1.0`.

Updated conclusion:

- The main bottleneck is likely no longer the exact scalar loss form.
- The more fundamental issue is that the current reference-pair proxy and candidate-pair geometry are not sharp enough to anchor the model to the correct duplex organization.
- In other words: with the current proxy pair labels, both pair-logit matching and direct local pair geometry supervision collapse toward better coordinate fit without recovering correct complementary partner structure.

Most likely next steps now:

1. replace or sharpen the reference-pair source itself, ideally using explicit routing / topology annotations when available;
2. derive more reliable local duplex targets such as pair frames or per-pair canonical transforms from external structure information rather than only greedy geometric proxy pairs;
3. if those annotations are unavailable, move up one level and model duplex segments / domains / helices as structured units instead of only nucleotide-pair penalties.

## First A30 Training Comparison With Physical Loss Hooks

Started two direct A30 `small3` DGNN-lite comparison runs in the `ebd` CUDA environment on 2026-06-12:

- baseline:
  `outputs/manual_a30_small3_dgnn_baseline_physcmp_30e/`
- pair+helix auxiliary loss:
  `outputs/manual_a30_small3_dgnn_pairhelix_physcmp_30e/`

Common settings:

- manifest: `outputs/manifests/nupack_small3.json`
- train: `11_Nanolett_Burns_Howorka_2013`, `12_26._Burns_Howorka_ACIE_2013`
- val: `101_50_bp_nicked`
- model: `dgnn-lite`
- epochs: `30`
- optimizer: `adamw`
- hidden dim: `256`
- message steps: `3`

Early logs observed before summary files were written:

### Baseline

- epoch 1:
  - loss `60.0623`
  - position_loss `59.1608`
  - orientation_loss `0.9015`
  - os `0.0985`
- epoch 15:
  - loss `233991.8984`
  - position_loss `233990.8984`
  - os `0.0040`
- epoch 30:
  - loss `41.5485`
  - position_loss `40.5521`
  - os `0.0036`

### Pair + Helix Auxiliary Loss

- weights:
  - `pair_distance_loss_weight = 0.1`
  - `helix_step_loss_weight = 0.1`
- epoch 1:
  - loss `69.9330`
  - position_loss `59.1608`
  - orientation_loss `0.9015`
  - os `0.0985`
- epoch 15:
  - loss `137334.2031`
  - position_loss `129343.2148`
  - os `0.0118`
- epoch 30:
  - loss `108.0400`
  - position_loss `99.4888`
  - os `0.0146`

Interpretation so far:

- The auxiliary pair/helix terms clearly change optimization behavior.
- They do not yet solve the main issue: `OS` still collapses close to zero by 30 epochs in both runs.
- However, the physical-loss run has measurably different dynamics and slightly higher `OS` at epochs 15 and 30, so the hook is active and worth further controlled tuning.
- Final judgment should wait for the run summaries and then compare:
  - `final_rmsd`
  - `final_os`
  - `physical_rule_metrics.wc_helix_rule_score`

## Auditable Short A30 Comparison

Because the 30e runs exited after writing predictions but before writing `summary.json`, a shorter 5e comparison was executed to obtain auditable prediction files and direct physical-rule evaluation on the validation design `101_50_bp_nicked`.

Outputs:

- baseline prediction:
  `outputs/manual_a30_small3_dgnn_baseline_physcmp_5e/101_50_bp_nicked.conf`
- pair+helix prediction:
  `outputs/manual_a30_small3_dgnn_pairhelix_physcmp_5e/101_50_bp_nicked.conf`
- baseline physical eval:
  `outputs/manual_a30_small3_dgnn_baseline_physcmp_5e/101_50_bp_nicked_physical_metrics.json`
- pair+helix physical eval:
  `outputs/manual_a30_small3_dgnn_pairhelix_physcmp_5e/101_50_bp_nicked_physical_metrics.json`

Observed validation physical metrics:

### Baseline 5e

- `wc_helix_rule_score = 0.056654064430169786`
- `predicted_wc_f1 = 0.0`
- `predicted_wc_conflict_rate = 0.0`
- `helix_step_axis_score = -0.20695864122647506`

### Pair + Helix 5e

- `wc_helix_rule_score = 0.07283390485995138`
- `predicted_wc_f1 = 0.0`
- `predicted_wc_conflict_rate = 0.0`
- `helix_step_axis_score = 0.019018596754624292`

### Pair Only 5e

- `wc_helix_rule_score = 0.07095199465827796`
- `predicted_wc_f1 = 0.0`
- `predicted_wc_conflict_rate = 0.0`
- `helix_step_axis_score = -0.00796346366405487`
- `reference_pair_distance_rms_error = 4694.873503474653`

Complete validation comparison from `summary.json` plus direct physical evaluation:

### Baseline 5e Validation

- `final_rmsd = 807122.5625`
- `final_os = 0.0026208185590803623`
- `wc_helix_rule_score = 0.05665406475767603`

### Pair + Helix 5e Validation

- `final_rmsd = 95716.640625`
- `final_os = 0.0066336276941001415`
- `wc_helix_rule_score = 0.07283390475731412`

### Pair Only 5e Validation

- `final_rmsd = 110603.6171875`
- `final_os = 0.0024563963524997234`
- `wc_helix_rule_score = 0.07095199433062055`

Dataset means over `small3`:

- baseline:
  - train mean RMSD `879997.40625`
  - train mean OS `-0.0005532241630135104`
  - train mean WC score `0.06785557749320423`
  - val mean RMSD `807122.5625`
  - val mean OS `0.0026208185590803623`
  - val mean WC score `0.05665406475767603`
- pair+helix:
  - train mean RMSD `99850.65234375`
  - train mean OS `0.0001879277260741219`
  - train mean WC score `0.07057239989590784`
  - val mean RMSD `95716.640625`
  - val mean OS `0.0066336276941001415`
  - val mean WC score `0.07283390475731412`
- pair-only:
  - train mean RMSD `120488.3046875`
  - train mean OS `-0.000685065780999139`
  - train mean WC score `0.0708348073860646`
  - val mean RMSD `110603.6171875`
  - val mean OS `0.0024563963524997234`
  - val mean WC score `0.07095199433062055`

Interpretation:

- The pair+helix auxiliary losses improve the aggregate physical-rule score from `0.0567` to `0.0728`.
- This is a real but very small gain. The validation output remains physically poor.
- `predicted_wc_f1 = 0.0` in both runs means the model still fails to recover any correct target-derived WC pair matches on this validation design.
- The main visible gain is in local helix-axis behavior, which moved from clearly anti-aligned (`-0.207`) to near-neutral (`0.019`), but this is still far from acceptable.
- The pair-only run is slightly below pair+helix on aggregate score (`0.0710` vs `0.0728`) but looks more stable on pair-distance behavior:
  - baseline pair-distance RMS error: `63449.4444`
  - pair+helix pair-distance RMS error: `10726.7469`
  - pair-only pair-distance RMS error: `4694.8735`
- This suggests the immediate next tuning direction should prioritize pair-distance loss before stronger helix-step constraints.
- However, on this exact 5e `small3` comparison, pair+helix is the best overall setting by validation RMSD, validation OS, and validation WC score simultaneously.
- The current more precise conclusion is:
  - `pair-only` is best for raw pair-distance matching,
  - `pair+helix` is best for the aggregate objective among the tested 5e settings,
  - all three remain unusable because `predicted_wc_f1 = 0.0` and `OS` is still near zero.
- Therefore:
  - the auxiliary losses are active,
  - the direction is not useless,
  - but current settings are nowhere near enough for `RMSD/OS -> 0/1` plus physical validity.

## Lower-LR Stability Comparison In Progress

To test whether the earlier failures were caused more by optimizer instability than by the physical losses themselves, two new `small3` A30 runs were started with:

- learning rate reduced from `0.01` to `0.001`
- pair/helix auxiliary weights reduced from `0.1` to `0.01`
- epochs increased to `10`

Runs:

- pair-only:
  `outputs/manual_a30_small3_dgnn_paironly_physcmp_10e_lr1e3_w1e2/`
- pair+helix:
  `outputs/manual_a30_small3_dgnn_pairhelix_physcmp_10e_lr1e3_w1e2/`

Observed training logs before summary files finished writing:

### Pair Only

- epoch 1: `loss 60.7123`, `os 0.0985`
- epoch 2: `loss 1748.2443`, `os 0.0450`
- epoch 4: `loss 227.3748`, `os 0.1566`
- epoch 6: `loss 28.3032`, `os 0.2182`
- epoch 8: `loss 26.5138`, `os 0.2892`
- epoch 10: `loss 22.6428`, `os 0.3301`

### Pair + Helix

- epoch 1: `loss 61.0493`, `os 0.0985`
- epoch 2: `loss 1739.6682`, `os 0.0448`
- epoch 4: `loss 231.9136`, `os 0.1565`
- epoch 6: `loss 28.1277`, `os 0.2168`
- epoch 8: `loss 25.9945`, `os 0.2952`
- epoch 10: `loss 21.9069`, `os 0.3378`

Interpretation so far:

- This regime is dramatically more stable than the earlier `lr=0.01`, `weight=0.1` experiments.
- `OS` now increases meaningfully instead of collapsing toward zero.
- At epoch 10, pair+helix is slightly ahead of pair-only on both loss and `OS`.
- Final judgment should wait for the completed `summary.json` files and direct physical-rule evaluation, but this is the first strong evidence that the issue is not “physics losses are bad”; it is “physics losses at the earlier scale were unstable.”

## Lower-LR Stability Comparison Finalized

The two 10e lower-LR A30 runs later completed with `summary.json`:

- pair-only:
  `outputs/manual_a30_small3_dgnn_paironly_physcmp_10e_lr1e3_w1e2/summary.json`
- pair+helix:
  `outputs/manual_a30_small3_dgnn_pairhelix_physcmp_10e_lr1e3_w1e2/summary.json`

Validation design `101_50_bp_nicked`:

### Pair Only 10e

- `final_rmsd = 31.9116153717041`
- `final_os = 0.046690016984939575`
- `wc_helix_rule_score = 0.4934289575406094`
- `predicted_wc_f1 = 0.35294117647058826`
- `predicted_wc_precision = 0.7058823529411765`
- `predicted_wc_recall = 0.23529411764705882`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_occupancy = 0.3333333333333333`
- `predicted_wc_complementarity = 0.34`
- `reference_pair_distance_rms_error = 0.5761121415540272`
- `helix_step_distance_mae = 0.24067869725135657`
- `helix_step_axis_score = 0.05557696865155147`

### Pair + Helix 10e

- `final_rmsd = 32.17654800415039`
- `final_os = 0.04702764004468918`
- `wc_helix_rule_score = 0.5049633183347394`
- `predicted_wc_f1 = 0.38235294117647056`
- `predicted_wc_precision = 0.7647058823529411`
- `predicted_wc_recall = 0.2549019607843137`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_occupancy = 0.3333333333333333`
- `predicted_wc_complementarity = 0.34`
- `reference_pair_distance_rms_error = 0.5665128497437257`
- `helix_step_distance_mae = 0.23986191761035186`
- `helix_step_axis_score = 0.051304215422043435`

Interpretation:

- The lower-LR/lower-weight regime confirmed that the earlier failure mode was primarily optimization instability.
- Compared with the 5e unstable setting, the WC/helix proxy score improved dramatically:
  - pair-only: `0.0710 -> 0.4934`
  - pair+helix: `0.0728 -> 0.5050`
- `pair+helix` is now the best aggregate setting on the validation design:
  - best `wc_helix_rule_score`
  - best WC `F1`
  - best WC precision/recall
  - best reference-pair distance RMS error
- However, the outputs are still physically unacceptable:
  - `final_rmsd` remains around `32`
  - `final_os` remains around `0.047`
  - `predicted_wc_conflict_rate` remains `1.0`
  - helix-axis consistency remains close to zero

Updated conclusion:

- The pair/helix auxiliary losses are not inherently the wrong idea.
- The stable next DGNN-lite regime is approximately:
  - `learning_rate = 1e-3`
  - `pair_distance_loss_weight = 1e-2`
  - `helix_step_loss_weight = 1e-2` for the best aggregate result so far
- `pair+helix` should be treated as the preferred aggregate setting for follow-up ablations, while pair-only remains a useful simplification check.
- No success claim is justified until RMSD, OS, pairing conflict, and helix-axis consistency improve together.

## Generative SNUPI Code-Level Interpretation

Local code inspection of the public GenerativeSNUPI repository on 2026-06-12 shows that WC pairing and helical organization are handled mainly in a **post-generation routing stage**, not as an explicit diffusion-time pair-label objective.

Inspected files:

- `/tmp/GenerativeSNUPI_wcinspect/routing.py`
- `/tmp/GenerativeSNUPI_wcinspect/automated_design/auto_design.py`
- `/tmp/GenerativeSNUPI_wcinspect/automated_design/coords_to_triads.py`
- `/tmp/GenerativeSNUPI_wcinspect/automated_design/ults.py`

Key observations:

- `routing.py` loads generated point clouds and calls `automated_DnaOrigami(...)` to recover a full origami design.
- `automated_design/auto_design.py`:
  - constructs regular base-pair edges,
  - infers scaffold routing,
  - assigns helix triads,
  - converts base-pair centers into scaffold/staple nucleotide coordinates,
  - generates staple crossovers and staple routing with `min_pairing_len` constraints.
- `automated_design/coords_to_triads.py` explicitly aligns rotational phase between connected helices and adjusts scaffold crossovers to nearby compatible positions.
- `automated_design/ults.py` places scaffold/staple nucleotides on opposite sides of each base-pair center using signed offsets from the local triad frame.

What this means:

- The generative model is responsible for producing a **duplex-compatible base-pair geometry**.
- Exact scaffold/staple pairing, crossover placement, and helical phase consistency are largely recovered by the downstream routing/design algorithm.
- Therefore, Generative SNUPI does not contradict the current repo direction:
  - geometry should be evaluated with WC/helix plausibility metrics,
  - exact discrete WC pairing can remain a downstream constrained-routing problem unless explicit pair annotations are available.

## GeoTDM Structural Evidence And DGNN-lite Transfer

Date-verified source inspection on 2026-06-12:

- `GeoTDM` CodeGraph was requested by the user and is also required by that repo's `AGENTS.md`.
- In this shell session, neither `codegraph_*` MCP tools nor a local `codegraph` CLI were available, so strict CodeGraph execution was not possible.
- The best available structural evidence was therefore direct source inspection of:
  - `/home/lijingjing/lijj/users/lht2/deeporigami/agent/GeoTDM/datasets/oxdna.py`

Observed `GeoTDM` oxDNA representation:

- Node features encode:
  - base identity one-hot `A/C/G/T`
  - strand-end flags from `prev_idx < 0` and `next_idx < 0`
  - normalized strand id
  - normalized local position within strand
  - normalized strand length fraction
- Graph edges encode only:
  - backbone `prev/next` connectivity as edge type `0`
  - optional skip-2 along-strand connectivity as edge type `1`
- There is no explicit:
  - Watson-Crick pair edge,
  - pair occupancy target,
  - duplex-step edge,
  - helix-axis feature,
  - pairing or helix loss.

This confirms that the current `GeoTDM` oxDNA branch does **not** model WC pairing as a first-class graph relation.

## Concrete DGNN-lite Application Plan

Based on the current `GeoTDM` evidence, the current `DGNN-lite` implementation, and the Generative SNUPI routing pattern, the most defensible transfer path is:

### 1. Keep WC/helix as explicit evaluation and auxiliary supervision

This part is already partly implemented:

- `ebd_oxdna/physical_metrics.py`
- `scripts/ebd_oxdna_shared_rigid_train.py`

Current status:

- `build_reference_duplex_geometry(...)` derives target-side reference pairs and helix steps.
- `compute_wc_helix_metrics(...)` scores predicted geometry for complementarity, occupancy, conflict, pair recovery, pair distance, and helix-step consistency.
- Optional `pair_distance_loss_weight` and `helix_step_loss_weight` already route these constraints into training.

Why this is correct:

- It matches `GeoTDM`: no invented pair-edge supervision that the source method itself does not have.
- It matches Generative SNUPI: geometry first, exact routing later.

### 2. Add duplex-aware graph features before adding new hard labels

The next useful `DGNN-lite` change is not a full routing head. It is a better graph input.

Current `DGNN-lite` edge features are only:

- relative xyz
- distance
- same-strand bit
- backbone bit

Recommended additions:

- `cross_strand_bit`
  - explicit inverse of `same_strand`
- `complementary_base_bit`
  - `1` when source/destination bases are `A-T` or `C-G`
- `local_index_delta`
  - absolute difference in local strand position fraction
- `strand_direction_compatibility`
  - whether `(src.next, dst.prev)` or `(src.prev, dst.next)` is topologically plausible for a duplex step
- `target_reference_pair_bit` for training-only teacher forcing
  - `1` only on reference WC pairs derived from target geometry
- `target_reference_step_bit` for training-only teacher forcing
  - `1` only on adjacent reference duplex-step edges

Important restriction:

- The last two bits should be available only during training/eval when target geometry is present.
- They should not be treated as inference-time inputs.
- They are useful as teacher edges for auxiliary losses, sampling curricula, or edge-drop masking, not as leaked prediction inputs at deployment.

### 3. Add a sparse candidate cross-strand subgraph instead of full pair classification

Do not connect every nucleotide to every other cross-strand nucleotide.

Instead:

- build a candidate cross-strand graph from:
  - complementary bases only,
  - opposite strands only,
  - top-k nearest neighbors under current start geometry or current predicted geometry proxy,
  - optional local-index compatibility window
- run message passing over:
  - backbone edges
  - skip-2 edges
  - candidate cross-strand edges

Why this is preferable:

- It is the closest graph-level analogue to the geometric candidate matching already used in `physical_metrics.py`.
- It keeps memory bounded.
- It lets `DGNN-lite` learn duplex organization without pretending exact routing labels are known.

### Implemented Minimal Version On 2026-06-12

The first minimal code version of this idea is now wired into:

- `scripts/ebd_oxdna_shared_rigid_train.py`

Added graph construction pieces:

- optional sparse candidate WC edges:
  - `--include-candidate-wc-edges`
  - `--candidate-wc-top-k`
  - `--candidate-wc-cutoff`
- candidate edges are built only between:
  - opposite strands
  - complementary bases
  - top-k nearest candidates under the start geometry

Added duplex-aware edge features for `DGNN-lite`:

- relative xyz
- distance
- `same_strand`
- `backbone`
- `cross_strand`
- `complementary`
- `local_index_delta`
- `direction_compatibility`

This is intentionally still a **geometry-side inductive bias**, not a full pair classifier or routing head.

Reason:

- It stays aligned with the `GeoTDM` evidence, which has no explicit pair-edge supervision.
- It stays aligned with Generative SNUPI, which recovers exact duplex/routing structure downstream.
- It is a bounded, testable change that can now be ablated directly on the current `DGNN-lite` trainer.

### First Direct A30 Ablation Of Candidate WC Graph

Ran on 2026-06-12 under the previously stable `small3` regime with validation design `101_50_bp_nicked`:

- baseline backbone graph:
  `outputs/manual_a30_small3_dgnn_backbone_physcmp_10e_lr1e3_w1e2_refresh/summary.json`
- backbone + candidate WC graph:
  `outputs/manual_a30_small3_dgnn_candidatewc_physcmp_10e_lr1e3_w1e2/summary.json`

Common settings:

- `epochs=10`
- `learning_rate=0.001`
- `optimizer=adamw`
- `shared_hidden_dim=256`
- `message_passing_steps=3`
- `graph_mode=backbone`
- `pair_distance_loss_weight=0.01`
- `helix_step_loss_weight=0.01`
- `orientation_loss_weight=1.0`
- `fourier_features=4`
- `design_features=stats`
- `dropout=0.1`
- `feature_noise_std=0.01`

Candidate-WC-only changes:

- `--include-candidate-wc-edges`
- `--candidate-wc-top-k 4`
- `--candidate-wc-cutoff 5.0`

Validation comparison on `101_50_bp_nicked`:

### Backbone Graph

- `final_rmsd = 35.1607`
- `final_os = 0.10933`
- `wc_helix_rule_score = 0.44875`
- `predicted_wc_f1 = 0.15873`
- `predicted_wc_precision = 0.41667`
- `predicted_wc_recall = 0.09804`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_occupancy = 0.23529`
- `predicted_wc_complementarity = 0.23529`
- `reference_pair_distance_rms_error = 0.43011`
- `helix_step_distance_mae = 0.08721`
- `helix_step_axis_score = 0.18172`

### Backbone + Candidate WC Graph

- `final_rmsd = 36.0632`
- `final_os = 0.06586`
- `wc_helix_rule_score = 0.48700`
- `predicted_wc_f1 = 0.20290`
- `predicted_wc_precision = 0.38889`
- `predicted_wc_recall = 0.13725`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_occupancy = 0.35294`
- `predicted_wc_complementarity = 0.36735`
- `reference_pair_distance_rms_error = 0.34450`
- `helix_step_distance_mae = 0.14448`
- `helix_step_axis_score = 0.28268`

Interpretation:

- The candidate WC graph gives a **real physical-structure gain**:
  - `wc_helix_rule_score`: `0.44875 -> 0.48700`
  - `predicted_wc_f1`: `0.15873 -> 0.20290`
  - `predicted_wc_recall`: `0.09804 -> 0.13725`
  - `predicted_wc_occupancy`: `0.23529 -> 0.35294`
  - `predicted_wc_complementarity`: `0.23529 -> 0.36735`
  - `reference_pair_distance_rms_error`: `0.43011 -> 0.34450`
  - `helix_step_axis_score`: `0.18172 -> 0.28268`
- But it does **not** solve the full objective:
  - `final_rmsd` got slightly worse
  - `final_os` got materially worse
  - `predicted_wc_conflict_rate` remains `1.0`
  - `helix_step_distance_mae` also got worse

Conclusion:

- The candidate WC graph is not a final fix, but it is the first graph-side change that measurably improves duplex-physics metrics in a controlled direct A30 comparison.
- Right now it should be treated as a useful inductive bias that needs co-tuning with the orientation/coordinate objective, not as a standalone solution.

## Follow-Up Candidate-WC Sweep

To test whether the first candidate-WC graph tradeoff could be improved without a broad sweep, two minimal follow-up A30 runs were executed on 2026-06-12:

- sparser candidate graph:
  `outputs/manual_a30_small3_dgnn_candidatewc_top2_physcmp_10e_lr1e3_w1e2/summary.json`
- stronger orientation weight on candidate graph:
  `outputs/manual_a30_small3_dgnn_candidatewc_top4_ori2_physcmp_10e_lr1e3_w1e2/summary.json`

Changes relative to the first candidate-WC run:

- `candidatewc_top2`:
  - `--candidate-wc-top-k 2`
  - `orientation_loss_weight = 1.0`
- `candidatewc_top4_ori2`:
  - `--candidate-wc-top-k 4`
  - `orientation_loss_weight = 2.0`

Validation `101_50_bp_nicked` comparison:

### Candidate WC Top-2

- `final_rmsd = 35.9207`
- `final_os = 0.04352`
- `wc_helix_rule_score = 0.49514`
- `predicted_wc_f1 = 0.22857`
- `predicted_wc_precision = 0.42105`
- `predicted_wc_recall = 0.15686`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_occupancy = 0.37255`
- `predicted_wc_complementarity = 0.38`
- `reference_pair_distance_rms_error = 0.33821`
- `helix_step_distance_mae = 0.18495`
- `helix_step_axis_score = 0.32222`

### Candidate WC Top-4 With Orientation Weight 2.0

- `final_rmsd = 36.0816`
- `final_os = 0.05974`
- `wc_helix_rule_score = 0.47969`
- `predicted_wc_f1 = 0.17143`
- `predicted_wc_precision = 0.31579`
- `predicted_wc_recall = 0.11765`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_occupancy = 0.37255`
- `predicted_wc_complementarity = 0.38776`
- `reference_pair_distance_rms_error = 0.34609`
- `helix_step_distance_mae = 0.14325`
- `helix_step_axis_score = 0.28408`

Interpretation:

- `candidatewc_top2` is the best physical-structure setting tested so far on this design:
  - best `wc_helix_rule_score`
  - best WC `F1`
  - best recall
  - best pair-distance RMS error
  - best helix-axis score
- But it also produces the worst `OS` among the four compared settings.
- Increasing `orientation_loss_weight` from `1.0` to `2.0` on the top-4 candidate graph did not recover the lost `OS` enough to justify the physical regression:
  - `final_os` stayed far below the backbone baseline
  - `wc_helix_rule_score` and WC `F1` both dropped relative to `candidatewc_top4`

Updated conclusion:

- The current candidate-WC graph helps the physical duplex proxy most when it is **sparser**, not denser.
- However, the present training objective still trades off duplex physics against OS.
- Therefore, the next useful step is not simply “increase orientation weight more”; it is to decouple or rebalance the orientation objective against the candidate-WC graph, or add a conflict-specific penalty because conflict remains saturated at `1.0` in every tested setting.

## First Pair-Conflict Penalty Probe

To attack the most persistent failure signal directly, a first explicit pair-conflict penalty was added and tested on 2026-06-12.

Implementation status:

- `ebd_oxdna/physical_metrics.py`
  - added `reference_pair_conflict_loss(...)`
- `scripts/ebd_oxdna_shared_rigid_train.py`
  - added `--pair-conflict-loss-weight`
  - loss remains backward-compatible because the default is `0.0`

First direct A30 probe:

- baseline sparse candidate graph:
  `outputs/manual_a30_small3_dgnn_candidatewc_top2_physcmp_10e_lr1e3_w1e2/summary.json`
- same setting + conflict loss:
  `outputs/manual_a30_small3_dgnn_candidatewc_top2_conflict2e2_physcmp_10e_lr1e3_w1e2/summary.json`

Conflict-loss setting change:

- `--pair-conflict-loss-weight 0.02`

Validation `101_50_bp_nicked`:

### Sparse Candidate Graph Baseline

- `final_rmsd = 35.9207`
- `final_os = 0.04352`
- `wc_helix_rule_score = 0.49514`
- `predicted_wc_f1 = 0.22857`
- `predicted_wc_conflict_rate = 1.0`

### Sparse Candidate Graph + Conflict Loss

- `final_rmsd = 35.9188`
- `final_os = 0.03230`
- `wc_helix_rule_score = 0.49512`
- `predicted_wc_f1 = 0.22857`
- `predicted_wc_conflict_rate = 1.0`

Interpretation:

- This first conflict-loss formulation produced essentially **no useful effect** on the measured physical metrics.
- `predicted_wc_conflict_rate` remained saturated at `1.0`.
- The main side effect was slightly worse `OS`.

Conclusion:

- The current conflict penalty formulation is too weak or too non-smooth to change model behavior meaningfully.
- The next aligned step is **not** to blindly increase this exact weight.
- A better next attempt should redesign the penalty itself, for example:
  - a soft overlap / soft assignment loss over candidate complementary partners,
  - a differentiable one-to-one matching relaxation,
  - or a pair-logit head whose outputs can be regularized for exclusivity.

## Soft Partner Exclusivity Repair And Research-Grounded Next Step

On 2026-06-12, the smoother exclusivity path was repaired and revalidated before any further A30 probe.

Validation status:

- `tests/test_physical_metrics.py`
  - restored the hard-conflict fixture to a clean 4-nucleotide duplex
  - kept the 6-nucleotide crowded multi-partner geometry only for the soft exclusivity case
- `tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_soft_partner_exclusivity_weight`
  - passes and confirms the new trainer summary field is wired correctly

Why this matters:

- The previous broken test mixed a 4-node topology with 6 configuration rows.
- That was a validation bug, not evidence about the loss itself.
- With the fixture repaired, the current codebase now has a clean validated path for:
  - candidate cross-strand WC edges,
  - hard conflict counting,
  - soft partner exclusivity,
  - and trainer-side loss-weight recording.

Verified commands:

- `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_physical_metrics -v`
- `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_soft_partner_exclusivity_weight -v`
- `python3 -m py_compile ebd_oxdna/physical_metrics.py scripts/ebd_oxdna_shared_rigid_train.py tests/test_physical_metrics.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`

### Refined interpretation from GenerativeSNUPI

Direct inspection of the public implementation strengthens the earlier literature interpretation:

- `routing.py`
  - final DNA origami export happens only after a downstream routing/design pipeline completes
- `automated_design/auto_design.py`
  - first creates regular base-pair edges / helix configuration
  - then aligns crossovers, assigns loop indices, routes scaffold and staples, and assigns triads
- `automated_design/coords_to_triads.py`
  - enforces local helical frame compatibility and aligned helix-turn geometry at the routing stage

This means the public GenerativeSNUPI code does **not** solve exact Watson-Crick partner assignment inside the main geometry generator in the same way a discrete pair-classifier would.

Instead, the practical split is:

- the generator should produce a duplex-compatible geometric field
- routing / triad assignment should convert that geometry into a legally routed origami design

For this repo, that supports the current direction:

- keep WC and helix as geometry-aware supervision and evaluation in `DGNN-lite`
- do **not** pretend the present coordinate residual model already solves exact discrete partner matching
- do **not** directly copy the full routing stack into the training target

### Refined interpretation from DeepSNUPI

DeepSNUPI remains useful as a reminder that:

- separate position/orientation streams can help
- physics-style auxiliary structure can matter
- cross-helix interactions should not be restricted to backbone-only message passing

But it still does **not** provide an explicit nucleotide-level WC partner label head that can simply be copied here.

Therefore, the right transfer is structural bias and auxiliary physics, not imitation of a nonexistent explicit WC classifier.

### Updated recommended next model change

The current validated codebase and the external research now point to a more specific next step than the earlier hard-conflict attempt.

Recommended next design:

1. add a dedicated candidate-pair head over the existing sparse candidate-WC edges
2. produce symmetric pair logits for each complementary cross-strand candidate edge
3. replace greedy post-hoc exclusivity pressure as the main training signal with a soft matching style objective:
   - partner exclusivity
   - symmetry
   - complement prior
   - distance prior
4. keep the current greedy pair extraction only for evaluation metrics, not as the main differentiable training mechanism

Reason:

- candidate-WC graph structure already improves the physical duplex proxy
- hard conflict count penalty did not work
- soft exclusivity is a better stepping stone, but the real failure is that pairing is still only inferred after coordinate prediction
- a pair-logit head is the smallest change that upgrades WC from a pure post-hoc metric into a learnable structured signal without claiming full routing capability

### Updated helix-rule recommendation

Current helix supervision is still too distance-heavy.

The next helix-side improvement should extend beyond:

- pair distance
- pair-center step distance

to include:

- anti-parallel strand direction consistency
- local duplex-axis alignment
- local twist / phase consistency between adjacent reference pairs

This is the closest transferable lesson from the triad-assignment stage in GenerativeSNUPI without copying the whole routing program into the training objective.

## First Pair-Classification Head Integration

After repairing the validation path, the next minimal model-side step was implemented directly in `DGNN-lite` on 2026-06-12.

Implementation scope:

- `scripts/ebd_oxdna_shared_rigid_train.py`
  - `DgnnLiteRigidModel` now has a small `pair_head`
  - the head reads the same edge-local representation already used for message passing
  - the head outputs one logit per graph edge
- new CLI flag:
  - `--pair-classification-loss-weight`
- new training-side loss term:
  - binary cross-entropy over existing graph edges
  - positive labels are reference duplex pairs derived from target geometry
  - negative labels are other graph edges
- summary / history now record:
  - `pair_classification_loss_weight`
  - `pair_classification_loss`

Important limitation:

- This is **not yet** the full soft matching / one-to-one partner assignment design recommended above.
- It is a minimal first step that turns WC from a pure post-hoc evaluation quantity into a directly learnable signal.
- It still relies on the current graph edges and reference-pair proxy labels.

Why this was the right next step:

- the hard conflict penalty had already failed
- the repaired soft exclusivity path was validated but still acted only on coordinates after the fact
- a pair head is the smallest code change that makes the model explicitly score candidate WC partnerships during training

Verification:

- added test:
  - `tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_pair_classification_loss_weight_and_history`
- passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_pair_classification_loss_weight_and_history -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_soft_partner_exclusivity_weight tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_dgnn_lite_cli_records_candidate_wc_graph_configuration -v`
  - `python3 -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`

Interpretation:

- The codebase now has a clean progression:
  - WC/helix evaluation metrics
  - candidate-WC graph bias
  - hard conflict loss
  - soft exclusivity loss
  - first explicit pair-classification head
- This still does **not** solve the user's final physicality requirement.
- But it materially improves alignment with that requirement because candidate cross-strand pairing is no longer only inferred after coordinate prediction.

## First Direct A30 Pair-Head Probe Started

After the pair-classification head landed and its CLI/summary path was validated, a first direct local A30 ablation was started from the current best physical baseline regime.

Command shape:

- manifest: `outputs/manifests/nupack_small3.json`
- train ids: `11_Nanolett_Burns_Howorka_2013`, `12_26._Burns_Howorka_ACIE_2013`
- val id: `101_50_bp_nicked`
- output root:
  `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_physcmp_10e_lr1e3_w1e2/`
- key settings:
  - `model_kind=dgnn-lite`
  - `epochs=10`
  - `learning_rate=0.001`
  - `optimizer=adamw`
  - `shared_hidden_dim=256`
  - `message_passing_steps=3`
  - `graph_mode=backbone`
  - `include_candidate_wc_edges=true`
  - `candidate_wc_top_k=2`
  - `candidate_wc_cutoff=5.0`
  - `pair_distance_loss_weight=0.01`
  - `helix_step_loss_weight=0.01`
  - `pair_classification_loss_weight=0.02`
  - `orientation_loss_weight=1.0`
  - `fourier_features=4`
  - `design_features=stats`
  - `dropout=0.1`
  - `feature_noise_std=0.01`

Runtime state observed during launch:

- direct local GPU use, not Slurm
- `CUDA_VISIBLE_DEVICES=1`
- process PID `110981`
- observed `Rsl` state with high CPU usage and active GPU memory allocation

Important runtime limitation discovered:

- this trainer writes `summary.json` and prediction `.conf` files only after the full epoch loop and final evaluation complete
- during direct A30 ablations, this creates a poor feedback loop:
  - no early machine-readable epoch records
  - no partial summary
  - no early output directory or JSON artifact to inspect while the run is active

Implication:

- if this probe completes successfully, compare it directly against:
  `outputs/manual_a30_small3_dgnn_candidatewc_top2_physcmp_10e_lr1e3_w1e2/summary.json`
- if direct A30 ablations continue to be the main iteration loop, the trainer should eventually gain one of:
  - per-epoch JSONL logging
  - periodic partial summary flush
  - periodic checkpoint + metrics dump
  - or a lightweight sidecar log artifact

This is not the main scientific result, but it is now a practical harness finding because the current observability gap slows the physicality-improvement loop on A30.

## First Direct A30 Pair-Head Probe Result

The direct local A30 pair-head probe completed on 2026-06-12 and can now be compared against the current best sparse candidate-WC baseline.

Compared runs:

- sparse candidate-WC baseline:
  `outputs/manual_a30_small3_dgnn_candidatewc_top2_physcmp_10e_lr1e3_w1e2/summary.json`
- sparse candidate-WC + pair head:
  `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_physcmp_10e_lr1e3_w1e2/summary.json`

Probe setting change:

- `--pair-classification-loss-weight 0.02`

Validation design `101_50_bp_nicked`:

### Sparse Candidate Graph Baseline

- `final_rmsd = 35.9207`
- `final_os = 0.04352`
- `wc_helix_rule_score = 0.49514`
- `predicted_wc_f1 = 0.22857`
- `predicted_wc_precision = 0.42105`
- `predicted_wc_recall = 0.15686`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_complementarity = 0.38`
- `predicted_wc_occupancy = 0.37255`
- `reference_pair_distance_rms_error = 0.33821`
- `helix_step_distance_mae = 0.18495`
- `helix_step_axis_score = 0.32222`

### Sparse Candidate Graph + Pair Head

- `final_rmsd = 34.1816`
- `final_os = 0.08056`
- `wc_helix_rule_score = 0.49487`
- `predicted_wc_f1 = 0.26087`
- `predicted_wc_precision = 0.5`
- `predicted_wc_recall = 0.17647`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_complementarity = 0.35294`
- `predicted_wc_occupancy = 0.35294`
- `reference_pair_distance_rms_error = 0.44603`
- `helix_step_distance_mae = 0.22271`
- `helix_step_axis_score = 0.39811`

Interpretation:

- This first pair-head probe is **not** a null result.
- It improves several of the most important current failure signals at once:
  - better `final_rmsd`
  - better `final_os`
  - better WC `F1`
  - better WC precision
  - better WC recall
  - better helix-axis score
- But it still fails on the most stubborn ambiguity signal:
  - `predicted_wc_conflict_rate` remains saturated at `1.0`
- It also regresses some geometry-side terms:
  - worse pair-distance RMS error
  - worse helix-step distance MAE
  - worse occupancy
  - worse complementarity
- The aggregate score stays almost unchanged:
  - `0.49514 -> 0.49487`

Updated conclusion:

- Adding an explicit pair-classification signal is more promising than the earlier hard conflict penalty:
  - unlike the hard conflict penalty, it materially improves both standard fit (`RMSD`, `OS`) and some WC-recovery metrics
- However, BCE over existing candidate edges is still not enough to solve partner exclusivity
- Therefore, the next aligned model change should be:
  - keep the pair head
  - move from plain independent edge BCE toward a structured exclusivity objective over candidate partners

Practical next step:

- retain the pair head introduced here
- combine it with a stronger structured loss such as:
  - soft row/column exclusivity
  - symmetric partner agreement
  - or a differentiable one-to-one matching relaxation
- do **not** discard the pair head and go back to conflict-count-only penalties

## First Structured Exclusivity Integration Over Pair Logits

The first follow-up to the pair-head result was implemented on 2026-06-12.

Goal:

- keep the pair head that already improved `RMSD`, `OS`, and WC recovery
- add a structured pressure directly on the pair logits so a nucleotide does not spread probability mass over many candidate partners

Implemented minimal form:

- new CLI flag:
  - `--pair-logit-exclusivity-loss-weight`
- new trainer-side loss:
  - row-wise exclusivity over pair logits
  - for each source nucleotide with multiple candidate edges, compute sigmoid probabilities on its outgoing candidate pair logits
  - penalize `p * (1 - p)` across those candidate probabilities
  - average over source nucleotides with more than one candidate

Scope:

- this is still a minimal structured exclusivity step
- it is **not yet** a full doubly-constrained or matching-relaxation objective
- it does not yet enforce column-wise agreement or explicit symmetry between `i -> j` and `j -> i`

Why this is still useful:

- it directly addresses the main failure left after the first pair-head probe:
  `predicted_wc_conflict_rate = 1.0`
- it preserves the current pair head rather than discarding the best new signal found so far
- it is the smallest code change consistent with the updated recommendation from the previous section

Verification:

- added test:
  - `tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_pair_logit_exclusivity_loss_weight_and_history`
- passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_pair_logit_exclusivity_loss_weight_and_history -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_pair_classification_loss_weight_and_history tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_soft_partner_exclusivity_weight -v`
  - `python3 -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`

Updated next experiment recommendation:

- do **not** return to hard conflict-count tuning
- next direct A30 probe should start from the completed pair-head run and add:
  - `--pair-classification-loss-weight 0.02`
  - `--pair-logit-exclusivity-loss-weight 0.01` or `0.02`
- compare first against:
  - `outputs/manual_a30_small3_dgnn_candidatewc_top2_physcmp_10e_lr1e3_w1e2/summary.json`
  - `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_physcmp_10e_lr1e3_w1e2/summary.json`

Success criterion for that next probe:

- maintain or improve the pair-head gains in:
  - `final_rmsd`
  - `final_os`
  - `predicted_wc_f1`
  - `helix_step_axis_score`
- while reducing:
  - `predicted_wc_conflict_rate`

If conflict still stays at `1.0`, the next upgrade should be:

- add symmetry loss between directed pair logits
- then move to a stronger soft matching relaxation

## Direct A30 Pair-Head + Structured Exclusivity Probe Started

The first direct local A30 probe of the new structured exclusivity path was started on 2026-06-12.

Output root:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairx1e2_physcmp_10e_lr1e3_w1e2/`

Key settings:

- manifest: `outputs/manifests/nupack_small3.json`
- train ids: `11_Nanolett_Burns_Howorka_2013`, `12_26._Burns_Howorka_ACIE_2013`
- val id: `101_50_bp_nicked`
- `model_kind=dgnn-lite`
- `epochs=10`
- `learning_rate=0.001`
- `optimizer=adamw`
- `shared_hidden_dim=256`
- `message_passing_steps=3`
- `graph_mode=backbone`
- `include_candidate_wc_edges=true`
- `candidate_wc_top_k=2`
- `candidate_wc_cutoff=5.0`
- `pair_distance_loss_weight=0.01`
- `helix_step_loss_weight=0.01`
- `pair_classification_loss_weight=0.02`
- `pair_logit_exclusivity_loss_weight=0.01`
- `orientation_loss_weight=1.0`
- `fourier_features=4`
- `design_features=stats`
- `dropout=0.1`
- `feature_noise_std=0.01`

Runtime state observed during launch:

- direct local GPU use, not Slurm
- `CUDA_VISIBLE_DEVICES=1`
- process PID `112532`

Planned comparison once the summary is written:

1. baseline sparse candidate graph:
   `outputs/manual_a30_small3_dgnn_candidatewc_top2_physcmp_10e_lr1e3_w1e2/summary.json`
2. pair-head only:
   `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_physcmp_10e_lr1e3_w1e2/summary.json`
3. pair-head + structured exclusivity:
   this run

Primary question for the next turn:

- does `predicted_wc_conflict_rate` finally move off `1.0` without erasing the pair-head gains in:
  - `final_rmsd`
  - `final_os`
  - `predicted_wc_f1`
  - `helix_step_axis_score`

## Direct A30 Pair-Head + Structured Exclusivity Result

The first direct local A30 structured-exclusivity probe completed on 2026-06-12.

Compared runs:

1. sparse candidate-WC baseline:
   `outputs/manual_a30_small3_dgnn_candidatewc_top2_physcmp_10e_lr1e3_w1e2/summary.json`
2. sparse candidate-WC + pair head:
   `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_physcmp_10e_lr1e3_w1e2/summary.json`
3. sparse candidate-WC + pair head + structured exclusivity:
   `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairx1e2_physcmp_10e_lr1e3_w1e2/summary.json`

Structured-exclusivity probe setting change relative to pair-head-only:

- `--pair-logit-exclusivity-loss-weight 0.01`

Validation design `101_50_bp_nicked`:

### Pair-Head Only

- `final_rmsd = 34.1816`
- `final_os = 0.08056`
- `wc_helix_rule_score = 0.49487`
- `predicted_wc_f1 = 0.26087`
- `predicted_wc_precision = 0.5`
- `predicted_wc_recall = 0.17647`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_complementarity = 0.35294`
- `predicted_wc_occupancy = 0.35294`
- `reference_pair_distance_rms_error = 0.44603`
- `helix_step_axis_score = 0.39811`
- `helix_step_distance_mae = 0.22271`

### Pair-Head + Structured Exclusivity

- `final_rmsd = 34.0757`
- `final_os = 0.05921`
- `wc_helix_rule_score = 0.49622`
- `predicted_wc_f1 = 0.26087`
- `predicted_wc_precision = 0.5`
- `predicted_wc_recall = 0.17647`
- `predicted_wc_conflict_rate = 1.0`
- `predicted_wc_complementarity = 0.35294`
- `predicted_wc_occupancy = 0.35294`
- `reference_pair_distance_rms_error = 0.44073`
- `helix_step_axis_score = 0.39837`
- `helix_step_distance_mae = 0.21595`

Interpretation:

- This first structured-exclusivity step is **not** a null result, but it is also **not** the breakthrough needed.
- Compared with pair-head-only, it:
  - slightly improves `final_rmsd`
  - slightly improves `wc_helix_rule_score`
  - slightly improves pair-distance RMS error
  - slightly improves helix-step distance MAE
  - very slightly improves helix-axis score
- But it does **not** improve:
  - `predicted_wc_f1`
  - WC precision
  - WC recall
  - complementarity
  - occupancy
  - most importantly, `predicted_wc_conflict_rate`
- It also gives back some of the OS gain:
  - `0.08056 -> 0.05921`

Updated conclusion:

- Row-wise exclusivity over pair logits is too weak to change the main ambiguity failure.
- It can mildly regularize geometry around the pair-head solution, but it does not move the model off the `conflict_rate = 1.0` regime.
- Therefore, the next aligned move should **not** be another scalar sweep of this same row-wise loss.

Recommended next model upgrade:

1. keep the pair head
2. add a symmetry loss between directed pair logits:
   - penalize disagreement between `logit(i,j)` and `logit(j,i)`
3. then move to a stronger matching-style relaxation:
   - row + column exclusivity
   - or a doubly-stochastic / one-to-one soft matching objective

This is now evidence-backed:

- hard conflict count failed
- pair head improved `RMSD`, `OS`, and WC recovery
- row-wise pair-logit exclusivity slightly regularized geometry but did not reduce ambiguity
- so the remaining missing ingredient is stronger structured matching, not more independent-edge tuning

## Pair-Logit Symmetry Loss Integrated

The next evidence-backed upgrade after the row-wise exclusivity result was implemented on 2026-06-12.

Goal:

- keep the pair head
- add a stronger structural constraint before attempting a full matching relaxation
- specifically, penalize disagreement between the directed logits on reverse candidate edges

Implemented path:

- new CLI flag:
  - `--pair-logit-symmetry-loss-weight`
- new trainer-side loss:
  - `_pair_logit_symmetry_loss(...)`
  - finds reverse directed edges `(i, j)` and `(j, i)` in the current graph
  - penalizes squared difference between their pair logits
- summary / history now record:
  - `pair_logit_symmetry_loss_weight`
  - `pair_logit_symmetry_loss`

Why this is the right next step:

- pair-head-only improved `RMSD`, `OS`, WC `F1`, and helix-axis score
- row-wise exclusivity alone did not reduce ambiguity
- the most direct missing structural condition before full matching is that pair preferences should at least agree in both directions

Verification:

- added tests:
  - `tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_pair_logit_symmetry_loss_weight_and_history`
  - `tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_pair_logit_symmetry_loss_is_higher_for_asymmetric_reverse_edges`
- passed:
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_pair_logit_symmetry_loss_weight_and_history tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_pair_logit_symmetry_loss_is_higher_for_asymmetric_reverse_edges -v`
  - `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_pair_logit_exclusivity_loss_weight_and_history tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_records_pair_classification_loss_weight_and_history -v`
  - `python3 -m py_compile scripts/ebd_oxdna_shared_rigid_train.py tests/test_ebd_oxdna_shared_rigid_train_cli.py`

Updated next experiment recommendation:

- do not run more probes with row-wise exclusivity alone
- next direct A30 probe should use:
  - `--pair-classification-loss-weight 0.02`
  - `--pair-logit-symmetry-loss-weight 0.01`
- if that still leaves `predicted_wc_conflict_rate = 1.0`, the next upgrade should be a true row+column matching relaxation rather than more scalar tuning

## Direct A30 Pair-Head + Symmetry Probe Started

The first direct local A30 symmetry probe was started on 2026-06-12.

Output root:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_physcmp_10e_lr1e3_w1e2/`

Key settings:

- manifest: `outputs/manifests/nupack_small3.json`
- train ids: `11_Nanolett_Burns_Howorka_2013`, `12_26._Burns_Howorka_ACIE_2013`
- val id: `101_50_bp_nicked`
- `model_kind=dgnn-lite`
- `epochs=10`
- `learning_rate=0.001`
- `optimizer=adamw`
- `shared_hidden_dim=256`
- `message_passing_steps=3`
- `graph_mode=backbone`
- `include_candidate_wc_edges=true`
- `candidate_wc_top_k=2`
- `candidate_wc_cutoff=5.0`
- `pair_distance_loss_weight=0.01`
- `helix_step_loss_weight=0.01`
- `pair_classification_loss_weight=0.02`
- `pair_logit_symmetry_loss_weight=0.01`
- `orientation_loss_weight=1.0`
- `fourier_features=4`
- `design_features=stats`
- `dropout=0.1`
- `feature_noise_std=0.01`

Runtime state observed during launch:

- direct local GPU use, not Slurm
- `CUDA_VISIBLE_DEVICES=2`
- process PID `114048`
- at end of the current turn it was still alive in active `Rsl` state with GPU memory allocated, so no scientific result is claimed yet

Planned comparison once the summary is written:

1. baseline sparse candidate graph
2. pair-head only
3. pair-head + row-wise exclusivity
4. pair-head + symmetry

Primary question for the next turn:

- does symmetry improve over pair-head-only or row-wise exclusivity on:
  - `predicted_wc_conflict_rate`
  - `predicted_wc_f1`
  - `final_os`
  - `wc_helix_rule_score`

### 4. Do not directly copy Generative SNUPI routing into the network

The following should remain downstream or auxiliary logic, not the main `DGNN-lite` prediction target:

- staple routing
- crossover relocation heuristics
- full scaffold-route reconstruction
- exact duplex phase assignment across the whole origami

Reason:

- Those steps are combinatorial constrained design logic.
- They are appropriate after geometry generation, not as the first thing to supervise in a coordinate residual model.

### 5. Tight success criteria for future DGNN-lite runs

Future runs should not be judged by `RMSD/OS` alone.

A physically meaningful improvement should require all of:

- lower `final_rmsd`
- higher `final_os`
- higher `wc_helix_rule_score`
- lower `predicted_wc_conflict_rate`
- higher `predicted_wc_f1`
- materially positive `helix_step_axis_score`

Practical stop condition:

- If `wc_helix_rule_score` rises while `final_rmsd` and `final_os` stay unusable, treat the change as useful diagnostic evidence, not as a model success.
- If `RMSD/OS` improve but conflict stays near `1.0` and helix-axis score stays near `0`, treat the model as geometrically overfitting without learning duplex physics.

## 2026-06-12 continuation: explicit WC labels from caDNAno + virt2nuc

### New target-source finding

The strongest new evidence is that the current greedy geometric `reference_pairs`
proxy is probably replaceable with explicit scaffold-staple pairing labels derived
from the original design artifacts.

For the `small3` designs, the following sources are available:

- caDNAno-style design JSON:
  - `/home/lijingjing/lijj/users/lht2/deeporigami/agent/nupack/json/q4_bottom25_0.46_to_3.43/101_50_bp_nicked.json`
  - and matching JSONs for `11_Nanolett_Burns_Howorka_2013` and `12_26._Burns_Howorka_ACIE_2013`
- taCOxDNA conversion outputs:
  - `tacoxdna/virt2nuc`
  - `tacoxdna/<design>.json.top`
  - `tacoxdna/cadnano_to_oxdna.log`

The key result is that `virt2nuc` is not opaque noise; it stores explicit mappings
from `(virtual_helix, vbase)` positions to oxDNA nucleotide ids separately for
scaffold and staple strands.

### Decoding result

`virt2nuc` is a pickle of `libs.cadnano_utils.vhelix_vbase_to_nucleotide`.
This shell does not expose that module, so the object was decoded with a compatible
placeholder class plus `__setstate__`.

Recovered state structure for `101_50_bp_nicked`:

- `_scaf[(vh, vb)] -> (strand_id, [nucleotide_index])`
- `_stap[(vh, vb)] -> (strand_id, [nucleotide_index])`

Example explicit paired sites for `101_50_bp_nicked`:

- `(1, 1) -> scaf (0, [1]), stap (1, [75])`
- `(1, 2) -> scaf (0, [2]), stap (1, [74])`
- `(1, 3) -> scaf (0, [3]), stap (1, [73])`

For this design there are `48` shared scaffold/staple occupied `(vh, vb)` sites
that directly define nucleotide-level complementary partners without any geometric
nearest-neighbor inference.

### caDNAno consistency check

The caDNAno JSON itself already marks scaffold and staple occupancy by virtual-helix
position through `vstrands[*]['scaf']` and `vstrands[*]['stap']`.

For `101_50_bp_nicked`:

- top-level keys are `name`, `vstrands`
- there is one virtual helix with `num = 1`
- the JSON and `virt2nuc` agree on `48` double-occupied positions

This means an explicit WC label extractor can be built by:

1. identifying shared `(vh, vb)` positions where scaffold and staple are both present
2. mapping scaffold occupancy through `_scaf`
3. mapping staple occupancy through `_stap`
4. emitting nucleotide-id pairs as the supervision target

### Why this is better than the current proxy

The recent negative results for:

- row+column mass-cap exclusivity
- Sinkhorn-style matching
- pair-center / pair-axis direct geometry

all shared the same weak supervision source: greedy geometric `reference_pairs`.

The new evidence strongly suggests the next bottleneck is target quality, not loss
inventiveness. If the supervision pair labels are wrong or noisy, stronger matching
losses only enforce the wrong assignment more consistently.

### External-model interpretation after re-checking GenerativeSNUPI

The public GenerativeSNUPI code and paper are consistent on one point:

- the generator works at base-pair geometry level
- nucleotide-level scaffold/staple design is handled downstream by routing /
  automated design logic

Useful local evidence:

- `routing.py` routes generated base-pair coordinates into a DNA origami design
- `automated_design/coords_to_triads.py` and related modules reconstruct triads,
  helix indices, crossover candidates, scaffold/staple IDs, and routing-compatible
  edge structure
- `tacox/cadnano_oxDNA.py` explicitly reconstructs nucleotide `pair` links by
  grouping oxDNA nucleotide ids that share the same `(vh, vb)` position

This reinforces the transfer lesson for this repo:

- do not copy the whole routing stack into `DGNN-lite`
- do use the design artifacts to replace weak pseudo-pairs with explicit nucleotide
  pairing labels
- keep helix/routing logic as structured supervision and evaluation around the
  geometry model

### Updated recommended next implementation

The next high-value `DGNN-lite` change should be:

1. add a design-artifact pair-label extractor from `caDNAno JSON + virt2nuc`
2. replace or supplement greedy `reference_pairs` with explicit nucleotide-level
   scaffold-staple labels
3. keep current candidate-WC graph and pair head
4. retrain the `small3` candidate-WC + pair-head + symmetry setting against the
   explicit labels before inventing new losses
5. derive helix-segment supervision from the same source, e.g. contiguous shared
   `(vh, vb)` runs as duplex segments / helical domains

Only after that should new exclusivity or matching losses be re-judged.

### Immediate implementation sketch

Minimal bounded integration path:

- new utility to load `virt2nuc` with a compatibility unpickler
- new helper that converts shared `(vh, vb)` occupancy into explicit nucleotide-id
  pairs
- trainer option to prefer explicit design-derived pair labels when available
- metrics path that reports both:
  - explicit-label pair F1
  - old geometric proxy F1 for backward comparison

This is the first change in the whole WC/helix line that directly attacks the most
likely failure source identified by the local A30 experiments.

## 2026-06-12 continuation: explicit design pairs wired into DGNN-lite trainer

Implemented the first bounded code path that lets `DGNN-lite` consume explicit
design-derived WC labels instead of always falling back to the geometric proxy.

### What changed

In `scripts/ebd_oxdna_shared_rigid_train.py`:

- added a compatibility unpickler for taCOxDNA `virt2nuc` pickles
- added `_load_explicit_reference_pairs(entry)` that reads:
  - `entry["cadnano_json"]`
  - `entry["virt2nuc"]`
- explicit pair extraction now:
  - scans shared scaffold/staple occupied `(vh, vb)` sites from caDNAno JSON
  - maps them through `_scaf` and `_stap`
  - emits canonical nucleotide-id pairs
- `_prepare_sample()` now prefers those explicit pairs when available
- each prepared sample now records:
  - `reference_pair_source`
  - `reference_pairs`
  - `reference_pairs_geometric_proxy`
  - `helix_steps`
  - `helix_steps_geometric_proxy`

In `ebd_oxdna/physical_metrics.py`:

- `compute_wc_helix_metrics(...)` now accepts optional `reference_pairs` and
  `helix_steps`
- this allows the same metric function to evaluate against either:
  - explicit design labels
  - the old geometric proxy

### Why this matters

This is the first implementation step that changes the supervision source rather
than only changing the loss function applied to the same noisy proxy labels.

Training-time losses that now consume `prepared["reference_pairs"]` automatically
benefit from the explicit labels:

- pair-distance loss
- pair-center loss
- pair-axis loss
- pair-classification BCE
- pair-logit structured penalties through their positive labels
- helix-step distance loss

### Summary-level observability

Per-sample summary output now records:

- `reference_pair_source`
- `physical_rule_metrics`
- `physical_rule_metrics_geometric_proxy` when explicit labels are active

This preserves backward comparison with the old metric path while making the
explicit-label path the primary physical metric whenever available.

### Verification status

Added and passed targeted tests:

- explicit pair extraction from `cadnano_json + virt2nuc`
- `_prepare_sample()` preferring explicit design pairs
- CLI summary recording explicit pair source and proxy-metric side channel

This is enough evidence to proceed to the next scientific step:

- rerun the best `small3` candidate-WC + pair-head + symmetry setting with
  manifest entries that include `cadnano_json` and `virt2nuc`
- compare whether explicit labels improve:
  - `predicted_wc_f1`
  - `predicted_wc_conflict_rate`
  - `helix_step_axis_score`
  - `wc_helix_rule_score`
  without destroying `RMSD/OS`

## 2026-06-12 continuation: first explicit-label small3 run

Ran the first direct local A30 ablation that changes only the pair-label source
while keeping the previous best `small3` DGNN-lite hyperparameters fixed.

### Run

- output root:
  - `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_explicitpairs_physcmp_10e_lr1e3_w1e2/`
- manifest:
  - `outputs/manifests/nupack_small3_explicit_pairs.json`
- train ids:
  - `11_Nanolett_Burns_Howorka_2013`
  - `12_26._Burns_Howorka_ACIE_2013`
- val id:
  - `101_50_bp_nicked`
- same model/loss config as the earlier best geometric-proxy run:
  - `model_kind=dgnn-lite`
  - `epochs=10`
  - `learning_rate=0.001`
  - `optimizer=adamw`
  - `shared_hidden_dim=256`
  - `message_passing_steps=3`
  - `graph_mode=backbone`
  - `include_candidate_wc_edges=true`
  - `candidate_wc_top_k=2`
  - `candidate_wc_cutoff=5.0`
  - `pair_distance_loss_weight=0.01`
  - `helix_step_loss_weight=0.01`
  - `pair_classification_loss_weight=0.02`
  - `pair_logit_symmetry_loss_weight=0.01`
  - `orientation_loss_weight=1.0`
  - `fourier_features=4`
  - `design_features=stats`
  - `dropout=0.1`
  - `feature_noise_std=0.01`

### What was verified

- training ran successfully on local A30 and wrote held-out prediction:
  - `101_50_bp_nicked.conf`
- because trainer summary finalization again lagged behind prediction export, the
  held-out result was evaluated directly with:
  - `scripts/ebd_oxdna_physical_eval.py`
- evaluation output:
  - `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_explicitpairs_physcmp_10e_lr1e3_w1e2/101_50_bp_nicked_physical_metrics.json`

### Result versus the previous best geometric-proxy run

Previous best geometric-proxy validation reference:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_physcmp_10e_lr1e3_w1e2/summary.json`

Held-out `101_50_bp_nicked`, evaluated under the same geometric physical metric:

- `predicted_wc_precision`: `0.4783 -> 0.2105`
- `predicted_wc_recall`: `0.2157 -> 0.0784`
- `predicted_wc_f1`: `0.2973 -> 0.1143`
- `predicted_wc_complementarity`: `0.4510 -> 0.3878`
- `predicted_wc_occupancy`: `0.4510 -> 0.3725`
- `predicted_wc_conflict_rate`: `1.0 -> 1.0`
- `reference_pair_distance_rms_error`: `0.4443 -> 0.3303`
- `helix_step_distance_mae`: `0.2153 -> 0.1840`
- `helix_step_axis_score`: `0.3993 -> 0.3189`
- `wc_helix_rule_score`: `0.5267 -> 0.4555`

### Interpretation

This is an important negative but informative result.

Changing the supervision source to explicit design-derived WC labels did **not**
immediately improve held-out physicality under the current model/loss setup.

Observed pattern:

- local duplex distance terms improved:
  - pair-distance RMS error
  - helix-step distance MAE
- but discrete pairing quality got much worse:
  - precision
  - recall
  - F1
  - occupancy
- conflict remained completely unresolved at `1.0`

This updates the bottleneck diagnosis again:

- better labels are necessary
- but the current pair head plus independent BCE/symmetry objective is not strong
  enough to exploit those harder labels
- the model seems able to absorb some local geometric regularity from the explicit
  labels without learning cleaner one-to-one pairing decisions

### Updated next step

Do **not** revert to the old greedy proxy as if it were better ground truth.
Instead, keep the explicit-label path and strengthen the discrete assignment side.

Most aligned next probes are now:

1. explicit labels + symmetry + stronger exclusivity / Sinkhorn-style matching
2. explicit labels + edge filtering so only cross-strand complementary candidate
   edges participate in pair supervision
3. explicit labels + explicit metric split:
   - primary metrics against design labels
   - secondary compatibility metrics against geometric proxy

The key lesson from this run is that explicit labels alone are not sufficient;
they expose the current pair-assignment weakness more clearly.

## 2026-06-12 continuation: explicit-label evaluation path corrected

After the first explicit-label `small3` run, the initial held-out comparison used
the old geometric evaluator only. That was incomplete and slightly misleading,
because the model had been trained against explicit design labels while the metric
still judged it only against the geometric proxy.

### What was fixed

`scripts/ebd_oxdna_physical_eval.py` now supports:

- `--cadnano-json`
- `--virt2nuc`

and emits:

- `reference_pair_source`
- `physical_rule_metrics` as the primary metric
- `physical_rule_metrics_geometric_proxy` as the secondary comparison channel when
  explicit labels are available

This makes the evaluator consistent with the trainer-side explicit-label path.

### Re-evaluated held-out explicit-label result

Re-evaluated file:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_explicitpairs_physcmp_10e_lr1e3_w1e2/101_50_bp_nicked.conf`

New dual-metric output:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_explicitpairs_physcmp_10e_lr1e3_w1e2/101_50_bp_nicked_physical_metrics_explicit.json`

Primary explicit-design metrics on held-out `101_50_bp_nicked`:

- `reference_pair_count = 48`
- `predicted_wc_precision = 0.4737`
- `predicted_wc_recall = 0.1875`
- `predicted_wc_f1 = 0.2687`
- `predicted_wc_complementarity = 0.3878`
- `predicted_wc_occupancy = 0.3958`
- `predicted_wc_conflict_rate = 1.0`
- `reference_pair_distance_rms_error = 0.3527`
- `helix_step_distance_mae = 0.1493`
- `helix_step_axis_score = 0.2887`
- `wc_helix_rule_score = 0.5136`

Secondary geometric-proxy metrics for the same prediction:

- `predicted_wc_f1 = 0.1143`
- `wc_helix_rule_score = 0.4555`

### Updated interpretation

This changes the conclusion from the first quick read.

Under the **primary explicit-design metric**, the first explicit-label run is not
a collapse. It is actually **close to** the previous best geometric-proxy run on
aggregate score:

- old best geometric-proxy run, geometric metric:
  - `wc_helix_rule_score = 0.5267`
- explicit-label run, explicit primary metric:
  - `wc_helix_rule_score = 0.5136`

Important nuance:

- precision is nearly preserved:
  - `0.4783` old best geometric metric
  - `0.4737` explicit primary metric
- the main weakness is still recall / occupancy / conflict:
  - recall `0.1875`
  - occupancy `0.3958`
  - conflict `1.0`

So the new diagnosis is sharper:

- explicit labels are working as a meaningful primary supervision/evaluation source
- the current bottleneck is specifically **recovering more correct pairs without
  many-to-one ambiguity**
- the next change should target assignment structure, not pair-source quality

### Updated next best experiment

The highest-value next direct A30 probe is:

- keep explicit labels active
- keep pair classification and symmetry active
- add a stronger matching-style constraint:
  - either `pair_logit_sinkhorn_loss_weight`
  - or row+column exclusivity with explicit labels

Success should now be judged first by the explicit primary metric, especially:

- higher `predicted_wc_recall`
- higher `predicted_wc_f1`
- lower `predicted_wc_conflict_rate`
- no major regression in:
  - `reference_pair_distance_rms_error`
  - `helix_step_distance_mae`
  - `helix_step_axis_score`

## 2026-06-12 continuation: explicit labels + Sinkhorn matching probe

Ran the first direct explicit-label matching-strengthening probe by adding a
small Sinkhorn-style assignment loss on top of the explicit-label baseline.

### Run

- output root:
  - `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_pairsink5e3_explicitpairs_physcmp_10e_lr1e3_w1e2/`
- same `small3` explicit manifest:
  - `outputs/manifests/nupack_small3_explicit_pairs.json`
- same model/hyperparameters as the explicit-label baseline except:
  - `pair_logit_sinkhorn_loss_weight = 0.005`

### Evaluation

Held-out prediction:

- `101_50_bp_nicked.conf`

Evaluated with explicit primary metric plus proxy side channel:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_pairsink5e3_explicitpairs_physcmp_10e_lr1e3_w1e2/101_50_bp_nicked_physical_metrics_explicit.json`

### Result versus explicit-label baseline

Baseline explicit-label reference:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_explicitpairs_physcmp_10e_lr1e3_w1e2/101_50_bp_nicked_physical_metrics_explicit.json`

Primary explicit-design metrics:

- `predicted_wc_precision`: unchanged `0.4737 -> 0.4737`
- `predicted_wc_recall`: unchanged `0.1875 -> 0.1875`
- `predicted_wc_f1`: unchanged `0.2687 -> 0.2687`
- `predicted_wc_complementarity`: unchanged `0.3878 -> 0.3878`
- `predicted_wc_occupancy`: unchanged `0.3958 -> 0.3958`
- `predicted_wc_conflict_rate`: unchanged `1.0 -> 1.0`
- `reference_pair_distance_rms_error`: slightly worse `0.3527 -> 0.3529`
- `helix_step_distance_mae`: slightly worse `0.1493 -> 0.1501`
- `helix_step_axis_score`: slightly worse `0.2887 -> 0.2885`
- `wc_helix_rule_score`: essentially unchanged `0.5136 -> 0.5134`

Secondary geometric-proxy metrics were also unchanged to numerical precision.

### Interpretation

This is a clean negative result.

At `pair_logit_sinkhorn_loss_weight = 0.005`, the Sinkhorn-style assignment term
does not meaningfully change held-out explicit-label behavior in the current 10e
`small3` regime.

Updated inference:

- the main problem is not just the *presence* of a matching relaxation term
- the current Sinkhorn weight / formulation / training horizon is too weak to
  change the pair assignment outcome
- if assignment structure is going to help, it likely needs either:
  - a stronger weight,
  - tighter candidate-edge restriction,
  - or a more direct row+column mass constraint over only pair-supervised edges

### Updated next best step

Most aligned follow-up after this result:

1. explicit labels + stronger row+column exclusivity
2. explicit labels + larger Sinkhorn weight sweep
3. explicit labels + candidate-edge restriction so pair losses only see
   complementary cross-strand candidate edges rather than the full message graph

The current evidence chain now says:

- labels: improved
- primary metric: corrected
- remaining bottleneck: pair assignment ambiguity
- weak Sinkhorn at this scale: ineffective

## 2026-06-12 continuation: candidate-pair-only supervision + stronger exclusivity

Implemented and tested a tighter supervision mode where pair losses apply only on
candidate WC pair edges rather than the whole message graph.

### What changed

In `scripts/ebd_oxdna_shared_rigid_train.py`:

- added `--restrict-pair-losses-to-candidate-wc-edges`
- `_prepare_sample()` now records `pair_supervision_edge_mask`
- pair BCE / exclusivity / symmetry / Sinkhorn losses can be restricted to the
  directed candidate WC edges only

Targeted regression tests now verify:

- the candidate-pair-only mask is built correctly
- the CLI summary records the restriction flag

### Run

First direct A30 probe with this restriction:

- output root:
  - `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairx2e2_pairsym1e2_pairmask_explicitpairs_physcmp_10e_lr1e3_w1e2/`
- same explicit-label `small3` manifest
- same explicit-label baseline settings except:
  - `restrict_pair_losses_to_candidate_wc_edges = true`
  - `pair_logit_exclusivity_loss_weight = 0.02`

Held-out evaluation:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairx2e2_pairsym1e2_pairmask_explicitpairs_physcmp_10e_lr1e3_w1e2/101_50_bp_nicked_physical_metrics_explicit.json`

### Result versus explicit-label baseline

Primary explicit-design metric comparison:

- `predicted_wc_precision`: `0.4737 -> 0.5000`
- `predicted_wc_recall`: unchanged `0.1875 -> 0.1875`
- `predicted_wc_f1`: slight increase `0.2687 -> 0.2727`
- `predicted_wc_complementarity`: `0.3878 -> 0.3673`
- `predicted_wc_occupancy`: `0.3958 -> 0.3750`
- `predicted_wc_conflict_rate`: unchanged `1.0 -> 1.0`
- `reference_pair_distance_rms_error`: slight regression `0.3527 -> 0.3530`
- `helix_step_distance_mae`: slight regression `0.1493 -> 0.1495`
- `helix_step_axis_score`: tiny increase `0.2887 -> 0.2891`
- `wc_helix_rule_score`: slight regression `0.5136 -> 0.5114`

### Interpretation

This is not a clean failure like the weak Sinkhorn probe, but it is still not the
breakthrough needed.

What improved:

- precision
- F1, slightly

What did **not** improve:

- recall
- conflict rate

This means the tighter pair mask plus stronger exclusivity mainly makes the model
more conservative about which pairs it predicts. It trims some false positives but
does not recover more true pairs or resolve many-to-one ambiguity.

### Updated diagnosis

The bottleneck is now even clearer:

- explicit labels work
- coarse pair supervision over the whole graph was not the right target surface
- but restricting to candidate pair edges alone still does not raise recall or
  reduce conflict

The next useful change likely needs stronger structural assignment logic, not
just narrower supervision:

1. larger explicit-label Sinkhorn / exclusivity sweep
2. direct row+column normalized transport over candidate pair edges only
3. higher-capacity pair-specific head or edge subnetwork separate from the
   coordinate residual path

## Partner-Selection Loss Probe

### What changed

In `scripts/ebd_oxdna_shared_rigid_train.py`:

- added `--pair-partner-selection-loss-weight`
- added `_pair_partner_selection_loss(...)`
- this loss applies row-wise and column-wise softmax cross-entropy over the
  candidate WC pair-edge logits for each explicit reference pair

This is a sharper one-to-one partner-choice objective than independent edge BCE,
while still staying within the existing candidate-WC graph and pair-head design.

### Why this probe mattered

The previous repeated failure mode was:

- precision can move a bit
- recall remains low
- conflict rate stays at `1.0`

That suggested the core issue might be that the current setup still treats
Watson-Crick assignment as independent edge classification instead of direct
partner choice inside a candidate set.

### Verification

Added regression tests proving:

- `_pair_partner_selection_loss(...)` is lower for a correct one-to-one
  assignment than for a conflicting one
- CLI summaries record `pair_partner_selection_loss_weight`
- training history records `pair_partner_selection_loss`

### Run

Direct local A30 probe:

- output root:
  - `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_pairsel5e2_explicitpairs_physcmp_10e_lr1e3_w1e2/`
- manifest:
  - `outputs/manifests/nupack_small3_explicit_pairs.json`
- same explicit-label candidate-WC baseline settings except:
  - `restrict_pair_losses_to_candidate_wc_edges = true`
  - `pair_partner_selection_loss_weight = 0.05`

Held-out explicit evaluation:

- `outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_pairsel5e2_explicitpairs_physcmp_10e_lr1e3_w1e2/101_50_bp_nicked_physical_metrics_explicit.json`

### Result versus explicit-label baseline

Primary explicit-design metric comparison on held-out `101_50_bp_nicked`:

- `final_rmsd`: `35.7852 -> 32.5167`
- `final_os`: `0.03519 -> 0.05426`
- `predicted_wc_precision`: `0.4737 -> 0.3889`
- `predicted_wc_recall`: `0.1875 -> 0.1458`
- `predicted_wc_f1`: `0.2687 -> 0.2121`
- `predicted_wc_complementarity`: `0.3878 -> 0.3600`
- `predicted_wc_occupancy`: `0.3958 -> 0.3750`
- `predicted_wc_conflict_rate`: unchanged `1.0 -> 1.0`
- `reference_pair_distance_rms_error`: `0.3527 -> 0.5661`
- `helix_step_distance_mae`: `0.1493 -> 0.1392`
- `helix_step_axis_score`: `0.2887 -> 0.1594`
- `wc_helix_rule_score`: `0.5136 -> 0.4679`

### Interpretation

This is another useful negative result.

What improved:

- coordinate fit improved somewhat
- OS improved somewhat
- helix-step distance MAE improved slightly

What got worse:

- explicit WC precision
- explicit WC recall
- explicit WC F1
- explicit complementarity
- explicit occupancy
- pair-distance consistency
- helix-axis consistency

What did **not** improve at all:

- `predicted_wc_conflict_rate`, still exactly `1.0`

So this probe strengthens the current diagnosis:

- even when explicit pair supervision is rewritten as partner selection inside
  the candidate set,
- the current DGNN-lite pair head still does not resolve many-to-one ambiguity

### Updated diagnosis

The remaining bottleneck is likely not "one more pair loss on the same logits".

More likely failure points now are:

1. the pair head is too weakly coupled to duplex geometry and local frame state
2. candidate generation itself is still too ambiguous
3. there is no persistent pair/duplex latent state in message passing
4. helix segment structure is not represented explicitly enough for nucleotide
   partner choice to become sharp

### Updated next step

Do **not** keep tuning pair-logit losses of the same family first.

The next aligned change should probably be one of:

1. a dedicated pair-aware message-passing block over only candidate WC edges
2. duplex-segment or helix-lane latent state, then nucleotide partner decoding
3. explicit local pair-frame / duplex-center prediction before discrete partner
   choice
4. moving more of WC assignment downstream, closer to the GenerativeSNUPI
   geometry-then-routing split

## Pair-Aware Message Path Start

### Why this next change

The partner-selection loss probe above strengthened the diagnosis that the
current failure is not just "missing one more pair loss on the same edge logits".

The more structural hypothesis is:

- pair assignment remains ambiguous because the pair state never really enters
  node-state evolution
- `pair_logits` are predicted only after the main message-passing stack
- so the coordinate/orientation hidden states are still driven mostly by the
  generic graph stream, not by duplex-specific partner structure

This is closer to the gap between the current DGNN-lite path and DeepSNUPI:

- DeepSNUPI has explicit pose-state updates over structural edges
- plus a separate dynamic cross-helix interaction block
- so geometry is affected by a second structural relation, not only by one final
  readout

### Implemented structural change

In `scripts/ebd_oxdna_shared_rigid_train.py`, `DgnnLiteRigidModel` now has a
bounded pair-aware candidate-WC message path:

- added `pair_message`
- added `pair_gate`
- `_model_forward(...)` now passes `pair_supervision_edge_mask` into
  `DgnnLiteRigidModel`
- inside each DGNN-lite message-passing step:
  - the usual graph message `agg` is still computed over the full graph
  - a second `pair_agg` is computed only over candidate pair edges selected by
    `pair_supervision_edge_mask`
  - `pair_message(pair_inputs)` is gated by `sigmoid(pair_gate(pair_inputs))`
  - the gated pair message is scattered back to destination nodes
  - `agg + pair_agg` is then fed into both `pos_update` and `ori_update`

This keeps the change bounded:

- no change to manifests
- no new data dependency
- no new export path
- no replacement of the main DGNN-lite coordinate/orientation decoder

But it is a real architectural shift:

- pair-aware state now influences hidden-state evolution directly
- not just the terminal `pair_head` readout

### Verification completed so far

Regression test added:

- `test_dgnn_lite_pair_message_path_changes_output_when_pair_mask_is_enabled`

This proves that, on the same toy graph and same parameters:

- turning the pair mask off and on changes predicted positions
- changes predicted `a1`
- changes predicted `a3`

So the pair-aware path is live in the forward pass and not dead code.

### Probe

A direct local A30 probe was started to test this architectural change under the
same explicit small3 regime:

- output root:
  - `outputs/manual_a30_small3_dgnn_candidatewc_top2_pairmsg_paircls2e2_pairsym1e2_pairsel5e2_explicitpairs_physcmp_10e_lr1e3_w1e2/`

Settings intentionally match the previous explicit partner-selection probe,
except for the new pair-aware message path inside the model.
