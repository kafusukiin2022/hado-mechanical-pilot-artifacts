# TALOS97 下一阶段应预测什么：基于现有模拟数据与分子动力学文献的任务建议

## Material Passport

研究问题重构与定向文献综述；范围是 TALOS97 的 6HB 设计、现存模拟轨迹派生标签和模型开发方向；没有运行训练或模拟。文献元数据通过 Crossref API 按题名/DOI 核验；涉及论文结论时提供 DOI 原文链接。Verification Status: Literature metadata verified; recommendations are an evidence-informed proposal, not a completed benchmark.

## 建议先改变预测目标，而不是再换网络

目前的 RMSF 和平均位置任务都有统计意义，但没有直接对应“哪种设计值得继续做”的决策。逐核苷酸 RMSF 回归关注的是柔性幅度；平均位置回归关注的是一个有限轨迹的坐标均值。它们都没有直接回答某个设计是否整体保持结构、是否出现局部高风险、以及在模拟有限采样下这种判断有多可靠。

建议的近期主任务是**带不确定度的 DNA-origami 模拟稳定性筛选**：只给定初始设计结构和拓扑，预测该设计在既定 oxDNA 模拟条件下的两个互补结果，并给出区间或候选排序：

1. **整体构型保持程度**：使用当前已有的每核苷酸参考相对位移统计，汇总成设计级中位数、上分位数或最大区域位移；另保留平均位移 D 作为不同定义的独立标签。
2. **局部柔性/风险程度**：由每核苷酸 RMSF 汇总设计级中位数、上分位数、空间连续高柔性区域数量/长度；若原始帧可恢复，再增加每帧 crossover、同链骨架和局部几何偏差的超限频率及其尾部严重度。

这两个维度应分别报告，先不要人为加权成一个“总稳定性分数”。这样可以区分“整体形状偏移但局部仍刚性”和“整体形状接近但存在局部铰链/高柔性区”。前两类汇总量可从现有逐核苷酸标签做探索性版本；逐帧超限概率、尾部风险和标签采样误差需要读取/恢复轨迹帧。

最终应用形式应是：输入一个尚未跑完整 MD 的候选设计，输出其结构保持与局部风险的预测区间和排序，供研究者决定优先模拟哪些设计、哪些设计应先做结构修正。这个阶段预测的是**指定模拟条件下的计算稳定性代理指标**，不能把它称为实验组装成功率或真实功能。

## 为什么这比继续做均值构型回归更值得优先

分子动力学构象通常需要作为一个分布或慢动力学过程理解。VAMPnets 直接学习分子动力学的慢动力学状态与转移，而不是只回归一份平均坐标（Mardt et al., 2018）。时间延迟自编码器和变分 Koopman 工作也把目标放在慢集体变量及动力学（Wehmeyer & Noé, 2018; Wu et al., 2017）。Boltzmann generators 则将生成目标写成平衡态构象分布采样（Noé et al., 2019）。这些工作支持“任务要对准构象分布、状态或动力学”的方法学方向；它们并不证明 TALOS97 当前的 2000 帧足以训练相同复杂度的模型。

一个逐坐标均值把每一帧压成一个中心位置。当轨迹有多个亚稳态、状态切换或方向相反的形变时，中心位置可能代表一个低概率甚至不物理的构象。构象空间挖掘研究以轨迹中的构象变化和特征为对象（Degiacomi, 2019），也说明结构预测的应用输出不必是唯一平均结构。对 TALOS97 来说，先比较“保持/柔性/局部风险”这类能用于筛选的分布摘要，比把坐标 RMSE 继续压低几千分之一 nm 更贴近决策。

模拟标签本身也有有限采样误差。连续帧因时间相关而不是独立观测；Flyvbjerg 与 Petersen 的 block-averaging 方法专门讨论相关数据平均值的误差估计（1989）。因此“每个设计 2000 帧”不能等同 2000 个独立标签样本。应从时间块或独立 replica 估计每个设计目标的不确定度，再把标签误差与模型误差分开。现有平均位置标签来自 replica 1；另一些 RMSF 结果使用多个 replica，二者的采样基础并不相同。

## TALOS97 当前数据能做什么

本机 2026-11-04 的统计缓存说明，95 个无既知损坏排除设计中，有 88 个设计具有完整的 20M-step 续跑、每个 2000 帧；7 个设计缺失/失败，不应把短轨迹混入主标签。对 6hb_001 的现存 `statistics.npz` 检查发现保存的是每核苷酸 `rmsf_nm`、平均位置位移、参考相对 RMS 位移、对齐平均坐标和初始坐标等摘要，并不含 2000 帧的逐帧坐标。因此：

- 可以先做 88 个设计的**设计级双目标筛选基线**，从逐核苷酸摘要生成宏观结构保持/局部柔性标签；明确这是探索性代理任务。
- 如果要预测尾部风险、状态占比、转换率、时间相关长度或有限采样置信区间，需要恢复原始轨迹（或重新计算，但新模拟需要另行明确授权），不能从单个 RMSF/均值数组反推出完整时间分布。
- 设计而不是核苷酸才是主要泛化单位。88 个设计、71/17 train/validation 不会因为每个设计有数千核苷酸就变成数十万独立设计样本。
- 现验证集已在此前多轮模型选择中使用；下一次模型比较应优先建立新的设计级外层留出/分组交叉验证，或收集真正新设计作前瞻性测试。
- 现有设计集中于 6HB 且条件单一；结论只能覆盖相似设计与同一模拟条件。面向不同盐浓度、温度、拓扑或实验产率，需要跨条件模拟及实验标签。

## 任务路线与优先级

|优先级|任务|当前可行性|应用价值|主要门槛|
|---|---|---|---|---|
|1|预测设计级结构保持 + 局部柔性/风险的双目标区间与排序|可由现有 88 个设计的逐核苷酸统计先做|直接筛选应优先模拟/修正的设计；近期最可验证|设计数小；固定条件；旧验证集已反复使用；标签为单/有限 replica 摘要|
|2|有原始轨迹时，预测每设计构象分布、尾部风险和慢状态摘要|仅当逐帧坐标及足够有效样本可恢复|比平均构型更能表示多态、突发变形和候选风险|需要时间相关/块误差估计、replica 对照与状态可识别性检查|
|3|预测新的设计在实验中的组装成功率、产率、结构完整度或功能读出|当前没有对应 TALOS97 实验标签|最高的最终生物/工程应用价值|须收集同设计/同条件实验读出并做前瞻性验证；MD 标签只能作辅助特征|
|4|预测下一帧坐标或短时轨迹|技术上可用逐帧 MD，但实际价值暂弱|可用于模拟加速的中间方法|短时间预测可能只学到平滑惯性；必须比较长时 rollout、守恒/几何有效性和相对真实模拟的加速收益|
|5|继续优化逐核苷酸平均坐标或单点 RMSF RMSE|现有基线可复用|主要是指标上的小幅改进，不直接给出候选决策|坐标平均可能抹掉多态；现结果未显示 MeshGraphNet 稳定优于简单图/MLP|

## 推荐的最小可证伪实验

1. **先定决策问题。** 目标是从初始几何筛选候选设计，不是预测某个模型的隐藏表示。预先把两个连续终点定义清楚：整体结构保持和局部柔性/风险；分别报告，不事后拼成综合分数。
2. **先做设计级传统基线。** 汇总初始几何/拓扑特征与已有目标，比较训练均值、ridge/Elastic Net、Gaussian Process、随机森林或梯度提升。样本不足以预设深度图网络更合适；几何深度学习综述提供的是建模工具背景，不构成此数据规模下 GNN 必胜的证据（Atz et al., 2021）。
3. **外层按设计分组。** nested grouped CV 或未参与所有调参的新设计作测试；同一设计的核苷酸绝不跨训练/测试。bootstrap 也以设计为单位。
4. **测量筛选质量。** 除 MAE/RMSE 外，报告 Spearman 排序、Top-k 高风险/高稳定设计的 precision/enrichment、区间覆盖率与 calibration。对不确定度大的设计优先补模拟，这与主动学习构象集合的思路一致（Kleiman et al., 2023）。
5. **拆开三类不确定度。** 时间采样误差用轨迹分块/replica估计；模型不确定度用设计级 ensemble/GP；域外不确定度标记超出已见几何范围的设计。若当前原始轨迹无法访问，先把结论限定为摘要统计预测，不假装有尾部风险标签。
6. **只有简单基线通过外层测试后，再决定是否值得上图网络。** MeshGraphNet、GPR 风格图网络等必须匹配参数预算、输入信息、验证策略和标签；否则架构差异、图边差异与模型大小会继续混淆结论。概率图网络可以表达模拟预测的不确定性，但其一般物理仿真结果不能替代 TALOS97 上的对照验证（Prakash & Tucker, 2024）。

## 两个主任务的操作性指标

定义初始坐标为 `x_i0`，第 `t` 个已对齐轨迹帧坐标为 `x_it`，核苷酸数为 `N`，帧数为 `T=2000`。每个设计先产生结构/柔性终点，再跨设计做预测；核苷酸不是独立训练例。

### 整体形状保持

**主指标（逐帧刚体对齐 RMSD）**：对每一帧求使轨迹坐标最佳对齐到初始结构的 proper Kabsch 刚体变换 `(R_t,c_t)`，再计算

`g_t = sqrt[(1/N) Σ_i ||R_t x_it + c_t - x_i0||²]`。

每设计报告 `median_t(g_t)` 和 `Q95_t(g_t)`。中位数表示典型形变，Q95 表示高形变尾部。它们区分“通常保持得怎样”和“偶发最坏帧有多严重”；两项都从已采样轨迹估计，不是精确平衡态概率。主结果可再报告均值 `mean_t(g_t)`，但不以它替代尾部。

**辅助形状描述符**：`ΔRg/Rg0`（回转半径相对变化）、长轴延伸率、跨 helix/segment 的相对距离或相对角度变化。它们能指出 RMSD 来自整体弯曲、收缩还是 helix 间重排。DNA origami 项目的既有评估问题也明确列出 RMSD、domain-frame error、crossover error、helix bending 和 end-to-end distance，应按所需功能选择描述符，而不是默认只看一个全局 RMSD（[项目评估问题](../DNA_ORIGAMI_OPEN_QUESTIONS.md#evaluation)）。

**现有摘要可算的替代量（需明确标作 proxy）**：令 `μ_i` 为 Kabsch 对齐后时间平均位置，`m_i=||μ_i-x_i0||`；设计级 `G_mean=sqrt(mean_i m_i²)` 可由 `mean_position_displacement_nm` 计算。它表示持久的平均位置偏移，但轨迹向相反方向的形变会相互抵消，所以不等于上述 `median_t(g_t)` 或 `Q95_t(g_t)`。现有标签还给出 `r_i=RMSF_i`，故 `F_rms=sqrt(mean_i r_i²)`，并且

`D_rms = sqrt(mean_i D_i²) = sqrt(G_mean² + F_rms²)`，

其中逐核苷酸 `D_i² = r_i² + m_i²`。`D_rms` 可作一个总的参考相对运动量，但它把持续偏移和时间内波动合在一起，**不要作为唯一主指标**。

按现有 88 个设计的逐核苷酸摘要重算，设计级 `median_i(RMSF_i)` 的跨设计中位数为 1.6614 nm，`Q90_i(RMSF_i)` 的跨设计中位数为 2.2064 nm；`F_rms`、`G_mean`、`D_rms` 的跨设计中位数分别为 1.7661、2.7350、3.2690 nm。这些仅描述当前标签的尺度，不是阈值、物理失效边界或模型泛化结果。

### 局部柔性与风险

**主柔性指标**：对每设计报告逐核苷酸 RMSF 的 `median_i(r_i)`、`Q90_i(r_i)` 和超过预先定义阈值的核苷酸比例。中位数表示典型局部柔性；Q90 和高柔性比例对少数热点更敏感。阈值必须在训练集/物理规范中事先确定，不能针对验证集调到看起来最好。RMSF 是局部涨落幅度，不自动代表结构错误或功能失败。

**空间连续风险指标**：在真实拓扑/骨架图上，将超过固定 RMSF 阈值的核苷酸组成连续片段，报告片段数、最长长度、超阈节点比例和是否跨过 crossover。相比“最高的几个散点”，连续长段更容易对应局部铰链/失稳区域。`≥8 nt` 连续区可作为沿用项目已有探索的候选定义，但应与其他片段长度阈值做敏感性分析，不能称为已验证的物理失效阈值。

**需要原始帧才有的物理风险**：逐帧统计 backbone 邻接距离、crossover 连接距离/相对取向、base-pair 几何及碰撞等约束的超限率；每设计报告超限帧比例、最长连续异常段和事件严重度。阈值应来自对应 oxDNA 模型/拓扑物理判据，不能从当前验证集误差倒推。此类指标最接近“局部风险”，单用 RMSF 只能称柔性热点筛选。

### 采样与预测不确定度

对每个 `median/Q95/超限率` 做时间块 bootstrap，并以独立 replica 作外部重复，先估计有限采样置信区间；2000 个相邻采样帧不是 2000 个独立样本（Flyvbjerg & Petersen, 1989）。再用设计级 ensemble/GP 估计模型不确定度，并单独标记与训练设计几何差异很大的域外候选。报告标签置信区间和模型预测区间两套结果，不混成一个误差条。若只能访问保存的 `statistics.npz`，当前能给每核苷酸汇总预测，但不能重建时间块 bootstrap 或尾部事件的区间。

若后续真的把“慢构象状态/转移”设为研究终点，评价也要换成时间滞后动力学指标：held-out VAMP score、状态转移矩阵的 Chapman–Kolmogorov 一致性和 implied-timescale 稳定性；这与 RMSD/RMSF 的监督误差是不同问题。VAMPnets 和 variational Koopman 工作的目标正是慢动力学/状态估计（Mardt et al., 2018; Wu & Noé, 2017），但应先确认现有轨迹包含足够、可重复的状态转换。

### 衡量模型是否有用

模型主要在**设计级**做外层留出，报告：连续终点的 MAE/RMSE；设计排序 Spearman；按稳定/高风险排序取 Top-k 时的命中率或 enrichment；不确定区间覆盖率/校准。Top-k 的“好”方向要针对具体用例定义：筛稳定设计做实验，或筛高风险设计优先修正。不要把逐核苷酸随机拆分到训练/验证，也不要只报告全体节点 RMSE，否则同设计节点泄漏且大设计会支配结果。

## 可能的后续论文问题

近期、由当前数据直接支持的表述：

> Can initial topology and geometry rank DNA-origami 6HB designs by simulated global shape retention and local flexibility, with calibrated uncertainty under finite-trajectory sampling?

应用价值更强但需要增加实验标签的后续问题：

> Can simulation-derived dynamics descriptors improve prospective prediction of experimentally measured assembly yield, structural integrity, or task-specific function beyond static geometry alone?

第一问能验证“能否筛选值得模拟/修正的设计”；第二问才能支撑“能否筛选最终有应用价值的设计”。不应把第一问的模拟稳定性等同第二问的实验成功。

## 文献与来源

题名、作者、期刊与 DOI 元数据通过 Crossref DOI API 核对。以下论文用于构建任务方向，不是对 DNA origami 特定效果的直接证据。

1. Mardt, A., Pasquali, L., Wu, H., & Noé, F. (2018). VAMPnets for deep learning of molecular kinetics. *Nature Communications, 9*. [https://doi.org/10.1038/s41467-017-02388-1](https://doi.org/10.1038/s41467-017-02388-1)
2. Wehmeyer, C., & Noé, F. (2018). Time-lagged autoencoders: Deep learning of slow collective variables for molecular kinetics. *The Journal of Chemical Physics, 148*, 241703. [https://doi.org/10.1063/1.5011399](https://doi.org/10.1063/1.5011399)
3. Wu, H., & Noé, F. (2017). Variational Koopman models: Slow collective variables and molecular kinetics from short off-equilibrium simulations. *The Journal of Chemical Physics, 146*, 154104. [https://doi.org/10.1063/1.4979344](https://doi.org/10.1063/1.4979344)
4. Noé, F., Olsson, S., Köhler, J., & Wu, H. (2019). Boltzmann generators: Sampling equilibrium states of many-body systems with deep learning. *Science, 365*(6457), eaaw1147. [https://doi.org/10.1126/science.aaw1147](https://doi.org/10.1126/science.aaw1147)
5. Degiacomi, M. T. (2019). Coupling Molecular Dynamics and Deep Learning to Mine Protein Conformational Space. *Structure, 27*(6), 1034–1040.e3. [https://doi.org/10.1016/j.str.2019.03.018](https://doi.org/10.1016/j.str.2019.03.018)
6. Flyvbjerg, H., & Petersen, H. G. (1989). Error estimates on averages of correlated data. *The Journal of Chemical Physics, 91*(1), 461–466. [https://doi.org/10.1063/1.457480](https://doi.org/10.1063/1.457480)
7. Kleiman, A., et al. (2023). Active Learning of the Conformational Ensemble of Proteins Using Maximum Entropy VAMPNets. *Journal of Chemical Theory and Computation*. [https://doi.org/10.1021/acs.jctc.3c00040](https://doi.org/10.1021/acs.jctc.3c00040)
8. Atz, K., Grisoni, F., & Schneider, G. (2021). Geometric deep learning on molecular representations. *Nature Machine Intelligence, 3*, 1023–1032. [https://doi.org/10.1038/s42256-021-00418-8](https://doi.org/10.1038/s42256-021-00418-8)
9. Prakash, S. K. A., & Tucker, C. (2024). Probabilistic graph networks for learning physics simulations. *Journal of Computational Physics, 513*, 113137. [https://doi.org/10.1016/j.jcp.2024.113137](https://doi.org/10.1016/j.jcp.2024.113137)
10. Noé, F., De Fabritiis, G., & Clementi, C. (2020). Machine learning for protein folding and dynamics. *Current Opinion in Structural Biology, 60*, 77–84. [https://doi.org/10.1016/j.sbi.2019.12.005](https://doi.org/10.1016/j.sbi.2019.12.005)

### 搜索范围与限制

2026-11-07 对 Crossref DOI 元数据进行题名/DOI 定向检索，检索词覆盖 molecular kinetics、slow collective variables、conformational ensemble、Boltzmann sampling、MD correlated averages、geometric molecular learning、probabilistic graph simulation 和 protein dynamics。纳入能直接支持“分布/动力学/采样误差/不确定性/主动选择模拟”的跨领域方法论文及一篇综述；未做 PRISMA 系统检索，也未声称涵盖全部领域文献。上列跨领域方法须在 TALOS97 上重新验证。

AI 辅助研究声明：文献检索式、论文元数据核对与任务综合由 AI 辅助完成；题名/期刊/DOI 以 Crossref 记录为书目核对来源，正文方法细节应在正式投稿引用前阅读原文确认。
