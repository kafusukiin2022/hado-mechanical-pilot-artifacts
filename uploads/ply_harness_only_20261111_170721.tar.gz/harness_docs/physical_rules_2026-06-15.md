# Physical Rules Harness

Date: 2026-06-15

## Same-Series Continuation

The next dated file in this same physical-rule harness series is:

- `docs/harness/physical_rules_2026-06-16.md`

Read the 2026-06-16 file after this one when resuming assignment-realized coordinate/export work.

## Objective

This file is the goal-specific harness for the DGNN-lite Watson-Crick and duplex-helix line. The main dated DGNN-lite harness must point here for physical-rule-specific instructions and should not duplicate this content.

Current task scope:

- Verify local and external evidence instead of trusting old notes.
- Use `/home/lijingjing/lijj/users/lht2/deeporigami/agent/athena_generativesnupi` as local GenerativeSNUPI evidence.
- Use external paper and supplementary-material verification for Generative SNUPI before changing the training strategy.
- Improve the current DGNN-lite path toward Watson-Crick complementary pairing, double-helical structure, `RMSD -> 0`, and `OS -> 1`.
- Record meaningful findings and negative results.

## Startup Checks For This Goal

1. Read `AGENTS.md`, `feature_list.json`, `progress.md`, and `session-handoff.md`.
2. Read this file before changing physical-rule code or launching a physical-rule experiment.
3. Treat `session-handoff.md` as context only. On 2026-06-15 it conflicted with this active goal by saying the current objective had shifted to EBD diffusion. This goal explicitly continues the DGNN-lite physical-rule line.
4. Run `./init.sh` before substantial edits or experiments. It currently passes but reports that this directory is not a git worktree.
5. GPU state on 2026-06-15: current node `gpu30`, six visible NVIDIA A30 GPUs. PyTorch in `/home/lijingjing/lijj/.conda/envs/ebd/bin/python` reports CUDA available and can allocate a tensor on `cuda:1`.

## Current Verified State

The handoff claim that PID `130878` was still running is stale. Direct process inspection on 2026-06-15 found no active `ebd_oxdna_shared_rigid_train.py` process for that run. The output directory exists and contains `summary.json`:

`outputs/manual_a30_small3_dgnn_candidatewc_top2_pairmsg_paircls2e2_pairsym1e2_pairsel5e2_explicitpairs_physcmp_10e_lr1e3_w1e2/summary.json`

Held-out `101_50_bp_nicked`, using explicit design labels:

- `final_rmsd = 32.742027282714844`
- `final_os = 0.03173580393195152`
- `wc_helix_rule_score = 0.43073895869100404`
- `predicted_wc_f1 = 0.16129032258064516`
- `predicted_wc_precision = 0.35714285714285715`
- `predicted_wc_recall = 0.10416666666666667`
- `predicted_wc_occupancy = 0.2916666666666667`
- `predicted_wc_conflict_rate = 1.0`
- `reference_pair_distance_rms_error = 0.5627064023941774`
- `helix_step_axis_score = 0.14880863180303056`

Interpretation: the pair-aware message path is a negative result under this setting. It worsened the explicit physical-rule score relative to the simpler explicit pair-head + symmetry baseline.

## External Source Verification

Verified source:

- Paper page: `https://www.nature.com/articles/s41467-026-73578-z`
- Title: `Generative design of complex DNA origami nanostructures with diffusion models`
- Journal/date from the Nature page: Nature Communications, published 2026-05-25.
- Supplementary PDF: downloaded from Springer static content:
  `https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-026-73578-z/MediaObjects/41467_2026_73578_MOESM1_ESM.pdf`
- Local verification artifact:
  `/tmp/gensnupi_verify/supp.pdf`
- `pdfinfo` reported 79 pages, PDF 1.7, title `Microsoft Word - Supplementary_Proof.docx`.

Key supplementary evidence:

- Supplementary Note 1 defines the generated DNA origami representation as base-pair central coordinates, a point cloud over `N` base pairs.
- Supplementary Note 5, Routing, says the routing pipeline starts from the generated DNA structure from the diffusion model.
- Routing Step 1 creates regular base-pair steps within helices by radius graph generation and enforces base-pair bond length `0.34 +/- 0.05 nm`, while assigning helix indices.
- Routing Steps 2-5 create single-strand edges, loop double crossovers, a dual graph, and scaffold double-crossovers.
- Routing Step 6 assigns each base pair an orientation following the 3DNA convention and assigns remaining in-helix orientations to resemble B-form DNA.
- Routing Steps 7-8 derive staple nucleotide coordinates, optimize staple double-crossover locations, and partition staple routes into shorter segments.

Conclusion from external evidence: Generative SNUPI is geometry-first and routing-second. The diffusion model does not directly enforce a nucleotide-level Watson-Crick partner classifier. Watson-Crick-compatible duplex structure is created by downstream routing, orientation assignment, staple generation, and output conversion.

## Local GenerativeSNUPI Verification

Inspected local path:

`/home/lijingjing/lijj/users/lht2/deeporigami/agent/athena_generativesnupi/GenerativeSNUPI`

Relevant code evidence:

- `diffusion.py` implements Gaussian diffusion over DNA nanostructure coordinates, with optional shape conditioning.
- `routing.py` loads generated `.pt` coordinates, calls `automated_DnaOrigami(...)`, then writes PyG, CanDo, BILD, oxDNA, and PDB outputs.
- `automated_design/auto_design.py` uses:
  - `regular_BP_len = 0.4`
  - `one_turn_angle = (-2) * pi / 10.5`
  - `assign_RegularBp_edges(...)`
  - `gen_align_CrossOvers(...)`
  - `assign_SingleStrand_edges(...)`
  - `scaffold_routing(...)`
  - `assign_triads(...)`
  - `bps_to_bases(...)`
  - `gen_Staples_CrossOvers(...)`
  - `staples_routing(...)`
- `automated_design/gen_cando.py` writes scaffold/staple `across` partners into CanDo topology:
  - scaffold across: `2 * (SCroute_bpidx[i] + 1)`
  - staple across: `1 + 2 * stap_bpidx[j]`

Conclusion from local code: local GenerativeSNUPI also supports the geometry-first/routing-second interpretation. It is evidence for explicit pair labels and duplex-frame supervision in DGNN-lite, not for copying the full routing stack into the DGNN-lite loss.

## Current DGNN-lite Evidence Chain

Held-out `101_50_bp_nicked` comparison from current local summaries:

| Run | RMSD | OS | WC/helix score | WC F1 | Conflict |
|---|---:|---:|---:|---:|---:|
| explicit pair-head + symmetry | 35.7852 | 0.0352 | 0.5136 | 0.2687 | 1.0 |
| explicit + Sinkhorn logits | 35.7867 | 0.0885 | 0.5134 | 0.2687 | 1.0 |
| explicit + candidate mask/exclusivity | 35.7814 | 0.1150 | 0.5114 | 0.2727 | 1.0 |
| explicit + partner selection | 32.5167 | 0.0543 | 0.4679 | 0.2121 | 1.0 |
| explicit + pair-aware message | 32.7420 | 0.0317 | 0.4307 | 0.1613 | 1.0 |

Interpretation:

- Pair-logit-only matching and pair-message additions have not broken the `predicted_wc_conflict_rate = 1.0` regime.
- Some logit/matching terms improve RMSD or OS, but they do not reliably improve physical pairing.
- The next aligned probe should directly couple explicit design pairs to output geometry: pair centers, pair axes, duplex-step spacing/axis, and eventually local pair frames.

## Next Bounded Probe

Use the existing explicit-label manifest:

`outputs/manifests/nupack_small3_explicit_pairs.json`

Run a short local A30 `small3` experiment that starts from the best explicit pair-head + symmetry baseline and adds direct geometric pair supervision:

- Keep:
  - `--include-candidate-wc-edges`
  - `--candidate-wc-top-k 2`
  - `--candidate-wc-cutoff 5.0`
  - `--pair-classification-loss-weight 0.02`
  - `--pair-logit-symmetry-loss-weight 0.01`
- Add:
  - `--pair-center-loss-weight 0.02`
  - `--pair-axis-loss-weight 0.02`
  - optionally `--helix-step-loss-weight 0.01` if the first pair-center/axis result is stable but helix axis remains poor.

Primary evaluation must use explicit labels (`reference_pair_source = explicit_design`) and compare:

- `final_rmsd`
- `final_os`
- `wc_helix_rule_score`
- `predicted_wc_f1`
- `predicted_wc_precision`
- `predicted_wc_recall`
- `predicted_wc_occupancy`
- `predicted_wc_conflict_rate`
- `reference_pair_distance_rms_error`
- `helix_step_axis_score`

Do not claim success from geometric-proxy metrics when explicit labels are available. Keep `physical_rule_metrics_geometric_proxy` only as a secondary diagnostic.

## Stop/Restart Rule

If another pair-logit-only or pair-message-only attempt fails to improve conflict/recall, pause and re-check Generative SNUPI and local routing evidence again before adding another scalar loss. The evidence currently points toward stronger geometry-to-pair coupling and explicit design-derived pair labels, not more unconstrained pair-logit tuning.

## 2026-06-15 Pair-Center/Axis Probe Result

Ran the bounded A30 `small3` explicit-label probe recommended above:

`outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_paircenter2e2_pairaxis2e2_explicitpairs_physcmp_10e_lr1e3_w1e2/summary.json`

Configuration:

- `--manifest outputs/manifests/nupack_small3_explicit_pairs.json`
- `--model-kind dgnn-lite`
- `--include-candidate-wc-edges`
- `--candidate-wc-top-k 2`
- `--candidate-wc-cutoff 5.0`
- `--restrict-pair-losses-to-candidate-wc-edges`
- `--pair-classification-loss-weight 0.02`
- `--pair-logit-symmetry-loss-weight 0.01`
- `--pair-center-loss-weight 0.02`
- `--pair-axis-loss-weight 0.02`
- `--epochs 10`
- `--learning-rate 0.001`
- `--val-ids 101_50_bp_nicked`
- `CUDA_VISIBLE_DEVICES=2`

Held-out `101_50_bp_nicked`, explicit labels:

| Run | RMSD | OS | WC/helix score | WC F1 | Precision | Recall | Occupancy | Conflict | Pair-distance RMS error | Helix-axis |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| explicit pair-head + symmetry | 35.7852 | 0.0352 | 0.5136 | 0.2687 | 0.4737 | 0.1875 | 0.3958 | 1.0 | 0.3527 | 0.2887 |
| explicit + pair-aware message | 32.7420 | 0.0317 | 0.4307 | 0.1613 | 0.3571 | 0.1042 | 0.2917 | 1.0 | 0.5627 | 0.1488 |
| explicit + pair-center/axis | 33.1248 | 0.0597 | 0.5484 | 0.3714 | 0.5909 | 0.2708 | 0.4583 | 1.0 | 0.4914 | 0.2161 |

Interpretation:

- This is the best explicit-label WC F1 and aggregate WC/helix score in the local explicit `small3` series so far.
- Direct pair geometry supervision is more aligned than the pair-message / pair-logit-only attempts.
- It still does not solve one-to-one pairing: `predicted_wc_conflict_rate` remains `1.0`.
- It improves WC partner recovery but regresses pair-distance RMS error and helix-axis score relative to the explicit pair-head + symmetry baseline.

Next aligned step:

- Keep explicit labels, candidate-WC edges, pair-head, symmetry, and pair-center/axis losses.
- Add direct duplex-step/frame supervision instead of another pair-logit-only matching scalar. The existing `--helix-step-loss-weight 0.01` is the smallest next probe because it targets the helix-axis weakness exposed by this run.
- Compare against the pair-center/axis run above using explicit labels only.

## 2026-06-15 Verification Note

While verifying the session, the full physical-metrics/shared-trainer test command initially failed in `test_shared_rigid_train_cli_fits_two_manifest_entries` because `_model_forward` passed the DGNN-lite-only pair supervision mask into the `graph-shared` model path. Fixed `scripts/ebd_oxdna_shared_rigid_train.py` so only `dgnn-lite` receives `graph_edge_features` and `pair_supervision_edge_mask`; `graph-shared` now receives only `graph_edges` as before.

Verification after the fix:

- `python3 -m json.tool feature_list.json >/dev/null`
- `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m py_compile scripts/ebd_oxdna_shared_rigid_train.py ebd_oxdna/physical_metrics.py`
- `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_ebd_oxdna_shared_rigid_train_cli.EBDOxDNASharedRigidTrainCLITest.test_shared_rigid_train_cli_fits_two_manifest_entries -v`
- `PYTHONNOUSERSITE=1 /home/lijingjing/lijj/.conda/envs/ebd/bin/python -m unittest tests.test_physical_metrics tests.test_ebd_oxdna_shared_rigid_train_cli -v`

## 2026-06-15 Follow-Up Probes

### Helix-Step Distance Loss

Run:

`outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_paircenter2e2_pairaxis2e2_helix1e2_explicitpairs_physcmp_10e_lr1e3_w1e2/summary.json`

Change from pair-center/axis baseline:

- Added `--helix-step-loss-weight 0.01`.

Held-out `101_50_bp_nicked`, explicit labels:

- `wc_helix_rule_score = 0.5484726532857706`
- `predicted_wc_f1 = 0.3714285714285714`
- `predicted_wc_conflict_rate = 1.0`
- `helix_step_axis_score = 0.21576208244685247`

Interpretation: neutral. The distance-only helix-step loss slightly improved aggregate score through tiny distance changes, but did not alter WC F1, precision, recall, occupancy, or conflict. It also did not improve helix-axis.

### Helix-Step Axis Loss

Implemented:

- `reference_helix_step_axis_loss(...)` in `ebd_oxdna/physical_metrics.py`.
- `--helix-step-axis-loss-weight` in `scripts/ebd_oxdna_shared_rigid_train.py`.
- Regression coverage in:
  - `tests/test_physical_metrics.py`
  - `tests/test_ebd_oxdna_shared_rigid_train_cli.py`

Run:

`outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_paircenter2e2_pairaxis2e2_helixaxis2e2_explicitpairs_physcmp_10e_lr1e3_w1e2/summary.json`

Change from pair-center/axis baseline:

- Added `--helix-step-axis-loss-weight 0.02`.

Held-out `101_50_bp_nicked`, explicit labels:

- `wc_helix_rule_score = 0.5486368758228747`
- `predicted_wc_f1 = 0.3714285714285714`
- `predicted_wc_conflict_rate = 1.0`
- `helix_step_axis_score = 0.2147219215074311`

Interpretation: neutral. The new axis loss is implemented and tested, but this 10e small3 probe did not move pairing classification or conflict and slightly worsened the measured helix-axis score.

### Non-Reference Pair Repulsion

Implemented:

- `reference_nonpair_repulsion_loss(...)` in `ebd_oxdna/physical_metrics.py`.
- `--nonpair-repulsion-loss-weight` and `--nonpair-repulsion-margin` in `scripts/ebd_oxdna_shared_rigid_train.py`.
- Regression coverage in:
  - `tests/test_physical_metrics.py`
  - `tests/test_ebd_oxdna_shared_rigid_train_cli.py`

Rationale:

GenerativeSNUPI/CanDo routing has unique `across` partners per base pair, while the current DGNN-lite outputs keep many non-reference cross-strand nucleotides inside the geometric pair cutoff. This is the direct cause of `predicted_wc_conflict_rate = 1.0`.

Run:

`outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_paircenter2e2_pairaxis2e2_nonpairrep1e2_explicitpairs_physcmp_10e_lr1e3_w1e2/summary.json`

Change from pair-center/axis baseline:

- Added `--nonpair-repulsion-loss-weight 0.01`.
- Added `--nonpair-repulsion-margin 4.0`.

Held-out `101_50_bp_nicked`, explicit labels:

- `wc_helix_rule_score = 0.5484316253457808`
- `predicted_wc_f1 = 0.3714285714285714`
- `predicted_wc_conflict_rate = 1.0`
- `last_nonpair_repulsion_loss = 0.43839818239212036`

Interpretation: neutral. The loss is active, but the mild 10e probe did not change any WC partner-classification metric.

## Revised Strategy After Three Neutral Probes

Do not continue adding small scalar losses to the same DGNN-lite output without revisiting the structure. The latest evidence says:

- Pair-center/axis supervision is useful and should be kept.
- Helix-step distance, helix-step axis, and mild nonpair repulsion did not solve one-to-one pairing.
- The core bottleneck is likely the prediction/decoding structure: the model outputs coordinates independently enough that many non-partners remain inside the WC cutoff.

Next aligned work should be one of:

1. Add an explicit partner-decoding/evaluation path that predicts one partner per nucleotide from pair logits and evaluates that assignment separately from raw geometric cutoff conflicts.
2. Add a stronger assignment-coupled coordinate objective where selected explicit pairs are pulled together and all non-selected complementary candidates for the same nucleotide are pushed outside a margin with higher weight or curriculum.
3. Move to a pair-frame target: predict pair centers plus pair axes/frames as first-class outputs, then reconstruct nucleotide positions from pair frames, matching the GenerativeSNUPI base-pair-first representation more closely.

Before implementing the next structural change, re-open this harness, the GenerativeSNUPI supplementary routing section, and the local `gen_cando.py` `across` topology construction. The next change should not be another pair-logit-only or small scalar-loss-only sweep.

## 2026-06-15 One-To-One Pair-Logit Decoder

Implemented the first structural follow-up:

- `_decode_pair_logits_one_to_one(...)` in `scripts/ebd_oxdna_shared_rigid_train.py`.
- `_pair_assignment_metrics(...)` in `scripts/ebd_oxdna_shared_rigid_train.py`.
- Per-sample `pair_logit_assignment_metrics` in shared-trainer summaries.

The decoder is intentionally simple and dependency-free:

1. Filter to the same supervised candidate pair edges used by pair losses.
2. Collapse directed edge logits into undirected pair scores by taking the best directed score for each pair.
3. Sort by score and greedily accept pairs whose two endpoints are both unused.

This creates an explicit one-to-one assignment for evaluation. It does not yet feed the decoded assignment back into coordinate generation or loss.

Regression coverage:

- `test_pair_logit_decoder_returns_one_to_one_assignment_metrics` verifies that the decoder rejects many-to-one conflicts and can recover a perfect explicit assignment from ambiguous directed logits.
- `test_shared_rigid_train_cli_records_pair_partner_selection_loss_weight_and_history` now also verifies that the CLI summary records `pair_logit_assignment_metrics`.

Short A30 smoke:

`outputs/tmp_pairlogit_assignment_smoke/summary.json`

Held-out `101_50_bp_nicked`, explicit labels, 1 epoch:

- geometric cutoff `predicted_wc_conflict_rate = 1.0`
- geometric cutoff `predicted_wc_f1 = 0.09677419354838708`
- decoded pair-logit `decoded_pair_conflict_rate = 0.0`
- decoded pair-logit `decoded_pair_f1 = 0.7142857142857142`
- decoded pair-logit precision/recall = `0.7 / 0.7291666666666666`

Comparable 10e A30 rerun of the current pair-center/axis setting:

`outputs/manual_a30_small3_dgnn_candidatewc_top2_paircls2e2_pairsym1e2_paircenter2e2_pairaxis2e2_assignmentmetrics_explicitpairs_physcmp_10e_lr1e3_w1e2/summary.json`

Held-out `101_50_bp_nicked`, explicit labels:

- `final_rmsd = 32.74441146850586`
- `final_os = 0.07248381525278091`
- geometric cutoff `wc_helix_rule_score = 0.45010267824709577`
- geometric cutoff `predicted_wc_f1 = 0.1875`
- geometric cutoff precision/recall = `0.375 / 0.125`
- geometric cutoff `predicted_wc_conflict_rate = 1.0`
- decoded pair-logit `decoded_pair_count = 49`
- decoded pair-logit `decoded_pair_conflict_rate = 0.0`
- decoded pair-logit `decoded_pair_f1 = 0.7010309278350516`
- decoded pair-logit precision/recall = `0.6938775510204082 / 0.7083333333333334`
- decoded pair-logit occupancy = `1.0`

Interpretation:

- The pair head already contains substantially better one-to-one WC partner information than the raw geometric cutoff metric shows.
- The persistent `predicted_wc_conflict_rate = 1.0` is now better interpreted as a coordinate-realization/export problem, not purely a partner-classification problem.
- Next aligned work should couple decoded assignments back into geometry: either generate/export nucleotide positions from decoded pair assignments and pair frames, or add an assignment-coupled coordinate objective that pulls decoded/reference pairs into duplex geometry while pushing unselected candidates away.
