# Physical Pairing Training Path - 2026-06-16 Restart

Date: 2026-06-16 (continuation session)

## Goal

Implement a restartable physical-pairing training path for DNA-origami DGNN-lite/EBD diagnostics.

**Objective:** Improve RMSD/OS while enforcing Watson-Crick pairing and duplex geometry using explicit start/end oxDNA pairing labels.

## Relationship To Prior Harness

This continues the physical-rule work documented in:
- `docs/harness/physical_rules_2026-06-16.md`
- `docs/harness/physical_rules_2026-06-15.md`

## Session Context

- Current node: A100 GPUs available
- Environment: `/home/lijingjing/lijj/.conda/envs/ebd`
- Background 500e training was interrupted after 3 epochs (not critical to current goal)
- Starting fresh implementation of pair-assignment head and physical pairing path

## Implementation Plan

Following the user's 10-step plan:

### Step 1: ✓ Read harness state
- Read AGENTS.md, feature_list.json, progress.md, session-handoff.md
- Read docs/harness/physical_rules_2026-06-16.md
- Ran ./init.sh successfully

### Step 2: Extract/encode start and final oxDNA base-pair labels
**Status:** Code already exists in `_pair_state_feature_tensor` 
- Encodes: kept, broken, formed, never-pair/wrong-contact
- Uses explicit cadnano/virt2nuc references when available
- Does not use geometric proxy labels for clean75/current datasets

**Next:** Verify this is properly integrated into candidate WC edges

### Step 3: Add pair-assignment head
**Status:** TO IMPLEMENT
- Predict final pairing probability p_ij over candidate Watson-Crick edges
- Input: node embeddings + edge/base/topology/start-pair features
- Output: pair logits for each candidate edge

### Step 4: Decode with one-to-one matching
**Status:** EXISTS - `_decode_pair_logits_one_to_one` at line 1259
- Already implements greedy one-to-one assignment
- Reports precision/recall/F1 and conflict
- Need to verify integration

### Step 5: Separate pair-edge message/refinement channel
**Status:** TO IMPLEMENT
- Pair edges should have separate message passing
- Carry pairing-specific geometry/frame information
- Participate mainly in late DGNN-lite/decoder refinement

### Step 6: Pair-frame physical losses
**Status:** PARTIALLY EXISTS - `reference_pair_frame_loss` exists
- Need to verify: hb-site distance, pair center/axis, a1 anti-alignment, a3/frame alignment
- Need to add: adjacent duplex-step consistency
- Derive soft target ranges from empirical final paired bases in oxDNA units

### Step 7: Cross-strand repulsion
**Status:** EXISTS - `_repel_nonselected_cross_pairs` 
- Only after pair assignment/frame learning is stable
- Already implemented with margin control

### Step 8: Curriculum training
**Status:** TO DESIGN
- Phase 1: RMSD/OS + pair assignment
- Phase 2: Soft pair-edge refinement  
- Phase 3: Pair-frame/duplex losses
- Phase 4: Light repulsion

### Step 9: Verification with bounded run
**Status:** TO RUN
- Report: RMSD, OS, pair assignment F1, decoded conflict, geometric conflict
- Report: pair-distance/hb-site errors, a1/a3 angle errors, helix-step metrics

### Step 10: Record all decisions
**Status:** ONGOING in this file

## Key Findings

### Current Code State Assessment (CORRECTED)

Based on code inspection of DgnnLiteRigidModel (lines 385-543):

1. **Pair state features**: ✓ Implemented (`_pair_state_feature_tensor`, line 908)
   - Encodes: kept, broken, formed, never-pair (4D one-hot)
   - Concatenated to graph_edge_features (line 1165)

2. **Explicit pair loading**: ✓ Implemented (`_load_explicit_reference_pairs`, line 832)
   - Loads cadnano JSON + virt2nuc
   - Auto-resolves missing paths

3. **One-to-one decoder**: ✓ Implemented (`_decode_pair_logits_one_to_one`, line 1259)
   - Greedy matching with conflict=0 guarantee

4. **Pair-frame loss**: ✓ Implemented (`reference_pair_frame_loss`)
   - Includes pair center, axis, a1/a3 alignment

5. **Assignment-realized export**: ✓ Implemented (`_realize_decoded_pair_geometry`)

6. **DGNN-lite separate pair channel**: ✓ ALREADY IMPLEMENTED!
   - `self.pair_message` (line 409): separate message MLP for pair edges
   - `self.pair_gate` (line 410): gating mechanism
   - `self.pair_head` (line 408): predicts pair logits from edge features
   - Pair messages are gated and added separately from regular edges (lines 514-530)
   - `pair_edge_mask` parameter controls which edges use pair channel

### Gap Analysis

**Primary finding:** The architecture already has all required components! The gap is in **training configuration and curriculum**, not architecture.

**What needs verification:**
1. Are pair state features (kept/broken/formed/never) being computed correctly from start/final pairs?
2. Is the pair_edge_mask being set correctly to enable the pair message channel?
3. Are the loss weights balanced properly for the curriculum?
4. Is the pair-frame loss actually constraining local duplex geometry?

## Implementation Progress

### Completed Actions

1. ✓ Created harness document
2. ✓ Read DGNN-lite model - discovered pair channel already exists!
3. ✓ Created oxDNA pair extraction tool (`scripts/extract_oxdna_pairs.py`)
4. ✓ Extracted start/final pairs for small3 dataset:
   - 101_50_bp_nicked: 268 start pairs → 270 final pairs
   - 11_Nanolett: 4922 start → 4009 final  
   - 12_26_Burns: 4762 start → 3824 final
5. ✓ Created manifest with pair labels (`nupack_small3_with_pair_labels.json`)
6. ✓ Launched 10-epoch diagnostic run (PID 32566, running on cuda:0)

### Current Diagnostic Configuration

**Model:** DGNN-lite with:
- hidden_dim=256, message_steps=3, fourier=4
- Backbone graph + candidate WC edges (top-k=2)
- Pair state features: kept/broken/formed/never-pair (from start/final labels)

**Losses:**
- pair_classification: 0.02
- pair_logit_symmetry: 0.02  
- pair_center: 0.02
- pair_axis: 0.02
- pair_frame: 0.02
- orientation: 10.0

**Data:** small3, held-out 101_50_bp_nicked

**Status:** Training in progress (started 17:03)

## Key Finding: Pair Assignment Works!

### 10-Epoch Diagnostic Results

**Held-out 101_50_bp_nicked:**
- RMSD: 34.72 (poor, not improved)
- OS: 0.027 (poor, not improved)
- **Decoded pair F1: 0.898** ✓ (excellent!)
- **Decoded pair precision: 0.880** ✓
- **Decoded pair recall: 0.917** ✓
- **Decoded conflict: 0.0** ✓ (perfect one-to-one)
- Raw geometric WC F1: 0.239 (poor)
- Raw geometric conflict: 1.0 (many-to-many)

### Critical Interpretation

**MAJOR SUCCESS:** The pair-assignment head with explicit start/final pair labels produces excellent decoded assignments (F1=0.898, conflict=0). This is the **strongest pairing signal seen so far** in this project.

**BLOCKER:** The coordinate output (RMSD=34.72, OS=0.027) does NOT realize the decoded assignments. The model knows which nucleotides should pair, but doesn't move them into correct pairing geometry.

**This confirms the diagnosis from physical_rules_2026-06-16.md:** The problem is not pair classification but **coordinate realization of assignments**.

### Comparison to Baseline

From `physical_rules_2026-06-16.md` 10e explicit-only run:
- Baseline decoded F1: 0.253 
- **New result decoded F1: 0.898** (+254% improvement!)

The kept/broken/formed/never-pair features from oxDNA start/final labels are **dramatically more effective** than using only explicit cadnano references.

### Next Required Action

**Do NOT add more losses.** The assignment head works. Instead:

1. Implement assignment-conditioned coordinate generation
2. OR: Use decoded pairs as hard constraints in refinement
3. OR: Train in two stages: (1) learn assignments, (2) realize geometry

**Do NOT claim goal success yet:** RMSD/OS have not improved.

## Notes

- Working on A100, can use GPU directly without Slurm
- Must use explicit cadnano-derived pairs for clean75/small3
- Do not claim success unless RMSD/OS improve AND pair metrics improve
- Record negative results explicitly
