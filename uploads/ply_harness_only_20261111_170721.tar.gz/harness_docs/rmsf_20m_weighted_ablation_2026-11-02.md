# 2026-11-02 20M RMSF训练、加权损失与边消融记录

## 数据与划分

- 97个设计中90个20M continuation完成；7个NaN失败设计034/046/050/052/054/066/087不作完整标签。90个标签均通过2000帧、步数5010000–25000000、有限坐标/能量、拓扑行序和哈希校验。
- 每帧proper Kabsch对齐到原initial.dat；Welford逐核苷酸3D RMSF，单位换算0.8518nm；仅使用新增20M帧，单重复有限窗口标签，不代表已证实平衡态。
- seed20261102随机按设计划分72训练/18验证，无测试集。验证集已参与历史分析和checkpoint选择，所有结论为探索性。

## 实验版本区分

- continuation20m_20261102：历史预训练权重与36项历史筛选特征，3seed各200epoch，已完成97设计预测/90设计评估。历史训练设计与新验证集交叉，不能声称严格独立。
- strict_weighted20m_20261102：随机初始化，无历史checkpoint；全部输入几何候选特征，无标签相关筛选；仅72训练设计计算插补/归一化。3seed11/22/33，lr1e-4，200epoch；MSE对照加权MSE（每设计真实最高20%节点权重3，其余1，按权重总和归一）。标签权重仅进入训练损失，不进入模型输入。
- 旧版200epoch加权预检因旧torch不支持stable argsort失败，修复numpy stable排序后只重启加权组，所有3seed最终exit0完成。
- edge_ablation20m_20261102/single_seed120：用户修改为单seed11、max120、patience25、验证macroRMSE选checkpoint。3消融并行，随后补跑相同早停的完整基线；两个损失都比较。旧3seed消融已停止，保留产物但不混入结果。全部8个arm完成，pipeline complete于19:00:02。

## 单种子、相同早停规则消融结果（18验证设计macro）

| 模型 | 损失 | 最佳/停止epoch | RMSE nm | Spearman | Top20召回 | Top20 MAE nm |
|---|---|---:|---:|---:|---:|---:|
| full | mse | 37/62 | 1.727185 | 0.685253 | 59.16% | 0.639397 |
| full | weighted_mse | 25/50 | 1.728447 | 0.674960 | 58.55% | 0.640945 |
| no_spatial | mse | 51/76 | 1.730592 | 0.651666 | 56.79% | 0.655636 |
| no_spatial | weighted_mse | 67/92 | 1.727714 | 0.677623 | 58.62% | 0.629159 |
| no_helix_messages | mse | 75/100 | 1.731611 | 0.666250 | 57.76% | 0.638515 |
| no_helix_messages | weighted_mse | 61/86 | 1.728413 | 0.650008 | 57.14% | 0.594278 |
| no_basepair | mse | 36/61 | 1.730686 | 0.671468 | 58.08% | 0.630808 |
| no_basepair | weighted_mse | 25/50 | 1.728984 | 0.675492 | 58.60% | 0.656234 |

- 普通MSE删空间边rho下降0.0336，关闭helix消息下降0.0190，删配对边下降0.0138；加权版本空间/配对排序变化接近零，关闭helix消息rho下降0.0250但Top20数值MAE改善。只能作单seed当前实现的依赖证据，无显著性/普遍物理重要性结论。
- no_spatial/no_basepair仅删除显式type0/type2后重算标量几何、邻域统计和平滑；保留坐标导出density、配对几何、已缓存type4二跳关系，不能声称清除全部空间/配对信息。no_helix_messages仅绕过RodMessage，保留helix分组、端点池化和其他global context。

## 3seed严格随机初始化：均值基线与加权对照

- 训练设计均值常数1.755012nm；验证常数RMSE1.843002nm、MAE0.421522nm。普通MSE集成RMSE1.714939nm（降低6.95%）、MAE0.295942nm（降低29.79%）、rho0.707352、Top20召回60.43%。加权集成RMSE1.717325、MAE0.295119、rho0.705040、Top20召回60.06%，未稳定超过普通MSE。
- 3seed单模型指标再平均：加权Top20MAE0.606476 vs普通0.634307（降低约4.4%），但rho0.689609 vs0.693000，召回58.82% vs59.24%。勿与集成预测指标混淆。
- 验证6hb_009模型RMSE25.17181nm为极端异常，原因未诊断。保留主分析；事后整设计排除009、固定权重不重选checkpoint时，剩17验证普通集成RMSE0.335123 vs常数0.469116（降低28.56%），MAE0.253084 vs0.374828（降低32.48%），rho0.705490，Top20召回60.68%。仅敏感性分析，不应静默删除009。

## 不变性验证

- helix重编号：3设计001/048/099×3随机双射，共9/9通过；重算特征/rod graph；预测最大差4.768e-7nm。ID仅为分组，不作数值embedding。
- 刚体变换：3设计×3随机种子×旋转/平移/组合，共27/27通过，CPU eval strictseed11 MSE best；位置与局部orientation同步变换，重算全部几何特征；最大差7.153e-7nm。证据支持标量SE(3)不变性，不是向量输出等变或镜像不变验证。

## 可复核产物

- strict_weighted20m_20261102/{constant_baseline_comparison.json,exclude_009_sensitivity.json,helix_relabel_verification.json,rigid_transform_verification.json}。
- edge_ablation20m_20261102/single_seed120/comparison.json及各模型seed11/{mse,weighted_mse}/evaluation.json、history.jsonl、best.pt。
- continuation20m_20261102/{split.json,label_verification.json,summary.json}。

## 未完成事项

- 查清6hb_009极端节点/轨迹RMSF异常原因；本次只记录，不更改数据。
- 单seed消融需重复或独立数据验证才能形成稳定结论；无自动追加训练。
- 原97设计MD总目标仍未全部成功：7失败设计未重跑，不标记97/97完成。
