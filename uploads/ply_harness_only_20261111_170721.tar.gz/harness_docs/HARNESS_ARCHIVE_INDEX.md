# Harness Archive Index

This file routes agents to detailed historical records without requiring
`progress.md` or `feature_list.json` to carry every experiment log.

## Full Pre-Slim Backup

- `backups/harness_2026-06-17_pre_slim/progress.md`: complete pre-slim session log.
- `backups/harness_2026-06-17_pre_slim/feature_list.json`: complete pre-slim feature tracker.
- `backups/harness_2026-06-17_pre_slim/session-handoff.md`: handoff at the time of slimming.

Use these backup files only when the compact files and focused harness docs do
not contain enough context.

## Current Active Work

- `docs/harness/physical_rules_clean75_ablation_2026-06-17.md`: clean75 pair-rule ablation harness for current full 60/15 nt-stratified experiments.
- `docs/harness/wc_edge_mode_ablation_clean75_2026-06-17.md`: current clean75 WC edge-mode ablation notes and run outputs.
- `outputs/clean75_pair_rule_ablation_20260617/`: current clean75 pair-rule ablation outputs.

## TALOS97 RMSF Data Quality And Amplitude

- `docs/harness/talos97_source_structure_audit_2026-11-03.md`: original-input geometry audit across 97 designs; records the design-wide same-helix long-edge pattern and nonlocal-overlap screening candidates. Do not treat its thresholds as automatic exclusion rules.
- `experiments/talos97_rmsf_scalar/input_source_audit_20261103/audit.py` and `input_source_audit.json`: reproducible source audit and per-design measurements/hashes.
- `experiments/talos97_rmsf_scalar/rmse_floor_diagnosis_20261103/REPORT_ZH.md`: continuation trajectory failures and their effect on RMSF validation error; keep trajectory QC separate from initial-geometry QC.
- `docs/harness/rmsf_discrimination_vs_amplitude_calibration_20261103.md`: prior evidence that ranking ability does not establish amplitude calibration, and current diffusion/covariance conclusions.

## Physical Pairing And Rule Ablations

- `docs/harness/physical_pairing_2026-06-16_restart.md`: restart record for physical pairing diagnostics.
- `docs/harness/physical_rules_2026-06-15.md`: earlier physical-rule work.
- `docs/harness/physical_rules_2026-06-16.md`: explicit-only reference-pair correction, assignment-realized variants, and pair-frame loss results.
- `docs/harness/physical_rules_ablation_2026-06-17.md`: small3 unified-split ablation that showed candidate WC edges harmed coordinate RMSD/OS when mixed early into ordinary DGNN-lite message passing.
- `docs/harness/assignment_conditioned_geometry_2026-06-16.md`: assignment-conditioned geometry note.

## DGNN-lite And Non-EBD Diagnostics

- `docs/harness/dgnnlite_wc_helix_plan_2026-06-12.md`: large historical DGNN-lite plan and diagnostics.

Important standing conclusion: DGNN-lite is not the primary EBD diffusion route.
It can be used only as a diagnostic or post-EBD correction path unless the user
explicitly changes direction.

## Remote/GPU Scheduling

- `docs/harness/codex_gpu30_remote_schedule_2026-06-12.md`: remote scheduling and GPU notes.
- `AGENTS.md`: authoritative current GPU scheduling rule; high-memory work must avoid `gpu29`.

## Core Project Docs

- `docs/DNA_ORIGAMI_EBD_PLAN.md`: active research direction.
- `docs/DNA_ORIGAMI_OPEN_QUESTIONS.md`: archived implementation questions.
- `docs/EBD_ENVIRONMENT.md`: installed EBD environment.
- `docs/OXDNA_OUTPUT_SPEC.md`: oxDNA output contract.
- `docs/templates/OXVIEW_COMPARISON_TEMPLATE.md`: oxView comparison page pattern.
- `docs/ARCHITECTURE.md`: architecture notes.
- `docs/VERIFICATION.md`: verification commands and expectations.
