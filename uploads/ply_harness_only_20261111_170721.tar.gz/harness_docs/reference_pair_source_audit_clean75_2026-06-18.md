# Reference Pair Source Audit

## Summary

- Manifest: `/home/lijingjing/lijj/users/lht2/deeporigami/agent/Geodiff_fam/outputs/manifests/nupack_2e6_2000_all_clean75_with_pair_labels.json`
- Designs audited: `75`
- Distance cutoff for pair-label geometry: `4.0`
- Trusted final pair files for geometric proxy: `True`
- Reference pair sources: `{'geometric_proxy_from_final_pair_file': 75}`
- Pair state sources: `{'explicit_start_final': 75}`

## Aggregate Metrics

| Comparison | mean precision/recall | mean node recall | mean F1/pair recall | differing designs |
| --- | ---: | ---: | ---: | ---: |
| prepared_vs_final_pair_file | 1.000000 | n/a | 1.000000 | 0 |
| prepared_vs_final_pair_file_node_scan | 1.000000 | 1.000000 | 1.000000 | 0 |
| prepared_vs_target_geometric | 1.000000 | n/a | 1.000000 | 0 |
| prepared_vs_target_geometric_node_scan | 1.000000 | 1.000000 | 1.000000 | 0 |
| final_pair_file_vs_target_geometric | 1.000000 | n/a | 1.000000 | 0 |

## Lowest Prepared-vs-Final-File Node Scan Designs

| Design | source | prepared pairs | final-file pairs | pair recall | unmatched reference pairs | unmatched reference nodes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 101_50_bp_nicked | geometric_proxy_from_final_pair_file | 270 | 270 | 1.000000 | 0 | 0 |
| 102_3 | geometric_proxy_from_final_pair_file | 140632 | 140632 | 1.000000 | 0 | 0 |
| 105_honeycomb-74-final2 | geometric_proxy_from_final_pair_file | 406456 | 406456 | 1.000000 | 0 | 0 |
| 106_Berlin.1 | geometric_proxy_from_final_pair_file | 58517 | 58517 | 1.000000 | 0 | 0 |
| 10_Langecker_Science_Lipid_Bundle_all_out_correct_adapters_ppo_paper | geometric_proxy_from_final_pair_file | 83746 | 83746 | 1.000000 | 0 | 0 |
| 11_Nanolett_Burns_Howorka_2013 | geometric_proxy_from_final_pair_file | 4009 | 4009 | 1.000000 | 0 | 0 |
| 12_26._Burns_Howorka_ACIE_2013 | geometric_proxy_from_final_pair_file | 3824 | 3824 | 1.000000 | 0 | 0 |
| 130_6_helix_bundle | geometric_proxy_from_final_pair_file | 108113 | 108113 | 1.000000 | 0 | 0 |
| 132_square | geometric_proxy_from_final_pair_file | 78743 | 78743 | 1.000000 | 0 | 0 |
| 133_Double_Layer_Origami | geometric_proxy_from_final_pair_file | 103773 | 103773 | 1.000000 | 0 | 0 |
