SNUPI caDNAno sequence input

Files: design.json (topology), design.csv (sequence assignments), Default.snp (SNUPI parameters), Input.txt (lattice type and design basename), sequences.fasta (scaffold and staple sequences).

Candidate: DBS 6hb short; selector Origami ID 1342; scaffold source dbsACGT_k=5_1342.
TOPSIS rank 1 within this 5,000-sequence pool and this topology. Metrics M1-M4: 30.77314, 70.4842, 8.869449615, 0.5730195642.

The JSON geometry is the validated SNUPI short or nick-joined topology. The CSV assigns the selected 5-prime-to-3-prime scaffold sequence through the geometry and its Watson-Crick complementary staples. The strands cover the full scaffold (776 nt). SNUPI's README documents caDNAno JSON/CSV inputs. This is a sequence/topology input package, not evidence that this candidate folds or has been experimentally validated.
