SNUPI caDNAno sequence input

Files: design.json (topology), design.csv (sequence assignments), Default.snp (SNUPI parameters), Input.txt (lattice type and design basename), sequences.fasta (scaffold and staple sequences).

Candidate: VEC rectangle nick_join_min100; selector Origami ID 4377; scaffold source lambda_NEB_28579.
TOPSIS rank 1 within this 5,000-sequence pool and this topology. Metrics M1-M4: 29090.12196, 13076.24068, 10.05025041, 4.044175148.

The JSON geometry is the validated SNUPI short or nick-joined topology. The CSV assigns the selected 5-prime-to-3-prime scaffold sequence through the geometry and its Watson-Crick complementary staples. The strands cover the full scaffold (6912 nt). SNUPI's README documents caDNAno JSON/CSV inputs. This is a sequence/topology input package, not evidence that this candidate folds or has been experimentally validated.
