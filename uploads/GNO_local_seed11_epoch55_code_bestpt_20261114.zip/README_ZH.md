# GNO-local seed11 best epoch55

历史最佳local RMSF模型，17设计排除009后RMSE0.3142528666nm。checkpoint原先按18设计（含009）选模，17设计结果为事后评估，不是独立测试。

包含原始基础源码、split/protocol、best.pt、归一化manifest和evaluation。权重为state_dict（checkpoint键state），必须用同架构加载。依赖Python+numpy+scipy+torch。原始数据/模态缓存/映射和部分历史import配置不在本包内；这是原工程代码与权重包，不是独立开箱即用项目。不包含MD数据或其他模型权重。
