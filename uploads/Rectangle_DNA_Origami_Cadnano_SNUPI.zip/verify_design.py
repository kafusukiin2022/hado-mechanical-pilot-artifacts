#!/usr/bin/env python3
"""Independent static checks for this particular square-lattice design.

This script is not SNUPI and cannot verify its internal checks, startup,
simulation, or convergence. It uses only the Python standard library.
"""
import collections
import csv
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
SOURCE_JSON = ROOT / "SNUPI_Input/Rectangle.json"
SOURCE_CSV = ROOT / "SNUPI_Input/Rectangle.csv"
V2_JSON = ROOT / "CaDNAno_V2/Rectangle_v2.json"
V2_CSV = ROOT / "CaDNAno_V2/Rectangle_v2.csv"
INFERRED_SCAFFOLD = ROOT / "Scaffold/Modeled_Scaffold_6912nt.txt"
M13 = ROOT / "Scaffold/M13mp18_P7249_Standard.txt"
SOURCE_JSON_SHA = "35d7f643c8b8586da51783e19d5a3451d8d08767e632a73c7b953cd3cbda5a68"
SOURCE_CSV_SHA = "1aef4b533fb99cdda62048b344cff25f294cda993483caec413695039ddadf7d"
EMPTY = [-1, -1, -1, -1]
COMPLEMENT = str.maketrans("ACGT", "TGCA")

# caDNAno2 square-lattice low/high candidate positions, unioned for each
# direction. Checks below also require same-index, reciprocal connections.
PERMITTED = {
    "scaf": [{4, 26, 15, 5, 27, 16}, {18, 28, 7, 19, 29, 8},
             {10, 20, 31, 11, 21, 0}, {2, 12, 23, 3, 13, 24}],
    "stap": [{31, 0}, {23, 24}, {15, 16}, {7, 8}],
}


def check(condition, message):
    if not condition:
        raise ValueError(message)


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def nodes_for(helices, kind):
    return {(num, i) for num, helix in helices.items()
            for i, value in enumerate(helix[kind]) if value != EMPTY}


def endpoint(value):
    match = re.fullmatch(r"(\d+)\[(\d+)\]", value)
    check(match is not None, f"invalid CSV endpoint: {value}")
    return tuple(map(int, match.groups()))


def main():
    check(digest(SOURCE_JSON) == SOURCE_JSON_SHA, "source JSON SHA-256 mismatch")
    check(digest(SOURCE_CSV) == SOURCE_CSV_SHA, "source CSV SHA-256 mismatch")
    check(SOURCE_CSV.read_bytes() == V2_CSV.read_bytes(), "CSV copies differ")
    source = json.loads(SOURCE_JSON.read_text())
    converted = json.loads(V2_JSON.read_text())
    h = {x["num"]: x for x in source["vstrands"]}
    v2 = {x["num"]: x for x in converted["vstrands"]}
    check(len(h) == len(source["vstrands"]) == 24, "helix IDs are missing or duplicated")
    check(h.keys() == v2.keys(), "converted helix IDs differ")
    check(len({(x["row"], x["col"]) for x in h.values()}) == 24,
          "duplicate helix coordinates")
    check({(x["row"], x["col"]) for x in h.values()} == {(n, 0) for n in range(24)},
          "unexpected rectangular helix arrangement")
    changed_colors = 0
    for n, x in h.items():
        check((n - x["row"] - x["col"]) % 2 == 0, f"helix parity mismatch {n}")
        for field in ("num", "row", "col", "scaf", "stap", "skip", "loop"):
            check(x[field] == v2[n][field], f"converted {field} differs on helix {n}")
        changed_colors += x["stap_colors"] != v2[n]["stap_colors"]
        check(all(len(x[field]) == 320 for field in ("scaf", "stap", "skip", "loop")),
              f"incorrect array length at {n}")
        check(not any(x["skip"]) and not any(x["loop"]), f"insertion/deletion at {n}")

    # The SNUPI v1 protocol says double-strand breaks are not considered.
    # Check for adjacent paired sites in each helix at which neither backbone
    # directly continues to the next index. This is a limited local test.
    double_breaks = []
    for n, helix in h.items():
        for i in range(319):
            if not all(x != EMPTY for x in (helix["scaf"][i], helix["stap"][i],
                                            helix["scaf"][i + 1], helix["stap"][i + 1])):
                continue
            target = (n, i + 1)
            joined = [target in (tuple(helix[kind][i][:2]), tuple(helix[kind][i][2:]))
                      for kind in ("scaf", "stap")]
            if not any(joined):
                double_breaks.append((n, i))
    check(not double_breaks, f"local double backbone discontinuities: {double_breaks[:5]}")

    counts = collections.Counter()
    components = {}
    for kind in ("scaf", "stap"):
        nodes = nodes_for(h, kind)
        for num, i in nodes:
            helix = h[num]
            cell = helix[kind][i]
            check(len(cell) == 4 and all(type(x) is int for x in cell),
                  f"malformed {kind} cell {num}[{i}]")
            for offset, reverse in ((0, 2), (2, 0)):
                to, j = cell[offset:offset + 2]
                check((to == -1) == (j == -1), f"half-null link {kind} {num}[{i}]")
                if to == -1:
                    continue
                check(to in h and 0 <= j < 320, f"link out of bounds {kind} {num}[{i}]")
                check(h[to][kind][j][reverse:reverse + 2] == [num, i],
                      f"nonreciprocal {kind} link {num}[{i}]")
                if to == num:
                    check(abs(j - i) == 1, f"nonconsecutive in-helix link {kind} {num}[{i}]")

            to, j = cell[2:4]
            if to < 0 or to == num:
                continue
            other = h[to]
            r, c = helix["row"], helix["col"]
            if (r + c) % 2 == 0:
                neighbors = [(r, c + 1), (r + 1, c), (r, c - 1), (r - 1, c)]
            else:
                neighbors = [(r, c - 1), (r - 1, c), (r, c + 1), (r + 1, c)]
            target = (other["row"], other["col"])
            check(target in neighbors and i == j, f"nonlocal/offset crossover {kind} {num}[{i}]")
            direction = neighbors.index(target)
            check(i % 32 in PERMITTED[kind][direction],
                  f"nonstandard square-lattice crossover {kind} {num}[{i}]")
            check(all(cell != EMPTY for cell in (helix["scaf"][i], helix["stap"][i],
                                                other["scaf"][j], other["stap"][j])),
                  f"unpaired crossover endpoint {kind} {num}[{i}]")
            counts[kind] += 1

        remaining = set(nodes)
        strands = []
        while remaining:
            stack = [next(iter(remaining))]
            group = set()
            while stack:
                node = stack.pop()
                if node in group:
                    continue
                group.add(node)
                remaining.discard(node)
                cell = h[node[0]][kind][node[1]]
                for offset in (0, 2):
                    nxt = tuple(cell[offset:offset + 2])
                    if nxt[0] >= 0:
                        stack.append(nxt)
            starts = [node for node in group if h[node[0]][kind][node[1]][0] == -1]
            ends = [node for node in group if h[node[0]][kind][node[1]][2] == -1]
            check(len(starts) == len(ends) == 1, f"nonlinear/circular component in {kind}")
            strands.append((len(group), starts[0], ends[0]))
        components[kind] = strands

    check(len(components["scaf"]) == 1, "expected one scaffold")
    check(len(components["stap"]) == 216, "expected 216 staples")
    strands = {(start, end): length for length, start, end in components["stap"]}
    check(len(strands) == 216, "duplicate staple endpoints")
    assigned, seen = {}, set()
    with SOURCE_CSV.open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    check(len(rows) == 216, "CSV row count is not 216")
    for row in rows:
        start, end = endpoint(row["Start"]), endpoint(row["End"])
        seq = row["Sequence"].strip().upper()
        check((start, end) in strands and (start, end) not in seen, "CSV endpoint mismatch/duplicate")
        seen.add((start, end))
        check(set(seq) <= set("ACGT"), "non-DNA symbol in CSV")
        check(len(seq) == int(row["Length"]) == strands[(start, end)], "CSV length mismatch")
        node = start
        for base in seq:
            check(node not in assigned and node[0] >= 0, "overlapping or truncated CSV strand")
            assigned[node] = base.translate(COMPLEMENT)
            node = tuple(h[node[0]]["stap"][node[1]][2:4])
        check(node == (-1, -1), "CSV sequence is shorter than its topology")
    check(len(seen) == len(strands), "not every staple has a sequence")

    scaffold_nodes = nodes_for(h, "scaf")
    check(set(assigned) == scaffold_nodes, "scaffold and staples do not cover the same positions")
    node = components["scaf"][0][1]
    inferred = []
    while node != (-1, -1):
        inferred.append(assigned[node])
        node = tuple(h[node[0]]["scaf"][node[1]][2:4])
    inferred = "".join(inferred)
    check(inferred == "".join(INFERRED_SCAFFOLD.read_text().split()), "inferred scaffold mismatch")
    m13 = "".join(M13.read_text().split())
    check(len(inferred) == 6912 and len(m13) == 7249, "unexpected scaffold lengths")
    rotation = (m13 + m13).find(inferred)
    check(rotation == 5587, "inferred sequence does not match standard M13 at expected rotation")

    print("Independent square-lattice / crossover / sequence checks: PASS")
    print("This does not run or replicate SNUPI and is not proof of SNUPI acceptance.\n")
    print("Original JSON SHA-256:", SOURCE_JSON_SHA)
    print("Original CSV SHA-256: ", SOURCE_CSV_SHA)
    print("Helices: 24; square lattice; 320 array entries per helix")
    print("Scaffold: 1 linear modeled strand, 6912 nt; staples: 216 linear strands")
    print("No deletions/insertions; no adjacent paired-site double backbone breaks")
    print("Crossovers: 46 scaffold + 390 staple = 436; all neighboring, same-index,")
    print("and within caDNAno2 square candidate positions; no nonlocal transitions")
    print("All 216 CSV rows: unique start/end mapping and sequence length match")
    print("All 6912 scaffold positions have a complementary staple base")
    print("Inferred modeled scaffold matches M13mp18 p7249 rotation 5587; 337 nt unmodeled")
    print("caDNAno v2 round-trip: all numbers, coordinates, topology, loop and skip arrays identical")
    print(f"Color metadata changed on {changed_colors} helices; original CSV retained")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, IndexError, OSError, json.JSONDecodeError) as exc:
        print("CHECK FAILED:", exc, file=sys.stderr)
        sys.exit(1)
