Rothemund 单层长方形 DNA 折纸：设计与检查
===========================================

重要结论
--------
本包提供有公开实验研究基础的长方形设计、配套序列和 caDNAno v2 转换
版本，并通过了本包独立的方格晶格、交叉点和序列静态检查。没有安装或
运行 SNUPI，因此不能声称已经通过 SNUPI 自身的 lattice/crossover
检查，也不能保证其后模拟收敛。

设计来源与论文
--------------
CanDo 官方 Example 4 将该设计列为 Rothemund 单层 DNA rectangle：
约 50 × 100 nm，24 条双螺旋，方格晶格。其原始下载包包含 caDNAno
JSON 与配套序列 CSV：
https://www.cando-dna-origami.org/examples/
https://www.cando-dna-origami.org/DNA_rectangle.zip

1. Rothemund, Nature 440, 297–302 (2006)，介绍并实验研究 DNA 折纸
   二维形状，包括相关的长方形设计：
   https://doi.org/10.1038/nature04586
2. Kick 等, Nano Letters 15, 4672–4676 (2015)，实验研究了
   Rothemund 长方形的一个变体，并报告 TEM 图像：
   https://doi.org/10.1021/acs.nanolett.5b01461
3. CanDo 页面给出该长方形的有限元分析示例。其研究与模型背景见：
   https://doi.org/10.1093/nar/gkr1173

这些资料说明该设计家族具有实验及计算研究基础。2015 年论文使用的是
一个变体；不应据此声称每篇论文都使用了本包中逐字节相同的 JSON 和 CSV。

文件清单
--------
SNUPI_Input/Rectangle.json
    CanDo 原始 JSON，文件内容未改动；与下方 CSV 同名配对。
SNUPI_Input/Rectangle.csv
    CanDo 原始 216 条辅助链序列 CSV，文件内容未改动。
CaDNAno_V2/Rectangle_v2.json
    使用 scadnano 0.21.1 的 caDNAno v2 导出器转换；导出后将内部 name
    字段调整为 Rectangle_v2。链路、螺旋位置、插入和删除数组与原件一致。
    导出器更新了颜色元数据，颜色不作为序列或拓扑的一部分。
CaDNAno_V2/Rectangle_v2.csv
    与 CanDo 原始 CSV 逐字节相同；起点、终点及长度与 v2 拓扑对应。
Scaffold/Modeled_Scaffold_6912nt.txt
    从配套辅助链序列和拓扑互补推导出的 6912 nt 建模区域。
Scaffold/M13mp18_P7249_Standard.txt
    供序列比对的标准 7249 nt M13mp18；从 scadnano 0.21.1 的 m13()
    rotation=0 序列取得。建模区域对应循环位置 5587 起的连续 6912 nt。
    标准 7249 nt 中剩余 337 nt 未由本 JSON 表示，不能视为已在模型中。
Input_Template.txt
    依据官方 SNUPI v3.10 输入格式准备的方格晶格输入行。
verify_design.py
    仅使用 Python 3 标准库的本地、独立静态检查脚本。
Validation_Report.txt
    该检查脚本的实际输出。

已完成的核验
------------
1. 原始文件 SHA-256：
   JSON: 35d7f643c8b8586da51783e19d5a3451d8d08767e632a73c7b953cd3cbda5a68
   CSV:  1aef4b533fb99cdda62048b344cff25f294cda993483caec413695039ddadf7d
2. 原件和转换后的文件均能被 scadnano 0.21.1 的 caDNAno v2 导入器
   读为 square 格式，包含 24 个虚拟螺旋、1 条支架和 216 条辅助链。
   这不是用 caDNAno 桌面程序或 SNUPI 本身做的验证。
3. 前后拓扑引用均双向一致，没有越界引用；24 个螺旋坐标不重复，符合
   方格奇偶性。320 个位置/螺旋为 32 的整数倍；无插入和删除。
4. 46 个支架连接及 390 个辅助链连接共 436 个跨螺旋连接，均连接
   方格邻居、使用相同碱基索引，并位于 caDNAno2 对应方向的候选位置。
   没有非邻格的跨螺旋连接。候选位置与邻格算法依据：
   https://github.com/douglaslab/cadnano2/blob/239ecc851407b64b44a8a4bdecdd5eb4848868f5/cadnano2/model/parts/squarepart.py
5. 每个 CSV 序列的起点、终点和长度都与一条唯一辅助链匹配；全部
   6912 个建模支架位点都能由 CSV 推导出互补碱基。
6. SNUPI v1 官方协议要求生成 PDB 时支架为线性、删除不要放在 crossover
   或 nick、分析不考虑双链断裂。这里模型支架线性，没有删除；按相邻
   配对位点逐螺旋检查，没有发现两条骨架同时中断的局部位置。这些仍不是
   SNUPI 自身检查，也不能覆盖它可能采用的全部判定。

SNUPI 使用提示
--------------
官方项目说明： https://github.com/SSDL-SNU/SNUPI
本设计选择 S，即 Square（方格），不要选择 H（蜂窝）。若已有 SNUPI，
将 SNUPI_Input 文件夹放在与其 EXAMPLE 文件夹同一级，并将以下行加入
SNUPI 自己的 Input.txt：

    S  SNUPI_Input/Rectangle

同名 JSON 和 CSV 应保留在一起。该安排基于官方输入说明，不等于实际运行
通过。若使用转换版本，将 CaDNAno_V2 放在同一级，再参照模板中的备选行。
SNUPI 官方协议中的静力示例允许缺少 CSV；本包已提供匹配 CSV。

重新运行本包的独立静态检查：
    python verify_design.py

所有路径和文件名均为英文；本说明采用 UTF-8 编码。
